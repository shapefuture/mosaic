from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import shutil
import subprocess
from typing import Sequence

@dataclass(frozen=True)
class FirecrackerConfig:
    kernel_image: str
    rootfs: str
    memory_mib: int = 256
    vcpus: int = 1

class FirecrackerBackend:
    """Firecracker adapter: uses the real binary when installed, never silently degrades."""
    def __init__(self, binary: str | None = None):
        self.binary = binary or shutil.which("firecracker")

    @property
    def available(self) -> bool:
        return bool(self.binary)

    def start(self, cfg: FirecrackerConfig, *, socket_path: str) -> subprocess.Popen[str]:
        if not self.binary:
            raise RuntimeError("firecracker binary is unavailable")
        cmd = [self.binary, "--api-sock", socket_path]
        return subprocess.Popen(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def require_available(self) -> str:
        if not self.binary:
            raise RuntimeError("Firecracker is required but unavailable")
        return self.binary
