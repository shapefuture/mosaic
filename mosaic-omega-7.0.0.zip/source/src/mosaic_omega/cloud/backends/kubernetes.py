from __future__ import annotations
from dataclasses import dataclass
import shutil
import subprocess
from typing import Mapping

@dataclass(frozen=True)
class KubernetesCapabilities:
    available: bool
    kubectl: str | None

class KubernetesBackend:
    def __init__(self, kubectl: str | None = None):
        self.capabilities = KubernetesCapabilities(bool(kubectl or shutil.which("kubectl")), kubectl or shutil.which("kubectl"))

    def apply(self, manifest: str, *, namespace: str = "default") -> subprocess.CompletedProcess[str]:
        if not self.capabilities.available:
            raise RuntimeError("kubectl is unavailable")
        return subprocess.run([self.capabilities.kubectl, "apply", "-n", namespace, "-f", "-"], input=manifest, text=True, capture_output=True, check=False)

    def delete(self, manifest: str, *, namespace: str = "default") -> subprocess.CompletedProcess[str]:
        if not self.capabilities.available:
            raise RuntimeError("kubectl is unavailable")
        return subprocess.run([self.capabilities.kubectl, "delete", "-n", namespace, "-f", "-"], input=manifest, text=True, capture_output=True, check=False)
