from __future__ import annotations
from dataclasses import dataclass
import json
from urllib import request

@dataclass(frozen=True)
class CloudflareCapabilities:
    account_id: str
    available: bool = True

class CloudflareSandboxBackend:
    """Thin provider adapter. Actual endpoint/account URL is injected by deployment config."""
    def __init__(self, account_id: str, endpoint: str):
        self.capabilities = CloudflareCapabilities(account_id=account_id)
        self.endpoint = endpoint.rstrip("/")

    def request(self, path: str, payload: dict, *, token: str) -> dict:
        body = json.dumps(payload).encode()
        req = request.Request(f"{self.endpoint}/{path.lstrip('/')}", data=body, method="POST", headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
        with request.urlopen(req, timeout=20) as resp:
            return json.loads(resp.read().decode())
