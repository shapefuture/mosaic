from __future__ import annotations
from dataclasses import dataclass
import shutil
import subprocess
from pathlib import Path
from typing import Sequence

@dataclass(frozen=True)
class WASMCapabilities:
    available: bool
    runner: str | None

class WASMRuntime:
    def __init__(self, runner: str | None = None):
        candidate = runner or shutil.which("wasmtime") or shutil.which("wasmer")
        self.capabilities = WASMCapabilities(bool(candidate), candidate)

    def run(self, wasm_path: str | Path, args: Sequence[str] = (), *, timeout_s: float = 10.0) -> subprocess.CompletedProcess[str]:
        if not self.capabilities.available:
            raise RuntimeError("WASM runtime unavailable; install wasmtime/wasmer or use a cloud backend")
        cmd = [self.capabilities.runner, str(wasm_path), *map(str, args)]
        return subprocess.run(cmd, text=True, capture_output=True, timeout=timeout_s, check=False)
