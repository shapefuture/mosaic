from __future__ import annotations
from dataclasses import dataclass, field
from hashlib import sha256
import json
from typing import Any, Iterable

@dataclass(frozen=True, order=True)
class Dot:
    counter: int
    node_id: str

@dataclass(frozen=True)
class RegisterOp:
    key: str
    value: Any
    dot: Dot
    deleted: bool = False

class LWWMapCRDT:
    """Small deterministic op-based LWW map with causal dots.

    The implementation is intentionally dependency-free. Operations are content
    addressed and merge is commutative/idempotent for equal dots, while higher
    Lamport dots win conflicting writes. It is suitable for metadata/state
    coordination; large immutable artifacts remain outside the CRDT.
    """
    def __init__(self, node_id: str):
        self.node_id = node_id
        self._counter = 0
        self._ops: dict[tuple[str, Dot], RegisterOp] = {}
        self._heads: dict[str, Dot] = {}

    def _next(self) -> Dot:
        self._counter += 1
        dot = Dot(self._counter, self.node_id)
        return dot

    def put(self, key: str, value: Any) -> RegisterOp:
        op = RegisterOp(key, value, self._next(), False)
        self.apply(op)
        return op

    def delete(self, key: str) -> RegisterOp:
        op = RegisterOp(key, None, self._next(), True)
        self.apply(op)
        return op

    def apply(self, op: RegisterOp) -> None:
        self._counter = max(self._counter, op.dot.counter)
        existing = self._heads.get(op.key)
        if existing is None or op.dot > existing:
            self._heads[op.key] = op.dot
        self._ops[(op.key, op.dot)] = op

    def merge(self, other: "LWWMapCRDT") -> None:
        for op in other._ops.values():
            self.apply(op)

    def value(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for key, dot in self._heads.items():
            op = self._ops[(key, dot)]
            if not op.deleted:
                out[key] = op.value
        return out

    def operations(self) -> tuple[RegisterOp, ...]:
        return tuple(sorted(self._ops.values(), key=lambda o: (o.dot.counter, o.dot.node_id, o.key)))

    def digest(self) -> str:
        payload = [
            {"key": o.key, "value": o.value, "counter": o.dot.counter, "node": o.dot.node_id, "deleted": o.deleted}
            for o in self.operations()
        ]
        return sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

    def export(self) -> list[dict[str, Any]]:
        return [
            {"key": o.key, "value": o.value, "counter": o.dot.counter, "node": o.dot.node_id, "deleted": o.deleted}
            for o in self.operations()
        ]

    @classmethod
    def from_export(cls, node_id: str, rows: Iterable[dict[str, Any]]) -> "LWWMapCRDT":
        c = cls(node_id)
        for row in rows:
            c.apply(RegisterOp(row["key"], row.get("value"), Dot(int(row["counter"]), str(row["node"])), bool(row.get("deleted", False))))
        return c
