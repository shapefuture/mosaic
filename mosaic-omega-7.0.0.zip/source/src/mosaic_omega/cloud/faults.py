from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Iterable

@dataclass
class Node:
    node_id: str
    alive: bool = True
    inflight: int = 0

class MultiNodeFaultHarness:
    """Deterministic multi-node fault injector for stateless/task-handle recovery."""
    def __init__(self, nodes: Iterable[str]):
        self.nodes: Dict[str, Node] = {n: Node(n) for n in nodes}
        self.tasks: dict[str, str] = {}

    def assign(self, task_id: str) -> str:
        live = [n for n in self.nodes.values() if n.alive]
        if not live:
            raise RuntimeError("no live nodes")
        node = min(live, key=lambda n: n.inflight)
        node.inflight += 1
        self.tasks[task_id] = node.node_id
        return node.node_id

    def fail(self, node_id: str) -> list[str]:
        node = self.nodes[node_id]
        node.alive = False
        orphaned = [t for t, n in self.tasks.items() if n == node_id]
        return orphaned

    def recover(self, task_id: str) -> str:
        if task_id not in self.tasks:
            raise KeyError(task_id)
        old = self.tasks[task_id]
        if self.nodes[old].alive:
            return old
        new = self.assign(task_id)
        return new

    def restart_all(self) -> list[str]:
        orphaned: list[str] = []
        for node_id in list(self.nodes):
            orphaned.extend(self.fail(node_id)) if self.nodes[node_id].alive else None
        for task_id in orphaned:
            self.nodes[next(iter(self.nodes))].alive = True
            self.recover(task_id)
        return orphaned
