from __future__ import annotations
from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from typing import Any, Callable

from .mcp import MCPRequest, StatelessMCPGateway

class MCPHTTPServer:
    """Actual dependency-free HTTP transport for the stateless gateway."""
    def __init__(self, gateway: StatelessMCPGateway, host: str = "127.0.0.1", port: int = 8787):
        self.gateway = gateway
        self.host = host
        self.port = port
        gateway_ref = gateway

        class Handler(BaseHTTPRequestHandler):
            server_version = "MOSAIC-MCP/1.0"
            def _send(self, status: int, payload: dict[str, Any]) -> None:
                body = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self) -> None:
                if self.path == "/healthz":
                    self._send(200, {"ok": True})
                    return
                if self.path == "/mcp":
                    self._send(405, {"error": "POST required"})
                    return
                self._send(404, {"error": "not found"})

            def do_POST(self) -> None:
                if self.path not in {"/mcp", "/"}:
                    self._send(404, {"error": "not found"})
                    return
                try:
                    size = int(self.headers.get("Content-Length", "0"))
                    if size > 2 * 1024 * 1024:
                        self._send(413, {"error": "payload too large"})
                        return
                    raw = self.rfile.read(size)
                    obj = json.loads(raw or b"{}")
                    req = MCPRequest(
                        method=str(obj.get("method", "")),
                        params=obj.get("params") or {},
                        tenant_id=str(obj.get("tenant_id", "")),
                        request_id=obj.get("id"),
                        state_handle=obj.get("state_handle"),
                        capability=obj.get("capability"),
                    )
                    response = gateway_ref.handle(req)
                    self._send(200 if response.error is None else 400, {
                        "jsonrpc": "2.0",
                        "id": response.request_id,
                        "result": response.result,
                        "error": response.error,
                    })
                except Exception as exc:
                    self._send(400, {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": str(exc)}})

            def log_message(self, fmt: str, *args: Any) -> None:
                return

        self._server = ThreadingHTTPServer((host, port), Handler)

    @property
    def server_address(self) -> tuple[str, int]:
        return self._server.server_address[0], int(self._server.server_address[1])

    def serve_forever(self) -> None:
        self._server.serve_forever()

    def shutdown(self) -> None:
        self._server.shutdown()
        self._server.server_close()
