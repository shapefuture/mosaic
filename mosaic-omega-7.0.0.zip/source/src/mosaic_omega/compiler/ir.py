from __future__ import annotations
from dataclasses import dataclass, field
from hashlib import sha256
import json
from typing import Any, Mapping

from .effects import EffectSet


@dataclass(frozen=True)
class ResourceBudget:
    cpu_ms: float = 0.0
    memory_mb: float = 0.0
    network_mb: float = 0.0
    usd: float = 0.0
    energy_j: float = 0.0


@dataclass(frozen=True)
class UnitContract:
    inputs: tuple[str, ...] = ()
    outputs: tuple[str, ...] = ()
    preconditions: tuple[str, ...] = ()
    postconditions: tuple[str, ...] = ()


@dataclass(frozen=True)
class ComputationalUnit:
    unit_id: str
    kind: str
    contract: UnitContract = UnitContract()
    effects: EffectSet = EffectSet()
    dependencies: tuple[str, ...] = ()
    implementation: str = "interpreted"
    deterministic: bool = True
    resource_budget: ResourceBudget = ResourceBudget()
    verifier_ids: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def digest(self) -> str:
        payload = {
            "unit_id": self.unit_id,
            "kind": self.kind,
            "contract": self.contract.__dict__,
            "effects": {
                "required": sorted(self.effects.required),
                "produced": sorted(self.effects.produced),
                "reversible": sorted(self.effects.reversible),
            },
            "dependencies": list(self.dependencies),
            "implementation": self.implementation,
            "deterministic": self.deterministic,
            "resource_budget": self.resource_budget.__dict__,
            "verifier_ids": list(self.verifier_ids),
            "metadata": dict(self.metadata),
        }
        return sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

    def with_implementation(self, implementation: str) -> "ComputationalUnit":
        return ComputationalUnit(
            self.unit_id, self.kind, self.contract, self.effects, self.dependencies,
            implementation, self.deterministic, self.resource_budget, self.verifier_ids, dict(self.metadata)
        )


@dataclass(frozen=True)
class ProgramIR:
    units: tuple[ComputationalUnit, ...]
    entrypoints: tuple[str, ...] = ()
    authority: frozenset[str] = frozenset()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def digest(self) -> str:
        payload = {
            "units": [u.digest for u in self.units],
            "entrypoints": list(self.entrypoints),
            "authority": sorted(self.authority),
            "metadata": dict(self.metadata),
        }
        return sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

    def unit_map(self) -> dict[str, ComputationalUnit]:
        return {u.unit_id: u for u in self.units}

    def validate(self) -> tuple[str, ...]:
        errors: list[str] = []
        units = self.unit_map()
        if len(units) != len(self.units):
            errors.append("duplicate unit_id")
        for u in self.units:
            for dep in u.dependencies:
                if dep not in units:
                    errors.append(f"missing dependency: {u.unit_id}->{dep}")
        visiting: set[str] = set()
        visited: set[str] = set()
        def dfs(node: str) -> None:
            if node in visiting:
                errors.append(f"cycle detected at {node}")
                return
            if node in visited:
                return
            visiting.add(node)
            for dep in units[node].dependencies:
                if dep in units:
                    dfs(dep)
            visiting.remove(node)
            visited.add(node)
        for u in self.units:
            dfs(u.unit_id)
        if self.entrypoints and not set(self.entrypoints).issubset(units):
            errors.append("entrypoint missing")
        for u in self.units:
            check = u.effects.allows(self.authority)
            if not check:
                errors.append(f"unauthorized effects: {u.unit_id}")
        return tuple(dict.fromkeys(errors))
