from __future__ import annotations
from dataclasses import dataclass, field
from typing import Iterable, Mapping


@dataclass(frozen=True)
class VerificationNode:
    node_id: str
    obligation: str
    dependencies: tuple[str, ...] = ()
    evidence: tuple[str, ...] = ()
    valid: bool | None = None
    invalidation_keys: tuple[str, ...] = ()
    recompute_cost: float = 1.0


@dataclass(frozen=True)
class ResidualPlan:
    invalidated: tuple[str, ...]
    preserved: tuple[str, ...]
    estimated_cost: float


class ResidualVerifier:
    """Incremental verifier graph: invalidate only evidence downstream of a change."""
    def __init__(self, nodes: Iterable[VerificationNode] = ()) -> None:
        self._nodes = {n.node_id: n for n in nodes}

    def add(self, node: VerificationNode) -> None:
        self._nodes[node.node_id] = node

    def plan(self, changed_keys: Iterable[str]) -> ResidualPlan:
        keys = set(changed_keys)
        invalid = set()
        changed = True
        while changed:
            changed = False
            for node in self._nodes.values():
                if node.node_id in invalid:
                    continue
                if keys.intersection(node.invalidation_keys) or any(dep in invalid for dep in node.dependencies):
                    invalid.add(node.node_id)
                    changed = True
        preserved = set(self._nodes) - invalid
        cost = sum(self._nodes[n].recompute_cost for n in invalid)
        return ResidualPlan(tuple(sorted(invalid)), tuple(sorted(preserved)), cost)

    def invalidate(self, changed_keys: Iterable[str]) -> ResidualPlan:
        plan = self.plan(changed_keys)
        for node_id in plan.invalidated:
            n = self._nodes[node_id]
            self._nodes[node_id] = VerificationNode(
                n.node_id, n.obligation, n.dependencies, n.evidence, None, n.invalidation_keys, n.recompute_cost
            )
        return plan
