from __future__ import annotations
from dataclasses import dataclass, field
from typing import FrozenSet, Iterable


@dataclass(frozen=True)
class EffectSet:
    """Capability/effect contract for an executable unit.

    Effects are explicit authority requests. A compiled unit is valid only when
    requested effects are contained by the policy budget.
    """
    required: FrozenSet[str] = frozenset()
    produced: FrozenSet[str] = frozenset()
    reversible: FrozenSet[str] = frozenset()

    def allows(self, policy: Iterable[str]) -> bool:
        return self.required.issubset(frozenset(policy))

    def union(self, other: "EffectSet") -> "EffectSet":
        return EffectSet(
            self.required | other.required,
            self.produced | other.produced,
            self.reversible | other.reversible,
        )

    def digest(self) -> str:
        import hashlib, json
        payload = json.dumps({
            "required": sorted(self.required),
            "produced": sorted(self.produced),
            "reversible": sorted(self.reversible),
        }, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(payload.encode()).hexdigest()


@dataclass(frozen=True)
class EffectViolation:
    effect: str
    message: str


@dataclass(frozen=True)
class EffectCheck:
    allowed: bool
    violations: tuple[EffectViolation, ...] = ()


def check_effects(effects: EffectSet, policy: Iterable[str]) -> EffectCheck:
    allowed = frozenset(policy)
    violations = tuple(
        EffectViolation(e, f"effect '{e}' is not authorized")
        for e in sorted(effects.required - allowed)
    )
    return EffectCheck(not violations, violations)
