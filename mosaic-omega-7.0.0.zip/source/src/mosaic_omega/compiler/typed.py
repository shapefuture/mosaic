from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, Mapping

from .ir import ComputationalUnit, ProgramIR


@dataclass(frozen=True)
class TypeErrorInfo:
    unit_id: str
    message: str


@dataclass(frozen=True)
class TypeCheckResult:
    valid: bool
    errors: tuple[TypeErrorInfo, ...]


class CapabilityTypeChecker:
    """Small structural type/effect checker for capability composition."""
    def check(self, program: ProgramIR) -> TypeCheckResult:
        units = program.unit_map()
        errors: list[TypeErrorInfo] = []
        for unit in program.units:
            if not unit.dependencies:
                continue
            deps = [units[d] for d in unit.dependencies if d in units]
            produced = {o for d in deps for o in d.contract.outputs}
            missing = [i for i in unit.contract.inputs if i not in produced and i not in unit.contract.preconditions]
            if missing:
                errors.append(TypeErrorInfo(unit.unit_id, f"missing inputs: {', '.join(missing)}"))
        return TypeCheckResult(not errors, tuple(errors))
