from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class VerifierEvidence:
    verifier_id: str
    independent_group: str
    cost_usd: float
    strength: float


@dataclass(frozen=True)
class PortfolioSelection:
    selected: tuple[str, ...]
    estimated_cost_usd: float
    estimated_strength: float


def select_minimal_portfolio(evidence: tuple[VerifierEvidence, ...], *, target_strength: float, max_cost_usd: float) -> PortfolioSelection:
    # Greedy set cover over independent verification groups, favoring strength / cost.
    remaining = list(evidence)
    chosen: list[VerifierEvidence] = []
    groups: set[str] = set()
    strength = 0.0
    cost = 0.0
    while remaining and strength < target_strength:
        candidates = sorted(
            remaining,
            key=lambda x: (x.strength / max(x.cost_usd, 1e-9)) * (1.0 if x.independent_group not in groups else 0.3),
            reverse=True,
        )
        pick = candidates[0]
        if cost + pick.cost_usd > max_cost_usd:
            remaining.remove(pick)
            continue
        chosen.append(pick)
        remaining.remove(pick)
        groups.add(pick.independent_group)
        strength = min(1.0, 1.0 - (1.0 - strength) * (1.0 - min(pick.strength, 0.999)))
        cost += pick.cost_usd
    return PortfolioSelection(tuple(x.verifier_id for x in chosen), cost, strength)
