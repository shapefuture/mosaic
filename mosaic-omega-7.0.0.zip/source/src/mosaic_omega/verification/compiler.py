from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class VerificationPlan:
    stages: tuple[str, ...]
    estimated_cost_usd: float

class VerificationCompiler:
    """Compiles the cheapest sufficient verifier cascade from risk/change/value."""
    COST = {"syntax":0.0001,"type":0.0002,"unit":0.001,"static":0.002,"property":0.004,"differential":0.008,"fuzz":0.02,"symbolic":0.05,"formal":0.15,"neural":0.08}

    def compile(self, *, risk: float, novelty: float, change_surface: float, value: float, environment_drift: float = 0.0, verifier_uncertainty: float = 0.0) -> VerificationPlan:
        stages = ["syntax", "type", "unit"]
        if risk > 0.3 or change_surface > 0.3:
            stages += ["static", "property"]
        if novelty > 0.25 or environment_drift > 0.2:
            stages += ["differential"]
        if risk > 0.7 or value > 0.8 or verifier_uncertainty > 0.4:
            stages += ["fuzz"]
        if (risk > 0.9 and novelty > 0.6) or verifier_uncertainty > 0.7:
            stages += ["symbolic", "formal"]
        if novelty > 0.8 and risk > 0.6:
            stages += ["neural"]
        return VerificationPlan(tuple(stages), sum(self.COST[s] for s in stages))
