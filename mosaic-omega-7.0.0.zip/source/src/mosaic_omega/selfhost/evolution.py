from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from typing import Callable, Iterable


@dataclass(frozen=True)
class MutationCandidate:
    candidate_id: str
    parent_digest: str
    description: str
    source_hash: str

    @property
    def digest(self) -> str:
        return sha256(f"{self.candidate_id}|{self.parent_digest}|{self.description}|{self.source_hash}".encode()).hexdigest()


@dataclass(frozen=True)
class PromotionGate:
    tests_passed: bool
    holdout_passed: bool
    adversarial_passed: bool
    improvement: bool
    replayable: bool

    @property
    def accepted(self) -> bool:
        return all((self.tests_passed, self.holdout_passed, self.adversarial_passed, self.improvement, self.replayable))


class SelfHostController:
    """Build/measure/promote controller for MOSAIC self-modification.

    It intentionally never mutates the live process. A caller must supply the
    isolated build/test function and an independent promotion gate.
    """
    def propose(self, parent_digest: str, *, description: str, source_hash: str) -> MutationCandidate:
        cid = sha256(f"{parent_digest}|{description}|{source_hash}".encode()).hexdigest()[:16]
        return MutationCandidate(cid, parent_digest, description, source_hash)

    def promote(self, gate: PromotionGate) -> bool:
        return gate.accepted
