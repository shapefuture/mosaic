from __future__ import annotations
from dataclasses import dataclass
import shutil
import subprocess
from typing import Sequence


@dataclass(frozen=True)
class FormalResult:
    backend: str
    available: bool
    passed: bool
    command: tuple[str, ...] = ()
    output: str = ""


class FormalBackend:
    name = "base"
    executables: tuple[str, ...] = ()

    def available(self) -> bool:
        return any(shutil.which(x) for x in self.executables)

    def verify(self, command: Sequence[str], *, timeout_s: float = 30.0) -> FormalResult:
        exe = shutil.which(command[0]) if command else None
        if not exe:
            return FormalResult(self.name, False, False, tuple(command), "backend unavailable")
        try:
            proc = subprocess.run(command, capture_output=True, text=True, timeout=timeout_s, check=False)
            return FormalResult(self.name, True, proc.returncode == 0, tuple(command), (proc.stdout + proc.stderr)[-10000:])
        except (OSError, subprocess.TimeoutExpired) as exc:
            return FormalResult(self.name, True, False, tuple(command), str(exc))


class LeanBackend(FormalBackend):
    name = "lean"
    executables = ("lake", "lean")

class DafnyBackend(FormalBackend):
    name = "dafny"
    executables = ("dafny",)

class VerusBackend(FormalBackend):
    name = "verus"
    executables = ("verus",)

class RocqBackend(FormalBackend):
    name = "rocq"
    executables = ("rocq", "coqc")

class Z3Backend(FormalBackend):
    name = "z3"
    executables = ("z3",)

class FramaCBackend(FormalBackend):
    name = "frama-c"
    executables = ("frama-c",)


def available_backends() -> tuple[str, ...]:
    backends = (LeanBackend(), DafnyBackend(), VerusBackend(), RocqBackend(), Z3Backend(), FramaCBackend())
    return tuple(b.name for b in backends if b.available())
