from __future__ import annotations
from dataclasses import dataclass
from enum import Enum


class EdgeType(str, Enum):
    REQUIRES = "requires"
    COMPOSES_WITH = "composes_with"
    SPECIALIZES = "specializes"
    GENERALIZES = "generalizes"
    CONFLICTS_WITH = "conflicts_with"
    INVALIDATES = "invalidates"
    SUPERSEDES = "supersedes"
    VERIFIED_BY = "verified_by"
    DERIVED_FROM = "derived_from"
    OPTIMIZES = "optimizes"


@dataclass(frozen=True)
class CapabilityEdge:
    src: str
    dst: str
    kind: EdgeType
    evidence: tuple[str, ...] = ()


class TypedCapabilityGraph:
    def __init__(self) -> None:
        self.edges: list[CapabilityEdge] = []
        self.nodes: set[str] = set()

    def add_node(self, node: str) -> None:
        self.nodes.add(node)

    def add_edge(self, src: str, dst: str, kind: EdgeType, evidence: tuple[str, ...] = ()) -> None:
        self.nodes.update({src, dst})
        self.edges.append(CapabilityEdge(src, dst, kind, evidence))

    def neighbors(self, node: str, kind: EdgeType | None = None) -> tuple[str, ...]:
        return tuple(e.dst for e in self.edges if e.src == node and (kind is None or e.kind == kind))

    def conflicts(self, node: str) -> tuple[str, ...]:
        return self.neighbors(node, EdgeType.CONFLICTS_WITH)
