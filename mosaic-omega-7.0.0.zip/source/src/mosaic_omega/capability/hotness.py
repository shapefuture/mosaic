from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class CompilationDecision:
    tier: str
    reason: str


class HotnessCompiler:
    """Moves stable capabilities down the compilation ladder as reuse increases."""
    def compile(self, *, uses: int, success_rate: float, latency_ms: float, deterministic: bool = True) -> CompilationDecision:
        if not deterministic or success_rate < 0.995:
            return CompilationDecision("interpreted", "insufficient determinism/reliability")
        if uses >= 1_000_000 and latency_ms >= 1.0:
            return CompilationDecision("specialized-operator", "very-high reuse")
        if uses >= 100_000:
            return CompilationDecision("simd", "high reuse")
        if uses >= 1_000:
            return CompilationDecision("native", "material reuse")
        if uses >= 10:
            return CompilationDecision("wasm", "repeated verified reuse")
        return CompilationDecision("interpreted", "cold capability")
