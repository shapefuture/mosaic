from __future__ import annotations
from dataclasses import dataclass, field
from hashlib import sha256
import json
from pathlib import Path
from typing import Any, Iterable
import zipfile

from ..compiler.ir import ComputationalUnit, ProgramIR


@dataclass(frozen=True)
class CapabilityManifest:
    name: str
    version: str
    unit_digest: str
    contract_digest: str
    verifier_ids: tuple[str, ...] = ()
    applicability: tuple[str, ...] = ()
    parent: str | None = None
    source_provenance: tuple[str, ...] = ()
    privacy_scope: str = "private"
    hotness: float = 0.0
    format_version: int = 1

    @property
    def digest(self) -> str:
        payload = self.__dict__.copy()
        return sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


class CapabilityPackage:
    REQUIRED = ("manifest.json", "contract.json", "verification.json", "lineage.json")

    @staticmethod
    def build(unit: ComputationalUnit, *, name: str, version: str, verifier_ids: Iterable[str] = (), applicability: Iterable[str] = (), parent: str | None = None, provenance: Iterable[str] = (), privacy_scope: str = "private") -> dict[str, Any]:
        manifest = CapabilityManifest(
            name=name,
            version=version,
            unit_digest=unit.digest,
            contract_digest=sha256(json.dumps(unit.contract.__dict__, sort_keys=True).encode()).hexdigest(),
            verifier_ids=tuple(verifier_ids),
            applicability=tuple(applicability),
            parent=parent,
            source_provenance=tuple(provenance),
            privacy_scope=privacy_scope,
        )
        return {
            "manifest": manifest,
            "contract": unit.contract,
            "verification": {"verifiers": list(manifest.verifier_ids), "status": "unverified"},
            "lineage": {"parent": parent, "version": version},
            "unit": unit,
        }

    @staticmethod
    def write(package: dict[str, Any], output: str | Path) -> Path:
        out = Path(output)
        out.parent.mkdir(parents=True, exist_ok=True)
        manifest: CapabilityManifest = package["manifest"]
        with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("manifest.json", json.dumps(manifest.__dict__ | {"digest": manifest.digest}, sort_keys=True, indent=2))
            zf.writestr("contract.json", json.dumps(package["contract"].__dict__, sort_keys=True, indent=2))
            zf.writestr("verification.json", json.dumps(package["verification"], sort_keys=True, indent=2))
            zf.writestr("lineage.json", json.dumps(package["lineage"], sort_keys=True, indent=2))
            zf.writestr("unit.json", json.dumps({"unit_id": package["unit"].unit_id, "digest": package["unit"].digest}, sort_keys=True, indent=2))
        return out

    @staticmethod
    def inspect(path: str | Path) -> dict[str, Any]:
        with zipfile.ZipFile(path) as zf:
            missing = [x for x in CapabilityPackage.REQUIRED if x not in zf.namelist()]
            if missing:
                raise ValueError(f"capability package missing required files: {missing}")
            manifest = json.loads(zf.read("manifest.json"))
            return {"manifest": manifest, "files": sorted(zf.namelist()), "valid_shape": not missing}
