from __future__ import annotations
from dataclasses import dataclass
import json
import shutil
import subprocess
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class WasiComponentSpec:
    name: str
    version: str
    wit: str
    module_path: str | None = None
    permissions: tuple[str, ...] = ()

    @property
    def digest(self) -> str:
        import hashlib
        return hashlib.sha256(json.dumps(self.__dict__, sort_keys=True).encode()).hexdigest()


class WasiComponentToolchain:
    """Best-effort WASI/Component Model bridge; never falls back to unsafe execution."""
    def __init__(self) -> None:
        self.wasmtime = shutil.which("wasmtime")
        self.wasm_tools = shutil.which("wasm-tools")

    def available(self) -> bool:
        return bool(self.wasmtime or self.wasm_tools)

    def validate_component(self, module: str | Path) -> bool:
        if not self.wasm_tools:
            return False
        proc = subprocess.run([self.wasm_tools, "component", "validate", str(module)], capture_output=True, text=True, check=False)
        return proc.returncode == 0

    def write_spec(self, spec: WasiComponentSpec, out: str | Path) -> Path:
        p = Path(out)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(spec.__dict__ | {"digest": spec.digest}, indent=2, sort_keys=True), encoding="utf-8")
        return p
