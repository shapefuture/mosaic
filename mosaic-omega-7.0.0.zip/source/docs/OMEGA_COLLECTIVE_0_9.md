# Ω∞-COLLECTIVE 0.9

MOSAIC 0.9 extends the verified ECU substrate into a compiler/control plane:

1. `TaskIR` — explicit goal, constraints, state, verification and resource budget.
2. Proof-Carrying Capabilities — executable capability metadata with verifier, lineage, economics and counterexamples.
3. Marginal-value controller — choose the action with the highest expected verified value per unit cost.
4. Adaptive verification compiler — compile the cheapest sufficient verification cascade from risk, novelty, change surface and value.
5. Plan competition — compare verified execution plans on quality, latency and cost.
6. Existing trajectory/ECU pipeline — streaming ingestion, parameterized ECUs, replay/prefix sharing, CPU-first execution.

The architectural law is: optimize whether expensive computation is needed before optimizing the computation itself.
