# Frontier execution comparison

## GitHub-connected sources

MOSAIC's benchmark adapter was aligned against these public GitHub sources:

- https://github.com/hkust-nlp/Toolathlon — task environment, evaluation client/service, parallel runner, trajectory/replay layout.
- https://github.com/agentreplay/agentreplay — trajectory-efficiency and causal-integrity evaluation implementations.
- https://github.com/microsoft/Orchard — scalable isolated agent environments and multi-harness rollout infrastructure.
- https://github.com/SWE-bench/SWE-bench — executable coding-task benchmark infrastructure.
- https://github.com/microsoft/SWE-bench-Live — continuously refreshed coding evaluation infrastructure.

## Current external reference

Toolathlon-Verified is a 108-task verified benchmark. The August 2026 published snapshot records Claude Opus 5 at 80.6% Pass@1, GPT-5.6 Sol at 74.9%, and Kimi K3 at 76.5%.

These values are external reference measurements. They are not transformed into a MOSAIC score. The comparator deliberately returns `comparable=false` unless a MOSAIC run reports results for the same task count and protocol.

## Real comparison protocol

1. Run the same 108 Toolathlon tasks with MOSAIC's external agent endpoint in a network-enabled evaluation worker.
2. Retain `eval_stats.json`, `traj_log_all.jsonl`, per-task artifacts, and independent verifier outputs.
3. Convert the run summary into `ReplayMetrics`.
4. Run `mosaic frontier-compare --replay-json ...`.
5. Require same task set, same verifier release, independent repeated trials, and complete cost/latency accounting before declaring superiority.

This repository intentionally does not fabricate a frontier win when the current ChatGPT sandbox cannot reach the Toolathlon service or Hugging Face trajectory storage.
