# Frontier-model comparison contract

MOSAIC now carries a versioned public Toolathlon-Verified reference snapshot so that local runs cannot quietly redefine the benchmark bar.

The August 2026 published snapshot used by the package is:

- 108 tasks.
- Claude Opus 5: 80.6% Pass@1.
- Kimi K3: 76.5%.
- GPT-5.6 Sol: 74.9%.
- Claude Sonnet 5: 74.7%.
- DeepSeek V4 Pro 0813: 74.1%.

These are **external reference measurements**. A MOSAIC fixture result is deliberately marked non-comparable until it has been executed against the same 108 tasks.

## Live replay path

Toolathlon's GitHub repository provides a public evaluation service and records `eval_stats.json`, complete trajectory logs, server/client logs, and per-task artifacts. The repository also documents parallel evaluation and decoupled-agent execution.

For a network-enabled worker, run the actual Toolathlon evaluation for each baseline and for MOSAIC's OpenAI-compatible agent endpoint, then convert the resulting metrics into `ReplayMetrics` JSON and compare using `compare_to_published_snapshot`.

MOSAIC will only report **true frontier-relative superiority** when task count, verifier version, run protocol, and accounting are aligned.

## Important boundary

The ChatGPT execution sandbox used during development has no arbitrary outbound DNS/HTTP, so this release does not claim that live Toolathlon execution occurred here. It contains the comparison contract and replay format specifically to prevent fixture measurements from being mislabeled as frontier benchmark wins.
