# MOSAIC Ω — Long-Horizon Self-Evolution

This benchmark is inspired by summer-2026 long-horizon software-engineering evaluations such as DeepSWE and Long-Horizon Terminal-Bench.

It deliberately tests:

- multi-file dependency depth
- hidden invariants
- state drift
- partial-regression traps
- recovery without full restart
- repeated-task reuse
- recursive generation of harder task families

DeepSWE emphasizes 113 original long-horizon tasks across 91 repositories with hand-written programmatic verifiers and strong contamination resistance; Long-Horizon Terminal-Bench uses 46 stateful tasks with dense partial rewards and hidden rebuild-from-artifact verification.

MOSAIC's self-evolution loop mutates task depth and failure diversity after every round. A release gate requires the learned execution path to maintain near-perfect verified score while reducing latency and cost against the baseline workflow.

## Run

```bash
mosaic recursive-gauntlet --rounds 4 --tasks 12
```

The goal is not a benchmark-specific trick: each round creates more difficult state/dependency structures, and only a system that preserves correctness while becoming cheaper/faster can pass.
