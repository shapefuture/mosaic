# MOSAIC Ω 2.3.0 — GitHub real-trajectory research record

## Strongest verified raw-trace discovery

- Repository: `when2buy/llm-trajectory-data`
- File: `docs/hard-task-traces/all_haiku.trace.jsonl`
- Blob SHA: `6d24773c1303911ea2cfe065524797de502382fc`
- Size: 123,453 bytes
- Model: `claude-haiku-4-5-20251001-v1:0`
- Task: `american-option-fd-new`
- Recorded result: 40/54, reward 0.7407407407407407, 135 model calls
- License: MIT repository; source-specific research-data terms still apply

The blob is a real Claude-style execution log containing observable tool calls/results, errors, model identity, token metadata and timing/cost-related fields. It is not merely a benchmark description.

## Other GitHub candidates discovered

The search sweep also surfaced:

- `choucisan/mimo-claude-code-traces-1k` — README describes 1,017 complete Claude-Code-style trajectories, but the Git repository tree itself does not contain the session payloads; treat as metadata plus an external corpus lead.
- `blueberrycongee/swe-bench-trajectories` — public trajectory repository; payload availability must be verified by tree before ingestion.
- `Jiacheng-Zhu-AIML/terminal_bench_trajectories` — public repository, but its Git tree currently exposes a scraper rather than the trajectory payloads.
- `when2buy/llm-trajectory-data` — confirmed Git-addressable raw trace payload.
- `harrylettering/claude-trace-replay` — trace viewer/replay infrastructure, not itself a confirmed corpus of raw model logs.
- `agentreplay/agentreplay` — evaluation infrastructure and example datasets; examples are not treated as frontier traces.
- multiple OpenTelemetry/ATIF/trajectory visualizer repositories discovered during the sweep.

## Research discipline

MOSAIC classifies sources into:

1. raw/replayable model trace bytes;
2. recorded aggregate model outcomes;
3. benchmark/task/verifier definitions;
4. trace tooling/infrastructure;
5. external corpus references whose payloads are not Git-addressable.

Only class (1) is used as raw trajectory evidence. Class (2) is used for comparison context. Classes (3)-(5) are not falsely treated as model traces.

## Current local limitation

The ChatGPT sandbox used for development cannot resolve public DNS or download GitHub raw blobs directly. The complete 123,453-byte source is therefore handled by the GitHub connector and the packaged external-worker streaming adapter. The local wheel contains only the verified source-derived deterministic sample and source manifest; no synthetic rows are claimed as the full corpus.
