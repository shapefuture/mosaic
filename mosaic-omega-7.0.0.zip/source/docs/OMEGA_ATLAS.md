# MOSAIC Ω∞-ATLAS

The 0.4 architecture treats an execution as a versioned object spanning task, context, strategy, program, compiler/runtime, hardware, verifier, outcome and recovery.

## Core primitives

- **EER (Execution Evidence Record):** immutable content-addressed envelope connecting events, outcomes and provenance.
- **Trajectory IR:** structured action/observation/state events with cost and success metadata.
- **Strategy Graph:** reusable state→action→outcome statistics mined from prior executions.
- **Context Compiler:** cheap deterministic context deduplication/relevance pass before expensive inference.
- **ReplayStore:** checkpoint/fork primitives for causal recovery and counterfactual evaluation.
- **CPU-first execution:** native/LLVM execution remains the default; GPU is capability and economics gated.

## Frontier synthesis incorporated

The architecture draws from trajectory automata learning (ATLAS), full-trace failure attribution (TraceElephant / AgentRx), trajectory-first retrieval learning (LRAT), replayable stateful environments, context-compilation research, Inspect/ATIF/OpenTelemetry interoperability, and modern cost-aware model routing.

The guiding rule is: **avoid work, compress state, reuse evidence, specialize, execute cheaply, verify, then learn from the resulting trajectory.**

Relevant external references:

- https://arxiv.org/abs/2608.14352
- https://aclanthology.org/2026.acl-long.912/
- https://arxiv.org/abs/2605.21850
- https://github.com/Yuqi-Zhou/LRAT
- https://inspect.aisi.org.uk/
- https://github.com/harbor-framework/harbor/blob/main/rfcs/0001-trajectory-format.md
- https://github.com/open-telemetry/semantic-conventions-genai/issues/338
