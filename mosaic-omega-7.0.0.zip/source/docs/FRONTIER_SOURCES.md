# Frontier source integration

MOSAIC 0.6 uses external research/trajectory sources as *evidence and training inputs*, not as opaque text dumps.

## GitHub implementation references

- Inspect AI: https://github.com/UKGovernmentBEIS/inspect_ai
  - hierarchical timelines, event trees, branches, token accounting, replay-oriented evidence.
- Orchard: https://github.com/microsoft/Orchard
  - common environment substrate; explicit stateful sandbox/branching/prefix-sharing roadmap.
- Secure MCP Tunnel: https://github.com/openai/tunnel-client
  - externalizes network access through a private MCP gateway instead of bypassing the local sandbox.
- AgentReplay: https://github.com/agentreplay/agentreplay
  - deterministic trajectory-efficiency evaluation concepts.
- AgentLens: https://github.com/dreadnode/agent-lens
  - ATIF/trajectory observability and replay-oriented data structures.
- Reproducible Trajectories: https://github.com/ASSERT-KTH/reproducible-trajectories
  - source-commit ↔ trajectory linkage and replayability.

## Training policy

Training ingestion is controlled by `DatasetManifest.role` and `license`.
Sealed/restricted sources must never enter the training path. Remote acquisition is intentionally external to the Python sandbox; the production path should use a controlled MCP/worker gateway with host allowlists, byte limits, hashes, and immutable manifests.

## ECU learning path

```text
source trajectory
 -> schema adapter
 -> state/action trajectory
 -> efficiency analysis
 -> motif mining
 -> policy learning
 -> ECU compilation
 -> verifier
 -> economic benchmark
```
