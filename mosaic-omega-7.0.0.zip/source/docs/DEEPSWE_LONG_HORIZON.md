# DeepSWE / Long-Horizon Inspired Evaluation

MOSAIC's recursive coding Gauntlet is inspired by 2026 long-horizon evaluations, especially DeepSWE and Long-Horizon Terminal-Bench (LHTB).

DeepSWE emphasizes original tasks, contamination resistance, long multi-file engineering work, and hand-written behavioral verifiers. LHTB emphasizes stateful environments, hundreds of dependent actions, hidden verification, and dense partial credit.

MOSAIC translates those failure modes into a self-generating local benchmark:

- increasing cross-file dependency depth
- hidden behavioral invariants
- stale imports and partial refactors
- state drift injected between planning and execution
- late failures requiring local recovery
- repeated task families for measuring reuse
- recursive task mutation after each evaluation round

The evaluator executes the generated repository and verifier directly. Cached knowledge can reduce planning work, but never skips materialization or verification for a new state.

Run:

```bash
mosaic recursive-gauntlet --rounds 4 --tasks 8 --seed 13
```

The release gate requires non-inferior verified quality, lower cost, higher verified-work/step efficiency, recovery coverage, no residual regressions, and continued generation of harder task families.
