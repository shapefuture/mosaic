# MOSAIC Ω 0.5 — Executable Compute Units

MOSAIC 0.5 adds a trajectory-to-executable distillation layer. The design deliberately separates **training/analysis/sealed evaluation** datasets and refuses to ingest restricted datasets through the training command.

## Canonical sources

- Microsoft Orchard SWE: https://huggingface.co/datasets/microsoft/Orchard — MIT; 107,185 SWE trajectories, including resolved and unresolved trajectories.
- GPT-5.6 Sol traces: https://huggingface.co/datasets/greghavens/gpt-5.6-sol-coding-and-debugging-traces — CC-BY-4.0; use `source_trajectory_id` to group cumulative prefixes.
- Exgentic v2: https://huggingface.co/datasets/Exgentic/agent-llm-traces-v2 — analysis/replay source unless separately licensed.
- Toolathlon-Verified: https://huggingface.co/datasets/hkust-nlp/Toolathlon-Verified_Trajectories — sealed evaluation only; never pass through `ecu-train`.

## Pipeline

```text
trajectory -> provenance gate -> state/action normalization -> motif mining -> procedure induction -> ECU synthesis -> verification -> economic benchmark
```

An ECU contains a semantic contract, explicit executable actions, provenance, and a content-addressed digest. Concrete tool handlers are injected at execution time; the ECU itself does not carry arbitrary shell/network access.

## Training command

```bash
PYTHONPATH=src python -m mosaic_omega.cli.main ecu-train path/to/orchard.parquet --adapter orchard --limit 10000 --min-support 3 --output dist/orchard-ecus.jsonl
PYTHONPATH=src python -m mosaic_omega.cli.main ecu-train path/to/gpt56.jsonl --adapter gpt56 --limit 10000 --min-support 3 --output dist/gpt56-ecus.jsonl
```

Parquet ingestion requires optional `pyarrow`; JSONL requires no third-party runtime dependency.

## Design rule

Frontier models are teachers during distillation, not the permanent runtime. Stable repeated procedures become ECUs; ambiguous or novel residue remains eligible for a model fallback outside the ECU runtime.
