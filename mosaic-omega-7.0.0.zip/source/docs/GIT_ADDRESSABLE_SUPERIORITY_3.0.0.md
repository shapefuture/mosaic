# MOSAIC Ω 3.0.0 — Git-Addressable Trajectory Superiority

## Gauntlet loop goal

The release loop is not "collect more trajectories." It is:

```text
find Git-addressable evidence
  -> cryptographically pin the Git blob
  -> stream under bounded memory
  -> normalize into source-agnostic IR
  -> discard private/hidden reasoning
  -> split by trajectory identity / source family
  -> mine failure/success contrasts
  -> anti-unify across independent sources
  -> compile recovery/program ECUs
  -> independently replay
  -> adversarially attack
  -> score every rubric
  -> keep only Pareto-improving changes
  -> generate a harder holdout
  -> repeat
```

## Verified payload families

1. `when2buy/llm-trajectory-data` — real Claude-agent hard-task JSONL, 123,453 bytes.
2. `blueberrycongee/swe-bench-trajectories` — expanded SWE trajectory JSON, 971,957 bytes.
3. `valence-labs/VC-TRACES` — 18,950 structured causal traces in an 82,653,737-byte Parquet blob.
4. `THU-KEG/LongTraceRL` — 42,607,966-byte long-horizon reasoning JSONL.

The registry also records three Git-addressable metadata/instrumentation sources that are intentionally excluded from behavior imitation.

## TRIZ / far-transfer moves

- **Invert failure:** errors are promoted into recovery operators rather than discarded as negative examples.
- **Separate incompatible functions:** provenance, reasoning content, executable actions and causal explanations use different lanes.
- **Universality:** all heterogeneous sources lower into the same `TrajectoryEvent` IR.
- **Borrow from compilers:** common-prefix elimination, dataflow compilation and anti-unification turn repeated traces into parameterized programs.
- **Borrow from SRE/incident response:** failure signatures become typed runbooks with explicit success checkpoints.
- **Borrow from observability:** provenance and event structure follow trace/span semantics without treating instrumentation code as behavior data.
- **Borrow from causal reasoning:** verified DAG/action primitives provide far-transfer decomposition signals without copying domain-specific text.

## Hard non-negotiables

- No hidden chain-of-thought enters the reusable skill/ECU bank.
- Raw sources are pinned by Git object SHA and expected byte count.
- Remote materialization is bounded and streaming-first.
- Source diversity is required before a recovery program becomes cross-source promoted.
- Every promoted unit has deterministic digest/provenance.
- A regression on any existing Gauntlet is a release blocker.

## Current evidence

The release passed the complete local test suite plus legacy, frontier, maximal, collective, verified-recursive, Ω, Ω2, GitHub-trace and superiority Gauntlets. This is a local architectural/evidence gate; it is not a claim that MOSAIC has universally beaten every closed frontier model on every benchmark.
