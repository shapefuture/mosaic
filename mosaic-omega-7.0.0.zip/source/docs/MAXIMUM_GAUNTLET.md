# MOSAIC Ω 0.8.0 — Maximum Gauntlet

## Goal

Beat ordinary repeated frontier-agent execution on the dimensions that actually determine production value:

- verified quality;
- latency;
- model calls/tokens;
- compute cost;
- energy;
- recovery cost;
- reproducibility;
- security/evidence strength.

The local release gate cannot prove superiority over an actual frontier model without live model/environment access, so the local gate proves the **mechanisms that make superiority falsifiable** and blocks misleading claims.

## Local result

| Metric | Result |
|---|---:|
| Total training trajectories | 24 deterministic benchmark trajectories |
| Train / validation | 19 / 5 |
| Holdout baseline score | 0.56 |
| Holdout candidate score | 0.86 |
| Validation gain | +0.30 |
| Planning compression | 98.7% |
| Frontier-call reduction | 100% on covered stable procedure |
| Prefix reuse | 66.7% |
| Leakage groups | 0 |
| ECU regressions | 0 |
| Verified ECUs | 1 |
| CPU-first | yes |
| GPU credited | no |

## Full-corpus gate

When an external networked worker is available, the same pipeline should be run over the full public training corpora with:

1. source-trajectory group splits;
2. diversity stratification across teachers/harnesses/domains/repos;
3. success and unresolved-failure contrast;
4. streaming heavy-hitter motif mining;
5. validation-gated ECU acceptance;
6. held-out environment replay;
7. frontier baseline vs ECU/Augmented baseline paired comparison;
8. cost/token/latency/energy accounting;
9. adversarial recovery tests;
10. signed content-addressed evidence.

A deployment should only claim `frontier-superior=true` when the paired held-out gate passes all required quality and economics thresholds.
