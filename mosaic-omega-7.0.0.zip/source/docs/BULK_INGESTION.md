# Bulk Frontier Ingestion

## Why streaming

Orchard's current public card describes 107,185 SWE trajectories in 19 Parquet shards (~9.72 GB) and 3,070 GUI decision-point rows (~1.25 GB). The GPT-5.6 Sol public dataset currently exposes a 1.05 GB `traces.jsonl` file and 17,939 cumulative next-step rows in the published snapshot. The corpora are large enough that materializing everything in the ChatGPT sandbox is the wrong architecture.

## Recommended deployment

```text
ChatGPT / MOSAIC control plane
           |
           | MCP / secure tunnel
           v
external ingestion worker
           |
           +-- Hugging Face streaming / Parquet
           +-- GitHub / Inspect logs
           +-- provenance + license gate
           |
           v
bounded-memory MOSAIC trainer
           |
           +-- diversity + leakage split
           +-- heavy-hitter motif mining
           +-- contrastive failure analysis
           +-- held-out gate
           |
           v
ECU artifact lake
```

The ChatGPT sandbox should never be modified to bypass its own egress isolation. Network access belongs at the external worker boundary.

## Full-corpus anti-unified ECUs

For very large trajectory corpora, use `StreamingECUTrainer`. It retains only bounded heavy-hitter procedure signatures, group support, success/failure support and a bounded set of observed argument values; raw trajectories are discarded after each update. This allows one learned ECU to generalize across varying file paths, IDs, namespaces and other task parameters.

The intended production flow is:

```text
Hugging Face / Inspect / ATIF / OTel
        ↓
stream decoder
        ↓
leakage-safe split
        ↓
diversity-aware heavy hitters
        ↓
argument anti-unification
        ↓
verified generalized ECU
        ↓
ROI skill bank
```
