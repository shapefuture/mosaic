# MOSAIC Ω 4.0 — Evidence Compiler

MOSAIC Ω 4 turns heterogeneous agent trajectories into evidence-grounded reusable computation.

## Six views

1. **Reasoning** — explicit reasoning signals and intent/hypothesis/evidence/decision frames.
2. **Execution** — observable tool/program/state transitions.
3. **Outcome** — test, verifier, error and completion evidence.
4. **Causal** — temporal, reasoning-continuation and recovery edges.
5. **State** — state hashes and repository/environment context.
6. **Economics** — latency, cost and reuse-relevant execution metadata.

Reasoning is used as a search/generalization signal; promotion authority remains with observable execution and outcome evidence.

## Evidence-first promotion

A candidate experience must have independent support, positive execution evidence, explicit preconditions, and survive the deterministic promotion gate. Failed approaches remain eligible for negative memory rather than being silently discarded.

## Memory lifecycle

`episodic -> candidate -> verified procedural -> retrieval -> reuse -> retirement`

Negative evidence is retained separately. Retirement bounds hot-memory growth and removes low-value/stale procedural entries.

## Gauntlet

The Experience Compiler Gauntlet runs on 25 trajectories with both reasoning-bearing and execution-only traces, injected repeated failures, critical-step detection, causal graph construction, retrieval, and promotion safety.
