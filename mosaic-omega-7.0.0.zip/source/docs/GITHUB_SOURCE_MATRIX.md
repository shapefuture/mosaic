# MOSAIC Ω frontier source matrix

This document records external engineering references used to shape the implementation. MOSAIC does not copy source code from these repositories unless explicitly licensed and attributed; the project reimplements the relevant ideas behind its own APIs.

## Evaluation and trajectory evidence

- https://github.com/UKGovernmentBEIS/inspect_ai — evaluation logs, hierarchical events, replayable evaluation infrastructure.
- https://github.com/UKGovernmentBEIS/inspect_evals — evaluation suite corpus and Inspect-compatible eval implementations.
- https://github.com/UKGovernmentBEIS/control-arena — adversarial control evaluation patterns.
- https://github.com/agentreplay/agentreplay — deterministic trajectory-efficiency and replay ideas.
- https://github.com/dreadnode/agent-lens — ATIF-oriented trajectory observability.
- https://github.com/agentreplay/agentreplay — execution-efficiency measurement.
- https://github.com/ASSERT-KTH/reproducible-trajectories — replay/reproducibility lineage.
- https://github.com/harbor-framework/harbor — trajectory interchange / execution environment ecosystem.
- https://github.com/neulab/agent-data-protocol — trajectory normalization.

## Frontier trajectory / agent training

- https://github.com/microsoft/Orchard — shared sandbox + trajectory training/evaluation substrate.
- https://github.com/SWE-bench/SWE-bench — executable SWE evaluation and Docker grading harness.
- https://github.com/SWE-bench/experiments — benchmark experiment evidence.
- https://github.com/microsoft/SWE-bench-Live — refreshed live SWE evaluation.
- https://github.com/SWE-agent/mini-swe-agent — compact executable agent loop.
- https://github.com/wuxiyang1996/COS-PLAY — co-evolving model decisions and reusable skills.
- https://github.com/aiming-lab/WebXSkill — web-agent skill learning.
- https://github.com/agent-jit/AgentJIT — trace-to-deterministic-skill/JIT compilation.

## Compiler / execution substrate

- https://github.com/llvm/llvm-project — LLVM/MLIR compiler substrate.
- https://github.com/isl-org/kernelfoundry — evolutionary kernel optimization.
- https://github.com/msanthosh247/KernelSmith — kernel search.
- https://github.com/CerovazS/kernelsmith-rl — RL-based kernel optimization.
- https://github.com/ggml-org/llama.cpp — CPU-first low-bit inference / ISA-specific execution.
- https://github.com/vllm-project/vllm — high-performance serving and CPU/accelerator backends.
- https://github.com/oneapi-src/oneDNN — optimized CPU kernels.
- https://github.com/libxsmm/libxsmm — specialized CPU kernels.
- https://github.com/flame/blis — BLAS-like CPU primitives.

## Network / remote execution

- https://github.com/openai/tunnel-client — Secure MCP Tunnel for private/local MCP servers to ChatGPT/Codex/Responses API.

## Benchmarks

- https://github.com/swe-bench/sb-cli — remote/cloud evaluation execution path.
- https://github.com/terminal-bench/terminal-bench — executable terminal-agent evaluation.

## Research directions incorporated

- Agent JIT Compilation (ICML 2026): task-to-program compilation, invariant validation and latency-aware parallel scheduling.
- SkillGen (Microsoft Research): paired intervention audits over baseline failures and successes.
- Trace2Skill: broad-trajectory distillation into transferable skills.
- TDScaling: diversity-aware trajectory scaling rather than raw quantity scaling.
- LLVM 2026 agentic compilation work: reasoning fusion, context deduplication and capability scheduling.

## Evidence classes

Training data, analysis-only data and sealed evaluation data are kept separate. In particular, any dataset whose terms prohibit training/distillation stays outside the training stream and is used only for blind evaluation where permitted.
