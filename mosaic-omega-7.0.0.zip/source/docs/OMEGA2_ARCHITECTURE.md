# MOSAIC Ω 2.0 — Evolving Agent Runtime

Ω2 treats agentic work as an executable program rather than a prompt sequence.

The core objects are:

- **AgentProgram** — typed executable graph with contracts, budgets and dependency edges.
- **Proof/verification path** — verification is part of the program, not a post-hoc claim.
- **CollectiveEnvelope** — privacy-preserving capability exchange; no source repository or prompt history is required for semantic sharing.
- **HarnessGenome** — decomposition, verifier, parallelism, recovery and cache policies that can be mutated in isolated experiments.
- **AgentRuntime** — local-first execution with frontier inference explicitly represented as an exception path.

## Operating law

Choose the next computation by expected verified value per unit of cost, then promote only after independent validation.

The default execution ladder is:

`exact reuse → executable capability → deterministic local program → local model → accelerator → frontier model`

GPU and frontier inference therefore remain fallback mechanisms, not the primary substrate.

## Collective intelligence

A contributor publishes a content-addressed `CollectiveEnvelope` containing:

- capability/program digest
- contract summary
- benchmark evidence
- verifier fingerprint
- lineage
- contributor identifier

By default it does **not** include repository source, prompt history, secrets, or filesystem paths. A receiving node re-verifies locally before promotion.

## Self evolution

`HarnessGenome` mutations run outside the production runtime. A candidate is promoted only when an external judge shows non-inferior quality/reliability plus a strict latency or cost improvement and no adversarial regression.
