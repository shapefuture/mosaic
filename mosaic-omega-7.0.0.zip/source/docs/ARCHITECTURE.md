# MOSAIC Ω 0.2 architecture

```text
Intent / IR
   │
   ├── reference evaluator ─────────────── semantic truth
   │
   └── Search Space Compiler
             │
             ↓
        Executable Genome
             │
             ↓
       surrogate + evolution
             │
             ↓
   ┌───────────────────────────────────────┐
   │  CPU-first execution fabric           │
   │                                       │
   │  native SIMD → LLVM CPU → remote CPU  │
   │                ↓                      │
   │      VM/process isolation              │
   │                ↓                      │
   │          CUDA / ROCm                  │
   │   (only after economic escalation)    │
   └───────────────────────────────────────┘
             │
             ↓
      correctness evidence
             │
             ↓
       cost/energy profile
             │
             ↓
       Pareto + MAP-Elites
             │
             ↓
        dispatch synthesis
             │
             ↓
      runtime observation
             │
             └──────────→ evolution
```

## First-principles objective

For a verified candidate, MOSAIC tracks:

`latency`, `estimated energy`, `execution USD`, `startup overhead`, and correctness evidence.

The primary operational metric is:

`verified useful work / second / USD`

This prevents a raw latency win from being accepted when it costs disproportionately more. GPU carries an additional escalation barrier because a marginally faster GPU result can still be economically worse after startup, utilization and hourly price.

## Compiler strategy

The 0.2 native backend emits a small C kernel from the restricted MCIR. Clang is preferred and routes the generated C through LLVM; GCC remains the portable fallback. The generated code uses the executable genome to control tiling/unrolling/vectorization shape while preserving the reference semantics.

## Isolation

Fast trusted local execution uses a loaded native shared object. Untrusted execution has a separate resource-limited subprocess path. Production deployments requiring strong multi-tenant isolation should use Firecracker or an equivalent VM boundary; MOSAIC detects this requirement rather than silently pretending RLIMITs equal a VM.

## Attestation

Software manifests remain cryptographically bound with the existing development HMAC mechanism. Hardware-rooted trust is a separate provider layer for AWS Nitro and Intel TDX; a provider reports unavailable rather than producing a synthetic quote.
