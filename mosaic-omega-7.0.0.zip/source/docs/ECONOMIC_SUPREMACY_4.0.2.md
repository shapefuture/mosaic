# MOSAIC Ω 4.0.2 — Economic Supremacy / GPU-Last-Resort

Objective: maximize verified useful work per USD·latency·energy while treating GPU as last resort.

Policy:
1. eliminate/reuse work before backend selection;
2. prefer deterministic CPU/native/AOT and remote CPU;
3. use NPU/other accelerators only for strong measured gains;
4. use GPU only when non-GPU backends cannot satisfy a hard constraint or demonstrate a substantial risk-adjusted gain.

Primary composite metric:
`quality * useful_work / (USD * latency_seconds * energy_factor)`

Local evidence:
- full test suite: PASS
- economic supremacy tests: PASS
- legacy Gauntlet: PASS
- GPU-last-resort policy: PASS

Local host measurements are not claims against closed frontier-model systems.

## Ω5 network objective

The network scheduler generalizes the local economic policy to verified useful work:

`quality * expected_future_savings * reliability / (latency * USD * energy)`

GPU is treated as an exception path when a non-GPU route cannot satisfy constraints or is materially dominated on the composite objective.
