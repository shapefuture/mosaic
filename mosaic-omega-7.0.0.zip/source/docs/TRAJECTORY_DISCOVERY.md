# MOSAIC Ω 4.0.1 — agent trajectory discovery

MOSAIC no longer relies on fixed vendor paths to find agent histories.

`discover-session` uses a layered strategy:

1. `rg --files --hidden --follow` when available, with `.git`, dependency and cache directories excluded.
2. Portable `os.walk` fallback when ripgrep is unavailable.
3. Content/schema fingerprinting over JSONL/NDJSON/JSON/Inspect `.eval`/trace/log/SQLite candidates.
4. Agent identification from file content and schema rather than directory names.
5. SQLite read-only inspection of likely session/history tables.
6. Inode + content hashing for deduplication.

The known paths of Claude, Codex, Cursor, Gemini, Copilot, OpenHands, Aider, OpenCode, SWE-agent, etc. are only recognition hints. An agent installed under an arbitrary directory can still be discovered from its session content.

CLI:

```bash
mosaic discover-trajectories /workspace /home/me
mosaic discover-train /workspace /home/me --max-trajectories 256
```

The discovery output includes path, format, agent classification, confidence, byte count, root and digest. Unknown agents are retained when `--include-unknown` is supplied.

## Safety

Discovery is read-only. No discovered file is executed. SQLite is opened in read-only mode. Large files are bounded by `--max-file-bytes`, and the search is bounded by `--max-files`.
