# MOSAIC Ω6 runtime backends

Ω6 now provides executable integration boundaries for four deployment substrates:

- **Native**: local trusted execution.
- **WASM**: `wasmtime`/`wasmer` when installed; fails closed when absent.
- **Firecracker**: real Firecracker process launch when the binary is installed; MOSAIC does not silently weaken isolation.
- **Kubernetes**: `kubectl` apply/delete adapter for ephemeral workload manifests.
- **Cloudflare**: provider adapter for a deployment-controlled Sandbox/Worker endpoint; credentials are never stored by MOSAIC.

The core scheduler remains provider-neutral. The correct substrate is selected from trust, latency, memory, network, and isolation requirements.

## Real stateless MCP HTTP

`MCPHTTPServer` is a dependency-free loopback/edge transport around the stateless MCP gateway. It accepts JSON requests on `/mcp` and provides `/healthz`. State is carried in explicit application handles; the HTTP server stores no conversational session state.

## CRDT state

`LWWMapCRDT` is an operation-based, deterministic last-write-wins map using Lamport dots. It supports export/import, convergence after out-of-order merges, delete tombstones, and content-addressed digests. Large immutable artifacts remain in content-addressed storage instead of the CRDT.

## Multi-node fault injection

`MultiNodeFaultHarness` deterministically assigns tasks across nodes, kills nodes, returns orphaned task handles, and reassigns them to live nodes. It is intentionally transport-agnostic so the same recovery semantics can be used with local processes, Kubernetes, Firecracker, or cloud runtimes.

Production deployment remains dependent on the corresponding host/cloud binaries and credentials. Ω6's invariant is that unavailable infrastructure is detected explicitly rather than silently emulated.
