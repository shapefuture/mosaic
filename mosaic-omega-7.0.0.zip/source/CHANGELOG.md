# 5.0.0

- Added verified useful-work network reference layer.
- Added content-addressed capability market with local-first admission.
- Added adaptive replication and heterogeneous promotion gates.
- Added challenge/revocation flow and Proof-of-Useful-Improvement accounting.
- Added capability future-value accounting and GPU-last-resort economic routing.
- Added network Gauntlet and CLI commands `network-gauntlet` / `network-query`.

# Changelog

## 2.0.0
- Reframed MOSAIC as an evolving executable agent runtime.
- Added AgentProgram IR, safe parallel execution waves, compilation cache and recovery-aware runtime.
- Added privacy-preserving CollectiveRegistry and proof-carrying contribution receipts.
- Added isolated HarnessGenome mutation/promotion and Ω2 superiority Gauntlet.
- Local-first execution remains the default; accelerator/frontier paths are explicit fallbacks.

## 3.0.0
- Added provenance-pinned ingestion for GitHub-committed real model trajectories.
- Added `github-trace-audit`, `github-trace-train`, and `github-trace-gauntlet`.
- Added observable-only trajectory normalization that strips hidden/private reasoning.
- Added failure→repair recovery-operator mining and ECU compilation.
- Added allowlisted HTTPS streaming for full GitHub trace blobs in external workers.
- Added packaged offline trajectory/fixture data for clean-wheel Gauntlet execution.
- Ran 100+ distinct GitHub searches across English and Chinese terminology to identify trace-bearing repositories and distinguish raw traces from benchmark metadata.

## 3.0.0 — Git-Addressable Trajectory Superiority Substrate

This release upgrades trajectory learning from a single-source demo into a multi-corpus, provenance-pinned behavior compiler. It incorporates every additional Git-addressable payload verified during the 2026-08-22 frontier sweep, including Claude hard-task traces, SWE-bench expanded trajectories, VC-TRACES causal reasoning data, and LongTraceRL long-horizon data.

The core loop is now:

`Git blob pin → bounded streaming → privacy-safe normalization → source diversity split → failure/success mining → cross-source anti-unification → recovery/program compilation → independent replay → rubric gate → harder adversarial holdout`.

The system treats thought/reasoning text in source trajectories as non-executable and drops it at ingestion. Only observable actions, tool arguments, outcomes, verification signals and provenance metadata can become reusable computation.

## 3.0.2 — Three-view trajectory learning
- Added independent reasoning-only, execution-only, and joint trajectory learners.
- Added reasoning abstraction frames for cross-trajectory/far-transfer generalization.
- Added confidence-gated fusion and explicit ablation Gauntlet.
- Expanded the local trajectory evaluation to 28 trajectories (18 reasoning-bearing + 10 observable execution traces).

## 4.0.0 — Evidence Compiler

- Added six-view evidence graph: reasoning, execution, outcome, causal, state, economics.
- Added evidence-grounded procedural experience compiler and bounded episodic/procedural/negative memory.
- Added critical-step/failure-chain detection and cross-view experience mining.
- Added Experience Compiler Gauntlet with >4 trajectories, mixed reasoning-bearing/execution-only traces, injected critical failures, retrieval, promotion guards and deterministic memory lifecycle.
- Added `mosaic experience-gauntlet` CLI command.

## 4.0.2
- GPU-last-resort economic scheduler with hard non-GPU preference barriers.
- Quality/work per USD*latency*energy composite objective.
- Expanded backend-offer economics and economic-supremacy Gauntlet.

## 6.0.0 — Ephemeral Multi-Tenant Fabric
- added stateless MCP-shaped gateway with explicit state handles and tenant admission;
- added tenant quotas/policies and capability authorization;
- added ephemeral execution cells and forkable branches;
- added native/WASM/worker/MicroVM sandbox policy compiler;
- added 10,000-logical/1,000-concurrent Ω∞ ephemeral Gauntlet;
- preserved CPU-first/GPU-last economic routing and all prior Gauntlets.

## 7.0.0 — Computational Compiler
- Added typed ComputationalUnit / ProgramIR with explicit effect/authority contracts.
- Added residual verification graph and dependency-cone invalidation.
- Added verifier portfolio selection, formal backend adapters, capability package format, hotness compiler and typed capability graph.
- Added WASI/Component Model bridge metadata, self-host promotion gates, and Ω7 Gauntlet.
