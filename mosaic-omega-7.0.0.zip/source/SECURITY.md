# Security model

MOSAIC Ω separates four trust levels:

1. **Reference semantics** — deterministic, restricted evaluator used as the correctness oracle for the current IR.
2. **Native execution** — fast path; use only for trusted generated artifacts or run through the resource-limited subprocess boundary when required.
3. **VM isolation** — Firecracker capability gate for workloads whose policy requires a virtualization boundary.
4. **Hardware attestation** — Nitro/TDX adapters can return actual platform evidence when available; absence is fail-closed.

The project does not use `eval`, `exec`, or shell command strings for arbitrary generated code. Compiler invocations use argument arrays.

The CUDA/HIP backend is not authorized merely because a compiler exists: the device must also be detectable, the candidate must pass semantic verification, and the scheduler must find a materially better economic utility than the best CPU option.

For production deployment, pair MOSAIC with container/VM sandboxing, a signed artifact pipeline (e.g. Sigstore/in-toto/SLSA), and hardware-backed remote attestation.


## Exact caching

`ResultCache` is exact-only: program digest, canonical float64 input bytes, and cache policy version are part of the key. No approximate result substitution is performed.
