# MOSAIC Ω 7.0 — Computational Compiler

Ω7 closes the gap between the original MOSAIC draft and the runtime substrate.

## Core primitives

- `ComputationalUnit` / `ProgramIR`: typed executable units with explicit effects, budgets, contracts, dependencies and provenance.
- Effect system: deny-by-default authority checking before execution.
- Residual verification graph: only invalidated obligations are recomputed after a change.
- Verifier portfolio: select the smallest heterogeneous evidence set meeting a target confidence/cost bound.
- Capability package: content-addressed package shape for executable VRCs with contract, verification, lineage and provenance.
- Hotness compiler: interpreted → WASM → native → SIMD → specialized-operator as verified reuse grows.
- Typed capability graph: typed composition/conflict/supersession relations.
- Formal adapters: Lean, Dafny, Verus, Rocq/Coq, Z3 and Frama-C when installed; unavailable backends are reported honestly.
- WASI/Component Model bridge: capability manifest + validation hooks for wasm-tools/wasmtime environments.
- Self-hosting gate: isolated mutation candidates can only be promoted after tests, holdout, adversarial evaluation and replay checks.

## Ω7 control law

Prefer:

`eliminate → exact capability → generalized capability → deterministic program → specialist → remote model → frontier`

and separately minimize verification cost by invalidating only the dependency cone of changed obligations.

## Evidence boundary

This release contains production-ready interfaces and deterministic reference implementations. Real Lean/Dafny/Verus/Rocq/Z3/Frama-C execution depends on those host tools being installed. Firecracker/Kubernetes/Cloudflare backends remain external-provider adapters from Ω6.
