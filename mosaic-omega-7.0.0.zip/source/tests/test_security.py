from mosaic_omega.model import Candidate, ComputeSpec, Genome
from mosaic_omega.security.policy import ExecutionPolicy, authorize
from mosaic_omega.security.provenance import attest, make_manifest, verify_attestation


def test_attestation_and_policy():
    candidate = Candidate(ComputeSpec("x", "noop", 4), Genome())
    manifest = make_manifest(candidate, "abc")
    att = attest(manifest, b"secret")
    assert verify_attestation(att, b"secret")
    assert not verify_attestation(att, b"wrong")
    assert authorize(candidate, ExecutionPolicy())[0]
    blocked = candidate.__class__(ComputeSpec("x", "noop", 4, target="gpu"), candidate.genome)
    assert not authorize(blocked, ExecutionPolicy())[0]
