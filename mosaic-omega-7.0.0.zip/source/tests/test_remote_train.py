from mosaic_omega.learning.remote_train import RemoteDatasetSpec

def test_remote_spec():
    s = RemoteDatasetSpec("microsoft/Orchard", "swe")
    assert s.streaming is True
    assert s.split == "train"
