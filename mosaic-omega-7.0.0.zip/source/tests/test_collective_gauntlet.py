from mosaic_omega.gauntlets.collective import run_collective_gauntlet

def test_collective_gauntlet():
    r=run_collective_gauntlet()
    assert r.e2e_passed
    assert r.compiled_units>0
    assert r.verified_units==r.compiled_units
    assert r.plan_competition_gain>1
