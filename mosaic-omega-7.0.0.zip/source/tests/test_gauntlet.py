from mosaic_omega.gauntlet import run_gauntlet


def test_gauntlet_passes():
    result = run_gauntlet()
    assert result.all_checks_passed
    assert result.best_cpu_latency_ms > 0
    assert result.best_cpu_cost_usd > 0
