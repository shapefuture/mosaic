from mosaic_omega.frontier.recorded import CTI_REALM_50_JUNE_2026, TOOLATHLON_FIND_ALITA, compare_recorded_score


def test_cti_snapshot_is_real_published_result_set() -> None:
    assert CTI_REALM_50_JUNE_2026.tasks == 50
    assert CTI_REALM_50_JUNE_2026.best_model == "claude-opus-4-6"
    assert CTI_REALM_50_JUNE_2026.best_score == 0.6373


def test_comparison_refuses_wrong_task_count() -> None:
    result = compare_recorded_score(CTI_REALM_50_JUNE_2026, 1.0, 24)
    assert not result["comparable"]
    assert not result["superior_quality"]


def test_github_task_evidence_is_explicitly_not_a_model_trace() -> None:
    assert TOOLATHLON_FIND_ALITA.evidence_kind.startswith("task_definition")
    assert "not committed" in TOOLATHLON_FIND_ALITA.notes
