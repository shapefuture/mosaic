import json
from pathlib import Path

from mosaic_omega.evidence import EERBuilder
from mosaic_omega.trajectory import Trajectory, TrajectoryEvent, analyze_trajectory, trajectory_digest
from mosaic_omega.strategy import StrategyGraph


def test_eer_is_content_addressed_and_event_chain_is_stable():
    b = EERBuilder("r1", {"task": "demo"})
    h1 = b.event("execute", {"backend": "cpu"}, "s0")
    h2 = b.event("verify", {"ok": True}, "s1")
    eer = b.build()
    assert h1 != h2
    assert eer.events[1].parent_hash == h1
    assert eer.digest == b.build().digest
    json.loads(eer.to_json())


def test_failure_attribution_finds_decisive_step_and_recovery():
    traj = Trajectory("r2", (
        TrajectoryEvent(0, "plan", "plan", ok=True),
        TrajectoryEvent(1, "tool", "bad_call", ok=False, metadata={"failure_category": "tool_error"}),
        TrajectoryEvent(2, "recovery", "retry", ok=True),
    ))
    failure = analyze_trajectory(traj)
    assert failure.decisive_step == 1
    assert failure.category == "tool_error"
    assert failure.recovery_step == 2
    assert trajectory_digest(traj)


def test_strategy_graph_learns_reusable_action():
    graph = StrategyGraph()
    graph.ingest(Trajectory("a", (
        TrajectoryEvent(0, "classify", "quantize", state_hash="memory", ok=True, latency_ms=2),
        TrajectoryEvent(1, "execute", "cpu", state_hash="done", ok=True, latency_ms=3),
    )))
    graph.ingest(Trajectory("b", (
        TrajectoryEvent(0, "classify", "quantize", state_hash="memory", ok=True, latency_ms=2),
        TrajectoryEvent(1, "execute", "cpu", state_hash="done", ok=True, latency_ms=3),
    )))
    assert graph.best_action("START", ("quantize", "gpu")) == "quantize"
