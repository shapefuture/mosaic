from mosaic_omega.runtime.cost import CostPoint, quality_speed_per_dollar_latency
from mosaic_omega.runtime.scheduler import BackendOffer, LastResortGPUScheduler


def test_gpu_not_selected_for_small_speedup_when_cpu_is_viable():
    cpu = BackendOffer("cpu", "cpu", True, 40.0, 0.0, CostPoint(0.20, 50), expected_quality=1.0)
    gpu = BackendOffer("gpu", "gpu", True, 35.0, 20.0, CostPoint(1.50, 250), expected_quality=1.0)
    assert LastResortGPUScheduler().choose([gpu, cpu]).device_class == "cpu"


def test_gpu_can_win_only_on_large_risk_adjusted_gain():
    cpu = BackendOffer("cpu", "cpu", True, 5000.0, 0.0, CostPoint(0.20, 50), expected_quality=1.0)
    gpu = BackendOffer("gpu", "gpu", True, 100.0, 5.0, CostPoint(0.40, 150), expected_quality=1.0)
    assert LastResortGPUScheduler().choose([gpu, cpu], max_latency_ms=1000.0).device_class == "gpu"


def test_primary_objective_prefers_more_verified_work_per_dollar_latency():
    score = quality_speed_per_dollar_latency(
        quality=1.0,
        work_units=100,
        latency_ms=10,
        cost_usd=0.001,
    )
    assert score > 1_000_000
