import json
import threading
import urllib.request

from mosaic_omega.cloud import (
    StatelessMCPGateway, MCPRequest, MCPHTTPServer,
    LWWMapCRDT, MultiNodeFaultHarness,
    WASMRuntime, KubernetesBackend, FirecrackerBackend,
    CloudflareSandboxBackend,
)


def test_crdt_replication_converges():
    a, b = LWWMapCRDT("a"), LWWMapCRDT("b")
    a.put("x", 1); b.put("y", 2)
    a.merge(b); b.merge(a)
    assert a.value() == b.value() == {"x": 1, "y": 2}
    assert a.digest() == b.digest()


def test_crdt_delete_and_rehydrate():
    a = LWWMapCRDT("a")
    a.put("x", 1); a.delete("x")
    b = LWWMapCRDT.from_export("b", a.export())
    assert b.value() == {}
    assert b.digest() == a.digest()


def test_multinode_fault_recovery():
    h = MultiNodeFaultHarness(["a", "b", "c"])
    node = h.assign("task")
    orphaned = h.fail(node)
    assert orphaned == ["task"]
    recovered = h.recover("task")
    assert recovered != node and h.nodes[recovered].alive


def test_real_stateless_mcp_http_transport():
    g = StatelessMCPGateway({"echo": lambda a: a})
    s = MCPHTTPServer(g, port=0)
    thread = threading.Thread(target=s.serve_forever, daemon=True)
    thread.start()
    try:
        host, port = s.server_address
        req = urllib.request.Request(
            f"http://{host}:{port}/mcp",
            data=json.dumps({"jsonrpc":"2.0","id":1,"method":"tools/call","tenant_id":"t","params":{"name":"echo","arguments":{"x":7}}}).encode(),
            headers={"Content-Type":"application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=2) as resp:
            body = json.loads(resp.read().decode())
        assert body["result"]["x"] == 7
    finally:
        s.shutdown()
        thread.join(timeout=2)


def test_backend_adapters_are_capability_aware():
    assert isinstance(WASMRuntime().capabilities.available, bool)
    assert isinstance(KubernetesBackend().capabilities.available, bool)
    assert isinstance(FirecrackerBackend().available, bool)
    cf = CloudflareSandboxBackend("acct", "http://127.0.0.1")
    assert cf.capabilities.account_id == "acct"
