from mosaic_omega.runtime.jit import JITPlanner, ToolContract
from mosaic_omega.runtime.agent_program import ProgramNode
from mosaic_omega.ecu.core import ECUAction


def test_jit_selects_parallel_plan():
    j = JITPlanner({"a": ToolContract("a"), "b": ToolContract("b"), "v": ToolContract("v")})
    serial = [
        ProgramNode("a", "tool", ECUAction("a"), (), "cpu", 10),
        ProgramNode("b", "tool", ECUAction("b"), ("a",), "cpu", 10),
        ProgramNode("v", "verify", ECUAction("v"), ("b",), "cpu", 2),
    ]
    parallel = [
        ProgramNode("a", "tool", ECUAction("a"), (), "cpu", 10),
        ProgramNode("b", "tool", ECUAction("b"), (), "cpu", 10),
        ProgramNode("v", "verify", ECUAction("v"), ("a", "b"), "cpu", 2),
    ]
    best = j.choose([serial, parallel])
    assert best.valid and best.estimate.minimum_ms < 22
