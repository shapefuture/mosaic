from mosaic_omega.task_ir import TaskIR

def test_task_ir_roundtrip():
    t=TaskIR('fix bug', constraints=('tests pass',), candidate_capabilities=('skill.x',), resource_budget={'usd':1})
    assert TaskIR.from_dict(t.to_dict()).digest == t.digest
