from mosaic_omega.compiler.search_space import SearchSpaceCompiler
from mosaic_omega.eval.verifier import verify_candidate
from mosaic_omega.ir.nodes import Add, Const, Input, Mul
from mosaic_omega.ir.program import Program
from mosaic_omega.model import Candidate, ComputeSpec, Genome


def test_reference_equivalence_passes_for_scheduling_genome():
    program = Program("p", Add(Mul(Const(3), Input()), Const(-2)))
    spec = ComputeSpec("p", "elementwise", 16)
    candidate = Candidate(spec, Genome(tile=4, unroll=3, vector_width=2, pipeline=4, split=2))
    evidence = verify_candidate(candidate, program, [[1, 2, 3, 4], [-1.5, 0, 8, 2]])
    assert evidence.passed
    assert evidence.checked_points == 8
