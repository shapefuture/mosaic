from mosaic_omega.compiler import *
from mosaic_omega.capability import *
from mosaic_omega.formal import available_backends
from mosaic_omega.selfhost import PromotionGate, SelfHostController


def test_effects_are_explicitly_enforced():
    u = ComputationalUnit("x", "tool", effects=EffectSet(frozenset({"network.write"})))
    assert ProgramIR((u,), authority=frozenset()).validate()
    assert not ProgramIR((u,), authority=frozenset({"network.write"})).validate()


def test_residual_verifier_invalidates_only_dependency_cone():
    rv = ResidualVerifier((
        VerificationNode("a", "a", invalidation_keys=("x",), recompute_cost=1),
        VerificationNode("b", "b", dependencies=("a",), recompute_cost=2),
        VerificationNode("c", "c", invalidation_keys=("y",), recompute_cost=5),
    ))
    p = rv.plan(("x",))
    assert p.invalidated == ("a", "b")
    assert p.preserved == ("c",)
    assert p.estimated_cost == 3


def test_capability_package_and_hotness():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    u = ComputationalUnit("x", "transform")
    pkg = CapabilityPackage.build(u, name="x", version="1")
    with TemporaryDirectory() as td:
        path = CapabilityPackage.write(pkg, Path(td) / "x.vrc.zip")
        assert CapabilityPackage.inspect(path)["valid_shape"]
    assert HotnessCompiler().compile(uses=1000, success_rate=1.0, latency_ms=20).tier == "native"


def test_self_host_promotion_requires_all_gates():
    c = SelfHostController()
    cand = c.propose("p", description="d", source_hash="s")
    assert cand.digest
    assert c.promote(PromotionGate(True, True, True, True, True))
    assert not c.promote(PromotionGate(True, False, True, True, True))


def test_omega7_gauntlet_passes():
    from mosaic_omega.gauntlets.omega7 import run_omega7_gauntlet
    r = run_omega7_gauntlet()
    assert r.all_checks_passed
    assert r.gpu_work_fraction == 0.0
    assert r.frontier_call_fraction == 0.0
