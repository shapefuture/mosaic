from mosaic_omega.gauntlets.experience import run_experience_gauntlet

def test_experience_gauntlet_exercises_critical_failure_detection():
    r = run_experience_gauntlet(trajectories=25)
    assert r.status == "PASS"
    assert r.critical_steps > 0
