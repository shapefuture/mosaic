import pytest

from mosaic_omega.backends.native import NativeCPUBackend
from mosaic_omega.eval.reference import reference_vector
from mosaic_omega.ir.nodes import Add, Const, Input, Mul
from mosaic_omega.ir.program import Program
from mosaic_omega.model import Candidate, ComputeSpec, Genome


def test_native_backend_executes_and_matches_reference():
    b = NativeCPUBackend()
    if not b.capabilities.available:
        pytest.skip("no native compiler")
    p = Program("p", Add(Mul(Const(2.0), Input()), Const(1.0)))
    c = Candidate(ComputeSpec("p", "elementwise", 64, target="native-cpu"), Genome(tile=4, unroll=4, vector_width=4))
    x = [float(i) for i in range(64)]
    a = b.compile(p, c)
    assert b.run(a, x) == reference_vector(p, x)
    b.close()
