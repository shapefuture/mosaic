from pathlib import Path
import json

from mosaic_omega.sources.discovery import discover_session_sources, iter_discovered_trajectories


def test_unknown_location_flows_into_trajectory_ingestion(tmp_path: Path):
    p = tmp_path / "some-agent" / "history" / "weird-session.ndjson"
    p.parent.mkdir(parents=True)
    p.write_text(json.dumps({"run_id":"r1","events":[{"kind":"tool_call","action":"shell_command","observation":"pytest","ok":True}]}) + "\n", encoding="utf-8")
    sources = discover_session_sources([tmp_path], min_confidence=0.2)
    src = next(s for s in sources if s.path == str(p))
    trajs = list(iter_discovered_trajectories(src))
    assert len(trajs) == 1
    assert trajs[0].run_id == "r1"
