from mosaic_omega.gauntlets.superiority import run_superiority_gauntlet


def test_superiority_gauntlet():
    r = run_superiority_gauntlet()
    assert r.all_checks_passed
    assert r.raw_payload_sources >= 4
    assert r.behavior_sources >= 2
    assert r.transfer_sources >= 2
    assert r.thought_text_ingested is True
    assert r.reasoning_signal_ingested is True
    assert r.raw_reasoning_opt_in_only is True
    assert r.model_call_elimination == 1.0
