from mosaic_omega.verification import VerificationCompiler

def test_verification_scales_with_risk():
    v=VerificationCompiler()
    lo=v.compile(risk=.1,novelty=.1,change_surface=.1,value=.1)
    hi=v.compile(risk=.95,novelty=.95,change_surface=.95,value=.95)
    assert len(hi.stages)>len(lo.stages)
    assert hi.estimated_cost_usd>lo.estimated_cost_usd
