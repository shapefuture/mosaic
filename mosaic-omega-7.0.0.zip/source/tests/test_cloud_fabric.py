from mosaic_omega.cloud import *


def test_state_handles_are_explicit_and_forkable():
    s=StateStore(); h=s.create('t1', initial={'x':1}); h2=s.update(h, {'y':2}); h3=s.fork(h2, branch='b1')
    assert s.load(h2).data['y']==2
    assert s.load(h3).data['_branch']=='b1'
    assert h2.tenant_id==h3.tenant_id


def test_tenant_policy_blocks_gpu_and_network():
    k=TenantKernel(); k.register('t', policy=TenantPolicy(allow_network=False, allow_gpu=False, allowed_capabilities=frozenset({'x'})))
    auth=TenantAuth('t','s')
    try: k.authorize(auth,'x',gpu=True); assert False
    except PermissionError: pass
    try: k.authorize(auth,'x',network=True); assert False
    except PermissionError: pass


def test_runtime_ladder_prefers_lightweight_and_escalates_for_untrusted():
    c=SandboxPolicyCompiler()
    assert c.compile(tenant_id='t', trust='trusted', network=False, memory_mb=64, cpu_ms=10, capability='x').tier==ExecutionTier.NATIVE
    assert c.compile(tenant_id='t', trust='constrained', network=False, memory_mb=256, cpu_ms=10, capability='x').tier==ExecutionTier.WASM
    assert c.compile(tenant_id='t', trust='untrusted', network=False, memory_mb=2048, cpu_ms=1000, capability='x').tier==ExecutionTier.MICROVM


def test_stateless_gateway_reuses_catalog_and_explicit_state():
    g=StatelessMCPGateway({'echo': lambda x: x})
    a=g.tools_list(); b=g.tools_list(); assert a is b
    r=g.handle(MCPRequest('tools/call', {'name':'echo','arguments':{'x':7}}, 't1', request_id=1, state_handle='s1'))
    assert r.result['x']==7


def test_ephemeral_gauntlet_small():
    from mosaic_omega.cloud.gauntlet import run_ephemeral_gauntlet
    r=run_ephemeral_gauntlet(logical_agents=1000, concurrent_cells=100, tenants=10)
    assert r.all_checks_passed
    assert r.logical_agents==1000
