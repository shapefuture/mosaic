from pathlib import Path

from mosaic_omega.data.github_trajectories import (
    GITHUB_TRACE_SOURCES,
    iter_local_github_trace,
    records_to_trajectory,
)
from mosaic_omega.learning.recovery import compile_recovery_rules, mine_recovery_rules


FIXTURE = Path(__file__).resolve().parents[1] / "examples" / "frontier_traces" / "all_haiku_observable_sample.jsonl"


def test_real_github_source_manifest_is_pinned():
    spec = GITHUB_TRACE_SOURCES[0]
    assert spec.repository == "when2buy/llm-trajectory-data"
    assert spec.path.endswith("all_haiku.trace.jsonl")
    assert spec.blob_sha == "6d24773c1303911ea2cfe065524797de502382fc"
    assert spec.bytes == 123453
    assert spec.model.startswith("claude-haiku-4-5")
    assert spec.reward is not None and spec.passed == 40 and spec.total == 54


def test_local_projection_uses_observable_actions_only():
    traj = next(iter_local_github_trace(FIXTURE))
    assert traj.run_id == "all_haiku_observable_sample"
    assert len(traj.events) == 12
    assert all((e.kind != "reasoning") for e in traj.events)
    assert any(e.action == "Read" for e in traj.events)
    assert any(e.kind == "error" and e.action == "timeout" for e in traj.events)


def test_real_trace_failure_to_repair_rules_are_compiled():
    traj = next(iter_local_github_trace(FIXTURE))
    rules = mine_recovery_rules([traj], max_actions=1, min_occurrences=1)
    signatures = {r.error_signature: r.actions[0].name for r in rules}
    assert signatures["syntax_error"] == "write"
    assert signatures["timeout"] == "write"
    assert signatures["missing_dependency"] == "edit"
    units = compile_recovery_rules(rules, GITHUB_TRACE_SOURCES[0].digest)
    assert len(units) == 3
    assert all(u.contract.name.startswith("recovery_") for u in units)


def test_parser_records_model_metadata_without_hidden_reasoning():
    rows = [
        {"seq": 1, "orig": "x", "served": "m", "request": {}, "response": {"tool_uses": [{"name": "Read", "input_partial": "{}"}], "usage": {"input_tokens": 2, "output_tokens": 3}}}
    ]
    traj = records_to_trajectory(rows, run_id="r")
    assert traj.events[0].metadata["teacher_model"] == "m"
    assert traj.events[0].metadata["input_tokens"] == 2
    assert "thinking" not in traj.events[0].metadata
