from mosaic_omega.context import ContextCompiler
from mosaic_omega.replay import ReplayStore, StateSnapshot


def test_context_compiler_deduplicates_and_reduces():
    text = "alpha beta\nalpha beta\nimportant memory state\nnoise\n"
    out = ContextCompiler(max_chars=40).compile(text, query="important state")
    assert out.compiled_tokens <= out.original_tokens
    assert len(out.chunks) <= 3
    assert out.digest


def test_replay_checkpoint_and_fork(tmp_path):
    store = ReplayStore(tmp_path)
    root = StateSnapshot("s0", None, {"x": 1})
    store.save(root)
    child = store.fork("s0", "s1", {"x": 2, "y": 3})
    loaded = store.load("s1")
    assert loaded.parent_id == "s0"
    assert loaded.state == {"x": 2, "y": 3}


def test_context_compiler_protects_safety_constraints():
    text = "ordinary noisy history\nSECURITY: never disable sandbox\nmore noise"
    out = ContextCompiler(max_chars=80).compile(text, query="noise")
    assert any("never disable sandbox" in c.text.lower() for c in out.chunks)
