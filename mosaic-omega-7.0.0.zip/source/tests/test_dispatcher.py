from mosaic_omega.model import Candidate, ComputeSpec, Genome, Observation, VerificationEvidence
from mosaic_omega.runtime.dispatcher import DispatcherSynthesizer


def test_dispatcher_falls_back_to_best():
    def o(c, latency):
        return Observation(c.genome_id, 1, latency, latency, 8, True, VerificationEvidence(True, "ok"), (1, 1, 1, 1, 1), "reference-cpu")
    a = Candidate(ComputeSpec("x", "noop", 4), Genome(tile=1))
    b = Candidate(ComputeSpec("x", "noop", 4), Genome(tile=2))
    d = DispatcherSynthesizer().synthesize([(a, o(a, 2.0)), (b, o(b, 1.0))])
    assert d.select(999) == b.genome_id
