from mosaic_omega.network.gauntlet import run_network_gauntlet
from mosaic_omega.network.market import ReplicationPolicy


def test_network_gauntlet_passes():
    r = run_network_gauntlet()
    assert r["passed"]
    assert r["promotion"]
    assert r["selected"][0] == "cpu-a"
    assert r["net_future_value_usd"] > 0


def test_replication_policy_is_adaptive():
    p = ReplicationPolicy()
    assert p.replicas(trust=0.1, novelty=1.0, risk=0.0, mature=False) == 3
    assert p.replicas(trust=0.99, novelty=0.0, risk=0.0, mature=True) in (1, 2)
    assert p.replicas(trust=0.99, novelty=0.0, risk=0.9, mature=True) == 3
