from mosaic_omega.network.market import CapabilityRegistry, CapabilityOffer, CapabilityQuery, NodeProfile, NodeRoles
from mosaic_omega.capability.pcc import ProofCarryingCapability


def _offer(provider='n1'):
    cap = ProofCarryingCapability('x','x',('a',),('b',),'impl','ver',cost_usd=.01,latency_ms=10,provenance={'x':'y'})
    return CapabilityOffer(capability=cap, provider_id=provider, family='f', locality='same', verification_level=2, expected_reuse=20, future_savings_usd=2, cost_usd=.01, latency_ms=10, quality=1.0)


def test_local_first_registry_query_and_revoke():
    r=CapabilityRegistry(); r.register_node(NodeProfile('n1', frozenset({NodeRoles.EXECUTOR}), locality='same'))
    d=r.publish(_offer())
    assert len(r.query(CapabilityQuery('f', locality='same')))==1
    r.revoke(d)
    assert not r.query(CapabilityQuery('f', locality='same'))
