from mosaic_omega.ecu.gauntlet_v2 import run_frontier_gauntlet


def test_frontier_ecu_gauntlet():
    r = run_frontier_gauntlet()
    assert r.all_checks_passed
    assert r.frontier_call_reduction >= 0.5
    assert r.planning_step_reduction >= 0.5
    assert r.prefix_reuse_ratio >= 0.5
    assert r.verified_units >= 1
