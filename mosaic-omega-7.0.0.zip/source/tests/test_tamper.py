from dataclasses import replace
from mosaic_omega.model import Candidate, ComputeSpec, Genome
from mosaic_omega.security.provenance import attest, make_manifest, verify_attestation


def test_tampering_invalidates_attestation():
    c = Candidate(ComputeSpec("x", "noop", 4), Genome())
    att = attest(make_manifest(c, "abc"), b"secret")
    tampered = replace(att, manifest=replace(att.manifest, target="tampered"))
    assert not verify_attestation(tampered, b"secret")
