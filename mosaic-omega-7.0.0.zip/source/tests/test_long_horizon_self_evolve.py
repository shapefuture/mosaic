from mosaic_omega.gauntlets.long_horizon import recursive_long_horizon_gauntlet, generate_tasks, _mutate_harder


def test_long_horizon_generator_grows_harder():
    base = generate_tasks(2, depth=5, seed=1)
    harder = _mutate_harder(base, 1)
    assert len(harder) == len(base)
    assert all(h.depth > b.depth for b, h in zip(base, harder))
    assert all("cross_module_regression" in h.failure_modes for h in harder)


def test_recursive_long_horizon_superiority():
    r = recursive_long_horizon_gauntlet(rounds=3, base_tasks=5, seed=2)
    assert r.all_checks_passed
    assert r.mosaic_score >= 0.99
    assert r.quality_gain >= 0.05
    assert r.speedup >= 1.10
    assert r.cost_reduction >= 0.70
    assert r.harder_tasks_generated > 0
