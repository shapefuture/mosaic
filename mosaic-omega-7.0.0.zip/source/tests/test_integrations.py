import json
from pathlib import Path
from mosaic_omega.integrations import load_jsonl, export_atif_like


def test_jsonl_roundtrip(tmp_path):
    p = tmp_path / 'trace.jsonl'
    p.write_text(json.dumps({"step":0,"kind":"tool","action":"echo","observation":"ok","ok":True,"state_hash":"abc"})+'\n')
    traj = load_jsonl(p, 'r')
    out = export_atif_like(traj)
    assert out['trajectory_id'] == 'r'
    assert out['steps'][0]['action'] == 'echo'
