from mosaic_omega.learning.skill_bank import SkillBank
from mosaic_omega.ecu.core import ECUAction, ECUContract, ECUEnvironment, ExecutableComputeUnit


def test_skill_bank_roi_and_parameterized_route():
    unit = ExecutableComputeUnit(ECUContract('u'), [ECUAction('open', {'path': '$param.path'})], {'m': 1})
    bank = SkillBank()
    rec = bank.register(unit, actions=('open',), mean_latency_ms=1, mean_cost_usd=0, calls_saved=20)
    env = ECUEnvironment({}, {'open': lambda e, path: e.state.__setitem__('path', path)})
    got, result = bank.execute(('open',), env, params={'path': 'x.py'})
    assert got and got.roi > 0 and result and result.success and env.state['path'] == 'x.py'
