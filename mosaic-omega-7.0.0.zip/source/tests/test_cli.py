from mosaic_omega.cli.main import main


def test_demo_runs(capsys):
    assert main(["demo", "--generations", "2", "--population", "6", "--budget", "4"]) == 0
    out = capsys.readouterr().out
    assert '"attestation_valid": true' in out
    assert '"pareto_size"' in out
