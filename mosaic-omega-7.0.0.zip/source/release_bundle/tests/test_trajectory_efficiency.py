from mosaic_omega.trajectory.events import Trajectory, TrajectoryEvent
from mosaic_omega.trajectory.efficiency import analyze_efficiency


def test_efficiency_penalizes_duplicates_and_recovery():
    t = Trajectory(
        "t",
        (
            TrajectoryEvent(0, "tool_call", "open", observation="a", ok=True),
            TrajectoryEvent(1, "tool_call", "open", observation="a", ok=True),
            TrajectoryEvent(2, "tool_call", "run", observation="b", ok=False),
            TrajectoryEvent(3, "recovery", "run", observation="b", ok=True),
        ),
    )
    r = analyze_efficiency(t)
    assert r.exact_duplicates == 1
    assert r.backtracks == 1
    assert r.efficiency < 1.0
