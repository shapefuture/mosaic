from mosaic_omega.omega import run_omega_gauntlet, Capability, CapabilityGraph, TaskCompiler, PlanPortfolio, ActiveVerifier
from mosaic_omega.task_ir import TaskIR

def test_omega_gauntlet():
    r=run_omega_gauntlet()
    assert r.all_checks_passed
    assert r.local_plan_frontier_steps == 0
    assert r.winning_cost_usd < .01
    assert r.winning_latency_ms < 100

def test_capability_graph_and_plan_compiler():
    g=CapabilityGraph([Capability('a', provides=('x',)), Capability('b', requires=('x',), provides=('y',), latency_ms=1, cost_usd=.001)])
    p=TaskCompiler(g).compile(TaskIR('g',verification=('y',)))
    assert [c.name for c in p.capabilities] == ['a','b']

def test_active_verifier_stops_early():
    v=ActiveVerifier([('cheap', lambda x:(True,1.0,None), .001), ('expensive', lambda x:(True,1.0,None), 1.0)])
    o=v.verify(object())
    assert o.accepted and o.stages == ('cheap',) and o.cost_usd == .001
