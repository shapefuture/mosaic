from mosaic_omega.control import ActionEstimate, MarginalValueController

def test_control_prefers_highest_roi():
    c=MarginalValueController(min_roi=1)
    d=c.decide([ActionEstimate('cheap',.1,.2,0,0.1), ActionEstimate('expensive',.3,1,0,1)])
    assert d.action=='cheap'

def test_control_stops_when_no_roi():
    d=MarginalValueController(min_roi=2).decide([ActionEstimate('x',.1,0,0,1)])
    assert d.stop
