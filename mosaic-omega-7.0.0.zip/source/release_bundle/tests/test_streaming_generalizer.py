from mosaic_omega.learning.streaming import StreamingECUTrainer
from mosaic_omega.data.frontier import TRAINING_MANIFESTS
from mosaic_omega.trajectory.events import Trajectory, TrajectoryEvent
from mosaic_omega.ecu.core import ECUEnvironment


def test_streaming_generalizer_parameterizes_variants():
    ts=[]
    for i,p in enumerate(('a.py','b.py','c.py')):
        ts.append(Trajectory(str(i), (TrajectoryEvent(0,'tool','open',f'{{"path":"{p}"}}',ok=True), TrajectoryEvent(1,'verify','check',ok=True,metadata={'verify_status':'resolved'}))))
    t=StreamingECUTrainer(min_support=3)
    t.update_many(ts)
    units, diag=t.compile(TRAINING_MANIFESTS[0])
    assert units and diag['accepted_units'] >= 1
    unit=next(u for u in units if u.actions[0].name=='open')
    env=ECUEnvironment({}, {'open': lambda e, path: e.state.__setitem__('opened',path), 'check': lambda e: True}, {'0.path':'z.py'})
    assert unit.run(env).success and env.state['opened']=='z.py'
