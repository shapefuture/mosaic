from mosaic_omega.optimize.plan_competition import PlanCompetition, PlanCandidate

def test_plan_competition_selects_economic_verified_plan():
    r=PlanCompetition().select([
        PlanCandidate('a',10,1,.999,1,True),
        PlanCandidate('b',2,.2,.9995,1,True),
        PlanCandidate('c',1,.01,.8,1,True),
    ], min_quality=.99)
    assert r.selected=='b'
