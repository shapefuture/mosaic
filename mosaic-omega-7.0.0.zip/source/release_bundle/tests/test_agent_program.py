from mosaic_omega.runtime.agent_program import AgentProgramCompiler, ProgramNode
from mosaic_omega.ecu.core import ECUAction, ECUEnvironment


def test_agent_program_compiles_and_fuses_reasoning():
    p = AgentProgramCompiler().compile([
        ProgramNode("a", "inference", ECUAction("think1"), (), "frontier", 10, 0.01, "same ctx", False),
        ProgramNode("b", "inference", ECUAction("think2"), ("a",), "frontier", 10, 0.01, "same ctx", False),
        ProgramNode("v", "verify", ECUAction("verify"), ("b",), "cpu", 2, 0.0, "same ctx", True),
        ProgramNode("dead", "tool", ECUAction("dead"), (), "cpu", 1, 0.0, "", True),
    ])
    assert p.removed_nodes == ("dead",)
    assert p.fused_nodes == (("a", "b"),)
    assert p.dedup_contexts >= 1
    assert p.waves == (("a",), ("v",))


def test_agent_program_executes_shared_state():
    compiler = AgentProgramCompiler()
    p = compiler.compile([
        ProgramNode("a", "tool", ECUAction("inc"), (), "cpu", 1),
        ProgramNode("b", "tool", ECUAction("inc"), (), "cpu", 1),
        ProgramNode("v", "verify", ECUAction("check"), ("a", "b"), "cpu", 1),
    ])
    env = ECUEnvironment({"a": 0, "b": 0}, {"inc_a": lambda e: e.state.__setitem__("a", 1), "inc_b": lambda e: e.state.__setitem__("b", 2), "check": lambda e: e.state["a"] + e.state["b"] == 3})
    p = compiler.compile([
        ProgramNode("a", "tool", ECUAction("inc_a"), (), "cpu", 1),
        ProgramNode("b", "tool", ECUAction("inc_b"), (), "cpu", 1),
        ProgramNode("v", "verify", ECUAction("check"), ("a", "b"), "cpu", 1),
    ])
    r = compiler.execute(p, env)
    assert r.success and env.state["a"] == 1 and env.state["b"] == 2
