from mosaic_omega.network.market import CapabilityRegistry, CapabilityOffer, NodeProfile, NodeRoles, CapabilityQuery
from mosaic_omega.capability.pcc import ProofCarryingCapability


def test_content_address_changes_when_capability_changes():
    r=CapabilityRegistry(); r.register_node(NodeProfile('n', frozenset({NodeRoles.EXECUTOR}), locality='same'))
    a=ProofCarryingCapability('a','x',(),(),'i','v')
    b=ProofCarryingCapability('a','x2',(),(),'i','v')
    da=r.publish(CapabilityOffer(a,'n','f')); db=r.publish(CapabilityOffer(b,'n','f'))
    assert da != db


def test_executable_market_rejects_non_executable_offer():
    r=CapabilityRegistry()
    a=ProofCarryingCapability('a','x',(),(),'i','v')
    try:
        r.publish(CapabilityOffer(a,'n','f',executable=False))
    except ValueError:
        return
    raise AssertionError('non-executable capability was published')
