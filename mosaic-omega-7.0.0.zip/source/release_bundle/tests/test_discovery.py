from pathlib import Path
import json

from mosaic_omega.sources.discovery import discover_session_sources


def test_discovers_unknown_agent_location_by_content(tmp_path: Path):
    root = tmp_path / "custom-agent-install" / "sessions"
    root.mkdir(parents=True)
    trace = root / "session-001.jsonl"
    rows = [
        {"role": "assistant", "model": "mystery-agent-7", "content": "inspect"},
        {"role": "tool", "tool_call": {"name": "shell_command", "arguments": {"cmd": "pytest"}}, "tool_result": "ok"},
        {"trajectory_id": "abc", "events": [{"kind": "tool_call", "action": "shell_command", "observation": "pytest", "ok": True}]},
    ]
    trace.write_text("\n".join(json.dumps(r) for r in rows), encoding="utf-8")

    out = discover_session_sources([tmp_path], min_confidence=0.25)
    assert any(x.path == str(trace) for x in out)
    hit = next(x for x in out if x.path == str(trace))
    assert hit.format == "jsonl"
    assert hit.agent in {"generic-agent", "codex", "claude", "swe-agent"}
    assert hit.digest


def test_discovers_sqlite_session_by_schema(tmp_path: Path):
    import sqlite3
    db = tmp_path / "weird-agent-history.sqlite3"
    conn = sqlite3.connect(db)
    conn.execute("create table history(id integer primary key, role text, content text, tool_name text)")
    conn.execute("insert into history(role, content, tool_name) values(?,?,?)", ("assistant", "inspect repository", "shell_command"))
    conn.commit(); conn.close()

    out = discover_session_sources([tmp_path], min_confidence=0.15)
    assert any(x.path == str(db) and x.format == "sqlite" for x in out)
