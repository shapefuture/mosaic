import json
from pathlib import Path
from mosaic_omega.data.inspect_logs import iter_inspect_trajectories


def test_json_inspect_log_ingestion_is_streaming_shape(tmp_path: Path):
    p = tmp_path / "sample.json"
    p.write_text(json.dumps({"status":"success","eval":{"task":"demo","model":"x"},"samples":[{"id":"s1","events":[{"type":"tool","name":"search","content":"ok","ok":True},{"type":"verify","name":"check","ok":True}]}]}))
    rows = list(iter_inspect_trajectories(p))
    assert len(rows) == 1 and rows[0].run_id == "s1"
    assert rows[0].events[0].action == "search"
    assert rows[0].events[1].kind == "verify"
