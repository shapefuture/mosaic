from mosaic_omega.archive.pareto import Archived, ParetoArchive, dominates
from mosaic_omega.model import Candidate, ComputeSpec, Genome, Observation, VerificationEvidence


def obs(candidate, latency, energy, memory=10):
    return Observation(candidate.genome_id, 1, latency, energy, memory, True, VerificationEvidence(True, "ok", 1), (1, 1, 1, 1, 1), "reference-cpu")


def test_dominance_and_archive():
    spec = ComputeSpec("x", "noop", 2)
    a = Candidate(spec, Genome(tile=1))
    b = Candidate(spec, Genome(tile=2))
    oa, ob = obs(a, 1.0, 1.0), obs(b, 2.0, 2.0)
    assert dominates(oa, ob)
    archive = ParetoArchive()
    assert archive.add(Archived(a, oa))
    assert not archive.add(Archived(b, ob))
    assert len(archive.items()) == 1
