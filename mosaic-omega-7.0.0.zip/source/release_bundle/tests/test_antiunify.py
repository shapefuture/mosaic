from mosaic_omega.learning.antiunify import anti_unify, compile_generalized
from mosaic_omega.runtime.router import ExecutionRouter
from mosaic_omega.ecu.core import ECUEnvironment
from mosaic_omega.trajectory.events import Trajectory, TrajectoryEvent


def test_anti_unify_and_parameterized_execution():
    runs = [
        Trajectory("r1", (TrajectoryEvent(0, "tool", "open", '{"path":"a.py"}', ok=True), TrajectoryEvent(1, "verify", "check", ok=True, metadata={"verify_status":"resolved"}))),
        Trajectory("r2", (TrajectoryEvent(0, "tool", "open", '{"path":"b.py"}', ok=True), TrajectoryEvent(1, "verify", "check", ok=True, metadata={"verify_status":"resolved"}))),
        Trajectory("r3", (TrajectoryEvent(0, "tool", "open", '{"path":"c.py"}', ok=True), TrajectoryEvent(1, "verify", "check", ok=True, metadata={"verify_status":"resolved"}))),
    ]
    ps = anti_unify(runs, min_support=3)
    assert ps and any(p.parameter_count >= 1 for p in ps)
    units = compile_generalized(ps, "m")
    unit = next(u for u in units if u.actions[0].name == "open")
    env = ECUEnvironment({}, {"open": lambda e, path: e.state.__setitem__("opened", path), "check": lambda e: True})
    env.params["0.path"] = "z.py"
    r = unit.run(env)
    assert r.success and env.state["opened"] == "z.py"
