from mosaic_omega.cloud import StatelessMCPGateway, MCPRequest, TenantKernel, TenantPolicy

def test_mcp_edge_enforces_tenant_policy():
    k=TenantKernel(); k.register('t', policy=TenantPolicy(allow_network=False, allow_gpu=False, allowed_capabilities=frozenset({'echo'})))
    g=StatelessMCPGateway({'echo': lambda a: a, 'secret': lambda a: {'secret':True}}, tenant_kernel=k)
    ok=g.handle(MCPRequest('tools/call', {'name':'echo','arguments':{'x':1}}, 't', 1))
    assert ok.error is None and ok.result['x']==1
    bad=g.handle(MCPRequest('tools/call', {'name':'secret','arguments':{}}, 't', 2))
    assert bad.error is not None
