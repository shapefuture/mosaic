from mosaic_omega.network.pui import PUIRecord, capability_future_value


def test_pui_rewards_future_savings():
    r = PUIRecord(0.99, 1.0, 1.0, 0.01, 100, 10, 10, 2, expected_reuse=100, verified=True, transferred=True)
    assert r.pui > 1


def test_pui_rejects_quality_regression():
    r = PUIRecord(1.0, 0.9, 1.0, 0.01, 100, 10, 10, 2, expected_reuse=100, verified=True)
    assert r.pui == 0


def test_future_value():
    assert capability_future_value(expected_reuse=100, savings_per_use_usd=0.01, reliability=0.9, risk=0.1) > 0
