from mosaic_omega.model import Observation, VerificationEvidence
from mosaic_omega.search.surrogate import OnlineLinearSurrogate


def test_surrogate_learns_directionally():
    s = OnlineLinearSurrogate()
    obs = Observation("c", 1, 10.0, 1.0, 1, True, VerificationEvidence(True, "ok"), (10, 0, 0, 0, 0), "cpu")
    before = s.predict(obs.features)[0]
    s.update(obs)
    after = s.predict(obs.features)[0]
    assert after > before
