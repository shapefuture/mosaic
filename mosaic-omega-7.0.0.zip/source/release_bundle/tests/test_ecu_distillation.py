import json
from mosaic_omega.data.frontier import orchard_row_to_event_dict, gpt56_row_to_event_dict, TRAINING_MANIFESTS, SEALED_EVAL_MANIFESTS, validate_manifest_for_training
from mosaic_omega.trajectory.events import Trajectory, TrajectoryEvent
from mosaic_omega.ecu import ECUAction, ECUContract, ECUEnvironment, ExecutableComputeUnit, distill_ecus, verify_ecu

def _traj(run_id, actions, ok=True):
    return Trajectory(run_id, tuple(TrajectoryEvent(i, "tool_call", a, ok=ok, state_hash=f"s{i}") for i,a in enumerate(actions)))

def test_frontier_manifests_gate_training():
    for m in TRAINING_MANIFESTS: validate_manifest_for_training(m)
    for m in SEALED_EVAL_MANIFESTS:
        try: validate_manifest_for_training(m)
        except ValueError: pass
        else: raise AssertionError("sealed eval dataset must never pass training gate")

def test_orchard_schema_adapter():
    row={"metadata":json.dumps({"instance_id":"x","verify_status":"resolved"}),"messages":[{"role":"assistant","tool_calls":[{"function":{"name":"pytest","arguments":"{}"}}]}]}
    out=orchard_row_to_event_dict(row)
    assert out["dataset"] == "microsoft/Orchard" and out["events"][0]["action"] == "pytest"

def test_gpt56_schema_adapter_preserves_source_lineage():
    row={"task":"x","source_trajectory_id":"x:1","verifier":"tests","split":"train","teacher_model":"gpt-5.6-sol","messages":[{"role":"assistant","tool_calls":[{"function":{"name":"exec","arguments":"{}"}}]}]}
    out=gpt56_row_to_event_dict(row)
    assert out["run_id"] == "x:1" and out["events"][0]["metadata"]["teacher_model"] == "gpt-5.6-sol"

def test_ecu_executes_and_verifies():
    def add(env, key, value): env.state[key]=value; return value
    ecu=ExecutableComputeUnit(ECUContract("set", postconditions=('ready==true',)), [ECUAction("add", {"key":"ready","value":True})])
    v=verify_ecu(ecu, [(ECUEnvironment(handlers={"add":add}), lambda e: e.state["ready"] is True)])
    assert v.passed and v.cases == 1

def test_ecu_precondition_fails_closed():
    ecu=ExecutableComputeUnit(ECUContract("x", preconditions=("repo==\"ok\"",)), [ECUAction("noop")])
    r=ecu.run(ECUEnvironment(state={"repo":"bad"}, handlers={"noop":lambda e:None}))
    assert not r.success

def test_distillation_finds_repeated_procedure():
    ts=[_traj(f"r{i}",["open_file","apply_patch","run_tests"]) for i in range(5)] + [_traj("bad",["open_file","apply_patch"],ok=False)]
    units, report=distill_ecus(ts, min_support=3, max_actions=3, source_manifest="orchard-fixture")
    assert report.trajectories_seen==6 and report.failed==1 and units
    assert any("run_tests" in {a.name for a in u.actions} for u in units)
