from mosaic_omega.omega.benchmark import run_benchmark

def test_economic_execution_benchmark():
    r=run_benchmark(families=4, repeats=12)
    assert r.exact_match
    assert r.verified
    assert r.optimized_frontier_calls == 0
    assert r.cost_reduction > 0.5
    assert r.speedup > 1.5
    assert r.all_checks_passed
