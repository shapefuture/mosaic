from mosaic_omega.learning.diversity import split_by_group, trajectory_group_id
from mosaic_omega.trajectory.events import Trajectory, TrajectoryEvent


def test_group_split_has_no_overlap():
    ts = [Trajectory(f"r{i}", (TrajectoryEvent(0, "tool_call", "x", metadata={"source_trajectory_id": f"src-{i}"}),)) for i in range(10)]
    train, val = split_by_group(ts, 0.2)
    assert not {trajectory_group_id(t) for t in train}.intersection({trajectory_group_id(t) for t in val})
