from mosaic_omega.profiling.workload import profile_vector


def test_workload_profile_is_deterministic():
    p = profile_vector([1.0] * 4096, arithmetic_ops=2)
    assert p.elements == 4096
    assert p.total_bytes == 65536
    assert p.likely_memory_bound
