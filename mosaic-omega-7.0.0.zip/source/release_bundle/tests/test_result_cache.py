from mosaic_omega.ir.nodes import Add, Const, Input, Mul
from mosaic_omega.ir.program import Program
from mosaic_omega.runtime.result_cache import ResultCache


def test_exact_result_cache_eliminates_repeat_execution():
    p = Program("p", Add(Mul(Const(2.0), Input()), Const(1.0)))
    cache = ResultCache()
    calls = {"n": 0}
    x = [1.0, 2.0, 3.0]

    def compute():
        calls["n"] += 1
        return tuple(2.0 * v + 1.0 for v in x)

    assert cache.get_or_compute(p, x, compute) == (3.0, 5.0, 7.0)
    assert cache.get_or_compute(p, x, compute) == (3.0, 5.0, 7.0)
    assert calls["n"] == 1
    assert cache.stats().hits == 1
