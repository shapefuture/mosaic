from mosaic_omega.ir.nodes import Add, Const, Input, Mul, Neg
from mosaic_omega.optimize import optimize


def test_optimizer_eliminates_redundant_work():
    root = Add(Add(Mul(Const(2.0), Input()), Add(Const(3.0), Const(4.0))), Neg(Neg(Const(0.0))))
    out, report = optimize(root)
    assert report.original_nodes > report.optimized_nodes
    assert report.eliminated_nodes >= 2
    assert isinstance(out, Add)
