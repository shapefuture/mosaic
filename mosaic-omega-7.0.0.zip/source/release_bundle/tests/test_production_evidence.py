from mosaic_omega.eval.production import ProductionEvaluator, ProductionConfig
from mosaic_omega.ir.nodes import Add, Const, Input, Mul
from mosaic_omega.ir.program import Program
from mosaic_omega.model import Candidate, ComputeSpec, Genome


def test_production_evidence_emission():
    program = Program('evidence', Add(Mul(Const(2.0), Input()), Const(1.0)))
    spec = ComputeSpec('evidence', 'elementwise', 32)
    cand = Candidate(spec, Genome(tile=4, unroll=2, vector_width=2))
    evaluator = ProductionEvaluator(ProductionConfig(repeats=2, verify_samples=1))
    obs, eer = evaluator.evaluate_cpu_with_evidence(cand, program)
    evaluator.close()
    assert obs.correct
    assert eer.run_id == cand.genome_id
    assert len(eer.events) >= 2
    assert eer.digest
