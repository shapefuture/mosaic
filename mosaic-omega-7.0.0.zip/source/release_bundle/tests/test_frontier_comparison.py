import json
from pathlib import Path

from mosaic_omega.frontier import (
    TOOLATHLON_VERIFIED_AUG_2026,
    compare_to_published_snapshot,
    load_replay_metrics,
    aggregate_replays,
)


def test_snapshot_has_current_reference() -> None:
    s = TOOLATHLON_VERIFIED_AUG_2026
    assert s.tasks == 108
    assert s.best_model == "Claude Opus 5"
    assert s.best_score == 0.806


def test_comparison_flags_non_comparable_local_fixture() -> None:
    c = compare_to_published_snapshot(
        TOOLATHLON_VERIFIED_AUG_2026,
        mosaic_success=1.0,
        mosaic_frontier_calls=0,
        mosaic_tasks=24,
    )
    assert not c.comparable
    assert c.gap_to_frontier > 0
    assert c.frontier_call_reduction == 1.0
    assert not c.superior_quality


def test_replay_metrics_roundtrip_and_aggregate(tmp_path: Path) -> None:
    p = tmp_path / "replay.json"
    p.write_text(json.dumps({
        "model": "fixture-model",
        "tasks": 3,
        "successful_tasks": 2,
        "success_rate": 2 / 3,
        "frontier_calls": 9,
        "average_turns": 12,
        "latency_ms": 30,
        "cost_usd": 0.15,
    }), encoding="utf-8")
    row = load_replay_metrics(p)
    agg = aggregate_replays([row, row])
    assert agg.tasks == 6
    assert agg.successful_tasks == 4
    assert agg.frontier_calls == 18
    assert agg.cost_usd == 0.3
