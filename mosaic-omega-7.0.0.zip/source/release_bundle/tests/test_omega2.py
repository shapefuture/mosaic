from mosaic_omega.omega2.gauntlet import run_omega2_gauntlet
from mosaic_omega.omega2.ir import AgentNode, AgentProgram, NodeKind, ProgramContract
from mosaic_omega.omega2.collective import CollectiveRegistry, CollectiveEnvelope, contribution_receipt


def test_program_validates_and_waves():
    p=AgentProgram(ProgramContract('x'),(AgentNode('a',NodeKind.ACTION,'a'),AgentNode('b',NodeKind.ACTION,'b',('a',))))
    assert p.validate()[0]
    assert p.waves()==(('a',),('b',))


def test_collective_rejects_bad_quality():
    p=AgentProgram(ProgramContract('x'),(AgentNode('a',NodeKind.ACTION,'a'),))
    env=CollectiveEnvelope.from_program(p, contributor_id='u', benchmark={'quality':.5,'cost_usd':1}, verifier_digest='x')
    r=CollectiveRegistry()
    assert not r.verify_and_promote(env, lambda _: True)


def test_omega2_gauntlet():
    r=run_omega2_gauntlet(tasks=12, depth=8)
    assert r.all_checks_passed
    assert r.verified_success==1.0
    assert r.collective_acceptance==1.0
    assert r.frontier_call_reduction==1.0
    assert r.adversarial_robustness==1.0


def test_collective_tamper_rejected():
    p=AgentProgram(ProgramContract('x'),(AgentNode('a',NodeKind.ACTION,'a'),))
    env=CollectiveEnvelope.from_program(p, contributor_id='u', benchmark={'quality':1.0,'cost_usd':1e-6,'latency_ms':1.0}, verifier_digest='v')
    bad = CollectiveEnvelope(env.capability_id, 'tampered', env.contract, env.benchmark, env.verifier_digest, env.lineage, env.contributor_id, env.privacy_mode, env.program_nodes)
    r=CollectiveRegistry()
    assert not r.verify_and_promote(bad, lambda e: e.program_digest == p.digest)


def test_contribution_receipt_is_content_addressed():
    p=AgentProgram(ProgramContract('x'),(AgentNode('a',NodeKind.ACTION,'a'),))
    env=CollectiveEnvelope.from_program(p, contributor_id='u', benchmark={'quality':1.0}, verifier_digest='v')
    receipt=contribution_receipt('u', env, prior_quality=.8, reuse_count=3, verified=True)
    assert receipt.improvement > 0 and len(receipt.digest()) == 64
