from mosaic_omega.network.routing import CapabilityRouter, RouteCandidate


def test_gpu_is_last_resort_without_strong_margin():
    r = CapabilityRouter(gpu_margin=0.25)
    plan = r.choose([
        RouteCandidate('cpu', 'c', 1.0, 10, 0.001, 1, 1.0, False),
        RouteCandidate('gpu', 'g', 1.0, 8, 0.002, 50, 1.0, True),
    ])
    assert plan.selected.provider_id == 'c'


def test_gpu_can_win_when_strictly_better():
    r = CapabilityRouter(gpu_margin=0.25)
    plan = r.choose([
        RouteCandidate('cpu', 'c', 1.0, 100, 0.01, 20, 0.0, False),
        RouteCandidate('gpu', 'g', 1.0, 2, 0.001, 20, 0.0, True),
    ])
    assert plan.selected.provider_id == 'g'
