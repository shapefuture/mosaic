from mosaic_omega.ecu.core import ECUAction, ECUContract, ExecutableComputeUnit, ECUEnvironment
from mosaic_omega.runtime.router import ExecutionRouter


def test_router_prefers_verified_ecu():
    def h(env, **kwargs):
        env.state["ok"] = True
    ecu = ExecutableComputeUnit(ECUContract("x", max_steps=1), (ECUAction("compile"),), {"mean_cost_usd": 0.0, "mean_latency_ms": 0.1})
    d, result = ExecutionRouter([ecu]).execute(("compile",), ECUEnvironment({}, {"compile": h}))
    assert d.mode == "ecu"
    assert result is not None and result.success
