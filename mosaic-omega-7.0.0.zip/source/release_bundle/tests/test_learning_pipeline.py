from mosaic_omega.learning.pipeline import train_from_trajectories
from mosaic_omega.data.frontier import TRAINING_MANIFESTS
from mosaic_omega.trajectory.events import Trajectory, TrajectoryEvent


def test_training_pipeline_produces_reusable_units():
    ts = []
    for i in range(6):
        ts.append(
            Trajectory(
                f"r{i}",
                tuple(
                    TrajectoryEvent(j, "tool_call", a, ok=True, state_hash=f"s{j}")
                    for j, a in enumerate(["open_file", "apply_patch", "run_tests"])
                ),
            )
        )
    units, policy, motifs, report = train_from_trajectories(
        ts, TRAINING_MANIFESTS[0], min_support=3, max_len=3
    )
    assert report.trajectories == 6
    assert report.states >= 1
    assert motifs
    assert units
    assert policy.recommend("s0", ("open_file",)) is not None
