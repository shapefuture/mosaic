from mosaic_omega.gauntlets.maximal import run_maximal_gauntlet


def test_maximal_gauntlet_passes():
    report = run_maximal_gauntlet()
    assert report.all_checks_passed
    assert report.leakage_groups == 0
    assert report.accepted_units >= 1
    assert report.verified_units >= 1
    assert report.frontier_call_reduction >= 0.99
    assert report.planning_compression >= 0.5
    assert report.replay_prefix_reuse >= 0.5
    assert report.regressions == 0
