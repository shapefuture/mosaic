import json
from pathlib import Path
from mosaic_omega.data.trajectory_formats import iter_trajectory_file


def test_atif_and_otel_ingestion(tmp_path: Path):
    atif=tmp_path/'a.json'; atif.write_text(json.dumps({'trajectory_id':'t','steps':[{'type':'tool_call','tool_call':{'name':'search','arguments':'{"q":"x"}'},'ok':True},{'type':'verify','result':'ok','ok':True}]}))
    otel=tmp_path/'o.json'; otel.write_text(json.dumps({'spans':[{'traceId':'t2','name':'search','attributes':{'span.type':'tool','tool.name':'search'},'status':{'code':'OK'}},{'traceId':'t2','name':'verify','attributes':{},'status':{'code':'OK'}}]}))
    a=list(iter_trajectory_file(atif)); o=list(iter_trajectory_file(otel))
    assert a[0].run_id=='t' and a[0].events[0].action=='search'
    assert o[0].run_id=='t2' and len(o[0].events)==2


def test_jsonl_frontier_rows(tmp_path: Path):
    path = tmp_path / "frontier.jsonl"
    rows = [
        {"source_trajectory_id": "g1", "messages": [{"role": "tool", "content": "ok"}]},
        {"metadata": {"instance_id": "o1"}, "messages": [{"role": "assistant", "content": "x"}]},
    ]
    path.write_text("\n".join(json.dumps(r) for r in rows) + "\n")
    traces = list(iter_trajectory_file(path))
    assert [t.run_id for t in traces] == ["g1", "o1"]
    assert all(tr.events for tr in traces)


def test_swe_bench_ingests_reasoning_signals_without_executable_thought_text():
    from mosaic_omega.data.trajectory_formats import from_swe_bench_expanded
    obj = [{"instance_id":"r1","repo":"r","ground_truth":{"trajectory":[{"turn":1,"thought":"I suspect the parser fails because the regex is case-sensitive; I will inspect qdp.py and expect the fix to make lowercase commands pass.","tool_calls":[{"name":"grep","arguments":{"pattern":"qdp"}}]}]}}]
    t = list(from_swe_bench_expanded(obj))[0]
    m=t.events[0].metadata
    assert m.get("reasoning_signals")
    assert "case-sensitive" in m["reasoning_signals"]["hypothesis"] or m["reasoning_signals"]["hypothesis"]
    assert "I suspect" not in t.events[0].observation


def test_swe_bench_raw_reasoning_is_explicit_opt_in():
    from mosaic_omega.data.trajectory_formats import from_swe_bench_expanded
    obj = [{"instance_id":"r2","repo":"r","ground_truth":{"trajectory":[{"turn":1,"thought":"PUBLIC_REASONING","tool_calls":[{"name":"grep","arguments":{}}]}]}}]
    t = list(from_swe_bench_expanded(obj, retain_raw_reasoning=True))[0]
    assert t.events[0].metadata["raw_reasoning"] == "PUBLIC_REASONING"


def test_atif_reasoning_signals_are_ingested_without_raw_text():
    import json
    from mosaic_omega.data.trajectory_formats import from_atif
    obj={"trajectory_id":"a","steps":[{"type":"tool_call","thought":"I suspect the cache is stale because the state hash changed; inspect the file.","tool_call":{"name":"read","arguments":{}},"ok":True}]}
    t=list(from_atif(obj))[0]
    assert t.events[0].metadata["reasoning_signals"]
    assert "I suspect" not in t.events[0].observation
