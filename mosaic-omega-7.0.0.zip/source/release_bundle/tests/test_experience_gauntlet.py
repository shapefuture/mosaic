from mosaic_omega.gauntlets.experience import run_experience_gauntlet

def test_experience_gauntlet_runs_over_4_trajectories():
    r=run_experience_gauntlet(trajectories=24)
    assert r.status == "PASS"
    assert r.trajectories == 24
    assert r.reasoning_bearing > 0 and r.execution_only > 0
    assert r.candidate_patches > 0 and r.promoted_patches > 0
    assert r.causal_edges > 0 and r.retrieval_hits > 0
