from mosaic_omega.capability import ProofCarryingCapability, CapabilityPatch

def test_pcc_digest_stable():
    p=ProofCarryingCapability('x','y',('a',),('b',),'i','v')
    assert len(p.digest)==64
    assert p.to_dict()['digest']==p.digest

def test_capability_patch_score():
    p=CapabilityPatch('a','b',quality_delta=.5,cost_delta_usd=-.1,latency_delta_ms=-10)
    assert p.improvement>0
