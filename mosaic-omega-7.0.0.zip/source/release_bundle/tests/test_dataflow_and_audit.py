from mosaic_omega.runtime.dataflow import DataflowNode, DataflowPlanner
from mosaic_omega.ecu.core import ECUAction, ECUContract, ECUEnvironment, ExecutableComputeUnit
from mosaic_omega.learning.audit import audit_skill_paired
from mosaic_omega.learning.synthesis import compose_verified_units


def test_parallel_dataflow_waves():
    env=ECUEnvironment({'a':0,'b':0}, {'a':lambda e: e.state.__setitem__('a',1), 'b':lambda e:e.state.__setitem__('b',2), 'c':lambda e:e.state.__setitem__('c',e.state['a']+e.state['b'])})
    p=DataflowPlanner([
        DataflowNode('a',ECUAction('a'),(),estimated_latency_ms=10),
        DataflowNode('b',ECUAction('b'),(),estimated_latency_ms=10),
        DataflowNode('c',ECUAction('c'),('a','b'),estimated_latency_ms=5),
    ])
    r=p.execute(env)
    assert r.success and r.parallel_waves == (('a','b'),('c',)) and env.state['c']==3
    assert r.critical_path_ms == 15


def test_paired_audit_accepts_repair_without_regression():
    def make(): return ECUEnvironment({'x':0},{'inc':lambda e:e.state.__setitem__('x',1)})
    unit=ExecutableComputeUnit(ECUContract('u'),[ECUAction('inc')])
    audit=audit_skill_paired([unit],[(make,lambda e:e.state['x']==1,('inc',))])
    assert audit.accepted and audit.repairs==1 and audit.regressions==0


def test_synthetic_composition():
    def inc(env,**kw): env.state['x']=env.state.get('x',0)+1
    u1=ExecutableComputeUnit(ECUContract('a'),[ECUAction('inc')],{'k':'a'})
    u2=ExecutableComputeUnit(ECUContract('b'),[ECUAction('inc')],{'k':'b'})
    cases=compose_verified_units([u1,u2], lambda:ECUEnvironment({'x':0},{'inc':inc}), lambda env,c: env.state['x']==len(c))
    assert len(cases)==3
