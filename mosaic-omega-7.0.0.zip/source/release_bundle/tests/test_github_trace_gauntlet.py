from mosaic_omega.gauntlets.github_trace import run_github_trace_gauntlet


def test_github_trace_gauntlet_passes():
    report = run_github_trace_gauntlet()
    assert report.all_checks_passed
    assert report.source_verified
    assert report.model_calls == 135
    assert report.recorded_passed == 40
    assert report.recorded_total == 54
    assert report.recovery_rules >= 3
    assert report.compiled_recovery_units >= 3
    assert report.frontier_calls_on_recovery_hotpath == 0
    assert not report.hidden_reasoning_ingested
