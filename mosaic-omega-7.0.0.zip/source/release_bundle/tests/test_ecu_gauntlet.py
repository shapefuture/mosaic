from mosaic_omega.ecu.gauntlet import run_ecu_gauntlet

def test_ecu_gauntlet():
    r=run_ecu_gauntlet()
    assert r.all_checks_passed
    assert r.units >= 2
    assert r.reuse_amortization >= 0.5
    assert r.sealed_training_blocked
