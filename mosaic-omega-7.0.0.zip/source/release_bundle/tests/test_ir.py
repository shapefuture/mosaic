from mosaic_omega.ir.nodes import Add, Const, Input, Mul
from mosaic_omega.ir.program import Program


def test_program_digest_is_stable():
    a = Program("p", Add(Mul(Const(2), Input()), Const(1)))
    b = Program("p", Add(Mul(Const(2), Input()), Const(1)))
    assert a.digest == b.digest
    assert len(a.digest) == 64
