from mosaic_omega.data.git_sources import GIT_ADDRESSABLE_SOURCES, manifest_digest
from mosaic_omega.data.trajectory_formats import from_swe_bench_expanded
from mosaic_omega.learning.recovery_program import compile_cross_source_recovery
from mosaic_omega.trajectory.events import Trajectory, TrajectoryEvent


def test_registry_contains_multiple_real_git_payloads():
    raw = [s for s in GIT_ADDRESSABLE_SOURCES if s.status == "verified" and s.bytes > 100000]
    assert len(raw) >= 4
    assert len({s.repository for s in raw}) >= 3
    assert all(len(s.blob_sha) == 40 for s in raw)
    assert manifest_digest()


def test_swe_bench_import_uses_reasoning_signals_and_preserves_tools():
    obj = [{"instance_id":"x", "repo":"r", "ground_truth":{"trajectory":[{"turn":1,"thought":"SECRET", "tool_calls":[{"name":"grep","arguments":{"pattern":"foo"}}]}], "answer":[{"file":"x.py"}]}}]
    t = list(from_swe_bench_expanded(obj))[0]
    assert len(t.events) == 2
    assert all("SECRET" not in e.observation for e in t.events)
    assert t.events[0].metadata.get("reasoning_signals") is not None
    assert t.events[0].action == "grep" and t.events[-1].kind == "verify"


def test_cross_source_recovery_requires_support_across_runs():
    a = Trajectory("a", (TrajectoryEvent(0,"error","syntax_error",ok=False,metadata={"error_signature":"syntax_error"}),TrajectoryEvent(1,"tool_call","write",ok=True),TrajectoryEvent(2,"tool_call","bash",ok=True)))
    b = Trajectory("b", (TrajectoryEvent(0,"error","syntax_error",ok=False,metadata={"error_signature":"syntax_error"}),TrajectoryEvent(1,"tool_call","write",ok=True),TrajectoryEvent(2,"tool_call","bash",ok=True)))
    p = compile_cross_source_recovery([a,b], max_actions=2, min_support=2)
    assert p and p[0].support == 2 and p[0].actions[0].name == "write"
