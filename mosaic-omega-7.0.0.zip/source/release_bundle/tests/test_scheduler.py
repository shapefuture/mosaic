from mosaic_omega.runtime.cost import CostPoint
from mosaic_omega.runtime.scheduler import BackendOffer, LastResortGPUScheduler


def test_gpu_is_last_resort():
    cpu = BackendOffer("cpu", "cpu", True, 10.0, 0.0, CostPoint(0.30, 75))
    gpu = BackendOffer("gpu", "gpu", True, 8.0, 20.0, CostPoint(1.50, 250))
    assert LastResortGPUScheduler().choose([gpu, cpu]).name == "cpu"
