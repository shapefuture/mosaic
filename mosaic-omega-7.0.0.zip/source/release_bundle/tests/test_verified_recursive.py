from mosaic_omega.omega.recursive import DecompositionVerifier, RecursiveUnit
from mosaic_omega.gauntlets.verified_recursive import run_verified_recursive_gauntlet


def test_decomposition_verifier_rejects_lost_obligation():
    parent = RecursiveUnit("p", "abcdef", postconditions=("a", "b"))
    child = RecursiveUnit("c", "a", postconditions=("a",), executor_key="c", verifier_key="c")
    result = DecompositionVerifier().assess(parent, [child])
    assert not result.accepted
    assert "lost_obligation" in result.reasons


def test_verified_recursive_gauntlet():
    report = run_verified_recursive_gauntlet(rounds=2, tasks=4)
    assert report.all_checks_passed
    assert report.verified == report.tasks
    assert report.cost_reduction >= 0.90
    assert report.frontier_call_reduction == 1.0
    assert report.verifier_attack_survived
