import pytest
from mosaic_omega.backends.native import NativeCPUBackend
from mosaic_omega.ir.nodes import Add, Const, Input, Mul
from mosaic_omega.ir.program import Program
from mosaic_omega.model import Candidate, ComputeSpec, Genome


def test_native_repeated_matches_single_run():
    b = NativeCPUBackend()
    if not b.capabilities.available:
        pytest.skip("no native compiler")
    p = Program("p", Add(Mul(Const(2.0), Input()), Const(1.0)))
    c = Candidate(ComputeSpec("p", "elementwise", 32), Genome(tile=4, unroll=4, vector_width=4))
    a = b.compile(p, c)
    x = [float(i) for i in range(32)]
    assert b.run_repeated(a, x, 3) == b.run(a, x)
    b.close()
