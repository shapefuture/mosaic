from mosaic_omega.experience import ExperienceCompiler
from mosaic_omega.trajectory.events import Trajectory, TrajectoryEvent

def _traj(run, reasoning=True):
    ev=[]
    if reasoning:
        ev.append(TrajectoryEvent(1,'reasoning','',metadata={'reasoning_signals':{'goal':'fix timeout','hypothesis':'optimize bottleneck','decision':'rewrite loop'}}))
    ev += [TrajectoryEvent(2,'tool','inspect',ok=True),TrajectoryEvent(3,'tool','run',ok=False,observation='timeout'),TrajectoryEvent(4,'tool','repair',ok=True),TrajectoryEvent(5,'verify','test',ok=True)]
    return Trajectory(run,tuple(ev))

def test_evidence_compiler_uses_more_than_four_trajectories():
    traces=[_traj(f'r{i}',reasoning=(i%2==0)) for i in range(12)]
    c,r=ExperienceCompiler().mine(traces)
    assert r.trajectories==12 and r.reasoning_events and r.execution_events and r.outcome_events
    assert r.causal_edges and r.candidate_patches and r.promoted_patches

def test_negative_evidence_is_not_promoted():
    t=Trajectory('bad',(TrajectoryEvent(1,'tool','inspect',ok=False),TrajectoryEvent(2,'tool','bad',ok=False)))
    c,r=ExperienceCompiler().mine([t,t])
    assert r.promoted_patches==0
