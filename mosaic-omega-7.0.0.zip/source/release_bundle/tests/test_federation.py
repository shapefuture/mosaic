from mosaic_omega.federation.exchange import CandidateEnvelope, candidate_from_envelope
from mosaic_omega.model import Candidate, ComputeSpec, Genome
from mosaic_omega.security.provenance import attest, make_manifest


def test_round_trip_candidate_envelope():
    c = Candidate(ComputeSpec("x", "noop", 4), Genome(tile=4), source="node-a")
    att = attest(make_manifest(c, "digest"), b"k")
    e = CandidateEnvelope.from_candidate(c, att)
    c2 = candidate_from_envelope(e)
    assert c2.spec.name == c.spec.name
    assert c2.genome == c.genome
    assert c2.spec.target == c.spec.target
