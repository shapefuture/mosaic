from mosaic_omega.learning.trajectory_compiler import compile_trajectory
from mosaic_omega.trajectory.events import Trajectory, TrajectoryEvent


def test_compile_trajectory_compiles_deterministic_core():
    t = Trajectory("r1", (
        TrajectoryEvent(0, "tool_call", "prepare", '{"x": 1}', state_hash="s0", ok=True, latency_ms=5),
        TrajectoryEvent(1, "tool_call", "execute", '{"mode":"fast"}', state_hash="s1", ok=True, latency_ms=5),
        TrajectoryEvent(2, "verify", "verify", "", state_hash="s2", ok=True, metadata={"verify_status":"resolved"}),
    ))
    c = compile_trajectory(t, "manifest")
    assert c is not None
    assert c.compiled_steps == 3
    assert c.frontier_nodes == 0
    assert c.confidence == 1.0
    assert c.ecu.actions[0].args["x"] == 1



def test_reasoning_signals_flow_into_compiled_context():
    from mosaic_omega.trajectory.events import Trajectory, TrajectoryEvent
    from mosaic_omega.learning.trajectory_compiler import compile_trajectory
    t = Trajectory("reason", (TrajectoryEvent(0, "tool_call", "prepare", "ok", ok=True, metadata={"reasoning_signals": {"hypothesis": "parser is case-sensitive", "decision": "inspect parser"}}), TrajectoryEvent(1, "verify", "verify", "ok", ok=True)))
    c = compile_trajectory(t, "m", min_confidence=0.0)
    assert c is not None
    assert c.ecu.provenance["reasoning_signal_nodes"] == 1
