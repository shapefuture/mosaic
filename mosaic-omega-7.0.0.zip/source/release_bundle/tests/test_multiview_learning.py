from pathlib import Path
import json

from mosaic_omega.data.github_trace_sample import SAMPLE
from mosaic_omega.data.github_trajectories import records_to_trajectory
from mosaic_omega.data.trajectory_formats import from_atif
from mosaic_omega.learning.multiview import train_multiview


def _reasoning_trajs():
    # Six independent, reasoning-bearing trajectories + ten observable
    # GitHub-derived execution traces. The reasoning lines are separately
    # evaluated; execution-only training does not get the reasoning fields.
    out = []
    templates = [
        ("parser is case sensitive", "inspect parser", "read"),
        ("timeout is caused by slow solver", "optimize solver", "write"),
        ("dependency is unavailable", "remove dependency", "edit"),
        ("mask handling loses None", "inspect mask propagation", "read"),
        ("caller expects new signature", "update caller", "edit"),
        ("tests cover the changed invariant", "run targeted tests", "bash"),
    ]
    n = 0
    for rep in range(3):
        for i, (hyp, dec, tool) in enumerate(templates):
            obj = {"trajectory_id": f"reason-{i}-{rep}", "steps": [
                {"turn": 1, "type": "reasoning", "thought": f"Hypothesis: {hyp}. Decision: {dec}.", "metadata": {"teacher_model": "public-test"}},
                {"turn": 2, "type": "tool_call", "action": tool, "observation": "{}", "ok": True},
                {"turn": 3, "type": "verify", "action": "run_tests", "observation": "passed", "ok": True},
            ]}
            out.extend(from_atif(obj))
            n += 1
    return out


def test_three_parallel_learning_lines_on_more_than_four_trajectories():
    actual = [records_to_trajectory([r], run_id=f"haiku-{r['seq']}") for r in SAMPLE]
    traces = _reasoning_trajs() + actual
    assert len(traces) == 28
    report = train_multiview(traces, holdout_fraction=0.25)
    assert report.trajectories == 28
    assert report.reasoning.examples > 0
    assert report.execution.examples > 0
    assert report.joint.examples > 0
    assert report.reasoning.name == "reasoning-only"
    assert report.execution.name == "execution-only"
    assert report.joint.name == "joint"
    assert report.fused.name == "fused"


def test_reasoning_execution_joint_are_individually_non_empty_and_fusion_compares_them():
    traces = _reasoning_trajs() + [records_to_trajectory([r], run_id=f"haiku-{r['seq']}") for r in SAMPLE]
    report = train_multiview(traces, holdout_fraction=0.25)
    assert report.reasoning.rules > 0
    assert report.execution.rules > 0
    assert report.joint.rules > 0
    assert 0.0 <= report.reasoning.coverage <= 1.0
    assert 0.0 <= report.execution.coverage <= 1.0
    assert 0.0 <= report.joint.coverage <= 1.0
    assert 0.0 <= report.fused.coverage <= 1.0


def test_execution_only_can_run_without_reasoning_channel():
    actual = [records_to_trajectory([r], run_id=f"haiku-{r['seq']}") for r in SAMPLE]
    assert len(actual) == 10
    report = train_multiview(actual + actual, holdout_fraction=0.25)
    assert report.execution.rules > 0
    assert report.reasoning.rules == 0
    assert report.joint.rules == 0
