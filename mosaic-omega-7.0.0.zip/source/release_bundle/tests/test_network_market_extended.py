from mosaic_omega.capability.pcc import ProofCarryingCapability
from mosaic_omega.network.market import (
    CapabilityRegistry, CapabilityOffer, CapabilityQuery, NodeProfile, NodeRoles,
    ReplicationPolicy, Challenge,
)


def cap():
    return ProofCarryingCapability('r', 'repair', ('error',), ('pass',), 'impl', 'ver', cost_usd=.001, latency_ms=5)


def offer(pid='n'):
    return CapabilityOffer(cap(), pid, 'repair', locality='same', verification_level=3, expected_reuse=100, future_savings_usd=10, cost_usd=.001, latency_ms=5, quality=1.0)


def test_challenge_revokes_capability():
    r=CapabilityRegistry(); r.register_node(NodeProfile('n', frozenset({NodeRoles.EXECUTOR}), locality='same', trust=.9))
    d=r.publish(offer())
    r.propose_challenge(Challenge('c', d, 'challenger', 'exploit', 'e'))
    result=r.challenge('c', exploit_found=True)
    assert result.valid and not r.query(CapabilityQuery('repair'))


def test_adaptive_replication_increases_for_novel_or_risky():
    p=ReplicationPolicy()
    assert p.replicas(trust=.95, novelty=.9, risk=.0, mature=False) == 3
    assert p.replicas(trust=.95, novelty=.0, risk=.9, mature=True) == 3


def test_locality_query_filters():
    r=CapabilityRegistry(); r.register_node(NodeProfile('n', frozenset({NodeRoles.EXECUTOR}), locality='same', trust=.9))
    r.publish(offer())
    assert r.query(CapabilityQuery('repair', locality='remote')) == []
