from mosaic_omega.replay import ReplayStore


def test_prefix_sharing(tmp_path):
    store = ReplayStore(tmp_path)
    assert store.intern_prefix(["a", "b"], "s1") == "s1"
    assert store.intern_prefix(["a", "b"], "s2") == "s1"
    stats = store.prefix_stats()
    assert stats["prefixes"] == 1
