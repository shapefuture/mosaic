from mosaic_omega.ecu import ECUAction, ECUContract, ExecutableComputeUnit

def test_ecu_digest_changes_with_behavior():
    a=ExecutableComputeUnit(ECUContract("x"),[ECUAction("a")],{"source":"s"})
    b=ExecutableComputeUnit(ECUContract("x"),[ECUAction("b")],{"source":"s"})
    assert a.digest != b.digest

def test_ecu_roundtrip():
    a=ExecutableComputeUnit(ECUContract("x",tags=("t",)),[ECUAction("a",{"x":1})],{"source":"s"})
    b=ExecutableComputeUnit.from_dict(a.to_dict())
    assert a.digest == b.digest
