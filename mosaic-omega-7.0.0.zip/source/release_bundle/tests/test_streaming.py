from mosaic_omega.learning.streaming import train_streaming
from mosaic_omega.data.frontier import TRAINING_MANIFESTS
from mosaic_omega.trajectory.events import Trajectory, TrajectoryEvent


def test_streaming_trainer_is_bounded_and_compiles():
    def gen():
        for i in range(32):
            yield Trajectory(f"r{i}", (
                TrajectoryEvent(0, "tool_call", "inspect", state_hash="s0", ok=True),
                TrajectoryEvent(1, "tool_call", "patch", state_hash="s1", ok=True),
                TrajectoryEvent(2, "verify", "tests", state_hash="s2", ok=True, metadata={"verify_status": "resolved"}),
            ))
    units, stats = train_streaming(gen(), TRAINING_MANIFESTS[0], min_support=8, max_len=3, max_patterns=128)
    assert stats.peak_buffer == 1
    assert stats.trajectories_seen == 32
    assert units
    assert stats.holdout_success_rate == 1.0
