import json
from mosaic_omega.learning.procedures import mine_procedures, compile_procedures, delta_debug_sequence
from mosaic_omega.learning.offline_rl import OfflineTrajectoryQLearner
from mosaic_omega.trajectory.events import Trajectory, TrajectoryEvent


def _t(rid, good=True):
    return Trajectory(rid, (
        TrajectoryEvent(0,'tool','open',observation='{"path":"a.py"}',state_hash='s0',ok=True),
        TrajectoryEvent(1,'tool','patch',observation='{"file":"a.py","op":"fix"}',state_hash='s1',ok=True),
        TrajectoryEvent(2,'verify','tests',state_hash='s2',ok=good,metadata={'verify_status':'resolved' if good else 'unresolved'}),
    ))


def test_argument_aware_procedure_and_q_learning():
    ps=mine_procedures([_t(f'r{i}') for i in range(5)],min_support=3,max_len=3)
    units=compile_procedures(ps,'m')
    assert units
    assert any(a.args for u in units for a in u.actions)
    q=OfflineTrajectoryQLearner().fit([_t(f'r{i}') for i in range(5)])
    assert q.q


def test_delta_debugging_reduces_redundant_steps():
    t=_t('x')
    def score(events):
        names=[e.action for e in events]
        return 1.0 if 'patch' in names and 'tests' in names else 0.0
    r=delta_debug_sequence(t,score,minimum_score=1.0)
    assert r.removed_steps >= 1
