import pytest
from mosaic_omega.eval.reference import eval_node
from mosaic_omega.ir.nodes import Node


class Unknown(Node):
    op = "unknown"


def test_unknown_ir_is_rejected():
    with pytest.raises(TypeError):
        eval_node(Unknown(), [1.0])
