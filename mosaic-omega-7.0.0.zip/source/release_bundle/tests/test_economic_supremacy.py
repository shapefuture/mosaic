from mosaic_omega.runtime.cost import CostPoint, UtilityWeights, quality_speed_per_dollar_latency
from mosaic_omega.runtime.scheduler import BackendOffer, LastResortGPUScheduler


def test_non_gpu_wins_across_diverse_offer_pool():
    offers = [
        BackendOffer("python", "cpu", True, 4.5, 0.0, CostPoint(0.30, 75)),
        BackendOffer("llvm", "cpu", True, 1.8, 0.2, CostPoint(0.30, 75)),
        BackendOffer("remote-cpu", "remote_cpu", True, 2.4, 0.8, CostPoint(0.08, 40)),
        BackendOffer("npu", "npu", True, 1.4, 1.0, CostPoint(0.20, 60)),
        BackendOffer("gpu", "gpu", True, 1.1, 25.0, CostPoint(1.70, 280)),
        BackendOffer("frontier-gpu", "gpu", True, 0.9, 80.0, CostPoint(4.50, 420)),
    ]
    chosen = LastResortGPUScheduler(UtilityWeights()).choose(offers)
    assert chosen.device_class != "gpu"
    assert chosen.name in {"llvm", "remote-cpu", "npu"}


def test_gpu_is_used_when_non_gpu_cannot_meet_hard_latency():
    offers = [
        BackendOffer("cpu", "cpu", True, 900.0, 0.0, CostPoint(0.30, 75)),
        BackendOffer("gpu", "gpu", True, 90.0, 10.0, CostPoint(1.00, 250)),
    ]
    chosen = LastResortGPUScheduler().choose(offers, max_latency_ms=200.0)
    assert chosen.device_class == "gpu"


def test_composite_objective_rewards_quality_and_useful_work_density():
    a = quality_speed_per_dollar_latency(
        quality=0.99, work_units=1000, latency_ms=10, cost_usd=0.002, energy_j=5
    )
    b = quality_speed_per_dollar_latency(
        quality=0.90, work_units=1000, latency_ms=5, cost_usd=0.01, energy_j=5
    )
    assert a > b
