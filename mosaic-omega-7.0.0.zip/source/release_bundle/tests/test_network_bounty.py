from mosaic_omega.network.market import CapabilityBounty, CapabilityFutures

def test_bounty_and_futures():
    b=CapabilityBounty('b1','repair','reduce cost',10.0)
    f=CapabilityFutures(1000,0.01,0.99,0.01)
    assert b.reward_usd == 10.0
    assert f.expected_value_usd > 5
