from mosaic_omega.compiler.search_space import SearchSpaceCompiler
from mosaic_omega.model import ComputeSpec


def test_search_space_respects_constraints():
    spec = ComputeSpec("x", "elementwise", 8, constraints={"tile": (2, 4), "vector_width": (1, 2)})
    space = SearchSpaceCompiler().compile(spec)
    assert space.size() == 3 * 16 * 2 * 8 * 8
    assert all(g.tile in (2, 3, 4) for g in space.candidates())
