from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Mapping, Any

@dataclass(frozen=True)
class RecordedBenchmark:
    benchmark: str
    tasks: int
    source_url: str
    as_of: str
    model_scores: Mapping[str, float]
    notes: str = ""

    @property
    def best_model(self) -> str:
        return max(self.model_scores, key=self.model_scores.get)

    @property
    def best_score(self) -> float:
        return float(self.model_scores[self.best_model])

    def as_dict(self) -> dict[str, Any]:
        return asdict(self) | {
            "best_model": self.best_model,
            "best_score": self.best_score,
        }

# Real published aggregate outcomes reproduced from the GitHub-hosted
# inspect_evals CTI-REALM README. These are benchmark measurements, not
# synthetic MOSAIC fixtures and not raw trajectory logs.
CTI_REALM_50_JUNE_2026 = RecordedBenchmark(
    benchmark="CTI-REALM-50",
    tasks=50,
    source_url="https://github.com/UKGovernmentBEIS/inspect_evals/blob/main/src/inspect_evals/cti_realm/README.md",
    as_of="2026-06-10",
    model_scores={
        "claude-opus-4-6": 0.6373,
        "claude-opus-4-5": 0.6244,
        "claude-sonnet-4-5": 0.5872,
        "gpt-5-2025-03-01-preview-medium": 0.5720,
        "gpt-5.2-2025-03-01-preview-medium": 0.5716,
        "gpt-5-2025-03-01-preview-high": 0.5633,
        "gpt-5.2-2025-03-01-preview-high": 0.5513,
        "gpt-5-2025-03-01-preview-low": 0.5413,
        "gpt-5.1-2025-03-01-preview-medium": 0.5133,
        "gpt-5.1-2025-03-01-preview-high": 0.4946,
        "gpt-5.2-2025-03-01-preview-low": 0.4898,
        "o3-2025-03-01-preview": 0.4707,
        "gpt-5-mini-2025-03-01-preview": 0.4506,
        "gpt-4.1-2025-03-01-preview": 0.4186,
        "gpt-5.1-2025-03-01-preview-low": 0.3731,
        "o4-mini-2025-03-01-preview": 0.3602,
    },
    notes=(
        "Published CTI-REALM-50 aggregate rewards. Scoring combines trajectory checkpoints "
        "and ground-truth detection quality; do not equate these aggregate outcomes with raw traces."
    ),
)

@dataclass(frozen=True)
class GitHubTaskEvidence:
    benchmark: str
    task_id: str
    task_url: str
    verifier_url: str
    groundtruth_url: str | None
    evidence_kind: str  # task_definition | verifier | groundtruth
    source_revision: str
    notes: str = ""

TOOLATHLON_FIND_ALITA = GitHubTaskEvidence(
    benchmark="Toolathlon-Verified",
    task_id="find-alita-paper",
    task_url="https://github.com/hkust-nlp/Toolathlon/tree/main/tasks/finalpool/find-alita-paper",
    verifier_url="https://github.com/hkust-nlp/Toolathlon/blob/main/tasks/finalpool/find-alita-paper/evaluation/main.py",
    groundtruth_url="https://github.com/hkust-nlp/Toolathlon/blob/main/tasks/finalpool/find-alita-paper/groundtruth_workspace/gt_alita_2505.20286v1.pdf",
    evidence_kind="task_definition+verifier+groundtruth",
    source_revision="main",
    notes=(
        "Task specification, evaluator, and expected PDF are committed in GitHub. "
        "The model trajectory itself is not committed in this repository."
    ),
)

def compare_recorded_score(benchmark: RecordedBenchmark, mosaic_score: float, mosaic_tasks: int) -> dict[str, Any]:
    comparable = mosaic_tasks == benchmark.tasks
    gap = float(mosaic_score - benchmark.best_score)
    return {
        "benchmark": benchmark.benchmark,
        "tasks": benchmark.tasks,
        "mosaic_tasks": mosaic_tasks,
        "comparable": comparable,
        "best_model": benchmark.best_model,
        "best_recorded_score": benchmark.best_score,
        "mosaic_score": float(mosaic_score),
        "gap_to_best_recorded": gap,
        "superior_quality": comparable and gap >= 0,
        "source_url": benchmark.source_url,
        "as_of": benchmark.as_of,
        "notes": benchmark.notes,
    }
