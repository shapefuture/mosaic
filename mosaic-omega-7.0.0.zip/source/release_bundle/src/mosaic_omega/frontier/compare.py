from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import json
from statistics import mean
from typing import Any, Iterable, Mapping


@dataclass(frozen=True)
class FrontierSnapshot:
    benchmark: str
    tasks: int
    source_url: str
    as_of: str
    model_scores: Mapping[str, float]
    avg_turns: Mapping[str, float]

    @property
    def best_model(self) -> str:
        return max(self.model_scores, key=self.model_scores.get)

    @property
    def best_score(self) -> float:
        return float(self.model_scores[self.best_model])


# Published Toolathlon-Verified snapshot refreshed 2026-08-21.
# This is an external reference, not a locally executed MOSAIC score.
TOOLATHLON_VERIFIED_AUG_2026 = FrontierSnapshot(
    benchmark="Toolathlon-Verified",
    tasks=108,
    source_url="https://huggingface.co/datasets/hkust-nlp/Toolathlon-Verified_Trajectories",
    as_of="2026-08-21",
    model_scores={
        "Claude Opus 5": 0.806,
        "Kimi K3": 0.765,
        "GPT-5.6 Sol": 0.749,
        "Claude Sonnet 5": 0.747,
        "DeepSeek V4 Pro 0813": 0.741,
        "GLM-5.3": 0.730,
        "Qwen3.8 Max": 0.725,
        "DeepSeek V4 Flash 0731": 0.703,
        "Gemini 3.1 Pro Preview": 0.611,
        "GLM-5.2": 0.599,
    },
    avg_turns={
        "Claude Opus 5": 23.5,
        "Claude Opus 4.8": 20.4,
        "Claude Sonnet 5": 24.5,
        "Claude Mythos 5": 19.8,
    },
)


@dataclass(frozen=True)
class ReplayMetrics:
    model: str
    tasks: int
    successful_tasks: int
    success_rate: float
    frontier_calls: int
    average_turns: float
    latency_ms: float | None = None
    cost_usd: float | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Comparison:
    benchmark: str
    mosaic_success: float
    best_frontier_success: float
    gap_to_frontier: float
    frontier_call_reduction: float
    latency_reduction: float | None
    cost_reduction: float | None
    comparable: bool
    notes: tuple[str, ...]

    @property
    def superior_quality(self) -> bool:
        return self.comparable and self.mosaic_success >= self.best_frontier_success

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def load_replay_metrics(path: str | Path) -> ReplayMetrics:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return ReplayMetrics(
        model=str(data["model"]),
        tasks=int(data["tasks"]),
        successful_tasks=int(data["successful_tasks"]),
        success_rate=float(data["success_rate"]),
        frontier_calls=int(data.get("frontier_calls", 0)),
        average_turns=float(data.get("average_turns", 0.0)),
        latency_ms=(float(data["latency_ms"]) if data.get("latency_ms") is not None else None),
        cost_usd=(float(data["cost_usd"]) if data.get("cost_usd") is not None else None),
    )


def compare_to_published_snapshot(
    snapshot: FrontierSnapshot,
    *,
    mosaic_success: float,
    mosaic_frontier_calls: int,
    mosaic_tasks: int,
    mosaic_latency_ms: float | None = None,
    mosaic_cost_usd: float | None = None,
) -> Comparison:
    notes: list[str] = [
        "Published frontier scores are external reference measurements; MOSAIC must be run on the same task set before claiming benchmark superiority.",
        f"Reference benchmark: {snapshot.benchmark} ({snapshot.tasks} tasks).",
    ]
    comparable = mosaic_tasks == snapshot.tasks
    if not comparable:
        notes.append(f"MOSAIC task count={mosaic_tasks}; published task count={snapshot.tasks}.")
    best = snapshot.best_score
    gap = mosaic_success - best
    call_reduction = 1.0 - (mosaic_frontier_calls / max(1, mosaic_tasks))
    # Latency/cost are only meaningful when the same task set and accounting method are used.
    latency_reduction = None if mosaic_latency_ms is None else None
    cost_reduction = None if mosaic_cost_usd is None else None
    return Comparison(snapshot.benchmark, mosaic_success, best, gap, call_reduction, latency_reduction, cost_reduction, comparable, tuple(notes))


def aggregate_replays(replays: Iterable[ReplayMetrics]) -> ReplayMetrics:
    rows = list(replays)
    if not rows:
        raise ValueError("at least one replay is required")
    tasks = sum(r.tasks for r in rows)
    successes = sum(r.successful_tasks for r in rows)
    turns = mean(r.average_turns for r in rows)
    latency_values = [r.latency_ms for r in rows if r.latency_ms is not None]
    cost_values = [r.cost_usd for r in rows if r.cost_usd is not None]
    return ReplayMetrics(
        model="aggregate",
        tasks=tasks,
        successful_tasks=successes,
        success_rate=successes / max(1, tasks),
        frontier_calls=sum(r.frontier_calls for r in rows),
        average_turns=turns,
        latency_ms=mean(latency_values) if latency_values else None,
        cost_usd=sum(cost_values) if cost_values else None,
    )
