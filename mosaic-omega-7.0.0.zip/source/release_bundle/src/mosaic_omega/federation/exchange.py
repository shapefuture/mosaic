from __future__ import annotations

from dataclasses import dataclass, asdict
import json

from ..model import Candidate, ComputeSpec, Genome
from ..security.provenance import Attestation


@dataclass(frozen=True)
class CandidateEnvelope:
    name: str
    spec: dict
    genome: dict
    attestation: dict

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True)

    @staticmethod
    def from_candidate(candidate: Candidate, attestation: Attestation) -> "CandidateEnvelope":
        return CandidateEnvelope(candidate.source, candidate.spec.canonical(), candidate.genome.canonical(), asdict(attestation))


def candidate_from_envelope(env: CandidateEnvelope) -> Candidate:
    r = env.spec["resource"]
    from ..model import ResourceBudget
    spec = ComputeSpec(
        name=env.spec["name"], op=env.spec["op"], input_size=int(env.spec["input_size"]), dtype=env.spec["dtype"], target=env.spec["target"],
        resource=ResourceBudget(**r), expected=tuple(env.spec["expected"]) if env.spec.get("expected") else None,
        constraints={k: tuple(v) for k, v in env.spec.get("constraints", {}).items()},
    )
    return Candidate(spec, Genome(**env.genome), source=env.name, lineage=("federated-import",))
