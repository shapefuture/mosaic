from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..model import Observation


@dataclass
class OnlineLinearSurrogate:
    learning_rate: float = 0.02
    weights: list[float] = field(default_factory=lambda: [0.0] * 5)
    bias: float = 1.0
    residual_ema: float = 1.0
    count: int = 0

    def predict(self, features: tuple[float, ...]) -> tuple[float, float]:
        if len(features) != len(self.weights):
            raise ValueError("feature dimension mismatch")
        mean = max(0.0, self.bias + sum(w * x for w, x in zip(self.weights, features)))
        uncertainty = max(0.05, self.residual_ema / math.sqrt(max(1, self.count)))
        return mean, uncertainty

    def update(self, observation: Observation) -> None:
        if not observation.correct or not math.isfinite(observation.latency_ms):
            return
        target = observation.latency_ms
        prediction, _ = self.predict(observation.features)
        err = target - prediction
        for i, x in enumerate(observation.features):
            # Squashed features prevent unstable updates for large tile sizes.
            self.weights[i] += self.learning_rate * err * max(-4.0, min(4.0, x)) / 16.0
        self.bias += self.learning_rate * err / 16.0
        self.residual_ema = 0.9 * self.residual_ema + 0.1 * abs(err)
        self.count += 1
