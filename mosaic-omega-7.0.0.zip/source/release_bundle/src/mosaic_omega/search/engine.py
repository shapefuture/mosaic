from __future__ import annotations

from dataclasses import replace
import math
import random

from ..compiler.search_space import SearchSpace
from ..model import Candidate, ComputeSpec, Genome
from .surrogate import OnlineLinearSurrogate


class EvolutionEngine:
    def __init__(self, space: SearchSpace, seed: int = 42, surrogate: OnlineLinearSurrogate | None = None):
        self.space = space
        self.rng = random.Random(seed)
        self.surrogate = surrogate or OnlineLinearSurrogate()
        self._all = tuple(space.candidates())

    def seed_population(self, size: int) -> list[Genome]:
        if size < 1:
            raise ValueError("population size must be positive")
        if size >= len(self._all):
            return list(self._all)
        # Quasi-uniform random coverage prevents early convergence on one neighborhood.
        return self.rng.sample(list(self._all), size)

    def mutate(self, genome: Genome) -> Genome:
        fields = list(genome.canonical())
        name = self.rng.choice(fields)
        dim = next(d for d in self.space.dimensions if d.name == name)
        values = dim.values()
        current = getattr(genome, name)
        neighbors = [v for v in values if v != current]
        value = self.rng.choice(neighbors) if neighbors else current
        return replace(genome, **{name: value})

    def _predicted_cost(self, g: Genome, hourly_usd: float = 0.30) -> float:
        features = tuple(float(getattr(g, d.name)) for d in self.space.dimensions)
        latency, uncertainty = self.surrogate.predict(features)
        # UCB-style exploration, with cost converting predicted time into USD.
        optimistic_ms = max(0.001, latency - 0.75 * uncertainty)
        return hourly_usd * optimistic_ms / 3_600_000.0 + optimistic_ms

    def propose(self, spec: ComputeSpec, population: list[Genome], budget: int) -> list[Candidate]:
        if budget < 1:
            return []
        seeds = population or list(self._all)
        unique: dict[str, Candidate] = {}
        ranked = sorted(seeds, key=self._predicted_cost)
        for genome in ranked[: max(1, budget // 2)]:
            unique[Candidate(spec, genome, lineage=("surrogate-exploit",)).genome_id] = Candidate(spec, genome, lineage=("surrogate-exploit",))
        attempts = 0
        while len(unique) < budget and attempts < budget * 30:
            attempts += 1
            base = self.rng.choice(seeds)
            genome = self.mutate(base)
            c = Candidate(spec, genome, lineage=("evolutionary-mutation",))
            unique[c.genome_id] = c
        while len(unique) < budget:
            genome = self.rng.choice(self._all)
            c = Candidate(spec, genome, lineage=("diversity",))
            unique[c.genome_id] = c
        return list(unique.values())[:budget]
