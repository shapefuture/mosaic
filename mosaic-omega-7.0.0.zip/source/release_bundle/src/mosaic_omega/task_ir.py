from __future__ import annotations

from dataclasses import dataclass, field, asdict
from hashlib import sha256
import json
from typing import Mapping, Sequence

@dataclass(frozen=True)
class TaskIR:
    goal: str
    constraints: tuple[str, ...] = ()
    known_facts: tuple[str, ...] = ()
    unknowns: tuple[str, ...] = ()
    required_state: tuple[str, ...] = ()
    candidate_capabilities: tuple[str, ...] = ()
    verification: tuple[str, ...] = ()
    resource_budget: Mapping[str, float] = field(default_factory=dict)
    security_policy: tuple[str, ...] = ()

    @property
    def digest(self) -> str:
        blob = json.dumps(asdict(self), sort_keys=True, separators=(",", ":"))
        return sha256(blob.encode()).hexdigest()

    def to_dict(self) -> dict:
        out = asdict(self)
        out["digest"] = self.digest
        return out

    @classmethod
    def from_dict(cls, obj: Mapping) -> "TaskIR":
        task = cls(
            goal=str(obj["goal"]),
            constraints=tuple(obj.get("constraints", ())),
            known_facts=tuple(obj.get("known_facts", ())),
            unknowns=tuple(obj.get("unknowns", ())),
            required_state=tuple(obj.get("required_state", ())),
            candidate_capabilities=tuple(obj.get("candidate_capabilities", ())),
            verification=tuple(obj.get("verification", ())),
            resource_budget=dict(obj.get("resource_budget", {})),
            security_policy=tuple(obj.get("security_policy", ())),
        )
        if obj.get("digest") and obj["digest"] != task.digest:
            raise ValueError("TaskIR digest mismatch")
        return task
