from __future__ import annotations

import ctypes
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from .base import BackendCapabilities
from ..ir.codegen import c_expr
from ..model import Candidate


@dataclass(frozen=True)
class GPUCompilerInfo:
    compiler: str
    kind: str


@dataclass
class GPUArtifact:
    directory: Path
    library: ctypes.CDLL


class OptionalGPUBackend:
    """Real CUDA/HIP backend activated only when the target runtime is installed."""

    def __init__(self, kind: str):
        if kind not in {"cuda", "rocm"}:
            raise ValueError(kind)
        self.kind = kind
        compiler = shutil.which("nvcc") if kind == "cuda" else shutil.which("hipcc")
        self.compiler_info = GPUCompilerInfo(compiler, kind) if compiler else None
        target = "cuda" if kind == "cuda" else "rocm"
        runtime_probe = shutil.which("nvidia-smi") if kind == "cuda" else (shutil.which("rocminfo") or shutil.which("rocm-smi"))
        available = compiler is not None and runtime_probe is not None
        self.capabilities = BackendCapabilities(
            f"{kind}-runtime", target, available, False, "gpu",
            (f"compiler={compiler}", f"device_probe={runtime_probe}") if available else (f"{kind} toolchain or runtime unavailable",),
        )
        self._artifacts: list[GPUArtifact] = []

    def compile(self, program, candidate: Candidate) -> GPUArtifact:
        if not self.compiler_info:
            raise RuntimeError(f"{self.kind} compiler unavailable")
        root = Path(tempfile.mkdtemp(prefix=f"mosaic-{self.kind}-"))
        suffix = ".cu" if self.kind == "cuda" else ".hip"
        src = root / f"kernel{suffix}"
        out = root / "kernel.so"
        expr = c_expr(program.root, "x")
        if self.kind == "cuda":
            code = f'''#include <cuda_runtime.h>\n#include <stddef.h>\nextern "C" __global__ void mosaic_kernel(const double* x, double* y, size_t n) {{ size_t i = (size_t)(blockIdx.x * blockDim.x + threadIdx.x); if (i < n) y[i] = {expr}; }}\nextern "C" int mosaic_run(const double* hx, double* hy, size_t n) {{ double* dx=nullptr; double* dy=nullptr; cudaError_t e=cudaMalloc(&dx,n*sizeof(double)); if(e!=cudaSuccess) return (int)e; e=cudaMalloc(&dy,n*sizeof(double)); if(e!=cudaSuccess){{cudaFree(dx);return(int)e;}} e=cudaMemcpy(dx,hx,n*sizeof(double),cudaMemcpyHostToDevice); if(e==cudaSuccess){{ size_t b=256; size_t g=(n+b-1)/b; mosaic_kernel<<<g,b>>>(dx,dy,n); e=cudaGetLastError(); }} if(e==cudaSuccess)e=cudaDeviceSynchronize(); if(e==cudaSuccess)e=cudaMemcpy(hy,dy,n*sizeof(double),cudaMemcpyDeviceToHost); cudaFree(dx); cudaFree(dy); return (int)e; }}\n'''
        else:
            code = f'''#include <hip/hip_runtime.h>\n#include <stddef.h>\nextern "C" __global__ void mosaic_kernel(const double* x, double* y, size_t n) {{ size_t i = (size_t)(blockIdx.x * blockDim.x + threadIdx.x); if (i < n) y[i] = {expr}; }}\nextern "C" int mosaic_run(const double* hx, double* hy, size_t n) {{ double* dx=nullptr; double* dy=nullptr; hipError_t e=hipMalloc(&dx,n*sizeof(double)); if(e!=hipSuccess)return(int)e; e=hipMalloc(&dy,n*sizeof(double)); if(e!=hipSuccess){{hipFree(dx);return(int)e;}} e=hipMemcpy(dx,hx,n*sizeof(double),hipMemcpyHostToDevice); if(e==hipSuccess){{ size_t b=256; size_t g=(n+b-1)/b; hipLaunchKernelGGL(mosaic_kernel,dim3(g),dim3(b),0,0,dx,dy,n); e=hipGetLastError(); }} if(e==hipSuccess)e=hipDeviceSynchronize(); if(e==hipSuccess)e=hipMemcpy(hy,dy,n*sizeof(double),hipMemcpyDeviceToHost); hipFree(dx); hipFree(dy); return (int)e; }}\n'''
        src.write_text(code, encoding="utf-8")
        cmd = [self.compiler_info.compiler, "-O3", "-shared", "-Xcompiler", "-fPIC", str(src), "-o", str(out)]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
        if proc.returncode:
            raise RuntimeError(f"{self.kind} compilation failed: {proc.stderr[-4000:]}")
        lib = ctypes.CDLL(str(out))
        fn = lib.mosaic_run
        fn.argtypes = [ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double), ctypes.c_size_t]
        fn.restype = ctypes.c_int
        artifact = GPUArtifact(root, lib)
        self._artifacts.append(artifact)
        return artifact

    def run(self, artifact: GPUArtifact, x: Sequence[float]) -> tuple[float, ...]:
        import array
        n = len(x)
        xin = array.array("d", (float(v) for v in x))
        out = array.array("d", [0.0]) * n
        rc = artifact.library.mosaic_run(
            (ctypes.c_double * n).from_buffer(xin),
            (ctypes.c_double * n).from_buffer(out),
            n,
        )
        if rc:
            raise RuntimeError(f"{self.kind} runtime returned error code {rc}")
        return tuple(out)

    def close(self):
        for artifact in self._artifacts:
            shutil.rmtree(artifact.directory, ignore_errors=True)
        self._artifacts.clear()
