from __future__ import annotations

import shutil
from .native import NativeCPUBackend


class LLVMBackend(NativeCPUBackend):
    """LLVM codegen path via Clang.

    Clang lowers C generated from MCIR through LLVM's optimization/codegen pipeline.
    This gives MOSAIC a real LLVM backend without hard-linking to libLLVM Python bindings.
    """

    def __init__(self):
        clang = shutil.which("clang")
        super().__init__(compiler=clang)
        self.capabilities = self.capabilities.__class__(
            "llvm-clang", "llvm-cpu", self.capabilities.available,
            False, "cpu", self.capabilities.notes,
        )

    def compile(self, program, candidate):
        if not self.capabilities.available:
            raise RuntimeError("clang/LLVM is not available")
        return super().compile(program, candidate)
