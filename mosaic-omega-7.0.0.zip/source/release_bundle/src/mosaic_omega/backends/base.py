from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, Sequence

from ..model import Candidate, Observation


@dataclass(frozen=True)
class BackendCapabilities:
    name: str
    target: str
    available: bool
    sandboxed: bool
    device_class: str
    notes: tuple[str, ...] = ()


class ComputeBackend(Protocol):
    capabilities: BackendCapabilities

    def compile(self, program, candidate: Candidate): ...

    def run(self, artifact, x: Sequence[float]) -> tuple[float, ...]: ...

    def close(self) -> None: ...
