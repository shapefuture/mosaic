from __future__ import annotations

import ctypes
import hashlib
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from .base import BackendCapabilities
from ..ir.codegen import c_expr
from ..model import Candidate
from ..optimize import optimize


@dataclass
class NativeArtifact:
    directory: Path
    library: ctypes.CDLL
    path: Path
    optimized_nodes: int
    original_nodes: int


class NativeCPUBackend:
    """Real native CPU backend with compiler-driven vectorization and IR pre-optimization.

    The optimizer is deliberately semantics-preserving. Hardware-specific performance
    gains remain below this layer, where generated machine code can exploit the detected
    host ISA. Artifacts are content-addressed and persistent.
    """

    def __init__(
        self,
        compiler: str | None = None,
        fast_math: bool = False,
        cache_dir: str | Path | None = None,
        optimize_ir: bool = True,
    ):
        self.compiler = compiler or shutil.which("clang") or shutil.which("gcc")
        available = bool(self.compiler)
        notes = (f"compiler={self.compiler}", f"optimize_ir={optimize_ir}") if self.compiler else ("no C compiler found",)
        self.capabilities = BackendCapabilities("native-cpu", "native-cpu", available, False, "cpu", notes)
        self._artifacts: list[NativeArtifact] = []
        self.cache_dir = Path(cache_dir or (Path.home() / ".cache" / "mosaic-omega" / "native"))
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.fast_math = fast_math
        self.optimize_ir = optimize_ir

    def _bind(self, lib: ctypes.CDLL) -> None:
        fn = lib.mosaic_run
        fn.argtypes = [ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double), ctypes.c_size_t]
        fn.restype = None
        rep = lib.mosaic_run_repeated
        rep.argtypes = [ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double), ctypes.c_size_t, ctypes.c_size_t]
        rep.restype = None

    def compile(self, program, candidate: Candidate) -> NativeArtifact:
        if not self.compiler:
            raise RuntimeError("no clang/gcc available")
        root_node = program.root
        report = None
        if self.optimize_ir:
            root_node, report = optimize(root_node)
        original_nodes = report.original_nodes if report else 0
        optimized_nodes = report.optimized_nodes if report else 0
        digest = hashlib.sha256(
            (program.digest + candidate.genome_id + str(self.compiler) + str(self.fast_math) + str(self.optimize_ir) + repr(root_node)).encode()
        ).hexdigest()
        cached = self.cache_dir / f"{digest}.so"
        if cached.exists():
            lib = ctypes.CDLL(str(cached))
            self._bind(lib)
            artifact = NativeArtifact(cached.parent, lib, cached, optimized_nodes, original_nodes)
            self._artifacts.append(artifact)
            return artifact

        root = Path(tempfile.mkdtemp(prefix="mosaic-native-"))
        src = root / "kernel.c"
        so = root / "kernel.so"
        expr = c_expr(root_node)
        g = candidate.genome
        tile = max(1, min(64, g.tile))
        width = max(1, min(16, g.vector_width))
        unroll = max(1, min(16, g.unroll))
        # Keep the hot loop simple so LLVM/GCC can vectorize it. Unrolling is a hint,
        # not a semantic requirement; the compiler can choose a machine-appropriate width.
        body = "\n".join(
            f"    y[i + {j}] = {expr.replace('[i]', f'[i + {j}]')};" for j in range(unroll)
        )
        src.write_text(
            "#include <stddef.h>\n"
            "#if defined(__GNUC__)\n#define RESTRICT __restrict__\n#else\n#define RESTRICT\n#endif\n"
            "static inline void mosaic_kernel(const double* RESTRICT x, double* RESTRICT y, size_t i) {\n"
            + body + "\n}\n"
            "void mosaic_run(const double* RESTRICT x, double* RESTRICT y, size_t n) {\n"
            f"  const size_t U = {unroll}u;\n"
            f"  const size_t TILE = {tile}u * U;\n"
            "  size_t i = 0;\n"
            "  for (; i + TILE <= n; i += TILE) {\n"
            "    for (size_t j = 0; j < TILE; j += U) mosaic_kernel(x, y, i + j);\n"
            "  }\n"
            "  for (; i + U <= n; i += U) mosaic_kernel(x, y, i);\n"
            "  for (; i < n; ++i) y[i] = "
            + expr + ";\n"
            "}\n"
            "void mosaic_run_repeated(const double* RESTRICT x, double* RESTRICT y, size_t n, size_t repeats) {\n"
            "  for (size_t r = 0; r < repeats; ++r) mosaic_run(x, y, n);\n"
            "}\n",
            encoding="utf-8",
        )
        flags = [
            self.compiler,
            "-O3",
            "-fPIC",
            "-shared",
            "-std=c11",
            "-march=native",
            "-mtune=native",
            "-fno-math-errno",
            "-fno-trapping-math",
            "-funroll-loops",
            "-o", str(so), str(src),
        ]
        if not self.fast_math:
            flags.insert(1, "-fno-fast-math")
        else:
            flags.insert(1, "-ffast-math")
        proc = subprocess.run(flags, capture_output=True, text=True, timeout=30)
        if proc.returncode != 0:
            raise RuntimeError(f"native compilation failed: {proc.stderr[-4000:]}")
        shutil.copy2(so, cached)
        shutil.rmtree(root, ignore_errors=True)
        lib = ctypes.CDLL(str(cached))
        self._bind(lib)
        artifact = NativeArtifact(self.cache_dir, lib, cached, optimized_nodes, original_nodes)
        self._artifacts.append(artifact)
        return artifact

    @staticmethod
    def _buffers(x: Sequence[float]):
        import array
        n = len(x)
        xin = array.array("d", (float(v) for v in x))
        out = array.array("d", [0.0]) * n
        return xin, out, n

    def run(self, artifact: NativeArtifact, x: Sequence[float]) -> tuple[float, ...]:
        xin, out, n = self._buffers(x)
        artifact.library.mosaic_run(
            (ctypes.c_double * n).from_buffer(xin),
            (ctypes.c_double * n).from_buffer(out), n,
        )
        return tuple(out)

    def run_repeated(self, artifact: NativeArtifact, x: Sequence[float], repeats: int) -> tuple[float, ...]:
        if repeats < 1:
            raise ValueError("repeats must be >= 1")
        xin, out, n = self._buffers(x)
        artifact.library.mosaic_run_repeated(
            (ctypes.c_double * n).from_buffer(xin),
            (ctypes.c_double * n).from_buffer(out), n, repeats,
        )
        return tuple(out)

    def close(self) -> None:
        self._artifacts.clear()
