from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import math

from ..ir.nodes import Add, Const, Input, Mul, Neg, Node, ReduceSum


@dataclass(frozen=True)
class OptimizationReport:
    original_nodes: int
    optimized_nodes: int
    eliminated_nodes: int
    transformations: tuple[str, ...]


def _key(n: Node) -> tuple:
    if isinstance(n, Const): return ("const", float(n.value))
    if isinstance(n, Input): return ("input", n.index)
    if isinstance(n, Add): return ("add", _key(n.left), _key(n.right))
    if isinstance(n, Mul): return ("mul", _key(n.left), _key(n.right))
    if isinstance(n, Neg): return ("neg", _key(n.value))
    if isinstance(n, ReduceSum): return ("reduce_sum", _key(n.value))
    raise TypeError(type(n).__name__)


def count_nodes(n: Node) -> int:
    return 1 + sum(count_nodes(c) for c in n.children())


def _const(n: Node) -> float | None:
    return float(n.value) if isinstance(n, Const) else None


def _safe_add(a: float, b: float) -> float:
    return a + b


def _safe_mul(a: float, b: float) -> float:
    return a * b


@lru_cache(maxsize=4096)
def simplify(n: Node) -> Node:
    if isinstance(n, (Const, Input)):
        return n
    if isinstance(n, Neg):
        x = simplify(n.value)
        if isinstance(x, Const):
            return Const(-float(x.value))
        if isinstance(x, Neg):
            return x.value
        return Neg(x)
    if isinstance(n, Add):
        a, b = simplify(n.left), simplify(n.right)
        ca, cb = _const(a), _const(b)
        if ca is not None and cb is not None:
            return Const(_safe_add(ca, cb))
        if ca == 0.0: return b
        if cb == 0.0: return a
        # Canonicalize commutative expressions so common subexpressions collapse.
        if repr(_key(a)) > repr(_key(b)):
            a, b = b, a
        return Add(a, b)
    if isinstance(n, Mul):
        a, b = simplify(n.left), simplify(n.right)
        ca, cb = _const(a), _const(b)
        if ca is not None and cb is not None:
            return Const(_safe_mul(ca, cb))
        if ca == 0.0 or cb == 0.0: return Const(0.0)
        if ca == 1.0: return b
        if cb == 1.0: return a
        if repr(_key(a)) > repr(_key(b)):
            a, b = b, a
        return Mul(a, b)
    if isinstance(n, ReduceSum):
        x = simplify(n.value)
        if isinstance(x, Const): return x
        return ReduceSum(x)
    raise TypeError(type(n).__name__)


def _dedupe(n: Node, memo: dict[tuple, Node]) -> Node:
    kids = tuple(_dedupe(c, memo) for c in n.children())
    if isinstance(n, Const): out = n
    elif isinstance(n, Input): out = n
    elif isinstance(n, Add): out = Add(kids[0], kids[1])
    elif isinstance(n, Mul): out = Mul(kids[0], kids[1])
    elif isinstance(n, Neg): out = Neg(kids[0])
    elif isinstance(n, ReduceSum): out = ReduceSum(kids[0])
    else: raise TypeError(type(n).__name__)
    k = _key(out)
    prev = memo.get(k)
    if prev is not None: return prev
    memo[k] = out
    return out


def optimize(n: Node) -> tuple[Node, OptimizationReport]:
    before = count_nodes(n)
    transformed = simplify(n)
    transformed = _dedupe(transformed, {})
    after = count_nodes(transformed)
    names: list[str] = []
    if after < before: names.append("constant-folding")
    if _key(transformed) != _key(n): names.append("algebraic-simplification")
    if after < before and len(names) == 1: names.append("common-subexpression-deduplication")
    return transformed, OptimizationReport(before, after, max(0, before - after), tuple(names))
