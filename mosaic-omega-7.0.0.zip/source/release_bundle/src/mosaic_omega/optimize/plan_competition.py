from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Sequence

@dataclass(frozen=True)
class PlanCandidate:
    name: str
    latency_ms: float
    cost_usd: float
    quality: float
    confidence: float
    verified: bool = False

@dataclass(frozen=True)
class PlanSelection:
    selected: str
    rejected: tuple[str, ...]
    score: float

class PlanCompetition:
    def select(self, candidates: Sequence[PlanCandidate], min_quality: float = 0.99) -> PlanSelection:
        valid = [c for c in candidates if c.verified and c.quality >= min_quality]
        if not valid:
            raise ValueError("no verified plan satisfies quality constraint")
        def score(c: PlanCandidate):
            return c.quality * c.confidence / (max(c.latency_ms, 1e-9) * max(c.cost_usd, 1e-9))
        winner = max(valid, key=score)
        rejected = tuple(c.name for c in candidates if c.name != winner.name)
        return PlanSelection(winner.name, rejected, score(winner))
