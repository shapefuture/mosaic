from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
import json
from typing import Any, Callable, Iterable, Mapping, Sequence

from ..ecu.core import ECUAction, ECUContract, ExecutableComputeUnit
from ..trajectory.events import Trajectory, TrajectoryEvent


def _norm_action(e: TrajectoryEvent) -> tuple[str, dict[str, Any]]:
    """Normalize an event into action + best-effort structured arguments."""
    name = e.action.strip().lower().split(".")[-1][:128]
    args: dict[str, Any] = {}
    raw = e.observation.strip()
    if raw:
        try:
            obj = json.loads(raw)
            if isinstance(obj, dict):
                args = obj
        except Exception:
            # Some harnesses emit shell-like or free-form tool arguments.
            # Preserve them without trying to execute/parse arbitrary syntax.
            args = {"raw": raw[:2000]}
    meta = e.metadata or {}
    if isinstance(meta.get("tool_args"), dict):
        args.update(meta["tool_args"])
    return name, args


def _success(traj: Trajectory) -> bool:
    if any(e.ok is False for e in traj.events):
        return False
    for e in traj.events:
        meta = e.metadata or {}
        if meta.get("verify_status") in {"unresolved", "fail", "failure"}:
            return False
        if meta.get("judge_verdict") in {"reject", "fail", "failure"}:
            return False
    return any(
        e.ok is True
        or (e.metadata or {}).get("verify_status") in {"resolved", "pass", "accept"}
        or (e.metadata or {}).get("judge_verdict") in {"accept", "pass"}
        for e in traj.events
    )


def _transition_key(prev: TrajectoryEvent | None, event: TrajectoryEvent) -> str:
    before = prev.state_hash[:24] if prev and prev.state_hash else (prev.kind if prev else "START")
    after = event.state_hash[:24] if event.state_hash else event.kind
    return f"{before}->{after}"


@dataclass(frozen=True)
class Procedure:
    actions: tuple[ECUAction, ...]
    preconditions: tuple[str, ...]
    postconditions: tuple[str, ...]
    support_runs: int
    success_runs: int
    failure_runs: int
    mean_latency_ms: float
    mean_cost_usd: float
    transition_consistency: float
    causal_score: float
    provenance: Mapping[str, Any] = field(default_factory=dict)

    @property
    def success_rate(self) -> float:
        return self.success_runs / max(1, self.success_runs + self.failure_runs)

    @property
    def utility(self) -> float:
        # Strongly prefer correctness, then causal concentration, then cost/latency.
        return (
            self.success_rate
            * self.transition_consistency
            * max(0.0, self.causal_score)
            / (1.0 + self.mean_latency_ms / 1000.0 + 1000.0 * self.mean_cost_usd)
        )

    @property
    def digest(self) -> str:
        obj = {
            "actions": [{"name": a.name, "args": dict(a.args), "expected_state": dict(a.expected_state)} for a in self.actions],
            "pre": self.preconditions,
            "post": self.postconditions,
        }
        return sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


@dataclass(frozen=True)
class CounterfactualResult:
    kept: tuple[int, ...]
    score: float
    removed_steps: int


def _causal_scores(traj: Trajectory) -> dict[int, float]:
    """Cheap deterministic causal proxy: reward terminal verification and penalize pre-failure churn."""
    if not traj.events:
        return {}
    bad = next((e.step for e in traj.events if e.ok is False), None)
    terminal = max(e.step for e in traj.events)
    out: dict[int, float] = {}
    for e in traj.events:
        score = 0.0
        if e.ok is True:
            score += 0.2
        if e.kind in {"verify", "benchmark", "checkpoint", "recovery"}:
            score += 0.5
        if bad is not None and e.step <= bad:
            score += 0.2
        if e.step == terminal and _success(traj):
            score += 1.0
        score -= min(0.25, (e.latency_ms / 10000.0) + e.cost_usd)
        out[e.step] = max(0.0, score)
    return out


def delta_debug_sequence(
    traj: Trajectory,
    evaluator: Callable[[Sequence[TrajectoryEvent]], float],
    *,
    minimum_score: float = 0.9,
) -> CounterfactualResult:
    """Greedily delete chunks of events while preserving an outcome score.

    This turns a full trajectory into a minimal sufficient execution trace.
    The evaluator is supplied by the environment/harness, so MOSAIC does not
    assume textual similarity implies semantic equivalence.
    """
    events = list(traj.events)
    baseline = evaluator(events)
    if baseline < minimum_score:
        return CounterfactualResult(tuple(e.step for e in events), baseline, 0)
    changed = True
    while changed and len(events) > 1:
        changed = False
        granularity = max(1, len(events) // 2)
        for start in range(0, len(events), granularity):
            proposal = events[:start] + events[start + granularity :]
            if not proposal:
                continue
            score = evaluator(proposal)
            if score >= minimum_score:
                events = proposal
                changed = True
                break
    return CounterfactualResult(tuple(e.step for e in events), evaluator(events), len(traj.events) - len(events))


def mine_procedures(
    trajectories: Iterable[Trajectory],
    *,
    min_support: int = 2,
    max_len: int = 12,
) -> list[Procedure]:
    """Mine argument-aware, state-transition-aware procedures."""
    runs = list(trajectories)
    buckets: dict[tuple[tuple[str, str], ...], dict[str, Any]] = {}
    for traj in runs:
        good = _success(traj)
        causal = _causal_scores(traj)
        normalized = [_norm_action(e) for e in traj.events if e.action]
        event_refs = [e for e in traj.events if e.action]
        for n in range(1, min(max_len, len(normalized)) + 1):
            seen: set[tuple[tuple[str, str], ...]] = set()
            for i in range(len(normalized) - n + 1):
                sig = tuple((name, json.dumps(args, sort_keys=True, separators=(",", ":"))) for name, args in normalized[i:i+n])
                if sig in seen:
                    continue
                seen.add(sig)
                bucket = buckets.setdefault(sig, {"runs": set(), "good": set(), "bad": set(), "states": set(), "lat": 0.0, "cost": 0.0, "causal": 0.0, "count": 0})
                bucket["runs"].add(traj.run_id)
                (bucket["good"] if good else bucket["bad"]).add(traj.run_id)
                transitions = tuple(_transition_key(event_refs[j-1] if j > i else None, event_refs[j]) for j in range(i, i+n))
                bucket["states"].add(transitions)
                bucket["lat"] += sum(e.latency_ms for e in event_refs[i:i+n])
                bucket["cost"] += sum(e.cost_usd for e in event_refs[i:i+n])
                bucket["causal"] += sum(causal.get(e.step, 0.0) for e in event_refs[i:i+n])
                bucket["count"] += 1

    procedures: list[Procedure] = []
    for sig, b in buckets.items():
        support = len(b["runs"])
        if support < min_support:
            continue
        good = len(b["good"])
        bad = len(b["bad"])
        states = b["states"]
        consistency = 1.0 if len(states) <= max(1, support // 2) else max(0.0, 1.0 - (len(states) - support // 2) / max(1, support))
        actions: list[ECUAction] = []
        for name, raw_args in sig:
            try:
                args = json.loads(raw_args)
            except Exception:
                args = {"raw": raw_args}
            actions.append(ECUAction(name, args=args))
        procedures.append(
            Procedure(
                tuple(actions),
                (),
                (),
                support,
                good,
                bad,
                b["lat"] / max(1, b["count"]),
                b["cost"] / max(1, b["count"]),
                consistency,
                b["causal"] / max(1, b["count"]),
                {"method": "argument-aware-transition-mining-v1"},
            )
        )
    procedures.sort(key=lambda p: (-p.utility, -p.success_rate, -p.support_runs, -len(p.actions), p.digest))
    return procedures


def compile_procedures(procedures: Iterable[Procedure], manifest_digest: str, *, max_units: int = 256) -> list[ExecutableComputeUnit]:
    units: list[ExecutableComputeUnit] = []
    seen: set[str] = set()
    for p in procedures:
        if len(units) >= max_units:
            break
        if p.success_rate < 1.0 or p.transition_consistency < 0.8 or p.causal_score <= 0:
            continue
        if p.digest in seen:
            continue
        seen.add(p.digest)
        name = f"ecu_{p.digest[:16]}"
        provenance = {
            **dict(p.provenance),
            "source_manifest": manifest_digest,
            "support_runs": p.support_runs,
            "success_runs": p.success_runs,
            "failure_runs": p.failure_runs,
            "transition_consistency": p.transition_consistency,
            "causal_score": p.causal_score,
            "mean_latency_ms": p.mean_latency_ms,
            "mean_cost_usd": p.mean_cost_usd,
        }
        units.append(ExecutableComputeUnit(
            ECUContract(name=name, preconditions=p.preconditions, postconditions=p.postconditions, max_steps=len(p.actions), tags=("argument-aware", "transition-aware", "causal")),
            p.actions,
            provenance,
        ))
    return units
