from __future__ import annotations

import json

from collections import Counter, defaultdict
from dataclasses import dataclass, asdict
from hashlib import sha256
from typing import Iterable, Iterator, Sequence

from ..data.frontier import DatasetManifest, validate_manifest_for_training
from ..trajectory.events import Trajectory
from ..ecu.core import ECUAction, ECUContract, ExecutableComputeUnit
from .diversity import trajectory_group_id


@dataclass(frozen=True)
class StreamingStats:
    trajectories_seen: int
    train_seen: int
    validation_seen: int
    candidate_patterns: int
    accepted_units: int
    rejected_patterns: int
    peak_buffer: int
    holdout_success_rate: float
    compression_ratio: float

    def as_dict(self):
        return asdict(self)


@dataclass
class _PatternStat:
    support: int = 0
    success_support: int = 0
    failure_support: int = 0
    examples: int = 0
    total_steps: int = 0
    train_groups: set[str] | None = None
    success_groups: set[str] | None = None
    failure_groups: set[str] | None = None

    def __post_init__(self):
        self.train_groups = self.train_groups or set()
        self.success_groups = self.success_groups or set()
        self.failure_groups = self.failure_groups or set()


def _is_success(t: Trajectory) -> bool:
    for e in t.events:
        meta = e.metadata or {}
        if e.ok is False or meta.get("verify_status") == "unresolved" or meta.get("judge_verdict") in {"reject", "fail", "failure"}:
            return False
    return any(e.ok is True or (e.metadata or {}).get("verify_status") == "resolved" or (e.metadata or {}).get("judge_verdict") in {"accept", "pass"} for e in t.events)


def _split(traj: Trajectory, holdout_mod: int = 10) -> bool:
    """True => validation, False => training; deterministic by source trajectory."""
    return int(sha256(trajectory_group_id(traj).encode()).hexdigest()[:8], 16) % holdout_mod == 0


def _actions(t: Trajectory) -> list[str]:
    return [e.action.strip().lower().split(".")[-1][:96] for e in t.events if e.action]


class StreamingTrajectoryTrainer:
    """Bounded-memory full-corpus trajectory learner.

    Unlike the earlier trainer, this never materializes the corpus. It maintains
    only top heavy-hitter action motifs and bounded source-group support sets.
    """

    def __init__(self, *, min_support: int = 8, max_len: int = 8, max_patterns: int = 4096, max_support_ids: int = 4096):
        self.min_support = min_support
        self.max_len = max_len
        self.max_patterns = max_patterns
        self.max_support_ids = max_support_ids
        self.stats: dict[tuple[str, ...], _PatternStat] = {}
        self.total_steps = 0
        self.train_seen = 0
        self.val_seen = 0
        self.success_val = 0
        self.total_val = 0
        self.rejected = 0

    def update(self, traj: Trajectory) -> None:
        validation = _split(traj)
        if validation:
            self.val_seen += 1
            self.total_val += 1
            self.success_val += int(_is_success(traj))
        else:
            self.train_seen += 1
        self.total_steps += len(traj.events)
        acts = _actions(traj)
        if validation:
            return
        good = _is_success(traj)
        group = trajectory_group_id(traj)
        local: set[tuple[str, ...]] = set()
        for n in range(1, min(self.max_len, len(acts)) + 1):
            for i in range(0, len(acts) - n + 1):
                gram = tuple(acts[i:i+n])
                if gram in local:
                    continue
                local.add(gram)
                stat = self.stats.setdefault(gram, _PatternStat())
                stat.examples += 1
                stat.train_groups.add(group)
                if len(stat.train_groups) > self.max_support_ids:
                    stat.train_groups.pop()
                if good:
                    stat.success_groups.add(group)
                    if len(stat.success_groups) > self.max_support_ids:
                        stat.success_groups.pop()
                else:
                    stat.failure_groups.add(group)
                    if len(stat.failure_groups) > self.max_support_ids:
                        stat.failure_groups.pop()
                stat.support = len(stat.train_groups)
                stat.success_support = len(stat.success_groups)
                stat.failure_support = len(stat.failure_groups)
        if len(self.stats) > self.max_patterns * 2:
            self._prune()

    def update_many(self, trajectories: Iterable[Trajectory], *, batch_size: int = 256) -> Iterator[int]:
        batch = []
        for traj in trajectories:
            batch.append(traj)
            if len(batch) >= batch_size:
                for t in batch:
                    self.update(t)
                yield len(batch)
                batch.clear()
        for t in batch:
            self.update(t)
        if batch:
            yield len(batch)

    def _prune(self) -> None:
        scored = sorted(self.stats.items(), key=lambda kv: (kv[1].success_support, kv[1].support, len(kv[0])), reverse=True)
        self.stats = dict(scored[: self.max_patterns])

    def compile(self, manifest: DatasetManifest) -> tuple[list[ExecutableComputeUnit], StreamingStats]:
        validate_manifest_for_training(manifest)
        units: list[ExecutableComputeUnit] = []
        rejected = 0
        for actions, stat in sorted(self.stats.items(), key=lambda kv: (-kv[1].success_support, -len(kv[0]), kv[0])):
            if stat.support < self.min_support or stat.success_support < self.min_support or stat.failure_support > 0:
                rejected += 1
                continue
            stable = sha256((manifest.digest + "|" + "|".join(actions)).encode()).hexdigest()[:16]
            units.append(ExecutableComputeUnit(
                ECUContract(name=f"stream_ecu_{stable}", max_steps=len(actions), tags=("streaming-distill", "verified-candidate", f"support:{stat.support}")),
                tuple(ECUAction(a) for a in actions),
                {
                    "source_manifest": manifest.digest,
                    "method": "bounded-streaming-heavy-hitter-v1",
                    "support_runs": stat.support,
                    "success_runs": stat.success_support,
                    "failure_runs": stat.failure_support,
                },
            ))
        baseline = max(1, self.total_steps)
        compiled_steps = sum(len(u.actions) for u in units)
        stats = StreamingStats(
            trajectories_seen=self.train_seen + self.val_seen,
            train_seen=self.train_seen,
            validation_seen=self.val_seen,
            candidate_patterns=len(self.stats),
            accepted_units=len(units),
            rejected_patterns=rejected,
            peak_buffer=1,
            holdout_success_rate=self.success_val / max(1, self.total_val),
            compression_ratio=max(0.0, 1.0 - compiled_steps / baseline),
        )
        return units, stats


def train_streaming(trajectories: Iterable[Trajectory], manifest: DatasetManifest, **kwargs) -> tuple[list[ExecutableComputeUnit], StreamingStats]:
    trainer = StreamingTrajectoryTrainer(**kwargs)
    for _ in trainer.update_many(trajectories):
        pass
    return trainer.compile(manifest)

@dataclass
class _GeneralizedPattern:
    groups: set[str]
    success_groups: set[str]
    failure_groups: set[str]
    arg_values: dict[tuple[int, str], set[str]]


class StreamingECUTrainer:
    """Bounded-memory procedure miner with argument anti-unification.

    It keeps only heavy-hitter action signatures, group support and a bounded set of
    observed argument values; raw trajectories are never retained.
    """
    def __init__(self, *, min_support: int = 8, max_len: int = 8, max_patterns: int = 4096, max_values: int = 32):
        self.min_support = min_support
        self.max_len = max_len
        self.max_patterns = max_patterns
        self.max_values = max_values
        self.patterns: dict[tuple[str, ...], _GeneralizedPattern] = {}
        self.seen = 0

    def update(self, traj: Trajectory) -> None:
        from .procedures import _norm_action
        self.seen += 1
        acts = [_norm_action(e) for e in traj.events if e.action]
        if not acts:
            return
        good = _is_success(traj)
        group = trajectory_group_id(traj)
        local: set[tuple[str, ...]] = set()
        for n in range(1, min(self.max_len, len(acts)) + 1):
            for i in range(len(acts) - n + 1):
                gram = tuple(name for name, _ in acts[i:i+n])
                if gram in local:
                    continue
                local.add(gram)
                p = self.patterns.setdefault(gram, _GeneralizedPattern(set(), set(), set(), {}))
                p.groups.add(group)
                (p.success_groups if good else p.failure_groups).add(group)
                if len(p.groups) > self.max_values * self.max_len:
                    p.groups.pop()
                if good:
                    if len(p.success_groups) > self.max_values * self.max_len:
                        p.success_groups.pop()
                else:
                    if len(p.failure_groups) > self.max_values * self.max_len:
                        p.failure_groups.pop()
                for pos, (_, args) in enumerate(acts[i:i+n]):
                    for key, value in args.items():
                        bucket = p.arg_values.setdefault((pos, key), set())
                        try:
                            bucket.add(json.dumps(value, sort_keys=True, separators=(",", ":")))
                        except TypeError:
                            bucket.add(repr(value))
                        if len(bucket) > self.max_values:
                            bucket.pop()
        if len(self.patterns) > self.max_patterns * 2:
            ranked = sorted(self.patterns.items(), key=lambda kv: (len(kv[1].success_groups), len(kv[1].groups), len(kv[0])), reverse=True)
            self.patterns = dict(ranked[:self.max_patterns])

    def update_many(self, trajectories: Iterable[Trajectory]) -> None:
        for t in trajectories:
            self.update(t)

    def compile(self, manifest: DatasetManifest) -> tuple[list[ExecutableComputeUnit], dict[str, float]]:
        validate_manifest_for_training(manifest)
        from ..ecu.core import ECUAction, ECUContract, ExecutableComputeUnit
        units = []
        for names, p in sorted(self.patterns.items(), key=lambda kv: (-len(kv[1].success_groups), -len(kv[0]), kv[0])):
            if len(p.groups) < self.min_support or len(p.success_groups) < self.min_support or p.failure_groups:
                continue
            actions = []
            params = 0
            for pos, name in enumerate(names):
                args = {}
                for (arg_pos, key), values in p.arg_values.items():
                    if arg_pos != pos:
                        continue
                    if len(values) == 1:
                        raw = next(iter(values))
                        try:
                            args[key] = json.loads(raw)
                        except Exception:
                            args[key] = raw
                    else:
                        args[key] = f"$param.{pos}.{key}"
                        params += 1
                actions.append(ECUAction(name, args=args))
            digest = sha256((manifest.digest + "|" + json.dumps(names) + "|" + str(params)).encode()).hexdigest()[:16]
            units.append(ExecutableComputeUnit(
                ECUContract(name=f"stream_genu_{digest}", max_steps=len(actions), tags=("streaming", "parameterized", "anti-unified")),
                actions,
                {"source_manifest": manifest.digest, "support_runs": len(p.groups), "success_runs": len(p.success_groups), "parameter_count": params, "method": "bounded-streaming-anti-unify-v1"},
            ))
        diagnostics = {"patterns": float(len(self.patterns)), "trajectories_seen": float(self.seen), "accepted_units": float(len(units))}
        return units, diagnostics
