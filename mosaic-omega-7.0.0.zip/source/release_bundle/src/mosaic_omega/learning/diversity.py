from __future__ import annotations

from collections import defaultdict
from hashlib import sha256
from typing import Iterable, Sequence

from ..trajectory.events import Trajectory


def _meta_values(traj: Trajectory) -> tuple[str, ...]:
    values: list[str] = []
    for event in traj.events:
        meta = event.metadata or {}
        for key in ("teacher_model", "model", "harness", "source", "repo", "domain", "category", "lang"):
            val = meta.get(key)
            if val is not None and str(val) not in values:
                values.append(str(val))
    return tuple(values)


def trajectory_group_id(traj: Trajectory) -> str:
    """Stable leakage-safe grouping key; never split repeated source runs."""
    source = traj.events[0].metadata.get("source_trajectory_id") if traj.events else None
    base = str(source or traj.run_id)
    return sha256(base.encode()).hexdigest()[:16]


def stratified_sample(
    trajectories: Sequence[Trajectory],
    limit: int | None = None,
    *,
    seed: int = 42,
) -> list[Trajectory]:
    """Diversity-first sampling across model/harness/source/domain/repository strata."""
    if limit is None or limit >= len(trajectories):
        return list(trajectories)
    buckets: dict[tuple[str, ...], list[Trajectory]] = defaultdict(list)
    for t in trajectories:
        meta = _meta_values(t)
        key = tuple(sorted(meta[:6])) or ("unknown",)
        buckets[key].append(t)
    keys = sorted(buckets, key=lambda x: (len(buckets[x]), x))
    # Deterministic round-robin ensures long-tail strata are represented.
    out: list[Trajectory] = []
    cursor = 0
    while len(out) < limit and keys:
        progressed = False
        for key in keys[cursor:] + keys[:cursor]:
            bucket = buckets[key]
            if not bucket:
                continue
            out.append(bucket.pop(0))
            progressed = True
            if len(out) >= limit:
                break
        cursor = (cursor + 1) % max(1, len(keys))
        keys = [k for k in keys if buckets[k]]
        if not progressed:
            break
    return out


def split_by_group(trajectories: Sequence[Trajectory], validation_fraction: float = 0.2) -> tuple[list[Trajectory], list[Trajectory]]:
    """Leakage-safe split by source trajectory identity."""
    groups: dict[str, list[Trajectory]] = defaultdict(list)
    for t in trajectories:
        groups[trajectory_group_id(t)].append(t)
    ordered = sorted(groups.items(), key=lambda kv: kv[0])
    target = max(1, int(round(len(trajectories) * validation_fraction)))
    val: list[Trajectory] = []
    train: list[Trajectory] = []
    for group_id, group in ordered:
        if len(val) < target:
            val.extend(group)
        else:
            train.extend(group)
    if not train and val:
        train = val[:-1]
        val = val[-1:]
    return train, val
