from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Iterable

from ..data.frontier import validate_manifest_for_training, DatasetManifest
from ..trajectory.events import Trajectory
from .motifs import Motif, mine_motifs, compile_motifs_to_ecus
from .procedures import mine_procedures, compile_procedures
from .offline_rl import OfflineTrajectoryQLearner
from .policy import TrajectoryPolicy
from .diversity import split_by_group, stratified_sample


@dataclass(frozen=True)
class TrainingReport:
    trajectories: int
    states: int
    motifs: int
    executable_units: int
    avg_motif_support: float
    source_manifest: str
    train_trajectories: int = 0
    validation_trajectories: int = 0
    leakage_groups: int = 0
    diversity_strata: int = 0
    candidate_score: float = 0.0
    argument_aware_units: int = 0
    offline_rl_states: int = 0
    offline_rl_actions: int = 0
    causal_procedures: int = 0

    def as_dict(self):
        return asdict(self)


def _success(t: Trajectory) -> bool:
    return not any(e.ok is False or (e.metadata or {}).get("verify_status") == "unresolved" or (e.metadata or {}).get("judge_verdict") in {"reject", "fail", "failure"} for e in t.events)


def train_from_trajectories(trajectories: Iterable[Trajectory], manifest: DatasetManifest, *, min_support: int = 2, max_len: int = 6):
    from .trajectory_compiler import compile_trajectories
    validate_manifest_for_training(manifest)
    tr = list(trajectories)
    train, val = split_by_group(tr, 0.2) if len(tr) >= 5 else (tr, [])
    train = stratified_sample(train, min(len(train), max(32, len(train))), seed=42)
    policy = TrajectoryPolicy().fit(train)
    qlearner = OfflineTrajectoryQLearner().fit(train)
    motifs = mine_motifs(train, min_support=min_support, max_len=max_len)
    procedures = mine_procedures(train, min_support=min_support, max_len=max_len)
    compiled_programs = compile_trajectories(train, manifest.digest, min_confidence=0.75)
    from .antiunify import anti_unify, compile_generalized
    generalized = anti_unify(train, min_support=max(2, min_support))
    generalized_units = compile_generalized(generalized, manifest.digest)
    # Prefer argument-aware, transition-aware procedures; fall back to legacy motifs
    # where they cover additional validated behavior.
    units = compile_procedures(procedures, manifest.digest)
    units.extend(generalized_units)
    legacy_units = compile_motifs_to_ecus(motifs, manifest.digest)
    known = {u.digest for u in units}
    for item in compiled_programs:
        if item.ecu.digest not in known:
            units.append(item.ecu)
            known.add(item.ecu.digest)
    for u in legacy_units:
        if u.digest not in known:
            units.append(u)
            known.add(u.digest)
    avg = sum(m.support_runs for m in motifs) / max(1, len(motifs))
    leakage = len({t.run_id for t in train}.intersection({t.run_id for t in val}))
    candidate_score = float(sum(_success(t) for t in val) / max(1, len(val)))
    report = TrainingReport(
        len(tr),
        policy.states,
        len(motifs),
        len(units),
        avg,
        manifest.name,
        len(train),
        len(val),
        leakage,
        len({_stratum(t) for t in train}),
        candidate_score,
        sum(1 for u in units if any(a.args for a in u.actions)),
        len({k[0] for k in qlearner.q}),
        len(qlearner.q),
        len(procedures),
    )
    return units, policy, motifs, report


def _stratum(t: Trajectory) -> tuple[str, ...]:
    vals = []
    for e in t.events:
        meta = e.metadata or {}
        vals.extend(str(meta.get(k)) for k in ("model", "teacher_model", "harness", "source", "domain") if meta.get(k) is not None)
    return tuple(sorted(set(vals)))
