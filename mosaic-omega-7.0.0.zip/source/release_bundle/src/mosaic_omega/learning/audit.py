from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable, Any

from ..ecu.core import ECUEnvironment, ExecutableComputeUnit
from ..trajectory.events import Trajectory


@dataclass(frozen=True)
class PairedAudit:
    paired_cases: int
    baseline_success: int
    skill_success: int
    repairs: int
    regressions: int
    behavior_deltas: int
    net_gain: float
    accepted: bool


def audit_skill_paired(
    units: Iterable[ExecutableComputeUnit],
    cases: Iterable[tuple[Callable[[], ECUEnvironment], Callable[[ECUEnvironment], bool], tuple[str, ...]]],
    *,
    min_quality: float = 0.95,
) -> PairedAudit:
    """Paired intervention audit: same case with and without a skill.

    This implements the strongest general lesson from 2026 skill-evolution work:
    a skill is accepted only on net improvement, explicitly counting repairs and
    regressions rather than rewarding a raw success-rate delta alone.
    """
    units = tuple(units)
    base = skill = repairs = regressions = deltas = total = 0
    for make_env, oracle, action_seq in cases:
        total += 1
        env0 = make_env()
        try:
            baseline_ok = bool(oracle(env0))
        except Exception:
            baseline_ok = False
        base += int(baseline_ok)
        env1 = make_env()
        matched = None
        for unit in units:
            names = tuple(a.name for a in unit.actions)
            if names == action_seq[:len(names)]:
                matched = unit
                break
        skill_ok = False
        if matched is not None:
            result = matched.run(env1)
            skill_ok = bool(result.success and oracle(env1))
        skill += int(skill_ok)
        repairs += int((not baseline_ok) and skill_ok)
        regressions += int(baseline_ok and not skill_ok)
        deltas += int(baseline_ok != skill_ok)
    gain = (skill - base) / max(1, total)
    accepted = (skill / max(1, total)) >= min_quality and regressions == 0 and gain >= 0.0
    return PairedAudit(total, base, skill, repairs, regressions, deltas, gain, accepted)
