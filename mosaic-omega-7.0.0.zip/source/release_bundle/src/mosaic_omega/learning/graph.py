from __future__ import annotations

from dataclasses import dataclass
from collections import defaultdict
from typing import Iterable

from ..trajectory.events import Trajectory


@dataclass(frozen=True)
class TransitionStats:
    source: str
    action: str
    target: str
    support: int
    successes: int
    failures: int
    mean_latency_ms: float
    mean_cost_usd: float

    @property
    def success_rate(self) -> float:
        return self.successes / max(1, self.successes + self.failures)


class ExecutionGraph:
    """State/action graph with uncertainty-aware transition utility."""

    def __init__(self) -> None:
        self._stats: dict[tuple[str, str, str], list[float]] = defaultdict(lambda: [0.0, 0.0, 0.0, 0.0, 0.0])

    def ingest(self, trajectories: Iterable[Trajectory]) -> None:
        for traj in trajectories:
            previous = "START"
            for event in traj.events:
                state = event.state_hash[:24] if event.state_hash else event.kind
                key = (previous, event.action.strip().lower(), state)
                stats = self._stats[key]
                stats[0] += 1
                stats[1] += float(event.ok is True)
                stats[2] += float(event.ok is False)
                stats[3] += event.latency_ms
                stats[4] += event.cost_usd
                previous = state

    def transitions(self) -> tuple[TransitionStats, ...]:
        out = []
        for (src, action, target), (support, successes, failures, latency, cost) in self._stats.items():
            out.append(TransitionStats(src, action, target, int(support), int(successes), int(failures), latency / max(1, support), cost / max(1, support)))
        return tuple(out)

    def recommend(self, state: str, actions: Iterable[str]) -> TransitionStats | None:
        allowed = {a.strip().lower() for a in actions}
        candidates = [t for t in self.transitions() if t.source == state and t.action in allowed]
        if not candidates:
            return None
        # Upper-confidence style bonus prevents early overconfidence.
        scored = []
        total = sum(t.support for t in candidates)
        for t in candidates:
            ucb = t.success_rate + (2.0 * max(1, total).bit_length() / max(1, t.support)) ** 0.5
            utility = ucb / (1.0 + t.mean_latency_ms / 1000.0 + 1000.0 * t.mean_cost_usd)
            scored.append((utility, t))
        return max(scored, key=lambda x: x[0])[1]
