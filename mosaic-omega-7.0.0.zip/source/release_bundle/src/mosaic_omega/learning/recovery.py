from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Any, Iterable

from ..ecu.core import ECUAction, ECUContract, ExecutableComputeUnit
from ..trajectory.events import Trajectory, TrajectoryEvent


@dataclass(frozen=True)
class RecoveryRule:
    error_signature: str
    actions: tuple[ECUAction, ...]
    occurrences: int
    successful_recoveries: int
    support_runs: int
    mean_latency_ms: float
    mean_cost_usd: float
    source: str

    @property
    def confidence(self) -> float:
        return self.successful_recoveries / max(1, self.occurrences)

    @property
    def digest(self) -> str:
        payload = {
            "error": self.error_signature,
            "actions": [{"name": a.name, "args": dict(a.args)} for a in self.actions],
        }
        return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()[:16]


def _error_signature(event: TrajectoryEvent) -> str | None:
    if event.kind != "error" and event.ok is not False:
        return None
    meta = event.metadata or {}
    return str(meta.get("error_signature") or event.action or "unknown_error")


def _action_signature(event: TrajectoryEvent) -> ECUAction | None:
    if not event.action or event.kind in {"error", "model_call", "message", "reasoning"}:
        return None
    args = (event.metadata or {}).get("tool_args")
    if not isinstance(args, dict):
        args = {}
    return ECUAction(event.action.strip().lower(), args=args)


def mine_recovery_rules(trajectories: Iterable[Trajectory], *, max_actions: int = 3, min_occurrences: int = 1) -> list[RecoveryRule]:
    """Mine observable error→repair sequences from real execution traces.

    This is deliberately a behavior compiler: it does not ingest hidden
    reasoning. A rule is promoted only from observable error evidence followed
    by executable tool actions and later non-error evidence.
    """
    buckets: dict[tuple[str, tuple[tuple[str, str], ...]], dict[str, Any]] = {}
    for traj in trajectories:
        events = list(traj.events)
        for idx, event in enumerate(events):
            error = _error_signature(event)
            if not error:
                continue
            future: list[ECUAction] = []
            lat = 0.0
            cost = 0.0
            recovered = False
            collecting = True
            for nxt in events[idx + 1 : idx + 1 + max_actions + 4]:
                action = _action_signature(nxt)
                if collecting:
                    if action is not None:
                        future.append(action)
                        lat += nxt.latency_ms
                        cost += nxt.cost_usd
                        if len(future) >= max_actions:
                            collecting = False
                        continue
                    if nxt.kind == "error" or nxt.ok is False:
                        continue
                    if future and nxt.ok is True:
                        recovered = True
                        break
                else:
                    # After the minimal repair sequence has been collected,
                    # the very next successful executable action is evidence
                    # that the recovery path remained viable. Any new error
                    # invalidates the candidate.
                    if nxt.kind == "error" or nxt.ok is False:
                        break
                    if action is not None and nxt.ok is True:
                        recovered = True
                        break
                    if nxt.ok is True and future:
                        recovered = True
                        break
            if not future:
                continue
            key = (error, tuple((a.name, json.dumps(dict(a.args), sort_keys=True, separators=(",", ":"))) for a in future))
            bucket = buckets.setdefault(key, {"occ": 0, "rec": 0, "runs": set(), "lat": 0.0, "cost": 0.0})
            bucket["occ"] += 1
            bucket["rec"] += int(recovered)
            bucket["runs"].add(traj.run_id)
            bucket["lat"] += lat
            bucket["cost"] += cost

    rules: list[RecoveryRule] = []
    for (error, action_key), b in buckets.items():
        if b["occ"] < min_occurrences:
            continue
        actions = tuple(ECUAction(name, args=json.loads(raw_args)) for name, raw_args in action_key)
        rules.append(RecoveryRule(
            error_signature=error,
            actions=actions,
            occurrences=b["occ"],
            successful_recoveries=b["rec"],
            support_runs=len(b["runs"]),
            mean_latency_ms=b["lat"] / max(1, b["occ"]),
            mean_cost_usd=b["cost"] / max(1, b["occ"]),
            source="github-observed-trace",
        ))
    rules.sort(key=lambda r: (-r.confidence, -r.support_runs, -r.occurrences, r.error_signature, r.digest))
    return rules


def compile_recovery_rules(rules: Iterable[RecoveryRule], source_manifest: str, *, min_confidence: float = 0.75) -> list[ExecutableComputeUnit]:
    units: list[ExecutableComputeUnit] = []
    for rule in rules:
        if rule.confidence < min_confidence:
            continue
        contract = ECUContract(
            name=f"recovery_{rule.digest}",
            preconditions=(f"error:{rule.error_signature}",),
            postconditions=("recovery-attempted",),
            max_steps=len(rule.actions),
            tags=("recovery", "github-observed", f"confidence:{rule.confidence:.3f}"),
        )
        units.append(ExecutableComputeUnit(contract, rule.actions, {
            "source_manifest": source_manifest,
            "error_signature": rule.error_signature,
            "occurrences": rule.occurrences,
            "successful_recoveries": rule.successful_recoveries,
            "support_runs": rule.support_runs,
            "mean_latency_ms": rule.mean_latency_ms,
            "mean_cost_usd": rule.mean_cost_usd,
        }))
    return units
