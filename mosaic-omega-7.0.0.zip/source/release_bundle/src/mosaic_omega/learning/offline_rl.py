from __future__ import annotations

from dataclasses import dataclass
from collections import defaultdict
from typing import Iterable

from ..trajectory.events import Trajectory, TrajectoryEvent

@dataclass(frozen=True)
class QValue:
    state: str
    action: str
    value: float
    support: int

class OfflineTrajectoryQLearner:
    """Deterministic offline policy iteration over observed execution traces.

    The learner optimizes verified outcome, latency, monetary cost and failure
    penalties. It never invents an unseen action, making the result safe to pair
    with an executable-unit library and a frontier residue fallback.
    """
    def __init__(self, gamma: float = 0.97, failure_penalty: float = 1.0):
        self.gamma = gamma
        self.failure_penalty = failure_penalty
        self.q: dict[tuple[str, str], float] = defaultdict(float)
        self.counts: dict[tuple[str, str], int] = defaultdict(int)

    @staticmethod
    def _state(e: TrajectoryEvent | None) -> str:
        return (e.state_hash or e.kind if e else "START")[:32]

    @staticmethod
    def _reward(e: TrajectoryEvent, terminal_success: bool) -> float:
        reward = 1.0 if terminal_success and e.kind in {"verify", "benchmark"} and e.ok is True else 0.0
        if e.ok is False:
            reward -= 1.0
        reward -= min(0.5, e.cost_usd * 1000.0)
        reward -= min(0.5, e.latency_ms / 10000.0)
        return reward

    def fit(self, trajectories: Iterable[Trajectory], iterations: int = 6) -> "OfflineTrajectoryQLearner":
        traces = list(trajectories)
        actions_by_state: dict[str, set[str]] = defaultdict(set)
        for t in traces:
            for e in t.events:
                if e.action:
                    actions_by_state[self._state(e)].add(e.action.strip().lower())
        for _ in range(max(1, iterations)):
            for t in traces:
                success = not any(e.ok is False for e in t.events)
                for i, e in enumerate(t.events):
                    if not e.action:
                        continue
                    s = self._state(t.events[i-1] if i else None)
                    a = e.action.strip().lower()
                    ns = self._state(e)
                    next_best = max((self.q[(ns, na)] for na in actions_by_state.get(ns, ())), default=0.0)
                    target = self._reward(e, success) + self.gamma * next_best
                    key = (s, a)
                    self.q[key] = 0.8 * self.q[key] + 0.2 * target
                    self.counts[key] += 1
        return self

    def best(self, state: str, allowed_actions: Iterable[str] | None = None) -> QValue | None:
        allowed = {a.lower() for a in allowed_actions} if allowed_actions is not None else None
        candidates = [(k, v) for k, v in self.q.items() if k[0] == state and (allowed is None or k[1] in allowed)]
        if not candidates:
            return None
        (s, a), value = max(candidates, key=lambda kv: (kv[1], self.counts[kv[0]], kv[0][1]))
        return QValue(s, a, value, self.counts[(s, a)])
