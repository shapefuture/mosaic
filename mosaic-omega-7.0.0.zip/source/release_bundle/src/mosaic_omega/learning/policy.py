from __future__ import annotations

from dataclasses import dataclass
from collections import defaultdict
from typing import Iterable

from ..trajectory.events import Trajectory, TrajectoryEvent
from ..trajectory.efficiency import analyze_efficiency


@dataclass(frozen=True)
class PolicyDecision:
    action: str
    confidence: float
    expected_success: float
    expected_latency_ms: float
    expected_cost_usd: float
    uncertainty: float = 0.0


class TrajectoryPolicy:
    """Uncertainty-aware cost-sensitive offline policy learner.

    The policy is intentionally non-generative: it selects from observed actions
    and exposes uncertainty, making it safe to pair with a frontier residue router.
    """

    def __init__(self) -> None:
        self._stats: dict[tuple[str, str], list[float]] = defaultdict(lambda: [0, 0, 0, 0.0, 0.0, 0.0])

    @staticmethod
    def _state(event: TrajectoryEvent) -> str:
        base = event.state_hash[:24] if event.state_hash else event.kind
        rs = (event.metadata or {}).get("reasoning_signals")
        if isinstance(rs, dict):
            anchors = tuple(str(rs.get(k, ""))[:96] for k in ("goal", "hypothesis", "decision", "uncertainty") if rs.get(k))
            if anchors:
                import hashlib
                return base + ":r:" + hashlib.sha256("|".join(anchors).encode()).hexdigest()[:16]
        return base

    def fit(self, trajectories: Iterable[Trajectory]) -> "TrajectoryPolicy":
        for traj in trajectories:
            eff = analyze_efficiency(traj).efficiency
            final_success = not any(e.ok is False or (e.metadata or {}).get("verify_status") == "unresolved" for e in traj.events)
            for event in traj.events:
                key = (self._state(event), event.action.strip().lower())
                s = self._stats[key]
                s[0] += 1
                s[1] += 1 if (event.ok is True or final_success) else 0
                s[2] += 1 if event.ok is False else 0
                s[3] += event.latency_ms
                s[4] += event.cost_usd
                s[5] += eff
        return self

    def recommend(self, state: str, actions: Iterable[str], max_cost: float | None = None) -> PolicyDecision | None:
        candidates: list[tuple[float, PolicyDecision]] = []
        action_list = list(dict.fromkeys(a.lower() for a in actions))
        total = sum(self._stats.get((state, a), [0])[0] for a in action_list)
        for action in action_list:
            s = self._stats.get((state, action))
            if not s:
                continue
            count, succ, fail, latency, cost, eff_sum = s
            success = succ / max(1.0, succ + fail)
            mean_latency = latency / max(1.0, count)
            mean_cost = cost / max(1.0, count)
            if max_cost is not None and mean_cost > max_cost:
                continue
            uncertainty = min(1.0, 1.0 / max(1.0, count) ** 0.5)
            exploration = (2.0 * (max(1.0, total).bit_length() / max(1.0, count))) ** 0.5
            utility = (success + exploration * uncertainty) / (1.0 + mean_latency / 1000.0 + 1000.0 * mean_cost)
            candidates.append((utility, PolicyDecision(action, min(1.0, count / 10.0), success, mean_latency, mean_cost, uncertainty)))
        return max(candidates, key=lambda x: x[0])[1] if candidates else None

    @property
    def states(self) -> int:
        return len({k[0] for k in self._stats})
