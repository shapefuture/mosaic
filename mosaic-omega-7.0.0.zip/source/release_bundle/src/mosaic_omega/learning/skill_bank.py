from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any, Iterable, Mapping

from ..ecu.core import ECUEnvironment, ExecutableComputeUnit, ExecutionResult


@dataclass(frozen=True)
class SkillRecord:
    key: str
    unit_digest: str
    success_rate: float
    mean_latency_ms: float
    mean_cost_usd: float
    calls_saved: int
    regressions: int
    provenance: Mapping[str, Any] = field(default_factory=dict)

    @property
    def roi(self) -> float:
        savings = max(0.0, float(self.calls_saved) - 10.0 * float(self.regressions))
        return savings * max(0.0, self.success_rate) / (1.0 + self.mean_latency_ms + 1e6 * self.mean_cost_usd)


class SkillBank:
    """Persistent in-process catalog of verified ECUs with ROI-aware selection."""

    def __init__(self) -> None:
        self._skills: dict[str, tuple[ExecutableComputeUnit, SkillRecord]] = {}

    @staticmethod
    def key_for(actions: Iterable[str], state_signature: str = "") -> str:
        payload = "|".join(a.strip().lower() for a in actions) + "|" + state_signature
        return sha256(payload.encode()).hexdigest()[:24]

    def register(self, unit: ExecutableComputeUnit, *, actions: Iterable[str], state_signature: str = "", success_rate: float = 1.0, mean_latency_ms: float = 0.0, mean_cost_usd: float = 0.0, calls_saved: int = 0, regressions: int = 0) -> SkillRecord:
        key = self.key_for(actions, state_signature)
        record = SkillRecord(key, unit.digest, success_rate, mean_latency_ms, mean_cost_usd, calls_saved, regressions, dict(unit.provenance))
        self._skills[key] = (unit, record)
        return record

    def candidates(self, actions: Iterable[str], state_signature: str = "") -> list[tuple[ExecutableComputeUnit, SkillRecord]]:
        key = self.key_for(actions, state_signature)
        exact = self._skills.get(key)
        if exact:
            return [exact]
        target = tuple(a.strip().lower() for a in actions)
        scored = []
        for unit, record in self._skills.values():
            names = tuple(a.name.strip().lower() for a in unit.actions)
            common = len(set(names) & set(target)) / max(1, len(set(names) | set(target)))
            scored.append((common, record.roi, unit, record))
        return [(u, r) for common, roi, u, r in sorted(scored, key=lambda x: (-x[0], -x[1], x[2].digest)) if common >= 0.5][:16]

    def execute(self, actions: Iterable[str], env: ECUEnvironment, *, state_signature: str = "", params: Mapping[str, Any] | None = None) -> tuple[SkillRecord | None, ExecutionResult | None]:
        cands = self.candidates(actions, state_signature)
        if not cands:
            return None, None
        unit, record = max(cands, key=lambda x: x[1].roi)
        if params:
            env.params.update(params)
        result = unit.run(env)
        return record, result

    def snapshot(self) -> list[dict[str, Any]]:
        return [
            {"key": r.key, "unit_digest": r.unit_digest, "success_rate": r.success_rate, "latency_ms": r.mean_latency_ms, "cost_usd": r.mean_cost_usd, "calls_saved": r.calls_saved, "regressions": r.regressions, "roi": r.roi, "provenance": dict(r.provenance)}
            for _, r in sorted(self._skills.values(), key=lambda x: (-x[1].roi, x[1].key))
        ]
