from __future__ import annotations

from dataclasses import dataclass, asdict
import hashlib
import json
from typing import Any, Iterable, Sequence

from ..ecu.core import ECUAction
from ..trajectory.events import Trajectory, TrajectoryEvent


@dataclass(frozen=True)
class RecoveryProgram:
    trigger: str
    actions: tuple[ECUAction, ...]
    verify: str
    confidence: float
    support: int
    sources: tuple[str, ...]

    @property
    def digest(self) -> str:
        payload = json.dumps(asdict(self), sort_keys=True, default=lambda o: asdict(o) if hasattr(o, '__dataclass_fields__') else str(o), separators=(",", ":"))
        return hashlib.sha256(payload.encode()).hexdigest()[:20]

    def as_dict(self) -> dict[str, Any]:
        return {"trigger": self.trigger, "actions":[asdict(a) for a in self.actions], "verify":self.verify, "confidence":self.confidence, "support":self.support, "sources":list(self.sources), "digest":self.digest}


def _norm_name(event: TrajectoryEvent) -> str:
    return (event.action or "").strip().lower()


def compile_cross_source_recovery(trajectories: Iterable[Trajectory], *, max_actions: int = 3, min_support: int = 1) -> list[RecoveryProgram]:
    """Cross-source, cause→repair compiler with variable-friendly parameter retention."""
    buckets: dict[tuple[str, tuple[str, ...], str], dict[str, Any]] = {}
    for traj in trajectories:
        events = list(traj.events)
        for i, event in enumerate(events):
            if event.kind != "error" and event.ok is not False:
                continue
            trigger = str((event.metadata or {}).get("error_signature") or event.action or "unknown_error")
            actions: list[ECUAction] = []
            verify = ""
            for nxt in events[i+1: i+1+max_actions+6]:
                if nxt.kind == "error" or nxt.ok is False:
                    break
                if nxt.action and nxt.kind not in {"message", "reasoning"}:
                    args = dict((nxt.metadata or {}).get("tool_args") or {})
                    actions.append(ECUAction(_norm_name(nxt), args=args))
                    if len(actions) >= max_actions:
                        continue
                if nxt.ok is True and actions:
                    verify = "success"
                    break
            if not actions or verify != "success":
                continue
            key = (trigger, tuple(a.name for a in actions), verify)
            b = buckets.setdefault(key, {"support":0, "runs":set(), "args":actions})
            b["support"] += 1
            b["runs"].add(traj.run_id)
    out=[]
    for (trigger, names, verify), b in buckets.items():
        if b["support"] < min_support:
            continue
        confidence=min(0.99, 0.5 + 0.15*b["support"])
        out.append(RecoveryProgram(trigger, tuple(b["args"]), verify, confidence, b["support"], tuple(sorted(b["runs"]))))
    out.sort(key=lambda p:(-p.confidence,-p.support,p.trigger,p.digest))
    return out
