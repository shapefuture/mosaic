from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from typing import Iterable, Mapping, Sequence

from ..ecu.core import ECUAction, ECUContract, ExecutableComputeUnit
from ..runtime.agent_program import AgentProgramCompiler, ProgramNode
from ..trajectory.events import Trajectory, TrajectoryEvent


@dataclass(frozen=True)
class CompiledTrajectory:
    trajectory_id: str
    ecu: ExecutableComputeUnit
    program_digest: str
    original_steps: int
    compiled_steps: int
    frontier_nodes: int
    fused_groups: int
    context_dedup: int
    confidence: float


def _args(event: TrajectoryEvent) -> dict:
    meta = event.metadata or {}
    if isinstance(meta.get("tool_args"), dict):
        return dict(meta["tool_args"])
    try:
        obj = json.loads(event.observation or "")
        return dict(obj) if isinstance(obj, dict) else ({"raw": event.observation[:512]} if event.observation else {})
    except Exception:
        return {"raw": event.observation[:512]} if event.observation else {}


def compile_trajectory(traj: Trajectory, source_manifest: str, *, min_confidence: float = 0.75) -> CompiledTrajectory | None:
    events = [e for e in traj.events if e.action]
    if not events:
        return None
    nodes: list[ProgramNode] = []
    for i, e in enumerate(events):
        kind = e.kind.lower()
        capability = str((e.metadata or {}).get("capability") or ("frontier" if kind in {"reasoning", "message"} and (e.metadata or {}).get("teacher_model") else "cpu"))
        deps = (str(i - 1),) if i else ()
        deterministic = not (kind in {"reasoning", "message"} or capability == "frontier")
        context = str((e.metadata or {}).get("context") or e.observation[:2048])
        rs = (e.metadata or {}).get("reasoning_signals")
        if isinstance(rs, Mapping):
            reasoning_context = " | ".join(
                f"{k}={rs.get(k)}" for k in ("goal", "hypothesis", "evidence", "decision", "uncertainty", "expected_effect", "contradiction", "rationale")
                if rs.get(k)
            )
            if reasoning_context:
                context = (reasoning_context + " || " + context)[:4096]
        nodes.append(ProgramNode(
            str(i), kind, ECUAction(e.action.strip().lower(), args=_args(e), expected_state={}), deps,
            capability, float(e.latency_ms), float(e.cost_usd), context, deterministic,
        ))
    compiler = AgentProgramCompiler()
    program = compiler.compile(nodes, enable_fusion=False)
    # Only compile stable deterministic programs unless their frontier residue is small.
    frontier = sum(1 for n in program.nodes if n.capability == "frontier")
    confidence = max(0.0, min(1.0, 1.0 - frontier / max(1, len(program.nodes))))
    if confidence < min_confidence:
        return None
    actions = tuple(n.action for n in program.nodes if n.action is not None)
    digest = sha256(f"{source_manifest}|{traj.run_id}|{program.digest}".encode()).hexdigest()[:16]
    contract = ECUContract(
        name=f"program_{digest}",
        max_steps=len(actions),
        tags=("trajectory-compiled", "dataflow", "context-dedup", "reasoning-fusion"),
    )
    ecu = ExecutableComputeUnit(contract, actions, {
        "source_manifest": source_manifest,
        "trajectory_id": traj.run_id,
        "program_digest": program.digest,
        "confidence": confidence,
        "original_steps": len(events),
        "compiled_steps": len(actions),
        "frontier_nodes": frontier,
        "fused_groups": len(program.fused_nodes),
        "context_dedup": program.dedup_contexts,
        "reasoning_signal_nodes": sum(1 for e in events if isinstance((e.metadata or {}).get("reasoning_signals"), Mapping)),
    })
    return CompiledTrajectory(traj.run_id, ecu, program.digest, len(events), len(actions), frontier, len(program.fused_nodes), program.dedup_contexts, confidence)


def compile_trajectories(trajectories: Iterable[Trajectory], source_manifest: str, *, min_confidence: float = 0.75) -> list[CompiledTrajectory]:
    out = []
    for traj in trajectories:
        item = compile_trajectory(traj, source_manifest, min_confidence=min_confidence)
        if item is not None:
            out.append(item)
    out.sort(key=lambda x: (-x.confidence, x.compiled_steps, x.trajectory_id))
    return out
