from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Sequence

from ..ecu.core import ECUAction, ECUContract, ExecutableComputeUnit
from ..trajectory.events import Trajectory, TrajectoryEvent
from .procedures import _norm_action, _success


@dataclass(frozen=True)
class GeneralizedProcedure:
    action_names: tuple[str, ...]
    actions: tuple[ECUAction, ...]
    support: int
    successful: int
    parameter_count: int
    generalization_score: float


def _merge_value(values: Sequence[Any], key: str) -> tuple[Any, bool]:
    first = values[0]
    if all(v == first for v in values[1:]):
        return first, False
    return f"$param.{key}", True


def _is_executable_event(e: TrajectoryEvent) -> bool:
    """Keep actions that can be dispatched locally; reasoning/observation text is metadata.

    Verify/benchmark/check events remain executable because they often encode the
    contract boundary that makes a distilled unit independently verifiable.
    """
    return e.kind.lower() not in {"reasoning", "message", "thought", "analysis", "observe", "retrieval", "retrieve"}


def anti_unify(trajectories: Iterable[Trajectory], *, min_support: int = 2) -> list[GeneralizedProcedure]:
    """Generalize repeated successful procedures by replacing varying arguments with parameters."""
    runs = [t for t in trajectories if _success(t)]
    buckets: dict[tuple[str, ...], list[list[tuple[str, dict]]]] = {}
    for t in runs:
        norm = [_norm_action(e) for e in t.events if e.action and _is_executable_event(e)]
        for n in range(1, min(8, len(norm)) + 1):
            for i in range(len(norm) - n + 1):
                seq = norm[i:i+n]
                names = tuple(x[0] for x in seq)
                buckets.setdefault(names, []).append(seq)
    out: list[GeneralizedProcedure] = []
    for names, seqs in buckets.items():
        if len(seqs) < min_support:
            continue
        # Use only the first min_support*4 representatives to bound search.
        seqs = seqs[:min(len(seqs), min_support * 4)]
        actions: list[ECUAction] = []
        params = 0
        for pos, name in enumerate(names):
            keys = sorted({k for seq in seqs for k in seq[pos][1]})
            args: dict[str, Any] = {}
            for key in keys:
                vals = [seq[pos][1].get(key) for seq in seqs]
                value, variable = _merge_value(vals, f"{pos}.{key}")
                args[key] = value
                params += int(variable)
            actions.append(ECUAction(name, args=args))
        score = 1.0 / (1.0 + params / max(1, len(actions)))
        out.append(GeneralizedProcedure(names, tuple(actions), len(seqs), len(seqs), params, score))
    out.sort(key=lambda p: (-p.generalization_score, -p.support, len(p.actions), p.action_names))
    return out


def compile_generalized(procedures: Iterable[GeneralizedProcedure], source_manifest: str, *, min_score: float = 0.5) -> list[ExecutableComputeUnit]:
    units: list[ExecutableComputeUnit] = []
    seen: set[tuple[str, ...]] = set()
    for p in procedures:
        if p.generalization_score < min_score or p.action_names in seen:
            continue
        seen.add(p.action_names)
        contract = ECUContract(
            name="genu_" + "_".join(p.action_names)[:48],
            max_steps=len(p.actions),
            tags=("anti-unified", "parameterized", "trajectory-derived"),
        )
        units.append(ExecutableComputeUnit(contract, p.actions, {
            "source_manifest": source_manifest,
            "support": p.support,
            "parameter_count": p.parameter_count,
            "generalization_score": p.generalization_score,
        }))
    return units
