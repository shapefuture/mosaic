from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Iterable, Sequence

from ..data.frontier import DatasetManifest, validate_manifest_for_training
from ..trajectory.events import Trajectory
from .diversity import split_by_group, stratified_sample
from .motifs import Motif, compile_motifs_to_ecus, mine_motifs


@dataclass(frozen=True)
class SkillEdit:
    op: str
    rule: str
    support: int
    success_rate: float
    reason: str


@dataclass(frozen=True)
class GateResult:
    baseline: float
    candidate: float
    accepted: bool
    reason: str


@dataclass(frozen=True)
class SuperiorityReport:
    train_trajectories: int
    validation_trajectories: int
    motifs_seen: int
    candidate_units: int
    accepted_units: int
    rejected_edits: int
    baseline_validation_score: float
    candidate_validation_score: float
    planning_step_reduction: float
    frontier_call_reduction: float
    compression_ratio: float
    holdout_leakage_groups: int
    diversity_strata: int

    def as_dict(self):
        return asdict(self)


def _success(t: Trajectory) -> bool:
    if any(e.ok is False for e in t.events):
        return False
    for e in t.events:
        meta = e.metadata or {}
        if meta.get("verify_status") == "unresolved":
            return False
        if meta.get("judge_verdict") in {"reject", "fail", "failure"}:
            return False
    return any(e.ok is True or (e.metadata or {}).get("verify_status") == "resolved" or (e.metadata or {}).get("judge_verdict") in {"accept", "pass"} for e in t.events)


def _action_set(t: Trajectory) -> set[str]:
    return {e.action.strip().lower() for e in t.events if e.action}


def _validation_score(trajectories: Sequence[Trajectory], accepted_motifs: Sequence[Motif]) -> float:
    if not trajectories:
        return 0.0
    motif_sets = [set(m.actions) for m in accepted_motifs]
    scores = []
    for t in trajectories:
        actions = _action_set(t)
        coverage = max((len(actions.intersection(ms)) / max(1, len(ms)) for ms in motif_sets), default=0.0)
        quality = 1.0 if _success(t) else 0.0
        scores.append(0.7 * quality + 0.3 * coverage)
    return sum(scores) / len(scores)


def _contrastive_edits(train: Sequence[Trajectory], motifs: Sequence[Motif], learning_rate: int) -> tuple[list[SkillEdit], list[SkillEdit]]:
    failed_actions: set[str] = set()
    success_actions: set[str] = set()
    for t in train:
        (success_actions if _success(t) else failed_actions).update(_action_set(t))
    edits: list[SkillEdit] = []
    rejected: list[SkillEdit] = []
    for motif in motifs:
        if motif.success_runs < max(1, motif.support_runs):
            continue
        if any(a in failed_actions and a not in success_actions for a in motif.actions):
            rejected.append(SkillEdit("add", "avoid:" + " -> ".join(motif.actions), motif.support_runs, 0.0, "action appears only in failures"))
            continue
        edits.append(SkillEdit("add", "prefer:" + " -> ".join(motif.actions), motif.support_runs, motif.success_runs / max(1, motif.support_runs), "stable high-support procedure"))
    edits.sort(key=lambda e: (-e.success_rate, -e.support, e.rule))
    return edits[:learning_rate], rejected


def train_skill_evidence(
    trajectories: Iterable[Trajectory],
    manifest: DatasetManifest,
    *,
    epochs: int = 3,
    batch_size: int = 64,
    learning_rate: int = 8,
    validation_fraction: float = 0.2,
    seed: int = 42,
) -> tuple[list, list[SkillEdit], SuperiorityReport]:
    """Train a compact execution skill layer with held-out gating.

    This is intentionally model-free: the learned artifact is an executable
    procedure set. A remote optimizer/LLM can later propose richer edits, but
    the acceptance gate remains deterministic and held-out.
    """
    validate_manifest_for_training(manifest)
    all_tr = list(trajectories)
    train, val = split_by_group(all_tr, validation_fraction)
    train = stratified_sample(train, min(len(train), max(batch_size, 4 * batch_size)), seed=seed)
    accepted_motifs: list[Motif] = []
    accepted_units = []
    all_rejected = 0
    best_score = _validation_score(val, accepted_motifs)
    all_edits: list[SkillEdit] = []

    for _epoch in range(max(1, epochs)):
        successful_train = [t for t in train if _success(t)]
        motifs = mine_motifs(successful_train, min_support=max(2, min(8, len(successful_train))), max_len=8)
        edits, rejected = _contrastive_edits(train, motifs, learning_rate)
        all_rejected += len(rejected)
        for edit in edits:
            target_actions = tuple(edit.rule.split(":", 1)[1].split(" -> "))
            candidate = [m for m in motifs if m.actions == target_actions]
            proposed = accepted_motifs + candidate
            score = _validation_score(val, proposed)
            if score > best_score + 1e-12:
                accepted_motifs = proposed
                best_score = score
                all_edits.append(edit)
            else:
                all_rejected += 1
        if len(train) > batch_size:
            # Slow/meta step: mine across the full diverse training pool and retain only
            # a strictly improving consolidated motif set.
            meta = mine_motifs([t for t in all_tr if _success(t)], min_support=max(2, min(12, len([t for t in all_tr if _success(t)]))), max_len=8)
            candidate = accepted_motifs + [m for m in meta if m not in accepted_motifs][:learning_rate]
            score = _validation_score(val, candidate)
            if score > best_score + 1e-12:
                accepted_motifs = candidate
                best_score = score

    accepted_units = compile_motifs_to_ecus(accepted_motifs, manifest.digest)
    compression = 1.0
    if all_tr:
        baseline_steps = sum(len(t.events) for t in all_tr)
        compiled_steps = sum(len(m.actions) for m in accepted_motifs)
        compression = max(0.0, 1.0 - compiled_steps / max(1, baseline_steps))
    leakage_groups = len({t.run_id for t in train}.intersection({t.run_id for t in val}))
    strata = len({_stratum(t) for t in train})
    report = SuperiorityReport(
        train_trajectories=len(train),
        validation_trajectories=len(val),
        motifs_seen=len(mine_motifs([t for t in train if _success(t)], min_support=max(2, min(8, len([t for t in train if _success(t)]))), max_len=8)),
        candidate_units=len(accepted_units),
        accepted_units=len(accepted_units),
        rejected_edits=all_rejected,
        baseline_validation_score=_validation_score(val, []),
        candidate_validation_score=best_score,
        planning_step_reduction=compression,
        frontier_call_reduction=1.0 if accepted_units else 0.0,
        compression_ratio=compression,
        holdout_leakage_groups=leakage_groups,
        diversity_strata=strata,
    )
    return accepted_units, all_edits, report


def _stratum(t: Trajectory) -> tuple[str, ...]:
    keys = []
    for e in t.events:
        meta = e.metadata or {}
        keys.extend(str(meta.get(k)) for k in ("model", "teacher_model", "harness", "source", "domain") if meta.get(k) is not None)
    return tuple(sorted(set(keys)))
