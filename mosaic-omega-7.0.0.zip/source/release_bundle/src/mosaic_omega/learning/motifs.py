from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from hashlib import sha256
from typing import Iterable

from ..trajectory.events import Trajectory
from ..ecu.core import ECUAction, ECUContract, ExecutableComputeUnit


@dataclass(frozen=True)
class Motif:
    actions: tuple[str, ...]
    support_runs: int
    total_occurrences: int
    success_runs: int
    failure_runs: int
    mean_latency_ms: float
    mean_cost_usd: float
    state_consistency: float = 1.0

    @property
    def success_rate(self) -> float:
        return self.success_runs / max(1, self.success_runs + self.failure_runs)

    @property
    def utility(self) -> float:
        return (
            self.success_rate
            * self.state_consistency
            * self.support_runs
            / (1.0 + self.mean_latency_ms / 1000.0 + 1000.0 * self.mean_cost_usd)
        )


def _action(e) -> str:
    return e.action.strip().lower().split(".")[-1][:96]


def _success(t: Trajectory) -> bool:
    for e in t.events:
        meta = e.metadata or {}
        if e.ok is False or meta.get("verify_status") == "unresolved" or meta.get("judge_verdict") in {"reject", "fail", "failure"}:
            return False
    return any(e.ok is True or (e.metadata or {}).get("verify_status") == "resolved" or (e.metadata or {}).get("judge_verdict") in {"accept", "pass"} for e in t.events)


def mine_motifs(trajectories: Iterable[Trajectory], *, min_support: int = 2, max_len: int = 8) -> list[Motif]:
    """Mine repeated contiguous sub-trajectories across source runs.

    Support is measured by unique run IDs, not rows. Motifs retain contrastive
    failure support and state consistency so the compiler can reject fragile
    shortcuts that only correlate with success.
    """
    runs = list(trajectories)
    counts: Counter[tuple[str, ...]] = Counter()
    run_support: dict[tuple[str, ...], set[str]] = defaultdict(set)
    success_support: dict[tuple[str, ...], set[str]] = defaultdict(set)
    failure_support: dict[tuple[str, ...], set[str]] = defaultdict(set)
    latency: Counter[tuple[str, ...]] = Counter()
    cost: Counter[tuple[str, ...]] = Counter()
    state_values: dict[tuple[str, ...], set[tuple[str, ...]]] = defaultdict(set)

    for t in runs:
        acts = [_action(e) for e in t.events if e.action]
        states = [e.state_hash[:16] if e.state_hash else e.kind for e in t.events if e.action]
        good = _success(t)
        for n in range(1, min(max_len, len(acts)) + 1):
            seen: set[tuple[str, ...]] = set()
            for i in range(len(acts) - n + 1):
                gram = tuple(acts[i:i + n])
                if gram in seen:
                    continue
                seen.add(gram)
                counts[gram] += 1
                run_support[gram].add(t.run_id)
                (success_support if good else failure_support)[gram].add(t.run_id)
                latency[gram] += sum(e.latency_ms for e in t.events[i:i + n])
                cost[gram] += sum(e.cost_usd for e in t.events[i:i + n])
                state_values[gram].add(tuple(states[i:i + n]))

    motifs: list[Motif] = []
    for gram, occ in counts.items():
        support = len(run_support[gram])
        if support < min_support:
            continue
        states = state_values[gram]
        # Reward deterministic state transition structure while tolerating
        # equivalent traces with missing state hashes.
        consistency = 1.0 if len(states) <= max(1, support // 2) else 0.5
        motifs.append(Motif(
            gram,
            support,
            occ,
            len(success_support[gram]),
            len(failure_support[gram]),
            latency[gram] / max(1, occ),
            cost[gram] / max(1, occ),
            consistency,
        ))
    motifs.sort(key=lambda m: (-m.utility, -m.support_runs, -len(m.actions), m.actions))
    return motifs


def compile_motifs_to_ecus(motifs: Iterable[Motif], source_manifest: str) -> list[ExecutableComputeUnit]:
    units: list[ExecutableComputeUnit] = []
    seen: set[tuple[str, ...]] = set()
    for motif in motifs:
        # Production invariant: only compile motifs that have no observed
        # counterexamples and have stable state structure.
        if motif.success_rate < 1.0 or motif.state_consistency < 0.99 or motif.actions in seen:
            continue
        seen.add(motif.actions)
        stable = sha256((source_manifest + "|" + "|".join(motif.actions)).encode()).hexdigest()[:16]
        tags = (
            "distilled", "motif", "verified-candidate",
            f"support:{motif.support_runs}", f"utility:{motif.utility:.6f}",
        )
        contract = ECUContract(name=f"ecu_{stable}", max_steps=len(motif.actions), tags=tags)
        provenance = {
            "source_manifest": source_manifest,
            "method": "contrastive-motif-induction-v3",
            "support_runs": motif.support_runs,
            "success_runs": motif.success_runs,
            "failure_runs": motif.failure_runs,
            "state_consistency": motif.state_consistency,
            "mean_latency_ms": motif.mean_latency_ms,
            "mean_cost_usd": motif.mean_cost_usd,
        }
        units.append(ExecutableComputeUnit(contract, tuple(ECUAction(a) for a in motif.actions), provenance))
    return units
