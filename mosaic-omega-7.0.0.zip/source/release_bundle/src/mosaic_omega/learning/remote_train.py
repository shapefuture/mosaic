from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Iterator, Mapping

from .optimizer import train_skill_evidence
from ..data.frontier import DatasetManifest, orchard_row_to_event_dict, gpt56_row_to_event_dict
from ..trajectory.events import Trajectory, TrajectoryEvent


@dataclass(frozen=True)
class RemoteDatasetSpec:
    dataset: str
    config: str
    split: str = "train"
    revision: str = "main"
    row_limit: int | None = None
    streaming: bool = True


def _to_traj(obj: Mapping[str, Any]) -> Trajectory:
    return Trajectory(obj["run_id"], tuple(TrajectoryEvent(**e) for e in obj["events"]))


def iter_hf_rows(spec: RemoteDatasetSpec) -> Iterator[Mapping[str, Any]]:
    """Stream from Hugging Face when network access is available externally.

    Uses the datasets library's streaming path if installed; otherwise raises a
    clear deployment error. Production deployments should run this outside the
    ChatGPT sandbox via Secure MCP / worker infrastructure.
    """
    try:
        from datasets import load_dataset
    except ImportError as exc:
        raise RuntimeError("remote HF ingestion requires `datasets`; run the worker outside the sandbox") from exc
    ds = load_dataset(spec.dataset, spec.config, split=spec.split, revision=spec.revision, streaming=spec.streaming)
    for i, row in enumerate(ds):
        if spec.row_limit is not None and i >= spec.row_limit:
            break
        yield row


def stream_to_trajectories(spec: RemoteDatasetSpec) -> Iterator[Trajectory]:
    adapter = "orchard" if spec.dataset.lower().endswith("orchard") else "gpt56"
    for i, row in enumerate(iter_hf_rows(spec)):
        obj = orchard_row_to_event_dict(row, i) if adapter == "orchard" else gpt56_row_to_event_dict(row)
        yield _to_traj(obj)
