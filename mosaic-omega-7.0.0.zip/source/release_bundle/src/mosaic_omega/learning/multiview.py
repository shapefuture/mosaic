from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Iterable, Mapping, Sequence

from ..trajectory.events import Trajectory, TrajectoryEvent


@dataclass(frozen=True)
class ViewArtifact:
    """One independently learned view of a trajectory corpus."""
    name: str
    examples: int
    features: int
    rules: int
    coverage: float
    confidence: float
    predictions: int


@dataclass(frozen=True)
class MultiViewReport:
    """Ablation report for reasoning-only, execution-only and joint learning."""
    trajectories: int
    reasoning_examples: int
    execution_examples: int
    joint_examples: int
    reasoning: ViewArtifact
    execution: ViewArtifact
    joint: ViewArtifact
    fused: ViewArtifact
    joint_gain_vs_reasoning: float
    joint_gain_vs_execution: float
    fusion_gain_vs_best_single: float


@dataclass
class _RuleTable:
    counts: dict[str, Counter[str]] = field(default_factory=lambda: defaultdict(Counter))

    def add(self, key: str, value: str) -> None:
        self.counts[key][value] += 1

    def best(self, key: str) -> tuple[str, float] | None:
        c = self.counts.get(key)
        if not c:
            return None
        value, count = c.most_common(1)[0]
        total = sum(c.values())
        return value, count / max(1, total)

    @property
    def rules(self) -> int:
        return len(self.counts)


def _reasoning_key(meta: Mapping[str, object]) -> str:
    rs = meta.get("reasoning_signals")
    if not isinstance(rs, Mapping):
        return ""
    # Keep the representation structured and compact. We intentionally don't
    # require raw reasoning text for the reasoning-only line.
    frame = _reasoning_frame(meta)
    if not frame:
        return ""
    # Keep only compact reusable abstractions plus the highest-value structured
    # decision marker. This prevents prose memorization while retaining causal signal.
    decision = str(rs.get("decision") or "").strip().lower()[:80]
    return f"frame:{frame}|decision:{decision}"




def _reasoning_frame(meta: Mapping[str, object]) -> str:
    """Far-transfer reasoning abstraction: map verbose signals to reusable frames."""
    rs = meta.get("reasoning_signals")
    if not isinstance(rs, Mapping):
        return ""
    text = " ".join(str(rs.get(k, "")) for k in ("goal", "hypothesis", "evidence", "decision", "expected_effect", "contradiction", "rationale", "tool_intent", "keywords")).lower()
    groups = {
        "inspect": ("inspect", "search", "find", "read", "lookup", "locate", "trace", "parser"),
        "optimize": ("timeout", "slow", "performance", "optimi", "latency", "bottleneck"),
        "dependency": ("depend", "module", "package", "import", "library"),
        "repair": ("fix", "repair", "rewrite", "correct", "bug", "error"),
        "verify": ("test", "verify", "check", "regression", "invariant", "assert"),
        "api": ("signature", "caller", "interface", "parameter", "compatib"),
        "state": ("state", "cache", "mask", "propagat", "mutation"),
    }
    hits = [name for name, words in groups.items() if any(w in text for w in words)]
    return "+".join(sorted(hits)) or "general"

def _action_key(event: TrajectoryEvent) -> str:
    return event.action.strip().lower() if event.action else ""


def _action_family(action: str) -> str:
    a = action.lower()
    if any(x in a for x in ("read", "grep", "find", "search", "inspect", "open")):
        return "inspect"
    if any(x in a for x in ("write", "edit", "patch", "replace", "apply")):
        return "mutate"
    if any(x in a for x in ("test", "check", "verify", "lint", "compile", "bash", "run")):
        return "verify"
    if any(x in a for x in ("recover", "retry", "rollback", "repair")):
        return "recover"
    return "other"


def _iter_reasoning_examples(trajectories: Iterable[Trajectory]):
    for traj in trajectories:
        for i, event in enumerate(traj.events):
            key = _reasoning_key(event.metadata or {})
            if not key:
                continue
            nxt = next((e for e in traj.events[i + 1 :] if e.action and e.kind not in {"message", "reasoning"}), None)
            if nxt is not None:
                yield key, _action_family(nxt.action)


def _iter_execution_examples(trajectories: Iterable[Trajectory]):
    for traj in trajectories:
        prev = "<START>"
        for event in traj.events:
            action = _action_key(event)
            if not action or event.kind in {"message", "reasoning"}:
                continue
            yield prev, _action_family(action)
            prev = action


def _iter_joint_examples(trajectories: Iterable[Trajectory]):
    for traj in trajectories:
        prev = "<START>"
        for i, event in enumerate(traj.events):
            action = _action_key(event)
            if not action or event.kind in {"message", "reasoning"}:
                continue
            rs_key = _reasoning_key(event.metadata or {})
            # Joint learning can use either the current reasoning signal or the
            # immediately preceding reasoning-bearing event as the controller.
            if not rs_key:
                for prior in reversed(traj.events[:i]):
                    rs_key = _reasoning_key(prior.metadata or {})
                    if rs_key:
                        break
            if not rs_key:
                prev = action
                continue
            key = f"{rs_key}|prev:{prev}"
            yield key, _action_family(action)
            prev = action


def _score(table: _RuleTable, examples: Sequence[tuple[str, str]]) -> tuple[float, int]:
    if not examples:
        return 0.0, 0
    correct = 0
    for key, target in examples:
        pred = table.best(key)
        if pred and pred[0] == target:
            correct += 1
    return correct / len(examples), len(examples)


def train_multiview(trajectories: Sequence[Trajectory], *, holdout_fraction: float = 0.25) -> MultiViewReport:
    """Train three parallel lines and a fusion layer on >4 trajectories.

    The three lines are intentionally independent:
      1) reasoning-only: reasoning signal -> next action family
      2) execution-only: prior action -> next action family
      3) joint: reasoning context + execution state -> next action family

    The fused view uses joint when confident, then falls back to the best
    independently learned view. This is a TRIZ-style "one system, three
    information channels" design: contradictions are resolved by changing
    information placement, not by forcing one representation to do everything.
    """
    if len(trajectories) < 8:
        raise ValueError("multiview training requires at least 8 trajectories")
    # Deterministic stratified split across the three information regimes so
    # the holdout cannot accidentally contain only execution-only traces.
    reasoning_trajs = [t for t in trajectories if any(_reasoning_key(e.metadata or {}) for e in t.events)]
    execution_only_trajs = [t for t in trajectories if not any(_reasoning_key(e.metadata or {}) for e in t.events)]

    def split_group(group: list[Trajectory]) -> tuple[list[Trajectory], list[Trajectory]]:
        if len(group) <= 1:
            return list(group), []
        h = max(1, int(round(len(group) * holdout_fraction)))
        h = min(h, len(group) - 1)
        return group[:-h], group[-h:]

    r_train, r_holdout = split_group(reasoning_trajs)
    e_train, e_holdout = split_group(execution_only_trajs)
    train = r_train + e_train
    holdout = r_holdout + e_holdout
    # Preserve deterministic ordering but avoid view starvation.
    train.sort(key=lambda t: t.run_id)
    holdout.sort(key=lambda t: t.run_id)
    if not holdout:
        holdout = train[-1:]
        train = train[:-1]

    rtab = _RuleTable(); etab = _RuleTable(); jtab = _RuleTable()
    for k, v in _iter_reasoning_examples(train): rtab.add(k, v)
    for k, v in _iter_execution_examples(train): etab.add(k, v)
    for k, v in _iter_joint_examples(train): jtab.add(k, v)

    r_ex = list(_iter_reasoning_examples(holdout))
    e_ex = list(_iter_execution_examples(holdout))
    j_ex = list(_iter_joint_examples(holdout))
    r_cov = sum(1 for k, _ in r_ex if rtab.best(k)) / max(1, len(r_ex))
    e_cov = sum(1 for k, _ in e_ex if etab.best(k)) / max(1, len(e_ex))
    j_cov = sum(1 for k, _ in j_ex if jtab.best(k)) / max(1, len(j_ex))
    r_acc, _ = _score(rtab, r_ex)
    e_acc, _ = _score(etab, e_ex)
    j_acc, _ = _score(jtab, j_ex)

    # Fusion is evaluated over a joint key, with deterministic fallbacks.
    fused_total = 0; fused_correct = 0; fused_covered = 0
    best_single = max(r_acc, e_acc)
    for key, target in j_ex:
        pred = jtab.best(key)
        if pred and pred[1] >= 0.5:
            fused_total += 1; fused_covered += 1
            fused_correct += int(pred[0] == target)
            continue
        # Try execution-only by recovering the prev component from the joint key.
        prev = key.split("|prev:", 1)[1] if "|prev:" in key else "<START>"
        ep = etab.best(prev)
        if ep:
            fused_total += 1; fused_covered += 1
            fused_correct += int(ep[0] == target)
        else:
            fused_total += 1
    f_acc = fused_correct / max(1, fused_total)
    f_cov = fused_covered / max(1, fused_total)

    return MultiViewReport(
        trajectories=len(trajectories),
        reasoning_examples=len(r_ex),
        execution_examples=len(e_ex),
        joint_examples=len(j_ex),
        reasoning=ViewArtifact("reasoning-only", len(r_ex), rtab.rules, rtab.rules, r_cov, r_acc, len(r_ex)),
        execution=ViewArtifact("execution-only", len(e_ex), etab.rules, etab.rules, e_cov, e_acc, len(e_ex)),
        joint=ViewArtifact("joint", len(j_ex), jtab.rules, jtab.rules, j_cov, j_acc, len(j_ex)),
        fused=ViewArtifact("fused", fused_total, jtab.rules + etab.rules, jtab.rules + etab.rules, f_cov, f_acc, fused_total),
        joint_gain_vs_reasoning=j_acc - r_acc,
        joint_gain_vs_execution=j_acc - e_acc,
        fusion_gain_vs_best_single=f_acc - best_single,
    )
