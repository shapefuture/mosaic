from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Iterable

from ..ecu.core import ECUEnvironment, ExecutableComputeUnit
from ..ecu.verify import verify_ecu

@dataclass(frozen=True)
class SyntheticCase:
    case_id: str
    unit_digests: tuple[str, ...]
    complexity: int


def compose_verified_units(units: Iterable[ExecutableComputeUnit], env_factory, oracle_factory, *, max_combo: int = 3) -> list[SyntheticCase]:
    """Generate verified single/compound skill-use cases, SKT-style.

    Candidate combinations are retained only when every constituent unit is
    exercised and the composed result passes its end-state oracle.
    """
    units = tuple(units)
    out: list[SyntheticCase] = []
    for size in range(1, min(max_combo, len(units)) + 1):
        for combo in combinations(units, size):
            env = env_factory()
            ok = True
            used = []
            for unit in combo:
                result = unit.run(env)
                if not result.success:
                    ok = False
                    break
                used.append(unit.digest)
            if ok and oracle_factory(env, combo):
                out.append(SyntheticCase(f"syn-{len(out):06d}", tuple(used), sum(len(u.actions) for u in combo)))
    return out
