from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from typing import Iterable

from ..data.frontier import DatasetManifest
from ..trajectory.events import Trajectory
from .optimizer import train_skill_evidence, SuperiorityReport


@dataclass(frozen=True)
class MetaCandidate:
    min_support: int
    max_len: int
    learning_rate: int
    report: SuperiorityReport
    score: float


def evolve_training_strategy(
    trajectories: Iterable[Trajectory], manifest: DatasetManifest, *, budget: int = 12
) -> MetaCandidate:
    """Two-timescale meta-evolution over the *learning procedure itself*.

    The optimizer searches the training recipe, not just the resulting skill.
    This prevents MOSAIC from being permanently coupled to a single motif miner.
    """
    ts = list(trajectories)
    grid = list(product((2, 3, 4), (3, 5, 8), (4, 8, 12)))[:budget]
    best: MetaCandidate | None = None
    for min_support, max_len, lr in grid:
        units, _, report = train_skill_evidence(ts, manifest, epochs=2, batch_size=32, learning_rate=lr, seed=42 + min_support + max_len)
        score = (
            report.candidate_validation_score
            + 0.2 * report.planning_step_reduction
            + 0.2 * report.frontier_call_reduction
            - 0.1 * (len(units) / max(1, len(ts)))
        )
        candidate = MetaCandidate(min_support, max_len, lr, report, score)
        if best is None or candidate.score > best.score:
            best = candidate
    if best is None:
        raise ValueError("no meta-evolution candidate")
    return best
