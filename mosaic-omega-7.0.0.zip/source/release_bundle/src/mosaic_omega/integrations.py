from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

from .trajectory.events import Trajectory, TrajectoryEvent


def load_jsonl(path: str | Path, run_id: str = "imported") -> Trajectory:
    events: list[TrajectoryEvent] = []
    for i, line in enumerate(Path(path).read_text().splitlines()):
        if not line.strip():
            continue
        obj = json.loads(line)
        events.append(TrajectoryEvent(
            step=int(obj.get("step", i)),
            kind=str(obj.get("kind", obj.get("event", "unknown"))),
            action=str(obj.get("action", obj.get("name", ""))),
            observation=str(obj.get("observation", obj.get("result", ""))),
            state_hash=str(obj.get("state_hash", "")),
            ok=obj.get("ok"),
            latency_ms=float(obj.get("latency_ms", 0.0) or 0.0),
            cost_usd=float(obj.get("cost_usd", 0.0) or 0.0),
            metadata={k: v for k, v in obj.items() if k not in {"step", "kind", "event", "action", "name", "observation", "result", "state_hash", "ok", "latency_ms", "cost_usd"}},
        ))
    return Trajectory(run_id, tuple(events))


def export_atif_like(traj: Trajectory) -> dict[str, Any]:
    return {"trajectory_id": traj.run_id, "steps": [{"step": e.step, "type": e.kind, "action": e.action, "observation": e.observation, "state_hash": e.state_hash, "ok": e.ok, "latency_ms": e.latency_ms, "cost_usd": e.cost_usd, "metadata": dict(e.metadata)} for e in traj.events]}
