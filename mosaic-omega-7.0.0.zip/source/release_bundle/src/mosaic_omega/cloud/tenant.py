from __future__ import annotations
from dataclasses import dataclass, field
import time

@dataclass(frozen=True)
class TenantQuota:
    max_concurrent_cells: int = 16
    max_cpu_seconds: float = 3600.0
    max_memory_mb: float = 2048.0
    max_gpu_seconds: float = 0.0
    max_mcp_requests_per_minute: int = 600

@dataclass(frozen=True)
class TenantPolicy:
    allow_network: bool = False
    allow_gpu: bool = False
    allow_remote_compute: bool = True
    allowed_capabilities: frozenset[str] = frozenset()
    public_cache_reuse: bool = True

@dataclass(frozen=True)
class TenantAuth:
    tenant_id: str
    subject: str
    scopes: frozenset[str] = frozenset()

@dataclass
class _Usage:
    active_cells: int = 0
    cpu_seconds: float = 0.0
    memory_mb: float = 0.0
    gpu_seconds: float = 0.0
    requests: list[float] = field(default_factory=list)

class TenantKernel:
    def __init__(self) -> None:
        self._quotas: dict[str, TenantQuota] = {}
        self._policies: dict[str, TenantPolicy] = {}
        self._usage: dict[str, _Usage] = {}

    def register(self, tenant_id: str, *, quota: TenantQuota | None = None, policy: TenantPolicy | None = None) -> None:
        self._quotas[tenant_id] = quota or TenantQuota()
        self._policies[tenant_id] = policy or TenantPolicy()
        self._usage.setdefault(tenant_id, _Usage())

    def authorize(self, auth: TenantAuth, capability: str, *, gpu: bool = False, network: bool = False) -> None:
        policy = self._policies.get(auth.tenant_id)
        if policy is None:
            raise PermissionError("unknown tenant")
        if capability and policy.allowed_capabilities and capability not in policy.allowed_capabilities:
            raise PermissionError("capability not allowed for tenant")
        if gpu and not policy.allow_gpu:
            raise PermissionError("GPU disabled by tenant policy")
        if network and not policy.allow_network:
            raise PermissionError("network disabled by tenant policy")

    def admit_cell(self, tenant_id: str, *, memory_mb: float, gpu: bool) -> None:
        quota = self._quotas[tenant_id]
        usage = self._usage[tenant_id]
        if usage.active_cells >= quota.max_concurrent_cells:
            raise RuntimeError("tenant concurrency quota exceeded")
        if usage.memory_mb + memory_mb > quota.max_memory_mb:
            raise RuntimeError("tenant memory quota exceeded")
        if gpu and quota.max_gpu_seconds <= 0:
            raise RuntimeError("tenant GPU quota is zero")
        usage.active_cells += 1
        usage.memory_mb += memory_mb

    def release_cell(self, tenant_id: str, *, memory_mb: float, cpu_seconds: float = 0.0, gpu_seconds: float = 0.0) -> None:
        u = self._usage[tenant_id]
        u.active_cells = max(0, u.active_cells - 1)
        u.memory_mb = max(0.0, u.memory_mb - memory_mb)
        u.cpu_seconds += max(0.0, cpu_seconds)
        u.gpu_seconds += max(0.0, gpu_seconds)

    def admit_request(self, tenant_id: str) -> None:
        quota = self._quotas[tenant_id]
        u = self._usage[tenant_id]
        now = time.time()
        u.requests[:] = [t for t in u.requests if now - t < 60.0]
        if len(u.requests) >= quota.max_mcp_requests_per_minute:
            raise RuntimeError("MCP request quota exceeded")
        u.requests.append(now)

    def usage(self, tenant_id: str) -> dict[str, float]:
        u = self._usage[tenant_id]
        return {
            "active_cells": u.active_cells,
            "cpu_seconds": u.cpu_seconds,
            "memory_mb": u.memory_mb,
            "gpu_seconds": u.gpu_seconds,
            "requests_last_minute": float(len(u.requests)),
        }
