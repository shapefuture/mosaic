from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from hashlib import sha256
import time
from typing import Callable, Mapping, Any

class ExecutionTier(str, Enum):
    NATIVE = "native"
    WASM = "wasm"
    WORKER = "worker"
    MICROVM = "microvm"

@dataclass(frozen=True)
class SandboxPolicy:
    tier: ExecutionTier
    allow_network: bool = False
    memory_mb: int = 128
    cpu_ms: int = 1000
    read_only_root: bool = True
    tenant_id: str = ""
    capability: str = ""

class SandboxPolicyCompiler:
    def compile(self, *, tenant_id: str, trust: str, network: bool, memory_mb: int, cpu_ms: int, capability: str) -> SandboxPolicy:
        if network and trust == "untrusted":
            raise PermissionError("untrusted code cannot request network")
        if trust == "trusted" and not network and memory_mb <= 256:
            tier = ExecutionTier.NATIVE
        elif trust in {"trusted", "constrained"} and memory_mb <= 512:
            tier = ExecutionTier.WASM
        elif trust == "constrained":
            tier = ExecutionTier.WORKER
        else:
            tier = ExecutionTier.MICROVM
        return SandboxPolicy(tier=tier, allow_network=network, memory_mb=memory_mb, cpu_ms=cpu_ms, tenant_id=tenant_id, capability=capability)

@dataclass
class ExecutionCell:
    cell_id: str
    tenant_id: str
    state_handle: str
    policy: SandboxPolicy
    created_ns: int
    lease_expires_ns: int
    active: bool = True
    branch: str = "root"

    @property
    def digest(self) -> str:
        payload = f"{self.cell_id}|{self.tenant_id}|{self.state_handle}|{self.policy.tier}|{self.branch}".encode()
        return sha256(payload).hexdigest()

    def expired(self, now_ns: int | None = None) -> bool:
        return (now_ns or time.time_ns()) >= self.lease_expires_ns

class ExecutionFabric:
    """Backend-neutral ephemeral execution control plane.

    It models the logical/physical split: thousands of cells can exist as tiny
    handles while actual work is submitted to interchangeable runtime tiers.
    """
    def __init__(self, *, max_cells: int = 10_000) -> None:
        self.max_cells = max_cells
        self._cells: dict[str, ExecutionCell] = {}
        self._snapshots: dict[str, bytes] = {}
        self._handlers: dict[ExecutionTier, Callable[[ExecutionCell, Mapping[str, Any]], Any]] = {}

    def register_handler(self, tier: ExecutionTier, handler: Callable[[ExecutionCell, Mapping[str, Any]], Any]) -> None:
        self._handlers[tier] = handler

    def create(self, *, tenant_id: str, state_handle: str, policy: SandboxPolicy, lease_ms: int = 30_000, branch: str = "root") -> ExecutionCell:
        if len(self._cells) >= self.max_cells:
            raise RuntimeError("execution-cell capacity exceeded")
        cid = f"cell_{len(self._cells)+1:08d}"
        now = time.time_ns()
        cell = ExecutionCell(cid, tenant_id, state_handle, policy, now, now + lease_ms * 1_000_000, True, branch)
        self._cells[cid] = cell
        return cell

    def fork(self, cell_id: str, *, branches: int = 2) -> list[ExecutionCell]:
        parent = self._cells[cell_id]
        if parent.expired():
            raise RuntimeError("cannot fork expired cell")
        children = []
        for i in range(branches):
            children.append(self.create(tenant_id=parent.tenant_id, state_handle=parent.state_handle, policy=parent.policy, lease_ms=max(1, (parent.lease_expires_ns-time.time_ns())//1_000_000), branch=f"{parent.branch}.{i+1}"))
        return children

    def execute(self, cell_id: str, payload: Mapping[str, Any] | None = None) -> Any:
        cell = self._cells[cell_id]
        if not cell.active or cell.expired():
            cell.active = False
            raise RuntimeError("cell lease expired")
        handler = self._handlers.get(cell.policy.tier)
        if handler is None:
            return {"cell": cell_id, "tier": cell.policy.tier.value, "status": "simulated"}
        return handler(cell, payload or {})

    def terminate(self, cell_id: str) -> None:
        if cell_id in self._cells:
            self._cells[cell_id].active = False

    def active_count(self) -> int:
        return sum(1 for c in self._cells.values() if c.active and not c.expired())

    def logical_count(self) -> int:
        return len(self._cells)

    def reap(self) -> int:
        removed = 0
        now = time.time_ns()
        for c in self._cells.values():
            if c.active and c.expired(now):
                c.active = False
                removed += 1
        return removed
