# MOSAIC Ω6 cloud/ephemeral fabric

Backend-neutral reference layer for:

- stateless MCP-shaped edge routing;
- explicit state handles;
- multi-tenant quotas/policies;
- logical agents decoupled from execution processes;
- ephemeral execution cells;
- snapshot/fork-friendly state semantics;
- native → WASM → worker → microVM runtime escalation;
- shared runtime/gateway reuse.

Production deployments can adapt `StateStore`, `ExecutionFabric`, and the runtime tiers to Redis/SQLite/object stores, CRDT implementations, Firecracker, Kubernetes, WASM runtimes, Cloudflare Workers/Containers, etc.
