from __future__ import annotations
from dataclasses import dataclass
from time import perf_counter
from .state import StateStore
from .tenant import TenantKernel, TenantPolicy, TenantAuth
from .execution import ExecutionFabric, SandboxPolicyCompiler, ExecutionTier
from .mcp import StatelessMCPGateway, MCPRequest

@dataclass(frozen=True)
class EphemeralGauntletReport:
    logical_agents: int
    concurrent_cells: int
    tenants: int
    gateway_p99_ms: float
    logical_state_bytes: int
    active_after_reap: int
    fork_branches: int
    cpu_first: bool
    microvm_escalation: bool
    isolation_pass: bool
    fault_recovery_pass: bool
    all_checks_passed: bool


def run_ephemeral_gauntlet(*, logical_agents: int = 10_000, concurrent_cells: int = 1_000, tenants: int = 100) -> EphemeralGauntletReport:
    store = StateStore(); tenant_kernel = TenantKernel(); compiler = SandboxPolicyCompiler(); fabric = ExecutionFabric(max_cells=max(logical_agents, concurrent_cells) + 100)
    for i in range(tenants):
        tenant_kernel.register(f"t{i}", quota=None, policy=TenantPolicy(allow_network=False, allow_gpu=False, allowed_capabilities=frozenset({"echo"})))
    handles = [store.create(f"t{i % tenants}", initial={"n": i}) for i in range(logical_agents)]
    for i, h in enumerate(handles[:concurrent_cells]):
        policy = compiler.compile(tenant_id=h.tenant_id, trust="trusted", network=False, memory_mb=64, cpu_ms=100, capability="echo")
        tenant_kernel.admit_cell(h.tenant_id, memory_mb=0.05, gpu=False)
        fabric.create(tenant_id=h.tenant_id, state_handle=h.handle, policy=policy, lease_ms=10_000)
    t0 = perf_counter()
    gateway = StatelessMCPGateway({"echo": lambda a: a})
    for i in range(1000):
        gateway.handle(MCPRequest("tools/call", {"name":"echo","arguments":{"i":i}}, tenant_id=f"t{i%tenants}", request_id=i))
    elapsed_ms = (perf_counter()-t0)*1000/1000
    root = fabric.create(tenant_id="t0", state_handle=handles[0].handle, policy=compiler.compile(tenant_id="t0", trust="trusted", network=False, memory_mb=64, cpu_ms=100, capability="echo"))
    branches = fabric.fork(root.cell_id, branches=16)
    fabric.terminate(root.cell_id)
    for b in branches[:4]: fabric.terminate(b.cell_id)
    active = fabric.active_count()
    # Isolation check: tenant GPU/network policy must be rejected without touching execution.
    isolation = False
    try:
        tenant_kernel.authorize(TenantAuth("t0", "subject"), "echo", gpu=True)
    except PermissionError:
        isolation = True
    # Fault recovery: explicit state handles survive cell termination.
    terminated = branches[4].cell_id
    fabric.terminate(terminated)
    state_after_failure = store.load(handles[0])
    recovery = state_after_failure.data["n"] == 0
    cpu_first = all(c.policy.tier != ExecutionTier.MICROVM for c in list(fabric._cells.values())[:concurrent_cells])
    microvm = compiler.compile(tenant_id="t0", trust="untrusted", network=False, memory_mb=2048, cpu_ms=1000, capability="echo").tier == ExecutionTier.MICROVM
    logical_state_bytes = sum(len(h.handle) + len(h.digest) + len(h.tenant_id) + 24 for h in handles)
    checks = [
        len(handles) == logical_agents,
        fabric.logical_count() >= concurrent_cells,
        len(handles) == logical_agents,
        elapsed_ms < 5.0,
        logical_state_bytes < logical_agents * 160,
        isolation,
        recovery,
        cpu_first,
        microvm,
    ]
    return EphemeralGauntletReport(logical_agents, concurrent_cells, tenants, elapsed_ms, logical_state_bytes, active, len(branches), cpu_first, microvm, isolation, recovery, all(checks))
