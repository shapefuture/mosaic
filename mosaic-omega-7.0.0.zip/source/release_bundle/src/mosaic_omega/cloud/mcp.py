from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from .tenant import TenantKernel, TenantAuth

@dataclass(frozen=True)
class MCPRequest:
    method: str
    params: Mapping[str, Any]
    tenant_id: str
    request_id: str | int | None = None
    state_handle: str | None = None
    capability: str | None = None

@dataclass(frozen=True)
class MCPResponse:
    request_id: str | int | None
    result: Any = None
    error: dict[str, Any] | None = None

class StatelessMCPGateway:
    """Minimal stateless JSON-RPC/MCP-shaped gateway.

    Protocol state is carried in explicit handles; the gateway stores no per-session
    conversation state. This makes the edge horizontally routable.
    """
    def __init__(self, tools: Mapping[str, Callable[[Mapping[str, Any]], Any]] | None = None, *, tenant_kernel: TenantKernel | None = None) -> None:
        self.tools = dict(tools or {})
        self.tenant_kernel = tenant_kernel
        self._cache: dict[str, Any] = {}

    def tools_list(self) -> dict[str, Any]:
        key = "tools:list"
        if key not in self._cache:
            self._cache[key] = {
                "tools": [
                    {"name": name, "inputSchema": {"type": "object"}}
                    for name in sorted(self.tools)
                ]
            }
        return self._cache[key]

    def handle(self, request: MCPRequest) -> MCPResponse:
        try:
            if self.tenant_kernel is not None:
                self.tenant_kernel.admit_request(request.tenant_id)
            if request.method in {"tools/list", "tools.list"}:
                return MCPResponse(request.request_id, self.tools_list())
            if request.method in {"tools/call", "tools.call"}:
                name = str(request.params.get("name", ""))
                if self.tenant_kernel is not None:
                    self.tenant_kernel.authorize(TenantAuth(request.tenant_id, f"mcp:{request.request_id}"), name)
                tool = self.tools.get(name)
                if tool is None:
                    return MCPResponse(request.request_id, error={"code": -32601, "message": f"unknown tool: {name}"})
                args = request.params.get("arguments", {})
                return MCPResponse(request.request_id, tool(args))
            if request.method == "ping":
                return MCPResponse(request.request_id, {"ok": True})
            return MCPResponse(request.request_id, error={"code": -32601, "message": f"unknown method: {request.method}"})
        except Exception as exc:
            return MCPResponse(request.request_id, error={"code": -32000, "message": str(exc)})
