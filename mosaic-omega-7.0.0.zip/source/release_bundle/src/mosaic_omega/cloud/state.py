from __future__ import annotations
from dataclasses import dataclass, field
from hashlib import sha256
import json
import time
from typing import Any, Mapping

@dataclass(frozen=True)
class StateHandle:
    handle: str
    tenant_id: str
    version: int
    digest: str

@dataclass
class TenantState:
    tenant_id: str
    data: dict[str, Any] = field(default_factory=dict)
    version: int = 0
    created_at: float = field(default_factory=time.time)

    def snapshot(self) -> StateHandle:
        blob = json.dumps(self.data, sort_keys=True, separators=(",", ":")).encode()
        digest = sha256(blob).hexdigest()
        handle = f"st_{digest[:20]}_{self.version}"
        return StateHandle(handle, self.tenant_id, self.version, digest)

class StateStore:
    """Small durable-state abstraction: state is explicit, mutable only by tenant scope.

    Production adapters can back this with SQLite/object storage/KV/CRDTs. The core
    deliberately keeps the protocol independent from the storage engine.
    """
    def __init__(self) -> None:
        self._states: dict[tuple[str, str], TenantState] = {}
        self._snapshots: dict[str, TenantState] = {}

    def create(self, tenant_id: str, *, initial: Mapping[str, Any] | None = None) -> StateHandle:
        state = TenantState(tenant_id, dict(initial or {}))
        handle = state.snapshot().handle
        self._states[(tenant_id, handle)] = state
        self._snapshots[handle] = TenantState(tenant_id, dict(state.data), state.version, state.created_at)
        return state.snapshot()

    def load(self, handle: StateHandle) -> TenantState:
        state = self._states.get((handle.tenant_id, handle.handle))
        if state is None:
            state = self._snapshots.get(handle.handle)
        if state is None:
            raise KeyError(f"unknown state handle: {handle.handle}")
        return TenantState(state.tenant_id, dict(state.data), state.version, state.created_at)

    def update(self, handle: StateHandle, patch: Mapping[str, Any]) -> StateHandle:
        state = self.load(handle)
        state.data.update(dict(patch))
        state.version += 1
        new_handle = state.snapshot()
        self._states[(state.tenant_id, new_handle.handle)] = state
        self._snapshots[new_handle.handle] = TenantState(state.tenant_id, dict(state.data), state.version, state.created_at)
        return new_handle

    def fork(self, handle: StateHandle, *, branch: str) -> StateHandle:
        state = self.load(handle)
        forked = TenantState(state.tenant_id, dict(state.data), state.version)
        forked.data["_branch"] = branch
        forked.version += 1
        new_handle = forked.snapshot()
        self._states[(forked.tenant_id, new_handle.handle)] = forked
        self._snapshots[new_handle.handle] = TenantState(forked.tenant_id, dict(forked.data), forked.version, forked.created_at)
        return new_handle

    def materialized_bytes(self) -> int:
        return sum(len(json.dumps(s.data, separators=(",", ":"))) for s in self._snapshots.values())
