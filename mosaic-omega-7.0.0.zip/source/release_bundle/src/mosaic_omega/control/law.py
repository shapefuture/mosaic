from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class ActionEstimate:
    name: str
    expected_quality_gain: float
    expected_future_savings_usd: float
    expected_reuse_gain: float
    cost_usd: float
    confidence: float = 1.0

    @property
    def marginal_value(self) -> float:
        return (self.expected_quality_gain + self.expected_future_savings_usd + self.expected_reuse_gain) * max(0.0, self.confidence)

    @property
    def roi(self) -> float:
        return self.marginal_value / max(self.cost_usd, 1e-12)

@dataclass(frozen=True)
class ControlDecision:
    action: str
    roi: float
    stop: bool
    reason: str

class MarginalValueController:
    def __init__(self, min_roi: float = 1.0):
        self.min_roi = float(min_roi)

    def decide(self, actions: list[ActionEstimate]) -> ControlDecision:
        if not actions:
            return ControlDecision("stop", 0.0, True, "no actions")
        best = max(actions, key=lambda x: (x.roi, x.name))
        if best.roi < self.min_roi:
            return ControlDecision("stop", best.roi, True, "marginal value below threshold")
        return ControlDecision(best.name, best.roi, False, "highest verified marginal value")
