from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from typing import Iterator

from ..model import ComputeSpec, Genome
from ..profiling.host import HostProfile, profile_host


@dataclass(frozen=True)
class SearchDimension:
    name: str
    low: int
    high: int
    step: int = 1

    def values(self) -> tuple[int, ...]:
        if self.low < 1 or self.high < self.low or self.step < 1:
            raise ValueError(f"invalid dimension {self}")
        return tuple(range(self.low, self.high + 1, self.step))


@dataclass(frozen=True)
class SearchSpace:
    dimensions: tuple[SearchDimension, ...]

    def size(self) -> int:
        out = 1
        for d in self.dimensions:
            out *= len(d.values())
        return out

    def candidates(self) -> Iterator[Genome]:
        names = [d.name for d in self.dimensions]
        for vals in product(*(d.values() for d in self.dimensions)):
            yield Genome(**dict(zip(names, vals)))


class SearchSpaceCompiler:
    """Compile a hardware- and workload-aware legal region before evaluation."""

    _DEFAULTS = {
        "tile": SearchDimension("tile", 1, 32),
        "unroll": SearchDimension("unroll", 1, 16),
        "vector_width": SearchDimension("vector_width", 1, 16),
        "pipeline": SearchDimension("pipeline", 1, 8),
        "split": SearchDimension("split", 1, 8),
    }

    def __init__(self, host: HostProfile | None = None):
        self.host = host or profile_host()

    def compile(self, spec: ComputeSpec) -> SearchSpace:
        dims: list[SearchDimension] = []
        vhint = self.host.vector_width_hint
        for name, default in self._DEFAULTS.items():
            low, high = spec.constraints.get(name, (default.low, default.high))
            if name == "tile":
                high = min(high, max(1, spec.input_size))
                # Small vectors pay overhead from excessive blocking; cap the search accordingly.
                if spec.input_size < 1024:
                    high = min(high, 8)
            if name == "vector_width":
                high = min(high, max(1, vhint * 2))
                low = min(low, high)
            if name == "unroll" and self.host.arch in {"aarch64", "arm64"}:
                high = min(high, 8)
            dims.append(SearchDimension(name, max(1, low), max(1, high), default.step))
        return SearchSpace(tuple(dims))
