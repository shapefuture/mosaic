from __future__ import annotations

import os
import platform
import shutil
import subprocess
import time
from dataclasses import dataclass


@dataclass(frozen=True)
class HostProfile:
    arch: str
    cpu_model: str
    logical_cpus: int
    physical_cpus: int
    flags: frozenset[str]
    llvm_available: bool
    perf_available: bool
    cuda_available: bool
    rocm_available: bool

    @property
    def vector_width_hint(self) -> int:
        flags = self.flags
        if "avx512f" in flags:
            return 8
        if "avx2" in flags:
            return 4
        if "sve" in flags or "sve2" in flags:
            return 8
        if "neon" in flags:
            return 2
        return 1


def profile_host() -> HostProfile:
    model = platform.processor() or "unknown"
    flags: set[str] = set()
    try:
        text = open("/proc/cpuinfo", "r", encoding="utf-8", errors="ignore").read().splitlines()
        for line in text:
            if line.lower().startswith(("flags", "features")) and ":" in line:
                flags.update(line.split(":", 1)[1].strip().lower().split())
            if line.lower().startswith("model name") and ":" in line:
                model = line.split(":", 1)[1].strip()
                break
    except OSError:
        pass
    physical = os.cpu_count() or 1
    logical = os.cpu_count() or 1
    return HostProfile(
        arch=platform.machine(), cpu_model=model, logical_cpus=logical, physical_cpus=physical,
        flags=frozenset(flags), llvm_available=bool(shutil.which("clang")),
        perf_available=bool(shutil.which("perf")), cuda_available=bool(shutil.which("nvidia-smi")),
        rocm_available=bool(shutil.which("rocminfo") or shutil.which("rocm-smi")),
    )


def perf_stat(command: list[str], timeout_s: float = 60.0) -> dict[str, float | str]:
    if not shutil.which("perf"):
        raise RuntimeError("perf is unavailable")
    cmd = ["perf", "stat", "-x,", "-e", "cycles,instructions,cache-misses,branch-misses", "--", *command]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_s)
    data: dict[str, float | str] = {"returncode": proc.returncode}
    for line in proc.stderr.splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 3:
            try:
                data[parts[2]] = float(parts[0].replace("<not counted>", "nan"))
            except ValueError:
                continue
    return data
