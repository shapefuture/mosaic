from __future__ import annotations

from dataclasses import dataclass
import os
import platform
import shutil


@dataclass(frozen=True)
class ResourceSnapshot:
    logical_cpus: int
    physical_cpus: int
    available_memory_bytes: int
    cpu_affinity: tuple[int, ...]
    compiler: str | None
    gpu_runtime: bool


def snapshot() -> ResourceSnapshot:
    affinity = tuple(sorted(os.sched_getaffinity(0))) if hasattr(os, "sched_getaffinity") else tuple(range(os.cpu_count() or 1))
    mem = 0
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    mem = int(line.split()[1]) * 1024
                    break
    except OSError:
        pass
    return ResourceSnapshot(
        logical_cpus=len(affinity),
        physical_cpus=os.cpu_count() or 1,
        available_memory_bytes=mem,
        cpu_affinity=affinity,
        compiler=shutil.which("clang") or shutil.which("gcc"),
        gpu_runtime=bool(shutil.which("nvidia-smi") or shutil.which("rocminfo") or shutil.which("rocm-smi")),
    )
