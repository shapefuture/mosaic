from __future__ import annotations

from dataclasses import dataclass
import math
from statistics import median
from typing import Sequence


@dataclass(frozen=True)
class WorkloadProfile:
    elements: int
    bytes_in: int
    bytes_out: int
    arithmetic_ops: int
    bytes_per_element: float
    arithmetic_intensity: float
    working_set_bytes: int
    likely_memory_bound: bool

    @property
    def total_bytes(self) -> int:
        return self.bytes_in + self.bytes_out


def profile_vector(values: Sequence[float], arithmetic_ops: int) -> WorkloadProfile:
    n = len(values)
    bytes_in = n * 8
    bytes_out = n * 8
    total = max(1, bytes_in + bytes_out)
    intensity = float(max(0, arithmetic_ops) * max(1, n)) / total
    # Conservative CPU memory-bound heuristic: low arithmetic intensity and non-trivial footprint.
    memory_bound = intensity < 1.0 and total >= 16 * 1024
    return WorkloadProfile(n, bytes_in, bytes_out, arithmetic_ops, total / max(1, n), intensity, total, memory_bound)
