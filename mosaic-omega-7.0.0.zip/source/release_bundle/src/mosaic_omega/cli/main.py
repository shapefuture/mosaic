from __future__ import annotations

import argparse
import json

from ..archive.pareto import Archived, MAPElitesArchive, ParetoArchive
from ..compiler.search_space import SearchSpaceCompiler
from ..eval.multifidelity import MultiFidelityEvaluator
from ..ir.nodes import Add, Const, Input, Mul
from ..ir.program import Program
from ..model import Candidate, ComputeSpec
from ..runtime.dispatcher import DispatcherSynthesizer
from ..search.engine import EvolutionEngine
from ..security.policy import ExecutionPolicy, authorize
from ..security.provenance import attest, make_manifest, verify_attestation
from ..gauntlet import run_gauntlet
from ..gauntlets.maximal import run_maximal_gauntlet
from ..gauntlets.collective import run_collective_gauntlet
from ..learning.optimizer import train_skill_evidence
from ..learning.remote_train import RemoteDatasetSpec, stream_to_trajectories
from ..learning.streaming import train_streaming, StreamingECUTrainer
from ..integrations import load_jsonl, export_atif_like
from ..data.frontier import iter_records, orchard_row_to_event_dict, gpt56_row_to_event_dict, manifest_report
from ..data.trajectory_formats import iter_trajectory_file
from ..data.github_trajectories import GITHUB_TRACE_SOURCES, iter_local_github_trace, iter_remote_github_trace, audit_trace
from ..learning.recovery import mine_recovery_rules, compile_recovery_rules
from ..gauntlets.experience import run_experience_gauntlet
from ..trajectory.events import Trajectory, TrajectoryEvent
from ..ecu import distill_ecus, run_frontier_gauntlet
from ..learning.pipeline import train_from_trajectories
from ..data.frontier import TRAINING_MANIFESTS
from ..cloud.gauntlet import run_ephemeral_gauntlet
from pathlib import Path
from ..sources.discovery import discover_session_sources, extract_from_sqlite, iter_discovered_trajectories
from ..omega.gauntlet import run_omega_gauntlet
from ..omega2.gauntlet import run_omega2_gauntlet
from ..frontier import TOOLATHLON_VERIFIED_AUG_2026, compare_to_published_snapshot, load_replay_metrics
from ..frontier.recorded import CTI_REALM_50_JUNE_2026, TOOLATHLON_FIND_ALITA, compare_recorded_score
from ..network.gauntlet import run_network_gauntlet
from ..network.market import CapabilityRegistry, CapabilityQuery


def make_demo():
    program = Program("ax_plus_b", Add(Mul(Const(2.0), Input()), Const(1.0)))
    spec = ComputeSpec("ax_plus_b", "elementwise", 64, constraints={"tile": (1, 16), "unroll": (1, 4), "vector_width": (1, 8), "pipeline": (1, 4), "split": (1, 4)})
    return program, spec


def cmd_demo(args) -> int:
    program, spec = make_demo()
    compiler = SearchSpaceCompiler()
    space = compiler.compile(spec)
    engine = EvolutionEngine(space, seed=args.seed)
    evaluator = MultiFidelityEvaluator(seed=args.seed)
    pareto = ParetoArchive()
    elites = MAPElitesArchive()
    population = engine.seed_population(args.population)
    policy = ExecutionPolicy()
    observations = []
    for generation in range(args.generations):
        candidates = engine.propose(spec, population, args.budget)
        next_population = []
        for candidate in candidates:
            ok, reason = authorize(candidate, policy)
            if not ok:
                continue
            obs = evaluator.evaluate(candidate, program, fidelity=min(2, generation // 2))
            engine.surrogate.update(obs)
            item = Archived(candidate, obs)
            pareto.add(item)
            elites.add(item)
            observations.append((candidate, obs))
            next_population.append(candidate.genome)
        population = next_population or population
    dispatcher = DispatcherSynthesizer().synthesize(observations)
    best = min((x for x in pareto.items() if x.observation.correct), key=lambda x: x.observation.latency_ms)
    manifest = make_manifest(best.candidate, program.digest)
    att = attest(manifest, b"mosaic-demo-key")
    result = {
        "space_size": space.size(),
        "pareto_size": len(pareto.items()),
        "map_elites_size": len(elites.items()),
        "best_candidate": best.candidate.genome_id,
        "best_latency_ms": best.observation.latency_ms,
        "dispatch": dispatcher.explain(spec.input_size),
        "attestation_valid": verify_attestation(att, b"mosaic-demo-key"),
        "program_digest": program.digest,
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0



def _dict_to_trajectory(obj):
    return Trajectory(obj["run_id"], tuple(TrajectoryEvent(**e) for e in obj["events"]))

def cmd_ecu_train(args) -> int:
    adapter = args.adapter
    trajectories = []
    seen = 0
    for i, row in enumerate(iter_records(args.path, limit=None)):
        if adapter == "gpt56" and str(row.get("split", "train")) != "train":
            continue
        obj = orchard_row_to_event_dict(row, i) if adapter == "orchard" else gpt56_row_to_event_dict(row)
        trajectories.append(_dict_to_trajectory(obj))
        seen += 1
        if args.limit is not None and seen >= args.limit:
            break
    units, report = distill_ecus(trajectories, min_support=args.min_support, max_actions=args.max_actions, source_manifest=args.source_manifest)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(json.dumps(u.to_dict(), sort_keys=True) for u in units) + ("\n" if units else ""), encoding="utf-8")
    print(json.dumps({"report": report.__dict__, "output": str(out), "units": len(units), "manifest": manifest_report()}, indent=2, sort_keys=True))
    return 0




def cmd_frontier_learn(args) -> int:
    adapter = args.adapter
    trajectories = []
    seen = 0
    for i, row in enumerate(iter_records(args.path, limit=None)):
        if adapter == "gpt56" and str(row.get("split", "train")) != "train":
            continue
        obj = orchard_row_to_event_dict(row, i) if adapter == "orchard" else gpt56_row_to_event_dict(row)
        trajectories.append(_dict_to_trajectory(obj))
        seen += 1
        if args.limit is not None and seen >= args.limit:
            break
    manifest = next(m for m in TRAINING_MANIFESTS if (adapter == "orchard" and m.name.startswith("microsoft/")) or (adapter == "gpt56" and m.name.startswith("greghavens/")))
    units, policy, motifs, report = train_from_trajectories(trajectories, manifest, min_support=args.min_support, max_len=args.max_actions)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(json.dumps(u.to_dict(), sort_keys=True) for u in units) + ("\n" if units else ""), encoding="utf-8")
    payload = {"report": report.as_dict(), "units": len(units), "motifs": [m.__dict__ for m in motifs[:args.report_motifs]], "policy_states": policy.states, "output": str(out)}
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0



def cmd_frontier_max(args) -> int:
    adapter = args.adapter
    trajectories = []
    for i, row in enumerate(iter_records(args.path, limit=args.limit)):
        if adapter == "gpt56" and str(row.get("split", "train")) != "train":
            continue
        obj = orchard_row_to_event_dict(row, i) if adapter == "orchard" else gpt56_row_to_event_dict(row)
        trajectories.append(_dict_to_trajectory(obj))
    manifest = next(m for m in TRAINING_MANIFESTS if (adapter == "orchard" and m.name.startswith("microsoft/")) or (adapter == "gpt56" and m.name.startswith("greghavens/")))
    units, edits, report = train_skill_evidence(trajectories, manifest, epochs=args.epochs, batch_size=args.batch_size, learning_rate=args.learning_rate)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(json.dumps(u.to_dict(), sort_keys=True) for u in units) + ("\n" if units else ""), encoding="utf-8")
    payload = {"report": report.as_dict(), "accepted_edits": [e.__dict__ for e in edits], "output": str(out)}
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _github_trace_trajectory(args):
    if args.path:
        yield from iter_local_github_trace(args.path, run_id=args.run_id, limit=args.limit_records)
        return
    yield from iter_remote_github_trace(args.url, run_id=args.run_id, max_bytes=args.max_bytes)


def cmd_github_trace_train(args) -> int:
    trajectories = list(_github_trace_trajectory(args))
    if not trajectories:
        raise RuntimeError("no GitHub trajectory records were available")
    rules = mine_recovery_rules(trajectories, max_actions=args.max_actions, min_occurrences=args.min_occurrences)
    source = args.source_id or "github-trace"
    units = compile_recovery_rules(rules, source, min_confidence=args.min_confidence)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(json.dumps(u.to_dict(), sort_keys=True) for u in units) + ("\n" if units else ""), encoding="utf-8")
    report = {
        "source": source,
        "trajectories": len(trajectories),
        "events": sum(len(t.events) for t in trajectories),
        "recovery_rules": [
            {
                "error_signature": r.error_signature,
                "actions": [a.name for a in r.actions],
                "occurrences": r.occurrences,
                "successful_recoveries": r.successful_recoveries,
                "confidence": r.confidence,
                "digest": r.digest,
            } for r in rules
        ],
        "compiled_units": len(units),
        "recorded_model_outcome": {
            "reward": 0.7407407407407407,
            "passed": 40,
            "total": 54,
            "model_calls": 135,
            "model": "claude-haiku-4-5-20251001-v1:0",
        },
        "hidden_reasoning_ingested": False,
        "output": str(out),
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


def cmd_github_trace_audit(args) -> int:
    if args.source_id:
        spec = next((s for s in GITHUB_TRACE_SOURCES if s.source_id == args.source_id), None)
        if spec is None:
            raise ValueError(f"unknown source_id: {args.source_id}")
        result = audit_trace(spec)
    else:
        result = {"sources": [audit_trace(s) for s in GITHUB_TRACE_SOURCES]}
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


def cmd_trace_ingest(args) -> int:
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with out.open("w", encoding="utf-8") as f:
        for traj in iter_trajectory_file(args.path):
            f.write(json.dumps(traj.canonical(), sort_keys=True) + "\n")
            count += 1
            if args.limit is not None and count >= args.limit:
                break
    print(json.dumps({"trajectories": count, "output": str(out)}, indent=2, sort_keys=True))
    return 0


def cmd_frontier_remote(args) -> int:
    spec = RemoteDatasetSpec(args.dataset, args.config, args.split, args.revision, args.limit, True)
    if args.dataset.lower().endswith("orchard"):
        manifest = TRAINING_MANIFESTS[0]
    else:
        manifest = TRAINING_MANIFESTS[1]
    trainer = StreamingECUTrainer(min_support=args.min_support, max_len=args.max_actions, max_patterns=args.max_patterns, max_values=args.max_values)
    trainer.update_many(stream_to_trajectories(spec))
    units, diagnostics = trainer.compile(manifest)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(json.dumps(u.to_dict(), sort_keys=True) for u in units) + ("\n" if units else ""), encoding="utf-8")
    print(json.dumps({"diagnostics": diagnostics, "units": len(units), "output": str(out)}, indent=2, sort_keys=True))
    return 0





def cmd_frontier_compare(args) -> int:
    snapshot = TOOLATHLON_VERIFIED_AUG_2026
    if args.replay_json:
        replay = load_replay_metrics(args.replay_json)
        mosaic_success = replay.success_rate
        tasks = replay.tasks
        frontier_calls = replay.frontier_calls
        latency_ms = replay.latency_ms
        cost_usd = replay.cost_usd
    else:
        # Local result is intentionally allowed to be non-comparable unless it
        # covers the exact benchmark task count. This prevents fixture claims
        # from being presented as benchmark wins.
        mosaic_success = args.mosaic_success
        tasks = args.tasks
        frontier_calls = args.frontier_calls
        latency_ms = args.latency_ms
        cost_usd = args.cost_usd
    result = compare_to_published_snapshot(
        snapshot,
        mosaic_success=mosaic_success,
        mosaic_frontier_calls=frontier_calls,
        mosaic_tasks=tasks,
        mosaic_latency_ms=latency_ms,
        mosaic_cost_usd=cost_usd,
    )
    print(json.dumps({
        "comparison": result.as_dict(),
        "frontier_snapshot": {
            "benchmark": snapshot.benchmark,
            "tasks": snapshot.tasks,
            "as_of": snapshot.as_of,
            "best_model": snapshot.best_model,
            "best_score": snapshot.best_score,
        },
    }, indent=2, sort_keys=True))
    return 0 if result.comparable and result.superior_quality else 2

def cmd_omega_gauntlet(args) -> int:
    print(json.dumps(run_omega_gauntlet().as_dict(), indent=2, sort_keys=True))
    return 0



# Long-horizon / self-evolving benchmark is imported lazily to keep CLI startup cheap.
def cmd_recursive_gauntlet(args) -> int:
    from ..gauntlets.long_horizon import recursive_long_horizon_gauntlet
    report = recursive_long_horizon_gauntlet(rounds=args.rounds, base_tasks=args.tasks, seed=args.seed)
    print(json.dumps(report.as_dict(), indent=2, sort_keys=True))
    return 0 if report.all_checks_passed else 2



def cmd_verified_recursive_gauntlet(args) -> int:
    from ..gauntlets.verified_recursive import run_verified_recursive_gauntlet
    report = run_verified_recursive_gauntlet(rounds=args.rounds, tasks=args.tasks)
    print(json.dumps(report.as_dict(), indent=2, sort_keys=True))
    return 0 if report.all_checks_passed else 2


def cmd_github_trace_gauntlet(args) -> int:
    from ..gauntlets.github_trace import run_github_trace_gauntlet
    report = run_github_trace_gauntlet(args.sample_path)
    print(json.dumps(report.as_dict(), indent=2, sort_keys=True))
    return 0 if report.all_checks_passed else 2


def cmd_omega2_gauntlet(args) -> int:
    report = run_omega2_gauntlet(tasks=args.tasks, depth=args.depth)
    print(json.dumps(report.as_dict(), indent=2, sort_keys=True))
    return 0 if report.all_checks_passed else 2


def cmd_recorded_compare(args) -> int:
    bench = CTI_REALM_50_JUNE_2026 if args.benchmark == "cti-realm-50" else None
    if bench is None:
        raise ValueError("unsupported recorded benchmark")
    result = compare_recorded_score(bench, args.mosaic_score, args.tasks)
    result["mosaic_score_source"] = "user-supplied measurement"
    result["claimable_superiority"] = False
    result["claim_note"] = (
        "Published model outcomes are real benchmark evidence, but a MOSAIC score becomes a valid superiority claim only "
        "when produced by an independently recorded run on the same task set and scoring protocol."
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0



def cmd_discover_trajectories(args) -> int:
    roots = args.roots if args.roots else None
    discovered = discover_session_sources(
        roots,
        min_confidence=args.min_confidence,
        max_files=args.max_files,
        max_file_bytes=args.max_file_bytes,
        include_sqlite=not args.no_sqlite,
    )
    payload = {
        "count": len(discovered),
        "sources": [d.as_dict() for d in discovered],
    }
    if args.output:
        out = Path(args.output); out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def cmd_discover_train(args) -> int:
    sources = discover_session_sources(args.roots or None, min_confidence=args.min_confidence, max_files=args.max_files, max_file_bytes=args.max_file_bytes, include_sqlite=not args.no_sqlite)
    selected = sources[:args.max_sources]
    trajectories = []
    for src in selected:
        if src.agent == "unknown" and not args.include_unknown:
            continue
        for traj in iter_discovered_trajectories(src):
            trajectories.append(traj)
            if len(trajectories) >= args.max_trajectories:
                break
        if len(trajectories) >= args.max_trajectories:
            break
    # Keep the three learning lines separate: downstream consumers can inspect source/view provenance.
    from ..experience import ExperienceCompiler
    compiler = ExperienceCompiler()
    candidates, report = compiler.mine(trajectories)
    payload = {"sources": [x.as_dict() for x in selected], "trajectories": len(trajectories), "report": report.__dict__, "candidates": [c.patch.digest for c in candidates]}
    if args.output:
        out=Path(args.output); out.parent.mkdir(parents=True, exist_ok=True); out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0

def cmd_network_gauntlet(args) -> int:
    result = run_network_gauntlet()
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result.get("passed") else 1


def cmd_ephemeral_gauntlet(args) -> int:
    report = run_ephemeral_gauntlet(logical_agents=args.logical_agents, concurrent_cells=args.concurrent_cells, tenants=args.tenants)
    print(json.dumps(report.__dict__, indent=2, sort_keys=True))
    return 0 if report.all_checks_passed else 2


def cmd_network_query(args) -> int:
    registry = CapabilityRegistry()
    # Local JSON capability snapshots can be loaded by deployments; CLI keeps the reference behavior deterministic.
    offers = registry.query(CapabilityQuery(
        family=args.family, min_quality=args.min_quality, max_cost_usd=args.max_cost,
        max_latency_ms=args.max_latency, locality=args.locality, min_verification_level=args.min_verification
    ))
    print(json.dumps({"matches": [o.digest for o in offers], "count": len(offers)}, indent=2, sort_keys=True))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="mosaic", description="MOSAIC Ω executable-computation substrate")
    sub = p.add_subparsers(dest="command", required=True)
    demo = sub.add_parser("demo", help="run the end-to-end reference evolution demo")
    demo.add_argument("--generations", type=int, default=8)
    demo.add_argument("--population", type=int, default=24)
    demo.add_argument("--budget", type=int, default=12)
    demo.add_argument("--seed", type=int, default=42)
    demo.set_defaults(func=cmd_demo)
    g = sub.add_parser("gauntlet", help="run the production CPU-first performance gauntlet")
    g.set_defaults(func=lambda _args: (print(json.dumps(run_gauntlet().as_dict(), indent=2, sort_keys=True)) or 0))
    og = sub.add_parser("omega-gauntlet", help="run the Ω execution-compiler superiority gauntlet")
    og.set_defaults(func=cmd_omega_gauntlet)
    gtg = sub.add_parser("github-trace-gauntlet", help="run the real GitHub model-trace distillation/recovery gauntlet")
    gtg.add_argument("--sample-path", default=None)
    gtg.set_defaults(func=cmd_github_trace_gauntlet)
    o2 = sub.add_parser("omega2-gauntlet", help="run the Ω2 evolving collective execution gauntlet")
    o2.add_argument("--tasks", type=int, default=64)
    o2.add_argument("--depth", type=int, default=12)
    o2.set_defaults(func=cmd_omega2_gauntlet)
    gta = sub.add_parser("github-trace-audit", help="audit known GitHub-committed real model trajectory sources")
    gta.add_argument("--source-id", default=None)
    gta.set_defaults(func=cmd_github_trace_audit)
    gtt = sub.add_parser("github-trace-train", help="distill observable recovery operators from a real GitHub model trajectory")
    gtt.add_argument("--path", default=None, help="local JSONL trace; use --url for a network-enabled worker")
    gtt.add_argument("--url", default=None)
    gtt.add_argument("--run-id", default="github-trace")
    gtt.add_argument("--limit-records", type=int, default=None)
    gtt.add_argument("--max-bytes", type=int, default=256 * 1024 * 1024)
    gtt.add_argument("--max-actions", type=int, default=3)
    gtt.add_argument("--min-occurrences", type=int, default=1)
    gtt.add_argument("--min-confidence", type=float, default=0.75)
    gtt.add_argument("--source-id", default="when2buy/llm-trajectory-data:american-option-haiku")
    gtt.add_argument("--output", default="dist/github-recovery-ecus.jsonl")
    gtt.set_defaults(func=cmd_github_trace_train)

    ds = sub.add_parser("discover-trajectories", help="discover agent session/trajectory stores by filesystem and content search")
    ds.add_argument("roots", nargs="*", help="optional roots; defaults to cwd/home/common workspace roots")
    ds.add_argument("--min-confidence", type=float, default=0.35)
    ds.add_argument("--max-files", type=int, default=20000)
    ds.add_argument("--max-file-bytes", type=int, default=256 * 1024 * 1024)
    ds.add_argument("--no-sqlite", action="store_true")
    ds.add_argument("--output", default=None)
    ds.set_defaults(func=cmd_discover_trajectories)

    dtr = sub.add_parser("discover-train", help="discover unknown agent session stores, normalize trajectories, and learn experience")
    dtr.add_argument("roots", nargs="*", help="optional roots to search")
    dtr.add_argument("--min-confidence", type=float, default=0.35)
    dtr.add_argument("--max-files", type=int, default=20000)
    dtr.add_argument("--max-file-bytes", type=int, default=256 * 1024 * 1024)
    dtr.add_argument("--max-sources", type=int, default=32)
    dtr.add_argument("--max-trajectories", type=int, default=256)
    dtr.add_argument("--include-unknown", action="store_true")
    dtr.add_argument("--no-sqlite", action="store_true")
    dtr.add_argument("--output", default=None)
    dtr.set_defaults(func=cmd_discover_train)

    ti = sub.add_parser("trace-ingest", help="ingest Inspect/JSON/ATIF/OpenTelemetry trajectory logs")
    ti.add_argument("path")
    ti.add_argument("--limit", type=int, default=None)
    ti.add_argument("--output", default="dist/ingested-trajectories.jsonl")
    ti.set_defaults(func=cmd_trace_ingest)
    tr = sub.add_parser("trace-import", help="normalize a JSONL execution trace into MOSAIC trajectory format")
    tr.add_argument("path")
    tr.add_argument("--run-id", default="imported")
    tr.set_defaults(func=lambda args: (print(json.dumps(export_atif_like(load_jsonl(Path(args.path), args.run_id)), indent=2, sort_keys=True)) or 0))
    et = sub.add_parser("ecu-train", help="distill training-eligible frontier trajectories into executable compute units")
    et.add_argument("path")
    et.add_argument("--adapter", choices=("orchard", "gpt56"), required=True)
    et.add_argument("--limit", type=int, default=1000)
    et.add_argument("--min-support", type=int, default=2)
    et.add_argument("--max-actions", type=int, default=8)
    et.add_argument("--source-manifest", default="cli-import")
    et.add_argument("--output", default="dist/ecus.jsonl")
    et.set_defaults(func=cmd_ecu_train)
    fl = sub.add_parser("frontier-learn", help="learn trajectory policy + motifs and compile verified ECU candidates")
    fl.add_argument("path")
    fl.add_argument("--adapter", choices=("orchard", "gpt56"), required=True)
    fl.add_argument("--limit", type=int, default=1000)
    fl.add_argument("--min-support", type=int, default=2)
    fl.add_argument("--max-actions", type=int, default=6)
    fl.add_argument("--report-motifs", type=int, default=10)
    fl.add_argument("--output", default="dist/frontier-learned-ecus.jsonl")
    fl.set_defaults(func=cmd_frontier_learn)
    fg = sub.add_parser("frontier-gauntlet", help="run the trajectory-to-ECU superiority gauntlet")
    fg.set_defaults(func=lambda _args: (print(json.dumps(run_frontier_gauntlet().as_dict(), indent=2, sort_keys=True)) or 0))
    cg = sub.add_parser("collective-gauntlet", help="run the Ω∞-COLLECTIVE compiler/economics gauntlet")
    cg.set_defaults(func=lambda _args: (print(json.dumps(run_collective_gauntlet().as_dict(), indent=2, sort_keys=True)) or 0))
    fm = sub.add_parser("frontier-max", help="run held-out-gated diversity-aware trajectory optimization")
    fm.add_argument("path")
    fm.add_argument("--adapter", choices=("orchard", "gpt56"), required=True)
    fm.add_argument("--limit", type=int, default=10000)
    fm.add_argument("--epochs", type=int, default=4)
    fm.add_argument("--batch-size", type=int, default=64)
    fm.add_argument("--learning-rate", type=int, default=8)
    fm.add_argument("--output", default="dist/frontier-max-ecus.jsonl")
    fm.set_defaults(func=cmd_frontier_max)
    fr = sub.add_parser("frontier-remote", help="stream training-eligible trajectories from Hugging Face outside sandbox")
    fr.add_argument("dataset")
    fr.add_argument("--config", default="swe")
    fr.add_argument("--split", default="train")
    fr.add_argument("--revision", default="main")
    fr.add_argument("--limit", type=int, default=100000)
    fr.add_argument("--min-support", type=int, default=8)
    fr.add_argument("--max-actions", type=int, default=8)
    fr.add_argument("--max-patterns", type=int, default=4096)
    fr.add_argument("--max-values", type=int, default=32)
    fr.add_argument("--output", default="dist/frontier-remote-ecus.jsonl")
    fr.set_defaults(func=cmd_frontier_remote)
    mx = sub.add_parser("max-gauntlet", help="run the radical MOSAIC superiority gauntlet")
    mx.set_defaults(func=lambda _args: (print(json.dumps(run_maximal_gauntlet().as_dict(), indent=2, sort_keys=True)) or 0))
    fc = sub.add_parser("frontier-compare", help="compare a replayed MOSAIC run against the published Toolathlon-Verified frontier snapshot")
    fc.add_argument("--replay-json", default=None, help="JSON ReplayMetrics file from a real same-task-set run")
    fc.add_argument("--mosaic-success", type=float, default=1.0)
    fc.add_argument("--tasks", type=int, default=0)
    fc.add_argument("--frontier-calls", type=int, default=0)
    fc.add_argument("--latency-ms", type=float, default=None)
    fc.add_argument("--cost-usd", type=float, default=None)
    fc.set_defaults(func=cmd_frontier_compare)
    rc = sub.add_parser("recorded-compare", help="compare MOSAIC against published real model outcomes from GitHub-hosted evaluation reports")
    rc.add_argument("--benchmark", choices=("cti-realm-50",), required=True)
    rc.add_argument("--mosaic-score", type=float, required=True)
    rc.add_argument("--tasks", type=int, required=True)
    rc.set_defaults(func=cmd_recorded_compare)
    eg = sub.add_parser("experience-gauntlet", help="run Ω4 evidence-grounded continual experience compiler gauntlet")
    eg.add_argument("--trajectories", type=int, default=24)
    eg.set_defaults(func=lambda args: (print(json.dumps(run_experience_gauntlet(trajectories=args.trajectories).as_dict(), indent=2, sort_keys=True)) or 0))
    vr = sub.add_parser("verified-recursive-gauntlet", help="run verified recursive decomposition/proof/execution gauntlet")
    vr.add_argument("--rounds", type=int, default=4)
    vr.add_argument("--tasks", type=int, default=12)
    vr.set_defaults(func=cmd_verified_recursive_gauntlet)
    rh = sub.add_parser("recursive-gauntlet", help="run self-generating long-horizon coding benchmark and recursive self-improvement loop")
    rh.add_argument("--rounds", type=int, default=3)
    rh.add_argument("--tasks", type=int, default=8)
    rh.add_argument("--seed", type=int, default=13)
    rh.set_defaults(func=cmd_recursive_gauntlet)
    nw = sub.add_parser("network-gauntlet", help="run Ω5 verified-useful-work network/economics gauntlet")
    nw.set_defaults(func=cmd_network_gauntlet)
    nq = sub.add_parser("network-query", help="query the local capability-market reference registry")
    nq.add_argument("family")
    nq.add_argument("--min-quality", type=float, default=0.999)
    nq.add_argument("--max-cost", type=float, default=float("inf"))
    nq.add_argument("--max-latency", type=float, default=float("inf"))
    nq.add_argument("--locality", default=None)
    nq.add_argument("--min-verification", type=int, default=1)
    nq.set_defaults(func=cmd_network_query)
    eg6 = sub.add_parser("ephemeral-gauntlet", help="run Ω6 multi-tenant ephemeral-agent fabric Gauntlet")
    eg6.add_argument("--logical-agents", type=int, default=10000)
    eg6.add_argument("--concurrent-cells", type=int, default=1000)
    eg6.add_argument("--tenants", type=int, default=100)
    eg6.set_defaults(func=cmd_ephemeral_gauntlet)
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

