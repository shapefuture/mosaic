from __future__ import annotations

from dataclasses import dataclass, asdict
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
from typing import Any, Iterable, Iterator, Mapping, Sequence


TRAJ_EXTS = {".jsonl", ".ndjson", ".json", ".eval", ".trace", ".jsonl.gz", ".db", ".sqlite", ".sqlite3"}
DEFAULT_MAX_FILE_BYTES = 256 * 1024 * 1024
DEFAULT_MAX_FILES = 20_000

_AGENT_PATTERNS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("claude", ("claude", "anthropic", "assistant", "tool_use", "tool_result")),
    ("codex", ("codex", "openai", "shell_command", "computer_call")),
    ("cursor", ("cursor", "composer", "apply_patch")),
    ("gemini", ("gemini", "google", "function_call")),
    ("copilot", ("copilot", "github", "tool_use")),
    ("openhands", ("openhands", "action", "observation")),
    ("swe-agent", ("swe-agent", "traj", "action", "observation")),
    ("aider", ("aider", "edit", "repo_map")),
    ("opencode", ("opencode", "tool", "message")),
    ("qwen", ("qwen", "tool_call", "assistant")),
    ("generic-agent", ("tool_calls", "trajectory", "messages", "events", "observations")),
)

_SIGNATURE_KEYS = {
    "trajectory_id", "run_id", "events", "tool_calls", "messages", "observations", "actions",
    "thought", "reasoning", "usage", "model", "finish_reason", "verifier", "reward",
}


@dataclass(frozen=True)
class DiscoveredSource:
    path: str
    format: str
    agent: str
    confidence: float
    bytes: int
    digest: str
    source_reason: str
    root: str
    inode: int | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _iter_roots(roots: Sequence[str | Path] | None = None) -> tuple[Path, ...]:
    if roots:
        return tuple(Path(r).expanduser().resolve() for r in roots if Path(r).exists())
    candidates = [Path.cwd(), Path.home()]
    for raw in (os.getenv("PWD"), os.getenv("HOME"), "/mnt/data", "/workspace", "/workspaces", "/project"):
        if raw:
            p = Path(raw).expanduser()
            if p.exists():
                candidates.append(p.resolve())
    # Avoid duplicate roots while preserving order.
    seen: set[str] = set()
    out: list[Path] = []
    for p in candidates:
        s = str(p)
        if s not in seen:
            seen.add(s)
            out.append(p)
    return tuple(out)


def _rg_files(root: Path, *, max_files: int) -> Iterator[Path]:
    rg = shutil.which("rg")
    if rg:
        cmd = [rg, "--files", "--hidden", "--follow", "--glob", "!.git", str(root)]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=30, check=False)
            count = 0
            for line in proc.stdout.splitlines():
                if count >= max_files:
                    break
                p = Path(line)
                if p.is_file():
                    count += 1
                    yield p
            if proc.returncode in (0, 1):
                return
        except (OSError, subprocess.SubprocessError):
            pass
    # Portable fallback.
    count = 0
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames[:] = [d for d in dirnames if d not in {".git", "node_modules", ".venv", "venv", "__pycache__"}]
        for name in filenames:
            if count >= max_files:
                return
            count += 1
            yield Path(dirpath) / name


def _read_sample(path: Path, limit: int = 64 * 1024) -> bytes:
    try:
        with path.open("rb") as f:
            return f.read(limit)
    except (OSError, PermissionError):
        return b""


def _json_keys(sample: bytes) -> set[str]:
    text = sample.decode("utf-8", errors="ignore")
    keys: set[str] = set()
    # Cheap key discovery across JSON/JSONL and log-like files.
    for m in re.finditer(r'"([A-Za-z_][A-Za-z0-9_-]{1,80})"\s*:', text):
        keys.add(m.group(1))
    return keys


def _classify_agent(path: Path, sample: bytes, keys: set[str]) -> tuple[str, float, str]:
    lower = (str(path).lower() + " " + sample[:32768].decode("utf-8", errors="ignore").lower())
    best_agent = "unknown"
    best_score = 0.0
    best_hits: list[str] = []
    for agent, patterns in _AGENT_PATTERNS:
        hits = [p for p in patterns if p in lower or p in keys]
        if not hits:
            continue
        score = min(0.99, 0.18 * len(hits) + (0.25 if agent != "generic-agent" else 0.0))
        if agent in {"claude", "codex", "cursor", "gemini", "copilot", "openhands", "swe-agent", "aider", "opencode", "qwen"} and agent in lower:
            score += 0.25
        if score > best_score:
            best_agent, best_score, best_hits = agent, min(score, 0.99), hits
    return best_agent, best_score, ",".join(best_hits[:8])


def _classify_format(path: Path, sample: bytes) -> str | None:
    suffix = path.suffix.lower()
    if path.name.endswith(".jsonl.gz"):
        return "jsonl.gz"
    if suffix in {".jsonl", ".ndjson"}:
        return "jsonl"
    if suffix == ".eval":
        return "inspect-eval"
    if suffix == ".trace":
        return "trace"
    if suffix == ".json":
        return "json"
    if suffix in {".db", ".sqlite", ".sqlite3"}:
        return "sqlite"
    if suffix in {".txt", ".log", ".md"}:
        text = sample.decode("utf-8", errors="ignore").lower()
        if any(k in text for k in ("tool_call", "tool_use", "trajectory", "observation", "assistant")):
            return "text-trace"
    return None


def _score_candidate(path: Path, sample: bytes, fmt: str, keys: set[str]) -> tuple[float, str]:
    score = 0.0
    reasons: list[str] = []
    overlap = _SIGNATURE_KEYS.intersection(keys)
    if overlap:
        score += min(0.6, 0.1 * len(overlap))
        reasons.append("keys=" + ",".join(sorted(overlap)[:8]))
    if fmt in {"jsonl", "ndjson", "inspect-eval", "trace", "sqlite"}:
        score += 0.15
        reasons.append("trace-like-format")
    text = sample.decode("utf-8", errors="ignore").lower()
    for token in ("tool_call", "tool_use", "assistant", "observation", "trajectory", "verifier", "reward"):
        if token in text:
            score += 0.04
    # A single JSON object containing a clear role/tool structure is a strong signal.
    if '"role"' in text and ('"tool"' in text or '"content"' in text):
        score += 0.15
        reasons.append("chat-schema")
    return min(0.99, score), ";".join(reasons)


def _digest_path(path: Path, max_bytes: int) -> tuple[str, int]:
    h = sha256()
    total = 0
    try:
        with path.open("rb") as f:
            while total < max_bytes:
                chunk = f.read(min(1024 * 1024, max_bytes - total))
                if not chunk:
                    break
                h.update(chunk)
                total += len(chunk)
    except (OSError, PermissionError):
        return "", 0
    return h.hexdigest(), total


def discover_session_sources(
    roots: Sequence[str | Path] | None = None,
    *,
    min_confidence: float = 0.35,
    max_files: int = DEFAULT_MAX_FILES,
    max_file_bytes: int = DEFAULT_MAX_FILE_BYTES,
    include_sqlite: bool = True,
) -> list[DiscoveredSource]:
    """Discover agent trajectories without relying on hard-coded agent paths.

    Uses ``rg --files`` when available, then content fingerprints likely traces.
    Known agent directories are only hints; arbitrary install locations/projects are
    discoverable because classification is based on file content and session schema.
    """
    seen_files: set[tuple[int, int] | str] = set()
    seen_digests: set[str] = set()
    results: list[DiscoveredSource] = []
    for root in _iter_roots(roots):
        for path in _rg_files(root, max_files=max_files):
            try:
                st = path.stat()
            except OSError:
                continue
            if not path.is_file() or st.st_size <= 0 or st.st_size > max_file_bytes:
                continue
            fmt = _classify_format(path, _read_sample(path))
            if fmt is None or (fmt == "sqlite" and not include_sqlite):
                continue
            key = (st.st_dev, st.st_ino)
            if key in seen_files or str(path) in seen_files:
                continue
            seen_files.add(key)
            sample = _read_sample(path)
            if not sample:
                continue
            keys = _json_keys(sample)
            agent, agent_conf, reason = _classify_agent(path, sample, keys)
            score, score_reason = _score_candidate(path, sample, fmt, keys)
            score = min(0.99, score + 0.35 * agent_conf)
            if score < min_confidence:
                continue
            digest, hashed = _digest_path(path, max_file_bytes)
            if not digest or digest in seen_digests:
                continue
            seen_digests.add(digest)
            results.append(DiscoveredSource(str(path), fmt, agent, score, hashed, digest, ";".join(x for x in (reason, score_reason) if x), str(root), st.st_ino))
    results.sort(key=lambda x: (-x.confidence, -x.bytes, x.agent, x.path))
    return results


def extract_from_sqlite(path: str | Path, *, max_rows: int = 1000) -> list[dict[str, Any]]:
    """Best-effort SQLite session discovery using schema/content signatures.

    We do not assume a vendor-specific table name. Tables/columns are inspected and
    JSON/text columns are sampled. This is deliberately read-only.
    """
    rows: list[dict[str, Any]] = []
    conn = sqlite3.connect(f"file:{Path(path).resolve()}?mode=ro", uri=True)
    try:
        tables = [r[0] for r in conn.execute("select name from sqlite_master where type='table' and name not like 'sqlite_%'")]
        for table in tables:
            cols = [r[1] for r in conn.execute(f'pragma table_info("{table.replace(chr(34), chr(34)*2)}")')]
            if not cols:
                continue
            wanted = [c for c in cols if any(t in c.lower() for t in ("message", "content", "event", "tool", "trace", "session", "json", "payload", "role"))]
            if not wanted:
                continue
            sql = f'select * from "{table.replace(chr(34), chr(34)*2)}" limit ?'
            cur = conn.execute(sql, (max_rows,))
            names = [d[0] for d in cur.description]
            for raw in cur.fetchall():
                obj = dict(zip(names, raw))
                if any(isinstance(v, (str, bytes)) and any(k in str(v).lower() for k in ("tool", "assistant", "trajectory", "observation", "message")) for v in obj.values()):
                    rows.append(obj)
                if len(rows) >= max_rows:
                    return rows
    finally:
        conn.close()
    return rows


def iter_discovered_trajectories(source: DiscoveredSource) -> Iterator[Any]:
    """Materialize normalized trajectories from a discovered source when supported.

    JSON/JSONL/Inspect/trace sources are delegated to MOSAIC's existing format
    adapters. SQLite sources are read-only and converted from discovered rows into
    minimal observable events without assuming a vendor schema.
    """
    from ..data.trajectory_formats import iter_trajectory_file
    from ..trajectory.events import Trajectory, TrajectoryEvent

    p = Path(source.path)
    if source.format != "sqlite":
        yield from iter_trajectory_file(p)
        return
    rows = extract_from_sqlite(p, max_rows=10_000)
    for i, row in enumerate(rows):
        text_fields = {str(k): v for k, v in row.items() if isinstance(v, (str, int, float, bool)) and v is not None}
        action = str(row.get("tool_name") or row.get("action") or row.get("event") or "session_event")
        observation = json.dumps(text_fields, sort_keys=True, default=str)[:4000]
        yield Trajectory(
            str(row.get("session_id") or row.get("run_id") or f"sqlite:{p.name}:{i}"),
            (TrajectoryEvent(0, "discovered_sqlite", action, observation, "", None, 0.0, 0.0, {"discovered_agent": source.agent, "source": str(p)}),),
        )
