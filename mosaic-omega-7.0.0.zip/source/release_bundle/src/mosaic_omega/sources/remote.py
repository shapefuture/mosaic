from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

@dataclass(frozen=True)
class RemoteSourceConfig:
    name: str
    base_url: str
    mode: str = "mcp"
    allow_hosts: Tuple[str, ...] = ()
    max_bytes: int = 2_000_000_000

    def validate(self) -> None:
        if self.mode not in {"mcp", "https", "worker"}:
            raise ValueError("unsupported remote source mode")
        if not self.base_url.startswith(("https://", "http://")):
            raise ValueError("remote source must use http(s)")
        if self.max_bytes <= 0:
            raise ValueError("max_bytes must be positive")

# Production connector blueprint: actual outbound transport is deliberately external
# to the sandbox (e.g. OpenAI Secure MCP Tunnel / private worker). The sandbox never
# attempts to bypass its own egress restrictions.
DEFAULT_SOURCES = (
    RemoteSourceConfig("huggingface", "https://huggingface.co", allow_hosts=("huggingface.co", "hf.co", "xethub.hf.co")),
    RemoteSourceConfig("github", "https://github.com", allow_hosts=("github.com", "raw.githubusercontent.com")),
    RemoteSourceConfig("openai-secure-mcp", "https://developers.openai.com", mode="mcp"),
)
