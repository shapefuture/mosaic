from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CostPoint:
    hourly_usd: float
    watts: float
    fixed_latency_ms: float = 0.0

    def usd_for_ms(self, latency_ms: float) -> float:
        return self.hourly_usd * max(0.0, latency_ms + self.fixed_latency_ms) / 3_600_000.0

    def energy_for_ms(self, latency_ms: float) -> float:
        return self.watts * max(0.0, latency_ms + self.fixed_latency_ms) / 1000.0


@dataclass(frozen=True)
class UtilityWeights:
    latency: float = 1.0
    cost: float = 3.0
    energy: float = 0.15
    startup: float = 0.5
    gpu_penalty: float = 1000.0


def score_latency_cost_energy(
    latency_ms: float,
    cost_usd: float,
    energy_j: float,
    startup_ms: float,
    device_class: str,
    weights: UtilityWeights,
) -> float:
    gpu_penalty = weights.gpu_penalty if device_class == "gpu" else 0.0
    return (
        weights.latency * latency_ms
        + weights.cost * cost_usd
        + weights.energy * energy_j
        + weights.startup * startup_ms
        + gpu_penalty
    )


def quality_speed_per_dollar_latency(
    *,
    quality: float,
    work_units: float,
    latency_ms: float,
    cost_usd: float,
    energy_j: float = 0.0,
) -> float:
    """Verified quality * useful work / (USD * latency), optionally energy-adjusted."""
    q = max(0.0, min(1.0, float(quality)))
    work = max(float(work_units), 1e-12)
    seconds = max(float(latency_ms) / 1000.0, 1e-12)
    dollars = max(float(cost_usd), 1e-30)
    energy_factor = 1.0 + 0.001 * max(float(energy_j), 0.0)
    return q * work / (seconds * dollars * energy_factor)
