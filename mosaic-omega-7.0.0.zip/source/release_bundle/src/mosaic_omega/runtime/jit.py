from __future__ import annotations

from dataclasses import dataclass
from random import Random
from statistics import mean
from typing import Any, Mapping, Sequence

from .agent_program import AgentProgramCompiler, CompiledProgram, ProgramNode


@dataclass(frozen=True)
class ToolContract:
    name: str
    preconditions: tuple[str, ...] = ()
    postconditions: tuple[str, ...] = ()
    capability: str = "cpu"


@dataclass(frozen=True)
class PlanEstimate:
    serial_ms: float
    parallel_ms: float
    hedge_ms: float
    expected_cost_usd: float

    @property
    def minimum_ms(self) -> float:
        return min(self.serial_ms, self.parallel_ms, self.hedge_ms)


@dataclass(frozen=True)
class JITPlan:
    program: CompiledProgram
    estimate: PlanEstimate
    valid: bool
    rejection_reason: str = ""


class JITPlanner:
    """Compile multiple candidate programs, validate invariants, and choose the cheapest."""

    def __init__(self, contracts: Mapping[str, ToolContract] | None = None, *, seed: int = 42):
        self.contracts = dict(contracts or {})
        self.rng = Random(seed)
        self.compiler = AgentProgramCompiler()

    def _valid(self, nodes: Sequence[ProgramNode]) -> tuple[bool, str]:
        known = set()
        for n in nodes:
            name = n.action.name if n.action else n.kind
            c = self.contracts.get(name)
            if c is not None and c.capability != n.capability:
                return False, f"capability mismatch for {name}"
            if any(d not in known for d in n.dependencies):
                return False, f"missing dependency for {name}"
            known.add(n.node_id)
        return True, ""

    def _estimate(self, program: CompiledProgram) -> PlanEstimate:
        lat = {n.node_id: max(0.001, n.latency_ms) for n in program.nodes}
        serial = sum(lat.values())
        parallel = sum(max((lat[nid] for nid in wave), default=0.0) for wave in program.waves)
        # Hedge is useful only when there are independent branches; use a deterministic
        # bounded simulation over latency perturbations rather than assuming ideal tails.
        if len(program.waves) > 1 and any(len(w) > 1 for w in program.waves):
            samples = []
            for _ in range(64):
                total = 0.0
                for wave in program.waves:
                    draws = [lat[nid] * self.rng.uniform(0.85, 1.20) for nid in wave]
                    total += min(draws) if len(draws) > 1 else draws[0]
                samples.append(total)
            hedge = mean(samples)
        else:
            hedge = serial
        cost = sum(max(0.0, n.cost_usd) for n in program.nodes)
        return PlanEstimate(serial, parallel, hedge, cost)

    def compile_candidates(self, candidates: Sequence[Sequence[ProgramNode]]) -> tuple[JITPlan, ...]:
        out = []
        for nodes in candidates:
            valid, reason = self._valid(nodes)
            program = self.compiler.compile(nodes)
            out.append(JITPlan(program, self._estimate(program), valid, reason))
        return tuple(out)

    def choose(self, candidates: Sequence[Sequence[ProgramNode]]) -> JITPlan:
        plans = [p for p in self.compile_candidates(candidates) if p.valid]
        if not plans:
            raise ValueError("no valid candidate plans")
        return min(plans, key=lambda p: (p.estimate.minimum_ms, p.estimate.expected_cost_usd, p.program.digest))
