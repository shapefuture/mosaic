from __future__ import annotations

from dataclasses import dataclass

from ..model import Candidate, Observation


@dataclass(frozen=True)
class DispatchRule:
    min_size: int
    max_size: int
    candidate_id: str


class Dispatcher:
    def __init__(self, rules: tuple[DispatchRule, ...], fallback: str):
        self.rules = rules
        self.fallback = fallback

    def select(self, input_size: int) -> str:
        for rule in self.rules:
            if rule.min_size <= input_size <= rule.max_size:
                return rule.candidate_id
        return self.fallback

    def explain(self, input_size: int) -> str:
        selected = self.select(input_size)
        return f"input_size={input_size}: candidate={selected}"


class DispatcherSynthesizer:
    def synthesize(self, observations: list[tuple[Candidate, Observation]]) -> Dispatcher:
        if not observations:
            raise ValueError("at least one observation required")
        valid = [x for x in observations if x[1].correct]
        if not valid:
            raise ValueError("no correct candidates available")
        best = min(valid, key=lambda x: (x[1].latency_ms, x[1].energy_j))
        size = best[0].spec.input_size
        return Dispatcher((DispatchRule(size, size, best[0].genome_id),), best[0].genome_id)
