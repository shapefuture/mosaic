from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class EconomicPolicy:
    max_latency_ms: float = 1000.0
    max_cost_usd: float = 1.0
    max_energy_j: float = 10000.0
    min_quality: float = 0.999999
    gpu_min_margin: float = 0.20
    remote_cpu_min_margin: float = 0.05


@dataclass(frozen=True)
class EconomicScore:
    latency_ms: float
    cost_usd: float
    energy_j: float
    quality: float
    useful_work: float

    @property
    def work_per_second_per_usd(self) -> float:
        seconds = max(self.latency_ms / 1000.0, 1e-12)
        return self.useful_work / seconds / max(self.cost_usd, 1e-30)

    @property
    def utility(self) -> float:
        return self.quality * self.useful_work / (
            max(self.latency_ms / 1000.0, 1e-12) * max(self.cost_usd, 1e-30) * (1.0 + 0.01 * self.energy_j)
        )
