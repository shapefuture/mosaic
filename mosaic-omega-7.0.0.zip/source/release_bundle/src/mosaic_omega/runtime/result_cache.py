from __future__ import annotations

from array import array
from collections import OrderedDict
from dataclasses import dataclass
from hashlib import sha256
import struct
from threading import RLock
from typing import Sequence

from ..ir.program import Program


@dataclass(frozen=True)
class CacheStats:
    hits: int
    misses: int
    entries: int


class ResultCache:
    """Bounded exact-result cache with buffer-oriented keying.

    The key is a content hash of canonical IEEE-754 float64 input bytes plus program
    semantics. No approximation or lossy normalization occurs.
    """

    def __init__(self, max_entries: int = 256):
        if max_entries < 1:
            raise ValueError("max_entries must be positive")
        self.max_entries = max_entries
        self._data: OrderedDict[str, tuple[float, ...]] = OrderedDict()
        self._hits = 0
        self._misses = 0
        self._lock = RLock()

    @staticmethod
    def _key(program: Program, x: Sequence[float], policy_version: str = "exact-v1") -> str:
        h = sha256()
        h.update(policy_version.encode())
        h.update(program.digest.encode())
        h.update(struct.pack("<Q", len(x)))
        if isinstance(x, array) and x.typecode == "d":
            h.update(x.tobytes())
        else:
            # Convert once in C-backed array machinery rather than iterating Python objects.
            h.update(array("d", (float(v) for v in x)).tobytes())
        return h.hexdigest()

    def get_or_compute(self, program: Program, x: Sequence[float], compute, policy_version: str = "exact-v1") -> tuple[float, ...]:
        key = self._key(program, x, policy_version)
        with self._lock:
            hit = self._data.get(key)
            if hit is not None:
                self._hits += 1
                self._data.move_to_end(key)
                return hit
            self._misses += 1
        result = tuple(float(v) for v in compute())
        with self._lock:
            self._data[key] = result
            self._data.move_to_end(key)
            while len(self._data) > self.max_entries:
                self._data.popitem(last=False)
        return result

    def stats(self) -> CacheStats:
        with self._lock:
            return CacheStats(self._hits, self._misses, len(self._data))

    def clear(self) -> None:
        with self._lock:
            self._data.clear()
            self._hits = self._misses = 0
