from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from ..ecu.core import ECUEnvironment, ExecutableComputeUnit, ExecutionResult


@dataclass(frozen=True)
class RouteDecision:
    mode: str
    confidence: float
    expected_cost_usd: float
    expected_latency_ms: float
    reason: str


class ExecutionRouter:
    """Evidence-gated cheap-first router: ECU -> local model -> frontier fallback."""

    def __init__(self, units: Iterable[ExecutableComputeUnit] = ()):
        self.units = tuple(units)

    @staticmethod
    def _matches(unit: ExecutableComputeUnit, actions: tuple[str, ...]) -> bool:
        target = tuple(a.strip().lower() for a in actions)
        return target[: len(unit.actions)] == tuple(a.name.lower() for a in unit.actions)

    def choose(self, actions: tuple[str, ...], *, ecu_success_prior: float = 1.0) -> RouteDecision:
        candidates = [u for u in self.units if self._matches(u, actions)]
        if candidates:
            best = min(candidates, key=lambda u: (len(u.actions), u.provenance.get("mean_cost_usd", 0.0), u.digest))
            return RouteDecision("ecu", min(0.999, ecu_success_prior), float(best.provenance.get("mean_cost_usd", 0.0)), float(best.provenance.get("mean_latency_ms", 0.0)), "verified reusable executable unit")
        return RouteDecision("frontier", 0.0, float("inf"), float("inf"), "no verified ECU matched; escalate only because residue is uncovered")

    def execute(self, actions: tuple[str, ...], env: ECUEnvironment, *, params: dict | None = None) -> tuple[RouteDecision, ExecutionResult | None]:
        decision = self.choose(actions)
        if decision.mode != "ecu":
            return decision, None
        if params:
            env.params.update(params)
        for unit in self.units:
            if self._matches(unit, actions):
                return decision, unit.run(env)
        return decision, None
