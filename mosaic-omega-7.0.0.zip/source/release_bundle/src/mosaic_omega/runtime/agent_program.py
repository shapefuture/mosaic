from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any, Iterable, Mapping, Sequence

from ..ecu.core import ECUAction, ECUEnvironment, ExecutableComputeUnit, ExecutionResult
from .dataflow import DataflowNode, DataflowPlanner, DataflowResult


@dataclass(frozen=True)
class ProgramNode:
    node_id: str
    kind: str  # inference, tool, memory, verify, deterministic
    action: ECUAction | None = None
    dependencies: tuple[str, ...] = ()
    capability: str = "cpu"
    latency_ms: float = 0.0
    cost_usd: float = 0.0
    context: str = ""
    deterministic: bool = True


@dataclass(frozen=True)
class CompiledProgram:
    nodes: tuple[ProgramNode, ...]
    waves: tuple[tuple[str, ...], ...]
    removed_nodes: tuple[str, ...]
    fused_nodes: tuple[tuple[str, ...], ...]
    dedup_contexts: int
    digest: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "nodes": [
                {
                    "node_id": n.node_id,
                    "kind": n.kind,
                    "action": None if n.action is None else n.action.name,
                    "dependencies": list(n.dependencies),
                    "capability": n.capability,
                    "latency_ms": n.latency_ms,
                    "cost_usd": n.cost_usd,
                    "context": n.context,
                    "deterministic": n.deterministic,
                }
                for n in self.nodes
            ],
            "waves": [list(w) for w in self.waves],
            "removed_nodes": list(self.removed_nodes),
            "fused_nodes": [list(g) for g in self.fused_nodes],
            "dedup_contexts": self.dedup_contexts,
            "digest": self.digest,
        }


class AgentProgramCompiler:
    """Compile an agent trace into a cost-aware dataflow program.

    This is the trajectory analogue of a compiler pipeline:
      DCE -> context dedup -> reasoning fusion -> capability scheduling -> waves.
    """

    def __init__(self, *, frontier_cost: float = 0.001, parallelism: int = 8):
        self.frontier_cost = frontier_cost
        self.parallelism = parallelism

    @staticmethod
    def _stable_id(node: ProgramNode) -> str:
        payload = f"{node.node_id}|{node.kind}|{node.capability}|{node.action.name if node.action else ''}|{node.context}"
        return sha256(payload.encode()).hexdigest()[:12]

    def compile(self, nodes: Sequence[ProgramNode], *, enable_fusion: bool = True) -> CompiledProgram:
        items = list(nodes)
        removed: list[str] = []

        # Dead-node elimination: a deterministic node that is not on a path to
        # verify/output and has no downstream dependency can disappear.
        consumers = {d for n in items for d in n.dependencies}
        live = [n for n in items if n.kind in {"verify", "inference"} or n.node_id in consumers]
        removed.extend(n.node_id for n in items if n not in live)
        items = live

        # Context common-subexpression elimination. Identical contexts are retained
        # once logically; later consumers refer to the same semantic context.
        seen: dict[str, str] = {}
        rewritten: list[ProgramNode] = []
        dedup = 0
        for n in items:
            context = n.context
            if context and context in seen:
                dedup += 1
                context = f"@ctx:{seen[context]}"
            else:
                if context:
                    seen[context] = n.node_id
            rewritten.append(ProgramNode(n.node_id, n.kind, n.action, n.dependencies, n.capability, n.latency_ms, n.cost_usd, context, n.deterministic))
        items = rewritten

        # Reasoning fusion: adjacent inference nodes with no tool/memory/verify
        # boundary become one executable inference block. Disable it when the
        # caller needs a directly executable ECU made from registered handlers.
        fused_groups: list[tuple[str, ...]] = []
        fused_ids: set[str] = set()
        new_items: list[ProgramNode] = []
        if not enable_fusion:
            new_items = list(items)
        else:
            for n in items:
                if n.node_id in fused_ids:
                    continue
                group = [n]
                frontier = n
                while True:
                    group_ids = {g.node_id for g in group}
                    nxt = next((x for x in items if x.node_id not in fused_ids and x.node_id not in group_ids and x.kind == "inference" and tuple(x.dependencies) == (frontier.node_id,)), None)
                    if nxt is None:
                        break
                    group.append(nxt)
                    frontier = nxt
                if len(group) > 1:
                    fused_groups.append(tuple(g.node_id for g in group))
                    fused_ids.update(g.node_id for g in group[1:])
                    deps = group[0].dependencies
                    names = "+".join(g.action.name if g.action else g.kind for g in group)
                    args = {"fused": [g.node_id for g in group]}
                    new_items.append(ProgramNode(
                        node_id=group[0].node_id,
                        kind="inference_fused",
                        action=ECUAction(names, args=args),
                        dependencies=deps,
                        capability="frontier" if any(g.capability == "frontier" for g in group) else group[0].capability,
                        latency_ms=sum(g.latency_ms for g in group) * 0.7,
                        cost_usd=sum(g.cost_usd for g in group) * 0.65,
                        context="\n---\n".join(g.context for g in group if g.context),
                        deterministic=all(g.deterministic for g in group),
                    ))
                else:
                    new_items.append(n)
        items = new_items

        # Rewire dependencies when a fused node collapsed a chain.
        replacement: dict[str, str] = {}
        for group in fused_groups:
            for old in group[1:]:
                replacement[old] = group[0]
        normalized: list[ProgramNode] = []
        for n in items:
            deps = tuple(dict.fromkeys(replacement.get(d, d) for d in n.dependencies if replacement.get(d, d) != n.node_id))
            normalized.append(ProgramNode(n.node_id, n.kind, n.action, deps, n.capability, n.latency_ms, n.cost_usd, n.context, n.deterministic))
        items = normalized

        # Capability scheduling: expensive frontier nodes remain ordered behind
        # cheaper local work when there is no dependency forcing otherwise.
        rank = {"cpu": 0, "memory": 1, "remote-cpu": 2, "npu": 3, "gpu": 4, "frontier": 5}
        items.sort(key=lambda n: (rank.get(n.capability, 9), n.cost_usd, n.node_id))
        waves = DataflowPlanner([DataflowNode(n.node_id, n.action or ECUAction(n.kind), n.dependencies, (), n.latency_ms) for n in items]).waves() if items and all(n.action for n in items) else []
        payload = [self._stable_id(n) for n in items]
        digest = sha256("|".join(payload).encode()).hexdigest()
        return CompiledProgram(tuple(items), tuple(waves), tuple(removed), tuple(fused_groups), dedup, digest)

    def execute(self, program: CompiledProgram, env: ECUEnvironment, *, handlers: Mapping[str, Any] | None = None) -> DataflowResult:
        nodes = [DataflowNode(n.node_id, n.action or ECUAction(n.kind), n.dependencies, (), n.latency_ms) for n in program.nodes]
        return DataflowPlanner(nodes).execute(env, handlers)
