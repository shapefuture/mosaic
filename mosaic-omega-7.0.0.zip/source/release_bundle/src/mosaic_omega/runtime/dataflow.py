from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Callable, Iterable, Mapping, Sequence

from ..ecu.core import ECUAction, ECUEnvironment, ExecutionResult, ExecutableComputeUnit


@dataclass(frozen=True)
class DataflowNode:
    node_id: str
    action: ECUAction
    requires: tuple[str, ...] = ()
    produces: tuple[str, ...] = ()
    estimated_latency_ms: float = 0.0


@dataclass(frozen=True)
class DataflowResult:
    success: bool
    order: tuple[str, ...]
    parallel_waves: tuple[tuple[str, ...], ...]
    results: Mapping[str, ExecutionResult]
    critical_path_ms: float


class DataflowPlanner:
    """Compile an agent action graph into dependency-aware execution waves.

    Independent tool/compute operations can run concurrently; dependent nodes
    remain ordered. This is the agent-program analogue of instruction-level
    scheduling and directly targets reasoning/tool round-trip latency.
    """
    def __init__(self, nodes: Sequence[DataflowNode]):
        self.nodes = {n.node_id: n for n in nodes}
        for node in nodes:
            missing = [r for r in node.requires if r not in self.nodes]
            if missing:
                raise ValueError(f"node {node.node_id} has missing dependencies: {missing}")

    def waves(self) -> list[tuple[str, ...]]:
        remaining = set(self.nodes)
        done: set[str] = set()
        waves: list[tuple[str, ...]] = []
        while remaining:
            ready = sorted(n for n in remaining if set(self.nodes[n].requires) <= done)
            if not ready:
                raise ValueError("dataflow graph contains a cycle")
            waves.append(tuple(ready))
            done.update(ready)
            remaining.difference_update(ready)
        return waves

    def execute(self, env: ECUEnvironment, handlers: Mapping[str, Callable] | None = None, *, max_workers: int = 8) -> DataflowResult:
        if handlers:
            env.handlers.update(handlers)
        waves = self.waves()
        results: dict[str, ExecutionResult] = {}
        order: list[str] = []
        critical_path = 0.0
        # Each concurrent node works on a clone then commits only successful state deltas.
        # Conflicting writes should therefore be modeled as dependencies by the caller.
        for wave in waves:
            wave_results: dict[str, ExecutionResult] = {}
            with ThreadPoolExecutor(max_workers=min(max_workers, len(wave) or 1)) as pool:
                futs = {}
                parent_state = dict(env.state)
                for nid in wave:
                    node = self.nodes[nid]
                    child = env.clone()
                    futs[pool.submit(_run_action, child, node.action)] = (nid, child, node, parent_state)
                wave_deltas: dict[str, dict] = {}
                for fut in as_completed(futs):
                    nid, child, node, parent_state = futs[fut]
                    try:
                        res = fut.result()
                    except Exception as exc:
                        res = ExecutionResult(False, dict(child.state), (), 1, f"{type(exc).__name__}: {exc}")
                    wave_results[nid] = res
                    wave_deltas[nid] = {k: v for k, v in res.state.items() if parent_state.get(k, object()) != v or k not in parent_state}
            # Detect conflicting concurrent writes. Identical writes are safe.
            owners: dict[str, object] = {}
            for nid in wave:
                res = wave_results[nid]
                if not res.success:
                    results[nid] = res
                    order.append(nid)
                    return DataflowResult(False, tuple(order), tuple(waves), results, critical_path)
                for key, value in wave_deltas[nid].items():
                    if key in owners and owners[key] != value:
                        raise ValueError(f"conflicting concurrent write to {key!r}; add an explicit dependency")
                    owners[key] = value
            for nid in wave:
                res = wave_results[nid]
                results[nid] = res
                order.append(nid)
                env.state.update(wave_deltas[nid])
            critical_path += max(self.nodes[n].estimated_latency_ms for n in wave) if wave else 0.0
        return DataflowResult(True, tuple(order), tuple(waves), results, critical_path)


def _run_action(env: ECUEnvironment, action: ECUAction) -> ExecutionResult:
    try:
        out = env.dispatch(action)
        return ExecutionResult(True, dict(env.state), (out,), 1)
    except Exception as exc:
        return ExecutionResult(False, dict(env.state), (), 0, f"{type(exc).__name__}: {exc}")


def planner_from_unit(unit: ExecutableComputeUnit, dependencies: Mapping[int, Sequence[int]] | None = None) -> DataflowPlanner:
    dependencies = dependencies or {}
    nodes = []
    for i, action in enumerate(unit.actions):
        reqs = tuple(str(j) for j in dependencies.get(i, (i - 1 if i else -1,)) if j >= 0)
        nodes.append(DataflowNode(str(i), action, reqs, (), float(unit.provenance.get("mean_latency_ms", 0.0))))
    return DataflowPlanner(nodes)
