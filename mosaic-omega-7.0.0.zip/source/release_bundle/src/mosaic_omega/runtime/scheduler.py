from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .cost import CostPoint, UtilityWeights, score_latency_cost_energy


@dataclass(frozen=True)
class BackendOffer:
    name: str
    device_class: str
    available: bool
    estimated_latency_ms: float
    startup_ms: float
    cost: CostPoint
    correctness_confidence: float = 1.0
    memory_ok: bool = True
    expected_quality: float = 1.0
    throughput_work_units: float = 1.0
    fixed_overhead_ms: float = 0.0
    gpu_required: bool = False

    @property
    def effective_latency_ms(self) -> float:
        return max(0.0, self.estimated_latency_ms + self.fixed_overhead_ms)

    @property
    def estimated_cost_usd(self) -> float:
        return self.cost.usd_for_ms(self.effective_latency_ms)

    @property
    def estimated_energy_j(self) -> float:
        return self.cost.energy_for_ms(self.effective_latency_ms)

    @property
    def quality_per_cost_latency(self) -> float:
        q = max(0.0, min(1.0, self.expected_quality))
        seconds = max(self.effective_latency_ms / 1000.0, 1e-12)
        return q * max(self.throughput_work_units, 1e-12) / (
            max(self.estimated_cost_usd, 1e-30) * seconds
        )


class LastResortGPUScheduler:
    """Economic scheduler with a hard GPU-last-resort policy."""

    def __init__(
        self,
        weights: UtilityWeights | None = None,
        gpu_required_margin: float = 0.35,
        min_gpu_quality_gain: float = 0.02,
    ):
        self.weights = weights or UtilityWeights()
        self.gpu_required_margin = float(gpu_required_margin)
        self.min_gpu_quality_gain = float(min_gpu_quality_gain)

    def _score(self, offer: BackendOffer) -> float:
        base = score_latency_cost_energy(
            offer.effective_latency_ms,
            offer.estimated_cost_usd,
            offer.estimated_energy_j,
            offer.startup_ms,
            offer.device_class,
            self.weights,
        )
        return base / max(offer.expected_quality * max(offer.throughput_work_units, 1e-12), 1e-12)

    def rank(
        self,
        offers: Iterable[BackendOffer],
        max_latency_ms: float = float("inf"),
        max_cost_usd: float = float("inf"),
    ) -> list[BackendOffer]:
        viable = [
            o
            for o in offers
            if o.available
            and o.memory_ok
            and o.correctness_confidence >= 0.999
            and o.expected_quality >= 0.999
            and o.effective_latency_ms <= max_latency_ms
            and o.estimated_cost_usd <= max_cost_usd
        ]
        if not viable:
            return []

        non_gpu = [o for o in viable if o.device_class != "gpu"]
        gpu = [o for o in viable if o.device_class == "gpu"]
        ranked_non_gpu = sorted(non_gpu, key=self._score)
        if not ranked_non_gpu:
            return sorted(gpu, key=self._score)

        best_cpu = ranked_non_gpu[0]
        best_cpu_score = self._score(best_cpu)
        ranked_gpu = sorted(gpu, key=self._score)
        if ranked_gpu:
            g = ranked_gpu[0]
            gpu_score = self._score(g)
            strong_quality_delta = g.expected_quality >= best_cpu.expected_quality + self.min_gpu_quality_gain
            strong_score_gain = gpu_score < best_cpu_score * (1.0 - self.gpu_required_margin)
            hard_acceleration_requirement = g.gpu_required and not any(o.device_class == "cpu" for o in viable)
            if (strong_quality_delta and strong_score_gain) or hard_acceleration_requirement:
                return [g, *ranked_non_gpu, *ranked_gpu[1:]]
        return [*ranked_non_gpu, *ranked_gpu]

    def choose(
        self,
        offers: Iterable[BackendOffer],
        max_latency_ms: float = float("inf"),
        max_cost_usd: float = float("inf"),
    ) -> BackendOffer:
        ranked = self.rank(offers, max_latency_ms, max_cost_usd)
        if not ranked:
            raise RuntimeError("no backend satisfies hard resource constraints")
        return ranked[0]
