from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from ..trajectory.events import Trajectory
from ..learning.motifs import mine_motifs, compile_motifs_to_ecus

@dataclass(frozen=True)
class DistillationReport:
    trajectories_seen: int
    successful: int
    failed: int
    candidate_units: int
    common_actions: int
    provenance_digests: tuple[str, ...]


def _success(traj: Trajectory) -> bool:
    if any(e.ok is False for e in traj.events):
        return False
    if any(e.metadata.get("verify_status") == "unresolved" for e in traj.events):
        return False
    if any(e.metadata.get("judge_verdict") in {"reject", "fail", "failure"} for e in traj.events):
        return False
    return any(
        e.ok is True or e.metadata.get("verify_status") == "resolved" or e.metadata.get("judge_verdict") == "accept"
        for e in traj.events
    )


def distill_ecus(trajectories: Iterable[Trajectory], *, min_support: int = 2, max_actions: int = 8, source_manifest: str = ""):
    tr = list(trajectories)
    success = [t for t in tr if _success(t)]
    failed = [t for t in tr if not _success(t)]
    motifs = mine_motifs(success, min_support=min_support, max_len=max_actions)
    units = compile_motifs_to_ecus(motifs, source_manifest)
    return units, DistillationReport(
        trajectories_seen=len(tr),
        successful=len(success),
        failed=len(failed),
        candidate_units=len(units),
        common_actions=len(motifs),
        provenance_digests=(source_manifest,),
    )
