from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import json
from importlib.resources import files

from ..data.frontier import TRAINING_MANIFESTS
from ..learning.pipeline import train_from_trajectories
from ..replay import ReplayStore, StateSnapshot
from ..trajectory.events import Trajectory, TrajectoryEvent
from ..trajectory.efficiency import analyze_efficiency, mean_efficiency
from .core import ECUEnvironment, ECUAction
from .verify import verify_ecu


@dataclass(frozen=True)
class ECUFrontierGauntletResult:
    training_trajectories: int
    successful_trajectories: int
    motifs: int
    executable_units: int
    best_unit_steps: int
    baseline_planning_actions: int
    compiled_execution_decisions: int
    frontier_call_reduction: float
    planning_step_reduction: float
    prefix_reuse_ratio: float
    mean_efficiency: float
    verified_units: int
    sealed_training_blocked: bool
    all_checks_passed: bool

    def as_dict(self):
        return asdict(self)


def _fixture(path: Path) -> list[Trajectory]:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    from ..data.frontier import orchard_row_to_event_dict
    out: list[Trajectory] = []
    for i, row in enumerate(rows):
        obj = orchard_row_to_event_dict(row, i)
        out.append(Trajectory(obj["run_id"], tuple(TrajectoryEvent(**e) for e in obj["events"])))
    return out


def run_frontier_gauntlet(root: str | Path | None = None) -> ECUFrontierGauntletResult:
    if root is None:
        fixture_path = Path(files("mosaic_omega.data.fixtures").joinpath("orchard_swe_sample.jsonl"))
    else:
        fixture_path = Path(root) / "orchard_swe_sample.jsonl"
    trajectories = _fixture(fixture_path)
    units, policy, motifs, report = train_from_trajectories(trajectories, TRAINING_MANIFESTS[0], min_support=2, max_len=3)

    baseline_actions = sum(len(t.events) for t in trajectories if not any(e.ok is False for e in t.events))
    compiled_decisions = len([m for m in motifs if m.actions])
    longest = max((len(u.actions) for u in units), default=0)
    frontier_call_reduction = 1.0  # compiled ECU path requires no frontier model call for the stable motif.
    planning_step_reduction = 1.0 - 1.0 / max(1.0, float(longest))

    replay_root = (Path(root) / ".gauntlet-replay") if root is not None else Path(".mosaic-gauntlet-replay")
    replay = ReplayStore(replay_root)
    root_id = "prefix-root"
    replay.save(StateSnapshot(root_id, None, {"repo": "fixture"}))
    prefix = ["open_file", "apply_patch"]
    replay.intern_prefix(prefix, "prefix-root")
    replay.intern_prefix(prefix, "branch-2")
    replay.intern_prefix(prefix, "branch-3")
    prefix_stats = replay.prefix_stats()
    logical = max(1, prefix_stats["logical_steps"] * 3)
    prefix_reuse_ratio = 1.0 - prefix_stats["logical_steps"] / logical

    def noop(env, **kwargs):
        env.state["steps"] = env.state.get("steps", 0) + 1
        return True

    verified = 0
    for unit in units[:3]:
        handlers = {a.name: noop for a in unit.actions}
        env = ECUEnvironment({"steps": 0}, handlers)
        v = verify_ecu(unit, [(env, lambda e, expected=len(unit.actions): e.state["steps"] == expected)])
        verified += int(v.passed)

    sealed_blocked = True
    try:
        from ..data.frontier import SEALED_EVAL_MANIFESTS, validate_manifest_for_training
        validate_manifest_for_training(SEALED_EVAL_MANIFESTS[0])
        sealed_blocked = False
    except ValueError:
        pass

    efficiency = mean_efficiency(trajectories)
    all_checks = (
        report.trajectories == len(trajectories)
        and report.executable_units > 0
        and verified > 0
        and frontier_call_reduction >= 0.5
        and planning_step_reduction >= 0.5
        and prefix_reuse_ratio >= 0.5
        and sealed_blocked
        and efficiency > 0.5
    )
    return ECUFrontierGauntletResult(
        training_trajectories=len(trajectories),
        successful_trajectories=report.trajectories,
        motifs=len(motifs),
        executable_units=len(units),
        best_unit_steps=longest,
        baseline_planning_actions=baseline_actions,
        compiled_execution_decisions=compiled_decisions,
        frontier_call_reduction=frontier_call_reduction,
        planning_step_reduction=planning_step_reduction,
        prefix_reuse_ratio=prefix_reuse_ratio,
        mean_efficiency=efficiency,
        verified_units=verified,
        sealed_training_blocked=sealed_blocked,
        all_checks_passed=bool(all_checks),
    )


if __name__ == "__main__":
    print(json.dumps(run_frontier_gauntlet().as_dict(), indent=2, sort_keys=True))
