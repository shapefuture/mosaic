from __future__ import annotations

from dataclasses import dataclass
from typing import Callable
from .core import ECUEnvironment, ExecutableComputeUnit

@dataclass(frozen=True)
class ECUVerification:
    passed: bool
    cases: int
    failures: tuple[str, ...]


def verify_ecu(ecu: ExecutableComputeUnit, cases: list[tuple[ECUEnvironment, Callable[[ECUEnvironment], bool]]]) -> ECUVerification:
    failures: list[str] = []
    for i, (env, oracle) in enumerate(cases):
        before = env.clone()
        result = ecu.run(env)
        if not result.success:
            failures.append(f"case {i}: {result.error}")
            continue
        try:
            ok = bool(oracle(env))
        except Exception as exc:
            failures.append(f"case {i}: oracle {type(exc).__name__}: {exc}")
            continue
        if not ok:
            failures.append(f"case {i}: oracle rejected result; before={before.state} after={env.state}")
    return ECUVerification(not failures, len(cases), tuple(failures))
