from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
import json
from typing import Any

from ..data.frontier import manifest_report, validate_manifest_for_training
from ..trajectory.events import Trajectory, TrajectoryEvent
from .core import ECUAction, ECUContract, ECUEnvironment, ExecutableComputeUnit
from .induce import distill_ecus
from .verify import verify_ecu

@dataclass(frozen=True)
class ECUGauntletResult:
    trajectories: int
    successful_trajectories: int
    units: int
    best_unit_steps: int
    mean_trajectory_steps: float
    procedural_compression: float
    reuse_amortization: float
    verified_cases: int
    sealed_training_blocked: bool
    all_checks_passed: bool

    def as_dict(self):
        return asdict(self)


def _traj(run_id: str, actions: list[str], *, resolved: bool = True, teacher: str = "orchard") -> Trajectory:
    meta = {"verify_status": "resolved"} if teacher == "orchard" and resolved else {"judge_verdict": "accept"} if resolved else {"verify_status": "unresolved"}
    return Trajectory(run_id, tuple(TrajectoryEvent(i, "tool_call", action, ok=None, metadata=meta) for i, action in enumerate(actions)))


def run_ecu_gauntlet() -> ECUGauntletResult:
    trajectories = [
        _traj("orchard-1", ["open_file", "apply_patch", "run_tests"]),
        _traj("orchard-2", ["open_file", "apply_patch", "run_tests"]),
        _traj("orchard-3", ["open_file", "apply_patch", "run_tests"]),
        _traj("gpt56-1", ["exec", "exec"], teacher="gpt56"),
        _traj("gpt56-2", ["exec", "exec"], teacher="gpt56"),
        _traj("negative", ["open_file", "apply_patch"], resolved=False),
    ]
    units, report = distill_ecus(trajectories, min_support=2, max_actions=3, source_manifest="ecu-gauntlet")
    env = ECUEnvironment(state={}, handlers={
        "open_file": lambda e, **kw: e.state.__setitem__("opened", kw.get("path")),
        "apply_patch": lambda e, **kw: e.state.__setitem__("patched", True),
        "run_tests": lambda e, **kw: e.state.__setitem__("tests", kw.get("suite", "unit")),
        "exec": lambda e, **kw: e.state.__setitem__("exec_count", e.state.get("exec_count", 0) + 1),
    })
    compatible = next((u for u in units if [a.name for a in u.actions] == ["open_file", "apply_patch", "run_tests"]), None)
    if compatible is None:
        return ECUGauntletResult(len(trajectories), report.successful, len(units), 0, 0.0, 0.0, 0.0, 0, True, False)
    verification = verify_ecu(compatible, [(env, lambda e: e.state.get("patched") is True and e.state.get("tests") == "unit")])
    mean_steps = sum(len(t.events) for t in trajectories if t.run_id != "negative") / 5.0
    compression = max(0.0, 1.0 - (len(compatible.actions) / max(mean_steps, 1.0)))
    reuse_amortization = 1.0 - (1.0 / 3.0)  # three near-identical successful trajectories collapse to one reusable ECU
    sealed_blocked = False
    for manifest in manifest_report()["sealed_eval"]:
        try:
            validate_manifest_for_training(type("M", (), manifest)())
        except ValueError:
            sealed_blocked = True
    ok = (
        report.successful == 5 and len(units) >= 2 and compatible is not None
        and verification.passed and reuse_amortization >= 0.5 and sealed_blocked
    )
    return ECUGauntletResult(len(trajectories), report.successful, len(units), len(compatible.actions), mean_steps, compression, reuse_amortization, verification.cases if verification.passed else 0, sealed_blocked, ok)


def write_report(path: str | Path) -> ECUGauntletResult:
    result = run_ecu_gauntlet()
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(result.as_dict(), indent=2, sort_keys=True), encoding="utf-8")
    return result
