from __future__ import annotations

from dataclasses import dataclass, field, asdict
from hashlib import sha256
import json
import re
from typing import Any, Callable, Mapping, MutableMapping, Sequence

@dataclass(frozen=True)
class ECUAction:
    name: str
    args: Mapping[str, Any] = field(default_factory=dict)
    expected_state: Mapping[str, Any] = field(default_factory=dict)

@dataclass(frozen=True)
class ECUContract:
    name: str
    preconditions: tuple[str, ...] = ()
    postconditions: tuple[str, ...] = ()
    max_steps: int = 32
    tags: tuple[str, ...] = ()

@dataclass(frozen=True)
class ExecutionResult:
    success: bool
    state: Mapping[str, Any]
    outputs: tuple[Any, ...]
    steps: int
    error: str = ""

class ECUEnvironment:
    """Small deterministic execution environment; handlers are explicitly injected."""
    def __init__(self, state: Mapping[str, Any] | None = None, handlers: Mapping[str, Callable[..., Any]] | None = None, params: Mapping[str, Any] | None = None):
        self.state: MutableMapping[str, Any] = dict(state or {})
        self.handlers = dict(handlers or {})
        self.params: MutableMapping[str, Any] = dict(params or {})

    def clone(self) -> "ECUEnvironment":
        return ECUEnvironment(dict(self.state), self.handlers, dict(self.params))

    def dispatch(self, action: ECUAction) -> Any:
        fn = self.handlers.get(action.name)
        if fn is None:
            raise KeyError(f"no handler registered for action {action.name!r}")
        return fn(self, **self._resolve(action.args))

    def _resolve(self, value: Any) -> Any:
        if isinstance(value, str):
            if value.startswith("$param."):
                key = value[7:]
                if key not in self.params:
                    raise KeyError(f"missing ECU parameter {key!r}")
                return self.params[key]
            if value.startswith("$state."):
                key = value[7:]
                if key not in self.state:
                    raise KeyError(f"missing ECU state value {key!r}")
                return self.state[key]
            return value
        if isinstance(value, Mapping):
            return {k: self._resolve(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            typ = type(value)
            return typ(self._resolve(v) for v in value)
        return value

class ExecutableComputeUnit:
    def __init__(self, contract: ECUContract, actions: Sequence[ECUAction], provenance: Mapping[str, Any] | None = None):
        if not actions:
            raise ValueError("ECU must contain at least one action")
        if len(actions) > contract.max_steps:
            raise ValueError("ECU exceeds contract max_steps")
        self.contract = contract
        self.actions = tuple(actions)
        self.provenance = dict(provenance or {})

    @property
    def digest(self) -> str:
        payload = json.dumps({"contract": asdict(self.contract), "actions":[asdict(a) for a in self.actions], "provenance":self.provenance}, sort_keys=True, separators=(",", ":"))
        return sha256(payload.encode()).hexdigest()

    def _check_expr(self, expr: str, state: Mapping[str, Any]) -> bool:
        # Deliberately restricted predicate language: key=value, key!=value, key exists.
        m = re.fullmatch(r"([A-Za-z_][A-Za-z0-9_.-]*)\s*(==|!=|exists)\s*(.*)?", expr.strip())
        if not m:
            raise ValueError(f"unsupported ECU predicate: {expr!r}")
        key, op, raw = m.groups()
        current = state.get(key)
        if op == "exists":
            return key in state
        try:
            rhs: Any = json.loads(raw) if raw is not None and raw != "" else raw
        except json.JSONDecodeError:
            rhs = raw.strip('"\'') if raw is not None else None
        return current == rhs if op == "==" else current != rhs

    def run(self, env: ECUEnvironment) -> ExecutionResult:
        for p in self.contract.preconditions:
            if not self._check_expr(p, env.state):
                return ExecutionResult(False, dict(env.state), (), 0, f"precondition failed: {p}")
        outputs: list[Any] = []
        for i, action in enumerate(self.actions):
            try:
                out = env.dispatch(action)
                outputs.append(out)
            except Exception as exc:
                return ExecutionResult(False, dict(env.state), tuple(outputs), i, f"{type(exc).__name__}: {exc}")
            for key, value in action.expected_state.items():
                if env.state.get(key) != value:
                    return ExecutionResult(False, dict(env.state), tuple(outputs), i + 1, f"expected state mismatch: {key}")
        for p in self.contract.postconditions:
            if not self._check_expr(p, env.state):
                return ExecutionResult(False, dict(env.state), tuple(outputs), len(self.actions), f"postcondition failed: {p}")
        return ExecutionResult(True, dict(env.state), tuple(outputs), len(self.actions))

    def to_dict(self) -> dict[str, Any]:
        return {"contract": asdict(self.contract), "actions":[asdict(a) for a in self.actions], "provenance":self.provenance, "digest":self.digest}

    @classmethod
    def from_dict(cls, obj: Mapping[str, Any]) -> "ExecutableComputeUnit":
        contract = ECUContract(**dict(obj["contract"]))
        actions = [ECUAction(name=a["name"], args=a.get("args", {}), expected_state=a.get("expected_state", {})) for a in obj["actions"]]
        ecu = cls(contract, actions, obj.get("provenance", {}))
        if "digest" in obj and obj["digest"] != ecu.digest:
            raise ValueError("ECU digest mismatch")
        return ecu
