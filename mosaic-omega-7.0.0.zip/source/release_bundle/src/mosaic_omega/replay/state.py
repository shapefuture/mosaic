from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
from typing import Any, Mapping, Sequence


@dataclass(frozen=True)
class StateSnapshot:
    snapshot_id: str
    parent_id: str | None
    state: Mapping[str, Any]

    @property
    def digest(self) -> str:
        return sha256(json.dumps(self.state, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


class ReplayStore:
    """Deterministic checkpoint/fork store with prefix deduplication metadata."""
    def __init__(self, root: str | Path | None = None):
        self.root = Path(root or ".mosaic-replay")
        self.root.mkdir(parents=True, exist_ok=True)
        self._prefix: dict[tuple[str, ...], str] = {}

    def save(self, snapshot: StateSnapshot) -> str:
        payload = {"snapshot_id": snapshot.snapshot_id, "parent_id": snapshot.parent_id, "state": snapshot.state}
        (self.root / f"{snapshot.snapshot_id}.json").write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")))
        return snapshot.snapshot_id

    def load(self, snapshot_id: str) -> StateSnapshot:
        payload = json.loads((self.root / f"{snapshot_id}.json").read_text())
        return StateSnapshot(payload["snapshot_id"], payload.get("parent_id"), payload["state"])

    def fork(self, snapshot_id: str, new_id: str, updates: Mapping[str, Any]) -> StateSnapshot:
        parent = self.load(snapshot_id)
        state = dict(parent.state)
        state.update(updates)
        child = StateSnapshot(new_id, parent.snapshot_id, state)
        self.save(child)
        return child

    def intern_prefix(self, sequence: Sequence[str], snapshot_id: str) -> str:
        key = tuple(sequence)
        existing = self._prefix.get(key)
        if existing is not None:
            return existing
        self._prefix[key] = snapshot_id
        return snapshot_id

    def prefix_stats(self) -> dict[str, int]:
        prefixes = len(self._prefix)
        nodes = sum(len(k) for k in self._prefix)
        unique = len({x for k in self._prefix for x in k})
        return {"prefixes": prefixes, "logical_steps": nodes, "unique_steps": unique}
