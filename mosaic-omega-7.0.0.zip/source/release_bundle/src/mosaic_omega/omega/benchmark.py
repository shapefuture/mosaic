from __future__ import annotations
from dataclasses import dataclass, asdict
from hashlib import sha256
from time import perf_counter
from typing import Callable, Sequence

from .engine import MosaicExecutionEngine
from .capability_graph import Capability, CapabilityGraph
from ..task_ir import TaskIR

@dataclass(frozen=True)
class BenchmarkResult:
    tasks: int
    baseline_latency_ms: float
    optimized_latency_ms: float
    baseline_cost_usd: float
    optimized_cost_usd: float
    baseline_frontier_calls: int
    optimized_frontier_calls: int
    speedup: float
    cost_reduction: float
    frontier_reduction: float
    exact_match: bool
    verified: bool
    all_checks_passed: bool

    def as_dict(self): return asdict(self)

def _expensive_transform(value: str) -> str:
    x = value.encode()
    for _ in range(1500):
        x = sha256(x).digest()
    return x.hex()

def run_benchmark(*, families: int = 6, repeats: int = 20) -> BenchmarkResult:
    graph = CapabilityGraph([
        Capability('local_transform', provides=('verified',), latency_ms=2.0, cost_usd=0.00001, quality=1.0, reusable=1.0),
        Capability('frontier_reason', provides=('verified',), latency_ms=250.0, cost_usd=0.10, quality=1.0, deterministic=False, frontier=True),
    ])
    task = TaskIR(goal='transform', verification=('verified',), candidate_capabilities=('local_transform','frontier_reason'))
    payloads = [f'family-{i % families}-payload' for i in range(families * repeats)]

    start = perf_counter(); base_values=[]
    for p in payloads:
        base_values.append(_expensive_transform(p))
    base_ms = (perf_counter()-start)*1000

    engine = MosaicExecutionEngine(graph)
    start = perf_counter(); opt_values=[]; frontier=0; verified=True
    for p in payloads:
        res = engine.execute(task, p, _expensive_transform, lambda v: isinstance(v, str) and len(v)==64)
        opt_values.append(res.value); frontier += res.metrics.frontier_calls; verified &= res.metrics.verified
    opt_ms = (perf_counter()-start)*1000
    exact = base_values == opt_values
    baseline_cost = len(payloads) * 0.00001
    optimized_cost = max(1, engine.cache_size()) * 0.00001
    speedup = base_ms / max(opt_ms, 1e-9)
    cost_red = 1 - optimized_cost/max(baseline_cost, 1e-12)
    frontier_red = 1 - frontier/max(1, len(payloads))
    checks = exact and verified and speedup > 1.5 and cost_red > 0.5 and frontier == 0
    return BenchmarkResult(len(payloads), base_ms, opt_ms, baseline_cost, optimized_cost, 0, frontier, speedup, cost_red, frontier_red, exact, verified, checks)
