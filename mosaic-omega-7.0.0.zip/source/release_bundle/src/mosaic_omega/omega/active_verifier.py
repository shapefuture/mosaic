from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Sequence, Any

@dataclass(frozen=True)
class VerificationOutcome:
    accepted: bool
    stages: tuple[str, ...]
    cost_usd: float
    quality: float
    counterexample: Any = None

class ActiveVerifier:
    """Cheap-first verifier with escalation and counterexample production."""
    def __init__(self, stages: Sequence[tuple[str, Callable[[Any], tuple[bool,float,Any]], float]]):
        self.stages = tuple(stages)

    def verify(self, candidate: Any, *, target_quality: float = .99) -> VerificationOutcome:
        spent=0.0; used=[]; best_quality=0.0; counterexample=None
        for name, fn, cost in self.stages:
            used.append(name); spent += cost
            ok, quality, detail = fn(candidate)
            best_quality = max(best_quality, quality)
            if detail is not None: counterexample=detail
            if not ok:
                return VerificationOutcome(False, tuple(used), spent, quality, detail)
            if quality >= target_quality:
                return VerificationOutcome(True, tuple(used), spent, quality, None)
        return VerificationOutcome(best_quality >= target_quality, tuple(used), spent, best_quality, counterexample)
