from __future__ import annotations
from dataclasses import dataclass, field
from hashlib import sha256
import json
from typing import Iterable

@dataclass(frozen=True)
class Capability:
    name: str
    requires: tuple[str, ...] = ()
    provides: tuple[str, ...] = ()
    conflicts: tuple[str, ...] = ()
    latency_ms: float = 0.0
    cost_usd: float = 0.0
    quality: float = 1.0
    deterministic: bool = True
    frontier: bool = False
    reusable: float = 0.0
    implementation: str = "local"
    metadata: dict = field(default_factory=dict)

    @property
    def digest(self) -> str:
        payload = json.dumps({
            'name': self.name, 'requires': self.requires, 'provides': self.provides,
            'conflicts': self.conflicts, 'latency_ms': self.latency_ms,
            'cost_usd': self.cost_usd, 'quality': self.quality,
            'deterministic': self.deterministic, 'frontier': self.frontier,
            'reusable': self.reusable, 'implementation': self.implementation,
            'metadata': self.metadata,
        }, sort_keys=True, separators=(',', ':'))
        return sha256(payload.encode()).hexdigest()

class CapabilityGraph:
    def __init__(self, capabilities: Iterable[Capability] = ()):
        self._caps = {c.name: c for c in capabilities}

    def add(self, capability: Capability) -> None:
        self._caps[capability.name] = capability

    def get(self, name: str) -> Capability:
        return self._caps[name]

    def values(self) -> tuple[Capability, ...]:
        return tuple(self._caps.values())

    def can_use(self, chosen: list[Capability], candidate: Capability) -> bool:
        names = {c.name for c in chosen}
        if candidate.name in names:
            return False
        if any(x in names for x in candidate.conflicts):
            return False
        for c in chosen:
            if candidate.name in c.conflicts:
                return False
        provided = {p for c in chosen for p in c.provides}
        return all(r in provided or not r for r in candidate.requires)

    def greedy_plan(self, goals: set[str], *, allow_frontier: bool = True) -> list[Capability]:
        # Backward-chaining goal planner with cost-aware forward ordering.
        selected: list[Capability] = []
        provided: set[str] = set()
        pending = list(dict.fromkeys(goals))
        visited: set[str] = set()
        while pending:
            goal = pending.pop(0)
            if goal in provided or goal in visited:
                continue
            visited.add(goal)
            providers = [c for c in self._caps.values() if goal in c.provides and (allow_frontier or not c.frontier)]
            if not providers:
                continue
            ranked = sorted(providers, key=lambda c: (
                c.quality * (1.0 + c.reusable) / max(1e-9, c.latency_ms * max(c.cost_usd, 1e-6)),
                -int(c.frontier), c.name), reverse=True)
            best = next((c for c in ranked if c.name not in {x.name for x in selected} and not any(x in {y.name for y in selected} for x in c.conflicts)), None)
            if best is None:
                continue
            # Resolve prerequisites before adding the capability.
            missing = [r for r in best.requires if r not in provided]
            pending[0:0] = missing
            selected.append(best)
            # Capability is only considered provided after its prerequisites are scheduled;
            # the final planner reorders by dependency graph below.
            provided.update(best.provides)
        # Stable topological ordering by prerequisite availability.
        ordered=[]; remaining=list(dict.fromkeys(c.name for c in selected)); provided=set()
        while remaining:
            ready=[self._caps[n] for n in remaining if all(r in provided or not r for r in self._caps[n].requires)]
            if not ready:
                break
            ready.sort(key=lambda c:(int(c.frontier), c.cost_usd, c.latency_ms, c.name))
            for c in ready:
                ordered.append(c); provided.update(c.provides); remaining.remove(c.name)
        return ordered
