from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from time import perf_counter
from typing import Callable, Any, Mapping

from .capability_graph import CapabilityGraph
from .task_compiler import TaskCompiler, ExecutionPlan
from .portfolio import PlanPortfolio
from ..task_ir import TaskIR

@dataclass(frozen=True)
class ExecutionMetrics:
    success: bool
    latency_ms: float
    cost_usd: float
    frontier_calls: int
    cache_hit: bool
    verified: bool

@dataclass(frozen=True)
class EngineResult:
    value: Any
    metrics: ExecutionMetrics
    plan: ExecutionPlan

class MosaicExecutionEngine:
    """Economic execution engine with exact cache, plan compilation and verification.

    The engine treats model calls as an exception path. Deterministic handlers are
    preferred, then cached results, then local/remote computation, with frontier
    inference available only as a final explicit handler.
    """
    def __init__(self, graph: CapabilityGraph, *, unit_cost_usd: float = 0.000001):
        self.graph = graph
        self.compiler = TaskCompiler(graph)
        self.portfolio = PlanPortfolio()
        self.unit_cost_usd = unit_cost_usd
        self._cache: dict[str, Any] = {}

    @staticmethod
    def key(task: TaskIR, payload: Any) -> str:
        return sha256((task.digest + '|' + repr(payload)).encode()).hexdigest()

    def execute(self, task: TaskIR, payload: Any, compute: Callable[[Any], Any], verify: Callable[[Any], bool]) -> EngineResult:
        key = self.key(task, payload)
        start = perf_counter()
        if key in self._cache:
            value = self._cache[key]
            ok = bool(verify(value))
            elapsed = (perf_counter() - start) * 1000
            return EngineResult(value, ExecutionMetrics(ok, elapsed, self.unit_cost_usd, 0, True, ok), self.compiler.compile(task))
        plans = self.compiler.compile_alternatives(task)
        plan = plans[0]
        value = compute(payload)
        ok = bool(verify(value))
        if ok:
            self._cache[key] = value
        elapsed = (perf_counter() - start) * 1000
        frontier_calls = plan.frontier_steps
        return EngineResult(value, ExecutionMetrics(ok, elapsed, max(self.unit_cost_usd, plan.cost_usd), frontier_calls, False, ok), plan)

    def cache_size(self) -> int:
        return len(self._cache)
