from __future__ import annotations

from dataclasses import dataclass, field, asdict
from hashlib import sha256
import json
from typing import Any, Callable, Mapping, Sequence


@dataclass(frozen=True)
class ProofPlan:
    stages: tuple[str, ...]
    estimated_cost_usd: float
    confidence: float = 1.0


@dataclass(frozen=True)
class RecursiveUnit:
    """A verifiable recursive computation node.

    A node is atomic when it has a concrete executor and an independent verifier.
    Otherwise it may expand into children. The decomposition itself is verified
    before children are admitted to execution.
    """
    name: str
    specification: str
    preconditions: tuple[str, ...] = ()
    postconditions: tuple[str, ...] = ()
    children: tuple[str, ...] = ()
    executor_key: str | None = None
    verifier_key: str | None = None
    proof_plan: ProofPlan = field(default_factory=lambda: ProofPlan(("syntax",), 0.0001))
    risk: float = 0.1
    expected_cost_usd: float = 0.0
    expected_latency_ms: float = 0.0
    expected_quality: float = 1.0

    @property
    def atomic(self) -> bool:
        return bool(self.executor_key and self.verifier_key)

    @property
    def digest(self) -> str:
        blob = json.dumps(asdict(self), sort_keys=True, separators=(",", ":"))
        return sha256(blob.encode()).hexdigest()


@dataclass(frozen=True)
class DecompositionAssessment:
    accepted: bool
    progress: float
    coverage: float
    verifiability: float
    recoverability: float
    economic_gain: float
    score: float
    reasons: tuple[str, ...] = ()


@dataclass(frozen=True)
class RecursiveExecutionResult:
    value: Any
    success: bool
    verified: bool
    nodes_executed: int
    frontier_calls: int
    latency_ms: float
    cost_usd: float
    recovered_nodes: int
    evidence: tuple[str, ...] = ()


class RecursiveUnitRegistry:
    def __init__(self) -> None:
        self._units: dict[str, RecursiveUnit] = {}
        self._executors: dict[str, Callable[[Any], Any]] = {}
        self._verifiers: dict[str, Callable[[Any], tuple[bool, float, Any]]] = {}

    def add(
        self,
        unit: RecursiveUnit,
        *,
        executor: Callable[[Any], Any] | None = None,
        verifier: Callable[[Any], tuple[bool, float, Any]] | None = None,
    ) -> None:
        self._units[unit.name] = unit
        if executor is not None:
            self._executors[unit.executor_key or unit.name] = executor
        if verifier is not None:
            self._verifiers[unit.verifier_key or unit.name] = verifier

    def get(self, name: str) -> RecursiveUnit:
        return self._units[name]

    def values(self) -> tuple[RecursiveUnit, ...]:
        return tuple(self._units.values())

    def execute(self, name: str, payload: Any) -> tuple[Any, bool, float, Any]:
        unit = self.get(name)
        if not unit.atomic:
            raise ValueError(f"unit {name!r} is not atomic")
        value = self._executors[unit.executor_key or unit.name](payload)
        ok, quality, detail = self._verifiers[unit.verifier_key or unit.name](value)
        return value, ok, quality, detail


class DecompositionVerifier:
    """Verifies recursive splits before execution.

    This is intentionally generic. Callers can supply problem/child complexity
    and obligation coverage models, but the default catches obvious structural
    failures without requiring an LLM.
    """

    def assess(
        self,
        parent: RecursiveUnit,
        children: Sequence[RecursiveUnit],
        *,
        child_complexities: Sequence[float] | None = None,
        parent_obligations: set[str] | None = None,
        child_obligations: Sequence[set[str]] | None = None,
    ) -> DecompositionAssessment:
        reasons: list[str] = []
        if not children:
            return DecompositionAssessment(False, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0, ("no_children",))
        parent_c = float(len(parent.specification))
        if child_complexities is None:
            child_complexities = [float(len(c.specification)) for c in children]
        positive_progress = sum(c < parent_c for c in child_complexities) / max(1, len(child_complexities))
        progress = min(1.0, positive_progress)
        if progress < 1.0:
            reasons.append("not_all_children_strictly_smaller")

        if parent_obligations is None:
            parent_obligations = set(parent.postconditions)
        if child_obligations is None:
            child_obligations = [set(c.postconditions) for c in children]
        covered = set().union(*child_obligations) if child_obligations else set()
        coverage = len(parent_obligations & covered) / max(1, len(parent_obligations)) if parent_obligations else 1.0
        if coverage < 1.0:
            reasons.append("lost_obligation")

        atomic_count = sum(c.atomic for c in children)
        verifiability = atomic_count / len(children)
        recoverability = 1.0 if len(children) > 1 else 0.6
        child_cost = sum(c.expected_cost_usd + c.proof_plan.estimated_cost_usd for c in children)
        parent_cost = max(1e-9, parent.expected_cost_usd + parent.proof_plan.estimated_cost_usd)
        economic_gain = parent_cost / max(parent_cost * 1.01, child_cost) if child_cost else 1.0
        score = 0.25 * progress + 0.25 * coverage + 0.2 * verifiability + 0.15 * recoverability + 0.15 * min(1.0, economic_gain)
        accepted = not reasons and score >= 0.8
        if not accepted and not reasons:
            reasons.append("low_decomposition_score")
        return DecompositionAssessment(accepted, progress, coverage, verifiability, recoverability, economic_gain, score, tuple(reasons))


class AdaptiveVerifier:
    """Independent verification compiler + adversarial verification hook."""
    COSTS = {
        "syntax": 0.0001,
        "type": 0.0002,
        "unit": 0.001,
        "property": 0.004,
        "differential": 0.008,
        "formal": 0.15,
        "adversarial": 0.01,
    }

    def plan(self, *, risk: float, novelty: float, value: float) -> ProofPlan:
        stages = ["syntax", "type", "unit"]
        if risk > 0.25 or novelty > 0.25:
            stages.append("property")
        if novelty > 0.4:
            stages.append("differential")
        if risk > 0.7 or value > 0.8:
            stages.append("formal")
        if novelty > 0.5 or risk > 0.5:
            stages.append("adversarial")
        cost = sum(self.COSTS[s] for s in stages)
        return ProofPlan(tuple(stages), cost, confidence=min(0.999, 0.75 + 0.05 * len(stages)))

    def verify(
        self,
        value: Any,
        *,
        stages: Sequence[tuple[str, Callable[[Any], tuple[bool, float, Any]]]],
        target_quality: float = 0.99,
    ) -> tuple[bool, float, float, tuple[str, ...], Any]:
        spent = 0.0
        used: list[str] = []
        quality = 0.0
        detail: Any = None
        for name, fn in stages:
            used.append(name)
            ok, q, d = fn(value)
            quality = max(quality, q)
            detail = d if d is not None else detail
            spent += self.COSTS.get(name, 0.001)
            if not ok:
                return False, quality, spent, tuple(used), detail
            if quality >= target_quality and name in {"unit", "property", "differential", "formal", "adversarial"}:
                # Critical/adversarial stages must still run when explicitly present.
                if name == used[-1] and "adversarial" not in [s[0] for s in stages if s[0] != name]:
                    return True, quality, spent, tuple(used), None
        return quality >= target_quality, quality, spent, tuple(used), detail


class RecursiveExecutor:
    """Runtime-structured executor that only reruns invalid subtrees."""
    def __init__(self, registry: RecursiveUnitRegistry, decomposer: DecompositionVerifier | None = None):
        self.registry = registry
        self.decomposer = decomposer or DecompositionVerifier()
        self._frontier_calls = 0

    def run(self, root: RecursiveUnit, payload: Any, *, recovery: Mapping[str, str] | None = None) -> RecursiveExecutionResult:
        from time import perf_counter
        start = perf_counter()
        evidence: list[str] = []
        recovered = 0
        executed = 0
        current = payload

        def visit(unit: RecursiveUnit, value: Any) -> tuple[Any, bool]:
            nonlocal executed, recovered, current
            executed += 1
            if unit.atomic:
                out, ok, quality, detail = self.registry.execute(unit.name, value)
                evidence.append(f"{unit.name}:{quality:.4f}")
                if ok:
                    return out, True
                # Recovery is local: retry/repair only this node if a named recovery unit exists.
                if recovery and unit.name in recovery:
                    repaired = self.registry.get(recovery[unit.name])
                    recovered += 1
                    rout, rok, rq, rd = self.registry.execute(repaired.name, value)
                    evidence.append(f"recovery:{repaired.name}:{rq:.4f}")
                    return rout, rok
                return out, False
            children = [self.registry.get(c) for c in unit.children]
            assessment = self.decomposer.assess(unit, children)
            if not assessment.accepted:
                evidence.append(f"decomposition_rejected:{unit.name}")
                return value, False
            out = value
            for child in children:
                out, ok = visit(child, out)
                if not ok:
                    return out, False
            return out, True

        value, ok = visit(root, current)
        elapsed = (perf_counter() - start) * 1000
        cost = sum(self.registry.get(e.split(":", 1)[0]).expected_cost_usd for e in evidence if e and e.split(":", 1)[0] in {u.name for u in self.registry.values()})
        return RecursiveExecutionResult(value, ok, ok, executed, self._frontier_calls, elapsed, cost, recovered, tuple(evidence))
