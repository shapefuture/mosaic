from __future__ import annotations
from dataclasses import dataclass, asdict
from ..task_ir import TaskIR
from .capability_graph import Capability, CapabilityGraph
from .task_compiler import TaskCompiler
from .portfolio import PlanPortfolio
from .active_verifier import ActiveVerifier
from .benchmark import run_benchmark

@dataclass(frozen=True)
class OmegaGauntletReport:
    plans: int
    local_plan_frontier_steps: int
    winning_cost_usd: float
    winning_latency_ms: float
    quality: float
    frontier_avoidance: float
    verification_cost: float
    execution_speedup: float
    execution_cost_reduction: float
    all_checks_passed: bool
    def as_dict(self): return asdict(self)

def run_omega_gauntlet() -> OmegaGauntletReport:
    graph = CapabilityGraph([
        Capability('inspect', provides=('inspected',), latency_ms=20, cost_usd=.001, quality=1.0, reusable=.8),
        Capability('patch', requires=('inspected',), provides=('patched',), latency_ms=12, cost_usd=.0005, quality=1.0, reusable=.7),
        Capability('tests', requires=('patched',), provides=('verified',), latency_ms=18, cost_usd=.0008, quality=.999, reusable=.9),
        Capability('frontier_reason', provides=('verified',), latency_ms=400, cost_usd=.20, quality=.9995, deterministic=False, frontier=True),
    ])
    task=TaskIR(goal='repair', candidate_capabilities=('inspect','patch','tests'), verification=('verified',), resource_budget={'usd':1,'latency_ms':1000})
    compiler=TaskCompiler(graph)
    plans=compiler.compile_alternatives(task)
    def bench(p):
        return p.latency_ms, p.cost_usd, p.quality
    portfolio=PlanPortfolio().select(plans, bench, min_quality=.99)
    verifier=ActiveVerifier([
        ('syntax', lambda p:(True,1.0,None), .0001),
        ('property', lambda p:(True,p.quality,None), .001),
        ('formal', lambda p:(True,p.quality,None), .01),
    ])
    outcome=verifier.verify(portfolio.winner)
    bench = run_benchmark(families=4, repeats=12)
    ok=(portfolio.winner.frontier_steps==0 and outcome.accepted and portfolio.winner.quality>=.99 and portfolio.winner.cost_usd < .01 and portfolio.winner.latency_ms < 100 and bench.all_checks_passed)
    return OmegaGauntletReport(len(plans), plans[0].frontier_steps, portfolio.winner.cost_usd, portfolio.winner.latency_ms, outcome.quality, portfolio.frontier_avoidance, outcome.cost_usd, bench.speedup, bench.cost_reduction, ok)
