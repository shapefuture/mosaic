from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
import json
from ..task_ir import TaskIR
from .capability_graph import Capability, CapabilityGraph

@dataclass(frozen=True)
class ExecutionPlan:
    capabilities: tuple[Capability, ...]
    frontier_steps: int
    latency_ms: float
    cost_usd: float
    quality: float
    deterministic_fraction: float
    digest: str

    def score(self) -> float:
        return self.quality / max(1e-9, (self.latency_ms/1000.0) * max(self.cost_usd, 1e-9))

class TaskCompiler:
    def __init__(self, graph: CapabilityGraph):
        self.graph = graph

    def compile(self, task: TaskIR, *, allow_frontier: bool = False) -> ExecutionPlan:
        goals = set(task.verification or task.candidate_capabilities)
        selected = self.graph.greedy_plan(goals, allow_frontier=allow_frontier)
        quality = 1.0
        latency = 0.0
        cost = 0.0
        frontier = 0
        det = 0
        for c in selected:
            quality *= max(0.0, min(1.0, c.quality))
            latency += c.latency_ms
            cost += c.cost_usd
            frontier += int(c.frontier)
            det += int(c.deterministic)
        payload = [c.digest for c in selected]
        digest = sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        return ExecutionPlan(tuple(selected), frontier, latency, cost, quality, det/max(1,len(selected)), digest)

    def compile_alternatives(self, task: TaskIR) -> tuple[ExecutionPlan, ...]:
        plans = [self.compile(task, allow_frontier=False), self.compile(task, allow_frontier=True)]
        # Prefer plans that substitute deterministic local capability chains.
        if plans[0].digest == plans[1].digest:
            return tuple(plans[:1])
        return tuple(sorted(plans, key=lambda p: (-p.score(), p.frontier_steps, p.cost_usd)))
