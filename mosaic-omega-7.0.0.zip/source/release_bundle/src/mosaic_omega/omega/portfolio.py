from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Sequence
from .task_compiler import ExecutionPlan

@dataclass(frozen=True)
class PortfolioResult:
    winner: ExecutionPlan
    rejected: tuple[tuple[str, str], ...]
    expected_speedup: float
    frontier_avoidance: float

class PlanPortfolio:
    """Empirical portfolio optimizer: statically screen, then benchmark candidates.

    The key disruption is that plans compete as executable programs, not prompts.
    A plan is rejected if it violates quality or loses on measured economic utility.
    """
    def select(self, plans: Sequence[ExecutionPlan], benchmark: Callable[[ExecutionPlan], tuple[float,float,float]], *, min_quality: float = .99) -> PortfolioResult:
        if not plans:
            raise ValueError('no plans')
        accepted=[]; rejected=[]
        for p in plans:
            if p.quality < min_quality:
                rejected.append((p.digest,'quality'))
                continue
            latency,cost,quality = benchmark(p)
            if quality < min_quality:
                rejected.append((p.digest,'measured_quality'))
                continue
            accepted.append((p,latency,cost,quality))
        if not accepted:
            raise ValueError('no plan survived benchmark')
        winner, wl, wc, wq = min(accepted, key=lambda x: (x[1]*max(x[2],1e-9)/max(x[3],1e-9), x[1]))
        baseline = max((x[1]*max(x[2],1e-9)/max(x[3],1e-9) for x in accepted), default=1.0)
        expected = baseline / max(wl*max(wc,1e-9)/max(wq,1e-9),1e-12)
        frontier = 1.0 - winner.frontier_steps / max(1, max(p.frontier_steps for p,_,_,_ in accepted))
        return PortfolioResult(winner, tuple(rejected), expected, frontier)
