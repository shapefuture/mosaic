from __future__ import annotations

import os
import resource
import subprocess
import sys
from dataclasses import dataclass


@dataclass(frozen=True)
class IsolationLimits:
    cpu_seconds: int = 5
    memory_bytes: int = 512 * 1024 * 1024
    file_size_bytes: int = 16 * 1024 * 1024
    nofile: int = 64


def preexec_limits(limits: IsolationLimits):
    def apply():
        resource.setrlimit(resource.RLIMIT_CPU, (limits.cpu_seconds, limits.cpu_seconds))
        resource.setrlimit(resource.RLIMIT_AS, (limits.memory_bytes, limits.memory_bytes))
        resource.setrlimit(resource.RLIMIT_FSIZE, (limits.file_size_bytes, limits.file_size_bytes))
        resource.setrlimit(resource.RLIMIT_NOFILE, (limits.nofile, limits.nofile))
        os.nice(10)
    return apply


def run_isolated(argv: list[str], limits: IsolationLimits = IsolationLimits(), timeout_s: float = 10.0) -> subprocess.CompletedProcess[str]:
    if not argv:
        raise ValueError("argv must not be empty")
    return subprocess.run(
        argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, timeout=timeout_s, start_new_session=True,
        preexec_fn=preexec_limits(limits),
        close_fds=True,
    )
