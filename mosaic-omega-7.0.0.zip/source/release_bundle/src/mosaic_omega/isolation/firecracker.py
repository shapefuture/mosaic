from __future__ import annotations

import shutil
from dataclasses import dataclass


@dataclass(frozen=True)
class FirecrackerCapabilities:
    available: bool
    path: str | None


def detect_firecracker() -> FirecrackerCapabilities:
    path = shutil.which("firecracker")
    return FirecrackerCapabilities(bool(path), path)


class FirecrackerLauncher:
    """Capability-aware launcher contract.

    MOSAIC does not silently fall back to weaker isolation when a policy requires a VM.
    """
    def __init__(self):
        self.capabilities = detect_firecracker()

    def require_available(self) -> str:
        if not self.capabilities.available:
            raise RuntimeError("Firecracker is required by policy but is not installed")
        return self.capabilities.path  # type: ignore[return-value]
