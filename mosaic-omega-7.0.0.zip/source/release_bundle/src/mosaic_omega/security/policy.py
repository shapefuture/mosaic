from __future__ import annotations

from dataclasses import dataclass

from ..model import Candidate


@dataclass(frozen=True)
class ExecutionPolicy:
    allowed_targets: frozenset[str] = frozenset({"reference-cpu", "native-cpu", "llvm-cpu"})
    allowed_effects: frozenset[str] = frozenset()
    max_input_size: int = 1_000_000
    require_sandbox_for_untrusted: bool = True
    allow_gpu: bool = False


def authorize(candidate: Candidate, policy: ExecutionPolicy) -> tuple[bool, str]:
    target = candidate.spec.target
    if target not in policy.allowed_targets:
        if target in {"cuda", "rocm"} and policy.allow_gpu:
            pass
        else:
            return False, "target is not authorized"
    if candidate.spec.input_size > policy.max_input_size:
        return False, "input size exceeds policy"
    if not candidate.spec.resource.max_cost_usd > 0:
        return False, "invalid cost budget"
    return True, "authorized"
