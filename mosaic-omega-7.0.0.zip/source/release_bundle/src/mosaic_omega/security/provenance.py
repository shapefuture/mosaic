from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
import hmac
import json
import platform
from time import time

from ..model import Candidate, Observation


@dataclass(frozen=True)
class Manifest:
    candidate_id: str
    program_digest: str
    target: str
    source: str
    lineage: tuple[str, ...]
    timestamp: int
    host_class: str

    def canonical_bytes(self) -> bytes:
        return json.dumps(asdict(self), sort_keys=True, separators=(",", ":")).encode()


@dataclass(frozen=True)
class Attestation:
    manifest: Manifest
    mac: str


def make_manifest(candidate: Candidate, program_digest: str) -> Manifest:
    return Manifest(candidate.genome_id, program_digest, candidate.spec.target, candidate.source, candidate.lineage, int(time()), platform.machine())


def attest(manifest: Manifest, key: bytes) -> Attestation:
    if not key:
        raise ValueError("attestation key must not be empty")
    mac = hmac.new(key, manifest.canonical_bytes(), sha256).hexdigest()
    return Attestation(manifest, mac)


def verify_attestation(attestation: Attestation, key: bytes) -> bool:
    expected = hmac.new(key, attestation.manifest.canonical_bytes(), sha256).hexdigest()
    return hmac.compare_digest(expected, attestation.mac)
