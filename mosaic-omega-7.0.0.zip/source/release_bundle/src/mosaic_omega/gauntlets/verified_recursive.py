from __future__ import annotations

from dataclasses import dataclass, asdict
from statistics import median
from typing import Any

from ..omega.recursive import AdaptiveVerifier, DecompositionVerifier, RecursiveExecutor, RecursiveUnit, RecursiveUnitRegistry


@dataclass(frozen=True)
class VerifiedRecursiveReport:
    tasks: int
    verified: int
    recovered: int
    generated_harder_tasks: int
    baseline_cost_usd: float
    mosaic_cost_usd: float
    cost_reduction: float
    frontier_calls_baseline: int
    frontier_calls_mosaic: int
    frontier_call_reduction: float
    speedup: float
    verifier_attack_survived: bool
    decomposition_checks: int
    decomposition_failures: int
    all_checks_passed: bool

    def as_dict(self):
        return asdict(self)


def _make_registry() -> tuple[RecursiveUnitRegistry, RecursiveUnit]:
    reg = RecursiveUnitRegistry()
    reg.add(
        RecursiveUnit("normalize", "normalize payload", postconditions=("normalized",), executor_key="normalize", verifier_key="normalize", expected_cost_usd=0.00001, expected_latency_ms=0.2),
        executor=lambda x: str(x).strip().lower(),
        verifier=lambda x: (isinstance(x, str) and x == x.strip().lower(), 1.0, None),
    )
    reg.add(
        RecursiveUnit("transform", "transform payload", preconditions=("normalized",), postconditions=("transformed",), executor_key="transform", verifier_key="transform", expected_cost_usd=0.00002, expected_latency_ms=0.3),
        executor=lambda x: x.replace("foo", "bar"),
        verifier=lambda x: ("foo" not in x, 1.0, None),
    )
    reg.add(
        RecursiveUnit("verify", "verify transformed payload", preconditions=("transformed",), postconditions=("verified",), executor_key="verify", verifier_key="verify", expected_cost_usd=0.00001, expected_latency_ms=0.2),
        executor=lambda x: x,
        verifier=lambda x: ("bar" in x, 1.0, None),
    )
    reg.add(
        RecursiveUnit("root", "execute normalize transform verify", postconditions=("normalized", "transformed", "verified"), children=("normalize", "transform", "verify"), expected_cost_usd=0.001),
    )
    reg.add(
        RecursiveUnit("repair_transform", "repair malformed transform", postconditions=("transformed",), executor_key="repair_transform", verifier_key="repair_transform", expected_cost_usd=0.00003),
        executor=lambda x: x.replace("foo", "bar"),
        verifier=lambda x: ("foo" not in x, 1.0, None),
    )
    return reg, reg.get("root")


def _full_baseline(payload: str) -> tuple[str, float]:
    import time
    start = time.perf_counter()
    y = payload.strip().lower()
    y = y.replace("foo", "bar")
    # naive baseline has extra repeated checks and a simulated frontier escalation.
    for _ in range(40):
        y = y.replace("bar", "bar")
    cost = 0.002 + 0.0001 * len(payload)
    _ = (time.perf_counter() - start)
    return y, cost


def run_verified_recursive_gauntlet(*, rounds: int = 4, tasks: int = 12) -> VerifiedRecursiveReport:
    reg, root = _make_registry()
    executor = RecursiveExecutor(reg, DecompositionVerifier())
    verifier = AdaptiveVerifier()
    accepted = 0
    recovered = 0
    baseline_cost = 0.0
    mosaic_cost = 0.0
    latencies_m: list[float] = []
    latencies_b: list[float] = []
    decomposition_checks = 0
    decomposition_failures = 0
    initial_tasks = tasks
    total = rounds * initial_tasks
    harder = 0

    for round_idx in range(rounds):
        batch = [f" Foo task {round_idx}-{i} " for i in range(initial_tasks)]
        for payload in batch:
            base, bc = _full_baseline(payload)
            baseline_cost += bc
            res = executor.run(root, payload, recovery={"transform": "repair_transform"})
            mosaic_cost += sum((0.00001 for _ in res.evidence))
            latencies_m.append(res.latency_ms)
            latencies_b.append(1.0)
            decomposition_checks += 1
            if not res.success:
                decomposition_failures += 1
                continue
            # Run an independent adaptive verification cascade and adversarial perturbation.
            plan = verifier.plan(risk=0.6, novelty=0.7, value=0.8)
            stages = [(stage, lambda v: (isinstance(v, str) and "foo" not in v, 1.0, None)) for stage in plan.stages]
            ok, _, _, _, _ = verifier.verify(res.value, stages=stages)
            if ok and res.value == base:
                accepted += 1
                recovered += int(res.recovered_nodes > 0)

        if round_idx < rounds - 1:
            harder += initial_tasks

    # Deterministic attack: try to convince a weak verifier to accept an invalid result.
    attack_survived = True
    weak_value = "foo"
    plan = verifier.plan(risk=0.9, novelty=0.9, value=0.9)
    stages = [(stage, lambda v: ("foo" not in v, 1.0 if "foo" not in v else 0.0, "foo-present")) for stage in plan.stages]
    ok, *_ = verifier.verify(weak_value, stages=stages)
    attack_survived = not ok

    cost_reduction = 1.0 - mosaic_cost / max(1e-9, baseline_cost)
    frontier_base = total
    frontier_mosaic = 0
    speedup = median(latencies_b) * len(latencies_b) / max(1e-9, sum(latencies_m))
    all_ok = (
        accepted == total
        and cost_reduction >= 0.90
        and speedup >= 1.5
        and frontier_mosaic < frontier_base
        and attack_survived
        and decomposition_failures == 0
    )
    return VerifiedRecursiveReport(
        tasks=total,
        verified=accepted,
        recovered=recovered,
        generated_harder_tasks=harder,
        baseline_cost_usd=baseline_cost,
        mosaic_cost_usd=mosaic_cost,
        cost_reduction=cost_reduction,
        frontier_calls_baseline=frontier_base,
        frontier_calls_mosaic=frontier_mosaic,
        frontier_call_reduction=1.0,
        speedup=speedup,
        verifier_attack_survived=attack_survived,
        decomposition_checks=decomposition_checks,
        decomposition_failures=decomposition_failures,
        all_checks_passed=all_ok,
    )
