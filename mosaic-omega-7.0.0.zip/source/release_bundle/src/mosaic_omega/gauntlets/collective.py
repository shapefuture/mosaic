from __future__ import annotations

from dataclasses import dataclass, asdict
from statistics import mean

from ..task_ir import TaskIR
from ..capability import ProofCarryingCapability, CapabilityPatch
from ..control import ActionEstimate, MarginalValueController
from ..verification import VerificationCompiler
from ..optimize.plan_competition import PlanCandidate, PlanCompetition
from ..ecu.core import ECUAction, ECUContract, ECUEnvironment, ExecutableComputeUnit
from ..learning.trajectory_compiler import compile_trajectory
from ..gauntlets.maximal import _make_runs

@dataclass(frozen=True)
class CollectiveGauntletReport:
    trajectories: int
    parameterized_coverage: float
    compiled_units: int
    verified_units: int
    plan_competition_gain: float
    verification_cost_ratio: float
    control_stop_is_economic: bool
    pcc_valid: bool
    capability_patch_positive: bool
    no_frontier_needed_for_repeated_path: bool
    e2e_passed: bool

    @property
    def all_checks_passed(self):
        return self.e2e_passed

    def as_dict(self):
        return asdict(self)


def run_collective_gauntlet() -> CollectiveGauntletReport:
    runs = _make_runs()
    compiled = [compile_trajectory(t, "collective-fixture", min_confidence=0.0) for t in runs]
    compiled = [x for x in compiled if x is not None]

    # Parameterization is evaluated on the actual action argument surface.
    with_args = sum(1 for c in compiled if any(a.args for a in c.ecu.actions))
    parameterized_coverage = with_args / max(1, len(compiled))

    verified = 0
    for c in compiled:
        names = {a.name for a in c.ecu.actions}
        handlers = {n: (lambda env, **kw: env.state.__setitem__("steps", env.state.get("steps", 0) + 1)) for n in names}
        result = c.ecu.run(ECUEnvironment({"steps": 0}, handlers))
        verified += int(result.success)

    task = TaskIR(
        goal="repair repository change",
        constraints=("tests pass",),
        candidate_capabilities=("inspect", "patch", "verify"),
        verification=("unit", "differential"),
        resource_budget={"usd": 1.0, "latency_ms": 500.0},
    )
    assert task.digest

    vc = VerificationCompiler()
    cheap = vc.compile(risk=.1, novelty=.1, change_surface=.1, value=.1)
    deep = vc.compile(risk=.9, novelty=.9, change_surface=.9, value=.9)
    verification_cost_ratio = cheap.estimated_cost_usd / max(deep.estimated_cost_usd, 1e-9)

    control = MarginalValueController(min_roi=1.0)
    decision = control.decide([
        ActionEstimate("compile_cached", .2, .2, .4, .05),
        ActionEstimate("frontier_retry", .1, .0, 0.0, 1.0),
    ])
    control_stop_is_economic = decision.action == "compile_cached" and not decision.stop

    plan = PlanCompetition().select([
        PlanCandidate("frontier", 100.0, 1.0, 1.0, .99, True),
        PlanCandidate("compiled", 20.0, .1, .999, .999, True),
    ], min_quality=.99)
    baseline_score = 1.0 / (100.0 * 1.0)
    selected_score = plan.score
    plan_competition_gain = selected_score / baseline_score

    pcc = ProofCarryingCapability(
        name="fixture-repair",
        description="verified compiled repair path",
        preconditions=("repo exists",),
        postconditions=("tests pass",),
        implementation_digest=compiled[0].ecu.digest if compiled else "none",
        verifier_digest=VerificationCompiler().__class__.__name__,
        lineage=(compiled[0].trajectory_id,) if compiled else (),
        cost_usd=.1,
        latency_ms=20.0,
    )
    pcc_valid = len(pcc.digest) == 64 and pcc.to_dict()["digest"] == pcc.digest
    patch = CapabilityPatch(pcc.digest, pcc.digest, quality_delta=.01, latency_delta_ms=-5, cost_delta_usd=-.01)
    capability_patch_positive = patch.improvement > 0

    no_frontier = all(c.frontier_nodes == 0 or c.confidence < 0.5 for c in compiled) if compiled else False
    return CollectiveGauntletReport(
        trajectories=len(runs), parameterized_coverage=parameterized_coverage,
        compiled_units=len(compiled), verified_units=verified,
        plan_competition_gain=plan_competition_gain,
        verification_cost_ratio=verification_cost_ratio,
        control_stop_is_economic=control_stop_is_economic,
        pcc_valid=pcc_valid,
        capability_patch_positive=capability_patch_positive,
        no_frontier_needed_for_repeated_path=no_frontier,
        e2e_passed=bool(compiled) and verified == len(compiled) and pcc_valid and capability_patch_positive,
    )
