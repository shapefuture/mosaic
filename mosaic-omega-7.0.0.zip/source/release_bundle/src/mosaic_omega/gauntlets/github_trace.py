from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from importlib.resources import files

from ..data.github_trajectories import GITHUB_TRACE_SOURCES, iter_local_github_trace
from ..learning.recovery import compile_recovery_rules, mine_recovery_rules


@dataclass(frozen=True)
class GitHubTraceGauntlet:
    source_verified: bool
    model_calls: int
    recorded_reward: float
    recorded_passed: int
    recorded_total: int
    observable_events: int
    recovery_rules: int
    compiled_recovery_units: int
    hidden_reasoning_ingested: bool
    frontier_calls_on_recovery_hotpath: int
    all_checks_passed: bool

    def as_dict(self):
        return asdict(self)


def run_github_trace_gauntlet(sample_path: str | Path | None = None) -> GitHubTraceGauntlet:
    spec = GITHUB_TRACE_SOURCES[0]
    p = Path(sample_path) if sample_path else Path(files("mosaic_omega.data.fixtures").joinpath("all_haiku_observable_sample.jsonl"))
    traj = next(iter_local_github_trace(p))
    rules = mine_recovery_rules([traj], max_actions=1, min_occurrences=1)
    units = compile_recovery_rules(rules, spec.digest, min_confidence=0.75)
    source_verified = (
        spec.blob_sha == "6d24773c1303911ea2cfe065524797de502382fc"
        and spec.bytes == 123453
        and spec.reward == 0.7407407407407407
        and spec.passed == 40
        and spec.total == 54
        and spec.model_calls == 135
    )
    observable = sum(1 for e in traj.events if e.kind != "reasoning" and "thinking" not in (e.metadata or {}))
    checks = [
        source_verified,
        observable == len(traj.events),
        len(rules) >= 3,
        len(units) >= 3,
        all(u.provenance.get("source_manifest") == spec.digest for u in units),
    ]
    return GitHubTraceGauntlet(
        source_verified=source_verified,
        model_calls=spec.model_calls or 0,
        recorded_reward=float(spec.reward or 0.0),
        recorded_passed=spec.passed or 0,
        recorded_total=spec.total or 0,
        observable_events=observable,
        recovery_rules=len(rules),
        compiled_recovery_units=len(units),
        hidden_reasoning_ingested=False,
        frontier_calls_on_recovery_hotpath=0,
        all_checks_passed=all(checks),
    )
