from __future__ import annotations
from dataclasses import asdict, dataclass
from ..experience import ExperienceCompiler
from ..trajectory.events import Trajectory, TrajectoryEvent

@dataclass(frozen=True)
class ExperienceGauntletResult:
    trajectories: int
    reasoning_bearing: int
    execution_only: int
    candidate_patches: int
    promoted_patches: int
    critical_steps: int
    causal_edges: int
    reasoning_coverage: float
    execution_coverage: float
    joint_coverage: float
    cross_view_gain: float
    retrieval_hits: int
    negative_memory_guard: bool
    status: str
    def as_dict(self): return asdict(self)

def _make(run_id: str, reasoning: bool, variant: int) -> Trajectory:
    ev=[]
    if reasoning:
        ev.append(TrajectoryEvent(1,"reasoning","",metadata={"reasoning_signals":{
            "goal":"repair timeout",
            "hypothesis":"algorithmic bottleneck",
            "evidence":"run exceeds deadline",
            "decision":"replace slow path",
            "expected_effect":"lower latency",
            "uncertainty":"small",
            "tool_intent":"inspect and test",
        }}))
    ev += [TrajectoryEvent(2,"tool","inspect",ok=True)]
    if variant % 5 == 0:
        ev += [TrajectoryEvent(3,"tool","run",ok=False,observation="timeout"), TrajectoryEvent(4,"tool","repair",ok=False,observation="repair_failed"), TrajectoryEvent(5,"tool","repair",ok=True), TrajectoryEvent(6,"verify","test",ok=True)]
    else:
        ev += [TrajectoryEvent(3,"tool","run",ok=True), TrajectoryEvent(4,"verify","test",ok=True)]
    return Trajectory(run_id, tuple(ev))

def run_experience_gauntlet(*, trajectories: int = 24) -> ExperienceGauntletResult:
    if trajectories < 12: raise ValueError("experience gauntlet requires >=12 trajectories")
    ts=[_make(f"exp-{i}", reasoning=(i%3!=0), variant=i) for i in range(trajectories)]
    compiler=ExperienceCompiler()
    candidates, report=compiler.mine(ts)
    terms={"repair","verify","inspect","optimize"}
    hits=len(compiler.memory.retrieve(terms, limit=5))
    # Negative-memory guard is structural: a zero-success patch cannot enter procedural memory.
    guard=all(p.success_rate >= 0.5 for p in compiler.memory.procedural.values())
    status="PASS" if (report.promoted_patches>0 and report.causal_edges>0 and report.reasoning_events>0 and report.execution_events>0 and report.critical_steps>0 and guard and hits>0) else "FAIL"
    return ExperienceGauntletResult(trajectories, sum(i%3!=0 for i in range(trajectories)), sum(i%3==0 for i in range(trajectories)), report.candidate_patches, report.promoted_patches, report.critical_steps, report.causal_edges, report.reasoning_coverage, report.execution_coverage, report.joint_coverage, report.cross_view_gain, hits, guard, status)
