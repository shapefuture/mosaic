from __future__ import annotations
from dataclasses import dataclass
from math import inf
from typing import Iterable

from .market import CapabilityOffer, NodeProfile

@dataclass(frozen=True)
class RouteCandidate:
    kind: str
    provider_id: str
    quality: float
    latency_ms: float
    cost_usd: float
    energy_j: float
    future_savings_usd: float = 0.0
    gpu: bool = False
    locality: str = "unknown"

    @property
    def utility(self) -> float:
        return self.quality * max(self.future_savings_usd + 1.0, 1.0) / (
            max(self.latency_ms, 1e-6) * max(self.cost_usd, 1e-12) * max(self.energy_j + 1.0, 1.0)
        )

@dataclass(frozen=True)
class RoutePlan:
    selected: RouteCandidate
    alternatives: tuple[RouteCandidate, ...]
    reason: str

class CapabilityRouter:
    """Local-first, knowledge-first router. GPU is a constrained exception path."""
    def __init__(self, *, gpu_margin: float = 0.25):
        self.gpu_margin = gpu_margin

    def choose(self, candidates: Iterable[RouteCandidate], *, min_quality: float = 0.999, max_latency_ms: float = inf, max_cost_usd: float = inf) -> RoutePlan:
        viable = [c for c in candidates if c.quality >= min_quality and c.latency_ms <= max_latency_ms and c.cost_usd <= max_cost_usd]
        if not viable:
            raise ValueError("no route satisfies quality/latency/cost constraints")
        nongpu = [c for c in viable if not c.gpu]
        gpu = [c for c in viable if c.gpu]
        pool = nongpu or gpu
        best = max(pool, key=lambda c: c.utility)
        if nongpu and gpu:
            best_gpu = max(gpu, key=lambda c: c.utility)
            if best_gpu.utility > best.utility * (1.0 + self.gpu_margin):
                best = best_gpu
                reason = "GPU exception: exceeds best non-GPU utility by configured margin"
            else:
                reason = "GPU rejected: non-GPU route is Pareto/economically sufficient"
        elif best.gpu:
            reason = "GPU required: no viable non-GPU route"
        else:
            reason = "non-GPU route selected"
        return RoutePlan(best, tuple(viable), reason)
