from __future__ import annotations
from .market import CapabilityRegistry, CapabilityOffer, CapabilityQuery, NodeProfile, NodeRoles, ReplicationPolicy, UsefulWorkLedger, Challenge, CapabilityFutures
from .pui import PUIRecord
from .routing import CapabilityRouter, RouteCandidate
from ..capability.pcc import ProofCarryingCapability


def run_network_gauntlet() -> dict:
    reg = CapabilityRegistry()
    reg.register_node(NodeProfile("cpu-a", frozenset({NodeRoles.EXECUTOR, NodeRoles.VERIFIER, NodeRoles.COMPILER}), locality="same", trust=0.95, execution_reliability=0.99, verification_reliability=0.99, cost_usd=0.001, latency_ms=8, energy_j=1.0, gpu=False, capabilities=frozenset({"repair"})))
    reg.register_node(NodeProfile("cpu-b", frozenset({NodeRoles.EXECUTOR, NodeRoles.VERIFIER}), locality="remote", trust=0.92, execution_reliability=0.98, verification_reliability=0.97, cost_usd=0.002, latency_ms=22, energy_j=2.5, gpu=False, capabilities=frozenset({"repair","compile"})))
    reg.register_node(NodeProfile("gpu-z", frozenset({NodeRoles.EXECUTOR}), locality="remote", trust=0.9, execution_reliability=0.99, verification_reliability=0.9, cost_usd=0.05, latency_ms=5, energy_j=150.0, gpu=True, capabilities=frozenset({"repair","compile"})))
    cap = ProofCarryingCapability(name="repair_repeated_failure", description="verified repair", preconditions=("known_failure",), postconditions=("passes",), implementation_digest="impl", verifier_digest="ver", cost_usd=0.001, latency_ms=8, provenance={"source":"mosaic"})
    offer = CapabilityOffer(capability=cap, provider_id="cpu-a", family="repair", locality="same", verification_level=3, expected_reuse=1000, future_savings_usd=20.0, energy_j=1.0, cost_usd=0.001, latency_ms=8, quality=1.0)
    digest = reg.publish(offer)
    q = reg.query(CapabilityQuery("repair", locality="same"))
    decision = reg.decide_promotion(offer, replicas_passed=3, policy=ReplicationPolicy(), independent_environment_passed=True, improvement_vs_parent=True)
    ledger = UsefulWorkLedger(); ledger.credit_offer(offer, pui=decision.pui, verification_cost_usd=0.0002)
    router = CapabilityRouter()
    portfolio = [
        ("cached-capability", RouteCandidate("capability", "cpu-a", 1.0, 1.0, 0.0002, 0.2, 20.0, False, "same")),
        ("cpu-fast", RouteCandidate("cpu", "cpu-a", 1.0, 8, 0.001, 1, 20.0, False, "same")),
        ("remote-cpu", RouteCandidate("cpu", "cpu-b", 1.0, 22, 0.002, 2.5, 10.0, False, "remote")),
        ("gpu", RouteCandidate("gpu", "gpu-z", 1.0, 5, 0.05, 150, 0.0, True, "remote")),
    ]
    selected = []
    gpu_count = 0
    for _, *rest in portfolio:
        plan = router.choose([rest[0]])
        selected.append(plan.selected.provider_id)
        gpu_count += int(plan.selected.gpu)
    # One explicit GPU-exception case: all non-GPU choices are infeasible on a strict 2ms latency budget.
    mixed_plan = router.choose([
        RouteCandidate("cpu", "cpu-a", 1.0, 8, .001, 1),
        RouteCandidate("gpu", "gpu-z", 1.0, 5, .05, 150, gpu=True),
    ])
    gpu_exception = router.choose([
        RouteCandidate("cpu", "cpu-a", 1.0, 8, .001, 1),
        RouteCandidate("gpu", "gpu-z", 1.0, 1.5, .05, 150, gpu=True),
    ], max_latency_ms=2)
    challenge = Challenge("c1", digest, "attacker-1", "verifier-bypass", "evidence-hash")
    reg.propose_challenge(challenge)
    challenge_result = reg.challenge("c1", exploit_found=True)
    transfer = CapabilityFutures(expected_uses=5000, savings_per_use_usd=0.01, reliability=.98, risk=.02).expected_value_usd
    passed_cases = [
        bool(digest), bool(q), decision.accepted, ledger.net_future_value_usd > 0,
        selected[0] == "cpu-a", selected[1] == "cpu-a", selected[2] == "cpu-b", selected[3] == "gpu-z",
        mixed_plan.selected.provider_id == "cpu-a", mixed_plan.selected.gpu is False, gpu_exception.selected.provider_id == "gpu-z", challenge_result.valid, transfer > 40,
    ]
    return {
        "passed": all(passed_cases),
        "case_count": len(passed_cases),
        "passed_cases": sum(passed_cases),
        "offers": len(q),
        "promotion": decision.accepted,
        "replicas": decision.required_replicas,
        "pui": decision.pui,
        "net_future_value_usd": ledger.net_future_value_usd,
        "selected": selected,
        "gpu_exception_provider": gpu_exception.selected.provider_id,
        "successful_challenge_revoked": challenge_result.valid,
        "future_value_usd": transfer,
        "reason": "GPU rejected except when hard latency constraint makes non-GPU infeasible",
    }
