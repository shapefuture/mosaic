from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from hashlib import sha256
import json
import math
import random
from typing import Iterable, Mapping

from ..capability.pcc import ProofCarryingCapability
from .pui import capability_future_value

class NodeRoles(str, Enum):
    EXECUTOR = "executor"
    VERIFIER = "verifier"
    COMPILER = "compiler"
    SEARCHER = "searcher"
    STORAGE = "storage"
    MEMORY = "memory"
    RELAY = "relay"
    BENCHMARKER = "benchmarker"
    ATTESTOR = "attestor"
    TEACHER = "teacher"

@dataclass(frozen=True)
class NodeProfile:
    node_id: str
    roles: frozenset[NodeRoles]
    locality: str = "unknown"
    trust: float = 0.5
    execution_reliability: float = 0.5
    verification_reliability: float = 0.5
    challenge_quality: float = 0.5
    latency_ms: float = 1000.0
    cost_usd: float = 1.0
    energy_j: float = 1000.0
    memory_mb: float = 1024.0
    gpu: bool = False
    capabilities: frozenset[str] = frozenset()

    def score(self) -> float:
        return (self.trust + self.execution_reliability + self.verification_reliability + self.challenge_quality) / 4.0

@dataclass(frozen=True)
class CapabilityOffer:
    capability: ProofCarryingCapability
    provider_id: str
    family: str
    locality: str = "unknown"
    verification_level: int = 1
    expected_reuse: float = 1.0
    future_savings_usd: float = 0.0
    energy_j: float = 0.0
    cost_usd: float = 0.0
    latency_ms: float = 0.0
    quality: float = 1.0
    risk: float = 0.0
    executable: bool = True
    metadata: Mapping[str, str] = field(default_factory=dict)

    @property
    def digest(self) -> str:
        payload = json.dumps({
            "capability": self.capability.to_dict(),
            "provider_id": self.provider_id,
            "family": self.family,
            "locality": self.locality,
            "verification_level": self.verification_level,
            "expected_reuse": self.expected_reuse,
            "future_savings_usd": self.future_savings_usd,
        }, sort_keys=True, separators=(",", ":")).encode()
        return sha256(payload).hexdigest()

    @property
    def useful_value(self) -> float:
        return capability_future_value(
            expected_reuse=self.expected_reuse,
            savings_per_use_usd=max(self.future_savings_usd / max(self.expected_reuse, 1e-9), 0.0),
            reliability=self.quality * max(0.0, 1.0 - self.risk),
        )

@dataclass(frozen=True)
class CapabilityQuery:
    family: str
    min_quality: float = 0.999
    max_cost_usd: float = math.inf
    max_latency_ms: float = math.inf
    locality: str | None = None
    require_executable: bool = True
    min_verification_level: int = 1
    prefer_cpu: bool = True

@dataclass(frozen=True)
class CapabilityNode:
    profile: NodeProfile
    offers: tuple[CapabilityOffer, ...]

@dataclass(frozen=True)
class ReplicationPolicy:
    base: int = 1
    novel_capability: int = 3
    mature_capability: int = 1
    high_risk: int = 3
    random_audit_probability: float = 0.10

    def replicas(self, *, trust: float, novelty: float, risk: float, mature: bool, rng: random.Random | None = None) -> int:
        if risk >= 0.7 or novelty >= 0.8:
            return self.high_risk if risk >= 0.7 else self.novel_capability
        if mature and trust >= 0.85:
            rng = rng or random.Random(0)
            return 2 if rng.random() < self.random_audit_probability else self.mature_capability
        return self.base

@dataclass(frozen=True)
class Challenge:
    challenge_id: str
    capability_digest: str
    challenger_id: str
    reason: str
    evidence_digest: str

@dataclass(frozen=True)
class ChallengeResult:
    challenge_id: str
    valid: bool
    reward_units: float
    message: str

@dataclass(frozen=True)
class PromotionDecision:
    accepted: bool
    reason: str
    required_replicas: int
    pui: float
    transfer_required: bool

@dataclass(frozen=True)
class CapabilityBounty:
    bounty_id: str
    family: str
    objective: str
    reward_usd: float
    min_quality: float = 0.999
    max_cost_usd: float = 1.0

@dataclass(frozen=True)
class CapabilityFutures:
    expected_uses: float
    savings_per_use_usd: float
    reliability: float
    risk: float

    @property
    def expected_value_usd(self) -> float:
        return capability_future_value(expected_reuse=self.expected_uses, savings_per_use_usd=self.savings_per_use_usd, reliability=self.reliability, risk=self.risk)

class CapabilityRegistry:
    """In-memory content-addressed capability market with local-first admission."""
    def __init__(self) -> None:
        self._offers: dict[str, CapabilityOffer] = {}
        self._nodes: dict[str, NodeProfile] = {}
        self._revoked: set[str] = set()
        self._challenges: dict[str, Challenge] = {}

    def register_node(self, profile: NodeProfile) -> None:
        self._nodes[profile.node_id] = profile

    def publish(self, offer: CapabilityOffer) -> str:
        if not offer.executable:
            raise ValueError("non-executable capability cannot enter executable market")
        self._offers[offer.digest] = offer
        return offer.digest

    def revoke(self, digest: str) -> None:
        self._revoked.add(digest)

    def query(self, q: CapabilityQuery) -> list[CapabilityOffer]:
        candidates: list[CapabilityOffer] = []
        for digest, offer in self._offers.items():
            if digest in self._revoked:
                continue
            if offer.family != q.family or offer.quality < q.min_quality or offer.cost_usd > q.max_cost_usd or offer.latency_ms > q.max_latency_ms:
                continue
            if offer.verification_level < q.min_verification_level or (q.require_executable and not offer.executable):
                continue
            if q.locality and offer.locality not in {q.locality, "global"}:
                continue
            candidates.append(offer)
        return candidates

    def propose_challenge(self, challenge: Challenge) -> None:
        self._challenges[challenge.challenge_id] = challenge

    def challenge(self, challenge_id: str, *, exploit_found: bool) -> ChallengeResult:
        c = self._challenges.get(challenge_id)
        if c is None:
            raise KeyError(challenge_id)
        if exploit_found:
            self._revoked.add(c.capability_digest)
            return ChallengeResult(challenge_id, True, 1.0, "capability revoked after successful challenge")
        return ChallengeResult(challenge_id, False, 0.0, "challenge not reproduced")

    def decide_promotion(
        self,
        offer: CapabilityOffer,
        *,
        replicas_passed: int,
        policy: ReplicationPolicy,
        independent_environment_passed: bool,
        improvement_vs_parent: bool,
        risk: float | None = None,
        novelty: float | None = None,
    ) -> PromotionDecision:
        node = self._nodes.get(offer.provider_id)
        trust = node.trust if node else 0.0
        risk = offer.risk if risk is None else risk
        novelty = min(1.0, 1.0 / max(offer.expected_reuse, 1.0)) if novelty is None else novelty
        required = policy.replicas(trust=trust, novelty=novelty, risk=risk, mature=offer.expected_reuse >= 100)
        pui = offer.useful_value if improvement_vs_parent and independent_environment_passed else 0.0
        accepted = replicas_passed >= required and independent_environment_passed and improvement_vs_parent and pui > 0
        reason = "promote: reproduced, improved, and useful" if accepted else "reject: promotion gate not satisfied"
        return PromotionDecision(accepted, reason, required, pui, not independent_environment_passed)

@dataclass
class UsefulWorkLedger:
    verified_useful_work: float = 0.0
    future_compute_avoided_usd: float = 0.0
    verifier_cost_usd: float = 0.0
    learning_cost_usd: float = 0.0
    challenge_rewards: float = 0.0

    def credit_offer(self, offer: CapabilityOffer, *, pui: float, verification_cost_usd: float) -> None:
        self.verified_useful_work += max(pui, 0.0)
        self.future_compute_avoided_usd += max(offer.future_savings_usd, 0.0)
        self.verifier_cost_usd += max(verification_cost_usd, 0.0)
        self.learning_cost_usd += max(offer.cost_usd, 0.0)

    @property
    def net_future_value_usd(self) -> float:
        return self.future_compute_avoided_usd - self.verifier_cost_usd - self.learning_cost_usd

    def snapshot(self) -> dict:
        return asdict(self) | {"net_future_value_usd": self.net_future_value_usd}
