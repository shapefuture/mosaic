from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class PUIRecord:
    baseline_quality: float
    candidate_quality: float
    baseline_cost_usd: float
    candidate_cost_usd: float
    baseline_latency_ms: float
    candidate_latency_ms: float
    baseline_energy_j: float
    candidate_energy_j: float
    expected_reuse: float = 1.0
    verified: bool = False
    transferred: bool = False

    @property
    def quality_delta(self) -> float:
        return self.candidate_quality - self.baseline_quality

    @property
    def future_compute_avoided_usd(self) -> float:
        return max(0.0, self.baseline_cost_usd - self.candidate_cost_usd) * max(0.0, self.expected_reuse)

    @property
    def learning_cost_usd(self) -> float:
        return max(0.0, self.candidate_cost_usd)

    @property
    def verification_value(self) -> float:
        return 1.0 if self.verified else 0.0

    @property
    def pui(self) -> float:
        if not self.verified or self.baseline_quality <= 0 or self.candidate_quality + 1e-12 < self.baseline_quality:
            return 0.0
        improvement = max(self.quality_delta, 0.0) + 1e-6
        savings = self.future_compute_avoided_usd
        transfer = 1.25 if self.transferred else 1.0
        return improvement * max(savings, 1e-9) * self.verification_value * transfer


def compute_pui(**kwargs) -> float:
    return PUIRecord(**kwargs).pui


def capability_future_value(*, expected_reuse: float, savings_per_use_usd: float, reliability: float = 1.0, risk: float = 0.0) -> float:
    return max(0.0, expected_reuse) * max(0.0, savings_per_use_usd) * max(0.0, reliability) * max(0.0, 1.0 - min(max(risk, 0.0), 1.0))
