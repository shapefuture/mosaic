# Ω5 Verified Useful-Work Network

The network layer exchanges **proof-carrying capabilities**, not raw GPU-hours.

Core principles:

- eliminate work before scheduling compute;
- prefer deterministic local/CPU execution;
- adapt replication to risk, novelty, and worker trust;
- reward verified useful improvement and future compute avoided;
- challenge capabilities with explicit adversarial verification;
- route by knowledge/data locality as well as hardware;
- keep raw trajectories/private source local and exchange content-addressed capability evidence.

`CapabilityRegistry` is a deterministic local reference implementation. A production deployment can map it to DHT/P2P transports without changing the promotion semantics.
