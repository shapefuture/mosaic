from __future__ import annotations

from dataclasses import asdict, dataclass, field
from hashlib import sha256
import json
from typing import Any, Mapping


def _canon(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _canon(v) for k, v in sorted(value.items(), key=lambda kv: str(kv[0]))}
    if isinstance(value, (list, tuple)):
        return [_canon(v) for v in value]
    if hasattr(value, "canonical"):
        return _canon(value.canonical())
    return value


@dataclass(frozen=True)
class EvidenceEvent:
    seq: int
    kind: str
    state_hash: str = ""
    payload: Mapping[str, Any] = field(default_factory=dict)
    parent_hash: str = ""

    def canonical(self) -> dict[str, Any]:
        return _canon(asdict(self))

    @property
    def event_hash(self) -> str:
        return sha256(json.dumps(self.canonical(), sort_keys=True, separators=(",", ":")).encode()).hexdigest()


@dataclass(frozen=True)
class ProvenanceLink:
    artifact_hash: str
    parent_hash: str = ""
    transformation: str = ""
    version: str = ""


@dataclass(frozen=True)
class EER:
    version: str
    run_id: str
    task: Mapping[str, Any]
    model: Mapping[str, Any]
    scaffold: Mapping[str, Any]
    environment: Mapping[str, Any]
    execution: Mapping[str, Any]
    outcome: Mapping[str, Any]
    evidence: Mapping[str, Any]
    events: tuple[EvidenceEvent, ...] = ()
    provenance: tuple[ProvenanceLink, ...] = ()

    def canonical(self) -> dict[str, Any]:
        data = asdict(self)
        return _canon(data)

    @property
    def digest(self) -> str:
        return sha256(json.dumps(self.canonical(), sort_keys=True, separators=(",", ":")).encode()).hexdigest()

    def to_json(self) -> str:
        return json.dumps(self.canonical(), sort_keys=True, separators=(",", ":"))


class EERBuilder:
    """Build immutable execution evidence from partial runtime observations."""

    def __init__(self, run_id: str, task: Mapping[str, Any]):
        self.run_id = run_id
        self.task = dict(task)
        self.model: dict[str, Any] = {}
        self.scaffold: dict[str, Any] = {}
        self.environment: dict[str, Any] = {}
        self.execution: dict[str, Any] = {}
        self.outcome: dict[str, Any] = {}
        self.evidence: dict[str, Any] = {}
        self._events: list[EvidenceEvent] = []
        self._provenance: list[ProvenanceLink] = []

    def event(self, kind: str, payload: Mapping[str, Any], state_hash: str = "") -> str:
        parent = self._events[-1].event_hash if self._events else ""
        ev = EvidenceEvent(len(self._events), kind, state_hash, dict(payload), parent)
        self._events.append(ev)
        return ev.event_hash

    def link(self, artifact_hash: str, parent_hash: str = "", transformation: str = "", version: str = "") -> None:
        self._provenance.append(ProvenanceLink(artifact_hash, parent_hash, transformation, version))

    def build(self) -> EER:
        return EER(
            version="0.4",
            run_id=self.run_id,
            task=self.task,
            model=self.model,
            scaffold=self.scaffold,
            environment=self.environment,
            execution=self.execution,
            outcome=self.outcome,
            evidence=self.evidence,
            events=tuple(self._events),
            provenance=tuple(self._provenance),
        )
