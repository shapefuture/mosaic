from __future__ import annotations
from dataclasses import dataclass, replace
from hashlib import sha256
from random import Random
from typing import Callable, Sequence
from .ir import AgentProgram, AgentNode, ProgramContract

@dataclass(frozen=True)
class HarnessGenome:
    decomposition_width: int = 4
    verifier_depth: int = 2
    parallelism: int = 4
    frontier_budget: int = 0
    cache_bias: float = 0.9
    recovery_budget: int = 2

    @property
    def digest(self) -> str:
        return sha256(repr(self).encode()).hexdigest()

class PromotionResult:
    def __init__(self, promoted: bool, baseline: dict[str,float], candidate: dict[str,float], reason: str):
        self.promoted = promoted
        self.baseline = baseline
        self.candidate = candidate
        self.reason = reason

class EvolutionController:
    """Isolated harness evolution with an external judge; no self-promotion."""
    def __init__(self, seed: int = 7):
        self.rng = Random(seed)

    def mutate(self, g: HarnessGenome) -> HarnessGenome:
        fields = [
            lambda x: replace(x, decomposition_width=max(1,min(16,x.decomposition_width + self.rng.choice([-2,-1,1,2])))),
            lambda x: replace(x, verifier_depth=max(1,min(8,x.verifier_depth + self.rng.choice([-1,1])))),
            lambda x: replace(x, parallelism=max(1,min(16,x.parallelism + self.rng.choice([-2,-1,1,2])))),
            lambda x: replace(x, cache_bias=max(0.0,min(1.0,x.cache_bias + self.rng.choice([-0.1,0.1])))),
            lambda x: replace(x, recovery_budget=max(0,min(8,x.recovery_budget + self.rng.choice([-1,1])))),
        ]
        return self.rng.choice(fields)(g)

    def promote(self, baseline: dict[str,float], candidate: dict[str,float], *, quality_floor: float = 1.0) -> PromotionResult:
        required = all(candidate.get(k, 0.0) >= baseline.get(k, 0.0) for k in ('quality','reliability'))
        strict = candidate.get('cost_usd', 1e9) < baseline.get('cost_usd', 1e9) or candidate.get('latency_ms', 1e9) < baseline.get('latency_ms', 1e9)
        robust = candidate.get('adversarial_robustness', 0.0) >= baseline.get('adversarial_robustness', 0.0)
        ok = required and strict and robust and candidate.get('quality',0.0) >= quality_floor
        return PromotionResult(ok, baseline, candidate, 'pareto win + robustness' if ok else 'rejected by external judge')
