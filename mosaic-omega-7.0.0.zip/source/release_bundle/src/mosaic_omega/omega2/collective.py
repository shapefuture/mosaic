from __future__ import annotations
from dataclasses import dataclass, asdict
from hashlib import sha256
import json
import time
from typing import Any, Mapping
from .ir import AgentProgram

@dataclass(frozen=True)
class CollectiveEnvelope:
    capability_id: str
    program_digest: str
    contract: dict[str, Any]
    benchmark: dict[str, float]
    verifier_digest: str
    lineage: tuple[str, ...]
    contributor_id: str
    privacy_mode: str = 'semantic'
    program_nodes: tuple[dict[str, Any], ...] = ()

    @property
    def digest(self) -> str:
        body = asdict(self)
        return sha256(json.dumps(body, sort_keys=True, separators=(',', ':'), default=str).encode()).hexdigest()

    def to_json(self) -> str:
        return json.dumps({**asdict(self), 'digest': self.digest}, sort_keys=True)

    @staticmethod
    def from_program(program: AgentProgram, *, contributor_id: str, benchmark: Mapping[str, float], verifier_digest: str, lineage: tuple[str,...]=(), privacy_mode: str='semantic') -> 'CollectiveEnvelope':
        # Semantic sharing by default: no source repository, prompts, or filesystem paths.
        nodes = tuple({
            'node_id': n.node_id, 'kind': n.kind.value, 'action': n.action,
            'deps': list(n.deps), 'args': dict(n.args), 'frontier': n.frontier,
            'deterministic': n.deterministic,
        } for n in program.nodes) if privacy_mode != 'abstract' else ()
        return CollectiveEnvelope(program.digest, program.digest, {'name': program.contract.name, 'tags': list(program.contract.tags)}, dict(benchmark), verifier_digest, lineage, contributor_id, privacy_mode, nodes)

class CollectiveRegistry:
    """Content-addressed peer registry. Promotion is local: imported capabilities are never trusted blindly."""
    def __init__(self):
        self._items: dict[str, CollectiveEnvelope] = {}
        self._bench: dict[str, list[dict[str,float]]] = {}

    def publish(self, env: CollectiveEnvelope) -> str:
        self._items[env.digest] = env
        return env.digest

    def candidates(self, capability_id: str | None = None) -> list[CollectiveEnvelope]:
        vals = list(self._items.values())
        if capability_id is not None:
            vals = [v for v in vals if v.capability_id == capability_id]
        return sorted(vals, key=lambda x: (-(x.benchmark.get('quality',0.0)), x.benchmark.get('cost_usd', 1e9), x.benchmark.get('latency_ms',1e9)))

    def verify_and_promote(self, env: CollectiveEnvelope, verifier: callable) -> bool:
        if env.privacy_mode not in {'semantic','abstract','executable'}:
            return False
        if env.benchmark.get('quality', 0.0) < 0.99:
            return False
        verdict = verifier(env)
        if not verdict:
            return False
        self.publish(env)
        return True

    def merge(self, other: 'CollectiveRegistry') -> int:
        before = len(self._items)
        for env in other._items.values():
            # Merge only new content; acceptance remains local at use site.
            self._items.setdefault(env.digest, env)
        return len(self._items) - before

@dataclass(frozen=True)
class ContributionReceipt:
    contributor_id: str
    capability_id: str
    improvement: float
    verified: bool
    reuse_count: int
    timestamp: float

    def digest(self) -> str:
        return sha256(json.dumps(asdict(self), sort_keys=True).encode()).hexdigest()

def contribution_receipt(contributor_id: str, env: CollectiveEnvelope, *, prior_quality: float, reuse_count: int, verified: bool) -> ContributionReceipt:
    q = env.benchmark.get('quality', 0.0)
    return ContributionReceipt(contributor_id, env.capability_id, q-prior_quality, verified, reuse_count, time.time())
