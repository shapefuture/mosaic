from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from hashlib import sha256
import json
from typing import Any, Mapping, Tuple

class NodeKind(str, Enum):
    ACTION = 'action'
    VERIFY = 'verify'
    DELEGATE = 'delegate'
    CHECKPOINT = 'checkpoint'
    BRANCH = 'branch'

@dataclass(frozen=True)
class ProgramContract:
    name: str
    preconditions: tuple[str, ...] = ()
    postconditions: tuple[str, ...] = ()
    max_steps: int = 128
    max_frontier_calls: int = 0
    allow_network: bool = False
    tags: tuple[str, ...] = ()

@dataclass(frozen=True)
class AgentNode:
    node_id: str
    kind: NodeKind
    action: str
    deps: tuple[str, ...] = ()
    args: Mapping[str, Any] = field(default_factory=dict)
    cost_usd: float = 0.0
    latency_ms: float = 0.0
    frontier: bool = False
    deterministic: bool = True
    verifier: bool = False
    parallel_safe: bool = False

@dataclass(frozen=True)
class AgentProgram:
    contract: ProgramContract
    nodes: tuple[AgentNode, ...]
    provenance: Mapping[str, Any] = field(default_factory=dict)

    @property
    def digest(self) -> str:
        payload = {'contract': asdict(self.contract), 'nodes': [asdict(n) for n in self.nodes], 'provenance': dict(self.provenance)}
        return sha256(json.dumps(payload, sort_keys=True, default=str, separators=(',', ':')).encode()).hexdigest()

    def validate(self) -> tuple[bool, str]:
        ids = {n.node_id for n in self.nodes}
        if len(ids) != len(self.nodes):
            return False, 'duplicate node id'
        if len(self.nodes) > self.contract.max_steps:
            return False, 'step budget exceeded'
        if sum(1 for n in self.nodes if n.frontier) > self.contract.max_frontier_calls:
            return False, 'frontier budget exceeded'
        for n in self.nodes:
            if any(d not in ids for d in n.deps):
                return False, f'missing dependency for {n.node_id}'
            if n.frontier and not self.contract.allow_network:
                return False, f'frontier node not permitted: {n.node_id}'
        # DAG check.
        indeg = {n.node_id: 0 for n in self.nodes}
        succ = {n.node_id: [] for n in self.nodes}
        for n in self.nodes:
            for d in n.deps:
                indeg[n.node_id] += 1
                succ[d].append(n.node_id)
        q = [k for k,v in indeg.items() if v == 0]
        seen = 0
        while q:
            x = q.pop()
            seen += 1
            for y in succ[x]:
                indeg[y] -= 1
                if indeg[y] == 0:
                    q.append(y)
        if seen != len(self.nodes):
            return False, 'cycle detected'
        return True, 'ok'

    def waves(self) -> tuple[tuple[str, ...], ...]:
        ok, reason = self.validate()
        if not ok:
            raise ValueError(reason)
        done: set[str] = set()
        remaining = {n.node_id: n for n in self.nodes}
        waves: list[tuple[str, ...]] = []
        while remaining:
            ready = tuple(sorted(k for k,n in remaining.items() if set(n.deps) <= done))
            if not ready:
                raise ValueError('unreachable cycle')
            waves.append(ready)
            done.update(ready)
            for k in ready:
                remaining.pop(k)
        return tuple(waves)

    def economics(self) -> dict[str, float]:
        latency = sum(n.latency_ms for n in self.nodes)
        cost = sum(n.cost_usd for n in self.nodes)
        critical = 0.0
        end_at: dict[str,float] = {}
        for wave in self.waves():
            w = max((next(n.latency_ms for n in self.nodes if n.node_id == nid) for nid in wave), default=0.0)
            critical += w
            for nid in wave: end_at[nid] = critical
        frontier = sum(1 for n in self.nodes if n.frontier)
        deterministic = sum(1 for n in self.nodes if n.deterministic)
        return {
            'serial_latency_ms': latency,
            'critical_path_ms': critical,
            'parallel_speedup': latency / max(critical, 1e-9),
            'cost_usd': cost,
            'frontier_calls': float(frontier),
            'deterministic_fraction': deterministic / max(1, len(self.nodes)),
        }
