from __future__ import annotations
from dataclasses import dataclass
from time import perf_counter
from typing import Any, Callable, Mapping
from concurrent.futures import ThreadPoolExecutor
from .ir import AgentProgram

@dataclass(frozen=True)
class RuntimeResult:
    success: bool
    state: Mapping[str, Any]
    outputs: Mapping[str, Any]
    failed_node: str | None
    frontier_calls: int
    latency_ms: float
    cost_usd: float
    recovery_count: int
    verified: bool
    reason: str = ''

class AgentRuntime:
    """Local-first runtime for AgentProgram. Handlers are explicit and untrusted nodes are denied."""
    def __init__(self, handlers: Mapping[str, Callable[..., Any]], *, unit_cost_usd: float = 1e-7):
        self.handlers = dict(handlers)
        self.unit_cost_usd = unit_cost_usd
        self._checkpoints: dict[str, dict[str, Any]] = {}
        self._compiled: dict[str, tuple[tuple[tuple[str, ...], ...], dict[str, Any]]] = {}
        self._pool = ThreadPoolExecutor(max_workers=16)

    def run(self, program: AgentProgram, state: Mapping[str, Any] | None = None, *, recovery: bool = True) -> RuntimeResult:
        compiled = self._compiled.get(program.digest)
        if compiled is None:
            ok, reason = program.validate()
            if not ok:
                return RuntimeResult(False, dict(state or {}), {}, None, 0, 0.0, 0.0, 0, False, reason)
            cached_waves = program.waves()
            node_map = {n.node_id: n for n in program.nodes}
            compiled = (cached_waves, node_map)
            self._compiled[program.digest] = compiled
        cached_waves, node_map = compiled
        cur = dict(state or {})
        out: dict[str, Any] = {}
        frontier = 0
        recoveries = 0
        completed: set[str] = set()
        start = perf_counter()
        try:
            for wave_i, wave in enumerate(cached_waves):
                snapshot = dict(cur)
                self._checkpoints[f'{program.digest}:{wave_i}'] = snapshot
                nodes = [node_map[nid] for nid in wave]
                if len(nodes) > 1 and all(n.parallel_safe for n in nodes):
                    def run_node(node):
                        fn = self.handlers.get(node.action)
                        if fn is None:
                            raise KeyError(f'missing handler {node.action!r}')
                        return node, fn(cur, **dict(node.args))
                    results = list(self._pool.map(run_node, nodes))
                    for node, value in results:
                        if node.frontier:
                            frontier += 1
                        out[node.node_id] = value
                        completed.add(node.node_id)
                else:
                    for node in nodes:
                        fn = self.handlers.get(node.action)
                        if fn is None:
                            raise KeyError(f'missing handler {node.action!r}')
                        if node.frontier:
                            frontier += 1
                        value = fn(cur, **dict(node.args))
                        out[node.node_id] = value
                        completed.add(node.node_id)
                # explicit verification nodes can assert state via handler result.
            verified = True
            for expr in program.contract.postconditions:
                key, expected = self._parse_eq(expr)
                if cur.get(key) != expected:
                    raise AssertionError(f'postcondition failed: {expr}')
        except Exception as exc:
            if recovery and completed:
                # Roll back only the current wave then allow callers to replan externally.
                cur = dict(self._checkpoints.get(f'{program.digest}:{max(0, len(completed)-1)}', cur))
                recoveries = 1
            elapsed = (perf_counter() - start) * 1000
            return RuntimeResult(False, cur, out, next((n.node_id for n in program.nodes if n.node_id not in completed), None), frontier, elapsed, frontier*self.unit_cost_usd, recoveries, False, str(exc))
        elapsed = (perf_counter() - start) * 1000
        return RuntimeResult(True, cur, out, None, frontier, elapsed, frontier*self.unit_cost_usd, recoveries, verified)

    @staticmethod
    def _parse_eq(expr: str) -> tuple[str, Any]:
        if '==' not in expr:
            raise ValueError(f'unsupported contract expression {expr!r}')
        key, raw = expr.split('==', 1)
        raw = raw.strip().strip('"\'')
        if raw.lower() == 'true': val = True
        elif raw.lower() == 'false': val = False
        else:
            try: val = int(raw)
            except ValueError: val = raw
        return key.strip(), val

    def close(self) -> None:
        self._pool.shutdown(wait=True, cancel_futures=True)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False
