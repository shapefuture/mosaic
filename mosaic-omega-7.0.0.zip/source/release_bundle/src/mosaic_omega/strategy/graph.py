from __future__ import annotations

from dataclasses import dataclass
from collections import defaultdict
from typing import Iterable

from ..trajectory.events import Trajectory, TrajectoryEvent, classify_event


@dataclass(frozen=True)
class StrategyTransition:
    source: str
    action: str
    target: str
    count: int
    successes: int
    failures: int
    total_latency_ms: float
    total_cost_usd: float

    @property
    def success_rate(self) -> float:
        return self.successes / max(1, self.successes + self.failures)

    @property
    def mean_latency_ms(self) -> float:
        return self.total_latency_ms / max(1, self.count)

    @property
    def mean_cost_usd(self) -> float:
        return self.total_cost_usd / max(1, self.count)


class StrategyGraph:
    def __init__(self) -> None:
        self._stats: dict[tuple[str, str, str], list[float]] = defaultdict(lambda: [0, 0, 0, 0.0, 0.0])

    @staticmethod
    def _state(event: TrajectoryEvent) -> str:
        if event.state_hash:
            return event.state_hash[:12]
        return event.kind

    def ingest(self, traj: Trajectory) -> None:
        prev = "START"
        for event in traj.events:
            target = self._state(event)
            key = (prev, event.action, target)
            stats = self._stats[key]
            stats[0] += 1
            if event.ok is True:
                stats[1] += 1
            elif event.ok is False:
                stats[2] += 1
            stats[3] += event.latency_ms
            stats[4] += event.cost_usd
            prev = target

    def best_action(self, state: str, actions: Iterable[str], max_cost: float | None = None) -> str | None:
        candidates: list[tuple[float, str]] = []
        for (src, action, _), stats in self._stats.items():
            if src != state or action not in actions:
                continue
            count, succ, fail, latency, cost = stats
            rate = succ / max(1, succ + fail)
            mean_cost = cost / max(1, count)
            if max_cost is not None and mean_cost > max_cost:
                continue
            utility = rate / (1.0 + latency / 1000.0 + 1000.0 * mean_cost)
            candidates.append((utility, action))
        return max(candidates)[1] if candidates else None

    def transitions(self) -> tuple[StrategyTransition, ...]:
        out = []
        for (src, action, target), stats in self._stats.items():
            count, succ, fail, latency, cost = stats
            out.append(StrategyTransition(src, action, target, int(count), int(succ), int(fail), latency, cost))
        return tuple(sorted(out, key=lambda x: (x.source, x.action, x.target)))
