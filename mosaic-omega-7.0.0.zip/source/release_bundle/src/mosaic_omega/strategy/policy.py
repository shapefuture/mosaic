from __future__ import annotations

from dataclasses import dataclass
from .graph import StrategyGraph


@dataclass(frozen=True)
class StrategyDecision:
    state: str
    action: str
    expected_success: float
    expected_latency_ms: float
    expected_cost_usd: float


def recommend(graph: StrategyGraph, state: str, actions: tuple[str, ...], max_cost: float | None = None) -> StrategyDecision | None:
    action = graph.best_action(state, actions, max_cost=max_cost)
    if action is None:
        return None
    for t in graph.transitions():
        if t.source == state and t.action == action:
            return StrategyDecision(state, action, t.success_rate, t.mean_latency_ms, t.mean_cost_usd)
    return None
