"""MOSAIC Ω reference substrate."""

from .model import ComputeSpec, Genome, Candidate, Observation

__all__ = ["ComputeSpec", "Genome", "Candidate", "Observation"]
__version__ = "6.0.0"

from .runtime.result_cache import ResultCache

from .evidence import EER, EERBuilder
from .trajectory import Trajectory, TrajectoryEvent, analyze_trajectory
from .context import ContextCompiler
from .strategy import StrategyGraph

__all__ += ["EER", "EERBuilder", "Trajectory", "TrajectoryEvent", "analyze_trajectory", "ContextCompiler", "StrategyGraph"]

from .ecu import ECUAction, ECUContract, ECUEnvironment, ExecutableComputeUnit, distill_ecus, verify_ecu
from .data import DatasetManifest, TRAINING_MANIFESTS, ANALYSIS_MANIFESTS, SEALED_EVAL_MANIFESTS
__all__ += ["ECUAction","ECUContract","ECUEnvironment","ExecutableComputeUnit","distill_ecus","verify_ecu","DatasetManifest","TRAINING_MANIFESTS","ANALYSIS_MANIFESTS","SEALED_EVAL_MANIFESTS"]

from .learning import PolicyDecision, TrajectoryPolicy, Motif, mine_motifs, compile_motifs_to_ecus, TrainingReport, train_from_trajectories
from .sources import DEFAULT_SOURCES, RemoteSourceConfig
__all__ += ["PolicyDecision", "TrajectoryPolicy", "Motif", "mine_motifs", "compile_motifs_to_ecus", "TrainingReport", "train_from_trajectories", "DEFAULT_SOURCES", "RemoteSourceConfig"]

from .omega.recursive import ProofPlan, RecursiveUnit, RecursiveUnitRegistry, DecompositionVerifier, AdaptiveVerifier, RecursiveExecutor
__all__ += ["ProofPlan","RecursiveUnit","RecursiveUnitRegistry","DecompositionVerifier","AdaptiveVerifier","RecursiveExecutor"]

from .frontier import FrontierSnapshot, ReplayMetrics, Comparison, TOOLATHLON_VERIFIED_AUG_2026
__all__ += ["FrontierSnapshot", "ReplayMetrics", "Comparison", "TOOLATHLON_VERIFIED_AUG_2026"]

from .data.github_trajectories import GitHubTraceSpec, GITHUB_TRACE_SOURCES, iter_local_github_trace, iter_remote_github_trace, audit_trace
__all__ += ["GitHubTraceSpec", "GITHUB_TRACE_SOURCES", "iter_local_github_trace", "iter_remote_github_trace", "audit_trace"]

from .learning.recovery import RecoveryRule, mine_recovery_rules, compile_recovery_rules
__all__ += ["RecoveryRule", "mine_recovery_rules", "compile_recovery_rules"]
from .data.git_sources import GitAddressableSource, GIT_ADDRESSABLE_SOURCES, manifest_digest
from .data.remote_trajectories import GitBlobIntegrityError, iter_source_trajectories
from .learning.recovery_program import RecoveryProgram, compile_cross_source_recovery
__all__ += ["GitAddressableSource","GIT_ADDRESSABLE_SOURCES","manifest_digest","GitBlobIntegrityError","iter_source_trajectories","RecoveryProgram","compile_cross_source_recovery"]

from .learning.multiview import MultiViewReport, ViewArtifact, train_multiview
__all__ += ["MultiViewReport", "ViewArtifact", "train_multiview"]

from .experience import CausalEdge, EvidenceNode, ExperienceCandidate, ExperienceCompiler, ExperienceMemory, ExperiencePatch, PromotionDecision, SixViewReport
__all__ += ["CausalEdge","EvidenceNode","ExperienceCandidate","ExperienceCompiler","ExperienceMemory","ExperiencePatch","PromotionDecision","SixViewReport"]

from .network import *

from .cloud import (StateHandle, StateStore, TenantState, TenantKernel, TenantPolicy, TenantQuota, TenantAuth,
                    ExecutionCell, ExecutionTier, SandboxPolicy, SandboxPolicyCompiler, ExecutionFabric,
                    StatelessMCPGateway, MCPRequest, MCPResponse)
__all__ += ["StateHandle","StateStore","TenantState","TenantKernel","TenantPolicy","TenantQuota","TenantAuth",
            "ExecutionCell","ExecutionTier","SandboxPolicy","SandboxPolicyCompiler","ExecutionFabric",
            "StatelessMCPGateway","MCPRequest","MCPResponse"]
