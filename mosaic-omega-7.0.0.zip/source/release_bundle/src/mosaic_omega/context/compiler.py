from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
import re
from typing import Iterable


@dataclass(frozen=True)
class ContextChunk:
    text: str
    score: float
    source_steps: tuple[int, ...] = ()


@dataclass(frozen=True)
class ContextDocument:
    original_tokens: int
    compiled_tokens: int
    chunks: tuple[ContextChunk, ...]
    digest: str


class ContextCompiler:
    """Deterministic, model-agnostic context compiler.

    It performs cheap transformations first: whitespace normalization, exact line
    deduplication, stable truncation, and task-keyword relevance scoring.
    """

    def __init__(self, max_chars: int = 12000):
        self.max_chars = max_chars

    @staticmethod
    def _tokens(text: str) -> int:
        return max(1, len(re.findall(r"\w+|[^\w\s]", text))) if text else 0

    def compile(self, text: str, query: str = "") -> ContextDocument:
        lines = [re.sub(r"\s+", " ", ln).strip() for ln in text.splitlines()]
        seen: set[str] = set()
        unique: list[str] = []
        for ln in lines:
            if not ln or ln in seen:
                continue
            seen.add(ln)
            unique.append(ln)
        terms = {t.lower() for t in re.findall(r"[A-Za-z0-9_]{3,}", query)}
        protected_markers = ("safety", "security", "must ", "never ", "do not", "deny", "forbid", "policy", "constraint")
        scored = []
        for i, ln in enumerate(unique):
            words = {t.lower() for t in re.findall(r"[A-Za-z0-9_]{3,}", ln)}
            protected = any(m in ln.lower() for m in protected_markers)
            score = (100.0 if protected else 1.0) + 2.0 * len(words & terms) / max(1, len(terms))
            scored.append((score, i, ln))
        scored.sort(key=lambda x: (-x[0], x[1]))
        chunks: list[ContextChunk] = []
        used = 0
        for score, i, ln in scored:
            cost = len(ln) + 1
            if used + cost > self.max_chars:
                continue
            chunks.append(ContextChunk(ln, score, (i,)))
            used += cost
        chunks.sort(key=lambda c: c.source_steps[0])
        compiled = "\n".join(c.text for c in chunks)
        return ContextDocument(self._tokens(text), self._tokens(compiled), tuple(chunks), sha256(compiled.encode()).hexdigest())
