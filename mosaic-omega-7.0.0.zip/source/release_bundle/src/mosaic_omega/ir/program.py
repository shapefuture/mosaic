from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from typing import Any

from .nodes import Node


def node_to_dict(node: Node) -> dict[str, Any]:
    if node.op == "const":
        return {"op": node.op, "value": node.value}  # type: ignore[attr-defined]
    if node.op == "input":
        return {"op": node.op, "index": node.index}  # type: ignore[attr-defined]
    return {"op": node.op, "children": [node_to_dict(x) for x in node.children()]}


@dataclass(frozen=True)
class Program:
    name: str
    root: Node
    effects: frozenset[str] = frozenset()

    @property
    def digest(self) -> str:
        payload = json.dumps(
            {"name": self.name, "root": node_to_dict(self.root), "effects": sorted(self.effects)},
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
        return sha256(payload).hexdigest()
