from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence


class Node:
    op: str

    def children(self) -> Sequence["Node"]:
        return ()


@dataclass(frozen=True)
class Const(Node):
    value: float
    op: str = "const"


@dataclass(frozen=True)
class Input(Node):
    index: int = 0
    op: str = "input"


@dataclass(frozen=True)
class Add(Node):
    left: Node
    right: Node
    op: str = "add"

    def children(self):
        return (self.left, self.right)


@dataclass(frozen=True)
class Mul(Node):
    left: Node
    right: Node
    op: str = "mul"

    def children(self):
        return (self.left, self.right)


@dataclass(frozen=True)
class Neg(Node):
    value: Node
    op: str = "neg"

    def children(self):
        return (self.value,)


@dataclass(frozen=True)
class ReduceSum(Node):
    value: Node
    op: str = "reduce_sum"

    def children(self):
        return (self.value,)
