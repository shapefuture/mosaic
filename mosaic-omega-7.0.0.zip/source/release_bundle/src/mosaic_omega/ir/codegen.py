from __future__ import annotations

from .nodes import Add, Const, Input, Mul, Neg, Node, ReduceSum


def c_expr(node: Node, input_name: str = "x") -> str:
    if isinstance(node, Const):
        return repr(float(node.value))
    if isinstance(node, Input):
        if node.index != 0:
            raise ValueError("native elementwise codegen currently supports Input(0) only")
        return f"{input_name}[i]"
    if isinstance(node, Add):
        return f"({c_expr(node.left, input_name)} + {c_expr(node.right, input_name)})"
    if isinstance(node, Mul):
        return f"({c_expr(node.left, input_name)} * {c_expr(node.right, input_name)})"
    if isinstance(node, Neg):
        return f"(-{c_expr(node.value, input_name)})"
    if isinstance(node, ReduceSum):
        return c_expr(node.value, input_name)
    raise TypeError(f"unsupported native IR node: {type(node).__name__}")
