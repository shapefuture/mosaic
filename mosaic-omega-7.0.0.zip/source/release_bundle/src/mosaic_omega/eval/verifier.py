from __future__ import annotations

from ..model import Candidate, VerificationEvidence
from .reference import optimized_vector, reference_vector, values_close


def verify_candidate(candidate: Candidate, program, samples: list[list[float]]) -> VerificationEvidence:
    if candidate.spec.input_size < 1:
        return VerificationEvidence(False, "input_size must be positive")
    try:
        checked = 0
        for sample in samples:
            expected = reference_vector(program, sample)
            actual = optimized_vector(program, sample, candidate.genome)
            checked += len(sample)
            if not values_close(expected, actual):
                return VerificationEvidence(False, "semantic mismatch", checked)
        return VerificationEvidence(True, "reference equivalence passed", checked)
    except (TypeError, ValueError, IndexError, OverflowError) as exc:
        return VerificationEvidence(False, f"execution rejected: {type(exc).__name__}: {exc}", 0)
