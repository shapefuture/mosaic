from __future__ import annotations

import hashlib
import random

from ..model import Candidate, Observation
from .reference import benchmark
from .verifier import verify_candidate


class MultiFidelityEvaluator:
    def __init__(self, seed: int = 7):
        self.rng = random.Random(seed)

    def _samples(self, candidate: Candidate, n: int) -> list[list[float]]:
        seed = int(hashlib.sha256(candidate.genome_id.encode()).hexdigest()[:12], 16)
        rng = random.Random(seed)
        return [[rng.uniform(-2, 2) for _ in range(max(1, candidate.spec.input_size))] for _ in range(n)]

    def evaluate(self, candidate: Candidate, program, fidelity: int = 0) -> Observation:
        n = (fidelity + 1) * 2
        samples = self._samples(candidate, n)
        evidence = verify_candidate(candidate, program, samples)
        if not evidence.passed:
            return Observation(candidate.genome_id, fidelity, float("inf"), float("inf"), 0, False, evidence, self.features(candidate), candidate.spec.target, evidence.message)
        x = samples[0]
        repeats = max(1, 4 - fidelity)
        latency, memory = benchmark(program, candidate.genome, x, repeats=repeats)
        energy = latency * 0.02 * (1.0 + 0.01 * candidate.genome.pipeline)
        return Observation(candidate.genome_id, fidelity, latency, energy, memory, True, evidence, self.features(candidate), candidate.spec.target, "verified")

    @staticmethod
    def features(candidate: Candidate) -> tuple[float, ...]:
        g = candidate.genome
        return (float(g.tile), float(g.unroll), float(g.vector_width), float(g.pipeline), float(g.split))
