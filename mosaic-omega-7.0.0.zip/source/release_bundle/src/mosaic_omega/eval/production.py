from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Sequence

from ..backends import LLVMBackend, NativeCPUBackend, OptionalGPUBackend
from ..model import Candidate, Observation, VerificationEvidence, ComputeSpec, ResourceBudget
from ..profiling.host import HostProfile, profile_host
from ..runtime.cost import CostPoint
from ..security.policy import ExecutionPolicy, authorize
from ..evidence import EERBuilder, EER
from ..trajectory import Trajectory, TrajectoryEvent, analyze_trajectory
from .reference import reference_vector, values_close


@dataclass(frozen=True)
class ProductionConfig:
    cpu_hourly_usd: float = 0.30
    gpu_hourly_usd: float = 1.50
    cpu_watts: float = 75.0
    gpu_watts: float = 250.0
    repeats: int = 5
    verify_samples: int = 3


class ProductionEvaluator:
    """Real native/LLVM evaluation with correctness gates and measurable economics."""

    def __init__(self, config: ProductionConfig | None = None, host: HostProfile | None = None):
        self.config = config or ProductionConfig()
        self.host = host or profile_host()
        self.native = NativeCPUBackend()
        self.llvm = LLVMBackend() if self.host.llvm_available else None
        self.gpu_backends = [OptionalGPUBackend("cuda"), OptionalGPUBackend("rocm")]

    def _samples(self, candidate: Candidate) -> list[list[float]]:
        import hashlib, random
        seed = int(hashlib.sha256(candidate.genome_id.encode()).hexdigest()[:12], 16)
        rng = random.Random(seed)
        return [[rng.uniform(-2, 2) for _ in range(max(1, candidate.spec.input_size))] for _ in range(self.config.verify_samples)]

    def evaluate_cpu(self, candidate: Candidate, program, backend: str = "native-cpu") -> Observation:
        policy = ExecutionPolicy(allowed_targets=frozenset({"native-cpu", "llvm-cpu", "reference-cpu"}))
        target_spec = candidate.spec
        target = "native-cpu" if backend == "native-cpu" else "llvm-cpu"
        canon = target_spec.canonical()
        canon["resource"] = ResourceBudget(**canon["resource"])
        candidate = Candidate(ComputeSpec(**{**canon, "target": target}), candidate.genome, candidate.source, candidate.lineage)
        ok, reason = authorize(candidate, policy)
        if not ok:
            return Observation(candidate.genome_id, 0, math.inf, math.inf, 0, False, VerificationEvidence(False, reason), (), target, reason, math.inf, backend)
        runner = self.native if backend == "native-cpu" else self.llvm
        if runner is None or not runner.capabilities.available:
            return Observation(candidate.genome_id, 0, math.inf, math.inf, 0, False, VerificationEvidence(False, f"{backend} unavailable"), (), target, "backend unavailable", math.inf, backend)
        samples = self._samples(candidate)
        try:
            artifact = runner.compile(program, candidate)
            checked = 0
            for sample in samples:
                expected = reference_vector(program, sample)
                actual = runner.run(artifact, sample)
                checked += len(sample)
                if not values_close(expected, actual, tol=1e-10):
                    return Observation(candidate.genome_id, 0, math.inf, math.inf, len(sample) * 8, False, VerificationEvidence(False, "native semantic mismatch", checked), (), target, "verification failed", math.inf, backend)
            x = samples[0]
            runner.run(artifact, x)  # warm-up
            t0 = time.perf_counter_ns()
            result = ()
            for _ in range(max(1, self.config.repeats)):
                result = runner.run(artifact, x)
            latency_ms = (time.perf_counter_ns() - t0) / 1e6 / max(1, self.config.repeats)
            point = CostPoint(self.config.cpu_hourly_usd, self.config.cpu_watts)
            cost = point.usd_for_ms(latency_ms)
            energy = point.energy_for_ms(latency_ms)
            features = (float(candidate.genome.tile), float(candidate.genome.unroll), float(candidate.genome.vector_width), float(candidate.genome.pipeline), float(candidate.genome.split))
            return Observation(candidate.genome_id, 0, latency_ms, energy, len(result) * 8, True, VerificationEvidence(True, f"{backend} verified", checked), features, target, "native benchmark", cost, backend)
        except Exception as exc:
            return Observation(candidate.genome_id, 0, math.inf, math.inf, 0, False, VerificationEvidence(False, f"{type(exc).__name__}: {exc}"), (), target, "backend error", math.inf, backend)

    def evaluate_cpu_with_evidence(self, candidate: Candidate, program, backend: str = "native-cpu") -> tuple[Observation, EER]:
        """Evaluate and emit a replay/audit-oriented Execution Evidence Record."""
        run_id = candidate.genome_id
        eer = EERBuilder(run_id, {"candidate": candidate.genome_id, "program": program.digest})
        eer.model.update({"model": "external-or-harness", "backend_policy": "cpu-first"})
        eer.scaffold.update({"evaluator": "ProductionEvaluator", "backend": backend})
        eer.environment.update({"host": self.host.cpu_model, "llvm_available": self.host.llvm_available})
        eer.event("authorize", {"backend": backend})
        obs = self.evaluate_cpu(candidate, program, backend=backend)
        eer.event("verify", {"passed": obs.correct, "checked_points": obs.verification.checked_points})
        eer.execution.update({"backend": obs.backend, "latency_ms": obs.latency_ms, "memory_bytes": obs.memory_bytes, "cost_usd": obs.cost_usd})
        eer.outcome.update({"correct": obs.correct, "reason": obs.reason})
        eer.evidence.update({"verification": obs.verification.message, "evidence_strength": "measured" if obs.correct else "failed"})
        if not obs.correct:
            traj = Trajectory(run_id, (
                TrajectoryEvent(0, "execute", backend, state_hash="candidate", ok=False, metadata={"failure_category": "evaluation_failure"}),
            ))
            failure = analyze_trajectory(traj)
            eer.execution.update({"decisive_failure_step": failure.decisive_step, "failure_category": failure.category})
        return obs, eer.build()

    def close(self) -> None:
        self.native.close()
        if self.llvm:
            self.llvm.close()
        for b in self.gpu_backends:
            b.close()
