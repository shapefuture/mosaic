from __future__ import annotations

import math
import time
from typing import Sequence

from ..ir.nodes import Add, Const, Input, Mul, Neg, Node, ReduceSum


def eval_node(node: Node, x: Sequence[float]) -> float | tuple[float, ...]:
    if isinstance(node, Const):
        return node.value
    if isinstance(node, Input):
        if node.index < 0 or node.index >= len(x):
            raise IndexError("input index out of bounds")
        return x[node.index]
    if isinstance(node, Add):
        return float(eval_node(node.left, x)) + float(eval_node(node.right, x))
    if isinstance(node, Mul):
        return float(eval_node(node.left, x)) * float(eval_node(node.right, x))
    if isinstance(node, Neg):
        return -float(eval_node(node.value, x))
    if isinstance(node, ReduceSum):
        value = eval_node(node.value, x)
        if isinstance(value, tuple):
            return sum(value)
        return value
    raise TypeError(f"unsupported IR node: {type(node).__name__}")


def reference_vector(program, x: Sequence[float]) -> tuple[float, ...]:
    # The restricted reference backend treats the IR root as an element-wise scalar expression.
    return tuple(float(eval_node(program.root, [value])) for value in x)


def optimized_vector(program, x: Sequence[float], genome) -> tuple[float, ...]:
    """Reference implementation: optimization parameters affect work partitioning, not semantics."""
    genome.validate()
    out = [0.0] * len(x)
    width = max(1, genome.vector_width)
    tile = max(1, genome.tile)
    for start in range(0, len(x), tile * width):
        for i in range(start, min(len(x), start + tile * width)):
            v = float(eval_node(program.root, [x[i]]))
            # Unroll/pipeline/split model scheduling only. Preserve exact semantics.
            out[i] = v
    return tuple(out)


def benchmark(program, genome, x: Sequence[float], repeats: int = 3) -> tuple[float, int]:
    start = time.perf_counter_ns()
    result = ()
    for _ in range(repeats):
        result = optimized_vector(program, x, genome)
    elapsed_ms = (time.perf_counter_ns() - start) / 1e6 / repeats
    memory = len(result) * 8
    return elapsed_ms, memory


def values_close(a: Sequence[float], b: Sequence[float], tol: float = 1e-12) -> bool:
    return len(a) == len(b) and all(math.isclose(x, y, rel_tol=tol, abs_tol=tol) for x, y in zip(a, b))
