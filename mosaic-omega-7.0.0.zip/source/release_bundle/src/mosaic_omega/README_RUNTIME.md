# Runtime policy

MOSAIC Ω uses an escalation ladder:

1. Reference interpreter for correctness.
2. Host-native CPU code (Clang/LLVM or GCC) with detected SIMD features.
3. LLVM/Clang-specific CPU lowering.
4. Optional remote CPU offers (integrated by the scheduler as external offers).
5. Optional sandboxed VM/AOT execution when workload trust requires stronger isolation.
6. CUDA/ROCm only when an authorized, verified GPU runtime exists **and** its predicted utility beats the best non-GPU option by the configured margin.

This is an economic policy, not a branding choice: the score includes latency, per-execution USD, energy and startup overhead. GPU has a configurable escalation barrier.
