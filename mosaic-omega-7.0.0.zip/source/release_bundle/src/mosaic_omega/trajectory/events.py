from __future__ import annotations

from dataclasses import asdict, dataclass, field
from hashlib import sha256
import json
from typing import Any, Mapping


@dataclass(frozen=True)
class TrajectoryEvent:
    step: int
    kind: str
    action: str
    observation: str = ""
    state_hash: str = ""
    ok: bool | None = None
    latency_ms: float = 0.0
    cost_usd: float = 0.0
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def canonical(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Trajectory:
    run_id: str
    events: tuple[TrajectoryEvent, ...]

    def canonical(self) -> dict[str, Any]:
        return {"run_id": self.run_id, "events": [e.canonical() for e in self.events]}


def classify_event(event: TrajectoryEvent) -> str:
    if event.ok is False:
        return "harmful"
    if event.kind in {"verify", "benchmark", "checkpoint", "recovery"}:
        return "productive"
    if event.kind in {"observe", "retrieve", "tool_result"} and event.ok is not False:
        return "neutral"
    return "productive" if event.ok else "neutral"


def trajectory_digest(traj: Trajectory) -> str:
    return sha256(json.dumps(traj.canonical(), sort_keys=True, separators=(",", ":")).encode()).hexdigest()
