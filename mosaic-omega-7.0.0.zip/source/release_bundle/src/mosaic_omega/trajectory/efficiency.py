from __future__ import annotations

from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Iterable

from .events import Trajectory, TrajectoryEvent


@dataclass(frozen=True)
class TrajectoryEfficiency:
    total_steps: int
    actionable_steps: int
    exact_duplicates: int
    semantic_duplicates: int
    backtracks: int
    dead_steps: int
    efficiency: float
    step_efficiency: float | None = None


def _key(event: TrajectoryEvent) -> str:
    obs = (event.observation or "").strip().lower()
    return f"{event.kind}:{event.action.strip().lower()}:{obs[:256]}"


def _similar(a: str, b: str) -> float:
    return SequenceMatcher(a=a, b=b).ratio()


def analyze_efficiency(traj: Trajectory, *, optimal_steps: int | None = None, similarity_threshold: float = 0.92) -> TrajectoryEfficiency:
    actionable = [e for e in traj.events if e.kind in {"tool_call", "select", "action", "compile", "retrieve", "http", "database"}]
    if not actionable:
        return TrajectoryEfficiency(len(traj.events), 0, 0, 0, 0, 0, 1.0, 1.0 if optimal_steps else None)

    keys = [_key(e) for e in actionable]
    seen: set[str] = set()
    exact = 0
    semantic = 0
    for k in keys:
        if k in seen:
            exact += 1
        seen.add(k)
    for i, a in enumerate(keys):
        for b in keys[i + 1 :]:
            sim = _similar(a, b)
            if similarity_threshold <= sim < 1.0:
                semantic += 1

    backtracks = 0
    for i, event in enumerate(traj.events[:-1]):
        if event.ok is False and traj.events[i + 1].kind in {"tool_call", "select", "action", "retrieve", "recovery"}:
            backtracks += 1

    dead_steps = sum(1 for e in actionable if e.metadata.get("dead_end") is True)
    redundant = exact + min(semantic, max(0, len(actionable) - exact - 1)) + dead_steps
    score = max(0.0, 1.0 - redundant / max(1, len(actionable)))
    step_eff = None if optimal_steps is None else min(1.0, optimal_steps / max(1, len(traj.events)))
    if step_eff is not None:
        score = (score + step_eff) / 2.0
    if backtracks:
        score = max(0.0, score - min(0.2, 0.05 * backtracks))
    return TrajectoryEfficiency(len(traj.events), len(actionable), exact, semantic, backtracks, dead_steps, score, step_eff)


def mean_efficiency(trajectories: Iterable[Trajectory]) -> float:
    vals = [analyze_efficiency(t).efficiency for t in trajectories]
    return sum(vals) / max(1, len(vals))
