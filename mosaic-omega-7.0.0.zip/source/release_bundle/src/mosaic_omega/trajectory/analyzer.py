from __future__ import annotations

from dataclasses import dataclass
from collections import Counter
from .events import Trajectory, TrajectoryEvent, classify_event


@dataclass(frozen=True)
class FailureAttribution:
    decisive_step: int | None
    category: str
    confidence: float
    recovery_step: int | None = None


def analyze_trajectory(traj: Trajectory) -> FailureAttribution:
    first_bad = next((e for e in traj.events if e.ok is False), None)
    if first_bad is None:
        return FailureAttribution(None, "none", 1.0, None)
    category = str(first_bad.metadata.get("failure_category", "execution_error"))
    recovery = next((e.step for e in traj.events if e.step > first_bad.step and e.kind == "recovery" and e.ok is True), None)
    # Confidence is deterministic and intentionally conservative; downstream judges can replace it.
    later_failures = sum(1 for e in traj.events if e.step > first_bad.step and e.ok is False)
    confidence = 0.95 if later_failures else 0.80
    return FailureAttribution(first_bad.step, category, confidence, recovery)
