from __future__ import annotations

from dataclasses import dataclass

from ..model import Observation, Candidate


@dataclass(frozen=True)
class Archived:
    candidate: Candidate
    observation: Observation


def dominates(a: Observation, b: Observation) -> bool:
    if not a.correct or not b.correct:
        return a.correct and not b.correct
    no_worse = a.latency_ms <= b.latency_ms and a.energy_j <= b.energy_j and a.memory_bytes <= b.memory_bytes
    strictly = a.latency_ms < b.latency_ms or a.energy_j < b.energy_j or a.memory_bytes < b.memory_bytes
    return no_worse and strictly


class ParetoArchive:
    def __init__(self) -> None:
        self._items: dict[str, Archived] = {}

    def add(self, item: Archived) -> bool:
        if any(dominates(other.observation, item.observation) for other in self._items.values()):
            return False
        dead = [key for key, other in self._items.items() if dominates(item.observation, other.observation)]
        for key in dead:
            del self._items[key]
        self._items[item.candidate.genome_id] = item
        return True

    def items(self) -> tuple[Archived, ...]:
        return tuple(self._items.values())


class MAPElitesArchive:
    def __init__(self) -> None:
        self._cells: dict[tuple[int, int], Archived] = {}

    @staticmethod
    def key(item: Archived) -> tuple[int, int]:
        g = item.candidate.genome
        return (min(g.vector_width, 16), min(g.tile // 4, 8))

    def add(self, item: Archived) -> bool:
        k = self.key(item)
        old = self._cells.get(k)
        if old is None or item.observation.latency_ms < old.observation.latency_ms:
            self._cells[k] = item
            return True
        return False

    def items(self) -> tuple[Archived, ...]:
        return tuple(self._cells.values())
