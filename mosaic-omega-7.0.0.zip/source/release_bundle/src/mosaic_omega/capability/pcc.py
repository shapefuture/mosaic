from __future__ import annotations
from dataclasses import dataclass, field, asdict
from hashlib import sha256
import json
from typing import Mapping, Sequence

@dataclass(frozen=True)
class ProofCarryingCapability:
    name: str
    description: str
    preconditions: tuple[str, ...]
    postconditions: tuple[str, ...]
    implementation_digest: str
    verifier_digest: str
    lineage: tuple[str, ...] = ()
    counterexamples: tuple[str, ...] = ()
    cost_usd: float = 0.0
    latency_ms: float = 0.0
    applicability: float = 1.0
    provenance: Mapping[str, str] = field(default_factory=dict)

    @property
    def digest(self) -> str:
        blob = json.dumps(asdict(self), sort_keys=True, separators=(",", ":"))
        return sha256(blob.encode()).hexdigest()

    def to_dict(self) -> dict:
        d = asdict(self)
        d["digest"] = self.digest
        return d

@dataclass(frozen=True)
class CapabilityPatch:
    parent_digest: str
    child_digest: str
    changed_preconditions: tuple[str, ...] = ()
    changed_postconditions: tuple[str, ...] = ()
    cost_delta_usd: float = 0.0
    latency_delta_ms: float = 0.0
    quality_delta: float = 0.0
    regression_count: int = 0

    @property
    def improvement(self) -> float:
        return self.quality_delta - 0.01 * max(0.0, self.latency_delta_ms) - 0.1 * max(0.0, self.cost_delta_usd) - self.regression_count
