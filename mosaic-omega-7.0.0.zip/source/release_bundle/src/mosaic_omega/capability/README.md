# Proof-Carrying Capability
A capability is a versioned executable contract with verifier, evidence, lineage, counterexamples and economics.
