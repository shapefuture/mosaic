from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Any


@dataclass(frozen=True)
class GitAddressableSource:
    source_id: str
    repository: str
    path: str
    raw_url: str
    blob_sha: str
    bytes: int
    format: str
    corpus_class: str
    trajectory_count: int | None = None
    license: str = "unknown"
    status: str = "verified"
    notes: str = ""

    @property
    def digest(self) -> str:
        return hashlib.sha256(json.dumps(asdict(self), sort_keys=True, separators=(",", ":")).encode()).hexdigest()

    def as_dict(self) -> dict[str, Any]:
        out = asdict(self)
        out["digest"] = self.digest
        return out


# Verified Git-addressable payloads discovered by the 2026-08-22 frontier sweep.
# We distinguish executable-agent behavior, structured reasoning/casual traces,
# and instrumentation/tooling so MOSAIC does not contaminate the behavior bank
# with documentation or hidden reasoning.
GIT_ADDRESSABLE_SOURCES: tuple[GitAddressableSource, ...] = (
    GitAddressableSource(
        source_id="claude-hard-task-135-calls",
        repository="when2buy/llm-trajectory-data",
        path="docs/hard-task-traces/all_haiku.trace.jsonl",
        raw_url="https://raw.githubusercontent.com/when2buy/llm-trajectory-data/main/docs/hard-task-traces/all_haiku.trace.jsonl",
        blob_sha="6d24773c1303911ea2cfe065524797de502382fc",
        bytes=123453,
        format="jsonl.claude-agent",
        corpus_class="agent-behavior",
        trajectory_count=1,
        license="MIT repository; respect source/data terms",
        notes="Observable tool-call/error/usage trace. Do not ingest hidden/private reasoning; use explicit reasoning signals when publicly provided.",
    ),
    GitAddressableSource(
        source_id="swe-bench-expanded-trajectory",
        repository="blueberrycongee/swe-bench-trajectories",
        path="lite_all_expanded.json",
        raw_url="https://raw.githubusercontent.com/blueberrycongee/swe-bench-trajectories/main/lite_all_expanded.json",
        blob_sha="c48a6555ac13f8f00f18ad42e1c9713eb975ec72",
        bytes=971957,
        format="json.swe-bench-expanded",
        corpus_class="agent-behavior",
        trajectory_count=None,
        license="source repository terms",
        notes="Ground-truth trajectories contain explicit thought fields; MOSAIC extracts structured reasoning signals and keeps raw thought opt-in only.",
    ),
    GitAddressableSource(
        source_id="vc-traces-18950",
        repository="valence-labs/VC-TRACES",
        path="data/vc_traces.parquet",
        raw_url="https://raw.githubusercontent.com/valence-labs/VC-TRACES/main/data/vc_traces.parquet",
        blob_sha="48980700e8d041d81d724cd8ab417ef2645a9f4b",
        bytes=82653737,
        format="parquet.vc-traces",
        corpus_class="causal-reasoning-transfer",
        trajectory_count=18950,
        license="source repository terms",
        notes="Structured mechanistic traces with verified explanations and causal DAGs. Used for far-transfer causal decomposition, not coding-agent imitation.",
    ),
    GitAddressableSource(
        source_id="longtracer-qwen-test",
        repository="THU-KEG/LongTraceRL",
        path="data/test/aa_lcr.jsonl",
        raw_url="https://raw.githubusercontent.com/THU-KEG/LongTraceRL/main/data/test/aa_lcr.jsonl",
        blob_sha="c194e69fee5f6a0e7cae8e64e778898ad6ebed1d",
        bytes=42607966,
        format="jsonl.long-trace-rl",
        corpus_class="long-horizon-reasoning",
        trajectory_count=None,
        license="source repository terms",
        notes="Long-horizon reasoning corpus; retained as a transfer/evaluation source, not a direct coding-tool behavior source.",
    ),
    # Source repositories verified during the sweep but without raw behavior blobs:
    GitAddressableSource(
        source_id="mimo-claude-code-traces-1k-metadata",
        repository="choucisan/mimo-claude-code-traces-1k",
        path="README.md",
        raw_url="https://raw.githubusercontent.com/choucisan/mimo-claude-code-traces-1k/main/README.md",
        blob_sha="0a35209b3b24c0d55985e060e29497366929b058",
        bytes=12007,
        format="markdown.metadata",
        corpus_class="metadata-only",
        license="MIT",
        status="metadata-only",
        notes="README reports 1,017 complete trajectories; payload is not stored as Git objects in this repository.",
    ),
    GitAddressableSource(
        source_id="open-agent-traces-instrumentation",
        repository="christinetyip/open-agent-traces",
        path="src/collect.ts",
        raw_url="https://raw.githubusercontent.com/christinetyip/open-agent-traces/main/src/collect.ts",
        blob_sha="132a516883eb7fcf7c931a5ab9175dd88178a703",
        bytes=12491,
        format="typescript.instrumentation",
        corpus_class="instrumentation",
        license="source repository terms",
        status="tooling-only",
        notes="Trace collection/publishing implementation; useful for interoperable provenance and capture, not a training payload.",
    ),
    GitAddressableSource(
        source_id="terminaltraj-license-map",
        repository="multimodal-art-projection/TerminalTraj",
        path="source/repo&license.jsonl",
        raw_url="https://raw.githubusercontent.com/multimodal-art-projection/TerminalTraj/main/source/repo%26license.jsonl",
        blob_sha="b0e7caf98217865bd46970e56852ba987babe477",
        bytes=186046,
        format="jsonl.license-map",
        corpus_class="metadata-only",
        license="source repository terms",
        status="metadata-only",
        notes="Repository tree contains license mapping, not terminal trajectory payloads.",
    ),
)


def source_manifest() -> list[dict[str, Any]]:
    return [s.as_dict() for s in GIT_ADDRESSABLE_SOURCES]


def manifest_digest() -> str:
    payload = json.dumps(source_manifest(), sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()
