from __future__ import annotations

import io
import json
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping

from ..trajectory.events import Trajectory, TrajectoryEvent
from .reasoning_trace import extract_reasoning_signals
from .inspect_logs import iter_inspect_trajectories
from .frontier import orchard_row_to_event_dict, gpt56_row_to_event_dict


def _txt(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return " ".join(_txt(v.get("text", v) if isinstance(v, Mapping) else v) for v in value)
    if isinstance(value, Mapping):
        return json.dumps(value, sort_keys=True, separators=(",", ":"))
    return str(value)


def from_atif(obj: Mapping[str, Any], *, ingest_reasoning: bool = True, retain_raw_reasoning: bool = False) -> Iterator[Trajectory]:
    """Read ATIF-like step arrays into normalized trajectories."""
    traces = obj.get("trajectories") if isinstance(obj.get("trajectories"), list) else [obj]
    for idx, trace in enumerate(traces):
        if not isinstance(trace, Mapping):
            continue
        steps = trace.get("steps") or trace.get("trajectory") or trace.get("events") or []
        events = []
        for i, step in enumerate(steps if isinstance(steps, list) else []):
            if not isinstance(step, Mapping):
                continue
            tool = step.get("tool_call") or step.get("action") or {}
            if isinstance(tool, Mapping):
                action = tool.get("name") or tool.get("tool") or step.get("type") or "action"
                observation = tool.get("arguments") or step.get("observation") or step.get("result") or ""
            else:
                action = step.get("type") or "action"
                observation = step.get("observation") or step.get("result") or ""
            raw_reasoning = step.get("thought") or step.get("reasoning") or step.get("analysis") or ""
            reasoning = extract_reasoning_signals(str(raw_reasoning), turn=int(step.get("turn") or i)) if ingest_reasoning else None
            metadata = dict(step.get("metadata") or {})
            if reasoning:
                metadata["reasoning_signals"] = reasoning.as_dict()
                if retain_raw_reasoning:
                    metadata["raw_reasoning"] = str(raw_reasoning)[:12000]
            events.append(TrajectoryEvent(
                i,
                str(step.get("type") or "action").lower(),
                str(action),
                _txt(observation)[:4000],
                str(step.get("state_hash") or step.get("state") or ""),
                step.get("ok"),
                float(step.get("latency_ms", 0.0) or 0.0),
                float(step.get("cost_usd", 0.0) or 0.0),
                metadata,
            ))
        yield Trajectory(str(trace.get("trajectory_id") or trace.get("run_id") or f"atif-{idx}"), tuple(events))


def from_otel(obj: Mapping[str, Any]) -> Iterator[Trajectory]:
    """Read OpenTelemetry JSON spans into normalized trajectories."""
    spans = obj.get("spans") or obj.get("resourceSpans") or []
    if isinstance(spans, list) and spans and isinstance(spans[0], Mapping) and "scopeSpans" in spans[0]:
        flattened = []
        for rs in spans:
            for ss in rs.get("scopeSpans", []):
                flattened.extend(ss.get("spans", []))
        spans = flattened
    groups: dict[str, list[Mapping[str, Any]]] = {}
    for span in spans if isinstance(spans, list) else []:
        if not isinstance(span, Mapping):
            continue
        attrs = span.get("attributes") or span.get("attributesMap") or {}
        if isinstance(attrs, list):
            attrs = {a.get("key"): a.get("value") for a in attrs if isinstance(a, Mapping)}
        trace_id = str(span.get("traceId") or attrs.get("trace_id") or "default")
        groups.setdefault(trace_id, []).append(span)
    for trace_id, items in groups.items():
        items.sort(key=lambda s: str(s.get("startTimeUnixNano", s.get("start_time", ""))))
        events=[]
        for i, span in enumerate(items):
            attrs = span.get("attributes") or {}
            if isinstance(attrs, list):
                attrs = {a.get("key"): a.get("value") for a in attrs if isinstance(a, Mapping)}
            name = str(span.get("name") or attrs.get("gen_ai.tool.name") or attrs.get("tool.name") or "span")
            kind = str(attrs.get("span.type") or attrs.get("gen_ai.operation.name") or "span")
            ok = None
            status = span.get("status")
            if isinstance(status, Mapping):
                status_code = str(status.get("code", ""))
                if status_code in {"OK", "1", "STATUS_CODE_OK"}: ok=True
                elif status_code in {"ERROR", "2", "STATUS_CODE_ERROR"}: ok=False
            metadata = {k: v for k, v in attrs.items() if k in {"model", "harness", "tool.name", "gen_ai.request.model", "gen_ai.response.finish_reasons", "verifier"}}
            events.append(TrajectoryEvent(i, kind.lower(), name, _txt(attrs.get("output") or attrs.get("gen_ai.prompt") or "")[:4000], str(attrs.get("state_hash") or ""), ok, float(attrs.get("latency_ms", 0.0) or 0.0), float(attrs.get("cost_usd", 0.0) or 0.0), metadata))
        yield Trajectory(trace_id, tuple(events))


def from_swe_bench_expanded(obj: Any, *, ingest_reasoning: bool = True, retain_raw_reasoning: bool = False) -> Iterator[Trajectory]:
    """Normalize SWE-bench trajectories while extracting reusable reasoning signals.

    Raw thought text is never inserted into executable observations. When enabled,
    compact reasoning features are stored in event metadata; raw text requires an
    explicit opt-in and is isolated under ``raw_reasoning`` for licensed/public data.
    """
    rows = obj if isinstance(obj, list) else obj.get("data", []) if isinstance(obj, Mapping) else []
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            continue
        gt = row.get("ground_truth") or {}
        turns = gt.get("trajectory") or []
        events: list[TrajectoryEvent] = []
        step = 0
        for turn in turns if isinstance(turns, list) else []:
            if not isinstance(turn, Mapping):
                continue
            reasoning = extract_reasoning_signals(str(turn.get("thought") or ""), turn=int(turn.get("turn") or 0)) if ingest_reasoning else None
            for call in turn.get("tool_calls") or []:
                if not isinstance(call, Mapping):
                    continue
                args = call.get("arguments") or {}
                events.append(TrajectoryEvent(
                    step=step,
                    kind="tool_call",
                    action=str(call.get("name") or "unknown_tool"),
                    observation=_txt(args)[:4000],
                    ok=None,
                    metadata={
                        "source": "swe-bench-expanded",
                        "instance_id": row.get("instance_id"),
                        "repo": row.get("repo"),
                        "base_commit": row.get("base_commit"),
                        "turn": turn.get("turn"),
                        "reasoning_signals": reasoning.as_dict() if reasoning else None,
                        "raw_reasoning": str(turn.get("thought") or "")[:12000] if (retain_raw_reasoning and reasoning) else None,
                    },
                ))
                step += 1
        answers = gt.get("answer") or []
        if isinstance(answers, list) and answers:
            events.append(TrajectoryEvent(
                step=step, kind="verify", action="ground_truth_answer",
                observation=_txt(answers)[:4000], ok=True,
                metadata={"source": "swe-bench-expanded", "instance_id": row.get("instance_id"), "reasoning_summary": [e.metadata.get("reasoning_signals") for e in events if e.metadata.get("reasoning_signals")]},
            ))
        if events:
            yield Trajectory(str(row.get("instance_id") or f"swe-{index}"), tuple(events))


def from_vc_trace_records(data: bytes) -> Iterator[Trajectory]:
    """Normalize VC-TRACES structured causal explanations for far-transfer learning.

    This adapter requires pandas+pyarrow at runtime. The causal corpus is deliberately
    kept separate from coding-agent imitation; only verified structured primitives and
    DAG edges become executable-ish causal events.
    """
    try:
        import pandas as pd
    except ImportError as exc:  # pragma: no cover - optional transfer dependency
        raise RuntimeError("VC-TRACES ingestion requires pandas and a parquet engine (pyarrow or fastparquet)") from exc
    frame = pd.read_parquet(io.BytesIO(data))
    for index, row in frame.iterrows():
        events: list[TrajectoryEvent] = []
        verified = row.get("explain_verified")
        explain = verified if verified is not None else row.get("explain")
        primitives: list[Any]
        if isinstance(explain, list):
            primitives = explain
        elif isinstance(explain, str):
            try:
                parsed = json.loads(explain)
                primitives = parsed if isinstance(parsed, list) else [parsed]
            except Exception:
                primitives = [explain]
        else:
            primitives = [explain] if explain is not None else []
        for j, primitive in enumerate(primitives):
            if isinstance(primitive, Mapping):
                name = str(primitive.get("action") or primitive.get("name") or primitive.get("primitive") or "causal_step")
                obs = _txt(primitive)
            else:
                name = str(primitive).split("(", 1)[0].strip() or "causal_step"
                obs = str(primitive)
            events.append(TrajectoryEvent(
                j, "causal_step", name, obs[:4000], ok=True,
                metadata={"source": "VC-TRACES", "verified": verified is not None, "question": _txt(row.get("question"))[:1000]},
            ))
        if events:
            yield Trajectory(f"vc:{index}", tuple(events))


def _row_to_trajectory(row: Mapping[str, Any], source: Path, index: int) -> Iterator[Trajectory]:
    """Normalize one JSON-like record from common/frontier schemas."""
    if "events" in row and isinstance(row["events"], list):
        events = []
        for i, e in enumerate(row["events"]):
            if not isinstance(e, Mapping):
                continue
            events.append(TrajectoryEvent(
                i, str(e.get("kind", "event")), str(e.get("action", "event")),
                _txt(e.get("observation", "")), str(e.get("state_hash", "")),
                e.get("ok"), float(e.get("latency_ms", 0.0) or 0.0),
                float(e.get("cost_usd", 0.0) or 0.0), dict(e.get("metadata") or {}),
            ))
        yield Trajectory(str(row.get("run_id") or source.stem), tuple(events))
        return

    # Published frontier schemas used by the MOSAIC ingestion layer.
    if "source_trajectory_id" in row:
        normalized = gpt56_row_to_event_dict(row)
    elif "messages" in row:
        normalized = orchard_row_to_event_dict(row, index)
    else:
        normalized = None
    if normalized is not None:
        yield from _row_to_trajectory(normalized, source, index)


def from_generic_agent_record(row: Mapping[str, Any], *, index: int = 0, ingest_reasoning: bool = True, retain_raw_reasoning: bool = False) -> Iterator[Trajectory]:
    """Normalize a single vendor-neutral agent/session record.

    This intentionally accepts loose schemas discovered from unknown agent installs:
    role/content, tool_call/tool_result, action/observation, model, and run/session ids.
    """
    run_id = str(row.get("run_id") or row.get("session_id") or row.get("trajectory_id") or f"discovered-{index}")
    events: list[TrajectoryEvent] = []
    role = str(row.get("role") or row.get("type") or "event").lower()
    content = row.get("content") or row.get("text") or row.get("message") or ""
    raw_reasoning = row.get("thought") or row.get("reasoning") or row.get("analysis") or (content if role in {"assistant", "reasoning", "analysis"} else "")
    reasoning = extract_reasoning_signals(str(raw_reasoning), turn=index) if ingest_reasoning and raw_reasoning else None
    metadata = {"source": "generic-agent-discovery", "role": role, "model": row.get("model"), "reasoning_signals": reasoning.as_dict() if reasoning else None}
    if retain_raw_reasoning and raw_reasoning:
        metadata["raw_reasoning"] = str(raw_reasoning)[:12000]
    tool = row.get("tool_call") or row.get("action")
    if isinstance(tool, Mapping):
        action = str(tool.get("name") or tool.get("tool") or row.get("action") or "action")
        obs = tool.get("arguments") or row.get("tool_result") or row.get("observation") or ""
        events.append(TrajectoryEvent(0, "tool_call", action, _txt(obs)[:4000], str(row.get("state_hash") or ""), row.get("ok"), float(row.get("latency_ms", 0.0) or 0.0), float(row.get("cost_usd", 0.0) or 0.0), metadata))
    else:
        kind = "reasoning" if role in {"assistant", "reasoning", "analysis"} and reasoning else ("tool_result" if role in {"tool", "tool_result", "observation"} else role)
        action = str(row.get("action") or row.get("tool_name") or role)
        obs = row.get("tool_result") or row.get("observation") or content
        events.append(TrajectoryEvent(0, kind, action, _txt(obs)[:4000], str(row.get("state_hash") or ""), row.get("ok"), float(row.get("latency_ms", 0.0) or 0.0), float(row.get("cost_usd", 0.0) or 0.0), metadata))
    if events:
        yield Trajectory(run_id, tuple(events))


def iter_trajectory_file(path: str | Path) -> Iterator[Trajectory]:
    p = Path(path)
    if p.suffix.lower() == ".eval":
        yield from iter_inspect_trajectories(p)
        return

    suffix = p.suffix.lower()
    if suffix in {".jsonl", ".ndjson"}:
        with p.open("r", encoding="utf-8") as f:
            for index, line in enumerate(f):
                if not line.strip():
                    continue
                row = json.loads(line)
                if not isinstance(row, Mapping):
                    continue
                # Each JSONL record can itself be an ATIF/OTel document.
                if "resourceSpans" in row or "spans" in row and any(isinstance(s, Mapping) and "traceId" in s for s in row.get("spans", [])):
                    yield from from_otel(row)
                elif "steps" in row or "trajectories" in row or "tool_calls" in row or "events" in row:
                    yield from from_atif(row)
                elif any(k in row for k in ("role", "content", "tool_call", "tool_result", "action", "observation", "thought", "reasoning")):
                    yield from from_generic_agent_record(row, index=index)
                else:
                    yield from _row_to_trajectory(row, p, index)
        return

    obj = json.loads(p.read_text(encoding="utf-8"))
    if isinstance(obj, Mapping) and ("resourceSpans" in obj or "spans" in obj and any(isinstance(s, Mapping) and "traceId" in s for s in obj.get("spans", []))):
        yield from from_otel(obj)
        return
    if isinstance(obj, Mapping) and ("steps" in obj or "trajectories" in obj or "tool_calls" in obj):
        yield from from_atif(obj)
        return
    rows = obj if isinstance(obj, list) else [obj]
    for index, row in enumerate(rows):
        if isinstance(row, Mapping):
            yield from _row_to_trajectory(row, p, index)
