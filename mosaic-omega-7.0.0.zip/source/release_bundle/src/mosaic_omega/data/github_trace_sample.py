from __future__ import annotations

import json
from pathlib import Path

# Derived directly from the public GitHub trace
# when2buy/llm-trajectory-data/docs/hard-task-traces/all_haiku.trace.jsonl
# and intentionally restricted to observable execution events.
SAMPLE = [
    {"seq": 1, "orig": "haiku", "served": "claude-haiku-4-5-20251001-v1:0", "response": {"tool_uses": [], "stop_reason": "end_turn", "usage": {"input_tokens": 365, "output_tokens": 25}}, "request": {}},
    {"seq": 2, "orig": "claude-sonnet-4-6", "served": "claude-haiku-4-5-20251001-v1:0", "response": {"tool_uses": [{"name": "Read", "input_partial": "{\"file_path\":\"/workspace/TASK.md\"}"}], "stop_reason": "tool_use", "usage": {"input_tokens": 3, "output_tokens": 98}}, "request": {}},
    {"seq": 3, "orig": "claude-sonnet-4-6", "served": "claude-haiku-4-5-20251001-v1:0", "response": {"tool_uses": [{"name": "Write", "input_partial": "{\"file_path\":\"/workspace/solve.py\",\"content\":\"# Crank-Nicolson solver\"}"}], "stop_reason": "tool_use", "usage": {"input_tokens": 6, "output_tokens": 4892}}, "request": {}},
    {"seq": 4, "orig": "claude-sonnet-4-6", "served": "claude-haiku-4-5-20251001-v1:0", "response": {"tool_uses": [{"name": "Bash", "input_partial": "{\"command\":\"cd /workspace && python3 solve.py\",\"timeout\":120000}"}], "stop_reason": "tool_use", "usage": {"input_tokens": 5, "output_tokens": 111}}, "request": {}},
    {"seq": 5, "orig": "claude-sonnet-4-6", "served": "claude-haiku-4-5-20251001-v1:0", "response": {"tool_uses": [{"name": "Write", "input_partial": "{\"file_path\":\"/workspace/solve.py\"}"}], "stop_reason": "tool_use", "usage": {"input_tokens": 6, "output_tokens": 4378}}, "request": {"last_content": [{"is_error": True, "preview": "SyntaxError: name 'dS' is used prior to global declaration"}]}},
    {"seq": 6, "orig": "claude-sonnet-4-6", "served": "claude-haiku-4-5-20251001-v1:0", "response": {"tool_uses": [{"name": "Bash", "input_partial": "{\"command\":\"cd /workspace && timeout 120 python3 solve.py\",\"timeout\":130000}"}], "stop_reason": "tool_use", "usage": {"input_tokens": 4, "output_tokens": 103}}, "request": {}},
    {"seq": 7, "orig": "claude-sonnet-4-6", "served": "claude-haiku-4-5-20251001-v1:0", "response": {"tool_uses": [{"name": "Write", "input_partial": "{\"file_path\":\"/workspace/solve.py\"}"}], "stop_reason": "tool_use", "usage": {"input_tokens": 5, "output_tokens": 4346}}, "request": {"last_content": [{"is_error": True, "preview": "Exit code 124 timeout"}]}},
    {"seq": 8, "orig": "claude-sonnet-4-6", "served": "claude-haiku-4-5-20251001-v1:0", "response": {"tool_uses": [{"name": "Bash", "input_partial": "{\"command\":\"timeout 90 python3 solve.py 2>&1\",\"timeout\":100000}"}], "stop_reason": "tool_use", "usage": {"input_tokens": 3, "output_tokens": 83}}, "request": {}},
    {"seq": 9, "orig": "claude-sonnet-4-6", "served": "claude-haiku-4-5-20251001-v1:0", "response": {"tool_uses": [{"name": "Edit", "input_partial": "{\"file_path\":\"/workspace/solve.py\"}"}], "stop_reason": "tool_use", "usage": {"input_tokens": 4, "output_tokens": 169}}, "request": {"last_content": [{"is_error": True, "preview": "ModuleNotFoundError: No module named 'scipy'"}]}},
    {"seq": 10, "orig": "claude-sonnet-4-6", "served": "claude-haiku-4-5-20251001-v1:0", "response": {"tool_uses": [{"name": "Bash", "input_partial": "{\"command\":\"timeout 90 python3 solve.py 2>&1\",\"timeout\":100000}"}], "stop_reason": "tool_use", "usage": {"input_tokens": 2, "output_tokens": 83}}, "request": {}},
]


def write_sample(path: str | Path) -> Path:
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(json.dumps(x, sort_keys=True) for x in SAMPLE) + "\n", encoding="utf-8")
    return out
