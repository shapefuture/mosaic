from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping

from ..trajectory.events import Trajectory, TrajectoryEvent


def _dump(obj: Any) -> Any:
    if hasattr(obj, "model_dump"):
        try:
            return obj.model_dump()
        except Exception:
            pass
    if hasattr(obj, "__dict__"):
        try:
            return dict(obj.__dict__)
        except Exception:
            pass
    return obj


def _event_to_dict(event: Any) -> Mapping[str, Any]:
    obj = _dump(event)
    return obj if isinstance(obj, Mapping) else {"type": type(event).__name__, "content": str(obj)}


def _sample_events(sample: Any) -> list[Mapping[str, Any]]:
    obj = _dump(sample)
    if isinstance(obj, Mapping):
        events = obj.get("events") or obj.get("trajectory") or []
        if isinstance(events, list):
            return [_event_to_dict(e) for e in events]
        messages = obj.get("messages") or []
        if isinstance(messages, list):
            return [_event_to_dict(e) for e in messages]
    return []


def _normalize_event(raw: Mapping[str, Any], step: int, header: Mapping[str, Any]) -> TrajectoryEvent:
    kind = str(raw.get("event_type") or raw.get("type") or raw.get("kind") or "event").lower()
    action = str(raw.get("tool_name") or raw.get("name") or raw.get("action") or raw.get("role") or kind)
    content = raw.get("content", raw.get("output", raw.get("observation", raw.get("text", ""))))
    if isinstance(content, list):
        content = " ".join(str(x.get("text", x)) if isinstance(x, Mapping) else str(x) for x in content)
    ok = raw.get("ok")
    if ok is None and "success" in raw:
        ok = bool(raw.get("success"))
    metadata = dict(header)
    for k in ("model", "task", "task_id", "solver", "sample_id", "status", "scorer"):
        if k in raw:
            metadata[k] = raw[k]
    for k in ("tool_args", "preconditions", "postconditions", "verify_status", "judge_verdict", "failure_category"):
        if k in raw:
            metadata[k] = raw[k]
    return TrajectoryEvent(step, kind, action, str(content)[:4000], str(raw.get("state_hash", "")), ok, float(raw.get("latency_ms", 0.0) or 0.0), float(raw.get("cost_usd", 0.0) or 0.0), metadata)


def _rows_from_json(path: Path) -> Iterator[tuple[str, Mapping[str, Any], list[Mapping[str, Any]]]]:
    obj = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(obj, Mapping):
        header = {k: obj.get(k) for k in ("model", "task", "task_id", "solver", "status") if k in obj}
        samples = obj.get("samples") or obj.get("events") or []
        if not isinstance(samples, list):
            samples = []
        if samples and all(isinstance(s, Mapping) and "events" in s for s in samples):
            for i, sample in enumerate(samples):
                sid = str(sample.get("id") or sample.get("uuid") or f"sample-{i}")
                yield sid, header, _sample_events(sample)
        else:
            yield str(obj.get("run_id") or obj.get("id") or path.stem), header, [_event_to_dict(e) for e in samples]
    elif isinstance(obj, list):
        yield path.stem, {}, [_event_to_dict(e) for e in obj]


def iter_inspect_trajectories(path: str | Path) -> Iterator[Trajectory]:
    """Stream Inspect JSON/.eval logs into MOSAIC trajectories.

    `.eval` is read through Inspect's official Log File API when inspect_ai is
    installed; this avoids depending on its binary representation. JSON logs
    are handled directly for portability. Samples are yielded one at a time.
    """
    p = Path(path)
    if p.suffix.lower() == ".eval":
        try:
            from inspect_ai.log import read_eval_log_samples, read_eval_log
        except Exception as exc:
            raise RuntimeError("Inspect .eval ingestion requires the optional inspect_ai package") from exc
        log = read_eval_log(p, header_only=True)
        header_obj = _dump(log)
        header = {}
        if isinstance(header_obj, Mapping):
            header.update({k: header_obj.get(k) for k in ("status",) if k in header_obj})
            ev = header_obj.get("eval")
            if isinstance(ev, Mapping):
                for k in ("id", "task", "task_id", "model"):
                    if k in ev:
                        header[k] = ev[k]
        for idx, sample in enumerate(read_eval_log_samples(p, all_samples_required=False, exclude_fields={"attachments", "store"})):
            events = _sample_events(sample)
            sid = str(getattr(sample, "id", None) or getattr(sample, "uuid", None) or f"{p.stem}:{idx}")
            yield Trajectory(sid, tuple(_normalize_event(e, i, header) for i, e in enumerate(events)))
        return
    for sid, header, events in _rows_from_json(p):
        yield Trajectory(sid, tuple(_normalize_event(e, i, header) for i, e in enumerate(events)))
