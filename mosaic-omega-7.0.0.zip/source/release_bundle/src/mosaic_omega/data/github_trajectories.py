from __future__ import annotations

from dataclasses import asdict, dataclass
import io
import json
import re
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from ..trajectory.events import Trajectory, TrajectoryEvent


@dataclass(frozen=True)
class GitHubTraceSpec:
    source_id: str
    repository: str
    path: str
    raw_url: str
    blob_sha: str
    bytes: int
    model: str
    task: str
    reward: float | None
    passed: int | None
    total: int | None
    model_calls: int | None
    license: str
    notes: str = ""

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def digest(self) -> str:
        import hashlib
        payload = json.dumps(self.as_dict(), sort_keys=True, separators=(",", ":")).encode()
        return hashlib.sha256(payload).hexdigest()


# This is a GitHub-committed, executable-model trace. The source repository is
# MIT licensed; the trace itself is treated as model-generated research data.
# We distill observable execution structure plus compact reasoning signals when
# explicit assistant reasoning is publicly present; no hidden/private reasoning is retained.
GITHUB_TRACE_SOURCES: tuple[GitHubTraceSpec, ...] = (
    GitHubTraceSpec(
        source_id="when2buy/llm-trajectory-data:american-option-haiku",
        repository="when2buy/llm-trajectory-data",
        path="docs/hard-task-traces/all_haiku.trace.jsonl",
        raw_url="https://raw.githubusercontent.com/when2buy/llm-trajectory-data/main/docs/hard-task-traces/all_haiku.trace.jsonl",
        blob_sha="6d24773c1303911ea2cfe065524797de502382fc",
        bytes=123453,
        model="claude-haiku-4-5-20251001-v1:0",
        task="american-option-fd-new",
        reward=0.7407407407407407,
        passed=40,
        total=54,
        model_calls=135,
        license="MIT-repository; research-data-use must follow source terms",
        notes="Full JSONL blob is GitHub-accessible. Distill only observable execution metadata; exclude hidden reasoning/private chain-of-thought.",
    ),
)


# The broader Git-addressable registry lives in git_sources.py.  Keep the
# historical GITHUB_TRACE_SOURCES API stable for callers focused on executable
# Claude traces; frontier_registry() exposes the complete multi-corpus set.
from .git_sources import GIT_ADDRESSABLE_SOURCES, manifest_digest as git_sources_manifest_digest

def frontier_registry():
    return GIT_ADDRESSABLE_SOURCES


def _tool_name(item: Mapping[str, Any]) -> str:
    return str(item.get("name") or item.get("tool") or "unknown_tool")


def _error_signature(text: str) -> str:
    lower = text.lower()
    patterns = (
        ("timeout", r"exit code 124|timed out|timeout"),
        ("syntax_error", r"syntaxerror"),
        ("missing_dependency", r"modulenotfounderror|no module named"),
        ("shape_error", r"broadcast|shape|size"),
        ("runtime_error", r"traceback|runtimeerror|valueerror|typeerror"),
        ("verification_failure", r"failed|failure|incorrect|wrong"),
    )
    for name, pattern in patterns:
        if re.search(pattern, lower):
            return name
    return "unknown_error"


def _extract_error_events(request: Mapping[str, Any], step: int) -> list[TrajectoryEvent]:
    last_content = request.get("last_content") or []
    if not isinstance(last_content, list):
        return []
    out: list[TrajectoryEvent] = []
    for item in last_content:
        if not isinstance(item, Mapping) or not item.get("is_error"):
            continue
        preview = str(item.get("preview") or "")[:4000]
        sig = _error_signature(preview)
        out.append(
            TrajectoryEvent(
                step=step,
                kind="error",
                action=sig,
                observation=preview,
                ok=False,
                metadata={"source": "github_trace", "error_signature": sig},
            )
        )
    return out


def records_to_trajectory(records: Iterable[Mapping[str, Any]], *, run_id: str) -> Trajectory:
    events: list[TrajectoryEvent] = []
    step = 0
    for rec in records:
        response = rec.get("response") or {}
        request = rec.get("request") or {}
        usage = response.get("usage") or {}
        model = str(rec.get("served") or "unknown")
        tool_uses = response.get("tool_uses") or []
        # Model-call metadata is retained on each observable action. The actual
        # reasoning text is deliberately omitted from the normalized artifact.
        call_meta = {
            "teacher_model": model,
            "origin_model": rec.get("orig"),
            "seq": rec.get("seq"),
            "input_tokens": int(usage.get("input_tokens", 0) or 0),
            "cache_read_input_tokens": int(usage.get("cache_read_input_tokens", 0) or 0),
            "cache_creation_input_tokens": int(usage.get("cache_creation_input_tokens", 0) or 0),
            "output_tokens": int(usage.get("output_tokens", 0) or 0),
            "http_status": rec.get("http_status"),
            "stop_reason": response.get("stop_reason"),
        }

        # Causal ordering: the prior tool-result/error belongs before the
        # next assistant action. This makes failure→repair mining faithful.
        errors = _extract_error_events(request, step)
        for err in errors:
            events.append(err)
            step += 1

        for tool in tool_uses:
            if not isinstance(tool, Mapping):
                continue
            name = _tool_name(tool)
            partial = tool.get("input_partial") or tool.get("input") or ""
            if isinstance(partial, Mapping):
                observation = json.dumps(partial, sort_keys=True, separators=(",", ":"))
                tool_args = dict(partial)
            else:
                observation = str(partial)[:4000]
                tool_args = None
            meta = dict(call_meta)
            if tool_args is not None:
                meta["tool_args"] = tool_args
            events.append(TrajectoryEvent(
                step=step,
                kind="tool_call",
                action=name,
                observation=observation,
                ok=True,
                latency_ms=0.0,
                cost_usd=0.0,
                metadata=meta,
            ))
            step += 1

    return Trajectory(run_id, tuple(events))


def iter_local_github_trace(path: str | Path, *, run_id: str | None = None, limit: int | None = None) -> Iterator[Trajectory]:
    """Stream a GitHub-committed Claude-style JSONL trace from local disk."""
    p = Path(path)
    records: list[Mapping[str, Any]] = []
    with p.open("r", encoding="utf-8") as f:
        for idx, line in enumerate(f):
            if not line.strip():
                continue
            if limit is not None and idx >= limit:
                break
            obj = json.loads(line)
            if isinstance(obj, Mapping):
                records.append(obj)
    yield records_to_trajectory(records, run_id=run_id or p.stem)


def iter_remote_github_trace(url: str, *, run_id: str, max_bytes: int = 256 * 1024 * 1024, timeout: float = 20.0) -> Iterator[Trajectory]:
    """Stream the same GitHub raw trace for a network-enabled worker.

    This deliberately lives in a separate adapter so network access is not a
    hidden dependency of local MOSAIC runs. In the network-isolated sandbox it
    should fail loudly and safely rather than silently substituting fixture data.
    """
    parsed = urlparse(url)
    if parsed.scheme != "https" or parsed.netloc not in {"raw.githubusercontent.com", "github.com"}:
        raise ValueError("remote GitHub trace URL must use HTTPS and a GitHub host")
    request = Request(url, headers={"User-Agent": "mosaic-omega/2.3"})
    records: list[Mapping[str, Any]] = []
    total = 0
    buffer = b""
    with urlopen(request, timeout=timeout) as resp:  # nosec B310: scheme/host are allow-listed above
        while True:
            chunk = resp.read(64 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > max_bytes:
                raise ValueError(f"remote trace exceeds max_bytes={max_bytes}")
            buffer += chunk
            lines = buffer.split(b"\n")
            buffer = lines.pop()
            for line in lines:
                if not line.strip():
                    continue
                obj = json.loads(line.decode("utf-8"))
                if isinstance(obj, Mapping):
                    records.append(obj)
    if buffer.strip():
        obj = json.loads(buffer.decode("utf-8"))
        if isinstance(obj, Mapping):
            records.append(obj)
    if records:
        yield records_to_trajectory(records, run_id=run_id)


def audit_trace(spec: GitHubTraceSpec) -> dict[str, Any]:
    return {
        "source": spec.as_dict(),
        "source_digest": spec.digest,
        "training_note": "Observable execution-only distillation; hidden reasoning omitted.",
        "recorded_model_outcome": {
            "reward": spec.reward,
            "passed": spec.passed,
            "total": spec.total,
            "model_calls": spec.model_calls,
        },
    }
