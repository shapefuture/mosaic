from __future__ import annotations

from dataclasses import dataclass, asdict
from hashlib import sha256
import re
from typing import Any, Mapping


@dataclass(frozen=True)
class ReasoningSignals:
    """Compact, non-verbatim reasoning features derived from an explicit trace.

    The signals preserve decision structure without putting chain text into the
    executable observation channel. Raw text can only be retained through an
    explicit caller opt-in at an upstream storage boundary.
    """
    trace_hash: str
    turn: int
    goal: str = ""
    hypothesis: str = ""
    evidence: str = ""
    decision: str = ""
    uncertainty: str = ""
    expected_effect: str = ""
    contradiction: str = ""
    rationale: str = ""
    tool_intent: str = ""
    keywords: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


_PATTERNS = {
    "goal": r"(?:goal|need to|trying to|objective|task is|issue|problem)[: ](.+)",
    "hypothesis": r"(?:think|suspect|likely|probably|hypothesis|maybe|might be)[: ,]?(.*)",
    "evidence": r"(?:found|find|shows|because|evidence|trace|error|line)[: ,]?(.*)",
    "decision": r"(?:therefore|so |thus |decide|will |should |use |change |fix )[: ,]?(.*)",
    "uncertainty": r"(?:uncertain|not sure|unknown|ambiguous|could be|may be)[: ,]?(.*)",
    "expected_effect": r"(?:expected|should make|will cause|result|outcome)[: ,]?(.*)",
    "contradiction": r"(?:but |however|except|contradicts|doesn't match|failed)[: ,]?(.*)",
    "rationale": r"(?:because|since|reason|reasoning|rationale)[: ,]?(.*)",
}


def extract_reasoning_signals(thought: str, *, turn: int = 0, tool_intent: str = "") -> ReasoningSignals | None:
    text = " ".join(str(thought or "").split())[:12000]
    if not text:
        return None
    vals: dict[str, str] = {}
    low = text.lower()
    for key, pat in _PATTERNS.items():
        m = re.search(pat, low)
        if m:
            vals[key] = text[max(0, m.start(1)):m.end(1)].strip()[:600]
    kws = tuple(sorted(set(re.findall(r"[A-Za-z_]{4,}", low)))[:24])
    return ReasoningSignals(
        trace_hash=sha256(text.encode()).hexdigest(), turn=turn, tool_intent=tool_intent[:200],
        keywords=kws, **vals
    )
