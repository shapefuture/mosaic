from __future__ import annotations

import base64
import hashlib
import io
import json
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping
from urllib.request import Request, urlopen

from .git_sources import GitAddressableSource
from .trajectory_formats import from_swe_bench_expanded, from_vc_trace_records
from ..trajectory.events import Trajectory


class GitBlobIntegrityError(ValueError):
    pass


def stream_raw_bytes(source: GitAddressableSource, *, timeout: float = 30.0, chunk_size: int = 1024 * 1024) -> Iterator[bytes]:
    """Stream and verify a pinned GitHub blob using the Git blob SHA-1 algorithm."""
    req = Request(source.raw_url, headers={"User-Agent": "mosaic-omega/3.0.0"})
    sha = hashlib.sha1()
    sha.update(f"blob {source.bytes}\0".encode())
    seen = 0
    with urlopen(req, timeout=timeout) as response:  # noqa: S310 - URL is pinned in source manifest
        while True:
            chunk = response.read(chunk_size)
            if not chunk:
                break
            seen += len(chunk)
            sha.update(chunk)
            yield chunk
    if source.bytes and seen != source.bytes:
        raise GitBlobIntegrityError(f"byte-size mismatch for {source.source_id}: {seen} != {source.bytes}")
    if source.blob_sha and sha.hexdigest() != source.blob_sha:
        raise GitBlobIntegrityError(f"Git blob SHA mismatch for {source.source_id}: {sha.hexdigest()} != {source.blob_sha}")


def fetch_text(source: GitAddressableSource, *, max_bytes: int = 256 * 1024 * 1024) -> bytes:
    chunks: list[bytes] = []
    total = 0
    for chunk in stream_raw_bytes(source):
        total += len(chunk)
        if total > max_bytes:
            raise ValueError(f"source exceeds configured materialization limit: {total} > {max_bytes}")
        chunks.append(chunk)
    return b"".join(chunks)


def iter_jsonl_source(source: GitAddressableSource) -> Iterator[Mapping[str, Any]]:
    req = Request(source.raw_url, headers={"User-Agent": "mosaic-omega/3.0.0"})
    sha = hashlib.sha1()
    sha.update(f"blob {source.bytes}\0".encode())
    seen = 0
    with urlopen(req, timeout=30.0) as response:  # noqa: S310
        for line in response:
            sha.update(line)
            seen += len(line)
            if not line.strip():
                continue
            obj = json.loads(line.decode("utf-8"))
            if isinstance(obj, Mapping):
                yield obj
    if source.bytes and seen != source.bytes:
        raise GitBlobIntegrityError(f"streamed byte-size mismatch: {seen} != {source.bytes}")
    if source.blob_sha and sha.hexdigest() != source.blob_sha:
        raise GitBlobIntegrityError(f"Git blob SHA mismatch: {sha.hexdigest()} != {source.blob_sha}")


def iter_source_trajectories(source: GitAddressableSource) -> Iterator[Trajectory]:
    if source.format == "jsonl.claude-agent":
        from .github_trajectories import records_to_trajectory
        yield records_to_trajectory(iter_jsonl_source(source), run_id=source.source_id)
        return
    if source.format == "json.swe-bench-expanded":
        # The source is <1 MB and can be safely materialized under the configured cap.
        obj = json.loads(fetch_text(source, max_bytes=32 * 1024 * 1024).decode("utf-8"))
        yield from from_swe_bench_expanded(obj)
        return
    if source.format == "parquet.vc-traces":
        yield from from_vc_trace_records(fetch_text(source, max_bytes=128 * 1024 * 1024))
        return
    if source.format == "jsonl.long-trace-rl":
        # LongTraceRL is a long-form reasoning transfer source. Preserve reusable
        # reasoning signals even when raw prose is not used as executable content.
        for index, row in enumerate(iter_jsonl_source(source)):
            events = []
            for turn in row.get("trajectory", []) if isinstance(row.get("trajectory"), list) else []:
                if not isinstance(turn, Mapping):
                    continue
                for tool in turn.get("tool_calls", []) or []:
                    if not isinstance(tool, Mapping):
                        continue
                    reasoning = extract_reasoning_signals(str(turn.get("thought") or turn.get("reasoning") or ""), turn=int(turn.get("turn") or len(events)))
                    metadata = {"source": source.source_id}
                    if reasoning:
                        metadata["reasoning_signals"] = reasoning.as_dict()
                    events.append({
                        "kind": "tool_call", "action": str(tool.get("name") or "unknown"),
                        "observation": json.dumps(tool.get("arguments") or {}, sort_keys=True),
                        "ok": None, "metadata": metadata,
                    })
            if events:
                from ..trajectory.events import TrajectoryEvent
                yield Trajectory(source.source_id + f":{index}", tuple(TrajectoryEvent(i, e["kind"], e["action"], e["observation"], ok=e["ok"], metadata=e["metadata"]) for i, e in enumerate(events)))
        return
    raise ValueError(f"no trajectory adapter for source format {source.format}")
