from __future__ import annotations

from dataclasses import dataclass, asdict
import hashlib, json
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping

@dataclass(frozen=True)
class DatasetManifest:
    name: str
    url: str
    license: str
    role: str  # train|analysis|sealed_eval
    revision: str = "main"
    notes: str = ""

    @property
    def digest(self) -> str:
        raw = json.dumps(asdict(self), sort_keys=True, separators=(",", ":")).encode()
        return hashlib.sha256(raw).hexdigest()

TRAINING_MANIFESTS = (
    DatasetManifest(
        "microsoft/orchard-swe", "https://huggingface.co/datasets/microsoft/Orchard", "MIT", "train",
        notes="107,185 SWE trajectories; resolved/unresolved; use with dataset terms and provenance checks."
    ),
    DatasetManifest(
        "greghavens/gpt-5.6-sol-coding-and-debugging-traces",
        "https://huggingface.co/datasets/greghavens/gpt-5.6-sol-coding-and-debugging-traces", "CC-BY-4.0", "train",
        notes="Observable GPT-5.6 Sol Codex trajectories; use source_trajectory_id for session grouping."
    ),
)
ANALYSIS_MANIFESTS = (
    DatasetManifest(
        "Exgentic/agent-llm-traces-v2", "https://huggingface.co/datasets/Exgentic/agent-llm-traces-v2", "UNKNOWN", "analysis",
        notes="10,057 OpenTelemetry-shaped execution records; do not treat license absence as training permission."
    ),
)
SEALED_EVAL_MANIFESTS = (
    DatasetManifest(
        "hkust-nlp/Toolathlon-Verified_Trajectories",
        "https://huggingface.co/datasets/hkust-nlp/Toolathlon-Verified_Trajectories", "RESTRICTED", "sealed_eval",
        notes="Explicitly excluded from training/distillation; must remain blind."
    ),
)

def validate_manifest_for_training(manifest: DatasetManifest) -> None:
    if manifest.role != "train":
        raise ValueError(f"dataset {manifest.name!r} is not training-eligible; role={manifest.role}")
    if manifest.license.upper() in {"UNKNOWN", "RESTRICTED", "NONE", ""}:
        raise ValueError(f"dataset {manifest.name!r} lacks a verified training license")


def manifest_report() -> dict[str, Any]:
    return {
        "train": [asdict(x) | {"digest": x.digest} for x in TRAINING_MANIFESTS],
        "analysis": [asdict(x) | {"digest": x.digest} for x in ANALYSIS_MANIFESTS],
        "sealed_eval": [asdict(x) | {"digest": x.digest} for x in SEALED_EVAL_MANIFESTS],
    }


def _jsonl(path: Path) -> Iterator[Mapping[str, Any]]:
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                yield json.loads(line)


def iter_records(path: str | Path, *, limit: int | None = None) -> Iterator[Mapping[str, Any]]:
    p = Path(path)
    suffix = p.suffix.lower()
    if suffix in {".jsonl", ".ndjson"}:
        src = _jsonl(p)
    elif suffix == ".json":
        obj = json.loads(p.read_text(encoding="utf-8"))
        src = iter(obj if isinstance(obj, list) else [obj])
    elif suffix == ".parquet":
        try:
            import pyarrow.parquet as pq  # optional
        except ImportError as exc:
            raise RuntimeError("parquet ingestion requires optional pyarrow") from exc
        table = pq.read_table(p)
        src = (dict(x) for x in table.to_pylist())
    else:
        raise ValueError(f"unsupported dataset file type: {p.suffix}")
    for i, row in enumerate(src):
        if limit is not None and i >= limit:
            break
        yield row


def _message_text(m: Mapping[str, Any]) -> str:
    content = m.get("content", "")
    if isinstance(content, list):
        return " ".join(str(part.get("text", "")) if isinstance(part, Mapping) else str(part) for part in content)
    return str(content)


def orchard_row_to_event_dict(row: Mapping[str, Any], step: int = 0) -> dict[str, Any]:
    metadata = row.get("metadata", {})
    if isinstance(metadata, str):
        metadata = json.loads(metadata or "{}")
    messages = row.get("messages", [])
    events: list[dict[str, Any]] = []
    for i, msg in enumerate(messages if isinstance(messages, list) else []):
        role = str(msg.get("role", "unknown"))
        tool_calls = msg.get("tool_calls") or []
        if tool_calls:
            for tc in tool_calls:
                fn = (tc.get("function") or {}) if isinstance(tc, Mapping) else {}
                events.append({"step": len(events), "kind": "tool_call", "action": str(fn.get("name", "")),
                               "observation": str(fn.get("arguments", "")), "ok": None,
                               "metadata": {"role": role, "instance_id": metadata.get("instance_id"), "verify_status": metadata.get("verify_status")}})
        else:
            txt = _message_text(msg)
            if txt.strip():
                events.append({"step": len(events), "kind": "message", "action": role, "observation": txt[:1000],
                               "ok": True if role == "tool" else None,
                               "metadata": {"instance_id": metadata.get("instance_id"), "verify_status": metadata.get("verify_status")}})
    return {"run_id": str(metadata.get("instance_id", row.get("task", f"orchard-{step}"))), "events": events,
            "dataset": "microsoft/Orchard", "license": "MIT"}


def gpt56_row_to_event_dict(row: Mapping[str, Any]) -> dict[str, Any]:
    events: list[dict[str, Any]] = []
    messages = row.get("messages") or []
    for i, msg in enumerate(messages if isinstance(messages, list) else []):
        role = str(msg.get("role", "unknown"))
        tool_calls = msg.get("tool_calls") or []
        if tool_calls:
            for tc in tool_calls:
                fn = (tc.get("function") or {}) if isinstance(tc, Mapping) else {}
                events.append({"step": len(events), "kind": "tool_call", "action": str(fn.get("name", "")),
                               "observation": str(fn.get("arguments", "")), "ok": None,
                               "metadata": {"task": row.get("task"), "source_trajectory_id": row.get("source_trajectory_id"),
                                            "verifier": row.get("verifier"), "split": row.get("split"), "teacher_model": row.get("teacher_model"), "judge_verdict": row.get("judge_verdict")}})
        else:
            txt = _message_text(msg)
            if txt.strip():
                events.append({"step": len(events), "kind": "message", "action": role, "observation": txt[:1000], "ok": True if role == "tool" else None,
                               "metadata": {"task": row.get("task"), "source_trajectory_id": row.get("source_trajectory_id"), "verifier": row.get("verifier"), "split": row.get("split"), "judge_verdict": row.get("judge_verdict")}})
    return {"run_id": str(row.get("source_trajectory_id", row.get("task", "gpt56"))), "events": events,
            "dataset": "greghavens/gpt-5.6-sol-coding-and-debugging-traces", "license": "CC-BY-4.0"}
