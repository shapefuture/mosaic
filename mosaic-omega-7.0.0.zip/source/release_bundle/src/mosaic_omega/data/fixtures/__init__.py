"""Packaged GitHub-trajectory fixtures used by offline Gauntlets."""
