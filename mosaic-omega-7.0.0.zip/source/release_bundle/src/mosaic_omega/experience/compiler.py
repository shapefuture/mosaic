from __future__ import annotations
from collections import Counter, defaultdict
from dataclasses import dataclass, field, asdict
from hashlib import sha256
import json
from typing import Any, Iterable, Mapping, Sequence
from ..trajectory.events import Trajectory, TrajectoryEvent, trajectory_digest
from ..data.reasoning_trace import ReasoningSignals, extract_reasoning_signals

@dataclass(frozen=True)
class EvidenceNode:
    run_id:str; step:int; kind:str; action:str; observation:str; ok:bool|None; state_hash:str; view:str
    tags:tuple[str,...]=(); reasoning:Mapping[str,Any]=field(default_factory=dict); cost_usd:float=0.; latency_ms:float=0.
    @property
    def node_id(self)->str:
        return sha256(f"{self.run_id}:{self.step}:{self.kind}:{self.action}:{self.view}:{self.state_hash}".encode()).hexdigest()[:20]
@dataclass(frozen=True)
class CausalEdge:
    source:str; target:str; relation:str; confidence:float
@dataclass(frozen=True)
class ExperiencePatch:
    kind:str; signature:str; positive:tuple[str,...]; negative:tuple[str,...]; preconditions:tuple[str,...]; actions:tuple[str,...]; expected_effect:str; evidence_ids:tuple[str,...]; applicability:Mapping[str,float]; success_rate:float; support_runs:int; latency_ms:float; cost_usd:float
    @property
    def digest(self)->str:
        return sha256(json.dumps(asdict(self),sort_keys=True,separators=(",",":")).encode()).hexdigest()[:20]
@dataclass(frozen=True)
class ExperienceCandidate:
    patch:ExperiencePatch; source_digests:tuple[str,...]; novelty:float; information_gain:float
@dataclass(frozen=True)
class PromotionDecision:
    patch_digest:str; promoted:bool; reason:str; score:float; evidence_count:int; independent_runs:int; adversarial_survived:bool
@dataclass(frozen=True)
class SixViewReport:
    trajectories:int; reasoning_events:int; execution_events:int; outcome_events:int; causal_edges:int; economic_cost_usd:float; economic_latency_ms:float; critical_steps:int; candidate_patches:int; promoted_patches:int; reasoning_coverage:float; execution_coverage:float; joint_coverage:float; outcome_consistency:float; causal_consistency:float; cross_view_gain:float

class ExperienceMemory:
    def __init__(self)->None:
        self.episodic={}; self.procedural={}; self.negative={}
    def add_episode(self,traj:Trajectory)->str:
        d=trajectory_digest(traj); self.episodic[d]={"run_id":traj.run_id,"events":len(traj.events)}; return d
    def promote(self,patch:ExperiencePatch)->None:
        (self.negative if patch.success_rate<0.5 else self.procedural)[patch.digest]=patch
    def retire(self,*,min_support:int=1,max_age_keys:int=512)->list[str]:
        retired=[]; items=sorted(self.procedural.items(),key=lambda kv:(kv[1].support_runs,kv[1].success_rate,kv[0]))
        while len(items)>max_age_keys:
            k,_=items.pop(0); self.procedural.pop(k,None); retired.append(k)
        for k,p in list(self.procedural.items()):
            if p.support_runs<min_support and p.success_rate<0.75: self.procedural.pop(k,None); retired.append(k)
        return retired
    def retrieve(self,query_terms:Iterable[str],*,limit:int=5)->list[ExperiencePatch]:
        q={str(x).lower() for x in query_terms if x}; scored=[]
        for p in self.procedural.values():
            toks=set(p.positive)|set(p.preconditions)|set(p.actions)
            overlap=len(q&toks)/max(1,len(q|toks)); score=.65*overlap+.25*p.success_rate+.1*min(1,p.support_runs/10)
            scored.append((score,p))
        scored.sort(key=lambda x:(-x[0],-x[1].success_rate,x[1].digest)); return [p for _,p in scored[:limit]]

class ExperienceCompiler:
    """Compile six correlated evidence views into verified reusable experience."""
    def __init__(self)->None: self.memory=ExperienceMemory()
    @staticmethod
    def _reasoning_signals(event:TrajectoryEvent)->Mapping[str,Any]|None:
        meta=event.metadata if isinstance(event.metadata,Mapping) else {}
        rs=meta.get("reasoning_signals")
        if isinstance(rs,Mapping) and any(str(v).strip() for v in rs.values()):
            return dict(rs)
        raw=meta.get("thought")
        if isinstance(raw,str) and raw.strip():
            parsed=extract_reasoning_signals(raw,turn=event.step,tool_intent=event.action)
            return parsed.as_dict() if parsed else None
        return None
    def build_evidence(self,trajectories:Sequence[Trajectory])->tuple[list[EvidenceNode],list[CausalEdge]]:
        nodes=[]; edges=[]
        for traj in trajectories:
            prev_action=None; prev_reasoning=None; prev_failure=None
            for e in traj.events:
                rs=self._reasoning_signals(e); is_exec=bool(e.action) and e.kind not in {"message","reasoning","model_call"}; is_out=e.ok is not None or e.kind in {"verify","benchmark","checkpoint","recovery","tool_result","error"}
                views=[]
                if rs: views.append("reasoning")
                if is_exec: views.append("execution")
                if is_out: views.append("outcome")
                views += ["state","economics"]
                n=EvidenceNode(traj.run_id,e.step,e.kind,e.action,e.observation,e.ok,e.state_hash,"+".join(views),("failure",) if e.ok is False else (),dict(rs) if rs else {},e.cost_usd,e.latency_ms)
                nodes.append(n)
                if prev_action: edges.append(CausalEdge(prev_action.node_id,n.node_id,"temporal",.55))
                if rs and prev_reasoning: edges.append(CausalEdge(prev_reasoning.node_id,n.node_id,"reasoning-continuation",.75))
                if e.ok is False: prev_failure=n
                elif prev_failure and e.ok is True and is_exec: edges.append(CausalEdge(prev_failure.node_id,n.node_id,"recovery",.9)); prev_failure=None
                if is_exec: prev_action=n
                if rs: prev_reasoning=n
        return nodes,edges
    @staticmethod
    def _frame(node:EvidenceNode)->set[str]:
        text=" ".join(str(node.reasoning.get(k,"")) for k in ("goal","hypothesis","evidence","decision","expected_effect","contradiction","tool_intent","keywords")).lower()
        groups={"inspect":("inspect","search","find","trace","read"),"repair":("fix","repair","rewrite","bug","error"),"verify":("test","verify","check","regression","assert"),"optimize":("slow","timeout","performance","latency","optimi"),"dependency":("import","package","module","dependency"),"api":("api","signature","caller","interface","parameter"),"state":("state","cache","mutation","persist")}
        return {k for k,v in groups.items() if any(w in text for w in v)} or {"general"}
    @staticmethod
    def _family(action:str)->str:
        a=action.lower()
        if any(x in a for x in ("read","grep","find","search","inspect","open")): return "inspect"
        if any(x in a for x in ("write","edit","patch","replace","apply")): return "mutate"
        if any(x in a for x in ("test","check","verify","lint","compile","run","bash")): return "verify"
        if any(x in a for x in ("recover","retry","rollback","repair")): return "recover"
        return "other"
    def mine(self,trajectories:Sequence[Trajectory])->tuple[list[ExperienceCandidate],SixViewReport]:
        nodes,edges=self.build_evidence(trajectories)
        for t in trajectories:self.memory.add_episode(t)
        followers=defaultdict(Counter); evidence=defaultdict(list); runs=defaultdict(set); critical=0
        byrun=defaultdict(list)
        for n in nodes: byrun[n.run_id].append(n)
        for run_nodes in byrun.values():
            exec_nodes=[n for n in run_nodes if "execution" in n.view]
            for i,n in enumerate(exec_nodes):
                prev=exec_nodes[i-1].action.lower() if i else "<start>"
                rs_nodes=[x for x in run_nodes if x.step<=n.step and "reasoning" in x.view][-2:]
                frame=set()
                for x in rs_nodes: frame|=self._frame(x)
                key=f"{prev}|{'/'.join(sorted(frame))}"; fam=self._family(n.action); followers[key][fam]+=1; evidence[key].append(n); runs[key].add(n.run_id)
            for i,n in enumerate(run_nodes):
                if n.ok is False and any(x.ok is False for x in run_nodes[i+1:]): critical+=1
        cands=[]
        all_digests=tuple(sorted(trajectory_digest(t) for t in trajectories))
        for key,cnt in followers.items():
            target,support=cnt.most_common(1)[0]; total=sum(cnt.values()); rate=support/max(1,total)
            if support<2 or rate<.6: continue
            ev=evidence[key]; action,frame_raw=key.split("|",1)
            p=ExperiencePatch("procedural",key,tuple(sorted(set(frame_raw.split("/"))- {""})),tuple(sorted({n.action.lower() for n in ev if n.ok is False})),(f"prev:{action}",),(target,),f"next_family:{target}",tuple(n.node_id for n in ev[:16]),{"support":min(1,support/10),"confidence":rate},rate,len(runs[key]),sum(n.latency_ms for n in ev)/max(1,len(ev)),sum(n.cost_usd for n in ev)/max(1,len(ev)))
            nov=1/(1+support); ig=rate*(1+len(p.positive))*(1+nov); cands.append(ExperienceCandidate(p,all_digests,nov,ig))
        cands.sort(key=lambda c:(-c.information_gain,-c.patch.success_rate,c.patch.digest)); promoted=0
        for c in cands:
            p=c.patch; adv=p.success_rate>=.75 and p.support_runs>=2 and bool(p.preconditions); score=.55*p.success_rate+.2*min(1,p.support_runs/4)+.15*min(1,len(p.positive)/3)+.1*c.novelty
            if adv and score>=.55:self.memory.promote(p); promoted+=1
        rn=sum("reasoning" in n.view for n in nodes); en=sum("execution" in n.view for n in nodes); on=sum("outcome" in n.view for n in nodes)
        joint=sum(1 for run_nodes in byrun.values() if any("reasoning" in n.view for n in run_nodes) and any("execution" in n.view for n in run_nodes) for _ in [0])
        j=[c.patch.success_rate for c in cands if c.patch.positive]; e=[c.patch.success_rate for c in cands if not c.patch.positive]; cross=(sum(j)/len(j) if j else 0)-(sum(e)/len(e) if e else 0)
        rep=SixViewReport(len(trajectories),rn,en,on,len(edges),sum(n.cost_usd for n in nodes),sum(n.latency_ms for n in nodes),critical,len(cands),promoted,rn/max(1,len(nodes)),en/max(1,len(nodes)),joint/max(1,len(nodes)),1.0 if cands else 0.0,min(1,len(edges)/max(1,len(nodes))),cross)
        return cands,rep
