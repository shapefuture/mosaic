from __future__ import annotations

from dataclasses import dataclass, field, asdict
from hashlib import sha256
import json
from typing import Any


@dataclass(frozen=True)
class ResourceBudget:
    max_ops: int = 100_000
    max_memory: int = 1_000_000
    max_latency_ms: float = 1000.0
    max_cost_usd: float = 1.0
    max_energy_j: float = 10_000.0


@dataclass(frozen=True)
class ComputeSpec:
    name: str
    op: str
    input_size: int
    dtype: str = "f64"
    target: str = "reference-cpu"
    resource: ResourceBudget = field(default_factory=ResourceBudget)
    expected: tuple[float, ...] | None = None
    constraints: dict[str, tuple[int, int]] = field(default_factory=dict)

    def canonical(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Genome:
    tile: int = 1
    unroll: int = 1
    vector_width: int = 1
    pipeline: int = 1
    split: int = 1

    def validate(self) -> None:
        for name in ("tile", "unroll", "vector_width", "pipeline", "split"):
            if getattr(self, name) < 1:
                raise ValueError(f"{name} must be >= 1")

    def canonical(self) -> dict[str, int]:
        self.validate()
        return asdict(self)


@dataclass(frozen=True)
class Candidate:
    spec: ComputeSpec
    genome: Genome
    source: str = "mosaic"
    lineage: tuple[str, ...] = ()

    @property
    def genome_id(self) -> str:
        payload = json.dumps(
            {"spec": self.spec.canonical(), "genome": self.genome.canonical(), "source": self.source},
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
        return sha256(payload).hexdigest()[:24]


@dataclass(frozen=True)
class VerificationEvidence:
    passed: bool
    message: str
    checked_points: int = 0


@dataclass(frozen=True)
class Observation:
    candidate_id: str
    fidelity: int
    latency_ms: float
    energy_j: float
    memory_bytes: int
    correct: bool
    verification: VerificationEvidence
    features: tuple[float, ...]
    target: str
    reason: str = ""
    cost_usd: float = 0.0
    backend: str = ""
