from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass


@dataclass(frozen=True)
class AttestationQuote:
    provider: str
    available: bool
    raw: bytes | None = None
    message: str = ""


class NitroAttestationProvider:
    """Uses nitro-cli when present; never claims attestation if unavailable."""
    def quote(self, user_data: bytes = b"") -> AttestationQuote:
        nitro = shutil.which("nitro-cli")
        if not nitro:
            return AttestationQuote("aws-nitro", False, message="nitro-cli unavailable")
        proc = subprocess.run([nitro, "describe-enclaves"], capture_output=True, timeout=10)
        if proc.returncode:
            return AttestationQuote("aws-nitro", False, message=proc.stderr.decode(errors="ignore")[-1000:])
        return AttestationQuote("aws-nitro", True, proc.stdout, "environment reports Nitro tooling")


class TDXAttestationProvider:
    """Detects a TDX guest quote tool without treating detection as proof."""
    def quote(self) -> AttestationQuote:
        tool = shutil.which("tdx-attest")
        if not tool:
            return AttestationQuote("intel-tdx", False, message="tdx-attest unavailable")
        proc = subprocess.run([tool, "quote"], capture_output=True, timeout=15)
        if proc.returncode:
            return AttestationQuote("intel-tdx", False, message=proc.stderr.decode(errors="ignore")[-1000:])
        return AttestationQuote("intel-tdx", True, proc.stdout, "TDX quote tool returned successfully")
