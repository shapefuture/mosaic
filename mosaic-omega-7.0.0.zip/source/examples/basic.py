from mosaic_omega.cli.main import main

if __name__ == "__main__":
    raise SystemExit(main(["demo"]))
