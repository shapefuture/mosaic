"""Offline frontier-trajectory-to-ECU demonstration using canonical dataset schemas."""
from mosaic_omega.data.frontier import orchard_row_to_event_dict, gpt56_row_to_event_dict
from mosaic_omega.trajectory.events import Trajectory, TrajectoryEvent
from mosaic_omega.ecu import distill_ecus, ECUEnvironment, ECUAction, ECUContract, ExecutableComputeUnit
ORCHARD_SAMPLE={"metadata":'{"instance_id":"demo__repo-1","verify_status":"resolved"}',"messages":[{"role":"assistant","tool_calls":[{"function":{"name":"open_file","arguments":"{\"path\":\"src/a.py\"}"}}]},{"role":"assistant","tool_calls":[{"function":{"name":"apply_patch","arguments":"{\"path\":\"src/a.py\"}"}}]},{"role":"assistant","tool_calls":[{"function":{"name":"run_tests","arguments":"{\"suite\":\"unit\"}"}}]}]}
GPT56_SAMPLE={"task":"demo-build-cli","source_trajectory_id":"demo-build-cli:abc123","verifier":"acceptance-tests","split":"train","teacher_model":"gpt-5.6-sol","messages":[{"role":"assistant","tool_calls":[{"function":{"name":"exec","arguments":"{\"cmd\":\"ls\"}"}}]},{"role":"assistant","tool_calls":[{"function":{"name":"exec","arguments":"{\"cmd\":\"pytest\"}"}}]}]}
def as_traj(obj): return Trajectory(obj["run_id"], tuple(TrajectoryEvent(**e) for e in obj["events"]))
if __name__=="__main__":
    trajectories=[as_traj(orchard_row_to_event_dict(ORCHARD_SAMPLE)),as_traj(gpt56_row_to_event_dict(GPT56_SAMPLE))]
    units,report=distill_ecus(trajectories,min_support=1,max_actions=3,source_manifest="frontier-schema-smoke")
    print({"report":report.__dict__,"units":len(units)})
    def open_file(env,path): env.state["opened"]=path; return path
    def run_tests(env,suite): env.state["tests"]=suite; return True
    ecu=ExecutableComputeUnit(ECUContract("demo",postconditions=('tests=="unit"',)),[ECUAction("open_file",{"path":"src/a.py"}),ECUAction("run_tests",{"suite":"unit"})],{"source":"frontier-schema-smoke"})
    print(ecu.run(ECUEnvironment(handlers={"open_file":open_file,"run_tests":run_tests})))
