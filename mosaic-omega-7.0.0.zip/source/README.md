# MOSAIC Ω 2.0

MOSAIC Ω 2.0 is an evolving execution compiler for agentic work. It compiles repeated reasoning into verified executable units, runs local deterministic paths before model/accelerator fallback, and supports privacy-preserving collective exchange of proof-carrying capabilities.

Core path:

`Task → AgentProgram IR → plan/verify → parallel execution → evidence → capability promotion → collective reuse`

The release includes the previous trajectory/ECU/verification stack plus the Ω2 runtime, collective registry, harness evolution and Ω2 superiority Gauntlet.

# MOSAIC Ω 1.2.0

MOSAIC Ω is a local-first verified execution-intelligence substrate. The 1.2 release adds verified recursive decomposition: decomposition is checked before execution, code and proof plans are co-designed, failures trigger local re-decomposition/recovery, and adversarial verification is part of promotion.

## Core loop

```text
intent → TaskIR → recursive decomposition → verify decomposition
      → code + proof plan → execute → independent verification
      → adversarial audit → recover/re-decompose → promote
      → reusable capability → harder regression
```

## Release evidence

The release contains legacy, ECU, collective, long-horizon and verified-recursive Gauntlets. Local measurements are reproducible fixture/host measurements; they are not claims of beating closed frontier models without a network-enabled external benchmark run.

## 0.9.0 Ω∞-COLLECTIVE

Adds TaskIR, proof-carrying capabilities, adaptive verification, marginal-value control and verified plan competition on top of the trajectory/ECU compiler. See `docs/OMEGA_COLLECTIVE_0_9.md`.

# MOSAIC Ω 1.0.0 — Frontier Execution Intelligence

MOSAIC Ω is a CPU-first, evidence-carrying execution-intelligence substrate that treats agent trajectories as **program data**: it mines reusable procedures, validates them on disjoint holdouts, compiles stable motifs into executable compute units (ECUs), and routes only uncovered residue to more expensive reasoning.

## North-star objective

\[
U = \frac{quality \times verified\ useful\ work}{latency \times USD \times energy \times risk}
\]

GPU and frontier-model inference are **late escalation tiers**, not defaults.

## 0.7 loop

```text
trajectory lake
  -> provenance + licensing gate
  -> leakage-safe group split
  -> diversity-first sampling / streaming heavy hitters
  -> success/failure contrast
  -> reusable motif / state-transition mining
  -> bounded skill optimization + held-out gate
  -> ECU compilation
  -> independent verification
  -> ECU-first economic routing
  -> checkpoint/prefix reuse
  -> evidence + recovery
  -> continual improvement
```

### Why this architecture

Recent frontier work shows three particularly important directions: Orchard demonstrates large-scale trajectory distillation and productive-segment learning from unresolved rollouts; SkillDisCo compiles shared trajectory structure into executable, verifiable procedural skills; SkillOpt applies bounded, validation-gated optimization with rejected-edit memory and slow/meta updates. These ideas are combined here into a **model-free executable path plus optional model-residue path** rather than a prompt-only optimizer.

## Full-corpus ingestion

The repository includes adapters for:

- `microsoft/Orchard` SWE and GUI data (training-eligible subject to per-repository licensing checks).
- `greghavens/gpt-5.6-sol-coding-and-debugging-traces` (CC-BY-4.0).
- JSONL/Inspect/ATIF-like normalized trajectories.

The remote trainer is bounded-memory and streams the corpus:

```bash
mosaic frontier-remote microsoft/Orchard --config swe --split train \
  --min-support 8 --max-actions 8 --max-patterns 4096 \
  --output dist/orchard-stream-ecus.jsonl
```

For GPT-5.6 Sol:

```bash
mosaic frontier-remote greghavens/gpt-5.6-sol-coding-and-debugging-traces \
  --config default --split train \
  --min-support 8 --max-actions 8 --max-patterns 4096 \
  --output dist/gpt56-stream-ecus.jsonl
```

Those commands are designed to run in an external worker with network access (for example a private MCP/worker environment). The ChatGPT sandbox used for this release has no public DNS/HTTP egress, so the release does **not** falsely claim that 9.72 GB of Orchard data or the 1.05 GB GPT-5.6 corpus were downloaded here.

## Training integrity

MOSAIC never trains on a sealed evaluation manifest. It splits by source trajectory identity, not row, so prefixes from the same execution cannot leak across train/validation. Rejected candidate procedures remain negative evidence rather than being silently discarded.

## Commands

```bash
mosaic demo
mosaic gauntlet
mosaic frontier-learn examples/frontier_fixtures/orchard_swe_sample.jsonl --adapter orchard
mosaic frontier-max examples/frontier_fixtures/orchard_swe_sample.jsonl --adapter orchard
mosaic frontier-gauntlet
mosaic max-gauntlet
```

## Release gate

The 0.8.0 maximum Gauntlet requires:

- zero train/holdout leakage groups;
- at least one independently verified ECU;
- held-out validation improvement or non-regression;
- >=50% planning compression;
- >=99% frontier-call elimination for covered stable procedures;
- >=50% replay-prefix reuse;
- zero ECU regressions;
- CPU-first execution;
- sealed-evaluation training blocked.

Measured local result on the deterministic maximum fixture: +0.30 held-out score, 98.7% planning compression, 100% frontier-call reduction, 66.7% prefix reuse, zero regressions.

## Important boundary

MOSAIC 1.0.0 is a production-oriented **execution-intelligence substrate**, not a claim of general superintelligence. Demonstrating superiority to frontier models requires running the same ECU/route candidates against real held-out environments and frontier baselines. The codebase now provides the necessary training, streaming, verification, routing, evidence, and benchmark interfaces for that external deployment.

## 0.8 architecture delta

0.8 adds three compiler-grade layers:

1. **Agent-program JIT**: dead-node elimination, context common-subexpression elimination, reasoning fusion, capability scheduling, and parallel execution waves.
2. **Trajectory anti-unification**: varying concrete tool arguments become runtime `$param.*` bindings so a single ECU can generalize across a family of tasks.
3. **Inspect log ingestion + ROI skill bank**: `.eval` logs are read through Inspect's official API when installed, and verified ECUs become versioned ROI-aware skills rather than an unstructured collection.

The production path intentionally separates optimized program representations from directly executable ECUs: reasoning fusion is only enabled for representations with an appropriate runtime implementation; the safe ECU compiler leaves fused frontier calls as explicit executable boundaries.

## Frontier comparison

`mosaic frontier-compare` compares a real same-task-set replay against the published Toolathlon-Verified reference snapshot. It intentionally refuses to label local fixtures as a frontier benchmark win. See `docs/FRONTIER_EXECUTION_COMPARISON.md` and `scripts/run_toolathlon_external.sh`.


## Recorded-model comparison

MOSAIC can ingest two evidence classes from GitHub-hosted evaluation projects: (1) real published model outcomes and (2) executable task/verifier artifacts. `mosaic recorded-compare` compares MOSAIC against recorded aggregate model outcomes while refusing incompatible task-count comparisons. Full raw frontier trajectories for Toolathlon/CTI-REALM are hosted outside GitHub; they are not silently treated as if the GitHub repositories contained them.

Example:

```bash
mosaic recorded-compare --benchmark cti-realm-50 --mosaic-score 0.6373 --tasks 50
```

# MOSAIC Ω 3.0.0 — Real GitHub Trajectory Distillation

This release adds a provenance-pinned ingestion path for **actual model execution traces committed to GitHub**, rather than benchmark descriptions alone.

## Verified GitHub trace source

`when2buy/llm-trajectory-data` contains a Git-addressable 123,453-byte JSONL trace at:

`docs/hard-task-traces/all_haiku.trace.jsonl`

Pinned blob SHA:

`6d24773c1303911ea2cfe065524797de502382fc`

Recorded outcome for the run:

- model: `claude-haiku-4-5-20251001-v1:0`
- task: `american-option-fd-new`
- 135 model calls
- 40 / 54 checks passed
- reward: `0.7407407407407407`

MOSAIC distills only **observable execution evidence** from these traces: tool calls, tool arguments, tool-result failures, model/cost metadata and causal ordering. Hidden/private reasoning is explicitly excluded from the compiled capability.

Because this ChatGPT sandbox has no public DNS/HTTP egress, the full remote blob is accessed through the GitHub connector / external-worker adapter rather than copied into the local wheel. The package includes a verified source-derived offline slice for deterministic Gauntlet execution and a bounded streaming remote adapter for the complete blob.

## Real-trace commands

```bash
mosaic github-trace-audit
mosaic github-trace-train examples/frontier_traces/all_haiku_observable_sample.jsonl
mosaic github-trace-gauntlet
```

For a network-enabled worker, the adapter accepts the pinned raw GitHub URL and enforces HTTPS + GitHub-host allowlisting before streaming the JSONL.

## What the first real trace teaches MOSAIC

The trace contains repeated failure→repair transitions including syntax errors, timeouts, missing dependencies and shape/broadcasting failures. MOSAIC compiles these into reusable recovery operators rather than imitating the model's reasoning prose.


## Reasoning Trace Utilization (3.0.1)

MOSAIC 3.0.1 does not discard explicit reasoning traces. It extracts compact, hashed reasoning signals (goal, hypothesis, evidence, decision, uncertainty, expected effect, contradiction, rationale, tool intent, and keywords) and feeds them into trajectory compilation and policy-state selection. Raw reasoning text is isolated behind an explicit `retain_raw_reasoning=True` opt-in for licensed/public datasets and is never placed in the executable observation channel by default.

### Three-view learning (3.0.2)
MOSAIC can learn each trajectory through three independent information channels: reasoning-only, execution-only, and joint reasoning+execution. The joint/fused paths are promoted only when holdout evidence shows benefit over the single-view baselines.

## Ω5 Verified Useful-Work Network

MOSAIC exchanges content-addressed, proof-carrying capabilities rather than raw compute hours. The reference network layer supports local-first capability discovery, adaptive replication, challenge/revocation, Proof-of-Useful-Improvement (PUI), future-compute-avoided accounting, and GPU-last-resort routing.

CLI:

```bash
mosaic network-gauntlet
mosaic network-query repair
```

The included registry is a deterministic transport-neutral reference implementation; production deployments can map the same promotion semantics to a DHT/P2P transport.
