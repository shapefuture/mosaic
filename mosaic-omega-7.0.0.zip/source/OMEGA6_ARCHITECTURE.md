# MOSAIC Ω6 — Ephemeral Multi-Tenant Fabric

Ω6 separates logical agent identity from physical execution. The edge is stateless; state is carried by explicit handles; execution cells are disposable and can be forked. A tier compiler chooses native, WASM, worker, or MicroVM execution based on trust, resources, network needs, and latency.

## Interfaces

- CLI, MCP-shaped JSON-RPC, and future A2A adapters all call the same runtime primitives.
- MCP edge state is explicit; no hidden protocol session is required.
- Tenant policy/quotas are enforced before capability execution.

## Scale model

10,000 logical agents are represented as compact handles; only the active set receives execution cells. Cells can be forked for speculative search and terminated/reaped without destroying durable state.

## Runtime ladder

`native → WASM → worker → MicroVM`

Use the lightest isolated substrate that satisfies the contract. GPU remains governed by the existing economic router and is not an execution-tier default.

## State model

- immutable artifacts: content-addressed storage;
- mergeable collaborative state: CRDT/event adapters;
- authoritative billing/policy/security: transactional store adapters.

The reference implementation is backend-neutral so local, Kubernetes, Firecracker, Cloudflare-style isolate/microVM, and other providers can be attached without changing TaskIR semantics.
