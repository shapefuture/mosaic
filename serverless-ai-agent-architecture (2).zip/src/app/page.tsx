"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { Activity, ArrowRight, Boxes, CheckCircle2, CircleSlash, Cpu, Gauge, Network, ShieldAlert, XCircle, Zap } from "lucide-react";
import { useAos } from "@/lib/client/state";
import { Badge, Btn, Dot, Empty, KV, Meter, Panel, QueueTone, Spark, Stat, Status, Table, Td } from "@/components/ui";
import { cn } from "@/lib/cn";
import { formatMicros, formatTime, relativeTime } from "@/lib/format";

const QUICK_OBJECTIVES = [
  "Research the market for AI agent platforms and produce an executive brief with cited evidence",
  "Extract competitor pricing tables and normalise them to annual USD per seat",
  "Log into the supplier portal, download this month's invoices and reconcile them",
  "Implement and test a billing adapter refactor, then deploy to preview",
  "Triage the shared inbox, route each item and draft replies for approval",
];

export default function ControlPlanePage() {
  const { data, post, busy } = useAos();
  const [objective, setObjective] = useState(QUICK_OBJECTIVES[0]);
  const [launching, setLaunching] = useState(false);
  const [launched, setLaunched] = useState<string | null>(null);

  const footprint = data?.footprint;
  const totals = data?.scheduler?.totals;
  const signals = data?.scheduler?.signals;
  const queues = data?.queues ?? [];
  const events = data?.events ?? [];
  const workUnits = (data?.workUnits ?? []).slice(0, 8);
  const approvals = (data?.approvals ?? []).filter((a: any) => a.status === "pending").slice(0, 5);
  const metrics = data?.metrics ?? [];
  const tiers = data?.tiers ?? [];
  const sessions = data?.sessions ?? {};

  const naiveMb = footprint?.naiveFootprintMb ?? 0;
  const actualMb = footprint?.residentMemoryMb ?? 0;
  const saving = naiveMb > 0 ? Math.round((1 - actualMb / naiveMb) * 100) : 0;
  const costPerDeliverable = totals?.deliverablesAccepted ? totals.costMicros / totals.deliverablesAccepted : 0;
  const deterministicShare = totals?.tasksCompleted ? Math.round((totals.deterministicSteps / totals.tasksCompleted) * 100) : 0;

  const memorySeries = useMemo(() => metrics.map((m: any) => m.residentMemoryMb), [metrics]);
  const taskSeries = useMemo(() => metrics.map((m: any) => m.runningTasks), [metrics]);

  async function launch() {
    if (!objective.trim()) return;
    setLaunching(true);
    try {
      const res = await post("/api/work-units", { objective: objective.trim(), fanOutLimit: 12, budgetMicros: 750_000 });
      setLaunched(res?.workUnit?.id ?? null);
    } finally {
      setLaunching(false);
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="mono text-[10.5px] uppercase tracking-[0.22em] text-cyan">Layer 1–6 · live control plane</p>
          <h1 className="mt-1.5 text-[26px] font-semibold leading-tight tracking-[-0.02em] text-chalk">
            An agent is an identity, not a process.
          </h1>
          <p className="mt-1.5 max-w-3xl text-[13px] leading-relaxed text-mist">
            {footprint?.logicalSessions ?? 0} durable sessions exist right now. {sessions.resident ?? 0} hold compute. The rest cost storage only —
            they wake when work arrives, load a compact context, execute, commit receipts and hibernate again.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Btn size="sm" onClick={() => void post("/api/engine", { action: "tick", ticks: 4 })} disabled={busy}>
            <Zap size={12} /> advance 4 ticks
          </Btn>
          <Link href="/benchmark">
            <Btn size="sm" tone="violet">
              <Gauge size={12} /> run qualification
            </Btn>
          </Link>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat
          label="Logical identities"
          value={data?.agents?.length ?? 0}
          unit="agents"
          tone="violet"
          hint={`${data?.counters?.memoryRecords ?? 0} memory records · ${data?.connectors?.length ?? 0} connectors`}
          sub={<span className="mono text-[11px] text-dim">resident processes per idle agent: 0</span>}
        />
        <Stat
          label="Resident footprint"
          value={actualMb}
          unit="MiB"
          tone="cyan"
          hint={`${saving}% below a process-per-agent design (${Math.round(naiveMb / 1024)} GiB naive)`}
          sub={<Spark points={memorySeries} tone="cyan" height={22} />}
        />
        <Stat
          label="Concurrent tasks"
          value={footprint?.runningTasks ?? 0}
          unit="running"
          tone="blue"
          hint={`${footprint?.pendingTasks ?? 0} queued · p95 ${signals?.p95Ms ?? 0}ms · wait ${signals?.queueWaitMs ?? 0}ms`}
          sub={<Spark points={taskSeries} tone="blue" height={22} />}
        />
        <Stat
          label="Cost per verified deliverable"
          value={costPerDeliverable ? `$${(costPerDeliverable / 1_000_000).toFixed(3)}` : "—"}
          tone="jade"
          hint={`${totals?.deliverablesAccepted ?? 0} accepted · ${totals?.deliverablesRejected ?? 0} rejected by the independent critic`}
          sub={<span className="mono text-[11px] text-dim">{deterministicShare}% of steps needed no model</span>}
        />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.35fr_1fr]">
        <Panel
          title="Launch a Work Unit"
          subtitle="The human defines the outcome. The planner builds a bounded task DAG; the shared pool executes it."
          icon={<Network size={14} className="text-cyan" />}
          right={launched ? <Link href={`/work/${launched}`}><Btn size="sm" tone="jade">open {launched.slice(0, 12)}… <ArrowRight size={11} /></Btn></Link> : undefined}
        >
          <textarea
            value={objective}
            onChange={(e) => setObjective(e.target.value)}
            rows={3}
            className="w-full resize-y rounded-lg border border-line2 bg-abyss px-3 py-2 text-[13px] leading-relaxed text-chalk outline-none transition-colors placeholder:text-dim focus:border-cyan/60"
            placeholder="Describe the outcome you want, e.g. “Compare the top six competitors' pricing and produce a cited brief”"
          />
          <div className="mt-2.5 flex flex-wrap items-center gap-2">
            <Btn onClick={launch} disabled={launching || busy}>
              <Activity size={12} /> {launching ? "planning…" : "plan + execute"}
            </Btn>
            {QUICK_OBJECTIVES.map((q) => (
              <button
                key={q}
                onClick={() => setObjective(q)}
                className={cn(
                  "mono max-w-[280px] truncate rounded-md border px-2 py-1 text-left text-[10.5px] transition-colors",
                  objective === q ? "border-cyan/50 bg-cyan/10 text-cyan" : "border-line bg-panel2 text-dim hover:border-line2 hover:text-mist",
                )}
              >
                {q}
              </button>
            ))}
          </div>
          <div className="mt-3 grid gap-2 border-t border-line pt-3 sm:grid-cols-3">
            <KV k="Execution pattern" v="plan → fan-out → join → verify → commit" />
            <KV k="Fan-out" v="bounded by min(budget, tenant, queue)" />
            <KV k="Verification" v="independent critic, blind to effort" />
          </div>
        </Panel>

        <Panel
          title="Execution tiers"
          subtitle="The biggest saving is avoiding execution entirely."
          icon={<Boxes size={14} className="text-violet" />}
        >
          <div className="space-y-2.5">
            {tiers.map((t: any) => (
              <div key={t.tier} className="rounded-lg border border-line bg-panel2/60 px-3 py-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="mono text-[11.5px] text-chalk">
                    tier {t.tier} · {t.tasks} tasks
                  </span>
                  <Badge tone={t.tier === 0 ? "jade" : t.tier === 1 ? "cyan" : "violet"}>
                    {t.tier === 0 ? "no computer" : t.tier === 1 ? "container" : "isolated"}
                  </Badge>
                </div>
                <div className="mt-2">
                  <Meter value={t.done} max={Math.max(1, t.tasks)} tone={t.tier === 0 ? "jade" : t.tier === 1 ? "cyan" : "violet"} label="completed" right={`${t.done}/${t.tasks}`} />
                </div>
                <p className="mt-1.5 text-[11px] leading-snug text-dim">
                  {t.tier === 0
                    ? "Typed APIs, HTTP, SQL and deterministic functions inside a shared isolate. Nothing boots."
                    : t.tier === 1
                      ? "1/16 vCPU · 256 MiB containers for parsers and transforms. Scale to zero after the task."
                      : "Firecracker microVM (≤5 MiB VMM overhead, ~122 ms boot) and pooled Chromium for untrusted code or authenticated browsing."}
                </p>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1fr_1fr]">
        <Panel
          title="Queue fabric"
          subtitle="Four independent queues so one pathological browser task cannot starve a conversation."
          icon={<Cpu size={14} className="text-blue" />}
          right={<Link href="/scheduler" className="mono text-[11px] text-cyan hover:underline">scheduler →</Link>}
        >
          <div className="grid gap-3 sm:grid-cols-2">
            {queues.map((q: any) => (
              <div key={q.queue} className="rounded-lg border border-line bg-panel2/60 p-3">
                <div className="flex items-center justify-between">
                  <span className="mono flex items-center gap-1.5 text-[11.5px] uppercase tracking-[0.1em] text-chalk">
                    <Dot tone={QueueTone(q.queue)} pulse={q.running > 0} />
                    {q.queue}
                  </span>
                  <span className="mono text-[11px] text-dim">
                    {q.running}/{q.limit}
                  </span>
                </div>
                <div className="mt-2">
                  <Meter value={q.running} max={Math.max(1, q.limit)} tone={QueueTone(q.queue)} />
                </div>
                <div className="mono mt-2 flex flex-wrap gap-x-3 gap-y-1 text-[10.5px] text-dim">
                  <span>ready {q.ready}</span>
                  <span>pending {q.pending}</span>
                  <span>blocked {q.blocked}</span>
                  <span>done {q.done}</span>
                  <span>p95 {q.p95Ms}ms</span>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 rounded-lg border border-line bg-abyss/60 p-3">
            <p className="mono text-[10.5px] uppercase tracking-[0.14em] text-dim">C_allowed = min(provider, tenant, queue, sandbox, budget)</p>
            <div className="mono mt-2 flex flex-wrap gap-2 text-[11px]">
              {Object.entries(data?.scheduler?.limits ?? {}).slice(0, 5).map(([k, v]) => (
                <span key={k} className="rounded-md border border-line2 bg-panel2 px-2 py-1 text-mist">
                  {k} <span className="text-cyan">{String(v)}</span>
                </span>
              ))}
            </div>
          </div>
        </Panel>

        <Panel
          title="Live engine stream"
          subtitle="Only meaningful boundaries are persisted — never a streamed token or a UI event."
          icon={<Activity size={14} className="text-jade" />}
          right={<span className="mono text-[10.5px] text-dim">{data?.scheduler?.tickCount ?? 0} ticks · {signals?.dbWritesPerTask ?? 0} writes/task</span>}
          bodyClass="p-0"
        >
          <div className="max-h-[420px] overflow-y-auto">
            {events.length === 0 && <div className="p-4"><Empty>no events yet — launch a Work Unit</Empty></div>}
            <ul className="divide-y divide-line/60">
              {events.map((ev: any) => (
                <li key={ev.id} className="rise flex items-start gap-2.5 px-4 py-2">
                  <EventIcon type={ev.type} />
                  <div className="min-w-0 flex-1">
                    <p className="mono truncate text-[11px] text-chalk">
                      <span className={cn("mr-1.5", eventTone(ev.type))}>{ev.type}</span>
                      <span className="text-mist">{ev.detail}</span>
                    </p>
                    <p className="mono mt-0.5 text-[10px] text-dim">
                      {relativeTime(ev.at)} · {String(ev.workUnitId).slice(0, 14)}
                      {ev.taskId ? ` · ${String(ev.taskId).slice(0, 12)}` : ""}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </Panel>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.4fr_1fr]">
        <Panel
          title="Work Units in flight"
          subtitle="Durable task graphs. State survives worker loss; completed side effects are reconciled, never repeated."
          icon={<Network size={14} className="text-cyan" />}
          right={<Link href="/work" className="mono text-[11px] text-cyan hover:underline">all work →</Link>}
          bodyClass="p-0"
        >
          {workUnits.length === 0 ? (
            <div className="p-4"><Empty>no work units yet</Empty></div>
          ) : (
            <Table head={["work unit", "template", "status", "progress", "parallelism", "spend", ""]}>
              {workUnits.map((wu: any) => (
                <tr key={wu.id} className="transition-colors hover:bg-white/2">
                  <Td className="max-w-[280px]">
                    <Link href={`/work/${wu.id}`} className="block truncate text-chalk hover:text-cyan">{wu.title}</Link>
                    <span className="mono text-[10px] text-dim">{wu.id}</span>
                  </Td>
                  <Td><Badge tone="violet">{wu.template}</Badge></Td>
                  <Td><Status value={wu.status} /></Td>
                  <Td className="w-[170px]">
                    <Meter value={wu.doneCount} max={Math.max(1, wu.taskCount)} tone={wu.status === "completed" ? "jade" : "cyan"} right={`${wu.doneCount}/${wu.taskCount}`} />
                  </Td>
                  <Td className="mono">{wu.maxParallelismObserved}×</Td>
                  <Td className="mono">{formatMicros(wu.spentMicros)}</Td>
                  <Td>
                    <Link href={`/work/${wu.id}`}><Btn size="sm">inspect</Btn></Link>
                  </Td>
                </tr>
              ))}
            </Table>
          )}
        </Panel>

        <div className="space-y-4">
          <Panel
            title="Approval center"
            subtitle="Agents request; humans authorize. No consequential side effect runs without a recorded decision."
            icon={<ShieldAlert size={14} className="text-amber" />}
            bodyClass="p-0"
          >
            {approvals.length === 0 ? (
              <div className="p-4"><Empty>nothing awaiting authorization</Empty></div>
            ) : (
              <ul className="divide-y divide-line/60">
                {approvals.map((a: any) => (
                  <li key={a.id} className="px-4 py-2.5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="mono text-[11.5px] text-chalk">{a.action}</p>
                        <p className="mt-0.5 text-[11px] leading-snug text-mist">{a.reason}</p>
                        <p className="mono mt-1 text-[10px] text-dim">
                          risk {a.risk} · {formatTime(a.createdAt)} · {String(a.workUnitId).slice(0, 14)}
                        </p>
                      </div>
                      <div className="flex shrink-0 gap-1.5">
                        <Btn size="sm" tone="jade" disabled={busy} onClick={() => void post(`/api/approvals/${a.id}`, { decision: "approved", note: "authorized from control plane", decidedBy: "operator" })}>
                          <CheckCircle2 size={12} /> approve
                        </Btn>
                        <Btn size="sm" tone="rose" disabled={busy} onClick={() => void post(`/api/approvals/${a.id}`, { decision: "denied", note: "out of scope for this run", decidedBy: "operator" })}>
                          <XCircle size={12} /> deny
                        </Btn>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Panel>

          <Panel title="Scheduler decisions" subtitle="Feedback control: concurrency follows observed latency, memory, error rate and provider quotas." icon={<CircleSlash size={14} className="text-blue" />} bodyClass="p-0">
            <ul className="max-h-[220px] divide-y divide-line/60 overflow-y-auto">
              {(data?.scheduler?.decisions ?? []).slice(0, 10).map((d: string, i: number) => (
                <li key={i} className="mono px-4 py-2 text-[11px] leading-snug text-mist">
                  <span className="mr-2 text-cyan">▸</span>
                  {d}
                </li>
              ))}
              {(data?.scheduler?.decisions ?? []).length === 0 && <li className="p-4"><Empty>no adaptations yet</Empty></li>}
            </ul>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function eventTone(type: string): string {
  if (type.includes("denied") || type.includes("failed") || type.includes("injection") || type.includes("429")) return "text-rose";
  if (type.includes("completed") || type.includes("committed") || type.includes("granted") || type.includes("stored")) return "text-jade";
  if (type.includes("approval") || type.includes("budget")) return "text-amber";
  if (type.includes("model") || type.includes("cache")) return "text-violet";
  if (type.includes("browser") || type.includes("credential")) return "text-blue";
  return "text-cyan";
}

function EventIcon({ type }: { type: string }) {
  const cls = "mt-0.5 shrink-0";
  if (type.includes("denied") || type.includes("injection")) return <ShieldAlert size={13} className={cn(cls, "text-rose")} />;
  if (type.includes("completed") || type.includes("granted")) return <CheckCircle2 size={13} className={cn(cls, "text-jade")} />;
  if (type.includes("failed") || type.includes("retry")) return <XCircle size={13} className={cn(cls, "text-rose")} />;
  if (type.includes("browser")) return <Gauge size={13} className={cn(cls, "text-blue")} />;
  return <Dot tone="cyan" />;
}
