import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { agents, approvals, auditLog, capabilityTokens, receipts } from "@/db/schema";
import { fail, json, readBody } from "@/lib/api";
import { POLICY_LIBRARY, authorize, brokerCredential, mintCapability, scanUntrusted } from "@/lib/engine/authority";

export const dynamic = "force-dynamic";

export const INVARIANTS = [
  {
    id: "I1",
    statement: "The model never receives the underlying secret required to authorize an external action.",
    enforcement: "Credential broker injects at the tool gateway; the model sees vault:// references only.",
  },
  {
    id: "I2",
    statement: "A webpage, email or other untrusted input cannot change governing permissions.",
    enforcement: "Untrusted content is scanned and quarantined as data; the permission set is frozen for the turn.",
  },
  {
    id: "I3",
    statement: "No child task can have more authority than its parent.",
    enforcement: "Delegation depth and scope attenuation are checked before every dispatch.",
  },
];

export async function GET() {
  const [tokens, audit, agentRows, counts, approvalCounts, receiptCounts] = await Promise.all([
    db.select().from(capabilityTokens).orderBy(desc(capabilityTokens.createdAt)).limit(30),
    db.select().from(auditLog).orderBy(desc(auditLog.at)).limit(60),
    db.select({ id: agents.id, name: agents.name, role: agents.role }).from(agents),
    db
      .select({
        denied: sql<number>`count(*) filter (where result = 'denied')::int`,
        blocked: sql<number>`count(*) filter (where result = 'blocked')::int`,
        total: sql<number>`count(*)::int`,
      })
      .from(auditLog),
    db
      .select({ pending: sql<number>`count(*) filter (where status = 'pending')::int`, approved: sql<number>`count(*) filter (where status = 'approved')::int`, denied: sql<number>`count(*) filter (where status = 'denied')::int` })
      .from(approvals),
    db.select({ total: sql<number>`count(*)::int`, replayed: sql<number>`count(*) filter (where replayed)::int` }).from(receipts),
  ]);
  const byId = new Map(agentRows.map((a) => [a.id, a]));
  return json({
    invariants: INVARIANTS,
    policies: POLICY_LIBRARY,
    tokens: tokens.map((t) => ({ ...t, agent: t.agentId ? byId.get(t.agentId) ?? null : null, signature: `${t.signature.slice(0, 10)}…` })),
    audit: audit.map((a) => ({ ...a, actorName: byId.get(a.actor)?.name ?? a.actor })),
    counts: {
      denied: counts[0]?.denied ?? 0,
      blocked: counts[0]?.blocked ?? 0,
      auditEntries: counts[0]?.total ?? 0,
      approvalsPending: approvalCounts[0]?.pending ?? 0,
      approvalsGranted: approvalCounts[0]?.approved ?? 0,
      approvalsDenied: approvalCounts[0]?.denied ?? 0,
      receipts: receiptCounts[0]?.total ?? 0,
      reconciledReplays: receiptCounts[0]?.replayed ?? 0,
    },
  });
}

export async function POST(req: Request) {
  const body = await readBody<{
    action?: string;
    content?: string;
    request?: {
      agentId?: string;
      action?: string;
      resource?: string;
      domain?: string;
      estimatedCostMicros?: number;
      delegationDepth?: number;
      untrusted?: boolean;
    };
    mint?: { agentId?: string; actions?: string[]; resources?: string[]; domains?: string[]; maxCostMicros?: number; ttlSeconds?: number };
  }>(req);

  const action = body.action ?? "evaluate";

  if (action === "scan") {
    if (!body.content) return fail("content is required");
    const scan = scanUntrusted(body.content);
    return json({ ok: true, ...scan, invariant: "I2", note: scan.quarantine ? "Quarantined as data. Permissions unchanged." : "No known injection patterns." });
  }

  if (action === "mint") {
    const mint = body.mint;
    if (!mint?.agentId) return fail("mint.agentId is required");
    const token = await mintCapability({ ...mint, agentId: mint.agentId });
    return json({ ok: true, token }, 201);
  }

  if (action === "broker") {
    const credential = brokerCredential(body.request?.action ?? "http.get", body.request?.resource ?? body.request?.domain);
    return json({ ok: true, credential, invariant: "I1" });
  }

  if (!body.request?.agentId || !body.request?.action) return fail("request.agentId and request.action are required");
  const decision = await authorize({
    agentId: body.request.agentId,
    action: body.request.action,
    resource: body.request.resource,
    domain: body.request.domain,
    estimatedCostMicros: body.request.estimatedCostMicros,
    delegationDepth: body.request.delegationDepth,
    untrusted: body.request.untrusted,
  });
  const token = decision.tokenId ? (await db.select().from(capabilityTokens).where(eq(capabilityTokens.id, decision.tokenId)).limit(1))[0] : null;
  return json({ ok: true, decision, token: token ? { ...token, signature: `${token.signature.slice(0, 10)}…` } : null });
}
