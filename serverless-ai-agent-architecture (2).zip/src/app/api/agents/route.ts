import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { agents, memories, organizations, sessions, tasks } from "@/db/schema";
import { fail, json, readBody } from "@/lib/api";
import { mintCapability } from "@/lib/engine/authority";
import { uid } from "@/lib/engine/util";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(agents).orderBy(agents.department, agents.name);
  const enriched = await Promise.all(
    rows.map(async (agent) => {
      const [sessionAgg] = await db
        .select({
          total: sql<number>`count(*)::int`,
          resident: sql<number>`count(*) filter (where state = 'resident')::int`,
          hibernated: sql<number>`count(*) filter (where state in ('hibernated','evicted'))::int`,
        })
        .from(sessions)
        .where(eq(sessions.agentId, agent.id));
      const [taskAgg] = await db
        .select({ running: sql<number>`count(*) filter (where status = 'running')::int`, done: sql<number>`count(*) filter (where status = 'done')::int` })
        .from(tasks)
        .where(eq(tasks.assignedAgentId, agent.id));
      const [memAgg] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(memories)
        .where(eq(memories.agentId, agent.id));
      return {
        ...agent,
        sessions: { total: sessionAgg?.total ?? 0, resident: sessionAgg?.resident ?? 0, hibernated: sessionAgg?.hibernated ?? 0 },
        workload: { running: taskAgg?.running ?? 0, done: taskAgg?.done ?? 0 },
        memoryRecords: memAgg?.n ?? 0,
        costPerAccepted: agent.acceptedDeliverables ? Math.round((agent.spentCents * 10000) / agent.acceptedDeliverables) : 0,
      };
    }),
  );
  return json({ agents: enriched });
}

/** Create a specialist agent: an identity + capability manifest, never a new service. */
export async function POST(req: Request) {
  const body = await readBody<{
    name?: string;
    role?: string;
    department?: string;
    capabilities?: string[];
    template?: string;
    maxCostMicros?: number;
    domains?: string[];
  }>(req);

  if (!body.name || !body.role) return fail("name and role are required");
  const org = (await db.select().from(organizations).limit(1))[0];
  if (!org) return fail("no organization seeded", 500);

  const id = `agt_${uid("x").slice(2, 10)}`;
  const template = TEMPLATES[body.template ?? "specialist"] ?? TEMPLATES.specialist;
  const capabilities = body.capabilities?.length ? body.capabilities : template.capabilities;
  const authority = {
    actions: template.actions,
    resources: [`workunit:*`, `project:${org.id}`, "session:*", "memory:*"],
    domains: body.domains?.length ? body.domains : template.domains,
    maxCostMicros: body.maxCostMicros ?? template.maxCostMicros,
    maxDelegationDepth: template.maxDelegationDepth,
    requiresApproval: template.requiresApproval,
  };

  await db.insert(agents).values({
    id,
    orgId: org.id,
    name: body.name,
    role: body.role,
    department: body.department ?? template.department,
    capabilities,
    skills: template.skills,
    modelPolicy: template.modelPolicy as never,
    authorityPolicy: authority as never,
    memoryScope: template.memoryScope,
    budgetCents: 5000,
    status: "hibernating",
    residentMemoryMb: 0,
  });

  await mintCapability({
    agentId: id,
    actions: authority.actions,
    resources: authority.resources,
    domains: authority.domains,
    maxCostMicros: authority.maxCostMicros,
    delegationDepth: 0,
    ttlSeconds: 86400,
  });

  const created = (await db.select().from(agents).where(eq(agents.id, id)).limit(1))[0];
  return json({ ok: true, agent: created, note: "Identity registered. No process, computer or model is resident until work arrives." }, 201);
}

const TEMPLATES: Record<
  string,
  {
    department: string;
    capabilities: string[];
    actions: string[];
    domains: string[];
    maxCostMicros: number;
    maxDelegationDepth: number;
    requiresApproval: string[];
    memoryScope: string;
    modelPolicy: Record<string, string>;
    skills: { name: string; version: string; source: string; verified: boolean }[];
  }
> = {
  specialist: {
    department: "research",
    capabilities: ["http.get", "extract", "data.write"],
    actions: ["http.get", "data.write", "memory.read", "compute.run", "workunit.plan", "workunit.commit"],
    domains: ["*.example"],
    maxCostMicros: 250000,
    maxDelegationDepth: 1,
    requiresApproval: ["message.send"],
    memoryScope: "agent",
    modelPolicy: { planning: "balanced", extraction: "fast", synthesis: "balanced", vision: "vision", coding: "coding" },
    skills: [{ name: "role-template/specialist", version: "1.0.0", source: "catalog", verified: true }],
  },
  engineer: {
    department: "engineering",
    capabilities: ["sandbox.exec", "code", "compute.run", "data.write"],
    actions: ["sandbox.exec", "compute.run", "data.write", "http.get", "workunit.commit", "deploy.preview"],
    domains: ["registry.npmjs.org", "*.example"],
    maxCostMicros: 900000,
    maxDelegationDepth: 2,
    requiresApproval: ["deploy.preview"],
    memoryScope: "agent",
    modelPolicy: { planning: "reasoning", extraction: "fast", synthesis: "balanced", vision: "vision", coding: "coding" },
    skills: [{ name: "cow-workspace-fork", version: "1.0.0", source: "catalog", verified: true }],
  },
  operator: {
    department: "operations",
    capabilities: ["browser", "http.get", "data.write"],
    actions: ["browser.session", "browser.read", "browser.write", "browser.login", "http.get", "data.write", "workunit.plan", "workunit.commit"],
    domains: ["portal.example", "*.example"],
    maxCostMicros: 300000,
    maxDelegationDepth: 1,
    requiresApproval: ["browser.login", "browser.live-view"],
    memoryScope: "agent",
    modelPolicy: { planning: "balanced", extraction: "fast", synthesis: "balanced", vision: "vision", coding: "coding" },
    skills: [{ name: "playwright-cdp-flows", version: "4.2.0", source: "catalog", verified: true }],
  },
  critic: {
    department: "quality",
    capabilities: ["verification", "data.write", "memory.read"],
    actions: ["data.write", "memory.read", "audit.read", "workunit.commit"],
    domains: [],
    maxCostMicros: 200000,
    maxDelegationDepth: 0,
    requiresApproval: [],
    memoryScope: "org",
    modelPolicy: { planning: "reasoning", extraction: "balanced", synthesis: "reasoning", vision: "vision", coding: "coding" },
    skills: [{ name: "blind-comparison", version: "3.0.1", source: "catalog", verified: true }],
  },
};

export const ROLE_TEMPLATES = Object.keys(TEMPLATES);
