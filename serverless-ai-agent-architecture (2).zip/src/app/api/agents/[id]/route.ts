import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { agents, capabilityTokens, memories, receipts, sessions, tasks, workUnits } from "@/db/schema";
import { fail, json } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const agent = (await db.select().from(agents).where(eq(agents.id, id)).limit(1))[0];
  if (!agent) return fail("agent not found", 404);

  const [agentSessions, agentTasks, agentWork, agentMemories, tokens, agentReceipts, subordinates] = await Promise.all([
    db.select().from(sessions).where(eq(sessions.agentId, id)).orderBy(desc(sessions.lastActiveAt)).limit(40),
    db.select().from(tasks).where(eq(tasks.assignedAgentId, id)).orderBy(desc(tasks.createdAt)).limit(60),
    db.select().from(workUnits).where(eq(workUnits.ownerAgentId, id)).orderBy(desc(workUnits.createdAt)).limit(30),
    db.select().from(memories).where(eq(memories.agentId, id)).orderBy(desc(memories.createdAt)).limit(40),
    db.select().from(capabilityTokens).where(eq(capabilityTokens.agentId, id)).orderBy(desc(capabilityTokens.createdAt)).limit(20),
    db.select().from(receipts).where(eq(receipts.agentId, id)).orderBy(desc(receipts.at)).limit(30),
    db.select().from(agents).where(eq(agents.reportsTo, id)).limit(20),
  ]);

  const [agg] = await db
    .select({
      tasksDone: sql<number>`count(*) filter (where status = 'done')::int`,
      tasksFailed: sql<number>`count(*) filter (where status = 'failed')::int`,
      cost: sql<number>`coalesce(sum(cost_micros),0)::int`,
      tokens: sql<number>`coalesce(sum(tokens_in + tokens_out),0)::int`,
      deterministic: sql<number>`count(*) filter (where status = 'done' and needs_model = false)::int`,
    })
    .from(tasks)
    .where(eq(tasks.assignedAgentId, id));

  return json({
    agent,
    sessions: agentSessions,
    tasks: agentTasks,
    workUnits: agentWork,
    memories: agentMemories,
    tokens,
    receipts: agentReceipts,
    subordinates,
    stats: {
      tasksDone: agg?.tasksDone ?? 0,
      tasksFailed: agg?.tasksFailed ?? 0,
      costMicros: agg?.cost ?? 0,
      tokens: agg?.tokens ?? 0,
      deterministicSteps: agg?.deterministic ?? 0,
      acceptanceRate: agent.completedWorkUnits ? Math.round((agent.acceptedDeliverables / agent.completedWorkUnits) * 100) : 0,
    },
  });
}
