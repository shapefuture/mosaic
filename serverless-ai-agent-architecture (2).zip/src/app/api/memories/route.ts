import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { memories, organizations } from "@/db/schema";
import { fail, json, readBody } from "@/lib/api";
import { addMemory, memoryStats, searchMemory } from "@/lib/engine/memory";
import type { MemoryKind } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const org = (await db.select().from(organizations).limit(1))[0];
  if (!org) return fail("no organization", 500);
  const q = url.searchParams.get("q");
  const kind = url.searchParams.get("kind") as MemoryKind | null;
  const stats = await memoryStats(org.id);
  if (q) {
    const hits = await searchMemory({ query: q, orgId: org.id, topK: Number(url.searchParams.get("topK") ?? 8), kind: kind ?? undefined });
    return json({ query: q, stats, results: hits.map((h) => ({ ...h.memory, score: h.score })) });
  }
  const rows = await db.select().from(memories).where(eq(memories.orgId, org.id)).orderBy(desc(memories.createdAt)).limit(300);
  return json({ stats, memories: rows });
}

export async function POST(req: Request) {
  const body = await readBody<{ action?: string; query?: string; topK?: number; kind?: MemoryKind; subject?: string; content?: string; agentId?: string | null }>(req);
  const org = (await db.select().from(organizations).limit(1))[0];
  if (!org) return fail("no organization", 500);

  if (body.action === "add") {
    if (!body.subject || !body.content) return fail("subject and content are required");
    const id = await addMemory({
      orgId: org.id,
      agentId: body.agentId ?? null,
      kind: body.kind ?? "semantic",
      subject: body.subject,
      content: body.content,
      trust: "candidate",
      provenance: { method: "operator" },
    });
    const created = (await db.select().from(memories).where(eq(memories.id, id)).limit(1))[0];
    return json({ ok: true, memory: created }, 201);
  }

  if (!body.query) return fail("query is required");
  const hits = await searchMemory({ query: body.query, orgId: org.id, topK: body.topK ?? 8, kind: body.kind });
  return json({
    query: body.query,
    results: hits.map((h) => ({ ...h.memory, score: h.score })),
    method: "cosine over stored vectors + lexical overlap + scope/trust bonus (in-Postgres; pgvector in production)",
  });
}
