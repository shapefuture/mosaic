import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { agents, auditLog, browserContexts, browserSessions } from "@/db/schema";
import { fail, json, readBody } from "@/lib/api";
import {
  acquireContext,
  contextAct,
  endTakeover,
  poolStats,
  recycleUnhealthy,
  releaseContext,
  requestTakeover,
} from "@/lib/engine/browser";
import { uid } from "@/lib/engine/util";

export const dynamic = "force-dynamic";

export async function GET() {
  const stats = await poolStats();
  const contexts = await db.select().from(browserContexts).where(eq(browserContexts.state, "open")).orderBy(desc(browserContexts.lastActionAt)).limit(40);
  const agentRows = await db.select({ id: agents.id, name: agents.name, role: agents.role }).from(agents);
  const byId = new Map(agentRows.map((a) => [a.id, a]));
  return json({
    ...stats,
    openContexts: contexts.map((c) => ({ ...c, agent: c.agentId ? byId.get(c.agentId) ?? null : null, liveViewToken: null })),
    processes: stats.browsers,
  });
}

export async function POST(req: Request) {
  const body = await readBody<{
    action?: string;
    contextId?: string;
    agentId?: string;
    domain?: string;
    label?: string;
    url?: string;
    title?: string;
    operator?: string;
  }>(req);
  const action = body.action ?? "stats";

  if (action === "recycle") {
    const n = await recycleUnhealthy(0);
    return json({ ok: true, recycled: n });
  }

  if (action === "open") {
    const ctx = await acquireContext({ agentId: body.agentId ?? null, domain: body.domain ?? "portal.example", label: body.label ?? "manual session" });
    if (body.url) await contextAct(ctx.contextId, { url: body.url, title: body.title });
    return json({ ok: true, ...ctx }, 201);
  }

  if (action === "navigate") {
    if (!body.contextId) return fail("contextId is required");
    const tabs = await contextAct(body.contextId, { url: body.url, title: body.title, memoryMb: 24 });
    return json({ ok: true, tabs });
  }

  if (action === "takeover") {
    if (!body.contextId) return fail("contextId is required");
    const result = await requestTakeover(body.contextId, body.operator ?? "operator");
    await db.insert(auditLog).values({
      id: uid("aud"),
      actor: body.operator ?? "operator",
      action: "browser.live-view-issued",
      subject: body.contextId,
      result: "issued",
      severity: "warning",
      detail: { note: "bearer credential issued to an authenticated human; not exposed to any model" },
    });
    return json({ ok: true, ...result });
  }

  if (action === "end-takeover") {
    if (!body.contextId) return fail("contextId is required");
    await endTakeover(body.contextId);
    return json({ ok: true, resumed: true });
  }

  if (action === "close") {
    if (!body.contextId) return fail("contextId is required");
    await releaseContext(body.contextId);
    return json({ ok: true, closed: body.contextId });
  }

  const browsers = await db.select().from(browserSessions);
  return json({ ok: true, browsers });
}
