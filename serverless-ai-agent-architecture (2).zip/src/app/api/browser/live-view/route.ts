import { eq } from "drizzle-orm";
import { db } from "@/db";
import { browserContexts, browserSessions } from "@/db/schema";

export const dynamic = "force-dynamic";

/**
 * Human takeover surface. The token in the URL is a bearer credential: whoever holds it
 * controls this browser and every site it is logged into. It is validated here, never
 * passed to a model, and never written into task data.
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const ctxId = url.searchParams.get("ctx");
  const token = url.searchParams.get("t");
  if (!ctxId || !token) return page(403, "Missing credentials", "A Live View link requires both a context id and its bearer token.");

  const rows = await db.select().from(browserContexts).where(eq(browserContexts.id, ctxId)).limit(1);
  const ctx = rows[0];
  if (!ctx || ctx.liveViewToken !== token) {
    return page(403, "Token rejected", "This Live View token is invalid, expired or already revoked. The browser session was not exposed.");
  }
  const browser = (await db.select().from(browserSessions).where(eq(browserSessions.id, ctx.browserId)).limit(1))[0];

  const tabs = ctx.tabs
    .map(
      (t) => `<li><span class="tab">${escape(t.title)}</span><code>${escape(t.url)}</code><em>${escape(t.state)}</em></li>`,
    )
    .join("");

  const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8" /><meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Live View — ${escape(ctx.label)}</title>
<style>
  :root { color-scheme: dark; }
  body { margin:0; background:#05070d; color:#dbe6f5; font:14px/1.55 ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif; }
  .wrap { max-width: 900px; margin: 0 auto; padding: 28px 20px 60px; }
  .warn { border:1px solid #7f1d1d; background:#1a0b0b; color:#fecaca; padding:12px 14px; border-radius:10px; font-size:13px; }
  h1 { font-size:20px; margin:18px 0 4px; letter-spacing:-0.01em; }
  .meta { color:#7f93b2; font-size:12px; text-transform:uppercase; letter-spacing:0.12em; }
  .frame { margin-top:18px; border:1px solid #1d2b45; border-radius:14px; overflow:hidden; background:#080d18; }
  .bar { display:flex; gap:8px; align-items:center; padding:10px 12px; background:#0c1322; border-bottom:1px solid #1d2b45; }
  .dot { width:9px; height:9px; border-radius:50%; background:#22314d; }
  .dot.live { background:#22d3ee; box-shadow:0 0 10px #22d3ee88; }
  .addr { flex:1; font-family:ui-monospace,SFMono-Regular,Menlo,monospace; font-size:12px; color:#9fb4d4; background:#070c16; border:1px solid #1b2740; border-radius:8px; padding:6px 9px; }
  .canvas { padding:22px; min-height:220px; }
  ul { list-style:none; padding:0; margin:14px 0 0; display:grid; gap:8px; }
  li { display:grid; grid-template-columns:190px 1fr 90px; gap:10px; align-items:center; border:1px solid #16223a; border-radius:10px; padding:9px 12px; background:#0a1120; }
  .tab { font-weight:600; color:#e6f0ff; }
  code { color:#7dd3fc; font-size:12px; }
  em { color:#64748b; font-style:normal; font-size:11px; text-transform:uppercase; letter-spacing:.08em; text-align:right; }
  .foot { margin-top:22px; color:#64748b; font-size:12px; }
  a { color:#67e8f9; }
</style></head>
<body><div class="wrap">
  <div class="warn"><strong>Bearer credential.</strong> Anyone holding this URL can drive this browser and every site it is authenticated to. It is issued only to authorized humans, is never given to a model, and is never stored as task data.</div>
  <p class="meta">Live View · human takeover active</p>
  <h1>${escape(ctx.label)}</h1>
  <p class="meta">context ${escape(ctx.id)} · process ${escape(browser?.label ?? "unknown")} · ${browser?.tabCount ?? 0}/${browser?.maxTabs ?? 6} tabs · ${Math.round(browser?.processMemoryMb ?? 0)} MiB</p>
  <div class="frame">
    <div class="bar"><span class="dot live"></span><span class="dot"></span><span class="dot"></span><span class="addr">${escape(ctx.tabs[ctx.tabs.length - 1]?.url ?? "about:blank")}</span><span class="addr" style="max-width:180px">${ctx.authenticated ? "authenticated session" : "anonymous session"}</span></div>
    <div class="canvas">
      <div>You are now driving the same Chromium process the agent is using. Complete the login or MFA challenge here; the agent resumes with your cookies and storage intact.</div>
      <ul>${tabs || "<li><span class='tab'>no tabs</span><code>about:blank</code><em>idle</em></li>"}</ul>
    </div>
  </div>
  <p class="foot">Return to the <a href="/browser">browser pool</a> and end the takeover so the agent can resume. The context stays isolated: no other agent identity can read these cookies.</p>
</div></body></html>`;
  return new Response(html, { status: 200, headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
}

function escape(input: string) {
  return input.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] ?? c);
}

function page(status: number, title: string, message: string) {
  const html = `<!doctype html><html><head><meta charset="utf-8" /><title>${title}</title>
  <style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#05070d;color:#dbe6f5;font:15px/1.6 ui-sans-serif,system-ui,sans-serif}
  .card{max-width:520px;border:1px solid #7f1d1d;background:#12090c;border-radius:14px;padding:26px}h1{font-size:19px;margin:0 0 8px;color:#fecaca}p{color:#a8b6cc;margin:0}a{color:#67e8f9}</style>
  </head><body><div class="card"><h1>${status} · ${title}</h1><p>${message}</p><p style="margin-top:14px"><a href="/browser">Back to the browser pool</a></p></div></body></html>`;
  return new Response(html, { status, headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
}
