import { desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  agents,
  approvals,
  artifacts,
  auditLog,
  benchmarkRuns,
  capabilityTokens,
  deliverySlices,
  memories,
  metricsSamples,
  models,
  organizations,
  receipts,
  sandboxes,
  schedules,
  sessions,
  taskEvents,
  tasks,
  workUnits,
} from "@/db/schema";
import { json, singleFlightTick } from "@/lib/api";
import { computeFootprint, getScheduler, tick } from "@/lib/engine/scheduler";
import { memoryStats } from "@/lib/engine/memory";
import { poolStats } from "@/lib/engine/browser";
import { seedIfEmpty } from "@/lib/engine/seed";
import { cacheStats } from "@/lib/engine/router";

export const dynamic = "force-dynamic";

/**
 * One aggregated snapshot for the control plane. The client polls this endpoint;
 * polling also drives the engine forward (the scheduler has no daemon — state is durable).
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const advance = url.searchParams.get("tick") !== "0";

  await seedIfEmpty();
  const summary = advance ? await singleFlightTick(() => tick()) : null;
  const sched = await getScheduler();
  const org = (await db.select().from(organizations).limit(1))[0];

  const [
    footprint,
    agentRows,
    sessionRows,
    workUnitRows,
    taskRows,
    approvalRows,
    eventRows,
    metricRows,
    modelRows,
    browser,
    sandboxRows,
    connectorless,
    scheduleRows,
    sliceRows,
    benchRows,
    receiptCount,
    artifactCount,
    deniedCount,
  ] = await Promise.all([
    computeFootprint(),
    db.select().from(agents),
    db.select().from(sessions).orderBy(desc(sessions.lastActiveAt)).limit(400),
    db.select().from(workUnits).orderBy(desc(workUnits.createdAt)).limit(60),
    db.select().from(tasks).orderBy(desc(tasks.createdAt)).limit(400),
    db.select().from(approvals).orderBy(desc(approvals.createdAt)).limit(40),
    db.select().from(taskEvents).orderBy(desc(taskEvents.at)).limit(60),
    db.select().from(metricsSamples).orderBy(desc(metricsSamples.at)).limit(120),
    db.select().from(models),
    poolStats(),
    db.select().from(sandboxes),
    memoryStats(org?.id ?? "org_northwind"),
    db.select().from(schedules),
    db.select().from(deliverySlices).orderBy(sql`step`),
    db.select().from(benchmarkRuns).orderBy(desc(benchmarkRuns.createdAt)).limit(12),
    db.select({ n: sql<number>`count(*)::int` }).from(receipts),
    db.select({ n: sql<number>`count(*)::int` }).from(artifacts),
    db.select({ n: sql<number>`count(*)::int` }).from(auditLog).where(eq(auditLog.result, "denied")),
  ]);

  const queueBreakdown = (["interactive", "io", "compute", "browser"] as const).map((q) => ({
    queue: q,
    ...sched.concurrency[q],
    running: taskRows.filter((t) => t.queue === q && t.status === "running").length,
    pending: taskRows.filter((t) => t.queue === q && t.status === "pending").length,
    ready: taskRows.filter((t) => t.queue === q && t.status === "ready").length,
    blocked: taskRows.filter((t) => t.queue === q && t.status === "blocked").length,
    done: taskRows.filter((t) => t.queue === q && t.status === "done").length,
  }));

  const tierBreakdown = [0, 1, 2].map((tier) => ({
    tier,
    tasks: taskRows.filter((t) => t.tier === tier).length,
    done: taskRows.filter((t) => t.tier === tier && t.status === "done").length,
    sandboxes: sandboxRows.filter((s) => s.tier === tier).length,
    running: sandboxRows.filter((s) => s.tier === tier && s.state === "running").length,
  }));

  return json({
    tick: summary,
    scheduler: {
      running: sched.running,
      tickCount: sched.tickCount,
      lastTickAt: sched.lastTickAt,
      concurrency: sched.concurrency,
      limits: sched.limits,
      signals: sched.signals,
      totals: sched.totals,
      decisions: sched.decisions,
    },
    organization: org,
    footprint,
    queues: queueBreakdown,
    tiers: tierBreakdown,
    agents: agentRows,
    sessions: {
      rows: sessionRows.slice(0, 60),
      total: sessionRows.length,
      resident: sessionRows.filter((s) => s.state === "resident").length,
      hibernated: sessionRows.filter((s) => s.state === "hibernated").length,
      evicted: sessionRows.filter((s) => s.state === "evicted").length,
      wakes: sessionRows.reduce((a, s) => a + s.wakes, 0),
      recoveries: sessionRows.reduce((a, s) => a + s.recoveries, 0),
      storageMb: Math.round(sessionRows.reduce((a, s) => a + s.storageBytes, 0) / (1024 * 1024)),
    },
    workUnits: workUnitRows,
    tasks: {
      rows: taskRows.slice(0, 120),
      counts: {
        pending: taskRows.filter((t) => t.status === "pending").length,
        ready: taskRows.filter((t) => t.status === "ready").length,
        running: taskRows.filter((t) => t.status === "running").length,
        done: taskRows.filter((t) => t.status === "done").length,
        failed: taskRows.filter((t) => t.status === "failed").length,
        blocked: taskRows.filter((t) => t.status === "blocked").length,
      },
    },
    approvals: approvalRows,
    events: eventRows,
    metrics: metricRows.reverse(),
    models: modelRows,
    browser,
    sandboxes: sandboxRows,
    memory: connectorless,
    schedules: scheduleRows,
    delivery: sliceRows,
    benchmarks: benchRows,
    counters: {
      receipts: receiptCount[0]?.n ?? 0,
      artifacts: artifactCount[0]?.n ?? 0,
      denied: deniedCount[0]?.n ?? 0,
      memoryRecords: connectorless.total,
      gatewayCache: cacheStats(),
    },
  });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { workUnitId?: string };
  if (body.workUnitId) {
    const rows = await db.select().from(workUnits).where(eq(workUnits.id, body.workUnitId)).limit(1);
    const wu = rows[0];
    if (!wu) return json({ error: "not found" }, 404);
    const taskRows = await db.select().from(tasks).where(eq(tasks.workUnitId, wu.id));
    const events = await db.select().from(taskEvents).where(eq(taskEvents.workUnitId, wu.id)).orderBy(desc(taskEvents.at)).limit(200);
    const arts = await db.select().from(artifacts).where(eq(artifacts.workUnitId, wu.id)).orderBy(desc(artifacts.createdAt));
    const rcpts = await db.select().from(receipts).where(eq(receipts.workUnitId, wu.id)).orderBy(desc(receipts.at));
    const tokens = await db.select().from(capabilityTokens).where(eq(capabilityTokens.workUnitId, wu.id));
    return json({ workUnit: wu, tasks: taskRows, events: events.reverse(), artifacts: arts, receipts: rcpts, tokens });
  }
  const running = await db.select().from(tasks).where(inArray(tasks.status, ["running", "ready", "pending"])).limit(200);
  return json({ tasks: running });
}
