import { desc } from "drizzle-orm";
import { db } from "@/db";
import { benchmarkRuns } from "@/db/schema";
import { fail, json, readBody, singleFlightTick } from "@/lib/api";
import { SCENARIOS, cleanupBenchmarkData, runScenario, type ScenarioId } from "@/lib/engine/benchmark";
import { tick } from "@/lib/engine/scheduler";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function GET() {
  const runs = await db.select().from(benchmarkRuns).orderBy(desc(benchmarkRuns.createdAt)).limit(30);
  return json({ scenarios: SCENARIOS, runs });
}

export async function POST(req: Request) {
  const body = await readBody<{ scenario?: ScenarioId | "all"; cleanup?: boolean }>(req);
  if (body.cleanup) {
    await cleanupBenchmarkData();
    return json({ ok: true, cleaned: true });
  }
  const requested = body.scenario ?? "all";
  const ids: ScenarioId[] = requested === "all" ? SCENARIOS.map((s) => s.id) : [requested];
  if (!ids.every((id) => SCENARIOS.some((s) => s.id === id))) return fail("unknown scenario");

  const results = [];
  for (const id of ids) {
    results.push(await runScenario(id));
    await singleFlightTick(() => tick());
  }
  const passed = results.every((r) => r.checks.every((c) => c.passed));
  return json({ ok: true, passed, results, hardAcceptance: HARD_ACCEPTANCE });
}

export const HARD_ACCEPTANCE = [
  "Zero unauthorized high-impact side effects",
  "No lost durable Work Units",
  "No duplicate external actions where the external system supports idempotency",
  "Correct recovery when a process or browser disappears",
  "No persistent execution cost for idle agents",
  "No unbounded task fan-out",
  "Every deliverable checked against its actual success criteria",
];
