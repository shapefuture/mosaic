import { db } from "@/db";
import { connectors, models, sandboxes, schedules } from "@/db/schema";
import { json } from "@/lib/api";

export const dynamic = "force-dynamic";

/** Central connector catalog + execution/intelligence catalogs. Capabilities are filtered per role, never all loaded into a prompt. */
export async function GET() {
  const [connectorRows, modelRows, sandboxRows, scheduleRows] = await Promise.all([
    db.select().from(connectors),
    db.select().from(models),
    db.select().from(sandboxes),
    db.select().from(schedules),
  ]);
  return json({
    connectors: connectorRows,
    models: modelRows,
    sandboxes: sandboxRows,
    schedules: scheduleRows,
    tiers: TIERS,
    stack: STACK,
    exclusions: EXCLUSIONS,
    sequence: SEQUENCE,
    roleTemplates: ROLE_TEMPLATES,
  });
}

export const TIERS = [
  {
    tier: 0,
    name: "No computer",
    share: "majority of business tasks",
    runtime: "Workers isolate · typed APIs · HTTP · SQL · deterministic functions",
    size: "128 MiB isolate ceiling, shared across thousands of identities",
    boots: "nothing",
  },
  {
    tier: 1,
    name: "Lightweight execution",
    share: "high-frequency transforms",
    runtime: "Containers (lite/basic) · parsers · document transforms · controlled commands",
    size: "1/16 vCPU · 256 MiB · 2 GB (lite) — 1/4 vCPU · 1 GiB · 4 GB (basic)",
    boots: "per task, scales to zero",
  },
  {
    tier: 2,
    name: "Isolated computers",
    share: "only when necessary",
    runtime: "Firecracker microVM · remote Chromium · full desktop when unavoidable",
    size: "≤5 MiB VMM overhead · 128 MiB guest · ~122 ms to user space",
    boots: "copy-on-write fork of a prepared snapshot",
  },
];

export const STACK = [
  { function: "Application and UI", primary: "Cloudflare Workers (this control plane: Next.js)", alternative: "Cloud Run · Fly.io" },
  { function: "Durable agent session", primary: "Agents SDK + PiHarness (hibernating DO sessions)", alternative: "custom lightweight harness (this build)" },
  { function: "Work Unit orchestration", primary: "Cloudflare Workflows", alternative: "DBOS on PostgreSQL (this build)" },
  { function: "Event fan-out", primary: "Cloudflare Queues (5k msg/s, 250 consumers)", alternative: "NATS JetStream" },
  { function: "Canonical database", primary: "Managed PostgreSQL", alternative: "D1 partitioned per tenant" },
  { function: "Connection pooling", primary: "Hyperdrive", alternative: "PgBouncer / managed pooler" },
  { function: "Large artifacts", primary: "R2 (no egress fees)", alternative: "S3-compatible object store" },
  { function: "Semantic retrieval", primary: "pgvector inside PostgreSQL", alternative: "Vectorize" },
  { function: "Model gateway", primary: "Cloudflare AI Gateway (BYO keys for parallel traffic)", alternative: "agentgateway (unified LLM/MCP/A2A)" },
  { function: "Browser automation", primary: "Browser Run + Playwright/CDP, contexts per identity", alternative: "Browserbase · Stagehand · Midscene" },
  { function: "Small code sandbox", primary: "Workers / Containers", alternative: "Cloud Run Jobs" },
  { function: "High-isolation sandbox", primary: "Firecracker / OpenSandbox", alternative: "E2B · microsandbox" },
  { function: "Authorization", primary: "Cedar-style policy evaluation + scoped SQL permissions", alternative: "OpenFGA when relationships grow" },
  { function: "Workload identity", primary: "Short-lived signed capability tokens", alternative: "SPIFFE/SPIRE on self-managed hosts" },
  { function: "Evaluation", primary: "Inspect AI · BrowserGym", alternative: "DeepEval · Promptfoo" },
  { function: "Telemetry", primary: "OpenTelemetry", alternative: "Opik trace UI" },
  { function: "Knowledge graph", primary: "PostgreSQL relations first", alternative: "Graphiti + FalkorDB when temporal edges justify it" },
];

export const EXCLUSIONS = [
  { item: "Redis", reason: "Durable Objects, workflow state and DB caching already cover the need" },
  { item: "Kafka / NATS at launch", reason: "Workflows + Queues handle the initial event volume" },
  { item: "Neo4j", reason: "Another database and operational footprint before value is proven" },
  { item: "FalkorDB server", reason: "Introduce only if temporal graph workload justifies it" },
  { item: "Qdrant", reason: "pgvector first — same retrieval semantics, no extra service" },
  { item: "Multiple model gateways", reason: "One primary model access path; five layers is bloat" },
  { item: "Dedicated agent pods", reason: "Agents are logical identities, not services" },
  { item: "Full desktop VMs for research", reason: "Reusable remote browser is far cheaper" },
  { item: "Always-on Kubernetes", reason: "Managed serverless execution is the better starting point" },
  { item: "D1 as the global write ledger", reason: "Serial per-database execution; partition per tenant instead" },
];

export const SEQUENCE = [
  { step: 1, build: "Workers, Postgres, R2, Hyperdrive", proof: "Very small, reliable cloud control plane" },
  { step: 2, build: "Agents SDK and PiHarness", proof: "Durable, hibernating sessions" },
  { step: 3, build: "Workflows and task contracts", proof: "Long-running Work Units and recovery" },
  { step: 4, build: "Queues and adaptive scheduler", proof: "Massive bounded parallelism" },
  { step: 5, build: "AI Gateway and model router", proof: "Model efficiency, fallback and budgets" },
  { step: 6, build: "Browser Run and Playwright", proof: "Reusable browser execution" },
  { step: 7, build: "Containers and Firecracker", proof: "Cheap execution with selectable isolation" },
  { step: 8, build: "Memory Compiler and pgvector", proof: "Growing organizational intelligence" },
  { step: 9, build: "Connectors, skills, schedules, webhooks", proof: "Full operational feature set" },
  { step: 10, build: "Evaluation and governance", proof: "Measured reliability and safety" },
];

export const ROLE_TEMPLATES = [
  { id: "specialist", label: "Research specialist", department: "research" },
  { id: "engineer", label: "Software engineer", department: "engineering" },
  { id: "operator", label: "Browser operator", department: "operations" },
  { id: "critic", label: "Verification critic", department: "quality" },
];
