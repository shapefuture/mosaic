import { eq } from "drizzle-orm";
import { db } from "@/db";
import { approvals, auditLog, tasks, workUnits } from "@/db/schema";
import { fail, json, readBody } from "@/lib/api";
import { emit } from "@/lib/engine/scheduler";
import { uid } from "@/lib/engine/util";

export const dynamic = "force-dynamic";

/** Human authorization gate. A consequential side effect only executes after a recorded decision. */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await readBody<{ decision?: "approved" | "denied"; note?: string; decidedBy?: string }>(req);
  const decision = body.decision === "denied" ? "denied" : "approved";

  const approval = (await db.select().from(approvals).where(eq(approvals.id, id)).limit(1))[0];
  if (!approval) return fail("approval not found", 404);
  if (approval.status !== "pending") return fail(`approval already ${approval.status}`, 409);

  await db
    .update(approvals)
    .set({ status: decision, decisionNote: body.note ?? null, decidedBy: body.decidedBy ?? "operator", decidedAt: new Date() })
    .where(eq(approvals.id, id));

  await db.insert(auditLog).values({
    id: uid("aud"),
    actor: body.decidedBy ?? "operator",
    action: `approval.${decision}`,
    subject: approval.action,
    result: decision,
    severity: decision === "approved" ? "info" : "warning",
    detail: { approvalId: id, taskId: approval.taskId, workUnitId: approval.workUnitId, risk: approval.risk },
  });

  if (approval.taskId) {
    if (decision === "approved") {
      await db.update(tasks).set({ status: "ready", error: null }).where(eq(tasks.id, approval.taskId));
      await emit(approval.workUnitId, approval.taskId, "approval.granted", `${approval.action} authorized by ${body.decidedBy ?? "operator"}`);
    } else {
      await db.update(tasks).set({ status: "skipped", error: `denied: ${body.note ?? "no reason given"}` }).where(eq(tasks.id, approval.taskId));
      await emit(approval.workUnitId, approval.taskId, "approval.denied", body.note ?? "operator denied the action");
    }
  }
  const remaining = await db.select({ id: tasks.id }).from(tasks).where(eq(tasks.status, "blocked"));
  if (!remaining.length) {
    await db.update(workUnits).set({ status: "running" }).where(eq(workUnits.id, approval.workUnitId));
  }
  return json({ ok: true, decision, approvalId: id });
}
