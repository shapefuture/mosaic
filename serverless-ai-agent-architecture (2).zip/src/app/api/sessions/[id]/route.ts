import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { agents, sessionMessages, sessions } from "@/db/schema";
import { fail, json, readBody } from "@/lib/api";
import { hibernateSession, wakeSession } from "@/lib/engine/scheduler";
import { runTurn } from "@/lib/engine/turn";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const session = (await db.select().from(sessions).where(eq(sessions.id, id)).limit(1))[0];
  if (!session) return fail("session not found", 404);
  const [agent, messages] = await Promise.all([
    db.select().from(agents).where(eq(agents.id, session.agentId)).limit(1),
    db.select().from(sessionMessages).where(eq(sessionMessages.sessionId, id)).orderBy(asc(sessionMessages.createdAt)),
  ]);
  return json({ session, agent: agent[0] ?? null, messages });
}

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await readBody<{ action?: string; content?: string }>(req);
  const action = body.action ?? "message";

  if (action === "wake") {
    const result = await wakeSession(id, "operator request");
    if (!result) return fail("session not found", 404);
    return json({ ok: true, ...result });
  }
  if (action === "hibernate") {
    const result = await hibernateSession(id);
    if (!result) return fail("session not found", 404);
    return json({ ok: true, state: "hibernated", residentMemoryMb: 0 });
  }
  if (action === "message") {
    if (!body.content?.trim()) return fail("content is required");
    const result = await runTurn({ sessionId: id, content: body.content.trim() });
    if (!result) return fail("session not found", 404);
    return json({ ok: true, ...result });
  }
  return fail(`unknown action: ${action}`);
}
