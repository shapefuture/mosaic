import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { agents, sessionMessages, sessions } from "@/db/schema";
import { fail, json, readBody } from "@/lib/api";
import { openSession } from "@/lib/engine/turn";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const limit = Number(url.searchParams.get("limit") ?? 60);
  const rows = await db.select().from(sessions).orderBy(desc(sessions.lastActiveAt)).limit(limit);
  const agentRows = await db.select({ id: agents.id, name: agents.name, role: agents.role, department: agents.department }).from(agents);
  const byId = new Map(agentRows.map((a) => [a.id, a]));
  const enriched = rows.map((s) => ({ ...s, agent: byId.get(s.agentId) ?? null }));
  const [agg] = await db
    .select({
      total: sql<number>`count(*)::int`,
      resident: sql<number>`count(*) filter (where state = 'resident')::int`,
      hibernated: sql<number>`count(*) filter (where state = 'hibernated')::int`,
      evicted: sql<number>`count(*) filter (where state = 'evicted')::int`,
      storageBytes: sql<number>`coalesce(sum(storage_bytes),0)::bigint`,
      residentMemoryMb: sql<number>`coalesce(sum(resident_memory_mb),0)::real`,
      wakes: sql<number>`coalesce(sum(wakes),0)::int`,
      hibernations: sql<number>`coalesce(sum(hibernations),0)::int`,
      evictions: sql<number>`coalesce(sum(evictions),0)::int`,
      recoveries: sql<number>`coalesce(sum(recoveries),0)::int`,
    })
    .from(sessions);
  return json({
    sessions: enriched,
    aggregate: {
      ...agg,
      storageMb: Math.round(Number(agg?.storageBytes ?? 0) / (1024 * 1024)),
      naiveResidentMemoryMb: (agg?.total ?? 0) * 512,
    },
  });
}

export async function POST(req: Request) {
  const body = await readBody<{ agentId?: string; title?: string; channel?: string }>(req);
  if (!body.agentId) return fail("agentId is required");
  const agent = (await db.select().from(agents).where(eq(agents.id, body.agentId)).limit(1))[0];
  if (!agent) return fail("agent not found", 404);
  const id = await openSession({ agentId: body.agentId, title: body.title, channel: body.channel });
  const created = (await db.select().from(sessions).where(eq(sessions.id, id)).limit(1))[0];
  const messages = await db.select().from(sessionMessages).where(eq(sessionMessages.sessionId, id));
  return json({ ok: true, session: created, messages, agent }, 201);
}
