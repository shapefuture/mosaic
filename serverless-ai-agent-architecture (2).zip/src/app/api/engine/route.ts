import { db } from "@/db";
import { schedulerState } from "@/db/schema";
import { fail, json, readBody, singleFlightTick } from "@/lib/api";
import { injectFailure, resetEngine, setSchedulerRunning, tick } from "@/lib/engine/scheduler";
import { cleanupBenchmarkData } from "@/lib/engine/benchmark";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** Engine control: the scheduler has no daemon, every action is a durable state transition. */
export async function POST(req: Request) {
  const body = await readBody<{ action?: string; mode?: "worker" | "browser" | "duplicate"; running?: boolean; ticks?: number }>(req);
  const action = body.action ?? "tick";

  if (action === "tick") {
    const count = Math.min(8, Math.max(1, body.ticks ?? 1));
    const summaries = [];
    for (let i = 0; i < count; i += 1) {
      summaries.push(await singleFlightTick(() => tick()));
    }
    return json({
      ok: true,
      ticks: summaries.length,
      last: summaries[summaries.length - 1],
      aggregate: summaries.reduce(
        (acc, s) => ({
          started: acc.started + s.started,
          completed: acc.completed + s.completed,
          failed: acc.failed + s.failed,
          blocked: acc.blocked + s.blocked,
          hibernated: acc.hibernated + s.hibernated,
          evicted: acc.evicted + s.evicted,
          planned: acc.planned + s.planned,
        }),
        { started: 0, completed: 0, failed: 0, blocked: 0, hibernated: 0, evicted: 0, planned: 0 },
      ),
      decisions: summaries.flatMap((s) => s.decisions).slice(0, 12),
    });
  }

  if (action === "failure") {
    const result = await injectFailure(body.mode ?? "worker");
    return json({ ok: true, ...result });
  }

  if (action === "toggle") {
    await setSchedulerRunning(body.running ?? true);
    const row = (await db.select().from(schedulerState).where(eq(schedulerState.id, "primary")).limit(1))[0];
    return json({ ok: true, running: row?.running ?? true });
  }

  if (action === "reset") {
    await cleanupBenchmarkData();
    await resetEngine();
    return json({ ok: true, reset: true });
  }

  return fail(`unknown action: ${action}`, 400);
}

export async function GET() {
  const summary = await singleFlightTick(() => tick());
  return json({ ok: true, ...summary });
}
