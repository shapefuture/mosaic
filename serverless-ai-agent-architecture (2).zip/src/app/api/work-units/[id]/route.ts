import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { agents, organizations, tasks, workUnits } from "@/db/schema";
import { fail, json, readBody } from "@/lib/api";
import { mintCapability } from "@/lib/engine/authority";
import { emit } from "@/lib/engine/scheduler";
import { detectTemplate } from "@/lib/engine/planner";
import { uid } from "@/lib/engine/util";

export const dynamic = "force-dynamic";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const wu = (await db.select().from(workUnits).where(eq(workUnits.id, id)).limit(1))[0];
  if (!wu) return fail("work unit not found", 404);
  const body = await readBody<{ action?: string; objective?: string; agentId?: string }>(req);
  const action = body.action ?? "cancel";

  if (action === "cancel") {
    await db.update(workUnits).set({ status: "cancelled" }).where(eq(workUnits.id, id));
    await db
      .update(tasks)
      .set({ status: "skipped", error: "work unit cancelled by operator" })
      .where(inArray(tasks.status, ["pending", "ready", "blocked"]));
    await emit(id, null, "workunit.cancelled", "operator cancelled; running tasks finish their current step, no new work dispatched");
    return json({ ok: true, status: "cancelled" });
  }

  if (action === "retry-failed") {
    const failed = await db.select().from(tasks).where(and(eq(tasks.workUnitId, id), eq(tasks.status, "failed")));
    await db.update(tasks).set({ status: "ready", attempts: 0, error: null }).where(inArray(tasks.id, failed.map((f) => f.id)));
    await db.update(workUnits).set({ status: "running" }).where(eq(workUnits.id, id));
    await emit(id, null, "workunit.retried", `${failed.length} failed task(s) re-queued from durable state`);
    return json({ ok: true, retried: failed.length });
  }

  if (action === "delegate") {
    if (!body.objective) return fail("objective is required for delegation");
    if (wu.delegationDepth >= 2) return fail("delegation depth ceiling reached — authority cannot be widened downward", 403);
    const org = (await db.select().from(organizations).limit(1))[0];
    const pool = await db.select().from(agents);
    const specialist = pool.find((a) => a.id === body.agentId) ?? pool.find((a) => a.id !== wu.ownerAgentId) ?? pool[0];
    const childId = uid("wu");
    await db.insert(workUnits).values({
      id: childId,
      orgId: org?.id ?? wu.orgId,
      parentWorkUnitId: wu.id,
      title: body.objective.slice(0, 90),
      objective: body.objective,
      template: detectTemplate(body.objective),
      ownerAgentId: specialist?.id ?? null,
      status: "planning",
      delegationDepth: wu.delegationDepth + 1,
      fanOutLimit: Math.max(2, Math.floor(wu.fanOutLimit / 2)),
      budgetMicros: Math.floor(wu.budgetMicros / 3),
      priority: wu.priority + 1,
    });
    if (specialist) {
      await mintCapability({
        agentId: specialist.id,
        workUnitId: childId,
        actions: ["http.get", "data.write", "memory.read", "compute.run"],
        resources: [`workunit:${childId}`],
        maxCostMicros: Math.floor(wu.budgetMicros / 3),
        delegationDepth: 0,
      });
    }
    await emit(wu.id, null, "workunit.delegated", `child ${childId} → ${specialist?.name ?? "specialist"} with attenuated authority (depth ${wu.delegationDepth + 1})`);
    return json({ ok: true, childId, specialist: specialist?.name ?? null, attenuated: true }, 201);
  }

  return fail(`unknown action: ${action}`);
}
