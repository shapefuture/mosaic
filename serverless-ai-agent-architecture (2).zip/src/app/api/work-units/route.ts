import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { agents, approvals, artifacts, capabilityTokens, organizations, receipts, taskEvents, tasks, workUnits } from "@/db/schema";
import { fail, json, readBody, singleFlightTick } from "@/lib/api";
import { detectTemplate } from "@/lib/engine/planner";
import { tick } from "@/lib/engine/scheduler";
import { uid } from "@/lib/engine/util";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (id) {
    const wu = (await db.select().from(workUnits).where(eq(workUnits.id, id)).limit(1))[0];
    if (!wu) return fail("work unit not found", 404);
    const [wuTasks, events, arts, rcpts, tokens, aprs, owner] = await Promise.all([
      db.select().from(tasks).where(eq(tasks.workUnitId, id)),
      db.select().from(taskEvents).where(eq(taskEvents.workUnitId, id)).orderBy(desc(taskEvents.at)).limit(300),
      db.select().from(artifacts).where(eq(artifacts.workUnitId, id)).orderBy(desc(artifacts.createdAt)),
      db.select().from(receipts).where(eq(receipts.workUnitId, id)).orderBy(desc(receipts.at)),
      db.select().from(capabilityTokens).where(eq(capabilityTokens.workUnitId, id)),
      db.select().from(approvals).where(eq(approvals.workUnitId, id)).orderBy(desc(approvals.createdAt)),
      wu.ownerAgentId ? db.select().from(agents).where(eq(agents.id, wu.ownerAgentId)).limit(1) : Promise.resolve([]),
    ]);
    const byStatus = wuTasks.reduce<Record<string, number>>((acc, t) => {
      acc[t.status] = (acc[t.status] ?? 0) + 1;
      return acc;
    }, {});
    return json({
      workUnit: wu,
      owner: owner[0] ?? null,
      tasks: wuTasks,
      events: events.reverse(),
      artifacts: arts,
      receipts: rcpts,
      tokens,
      approvals: aprs,
      summary: {
        byStatus,
        parallelism: wu.maxParallelismObserved,
        deterministicShare: wuTasks.length ? Math.round((wuTasks.filter((t) => !t.needsModel).length / wuTasks.length) * 100) : 0,
        tiers: [0, 1, 2].map((tier) => ({ tier, count: wuTasks.filter((t) => t.tier === tier).length })),
        queues: ["interactive", "io", "compute", "browser"].map((q) => ({ queue: q, count: wuTasks.filter((t) => t.queue === q).length })),
      },
    });
  }
  const rows = await db.select().from(workUnits).orderBy(desc(workUnits.createdAt)).limit(80);
  return json({ workUnits: rows });
}

/** Create a durable Work Unit. Planning happens on the next scheduler tick. */
export async function POST(req: Request) {
  const body = await readBody<{
    objective?: string;
    title?: string;
    template?: string;
    agentId?: string;
    budgetMicros?: number;
    fanOutLimit?: number;
    priority?: number;
  }>(req);
  if (!body.objective) return fail("objective is required");

  const org = (await db.select().from(organizations).limit(1))[0];
  if (!org) return fail("no organization seeded", 500);
  const agentPool = await db.select().from(agents);
  const owner =
    agentPool.find((a) => a.id === body.agentId) ??
    agentPool.find((a) => a.department === "operations") ??
    agentPool[0];

  const id = uid("wu");
  const template = body.template && body.template !== "auto" ? body.template : detectTemplate(body.objective);

  await db.insert(workUnits).values({
    id,
    orgId: org.id,
    title: body.title ?? body.objective.slice(0, 90),
    objective: body.objective,
    template,
    ownerAgentId: owner?.id ?? null,
    status: "planning",
    priority: body.priority ?? 5,
    fanOutLimit: Math.min(64, Math.max(2, body.fanOutLimit ?? 12)),
    budgetMicros: body.budgetMicros ?? 750_000,
    delegationDepth: 0,
  });

  // Plan immediately so the caller gets the graph back in the same request.
  await singleFlightTick(() => tick());
  const created = (await db.select().from(workUnits).where(eq(workUnits.id, id)).limit(1))[0];
  const createdTasks = await db.select().from(tasks).where(eq(tasks.workUnitId, id));
  return json(
    {
      ok: true,
      workUnit: created,
      tasks: createdTasks,
      note: `Planned as ${template}: ${createdTasks.length} tasks, bounded fan-out ${created?.fanOutLimit ?? 0}. Executing on the shared pool.`,
    },
    201,
  );
}
