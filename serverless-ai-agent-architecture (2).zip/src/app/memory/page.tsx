"use client";

import { useState } from "react";
import { Brain, Database, Layers, Search, Sparkles } from "lucide-react";
import { useAos, useResource, postJSON } from "@/lib/client/state";
import { Badge, Btn, Empty, KV, Meter, Panel, SectionTitle, Stat, Table, Td } from "@/components/ui";
import { formatBytes, relativeTime } from "@/lib/format";
import { cn } from "@/lib/cn";

const KINDS = ["preference", "episodic", "semantic", "procedural"] as const;

const KIND_META: Record<string, { storage: string; retrieval: string; tone: "jade" | "blue" | "cyan" | "violet" }> = {
  preference: { storage: "Structured PostgreSQL records", retrieval: "Exact lookup", tone: "jade" },
  episodic: { storage: "Event and task-derived records", retrieval: "Time, project and semantic retrieval", tone: "blue" },
  semantic: { storage: "Facts, entities and relationships", retrieval: "SQL, full-text and vector search", tone: "cyan" },
  procedural: { storage: "Versioned skill and procedure files", retrieval: "Skill registry", tone: "violet" },
};

export default function MemoryPage() {
  const { data } = useAos();
  const { data: store, reload } = useResource<any>("/api/memories", { interval: 5000 });
  const [query, setQuery] = useState("pricing normalisation and portal login procedure");
  const [results, setResults] = useState<any[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [kind, setKind] = useState<string>("all");
  const [form, setForm] = useState({ kind: "semantic", subject: "", content: "" });

  const stats = store?.stats ?? data?.memory ?? {};
  const rows = (store?.memories ?? []).filter((m: any) => kind === "all" || m.kind === kind);

  async function search() {
    if (!query.trim()) return;
    setSearching(true);
    try {
      const res = await postJSON("/api/memories", { query: query.trim(), topK: 8 });
      setResults(res.results ?? []);
    } finally {
      setSearching(false);
    }
  }

  return (
    <div className="space-y-5">
      <SectionTitle eyebrow="Layer 5 · managed data and intelligence" title="Organizational memory">
        Four classes of memory, one storage architecture. No separate graph service, no separate vector service: PostgreSQL holds the records and their
        vectors. The Memory Compiler runs in the background after work completes — it is never in the critical path of a conversation.
      </SectionTitle>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Stat label="Memory records" value={stats.total ?? 0} tone="cyan" hint={`${stats.promoted ?? 0} promoted to curated memory`} />
        <Stat label="Verified" value={stats.verified ?? 0} tone="jade" hint={`${stats.contested ?? 0} contested (contradiction detected)`} />
        <Stat label="Retrieval hits" value={stats.retrievalHits ?? 0} tone="violet" hint="served into compact context packages" />
        <Stat label="Storage" value={formatBytes(stats.bytes ?? 0)} tone="blue" hint="knowledge base ≠ working memory" />
        <Stat label="Graph services running" value={0} tone="amber" hint="relations live in PostgreSQL until temporal queries justify Graphiti" />
      </div>

      <div className="grid gap-4 xl:grid-cols-4">
        {KINDS.map((k) => (
          <Panel key={k} title={k} subtitle={KIND_META[k].storage} icon={<Layers size={13} className={cn(k === "procedural" && "text-violet")} />}>
            <p className="mono text-[26px] font-semibold leading-none text-chalk">{stats[k] ?? 0}</p>
            <p className="mt-2 text-[11.5px] leading-snug text-mist">{KIND_META[k].retrieval}</p>
            <div className="mt-2">
              <Meter value={stats[k] ?? 0} max={Math.max(1, stats.total ?? 1)} tone={KIND_META[k].tone} />
            </div>
            <Btn size="sm" className="mt-3" active={kind === k} onClick={() => setKind(kind === k ? "all" : k)}>
              {kind === k ? "showing" : "filter"}
            </Btn>
          </Panel>
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.2fr_1fr]">
        <Panel title="Semantic retrieval" subtitle="Cosine similarity over stored vectors, blended with lexical overlap and scope/trust bonuses. pgvector in production." icon={<Search size={14} className="text-cyan" />}>
          <div className="flex flex-wrap items-end gap-2">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && void search()}
              className="min-w-[240px] flex-1 rounded-lg border border-line2 bg-abyss px-3 py-2 text-[12.5px] text-chalk outline-none placeholder:text-dim focus:border-cyan/60"
              placeholder="search the knowledge base…"
            />
            <Btn onClick={search} disabled={searching}><Search size={12} /> {searching ? "searching…" : "retrieve"}</Btn>
          </div>
          <div className="mt-3 space-y-2">
            {results === null && <Empty>run a query to see scoped retrieval with scores</Empty>}
            {results?.map((r: any) => (
              <div key={r.id} className="rise rounded-lg border border-line bg-abyss/60 p-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-[12.5px] text-chalk">{r.subject}</p>
                    <p className="mt-0.5 text-[11.5px] leading-snug text-mist">{r.content}</p>
                  </div>
                  <span className="mono shrink-0 text-[13px] text-cyan">{r.score?.toFixed?.(3) ?? r.score}</span>
                </div>
                <div className="mono mt-2 flex flex-wrap gap-1.5 text-[10px] text-dim">
                  <Badge tone={KIND_META[r.kind]?.tone ?? "dim"}>{r.kind}</Badge>
                  <span className="rounded border border-line bg-panel2 px-1.5 py-0.5">trust {r.trust}</span>
                  <span className="rounded border border-line bg-panel2 px-1.5 py-0.5">confidence {Math.round(r.confidence * 100)}%</span>
                  <span className="rounded border border-line bg-panel2 px-1.5 py-0.5">scope {r.scope}</span>
                  {r.promoted && <span className="rounded border border-jade/30 bg-jade/10 px-1.5 py-0.5 text-jade">promoted</span>}
                  <span className="rounded border border-line bg-panel2 px-1.5 py-0.5">hits {r.hits}</span>
                </div>
              </div>
            ))}
            {results?.length === 0 && <Empty>no records above the similarity threshold</Empty>}
          </div>
        </Panel>

        <div className="space-y-4">
          <Panel title="Memory Compiler" subtitle="Cheap, asynchronous, and gated. Never rebuild a full memory profile on every turn." icon={<Sparkles size={14} className="text-violet" />}>
            <ol className="space-y-2">
              {[
                ["save outcome + evidence", "task result, artifacts and receipts land first"],
                ["extract candidates", "background workflow proposes facts and procedures"],
                ["deduplicate", "cosine > 0.86 against existing records merges and raises confidence"],
                ["scope + trust", "agent vs org scope; candidate → verified → contested"],
                ["validate contradictions", "conflicting records are marked contested, not silently overwritten"],
                ["promote", "only corroborated, high-confidence records enter curated memory"],
                ["generate a skill", "a procedure becomes a versioned skill only after repeated success"],
              ].map(([k, v], i) => (
                <li key={k} className="flex gap-2.5 rounded-lg border border-line bg-abyss/50 px-3 py-2">
                  <span className="mono mt-0.5 text-[10.5px] text-violet">{String(i + 1).padStart(2, "0")}</span>
                  <span className="text-[11.5px] leading-snug text-mist"><span className="mono text-chalk">{k}</span> — {v}</span>
                </li>
              ))}
            </ol>
            <p className="mt-3 text-[11.5px] leading-relaxed text-dim">
              Result: a large knowledge base with a small working memory. The agent receives a compact context package of references and summaries, not the
              whole corpus.
            </p>
          </Panel>

          <Panel title="Add a record" subtitle="Operator-written records start as candidates with provenance." icon={<Database size={14} className="text-jade" />}>
            <div className="space-y-2">
              <select value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })} className="w-full rounded-lg border border-line2 bg-abyss px-2.5 py-1.5 text-[12.5px] text-chalk outline-none focus:border-cyan/60">
                {KINDS.map((k) => <option key={k} value={k}>{k}</option>)}
              </select>
              <input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} placeholder="subject" className="w-full rounded-lg border border-line2 bg-abyss px-2.5 py-1.5 text-[12.5px] text-chalk outline-none placeholder:text-dim focus:border-cyan/60" />
              <textarea rows={3} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} placeholder="content" className="w-full resize-y rounded-lg border border-line2 bg-abyss px-2.5 py-1.5 text-[12.5px] text-chalk outline-none placeholder:text-dim focus:border-cyan/60" />
              <Btn
                tone="jade"
                disabled={!form.subject.trim() || !form.content.trim()}
                onClick={async () => {
                  await postJSON("/api/memories", { action: "add", kind: form.kind, subject: form.subject.trim(), content: form.content.trim() });
                  setForm({ ...form, subject: "", content: "" });
                  await reload();
                }}
              >
                store candidate memory
              </Btn>
            </div>
          </Panel>
        </div>
      </div>

      <Panel
        title="Records"
        subtitle="Every record carries provenance, trust and a validity window — the relational substrate a temporal graph would later formalize."
        icon={<Brain size={14} className="text-cyan" />}
        bodyClass="p-0"
        right={
          <div className="flex flex-wrap gap-1">
            {["all", ...KINDS].map((k) => (
              <button key={k} onClick={() => setKind(k)} className={cn("mono rounded-md border px-2 py-0.5 text-[10px] uppercase tracking-[0.08em]", kind === k ? "border-cyan/50 bg-cyan/12 text-cyan" : "border-line bg-panel2 text-dim hover:text-mist")}>
                {k}
              </button>
            ))}
          </div>
        }
      >
        <div className="max-h-[520px] overflow-y-auto">
          <Table head={["kind", "subject", "content", "scope", "trust", "confidence", "hits", "provenance", "written"]}>
            {rows.map((m: any) => (
              <tr key={m.id} className="hover:bg-white/2">
                <Td><Badge tone={KIND_META[m.kind]?.tone ?? "dim"}>{m.kind}</Badge></Td>
                <Td className="text-chalk">{m.subject}</Td>
                <Td className="max-w-[420px]"><span className="line-clamp-2">{m.content}</span></Td>
                <Td className="mono text-[10.5px]">{m.scope}</Td>
                <Td><Badge tone={m.trust === "verified" ? "jade" : m.trust === "contested" ? "rose" : "dim"}>{m.trust}</Badge></Td>
                <Td className="mono">{Math.round(m.confidence * 100)}%</Td>
                <Td className="mono">{m.hits}</Td>
                <Td className="mono text-[10px]">{m.provenance?.method ?? "—"}{m.provenance?.workUnitId ? ` · ${String(m.provenance.workUnitId).slice(0, 10)}` : ""}</Td>
                <Td className="mono text-[10.5px]">{relativeTime(m.createdAt)}</Td>
              </tr>
            ))}
            {!rows.length && <tr><Td colSpan={9}><Empty>no records in this class</Empty></Td></tr>}
          </Table>
        </div>
      </Panel>

      <Panel title="What we deliberately did not deploy">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["Neo4j", "another database and operational footprint"],
            ["FalkorDB server", "only if a temporal graph workload justifies it"],
            ["Qdrant", "pgvector first — same semantics, no extra service"],
            ["Giant shared agent-memory process", "memory is scoped records, not a resident service"],
          ].map(([k, v]) => (
            <div key={k} className="rounded-lg border border-line bg-abyss/60 px-3 py-2">
              <p className="mono text-[11.5px] text-rose">{k}</p>
              <p className="mt-0.5 text-[11.5px] leading-snug text-mist">{v}</p>
            </div>
          ))}
        </div>
        <KV k="Introduce Graphiti when" v="temporal relationship history, entity linking across projects, validity windows or multi-hop provenance queries become the bottleneck" />
      </Panel>
    </div>
  );
}
