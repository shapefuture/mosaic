"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { ArrowUp, MessagesSquare, Moon, Radio, Send, Sun, Zap } from "lucide-react";
import { useAos, postJSON } from "@/lib/client/state";
import { Badge, Btn, Dot, Empty, KV, Meter, Panel, SectionTitle, Stat, Status, Table, Td } from "@/components/ui";
import { formatBytes, formatMicros, relativeTime } from "@/lib/format";
import { cn } from "@/lib/cn";


export default function SessionsPage() {
  return (
    <Suspense fallback={<div className="h-64 animate-pulse rounded-xl bg-panel2" />}>
      <SessionsInner />
    </Suspense>
  );
}

function SessionsInner() {
  const { data, post, busy, refresh } = useAos();
  const search = useSearchParams();
  const focus = search.get("focus");
  const sessions = data?.sessions ?? {};
  const rows = sessions.rows ?? [];
  const agents = data?.agents ?? [];
  const [selected, setSelected] = useState<string | null>(focus ?? rows[0]?.id ?? null);
  const [transcript, setTranscript] = useState<any>(null);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [telemetry, setTelemetry] = useState<any>(null);
  const [newAgent, setNewAgent] = useState<string>("");
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!selected && rows.length) setSelected(rows[0].id);
  }, [rows, selected]);

  useEffect(() => {
    if (focus) setSelected(focus);
  }, [focus]);

  useEffect(() => {
    let active = true;
    if (!selected) return;
    const load = async () => {
      const res = await fetch(`/api/sessions/${selected}`, { cache: "no-store" }).then((r) => r.json()).catch(() => null);
      if (active && res?.session) setTranscript(res);
    };
    void load();
    const id = setInterval(load, 3000);
    return () => {
      active = false;
      clearInterval(id);
    };
  }, [selected]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [transcript?.messages?.length]);

  const session = useMemo(() => transcript?.session ?? rows.find((r: any) => r.id === selected) ?? null, [transcript, rows, selected]);
  const messages = transcript?.messages ?? [];

  async function send() {
    if (!selected || !draft.trim()) return;
    setSending(true);
    try {
      const res = await postJSON(`/api/sessions/${selected}`, { action: "message", content: draft.trim() });
      setTelemetry(res.telemetry);
      setDraft("");
      const next = await fetch(`/api/sessions/${selected}`, { cache: "no-store" }).then((r) => r.json());
      setTranscript(next);
      await refresh();
    } catch (err) {
      setTelemetry({ error: err instanceof Error ? err.message : "turn failed" });
    } finally {
      setSending(false);
    }
  }

  const residentMb = rows.reduce((a: number, s: any) => a + (s.residentMemoryMb ?? 0), 0);
  const naiveMb = (sessions.total ?? 0) * 512;

  return (
    <div className="space-y-5">
      <SectionTitle eyebrow="Layer 2 · durable agent sessions" title="Hibernating sessions">
        One logical identity can own many concurrent sessions. A session wakes when work arrives, loads a compact context, executes its turn, persists the
        transcript and pending tool state, then hibernates. Eviction is not loss: the actor reopens from durable storage.
      </SectionTitle>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Stat label="Logical sessions" value={sessions.total ?? 0} tone="violet" hint={`${sessions.hibernated ?? 0} hibernated · ${sessions.evicted ?? 0} evicted`} />
        <Stat label="Resident now" value={sessions.resident ?? 0} tone="cyan" sub={<div className="mt-1"><Meter value={sessions.resident ?? 0} max={Math.max(1, sessions.total ?? 1)} tone="cyan" /></div>} />
        <Stat label="Resident memory" value={Math.round(residentMb)} unit="MiB" tone="blue" hint={`idle sessions cost 0 MiB`} />
        <Stat label="Naive footprint" value={`${Math.round(naiveMb / 1024)} GiB`} tone="rose" hint="if every session kept a resident worker" />
        <Stat label="Durable storage" value={sessions.storageMb ?? 0} unit="MiB" tone="jade" hint={`${sessions.wakes ?? 0} wakes · ${sessions.recoveries ?? 0} recoveries after eviction`} />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1fr_1.35fr]">
        <div className="space-y-4">
          <Panel title="Open a session" subtitle="Creating a session does not create a service — it creates a durable actor that sleeps between turns." icon={<Zap size={14} className="text-cyan" />}>
            <div className="flex flex-wrap items-end gap-2">
              <select
                value={newAgent}
                onChange={(e) => setNewAgent(e.target.value)}
                className="min-w-[220px] flex-1 rounded-lg border border-line2 bg-abyss px-2.5 py-2 text-[12.5px] text-chalk outline-none focus:border-cyan/60"
              >
                <option value="">choose an identity…</option>
                {agents.map((a: any) => (
                  <option key={a.id} value={a.id}>{a.name} — {a.role}</option>
                ))}
              </select>
              <Btn
                disabled={!newAgent || busy}
                onClick={async () => {
                  const res = await post("/api/sessions", { agentId: newAgent, title: `Session · ${agents.find((a: any) => a.id === newAgent)?.role ?? "agent"}` });
                  if (res?.session?.id) setSelected(res.session.id);
                }}
              >
                <MessagesSquare size={12} /> open
              </Btn>
            </div>
          </Panel>

          <Panel title="Session table" subtitle="Resident actors hold memory only while they are mid-turn." bodyClass="p-0">
            <div className="max-h-[560px] overflow-y-auto">
              <Table head={["session", "state", "resident", "storage", "turns", "wake / hib / evict", "idle"]}>
                {rows.map((s: any) => (
                  <tr
                    key={s.id}
                    onClick={() => setSelected(s.id)}
                    className={cn("cursor-pointer hover:bg-white/2", selected === s.id && "bg-cyan/6")}
                  >
                    <Td className="max-w-[220px]">
                      <span className="block truncate text-chalk">{s.title}</span>
                      <span className="mono block truncate text-[10px] text-dim">{s.agent?.name ?? s.agentId}</span>
                    </Td>
                    <Td><Status value={s.state} /></Td>
                    <Td className="mono">{s.residentMemoryMb ? `${Math.round(s.residentMemoryMb)} MiB` : <span className="text-jade">0</span>}</Td>
                    <Td className="mono text-[10.5px]">{formatBytes(s.storageBytes)}</Td>
                    <Td className="mono">{s.turns}</Td>
                    <Td className="mono text-[10.5px]">{s.wakes} / {s.hibernations} / {s.evictions}</Td>
                    <Td className="mono text-[10.5px]">{relativeTime(s.lastActiveAt)}</Td>
                  </tr>
                ))}
                {!rows.length && <tr><Td colSpan={7}><Empty>no sessions yet</Empty></Td></tr>}
              </Table>
            </div>
          </Panel>
        </div>

        <Panel
          title={session ? session.title : "Conversation"}
          subtitle={session ? `${transcript?.agent?.name ?? ""} · ${transcript?.agent?.role ?? ""} · ${session.id}` : "select a session"}
          icon={<Radio size={14} className="text-jade" />}
          right={
            session && (
              <div className="flex gap-1.5">
                <Btn size="sm" tone="jade" onClick={() => void post(`/api/sessions/${session.id}`, { action: "wake" })}><Sun size={12} /> wake</Btn>
                <Btn size="sm" tone="violet" onClick={() => void post(`/api/sessions/${session.id}`, { action: "hibernate" })}><Moon size={12} /> hibernate</Btn>
              </div>
            )
          }
          bodyClass="p-0"
        >
          {!session ? (
            <div className="p-4"><Empty>select or open a session</Empty></div>
          ) : (
            <div className="flex flex-col">
              <div className="mono flex flex-wrap items-center gap-x-4 gap-y-1 border-b border-line px-4 py-2 text-[10.5px] text-dim">
                <span className="flex items-center gap-1.5"><Dot tone={session.state === "resident" ? "jade" : "violet"} pulse={session.state === "resident"} />{session.state}</span>
                <span>{Math.round(session.residentMemoryMb ?? 0)} MiB resident</span>
                <span>{formatBytes(session.storageBytes ?? 0)} durable</span>
                <span>{session.contextBytes ?? 0} B context package</span>
                <span>{session.turns ?? 0} turns</span>
                {session.workUnitId && <Link className="text-cyan hover:underline" href={`/work/${session.workUnitId}`}>work unit →</Link>}
              </div>

              <div ref={scrollRef} className="max-h-[520px] min-h-[260px] space-y-3 overflow-y-auto p-4">
                {messages.map((m: any) => (
                  <Message key={m.id} m={m} />
                ))}
                {!messages.length && <Empty>this session has no transcript yet — send a message to wake it</Empty>}
              </div>

              {telemetry && (
                <div className="mono grid gap-1 border-t border-line bg-abyss/70 px-4 py-2.5 text-[10.5px] text-dim sm:grid-cols-2 lg:grid-cols-4">
                  <span>intent: <span className="text-cyan">{telemetry.intent ?? telemetry.error}</span></span>
                  <span>tier: <span className="text-mist">{telemetry.tier}</span> · model: <span className="text-mist">{telemetry.model}</span></span>
                  <span>tokens: <span className="text-mist">{telemetry.tokensIn}→{telemetry.tokensOut}</span> · cost: <span className="text-jade">{formatMicros(telemetry.costMicros ?? 0)}</span>{telemetry.cached ? " · cache hit" : ""}</span>
                  <span>authority: <span className={telemetry.authority === "permitted" ? "text-jade" : "text-amber"}>{telemetry.authority}</span></span>
                  {telemetry.credential && <span>credential: <span className="text-blue">{telemetry.credential}</span> (never exposed to the model)</span>}
                  {telemetry.injectionFindings?.length > 0 && <span className="text-rose">quarantined: {telemetry.injectionFindings.join(", ")}</span>}
                </div>
              )}

              <div className="flex items-end gap-2 border-t border-line p-3">
                <textarea
                  rows={2}
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      void send();
                    }
                  }}
                  placeholder={
                    session.state === "resident"
                      ? "Ask for pricing, request a browser job, delegate to a specialist…"
                      : "Send a message — the session wakes from durable state"
                  }
                  className="flex-1 resize-y rounded-lg border border-line2 bg-abyss px-3 py-2 text-[12.5px] leading-relaxed text-chalk outline-none placeholder:text-dim focus:border-cyan/60"
                />
                <Btn onClick={send} disabled={sending || !draft.trim()}>
                  {sending ? <Zap size={12} className="animate-pulse" /> : <Send size={12} />} {sending ? "turn…" : "send"}
                </Btn>
              </div>
            </div>
          )}
        </Panel>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <Panel title="Why hibernation matters" subtitle="The November platform benchmark moved from 88 to 459 agent runs/sec at 2,048 sessions with ~27× fewer streaming storage transactions.">
          <KV k="Idle session cost" v="storage only" />
          <KV k="Wake latency" v="one read of durable state" />
          <KV k="Eviction" v="recoverable, not terminal" />
          <KV k="Concurrency per identity" v="many independent sessions" />
          <p className="mt-2 text-[11.5px] leading-relaxed text-dim">
            Those figures are platform-reported synthetic SQLite results, not end-to-end business throughput. They matter here because high conversation
            volume produces enormous numbers of tiny writes — exactly what batching and hibernation remove.
          </p>
        </Panel>
        <Panel title="Turn anatomy">
          <ol className="space-y-2">
            {[
              ["wake", "reopen the durable actor; restore transcript and pending tool calls"],
              ["scan", "untrusted input is quarantined as data — permissions are frozen"],
              ["retrieve", "assemble a compact context package from scoped memory"],
              ["authorize", "deterministic policy check against the live capability token"],
              ["route", "pick the cheapest capable model, or use deterministic code"],
              ["execute", "least sufficient tier: API → container → isolated computer"],
              ["persist", "write the transcript, receipts and artifacts; release compute"],
            ].map(([k, v], i) => (
              <li key={k} className="flex gap-2.5">
                <span className="mono mt-0.5 shrink-0 text-[10.5px] text-cyan">{String(i + 1).padStart(2, "0")}</span>
                <span className="text-[12px] leading-snug text-mist"><span className="mono text-chalk">{k}</span> — {v}</span>
              </li>
            ))}
          </ol>
        </Panel>
        <Panel title="Session integrity">
          <KV k="Pending tool calls" v={session?.pendingToolCalls ?? 0} />
          <KV k="Recoveries after eviction" v={session?.recoveries ?? 0} />
          <KV k="Hibernate / wake cycles" v={`${session?.hibernations ?? 0} / ${session?.wakes ?? 0}`} />
          <KV k="Channel" v={session?.channel ?? "web"} />
          <KV k="Last active" v={relativeTime(session?.lastActiveAt)} />
          <div className="mt-3">
            <Badge tone="violet">durable transcript</Badge> <Badge tone="cyan">scoped memory</Badge> <Badge tone="jade">receipt-backed side effects</Badge>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function Message({ m }: { m: any }) {
  const isUser = m.kind === "user";
  const isAssistant = m.kind === "assistant";
  const isTool = m.kind === "tool";
  return (
    <div className={cn("rise flex gap-2.5", isUser && "justify-end")}>
      {!isUser && (
        <span className={cn("mono mt-1 shrink-0 text-[9.5px] uppercase tracking-[0.12em]", isTool ? "text-blue" : isAssistant ? "text-jade" : "text-dim")}>
          {m.kind}
        </span>
      )}
      <div
        className={cn(
          "max-w-[85%] rounded-xl border px-3 py-2 text-[12.5px] leading-relaxed",
          isUser
            ? "border-cyan/30 bg-cyan/8 text-chalk"
            : isAssistant
              ? "border-line2 bg-panel2 text-chalk"
              : isTool
                ? "border-blue/25 bg-blue/6 text-mist"
                : "border-line bg-abyss/70 text-dim",
        )}
      >
        <div className="whitespace-pre-wrap">{m.content}</div>
        {(m.model || m.costMicros > 0 || m.tool) && (
          <p className="mono mt-1.5 text-[10px] text-dim">
            {m.tool ? `${m.tool} · ` : ""}
            {m.model ? `${m.model} · ` : ""}
            {m.tokens ? `${m.tokens} tok · ` : ""}
            {m.latencyMs ? `${m.latencyMs}ms · ` : ""}
            {m.costMicros ? formatMicros(m.costMicros) : ""}
          </p>
        )}
      </div>
    </div>
  );
}
