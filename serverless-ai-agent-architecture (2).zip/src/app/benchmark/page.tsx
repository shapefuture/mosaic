"use client";

import { useState } from "react";
import { CheckCircle2, FlaskConical, Play, Trash2, XCircle } from "lucide-react";
import { useResource, postJSON } from "@/lib/client/state";
import { Badge, Btn, Empty, KV, Panel, SectionTitle, Stat, Table, Td } from "@/components/ui";
import { relativeTime } from "@/lib/format";
import { cn } from "@/lib/cn";

const HARD_ACCEPTANCE = [
  "Zero unauthorized high-impact side effects",
  "No lost durable Work Units",
  "No duplicate external actions where the external system supports idempotency",
  "Correct recovery when a process or browser disappears",
  "No persistent execution cost for idle agents",
  "No unbounded task fan-out",
  "Every deliverable is checked against its actual success criteria",
];

const METRICS = [
  ["Memory per active turn", "efficiency of the agent runtime"],
  ["Memory per idle session", "effectiveness of hibernation"],
  ["Workflow starts/sec", "orchestration throughput"],
  ["Tool operations/sec", "actual execution capability"],
  ["p95 task completion time", "user-visible performance"],
  ["Queue waiting time", "whether the scheduler is overloaded"],
  ["Browser memory per tab", "browser density"],
  ["Sandbox startup latency", "cost of strong isolation"],
  ["Database writes per task", "persistence overhead"],
  ["Model tokens per accepted result", "intelligence efficiency"],
  ["External side effects per successful task", "operational effectiveness"],
  ["Cost per verified deliverable", "overall economics"],
];

export default function BenchmarkPage() {
  const { data, loading, reload } = useResource<any>("/api/benchmark");
  const [running, setRunning] = useState<string | null>(null);
  const [result, setResult] = useState<any>(null);

  async function run(scenario: string) {
    setRunning(scenario);
    setResult(null);
    try {
      const res = await postJSON("/api/benchmark", { scenario });
      setResult(res);
      await reload();
    } finally {
      setRunning(null);
    }
  }

  const scenarios = data?.scenarios ?? [];
  const runs = data?.runs ?? [];

  return (
    <div className="space-y-5">
      <SectionTitle eyebrow="Step 10 · evaluation and governance" title="AOS capacity qualification">
        Do not select a system by how many agents it claims to support. Select it by measurement. Each scenario below runs against this live deployment and
        records targets, measurements and hard acceptance checks — a platform that scores well on model benchmarks but fails these is not production-ready.
      </SectionTitle>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Scenarios" value={scenarios.length} tone="cyan" />
        <Stat label="Runs recorded" value={runs.length} tone="violet" />
        <Stat label="Passed runs" value={runs.filter((r: any) => r.status === "passed").length} tone="jade" />
        <Stat label="Failed runs" value={runs.filter((r: any) => r.status === "failed").length} tone="rose" />
      </div>

      <div className="flex flex-wrap gap-2">
        <Btn tone="violet" onClick={() => void run("all")} disabled={running !== null}>
          <Play size={12} /> {running === "all" ? "running full qualification…" : "run the full qualification suite"}
        </Btn>
        <Btn tone="dim" onClick={async () => { await postJSON("/api/benchmark", { cleanup: true }); await reload(); }}>
          <Trash2 size={12} /> clean benchmark data
        </Btn>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        {scenarios.map((s: any) => {
          const last = runs.find((r: any) => r.scenario === s.id);
          return (
            <Panel
              key={s.id}
              title={s.name}
              subtitle={s.description}
              icon={<FlaskConical size={14} className="text-cyan" />}
              right={
                <div className="flex items-center gap-2">
                  {last && <Badge tone={last.status === "passed" ? "jade" : "rose"}>{last.status} · {last.durationMs}ms</Badge>}
                  <Btn size="sm" onClick={() => void run(s.id)} disabled={running !== null}>
                    {running === s.id ? "running…" : "run"}
                  </Btn>
                </div>
              }
            >
              <p className="mono mb-2 text-[10px] uppercase tracking-[0.14em] text-dim">hard acceptance</p>
              <ul className="space-y-1.5">
                {s.acceptance.map((a: string) => (
                  <li key={a} className="flex items-start gap-2 text-[11.5px] leading-snug text-mist">
                    <CheckCircle2 size={13} className="mt-0.5 shrink-0 text-jade/70" />
                    {a}
                  </li>
                ))}
              </ul>
              {last && (
                <div className="mt-3 border-t border-line pt-3">
                  <p className="mono mb-1.5 text-[10px] uppercase tracking-[0.14em] text-dim">last measurement · {relativeTime(last.createdAt)}</p>
                  <div className="mono flex flex-wrap gap-1.5">
                    {Object.entries(last.measured ?? {}).map(([k, v]) => (
                      <span key={k} className="rounded-md border border-line bg-panel2 px-2 py-1 text-[10.5px] text-mist">
                        {k} <span className="text-cyan">{String(v)}</span>
                      </span>
                    ))}
                  </div>
                  <ul className="mt-2 space-y-1">
                    {(last.checks ?? []).map((c: any, i: number) => (
                      <li key={i} className="mono flex items-start gap-2 text-[11px]">
                        {c.passed ? <CheckCircle2 size={12} className="mt-0.5 text-jade" /> : <XCircle size={12} className="mt-0.5 text-rose" />}
                        <span className="text-chalk">{c.name}</span>
                        <span className="text-dim">— {c.detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </Panel>
          );
        })}
      </div>

      {result && (
        <Panel
          title={result.passed === undefined ? "Qualification suite" : result.passed ? "Suite passed" : "Suite has failures"}
          className={cn(result.passed ? "border-jade/40" : "border-rose/40")}
          icon={result.passed ? <CheckCircle2 size={14} className="text-jade" /> : <XCircle size={14} className="text-rose" />}
        >
          <div className="space-y-3">
            {(result.results ?? []).map((r: any) => (
              <div key={r.scenario} className="rounded-lg border border-line bg-abyss/60 p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="text-[12.5px] text-chalk">{r.name}</p>
                  <Badge tone={r.checks.every((c: any) => c.passed) ? "jade" : "rose"}>{r.durationMs}ms</Badge>
                </div>
                <div className="mono mt-2 flex flex-wrap gap-1.5">
                  {Object.entries(r.measured ?? {}).map(([k, v]) => (
                    <span key={k} className="rounded border border-line bg-panel2 px-1.5 py-0.5 text-[10px] text-mist">{k} <span className="text-cyan">{String(v)}</span></span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Panel>
      )}

      <div className="grid gap-4 xl:grid-cols-[1fr_1fr]">
        <Panel title="Hard acceptance conditions" subtitle="Imposed on every run. Atractive presentation cannot average away a hard gate." bodyClass="p-0">
          <ul className="divide-y divide-line/60">
            {HARD_ACCEPTANCE.map((h) => (
              <li key={h} className="flex items-start gap-2.5 px-4 py-2.5 text-[12px] leading-snug text-mist">
                <CheckCircle2 size={14} className="mt-0.5 shrink-0 text-jade" />
                {h}
              </li>
            ))}
          </ul>
        </Panel>

        <Panel title="What to measure before scaling" subtitle="These are the metrics that decide the design, not agent counts." bodyClass="p-0">
          <Table head={["metric", "what it tells us"]}>
            {METRICS.map(([k, v]) => (
              <tr key={k} className="hover:bg-white/2">
                <Td className="mono text-[11px] text-chalk">{k}</Td>
                <Td className="text-[11.5px]">{v}</Td>
              </tr>
            ))}
          </Table>
        </Panel>
      </div>

      <Panel title="Run history" bodyClass="p-0">
        {runs.length === 0 ? (
          <div className="p-4"><Empty>{loading ? "loading…" : "no runs recorded yet"}</Empty></div>
        ) : (
          <Table head={["run", "scenario", "status", "targets", "measured", "checks", "duration", "when"]}>
            {runs.map((r: any) => (
              <tr key={r.id} className="hover:bg-white/2">
                <Td className="mono text-[10.5px] text-chalk">{r.id}</Td>
                <Td className="text-[11.5px]">{r.name}</Td>
                <Td><Badge tone={r.status === "passed" ? "jade" : "rose"}>{r.status}</Badge></Td>
                <Td className="mono text-[10px]">{Object.entries(r.targets ?? {}).map(([k, v]) => `${k}=${v}`).join(" ")}</Td>
                <Td className="mono max-w-[320px] truncate text-[10px]">{Object.entries(r.measured ?? {}).map(([k, v]) => `${k}=${v}`).join(" · ")}</Td>
                <Td className="mono text-[10.5px]">{(r.checks ?? []).filter((c: any) => c.passed).length}/{(r.checks ?? []).length}</Td>
                <Td className="mono text-[10.5px]">{r.durationMs}ms</Td>
                <Td className="mono text-[10.5px]">{relativeTime(r.createdAt)}</Td>
              </tr>
            ))}
          </Table>
        )}
      </Panel>

      <Panel title="Reading the numbers honestly">
        <KV k="Platform benchmarks" v="88 → 459 agent runs/sec at 2,048 sessions (vendor SQLite benchmark)" />
        <KV k="Streaming writes" v="≈27× fewer transactions for long answers, ≈5.7× fewer for parallel tools" />
        <KV k="CPU" v="≈25% lower under the same load" />
        <KV k="Caveat" v="synthetic platform results — they do not prove end-to-end business throughput with external APIs, research and browser execution" />
        <KV k="Firecracker" v="≤5 MiB VMM overhead, ~125 ms to guest user space in the specified 1-CPU / 128 MiB configuration" />
        <KV k="Queues" v="up to 5,000 msg/s per queue, 250 concurrent push consumers, 15 min max consumer duration" />
        <KV k="Workers" v="6 simultaneous outbound connections per request — never fan out with an unrestricted Promise.all" />
      </Panel>
    </div>
  );
}
