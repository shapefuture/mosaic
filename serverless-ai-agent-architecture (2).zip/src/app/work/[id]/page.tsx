"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useState } from "react";
import { ArrowLeft, Ban, CheckCircle2, FileText, GitBranch, Receipt, RotateCcw, ShieldCheck, XCircle } from "lucide-react";
import { useResource, postJSON } from "@/lib/client/state";
import { Badge, Btn, Dot, Empty, KV, Meter, Panel, QueueTone, SectionTitle, Status, Table, Td } from "@/components/ui";
import { Dag } from "@/components/Dag";
import { formatBytes, formatDuration, formatMicros, formatTime, relativeTime } from "@/lib/format";
import { cn } from "@/lib/cn";

export default function WorkUnitPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const { data, loading, error, reload } = useResource<any>(`/api/work-units?id=${encodeURIComponent(id)}`, { interval: 2000, deps: [id] });
  const [selectedTask, setSelectedTask] = useState<string | null>(null);
  const [tab, setTab] = useState<"tasks" | "events" | "artifacts" | "receipts" | "authority">("tasks");
  const [delegateOpen, setDelegateOpen] = useState(false);
  const [delegateText, setDelegateText] = useState("");
  const [openArtifact, setOpenArtifact] = useState<string | null>(null);

  if (loading && !data) return <Loading />;
  if (error) return <Empty>{error}</Empty>;
  if (!data?.workUnit) return <Empty>work unit not found</Empty>;

  const wu = data.workUnit;
  const tasks = data.tasks ?? [];
  const events = data.events ?? [];
  const artifacts = data.artifacts ?? [];
  const receiptsList = data.receipts ?? [];
  const tokens = data.tokens ?? [];
  const approvals = data.approvals ?? [];
  const summary = data.summary ?? {};
  const selected = tasks.find((t: any) => t.id === selectedTask) ?? null;
  const verification = wu.verification ?? { verdict: "pending", checks: [] };

  const act = async (action: string, body?: any) => {
    await postJSON(`/api/work-units/${id}`, { action, ...body });
    await reload();
  };

  return (
    <div className="space-y-5">
      <div>
        <Link href="/work" className="mono inline-flex items-center gap-1.5 text-[11px] text-dim hover:text-cyan">
          <ArrowLeft size={12} /> all work units
        </Link>
        <div className="mt-2 flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0">
            <p className="mono text-[10.5px] uppercase tracking-[0.2em] text-cyan">{wu.template} · {wu.id}</p>
            <h1 className="mt-1 text-[24px] font-semibold leading-tight tracking-[-0.02em] text-chalk">{wu.title}</h1>
            <p className="mt-1.5 max-w-3xl text-[12.5px] leading-relaxed text-mist">{wu.objective}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Status value={wu.status} />
            {wu.delegationDepth > 0 && <Badge tone="violet">depth {wu.delegationDepth}</Badge>}
            <Btn size="sm" tone="amber" onClick={() => setDelegateOpen((v) => !v)} disabled={wu.delegationDepth >= 2}>
              <GitBranch size={12} /> delegate
            </Btn>
            <Btn size="sm" tone="dim" onClick={() => void act("retry-failed")}>
              <RotateCcw size={12} /> retry failed
            </Btn>
            <Btn size="sm" tone="rose" onClick={() => void act("cancel")} disabled={["completed", "cancelled", "failed"].includes(wu.status)}>
              <Ban size={12} /> cancel
            </Btn>
          </div>
        </div>
      </div>

      {delegateOpen && (
        <Panel title="Cross-agent delegation" subtitle="A child Work Unit inherits attenuated authority: smaller budget, lower fan-out, depth + 1. No child may exceed its parent." icon={<GitBranch size={14} className="text-violet" />}>
          <div className="flex flex-wrap items-end gap-2">
            <input
              value={delegateText}
              onChange={(e) => setDelegateText(e.target.value)}
              placeholder="Describe the sub-objective to delegate to a specialist"
              className="min-w-[280px] flex-1 rounded-lg border border-line2 bg-abyss px-3 py-2 text-[12.5px] text-chalk outline-none placeholder:text-dim focus:border-cyan/60"
            />
            <Btn
              tone="violet"
              disabled={!delegateText.trim()}
              onClick={async () => {
                await act("delegate", { objective: delegateText.trim() });
                setDelegateText("");
                setDelegateOpen(false);
              }}
            >
              create child work unit
            </Btn>
          </div>
        </Panel>
      )}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-6">
        <Stat label="Progress" value={`${wu.doneCount}/${wu.taskCount}`} sub={<div className="mt-1"><Meter value={wu.doneCount} max={Math.max(1, wu.taskCount)} tone={wu.status === "completed" ? "jade" : "cyan"} /></div>} />
        <Stat label="Max parallelism" value={`${wu.maxParallelismObserved}×`} hint={`fan-out ceiling ${wu.fanOutLimit}`} />
        <Stat label="Spend" value={formatMicros(wu.spentMicros)} hint={`budget ${formatMicros(wu.budgetMicros)}`} />
        <Stat label="Model calls" value={wu.modelCalls} hint={`${wu.deterministicSteps} deterministic steps`} />
        <Stat label="Tokens" value={`${wu.tokensIn + wu.tokensOut}`} hint={`${wu.tokensIn} in · ${wu.tokensOut} out`} />
        <Stat label="Duration" value={wu.startedAt && wu.completedAt ? formatDuration(new Date(wu.completedAt).getTime() - new Date(wu.startedAt).getTime()) : "in flight"} hint={`owner ${data.owner?.name ?? "—"}`} />
      </div>

      <Panel
        title="Task graph"
        subtitle="Plan → fan-out → execute → join → verify → commit. Independent work runs concurrently; the join happens once, at the dependency boundary."
        icon={<GitBranch size={14} className="text-cyan" />}
        right={
          <div className="mono flex flex-wrap gap-2 text-[10px] text-dim">
            {summary.queues?.map((q: any) => (
              <span key={q.queue} className={cn("rounded-md border border-line bg-panel2 px-1.5 py-0.5", q.count > 0 && "text-mist")}>
                {q.queue} {q.count}
              </span>
            ))}
          </div>
        }
      >
        <Dag tasks={tasks} selected={selectedTask} onSelect={(id2) => setSelectedTask(id2 === selectedTask ? null : id2)} />
        <div className="mono mt-3 grid grid-cols-2 gap-2 border-t border-line pt-3 text-[10.5px] text-dim sm:grid-cols-4">
          {summary.tiers?.map((t: any) => (
            <span key={t.tier}>tier {t.tier}: <span className="text-mist">{t.count} tasks</span></span>
          ))}
          <span>deterministic share: <span className="text-jade">{summary.deterministicShare ?? 0}%</span></span>
        </div>
      </Panel>

      <div className="grid gap-4 xl:grid-cols-[1.5fr_1fr]">
        <Panel
          bodyClass="p-0"
          title="Execution detail"
          right={
            <div className="flex flex-wrap gap-1">
              {(["tasks", "events", "artifacts", "receipts", "authority"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={cn(
                    "mono rounded-md border px-2 py-0.5 text-[10px] uppercase tracking-[0.08em] transition-colors",
                    tab === t ? "border-cyan/50 bg-cyan/12 text-cyan" : "border-line bg-panel2 text-dim hover:text-mist",
                  )}
                >
                  {t} {t === "artifacts" ? artifacts.length : t === "receipts" ? receiptsList.length : t === "authority" ? tokens.length : ""}
                </button>
              ))}
            </div>
          }
        >
          {tab === "tasks" && (
            <Table head={["task", "kind", "queue", "tier", "status", "model", "tokens", "cost", "duration", "wait"]}>
              {tasks.map((t: any) => (
                <tr
                  key={t.id}
                  onClick={() => setSelectedTask(t.id === selectedTask ? null : t.id)}
                  className={cn("cursor-pointer hover:bg-white/2", selectedTask === t.id && "bg-cyan/6")}
                >
                  <Td className="max-w-[240px]">
                    <span className="mono block truncate text-chalk">{t.key}</span>
                    <span className="block truncate text-[11px] text-dim">{t.title}</span>
                  </Td>
                  <Td className="mono text-[11px]">{t.kind}</Td>
                  <Td><Badge tone={QueueTone(t.queue)}>{t.queue}</Badge></Td>
                  <Td className="mono">{t.tier}</Td>
                  <Td><Status value={t.status} /></Td>
                  <Td className="mono text-[10.5px]">{t.needsModel ? (t.modelId ?? "routed") : <span className="text-jade">none</span>}</Td>
                  <Td className="mono text-[10.5px]">{t.tokensIn + t.tokensOut || "—"}</Td>
                  <Td className="mono text-[10.5px]">{t.costMicros ? formatMicros(t.costMicros) : "—"}</Td>
                  <Td className="mono text-[10.5px]">{t.durationMs ? formatDuration(t.durationMs) : "—"}</Td>
                  <Td className="mono text-[10.5px]">{t.waitMs ? `${t.waitMs}ms` : "—"}</Td>
                </tr>
              ))}
            </Table>
          )}

          {tab === "events" && (
            <ul className="max-h-[520px] divide-y divide-line/60 overflow-y-auto">
              {events.map((ev: any) => (
                <li key={ev.id} className="px-4 py-2">
                  <p className="mono text-[11px]">
                    <span className={cn("mr-2", ev.type.includes("denied") || ev.type.includes("failed") ? "text-rose" : ev.type.includes("completed") || ev.type.includes("committed") ? "text-jade" : "text-cyan")}>
                      {ev.type}
                    </span>
                    <span className="text-mist">{ev.detail}</span>
                  </p>
                  <p className="mono mt-0.5 text-[10px] text-dim">{formatTime(ev.at)} · {ev.taskId ? String(ev.taskId).slice(0, 12) : "work unit"}</p>
                </li>
              ))}
              {!events.length && <li className="p-4"><Empty>no events</Empty></li>}
            </ul>
          )}

          {tab === "artifacts" && (
            <div className="divide-y divide-line/60">
              {artifacts.map((a: any) => (
                <div key={a.id} className="px-4 py-2.5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="flex items-center gap-2 text-[12.5px] text-chalk">
                        <FileText size={13} className="text-cyan" />
                        {a.title}
                      </p>
                      <p className="mono mt-0.5 truncate text-[10.5px] text-dim">{a.uri}</p>
                      <p className="mono mt-0.5 text-[10px] text-dim">{a.kind} · {formatBytes(a.bytes)} · {a.checksum}</p>
                    </div>
                    <Btn size="sm" onClick={() => setOpenArtifact(openArtifact === a.id ? null : a.id)}>
                      {openArtifact === a.id ? "hide" : "view"}
                    </Btn>
                  </div>
                  {openArtifact === a.id && (
                    <pre className="mono rise mt-2 max-h-[320px] overflow-auto whitespace-pre-wrap rounded-lg border border-line bg-abyss p-3 text-[11px] leading-relaxed text-mist">
                      {a.body ?? "(binary artifact — content stored in the object store, reference kept in PostgreSQL)"}
                    </pre>
                  )}
                </div>
              ))}
              {!artifacts.length && <div className="p-4"><Empty>no artifacts yet</Empty></div>}
            </div>
          )}

          {tab === "receipts" && (
            <Table head={["action", "external system", "status", "idempotency key", "replayed", "time"]}>
              {receiptsList.map((r: any) => (
                <tr key={r.id} className="hover:bg-white/2">
                  <Td className="mono text-chalk">{r.action}</Td>
                  <Td className="mono">{r.externalSystem}</Td>
                  <Td><Badge tone={r.status === "ok" ? "jade" : "rose"}>{r.status}</Badge></Td>
                  <Td className="mono text-[10.5px]">{r.idempotencyKey}</Td>
                  <Td>{r.replayed ? <Badge tone="amber">reconciled</Badge> : <span className="mono text-[10.5px] text-dim">—</span>}</Td>
                  <Td className="mono text-[10.5px]">{relativeTime(r.at)}</Td>
                </tr>
              ))}
              {!receiptsList.length && (
                <tr><Td colSpan={6}><Empty>no external side effects yet</Empty></Td></tr>
              )}
            </Table>
          )}

          {tab === "authority" && (
            <div className="space-y-3 p-4">
              {tokens.map((t: any) => (
                <div key={t.id} className="rounded-lg border border-line bg-abyss/70 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="mono text-[11.5px] text-chalk">{t.id}</span>
                    <Badge tone={t.revoked ? "rose" : new Date(t.expiresAt) > new Date() ? "jade" : "dim"}>
                      {t.revoked ? "revoked" : new Date(t.expiresAt) > new Date() ? "live" : "expired"}
                    </Badge>
                  </div>
                  <div className="mt-2 grid gap-1 sm:grid-cols-2">
                    <KV k="actions" v={t.actions?.join(", ")} />
                    <KV k="resources" v={t.resources?.join(", ")} />
                    <KV k="domains" v={t.domains?.join(", ") || "none"} />
                    <KV k="max cost" v={formatMicros(t.maxCostMicros)} />
                    <KV k="delegation depth" v={t.delegationDepth} />
                    <KV k="policy version" v={t.policyVersion} />
                    <KV k="granted / denied" v={`${t.grantedCount} / ${t.deniedCount}`} />
                    <KV k="signature" v={`${String(t.signature).slice(0, 14)}…`} />
                  </div>
                </div>
              ))}
              {!tokens.length && <Empty>no capability token minted yet</Empty>}
              {approvals.length > 0 && (
                <div className="rounded-lg border border-amber/30 bg-amber/6 p-3">
                  <p className="mono text-[10.5px] uppercase tracking-[0.14em] text-amber">human authorization</p>
                  <ul className="mt-2 space-y-2">
                    {approvals.map((a: any) => (
                      <li key={a.id} className="flex flex-wrap items-center justify-between gap-2 border-b border-line/60 pb-2 last:border-0">
                        <div>
                          <p className="mono text-[11.5px] text-chalk">{a.action}</p>
                          <p className="text-[11px] text-mist">{a.reason}</p>
                        </div>
                        {a.status === "pending" ? (
                          <div className="flex gap-1.5">
                            <Btn size="sm" tone="jade" onClick={async () => { await postJSON(`/api/approvals/${a.id}`, { decision: "approved", note: "authorized", decidedBy: "operator" }); await reload(); }}>
                              <CheckCircle2 size={12} /> approve
                            </Btn>
                            <Btn size="sm" tone="rose" onClick={async () => { await postJSON(`/api/approvals/${a.id}`, { decision: "denied", note: "denied", decidedBy: "operator" }); await reload(); }}>
                              <XCircle size={12} /> deny
                            </Btn>
                          </div>
                        ) : (
                          <Badge tone={a.status === "approved" ? "jade" : "rose"}>{a.status} · {a.decidedBy}</Badge>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </Panel>

        <div className="space-y-4">
          <Panel
            title={selected ? `Task · ${selected.key}` : "Acceptance criteria"}
            subtitle={selected ? selected.title : "The verifier checks the deliverable against these, blind to how hard the builder tried."}
            icon={selected ? <Dot tone="cyan" /> : <ShieldCheck size={14} className="text-jade" />}
            right={selected ? <Btn size="sm" tone="dim" onClick={() => setSelectedTask(null)}>clear</Btn> : undefined}
          >
            {selected ? (
              <div className="space-y-1">
                <KV k="kind" v={selected.kind} />
                <KV k="status" v={selected.status} />
                <KV k="queue / tier" v={`${selected.queue} / ${selected.tier}`} />
                <KV k="assigned" v={selected.assignedAgentId ?? "—"} />
                <KV k="attempts" v={`${selected.attempts}/${selected.maxAttempts}`} />
                <KV k="needs model" v={selected.needsModel ? "yes" : "no — deterministic"} />
                <KV k="idempotency key" v={selected.idempotencyKey ?? "—"} />
                <KV k="cost" v={selected.costMicros ? formatMicros(selected.costMicros) : "—"} />
                {selected.error && (
                  <p className="mono mt-2 rounded-md border border-rose/30 bg-rose/8 p-2 text-[11px] text-rose">{selected.error}</p>
                )}
                {Object.keys(selected.output ?? {}).length > 0 && (
                  <pre className="mono mt-2 max-h-[240px] overflow-auto whitespace-pre-wrap rounded-lg border border-line bg-abyss p-2.5 text-[10.5px] leading-relaxed text-mist">
                    {JSON.stringify(selected.output, null, 2)}
                  </pre>
                )}
              </div>
            ) : (
              <ul className="space-y-2">
                {(wu.acceptanceCriteria ?? []).map((c: string) => {
                  const check = (verification.checks ?? []).find((k: any) => k.name === c);
                  return (
                    <li key={c} className="flex items-start gap-2 rounded-lg border border-line bg-abyss/60 px-3 py-2">
                      {check ? (
                        check.passed ? <CheckCircle2 size={14} className="mt-0.5 shrink-0 text-jade" /> : <XCircle size={14} className="mt-0.5 shrink-0 text-rose" />
                      ) : (
                        <Dot tone="dim" />
                      )}
                      <span className="text-[12px] leading-snug text-mist">{c}</span>
                    </li>
                  );
                })}
                {!wu.acceptanceCriteria?.length && <Empty>planning will define acceptance criteria</Empty>}
              </ul>
            )}
          </Panel>

          <Panel title="Independent verification" subtitle="A critic agent that did not produce the work scores the deliverable against the criteria." icon={<Receipt size={14} className="text-violet" />}>
            <div className="flex items-center justify-between">
              <Badge tone={verification.verdict === "accepted" ? "jade" : verification.verdict === "rejected" ? "rose" : "dim"}>{verification.verdict}</Badge>
              <span className="mono text-[20px] font-semibold text-chalk">{verification.score ?? 0}<span className="text-[11px] text-dim">/100</span></span>
            </div>
            <div className="mt-2">
              <Meter value={verification.score ?? 0} max={100} tone={verification.score >= 80 ? "jade" : verification.score > 0 ? "amber" : "dim"} />
            </div>
            <ul className="mt-3 space-y-1.5">
              {(verification.checks ?? []).map((c: any, i: number) => (
                <li key={i} className="mono flex items-start gap-2 text-[11px]">
                  <span className={c.passed ? "text-jade" : "text-rose"}>{c.passed ? "✓" : "✕"}</span>
                  <span className="text-mist">{c.name}</span>
                </li>
              ))}
              {!(verification.checks ?? []).length && <li className="text-[11.5px] text-dim">verification runs after the join boundary</li>}
            </ul>
            {verification.gaps?.length > 0 && (
              <p className="mono mt-2 rounded-md border border-rose/30 bg-rose/8 p-2 text-[11px] text-rose">
                gaps → rework spawned: {verification.gaps.join("; ")}
              </p>
            )}
          </Panel>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, hint, sub }: { label: string; value: React.ReactNode; hint?: string; sub?: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-line bg-panel/70 px-4 py-3 hairline">
      <p className="text-[10.5px] uppercase tracking-[0.14em] text-dim">{label}</p>
      <p className="mono mt-1.5 text-[22px] font-semibold leading-none text-chalk">{value}</p>
      {sub}
      {hint && <p className="mt-1 text-[11px] leading-snug text-dim">{hint}</p>}
    </div>
  );
}

function Loading() {
  return (
    <div className="space-y-3">
      <div className="h-6 w-64 animate-pulse rounded bg-panel2" />
      <div className="h-24 w-full animate-pulse rounded-xl bg-panel2" />
      <div className="h-64 w-full animate-pulse rounded-xl bg-panel2" />
    </div>
  );
}
