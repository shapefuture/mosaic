"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { ArrowRight, Network, Plus } from "lucide-react";
import { useAos } from "@/lib/client/state";
import { Badge, Btn, Empty, Meter, Panel, SectionTitle, Stat, Status, Table, Td } from "@/components/ui";
import { formatMicros, relativeTime } from "@/lib/format";
import { cn } from "@/lib/cn";

const TEMPLATES = [
  { id: "auto", label: "auto-detect" },
  { id: "market-intelligence", label: "market intelligence" },
  { id: "competitive-pricing", label: "competitive pricing" },
  { id: "inbound-triage", label: "inbound triage" },
  { id: "code-delivery", label: "code delivery" },
  { id: "authenticated-web-job", label: "authenticated web job" },
  { id: "content-pipeline", label: "content pipeline" },
];

export default function WorkPage() {
  const { data, post, busy } = useAos();
  const [objective, setObjective] = useState("");
  const [template, setTemplate] = useState("auto");
  const [fanOut, setFanOut] = useState(12);
  const [budget, setBudget] = useState(0.75);
  const [agentId, setAgentId] = useState<string>("");
  const [filter, setFilter] = useState<string>("all");
  const [created, setCreated] = useState<string | null>(null);

  const workUnits = data?.workUnits ?? [];
  const agents = data?.agents ?? [];
  const counts = data?.tasks?.counts ?? {};

  const filtered = useMemo(
    () => (filter === "all" ? workUnits : workUnits.filter((w: any) => w.status === filter)),
    [workUnits, filter],
  );

  async function create() {
    if (!objective.trim()) return;
    const res = await post("/api/work-units", {
      objective: objective.trim(),
      template,
      fanOutLimit: fanOut,
      budgetMicros: Math.round(budget * 1_000_000),
      agentId: agentId || undefined,
    });
    setCreated(res?.workUnit?.id ?? null);
    setObjective("");
  }

  const statuses = ["all", "planning", "running", "awaiting_approval", "verifying", "completed", "rejected", "failed"];

  return (
    <div className="space-y-5">
      <SectionTitle eyebrow="Layer 3 · universal work engine" title="Work Units — durable task graphs">
        A Work Unit owns the business process: assignment, delegation, bounded parallel subtasks, approvals, waiting, deadlines and final completion. The
        session actor owns the conversation. They never both own the same external side effect.
      </SectionTitle>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Stat label="Work units" value={workUnits.length} tone="cyan" />
        <Stat label="Tasks running" value={counts.running ?? 0} tone="blue" hint={`${counts.ready ?? 0} ready · ${counts.pending ?? 0} pending`} />
        <Stat label="Blocked on approval" value={counts.blocked ?? 0} tone="amber" />
        <Stat label="Completed tasks" value={counts.done ?? 0} tone="jade" hint={`${counts.failed ?? 0} failed`} />
        <Stat label="Side-effect receipts" value={data?.counters?.receipts ?? 0} tone="violet" hint={`${data?.counters?.artifacts ?? 0} artifacts in object store`} />
      </div>

      <Panel title="Compose a Work Unit" subtitle="Define the outcome; the planner picks the template, bounds the fan-out and assigns the least capable sufficient tier per task." icon={<Plus size={14} className="text-cyan" />}>
        <div className="grid gap-3 lg:grid-cols-[1.6fr_1fr]">
          <div className="space-y-3">
            <textarea
              rows={3}
              value={objective}
              onChange={(e) => setObjective(e.target.value)}
              placeholder="e.g. Compare the six leading vendors' published pricing, normalise to annual USD per seat, and flag contradictions"
              className="w-full resize-y rounded-lg border border-line2 bg-abyss px-3 py-2 text-[13px] leading-relaxed text-chalk outline-none placeholder:text-dim focus:border-cyan/60"
            />
            <div className="flex flex-wrap items-center gap-2">
              <Btn onClick={create} disabled={busy || !objective.trim()}>
                <Network size={12} /> create + plan
              </Btn>
              {created && (
                <Link href={`/work/${created}`}>
                  <Btn tone="jade">
                    inspect {created.slice(0, 12)}… <ArrowRight size={11} />
                  </Btn>
                </Link>
              )}
            </div>
          </div>
          <div className="space-y-3 rounded-lg border border-line bg-abyss/60 p-3">
            <label className="block">
              <span className="mono text-[10px] uppercase tracking-[0.14em] text-dim">Template</span>
              <select
                value={template}
                onChange={(e) => setTemplate(e.target.value)}
                className="mt-1 w-full rounded-lg border border-line2 bg-panel2 px-2 py-1.5 text-[12px] text-chalk outline-none focus:border-cyan/60"
              >
                {TEMPLATES.map((t) => (
                  <option key={t.id} value={t.id}>{t.label}</option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="mono text-[10px] uppercase tracking-[0.14em] text-dim">Owner agent</span>
              <select
                value={agentId}
                onChange={(e) => setAgentId(e.target.value)}
                className="mt-1 w-full rounded-lg border border-line2 bg-panel2 px-2 py-1.5 text-[12px] text-chalk outline-none focus:border-cyan/60"
              >
                <option value="">auto-assign by department</option>
                {agents.map((a: any) => (
                  <option key={a.id} value={a.id}>{a.name} — {a.role}</option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="mono flex justify-between text-[10px] uppercase tracking-[0.14em] text-dim">
                bounded fan-out <span className="text-cyan">{fanOut}</span>
              </span>
              <input type="range" min={2} max={64} value={fanOut} onChange={(e) => setFanOut(Number(e.target.value))} className="mt-2 w-full accent-cyan" />
            </label>
            <label className="block">
              <span className="mono flex justify-between text-[10px] uppercase tracking-[0.14em] text-dim">
                budget ceiling <span className="text-cyan">${budget.toFixed(2)}</span>
              </span>
              <input type="range" min={0.1} max={5} step={0.05} value={budget} onChange={(e) => setBudget(Number(e.target.value))} className="mt-2 w-full accent-cyan" />
            </label>
          </div>
        </div>
      </Panel>

      <Panel
        title="All Work Units"
        bodyClass="p-0"
        right={
          <div className="flex flex-wrap gap-1">
            {statuses.map((s) => (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className={cn(
                  "mono rounded-md border px-2 py-0.5 text-[10px] uppercase tracking-[0.08em] transition-colors",
                  filter === s ? "border-cyan/50 bg-cyan/12 text-cyan" : "border-line bg-panel2 text-dim hover:text-mist",
                )}
              >
                {s.replace(/_/g, " ")}
              </button>
            ))}
          </div>
        }
      >
        {filtered.length === 0 ? (
          <div className="p-4"><Empty>no work units match this filter</Empty></div>
        ) : (
          <Table head={["work unit", "owner", "template", "status", "progress", "max ∥", "tasks", "spend", "verification", "created"]}>
            {filtered.map((wu: any) => {
              const agent = agents.find((a: any) => a.id === wu.ownerAgentId);
              return (
                <tr key={wu.id} className="hover:bg-white/2">
                  <Td className="max-w-[300px]">
                    <Link href={`/work/${wu.id}`} className="block truncate text-chalk hover:text-cyan">{wu.title}</Link>
                    <span className="mono text-[10px] text-dim">
                      {wu.id}
                      {wu.parentWorkUnitId ? ` ← ${String(wu.parentWorkUnitId).slice(0, 12)}` : ""}
                      {wu.delegationDepth > 0 ? ` · depth ${wu.delegationDepth}` : ""}
                    </span>
                  </Td>
                  <Td>{agent?.name ?? "—"}</Td>
                  <Td><Badge tone="violet">{wu.template}</Badge></Td>
                  <Td><Status value={wu.status} /></Td>
                  <Td className="w-[150px]">
                    <Meter value={wu.doneCount} max={Math.max(1, wu.taskCount)} tone={wu.status === "completed" ? "jade" : wu.status === "failed" ? "rose" : "cyan"} right={`${wu.doneCount}/${wu.taskCount}`} />
                  </Td>
                  <Td className="mono">{wu.maxParallelismObserved}×</Td>
                  <Td className="mono">{wu.taskCount}</Td>
                  <Td className="mono">{formatMicros(wu.spentMicros)}</Td>
                  <Td>
                    {wu.verification?.verdict && wu.verification.verdict !== "pending" ? (
                      <Badge tone={wu.verification.verdict === "accepted" ? "jade" : "rose"}>{wu.verification.verdict} {wu.verification.score ?? ""}</Badge>
                    ) : (
                      <span className="mono text-[10.5px] text-dim">pending</span>
                    )}
                  </Td>
                  <Td className="mono text-[10.5px]">{relativeTime(wu.createdAt)}</Td>
                </tr>
              );
            })}
          </Table>
        )}
      </Panel>
    </div>
  );
}
