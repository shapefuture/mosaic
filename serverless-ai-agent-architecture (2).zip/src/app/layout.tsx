import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { AosProvider } from "@/lib/client/state";
import { Shell } from "@/components/Shell";

export const metadata: Metadata = {
  title: "AOS v3 — the hibernating, massively parallel AI operating system",
  description:
    "Event-driven agent control plane: logical identities, hibernating durable sessions, bounded parallel Work Units, tiered execution, deterministic authority and independent verification.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-void text-chalk antialiased">
        <AosProvider interval={2000}>
          <Shell>{children}</Shell>
        </AosProvider>
      </body>
    </html>
  );
}
