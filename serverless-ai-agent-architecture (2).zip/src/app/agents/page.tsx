"use client";

import Link from "next/link";
import { useState } from "react";
import { Brain, Cpu, Moon, Plus, ShieldCheck, Sparkles, UserPlus, Wallet } from "lucide-react";
import { useAos } from "@/lib/client/state";
import { Badge, Btn, Dot, Empty, KV, Meter, Panel, SectionTitle, Stat, Status } from "@/components/ui";
import { formatMicros, relativeTime } from "@/lib/format";
import { cn } from "@/lib/cn";

const DEPARTMENTS = ["research", "engineering", "operations", "support", "marketing", "finance", "quality", "governance"];
const TEMPLATES = [
  { id: "specialist", label: "Research specialist" },
  { id: "engineer", label: "Software engineer" },
  { id: "operator", label: "Browser operator" },
  { id: "critic", label: "Verification critic" },
];

export default function AgentsPage() {
  const { data, post, busy } = useAos();
  const agents = data?.agents ?? [];
  const [form, setForm] = useState({ name: "", role: "", department: "research", template: "specialist", capabilities: "", domains: "", maxCost: 0.25 });
  const [message, setMessage] = useState<string | null>(null);
  const [query, setQuery] = useState("");

  const grouped = DEPARTMENTS.map((d) => ({ dept: d, agents: agents.filter((a: any) => a.department === d) })).filter((g) => g.agents.length);
  const filtered = query
    ? agents.filter((a: any) => `${a.name} ${a.role} ${a.department} ${a.capabilities?.join(" ")}`.toLowerCase().includes(query.toLowerCase()))
    : null;

  const resident = agents.filter((a: any) => a.status === "active").length;
  const totalMemory = agents.reduce((acc: number, a: any) => acc + (a.residentMemoryMb ?? 0), 0);

  async function create() {
    if (!form.name.trim() || !form.role.trim()) {
      setMessage("name and role are required");
      return;
    }
    const res = await post("/api/agents", {
      name: form.name.trim(),
      role: form.role.trim(),
      department: form.department,
      template: form.template,
      capabilities: form.capabilities ? form.capabilities.split(",").map((c) => c.trim()).filter(Boolean) : undefined,
      domains: form.domains ? form.domains.split(",").map((c) => c.trim()).filter(Boolean) : undefined,
      maxCostMicros: Math.round(form.maxCost * 1_000_000),
    });
    setMessage(res?.note ?? "agent registered");
    setForm({ ...form, name: "", role: "", capabilities: "", domains: "" });
  }

  return (
    <div className="space-y-5">
      <SectionTitle eyebrow="Layer 2 · durable identities" title="Agent registry">
        An agent is an identity, a role, a capability manifest and persistent knowledge — not a process, not a computer, not a loaded model. Registering a
        specialist costs one database row. It consumes execution resources only while it has work.
      </SectionTitle>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Stat label="Registered identities" value={agents.length} tone="violet" hint={`${grouped.length} departments`} />
        <Stat label="Currently active" value={resident} tone="cyan" hint={`${agents.length - resident} hibernating at zero cost`} />
        <Stat label="Resident memory" value={Math.round(totalMemory)} unit="MiB" tone="blue" hint="only for identities with live work" />
        <Stat label="Naive design cost" value={`${Math.round((agents.length * 512) / 1024)} GiB`} tone="rose" hint="one process + VM per agent" />
        <Stat label="Verified deliverables" value={agents.reduce((a: number, x: any) => a + x.acceptedDeliverables, 0)} tone="jade" hint={`${agents.reduce((a: number, x: any) => a + x.rejectedDeliverables, 0)} rejected by critics`} />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1fr_1.5fr]">
        <Panel title="Register a specialist" subtitle="Role templates supply the capability manifest and the authority policy. Authority is always attenuated to least privilege." icon={<UserPlus size={14} className="text-cyan" />}>
          <div className="space-y-3">
            <Field label="Name">
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Nora Feldt" className={inputCls} />
            </Field>
            <Field label="Role">
              <input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} placeholder="e.g. Procurement Analyst" className={inputCls} />
            </Field>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Department">
                <select value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} className={inputCls}>
                  {DEPARTMENTS.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </Field>
              <Field label="Role template">
                <select value={form.template} onChange={(e) => setForm({ ...form, template: e.target.value })} className={inputCls}>
                  {TEMPLATES.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
                </select>
              </Field>
            </div>
            <Field label="Capabilities (comma separated, optional)">
              <input value={form.capabilities} onChange={(e) => setForm({ ...form, capabilities: e.target.value })} placeholder="http.get, extract, data.write" className={inputCls} />
            </Field>
            <Field label="Domain allowlist (optional)">
              <input value={form.domains} onChange={(e) => setForm({ ...form, domains: e.target.value })} placeholder="vendor.example, *.gov.example" className={inputCls} />
            </Field>
            <Field label={`Per-action cost ceiling · $${form.maxCost.toFixed(2)}`}>
              <input type="range" min={0.05} max={2} step={0.05} value={form.maxCost} onChange={(e) => setForm({ ...form, maxCost: Number(e.target.value) })} className="w-full accent-cyan" />
            </Field>
            <div className="flex items-center gap-2">
              <Btn onClick={create} disabled={busy}><Plus size={12} /> register identity</Btn>
              {message && <span className="mono text-[11px] text-jade">{message}</span>}
            </div>
            <p className="text-[11px] leading-relaxed text-dim">
              No process starts. No model loads. No computer boots. The identity becomes resident only when a session opens or a Work Unit assigns it work.
            </p>
          </div>
        </Panel>

        <Panel
          title="Registry"
          subtitle="Filter by name, role, department or capability."
          right={<input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="filter…" className={cn(inputCls, "w-44")} />}
          bodyClass="p-0"
        >
          {filtered ? (
            <div className="grid gap-3 p-4 md:grid-cols-2">
              {filtered.map((a: any) => <AgentCard key={a.id} agent={a} />)}
              {!filtered.length && <div className="md:col-span-2"><Empty>no identity matches that filter</Empty></div>}
            </div>
          ) : (
            <div className="space-y-4 p-4">
              {grouped.map((g) => (
                <div key={g.dept}>
                  <p className="mono mb-2 text-[10px] uppercase tracking-[0.18em] text-dim">{g.dept} · {g.agents.length}</p>
                  <div className="grid gap-3 md:grid-cols-2">
                    {g.agents.map((a: any) => <AgentCard key={a.id} agent={a} />)}
                  </div>
                </div>
              ))}
              {!grouped.length && <Empty>no agents registered</Empty>}
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}

const inputCls =
  "mt-1 w-full rounded-lg border border-line2 bg-abyss px-2.5 py-1.5 text-[12.5px] text-chalk outline-none placeholder:text-dim focus:border-cyan/60";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mono text-[10px] uppercase tracking-[0.14em] text-dim">{label}</span>
      {children}
    </label>
  );
}

function AgentCard({ agent }: { agent: any }) {
  return (
    <Link
      href={`/agents/${agent.id}`}
      className="group block rounded-xl border border-line bg-panel2/70 p-3 transition-colors hover:border-cyan/40"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate text-[13px] font-semibold text-chalk group-hover:text-cyan">{agent.name}</p>
          <p className="truncate text-[11.5px] text-mist">{agent.role}</p>
        </div>
        <Status value={agent.status} />
      </div>

      <div className="mono mt-2 flex flex-wrap gap-1">
        {(agent.capabilities ?? []).slice(0, 4).map((c: string) => (
          <span key={c} className="rounded border border-line bg-abyss px-1.5 py-0.5 text-[9.5px] text-mist">{c}</span>
        ))}
        {(agent.capabilities ?? []).length > 4 && <span className="text-[9.5px] text-dim">+{agent.capabilities.length - 4}</span>}
      </div>

      <div className="mt-2.5 grid grid-cols-2 gap-x-3 gap-y-1 text-[10.5px]">
        <span className="mono flex items-center gap-1.5 text-dim"><Cpu size={11} /> {Math.round(agent.residentMemoryMb ?? 0)} MiB resident</span>
        <span className="mono flex items-center gap-1.5 text-dim"><Moon size={11} /> {agent.sessions?.hibernated ?? 0} dormant sessions</span>
        <span className="mono flex items-center gap-1.5 text-dim"><Wallet size={11} /> {formatMicros((agent.spentCents ?? 0) * 10000)} spent</span>
        <span className="mono flex items-center gap-1.5 text-dim"><Sparkles size={11} /> {agent.completedWorkUnits ?? 0} work units</span>
        <span className="mono flex items-center gap-1.5 text-dim"><Brain size={11} /> {agent.memoryRecords ?? 0} memories</span>
        <span className="mono flex items-center gap-1.5 text-dim"><ShieldCheck size={11} /> {agent.stats?.acceptanceRate ?? (agent.completedWorkUnits ? Math.round((agent.acceptedDeliverables / agent.completedWorkUnits) * 100) : 0)}% accepted</span>
      </div>

      <div className="mt-2">
        <Meter
          value={agent.workload?.running ?? 0}
          max={Math.max(4, (agent.workload?.running ?? 0) + (agent.workload?.done ?? 0))}
          tone={agent.workload?.running ? "cyan" : "dim"}
          label={<span className="mono text-[10px] text-dim">live workload</span>}
          right={`${agent.workload?.running ?? 0} running`}
        />
      </div>

      <p className="mono mt-2 flex items-center gap-1.5 text-[9.5px] text-dim">
        <Dot tone={agent.status === "active" ? "jade" : "violet"} pulse={agent.status === "active"} />
        {agent.status === "active" ? "executing on the shared pool" : "identity only · zero resident compute"} · {relativeTime(agent.createdAt)}
      </p>
    </Link>
  );
}

void KV;
void Badge;
