"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useState } from "react";
import { ArrowLeft, Brain, MessagesSquare, ShieldCheck, Wallet } from "lucide-react";
import { useResource, postJSON } from "@/lib/client/state";
import { Badge, Btn, Empty, KV, Meter, Panel, SectionTitle, Status, Table, Td } from "@/components/ui";
import { formatBytes, formatMicros, relativeTime } from "@/lib/format";
import { cn } from "@/lib/cn";

export default function AgentDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const { data, loading, error, reload } = useResource<any>(`/api/agents/${encodeURIComponent(id)}`, { interval: 3000, deps: [id] });
  const [tab, setTab] = useState<"sessions" | "tasks" | "work" | "memory" | "authority">("sessions");

  if (loading && !data) return <div className="h-64 animate-pulse rounded-xl bg-panel2" />;
  if (error) return <Empty>{error}</Empty>;
  if (!data?.agent) return <Empty>agent not found</Empty>;

  const agent = data.agent;
  const stats = data.stats ?? {};
  const authority = agent.authorityPolicy ?? {};
  const modelPolicy = agent.modelPolicy ?? {};

  async function openSession() {
    const res = await postJSON("/api/sessions", { agentId: id, title: `Working session · ${agent.role}`, channel: "web" });
    window.location.href = `/sessions?focus=${res.session.id}`;
  }

  return (
    <div className="space-y-5">
      <div>
        <Link href="/agents" className="mono inline-flex items-center gap-1.5 text-[11px] text-dim hover:text-cyan">
          <ArrowLeft size={12} /> registry
        </Link>
        <div className="mt-2 flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="mono text-[10.5px] uppercase tracking-[0.2em] text-cyan">{agent.department} · {agent.id}</p>
            <h1 className="mt-1 text-[26px] font-semibold leading-tight tracking-[-0.02em] text-chalk">{agent.name}</h1>
            <p className="mt-1 text-[13px] text-mist">{agent.role} · system profile {agent.systemProfileVersion}</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Status value={agent.status} />
            <Btn size="sm" onClick={openSession}><MessagesSquare size={12} /> open session</Btn>
            <Link href="/work"><Btn size="sm" tone="violet">assign work</Btn></Link>
          </div>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Metric label="Resident memory" value={`${Math.round(agent.residentMemoryMb ?? 0)} MiB`} hint={agent.status === "active" ? "executing a turn or task" : "identity in storage only"} tone="cyan" />
        <Metric label="Sessions" value={data.sessions?.length ?? 0} hint={`${data.sessions?.filter((s: any) => s.state === "resident").length ?? 0} resident · ${data.sessions?.filter((s: any) => s.state !== "resident").length ?? 0} dormant`} />
        <Metric label="Tasks completed" value={stats.tasksDone ?? 0} hint={`${stats.deterministicSteps ?? 0} without a model call`} tone="jade" />
        <Metric label="Acceptance rate" value={`${stats.acceptanceRate ?? 0}%`} hint={`${agent.acceptedDeliverables ?? 0} accepted · ${agent.rejectedDeliverables ?? 0} rejected`} tone="violet" />
        <Metric label="Spend" value={formatMicros(stats.costMicros ?? 0)} hint={`${stats.tokens ?? 0} tokens routed`} tone="amber" />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1fr_1.4fr]">
        <div className="space-y-4">
          <Panel title="Capability manifest" subtitle="Filtered from the central catalog by role — never the whole tool list in every prompt." icon={<ShieldCheck size={14} className="text-cyan" />}>
            <div className="mono flex flex-wrap gap-1.5">
              {(agent.capabilities ?? []).map((c: string) => (
                <span key={c} className="rounded-md border border-line2 bg-panel2 px-2 py-1 text-[10.5px] text-mist">{c}</span>
              ))}
            </div>
            <p className="mono mt-3 text-[10px] uppercase tracking-[0.14em] text-dim">Versioned skills</p>
            <ul className="mt-1.5 space-y-1.5">
              {(agent.skills ?? []).map((s: any) => (
                <li key={`${s.name}-${s.version}`} className="flex items-center justify-between gap-2 rounded-lg border border-line bg-abyss/60 px-2.5 py-1.5">
                  <span className="mono text-[11px] text-chalk">{s.name} <span className="text-dim">v{s.version}</span></span>
                  <Badge tone={s.verified ? "jade" : "amber"}>{s.verified ? "verified" : s.source}</Badge>
                </li>
              ))}
              {!(agent.skills ?? []).length && <li className="text-[11.5px] text-dim">no skills yet — the memory compiler promotes procedures after repeated success</li>}
            </ul>
          </Panel>

          <Panel title="Authority policy" subtitle="An agent can request an action. It cannot authorize itself." icon={<ShieldCheck size={14} className="text-rose" />}>
            <KV k="permitted actions" v={(authority.actions ?? []).join(", ") || "none"} />
            <KV k="resources" v={(authority.resources ?? []).join(", ") || "none"} />
            <KV k="domain allowlist" v={(authority.domains ?? []).join(", ") || "default deny"} />
            <KV k="max cost / action" v={formatMicros(authority.maxCostMicros ?? 0)} />
            <KV k="max delegation depth" v={authority.maxDelegationDepth ?? 0} />
            <KV k="requires human approval" v={(authority.requiresApproval ?? []).join(", ") || "none"} />
            <KV k="memory scope" v={agent.memoryScope} />
            <KV k="budget" v={<span>{formatMicros((agent.budgetCents ?? 0) * 10000)} · spent {formatMicros((agent.spentCents ?? 0) * 10000)}</span>} />
            <div className="mt-2">
              <Meter value={agent.spentCents ?? 0} max={Math.max(1, agent.budgetCents ?? 1)} tone={(agent.spentCents ?? 0) / Math.max(1, agent.budgetCents ?? 1) > 0.8 ? "rose" : "jade"} label="budget utilization" right={`${Math.round(((agent.spentCents ?? 0) / Math.max(1, agent.budgetCents ?? 1)) * 100)}%`} />
            </div>
          </Panel>

          <Panel title="Model policy" subtitle="Task-aware routing: never call the strongest model by default." icon={<Brain size={14} className="text-violet" />}>
            {Object.entries(modelPolicy).map(([k, v]) => (
              <KV key={k} k={k} v={String(v)} />
            ))}
          </Panel>
        </div>

        <Panel
          bodyClass="p-0"
          title="Activity"
          right={
            <div className="flex flex-wrap gap-1">
              {(["sessions", "tasks", "work", "memory", "authority"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={cn(
                    "mono rounded-md border px-2 py-0.5 text-[10px] uppercase tracking-[0.08em] transition-colors",
                    tab === t ? "border-cyan/50 bg-cyan/12 text-cyan" : "border-line bg-panel2 text-dim hover:text-mist",
                  )}
                >
                  {t}
                </button>
              ))}
            </div>
          }
        >
          {tab === "sessions" && (
            <Table head={["session", "state", "turns", "resident", "storage", "wake / hibernate", "evictions", "last active"]}>
              {(data.sessions ?? []).map((s: any) => (
                <tr key={s.id} className="hover:bg-white/2">
                  <Td>
                    <Link href={`/sessions?focus=${s.id}`} className="text-chalk hover:text-cyan">{s.title}</Link>
                    <span className="mono block text-[10px] text-dim">{s.id}</span>
                  </Td>
                  <Td><Status value={s.state} /></Td>
                  <Td className="mono">{s.turns}</Td>
                  <Td className="mono">{Math.round(s.residentMemoryMb)} MiB</Td>
                  <Td className="mono">{formatBytes(s.storageBytes)}</Td>
                  <Td className="mono">{s.wakes} / {s.hibernations}</Td>
                  <Td className="mono">{s.evictions}</Td>
                  <Td className="mono text-[10.5px]">{relativeTime(s.lastActiveAt)}</Td>
                </tr>
              ))}
              {!(data.sessions ?? []).length && <tr><Td colSpan={8}><Empty>no sessions — this identity has never been woken</Empty></Td></tr>}
            </Table>
          )}

          {tab === "tasks" && (
            <Table head={["task", "kind", "queue", "tier", "status", "cost", "duration"]}>
              {(data.tasks ?? []).map((t: any) => (
                <tr key={t.id} className="hover:bg-white/2">
                  <Td>
                    <Link href={`/work/${t.workUnitId}`} className="mono text-chalk hover:text-cyan">{t.key}</Link>
                    <span className="block truncate text-[11px] text-dim">{t.title}</span>
                  </Td>
                  <Td className="mono text-[11px]">{t.kind}</Td>
                  <Td className="mono text-[11px]">{t.queue}</Td>
                  <Td className="mono">{t.tier}</Td>
                  <Td><Status value={t.status} /></Td>
                  <Td className="mono text-[10.5px]">{t.costMicros ? formatMicros(t.costMicros) : "—"}</Td>
                  <Td className="mono text-[10.5px]">{t.durationMs ? `${t.durationMs}ms` : "—"}</Td>
                </tr>
              ))}
              {!(data.tasks ?? []).length && <tr><Td colSpan={7}><Empty>no task history</Empty></Td></tr>}
            </Table>
          )}

          {tab === "work" && (
            <Table head={["work unit", "template", "status", "progress", "spend", "verification", "created"]}>
              {(data.workUnits ?? []).map((w: any) => (
                <tr key={w.id} className="hover:bg-white/2">
                  <Td className="max-w-[280px]">
                    <Link href={`/work/${w.id}`} className="block truncate text-chalk hover:text-cyan">{w.title}</Link>
                    <span className="mono text-[10px] text-dim">{w.id}</span>
                  </Td>
                  <Td><Badge tone="violet">{w.template}</Badge></Td>
                  <Td><Status value={w.status} /></Td>
                  <Td className="w-[140px]"><Meter value={w.doneCount} max={Math.max(1, w.taskCount)} tone="cyan" right={`${w.doneCount}/${w.taskCount}`} /></Td>
                  <Td className="mono">{formatMicros(w.spentMicros)}</Td>
                  <Td className="mono text-[10.5px]">{w.verification?.verdict ?? "pending"}</Td>
                  <Td className="mono text-[10.5px]">{relativeTime(w.createdAt)}</Td>
                </tr>
              ))}
              {!(data.workUnits ?? []).length && <tr><Td colSpan={7}><Empty>no work units owned</Empty></Td></tr>}
            </Table>
          )}

          {tab === "memory" && (
            <Table head={["kind", "subject", "content", "trust", "confidence", "hits", "provenance"]}>
              {(data.memories ?? []).map((m: any) => (
                <tr key={m.id} className="hover:bg-white/2">
                  <Td><Badge tone={m.kind === "procedural" ? "violet" : m.kind === "semantic" ? "cyan" : m.kind === "episodic" ? "blue" : "jade"}>{m.kind}</Badge></Td>
                  <Td className="text-chalk">{m.subject}</Td>
                  <Td className="max-w-[380px] truncate">{m.content}</Td>
                  <Td><Badge tone={m.trust === "verified" ? "jade" : m.trust === "contested" ? "rose" : "dim"}>{m.trust}</Badge></Td>
                  <Td className="mono">{Math.round(m.confidence * 100)}%</Td>
                  <Td className="mono">{m.hits}</Td>
                  <Td className="mono text-[10px]">{m.provenance?.method}{m.provenance?.workUnitId ? ` · ${String(m.provenance.workUnitId).slice(0, 10)}` : ""}</Td>
                </tr>
              ))}
              {!(data.memories ?? []).length && <tr><Td colSpan={7}><Empty>no scoped memory records yet</Empty></Td></tr>}
            </Table>
          )}

          {tab === "authority" && (
            <div className="space-y-4 p-4">
              <div>
                <p className="mono mb-2 text-[10px] uppercase tracking-[0.14em] text-dim">Capability tokens</p>
                <Table head={["token", "actions", "domains", "ceiling", "depth", "granted / denied", "expiry"]}>
                  {(data.tokens ?? []).map((t: any) => (
                    <tr key={t.id} className="hover:bg-white/2">
                      <Td className="mono text-[10.5px] text-chalk">{t.id}</Td>
                      <Td className="mono text-[10.5px]">{(t.actions ?? []).join(", ")}</Td>
                      <Td className="mono text-[10.5px]">{(t.domains ?? []).join(", ") || "—"}</Td>
                      <Td className="mono text-[10.5px]">{formatMicros(t.maxCostMicros)}</Td>
                      <Td className="mono">{t.delegationDepth}</Td>
                      <Td className="mono text-[10.5px]"><span className="text-jade">{t.grantedCount}</span> / <span className="text-rose">{t.deniedCount}</span></Td>
                      <Td className="mono text-[10.5px]">{new Date(t.expiresAt) > new Date() ? <Badge tone="jade">live</Badge> : <Badge tone="dim">expired</Badge>}</Td>
                    </tr>
                  ))}
                  {!(data.tokens ?? []).length && <tr><Td colSpan={7}><Empty>no tokens minted</Empty></Td></tr>}
                </Table>
              </div>
              <div>
                <p className="mono mb-2 text-[10px] uppercase tracking-[0.14em] text-dim">External side-effect receipts</p>
                <Table head={["action", "system", "status", "idempotency", "time"]}>
                  {(data.receipts ?? []).map((r: any) => (
                    <tr key={r.id} className="hover:bg-white/2">
                      <Td className="mono text-[11px] text-chalk">{r.action}</Td>
                      <Td className="mono text-[11px]">{r.externalSystem}</Td>
                      <Td><Badge tone={r.status === "ok" ? "jade" : "rose"}>{r.status}</Badge></Td>
                      <Td className="mono text-[10px]">{r.idempotencyKey}{r.replayed ? " · reconciled" : ""}</Td>
                      <Td className="mono text-[10.5px]">{relativeTime(r.at)}</Td>
                    </tr>
                  ))}
                  {!(data.receipts ?? []).length && <tr><Td colSpan={5}><Empty>no external side effects</Empty></Td></tr>}
                </Table>
              </div>
              <div className="rounded-lg border border-line bg-abyss/60 p-3">
                <p className="mono flex items-center gap-2 text-[10.5px] uppercase tracking-[0.14em] text-dim"><Wallet size={12} /> reporting line</p>
                <p className="mt-1.5 text-[12px] text-mist">
                  {agent.reportsTo ? (
                    <>Reports to <Link className="text-cyan hover:underline" href={`/agents/${agent.reportsTo}`}>{agent.reportsTo}</Link></>
                  ) : (
                    "Top of the organizational graph — owns planning and delegation."
                  )}
                </p>
                {(data.subordinates ?? []).length > 0 && (
                  <div className="mono mt-2 flex flex-wrap gap-1.5">
                    {data.subordinates.map((s: any) => (
                      <Link key={s.id} href={`/agents/${s.id}`} className="rounded-md border border-line bg-panel2 px-2 py-1 text-[10.5px] text-mist hover:border-cyan/40 hover:text-cyan">
                        {s.name} · {s.department}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </Panel>
      </div>
      <button className="hidden" onClick={() => void reload()} aria-hidden />
    </div>
  );
}

function Metric({ label, value, hint, tone = "chalk" }: { label: string; value: React.ReactNode; hint?: string; tone?: "cyan" | "jade" | "violet" | "amber" | "chalk" }) {
  const color = { cyan: "text-cyan", jade: "text-jade", violet: "text-violet", amber: "text-amber", chalk: "text-chalk" }[tone];
  return (
    <div className="rounded-xl border border-line bg-panel/70 px-4 py-3 hairline">
      <p className="text-[10.5px] uppercase tracking-[0.14em] text-dim">{label}</p>
      <p className={cn("mono mt-1.5 text-[22px] font-semibold leading-none", color)}>{value}</p>
      {hint && <p className="mt-1 text-[11px] leading-snug text-dim">{hint}</p>}
    </div>
  );
}
