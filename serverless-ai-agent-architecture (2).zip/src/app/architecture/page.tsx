"use client";

import Link from "next/link";
import { CheckCircle2, GitBranch, Layers, Target } from "lucide-react";
import { useAos } from "@/lib/client/state";
import { Badge, Empty, KV, Panel, SectionTitle, Stat, Table, Td } from "@/components/ui";
import { cn } from "@/lib/cn";

const LAYERS = [
  { n: 1, name: "User experience and global ingress", items: ["Workers · static UI", "WebSockets", "voice", "messaging channels"] },
  { n: 2, name: "Durable agent sessions", items: ["Agents SDK + PiHarness", "one identity, many sessions", "session state in DO SQLite", "hibernate when idle", "resume after eviction", "skills + scoped memory"] },
  { n: 3, name: "Universal Work Engine", items: ["Cloudflare Workflows", "long-running Work Units", "dynamic task DAGs", "fan-out / fan-in", "human approvals", "retries + deadlines", "cross-agent delegation", "cancellation + recovery"] },
  { n: 4, name: "Elastic execution fabric", items: ["Worker pools for fast API/tool tasks", "Queues for parallel dispatch + backpressure", "Containers for ephemeral code execution", "Firecracker / OpenSandbox isolation", "Browser Run: shared capacity, isolated contexts"] },
  { n: 5, name: "Managed data and intelligence", items: ["PostgreSQL: authoritative records", "Hyperdrive: connection pooling", "R2: artifacts and large files", "pgvector: semantic retrieval", "AI Gateway: provider access + routing", "Memory compiler: knowledge promotion"] },
  { n: 6, name: "Quality, governance and learning", items: ["Cedar policies", "task receipts", "independent evaluation", "OpenTelemetry", "Inspect AI · BrowserGym", "versioned skills", "audit + cost intelligence"] },
];

const STATE_BOUNDARIES = [
  ["Organizational identity and permissions", "PostgreSQL", "durable, queryable, shared"],
  ["Agent conversation and turn execution", "Durable Object SQLite", "local, fast, hibernatable"],
  ["Long-running business workflow", "Cloudflare Workflows", "durable orchestration and recovery"],
  ["Large files and outputs", "R2", "cheap persistent object storage"],
  ["Searchable semantic content", "pgvector", "avoid a separate vector service initially"],
];

const COST_TABLE = [
  ["1,000 agents", "1,000 agent processes", "1,000 database identities"],
  ["1,000 memories", "1,000 memory services", "shared memory service with scoped records"],
  ["1,000 computers", "1,000 permanent VMs", "task-specific ephemeral execution"],
  ["1,000 schedules", "1,000 polling loops", "event-driven durable scheduler"],
  ["1,000 integrations", "1,000 connector processes", "shared connector gateway"],
  ["1,000 parallel tasks", "1,000 dedicated workers", "bounded asynchronous worker pool"],
  ["Persistent conversations", "always-resident sessions", "hibernating durable sessions"],
  ["Persistent files", "mounted agent disks", "object storage + versioned workspaces"],
];

const TRIZ = [
  ["Persistent agent vs minimal memory", "separation in time; dynamization", "hibernating Durable Object sessions"],
  ["Independent computers vs low cost", "segmentation; local quality", "task-specific execution environments"],
  ["More parallelism vs limited memory", "universality; resource pooling", "shared stateless worker pools"],
  ["Isolation vs startup latency", "copying; prior action", "prepared images, snapshots, copy-on-write"],
  ["More agents vs fewer servers", "taking out; universality", "agent identity becomes database configuration"],
  ["More features vs less infrastructure", "merging; simplification", "native platform capabilities"],
  ["Faster execution vs safe retries", "feedback; prior action", "durable workflow steps + idempotency keys"],
  ["Larger memory vs small context", "segmentation; nesting", "retrieval and compact task-specific context"],
  ["Central security vs distributed workers", "intermediary; separation of authority", "capability gateway + scoped signed tokens"],
  ["Faster throughput vs provider overload", "feedback and adaptive control", "adaptive concurrency and backpressure"],
  ["Shared tools vs data leakage", "local quality and segmentation", "per-task grants and credential broker"],
  ["High quality vs lower model cost", "universality; asymmetry", "model routing by task difficulty"],
];

const FAR_TRANSFER = [
  ["Operating systems", "process scheduling", "Don't allocate a computer per process. Schedule execution, share memory safely, prioritize tasks."],
  ["MapReduce", "data parallelism", "Split work into independent pieces, process in parallel, combine. Agents should not spend their time chatting with each other."],
  ["Databases", "copy-on-write", "Parallel coding and analysis branches start from a prepared snapshot instead of rebuilding environments."],
  ["CDNs", "edge caching", "Cache immutable content, tool docs, prompt prefixes and verified source extracts; scope tenant-specific data correctly."],
  ["Control theory", "feedback scheduling", "Observe queue depth, p95 latency, error rates, quotas and sandbox memory; adjust concurrency dynamically."],
  ["Biology", "dormancy", "An organism retains identity and capacity for future action without continuously executing every function."],
];

const RESOLUTION = [
  ["Agents need continuity", "keep them running", "hibernating sessions"],
  ["Agents need computers", "give each agent a VM", "give tasks temporary execution"],
  ["Agents need memory", "load large memory at startup", "retrieve compact context on demand"],
  ["Agents need collaboration", "let them chat continuously", "exchange artifacts and task events"],
  ["Agents need reliability", "keep services running", "persist state and recreate workers"],
  ["Agents need high parallelism", "add servers", "shared pools and dynamic fan-out"],
  ["Agents need browser access", "start Chrome for every task", "reuse remote browser processes, separate contexts"],
  ["Agents need security", "isolated credentials each", "short-lived operation-specific capabilities"],
  ["Agents need more skills", "install more runtime services", "load versioned skill packages on demand"],
  ["System needs performance", "upgrade everything", "optimize the critical path and the binding bottleneck"],
];

const NOT_BUILDING = [
  "A permanently running VM for each agent",
  "A separate Python or Node process for each agent",
  "A collection of always-on agent orchestration servers",
  "Multiple workflow engines governing the same Work Unit",
  "Multiple overlapping model gateways",
  "Neo4j + FalkorDB + Qdrant + Redis at launch",
  "A browser agent that uses a vision model on every click",
  "Agents communicating through endless autonomous chat loops",
  "A platform that treats every task as a full computer-use task",
];

export default function ArchitecturePage() {
  const { data } = useAos();
  const delivery = data?.delivery ?? [];
  const footprint = data?.footprint ?? {};
  const totals = data?.scheduler?.totals ?? {};

  return (
    <div className="space-y-5">
      <SectionTitle eyebrow="AOS v3 · architectural north star" title="Millions of identities. Thousands of concurrent tasks. A tiny always-on footprint.">
        No permanently running process per agent. No permanently running computer per agent. No permanently loaded model per agent. No giant shared
        agent-memory process. No unnecessary graph database, message broker or vector database. No model call where deterministic code can do the job. No
        serial execution of independent tasks. No loss of state when a worker disappears.
      </SectionTitle>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Logical sessions live" value={footprint.logicalSessions ?? 0} tone="violet" hint={`${footprint.residentSessions ?? 0} resident · ${footprint.hibernatedSessions ?? 0} hibernated · ${footprint.evictedSessions ?? 0} evicted`} />
        <Stat label="Resident footprint" value={`${footprint.residentMemoryMb ?? 0} MiB`} tone="cyan" hint={`naive process-per-agent design: ${Math.round((footprint.naiveFootprintMb ?? 0) / 1024)} GiB`} />
        <Stat label="Verified deliverables" value={totals.deliverablesAccepted ?? 0} tone="jade" hint={`${totals.deliverablesRejected ?? 0} rejected by independent critics`} />
        <Stat label="Always-on services" value={1} tone="amber" hint="the control plane. Everything else is durable state plus shared pools" />
      </div>

      <Panel title="Reference architecture" subtitle="Deliberately avoids separate always-on infrastructure for every agent, department, model, browser and tool." icon={<Layers size={14} className="text-cyan" />}>
        <div className="grid gap-3 lg:grid-cols-3">
          {LAYERS.map((l) => (
            <div key={l.n} className="rounded-xl border border-line bg-panel2/60 p-3">
              <div className="flex items-center gap-2">
                <span className="mono rounded-md border border-cyan/30 bg-cyan/10 px-1.5 py-0.5 text-[10px] text-cyan">L{l.n}</span>
                <p className="text-[12.5px] font-semibold text-chalk">{l.name}</p>
              </div>
              <ul className="mt-2 space-y-1">
                {l.items.map((i) => (
                  <li key={i} className="mono flex items-start gap-1.5 text-[10.5px] leading-snug text-mist">
                    <span className="text-cyan/70">▸</span>
                    {i}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Panel>

      <div className="grid gap-4 xl:grid-cols-2">
        <Panel title="Three kinds of state, three different homes" subtitle="The same information should not be independently reconstructed and stored in four places." icon={<GitBranch size={14} className="text-violet" />} bodyClass="p-0">
          <Table head={["state", "where it belongs", "why"]}>
            {STATE_BOUNDARIES.map(([a, b, c]) => (
              <tr key={a} className="hover:bg-white/2">
                <Td className="text-chalk">{a}</Td>
                <Td><Badge tone="cyan">{b}</Badge></Td>
                <Td className="text-[11.5px] text-dim">{c}</Td>
              </tr>
            ))}
          </Table>
          <div className="border-t border-line p-3">
            <KV k="Session actor owns" v="transcript, model calls, tool calls, follow-ups, recovery" />
            <KV k="Workflow owns" v="assignment, delegation, parallel subtasks, approvals, waiting, deadlines, completion" />
            <KV k="Never both" v="the same task's external side effects" />
            <KV k="D1 as global ledger" v="rejected — serial per-database execution, 10 GB ceiling; partition per tenant instead" />
          </div>
        </Panel>

        <Panel title="First principles: what actually consumes resources" bodyClass="p-0">
          <Table head={["requirement", "expensive conventional design", "revised design"]}>
            {COST_TABLE.map(([a, b, c]) => (
              <tr key={a} className="hover:bg-white/2">
                <Td className="text-chalk">{a}</Td>
                <Td className="text-[11.5px] text-rose/90 line-through decoration-rose/40">{b}</Td>
                <Td className="text-[11.5px] text-jade">{c}</Td>
              </tr>
            ))}
          </Table>
          <div className="border-t border-line p-3">
            <p className="mono mb-1.5 text-[10px] uppercase tracking-[0.14em] text-dim">real bottlenecks, in order</p>
            <ol className="space-y-1 text-[11.5px] leading-snug text-mist">
              {["Browser and desktop processes", "Model inference — GPU memory and KV caches", "Repeated context construction and large in-memory transcripts", "Isolated execution environments", "Database indexes and graph/vector services", "Always-on processes and inefficient connection handling"].map((b, i) => (
                <li key={b}><span className="mono mr-2 text-cyan">{String(i + 1).padStart(2, "0")}</span>{b}</li>
              ))}
            </ol>
          </div>
        </Panel>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <Panel title="TRIZ: remove the contradictions structurally" subtitle="The strongest innovations are the separations, not the framework choice." bodyClass="p-0">
          <Table head={["contradiction", "principle", "resolution"]}>
            {TRIZ.map(([a, b, c]) => (
              <tr key={a} className="hover:bg-white/2">
                <Td className="text-[11.5px] text-chalk">{a}</Td>
                <Td className="mono text-[10.5px] text-violet">{b}</Td>
                <Td className="text-[11.5px]">{c}</Td>
              </tr>
            ))}
          </Table>
        </Panel>

        <div className="space-y-4">
          <Panel title="Far transfer" subtitle="Build agents with the principles that make operating systems, serverless infrastructure and distributed databases efficient." icon={<Target size={14} className="text-jade" />}>
            <div className="space-y-2">
              {FAR_TRANSFER.map(([from, principle, note]) => (
                <div key={from} className="rounded-lg border border-line bg-abyss/60 px-3 py-2">
                  <p className="mono text-[11px] text-jade">from {from} → {principle}</p>
                  <p className="mt-0.5 text-[11.5px] leading-snug text-mist">{note}</p>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Final resolution" bodyClass="p-0">
            <Table head={["problem", "conventional response", "revised invention"]}>
              {RESOLUTION.map(([a, b, c]) => (
                <tr key={a} className="hover:bg-white/2">
                  <Td className="text-[11.5px] text-chalk">{a}</Td>
                  <Td className="text-[11.5px] text-dim">{b}</Td>
                  <Td className="text-[11.5px] text-jade">{c}</Td>
                </tr>
              ))}
            </Table>
          </Panel>
        </div>
      </div>

      <Panel
        title="Delivery plan — bounded slices with acceptance criteria and evidence"
        subtitle="Each slice is a vertical increment verified by an independent check, not a polished demo or a self-assigned score."
        icon={<CheckCircle2 size={14} className="text-cyan" />}
        bodyClass="p-0"
      >
        {delivery.length === 0 ? (
          <div className="p-4"><Empty>delivery slices not seeded</Empty></div>
        ) : (
          <Table head={["#", "root", "slice", "acceptance criteria", "evidence", "status", "verified by"]}>
            {delivery.map((s: any) => (
              <tr key={s.id} className="align-top hover:bg-white/2">
                <Td className="mono text-cyan">{String(s.step).padStart(2, "0")}</Td>
                <Td className="mono text-[10.5px]">{s.root}</Td>
                <Td className="max-w-[260px] text-[11.5px] text-chalk">{s.title}</Td>
                <Td className="max-w-[320px]">
                  <ul className="space-y-1">
                    {(s.acceptanceCriteria ?? []).map((c: string) => (
                      <li key={c} className="flex items-start gap-1.5 text-[11px] leading-snug text-mist">
                        <span className="mt-0.5 text-jade">✓</span>
                        {c}
                      </li>
                    ))}
                  </ul>
                </Td>
                <Td className="max-w-[280px]">
                  <ul className="space-y-1">
                    {(s.evidence ?? []).map((e: string) => (
                      <li key={e} className="mono text-[10.5px] leading-snug text-dim">▸ {e}</li>
                    ))}
                  </ul>
                </Td>
                <Td><Badge tone={s.status === "verified" ? "jade" : "amber"}>{s.status}</Badge></Td>
                <Td className="mono text-[10.5px]">{s.verifiedBy}</Td>
              </tr>
            ))}
          </Table>
        )}
      </Panel>

      <div className="grid gap-4 xl:grid-cols-[1.2fr_1fr]">
        <Panel title="How the system is meant to work" className="border-cyan/25">
          <ol className="space-y-2">
            {[
              "The human defines the outcome.",
              "The organization creates a durable task graph.",
              "The scheduler activates only the necessary capabilities.",
              "Shared workers execute independent tasks concurrently.",
              "The right computer appears only when needed.",
              "The verifier checks the result against the actual acceptance criteria.",
              "The system preserves the learning and releases the resources.",
            ].map((s, i) => (
              <li key={s} className="flex gap-2.5 rounded-lg border border-line bg-abyss/50 px-3 py-2 text-[12.5px] leading-snug text-mist">
                <span className="mono shrink-0 text-cyan">{String(i + 1).padStart(2, "0")}</span>
                {s}
              </li>
            ))}
          </ol>
          <p className="mt-3 text-[12px] leading-relaxed text-dim">
            The most valuable metric is not how many agents the platform can create. It is how much verified work it completes, safely, per GB of active
            memory and per dollar of cloud expenditure.
          </p>
        </Panel>

        <Panel title="What I would emphatically not build" className="border-rose/25" bodyClass="p-0">
          <ul className="divide-y divide-line/60">
            {NOT_BUILDING.map((n) => (
              <li key={n} className="flex items-start gap-2 px-4 py-2 text-[12px] leading-snug text-mist">
                <span className="mt-0.5 text-rose">✕</span>
                {n}
              </li>
            ))}
          </ul>
          <div className="border-t border-line p-3">
            <KV k="Preserved alternative 1" v="if the experimental session harness does not stabilize, swap the session runtime only" />
            <KV k="Preserved alternative 2" v="if not Cloudflare-native: DBOS + PostgreSQL worker pools, OpenSandbox/Firecracker, reusable remote browser" />
            <KV k="Unchanged either way" v="identities, memory structure, Work Unit contracts, Authority Envelopes, verification model" />
          </div>
        </Panel>
      </div>

      <Panel title="Live cross-references" subtitle="Every claim on this page is wired to a running implementation in this deployment.">
        <div className="flex flex-wrap gap-2">
          {[
            ["Control plane", "/"],
            ["Work engine", "/work"],
            ["Scheduler", "/scheduler"],
            ["Agent registry", "/agents"],
            ["Sessions", "/sessions"],
            ["Browser pool", "/browser"],
            ["Memory", "/memory"],
            ["Models & connectors", "/catalog"],
            ["Authority", "/security"],
            ["Qualification harness", "/benchmark"],
          ].map(([label, href]) => (
            <Link key={href} href={href}>
              <span className={cn("mono inline-flex items-center gap-1.5 rounded-lg border border-line bg-panel2 px-2.5 py-1.5 text-[11px] text-mist transition-colors hover:border-cyan/45 hover:text-cyan")}>
                {label} →
              </span>
            </Link>
          ))}
        </div>
      </Panel>
    </div>
  );
}
