"use client";

import { Boxes, CalendarClock, Cpu, Plug, Router, ServerCog } from "lucide-react";
import { useAos, useResource } from "@/lib/client/state";
import { Badge, Btn, Dot, Empty, KV, Panel, SectionTitle, Stat, Status, Table, Td } from "@/components/ui";
import { relativeTime } from "@/lib/format";
import { cn } from "@/lib/cn";

export default function CatalogPage() {
  const { data } = useAos();
  const { data: catalog } = useResource<any>("/api/catalog", { interval: 8000 });
  const connectors = catalog?.connectors ?? [];
  const models = catalog?.models ?? data?.models ?? [];
  const schedules = catalog?.schedules ?? [];
  const sandboxes = catalog?.sandboxes ?? [];
  const tiers = catalog?.tiers ?? [];
  const stack = catalog?.stack ?? [];
  const exclusions = catalog?.exclusions ?? [];
  const sequence = catalog?.sequence ?? [];

  const totalActions = connectors.reduce((a: number, c: any) => a + (c.supportedActions?.length ?? 0), 0);

  return (
    <div className="space-y-5">
      <SectionTitle eyebrow="Layer 5–6 · integrations and intelligence" title="Models, connectors and execution catalog">
        Maximize integration breadth without one service per protocol. A central connector catalog holds identity, permissions, rate limits and approval
        requirements; each agent receives a filtered capability list from its role and task authorization — never the whole tool zoo in every prompt.
      </SectionTitle>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Stat label="Connectors" value={connectors.length} tone="cyan" hint={`${totalActions} authorized actions across the catalog`} />
        <Stat label="Models routed" value={models.length} tone="violet" hint={`${models.filter((m: any) => m.enabled).length} enabled · tiered ladder`} />
        <Stat label="Durable routines" value={schedules.length} tone="jade" hint="event-driven; no polling loops" />
        <Stat label="Execution pools" value={sandboxes.length} tone="blue" hint={`${sandboxes.filter((s: any) => s.state === "running").length} running now`} />
        <Stat label="Gateway services" value={1} tone="amber" hint="one primary model access path, not five overlapping layers" />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.4fr_1fr]">
        <Panel title="Connector catalog" subtitle="Shared connector gateway: typed adapters for high-value integrations, MCP for remote tool servers, OpenAPI for the long tail." icon={<Plug size={14} className="text-cyan" />} bodyClass="p-0">
          <Table head={["provider", "identity", "protocol", "auth", "actions", "rate limit", "approval", "events", "health"]}>
            {connectors.map((c: any) => (
              <tr key={c.id} className="hover:bg-white/2">
                <Td className="text-chalk">{c.provider}</Td>
                <Td className="mono text-[11px]">{c.identity}</Td>
                <Td><Badge tone={c.protocol === "mcp" ? "violet" : c.protocol === "openapi" ? "blue" : "cyan"}>{c.protocol}</Badge></Td>
                <Td className="mono text-[10.5px]">{c.authType}</Td>
                <Td className="mono max-w-[220px] text-[10.5px]">{(c.supportedActions ?? []).join(", ")}</Td>
                <Td className="mono">{c.rateLimitRps}/s</Td>
                <Td>{c.approvalRequired ? <Badge tone="amber">required</Badge> : <span className="mono text-[10.5px] text-dim">—</span>}</Td>
                <Td className="mono text-[10.5px]">{(c.eventSubscriptions ?? []).join(", ") || "—"}</Td>
                <Td><Badge tone={c.health === "healthy" ? "jade" : "amber"}>{c.health}</Badge></Td>
              </tr>
            ))}
            {!connectors.length && <tr><Td colSpan={9}><Empty>catalog empty</Empty></Td></tr>}
          </Table>
        </Panel>

        <div className="space-y-4">
          <Panel title="Integration strategy" subtitle="One gateway, not an integration zoo." icon={<Router size={14} className="text-violet" />}>
            {[
              ["Model providers", "Cloudflare AI Gateway (or agentgateway): routing, caching, fallback, rate limits, spend analytics"],
              ["Remote tools", "Agents SDK MCP client manager (stable) for remote MCP servers"],
              ["High-value APIs", "direct typed adapters — no MCP hop, no extra latency"],
              ["Long tail", "REST/OpenAPI adapters generated from the connector schema"],
              ["A2A", "only for interoperability with external agent organizations"],
              ["Code mode", "the model writes a small program composing already-authorized operations; the environment enforces the same per-operation authorization"],
            ].map(([k, v]) => (
              <div key={k} className="border-b border-line/60 py-2 last:border-0">
                <p className="mono text-[11.5px] text-cyan">{k}</p>
                <p className="mt-0.5 text-[11.5px] leading-snug text-mist">{v}</p>
              </div>
            ))}
            <p className="mt-2 rounded-lg border border-amber/30 bg-amber/6 p-2 text-[11px] leading-relaxed text-amber">
              AI Gateway's 200 requests/60s documented limit applies to Cloudflare Unified Billing gateway requests, not bring-your-own-key traffic. For heavy
              parallel model traffic, use provider keys and enforce spend and concurrency budgets in the application.
            </p>
          </Panel>

          <Panel title="Durable routines" subtitle="Schedules are records fired by the durable scheduler — never a polling loop per agent." icon={<CalendarClock size={14} className="text-jade" />} bodyClass="p-0">
            <Table head={["routine", "cron", "template", "runs", "next"]}>
              {schedules.map((s: any) => (
                <tr key={s.id} className="hover:bg-white/2">
                  <Td>
                    <span className="block text-chalk">{s.name}</span>
                    <span className="block max-w-[260px] truncate text-[10.5px] text-dim">{s.objective}</span>
                  </Td>
                  <Td className="mono text-[11px]">{s.cron}</Td>
                  <Td><Badge tone="violet">{s.template}</Badge></Td>
                  <Td className="mono">{s.runs}</Td>
                  <Td className="mono text-[10.5px]">{relativeTime(s.nextRunAt)}</Td>
                </tr>
              ))}
              {!schedules.length && <tr><Td colSpan={5}><Empty>no routines registered</Empty></Td></tr>}
            </Table>
          </Panel>
        </div>
      </div>

      <Panel title="Three execution tiers" subtitle="Consolidated from six conceptual environment classes. The default is no computer at all." icon={<Boxes size={14} className="text-blue" />}>
        <div className="grid gap-3 lg:grid-cols-3">
          {tiers.map((t: any) => (
            <div key={t.tier} className={cn("rounded-xl border p-3", t.tier === 0 ? "border-jade/35 bg-jade/5" : t.tier === 1 ? "border-cyan/30 bg-cyan/5" : "border-violet/30 bg-violet/5")}>
              <div className="flex items-center justify-between">
                <p className="mono text-[12px] text-chalk">tier {t.tier} · {t.name}</p>
                <Badge tone={t.tier === 0 ? "jade" : t.tier === 1 ? "cyan" : "violet"}>{t.share}</Badge>
              </div>
              <p className="mt-2 text-[11.5px] leading-snug text-mist">{t.runtime}</p>
              <p className="mono mt-2 text-[10.5px] text-dim">{t.size}</p>
              <p className="mono mt-1 text-[10.5px] text-dim">boots: {t.boots}</p>
            </div>
          ))}
        </div>
        <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["Worker isolate", "128 MiB ceiling, shared by thousands of identities"],
            ["Durable Object", "same Worker limits; configurable active CPU up to 5 min"],
            ["Container lite", "1/16 vCPU · 256 MiB · 2 GB"],
            ["Container basic", "1/4 vCPU · 1 GiB · 4 GB"],
            ["Container standard-1", "1/2 vCPU · 4 GiB · 8 GB"],
            ["Queue", "up to 5,000 msg/s, 250 concurrent push consumers"],
            ["Firecracker VMM", "≤5 MiB overhead in the minimal configuration"],
            ["Firecracker guest", "128 MiB guest memory in that example"],
          ].map(([k, v]) => (
            <div key={k} className="rounded-lg border border-line bg-abyss/60 px-3 py-2">
              <p className="mono text-[11px] text-chalk">{k}</p>
              <p className="mt-0.5 text-[10.5px] leading-snug text-dim">{v}</p>
            </div>
          ))}
        </div>
      </Panel>

      <div className="grid gap-4 xl:grid-cols-[1.5fr_1fr]">
        <Panel title="The stack actually deployed" subtitle="Consolidated on purpose. Each function gets one primary selection and one alternative." icon={<ServerCog size={14} className="text-cyan" />} bodyClass="p-0">
          <Table head={["function", "primary selection", "alternative / experimental"]}>
            {stack.map((s: any) => (
              <tr key={s.function} className="hover:bg-white/2">
                <Td className="mono text-[11px] text-chalk">{s.function}</Td>
                <Td className="text-[11.5px]">{s.primary}</Td>
                <Td className="text-[11.5px] text-dim">{s.alternative}</Td>
              </tr>
            ))}
          </Table>
        </Panel>

        <div className="space-y-4">
          <Panel title="Deliberately not deployed" subtitle="Avoid paying memory and operational cost before a component produces measurable value." icon={<Cpu size={14} className="text-rose" />} bodyClass="p-0">
            <ul className="divide-y divide-line/60">
              {exclusions.map((e: any) => (
                <li key={e.item} className="px-4 py-2">
                  <p className="mono flex items-center gap-2 text-[11.5px] text-rose"><Dot tone="rose" />{e.item}</p>
                  <p className="mt-0.5 text-[11.5px] leading-snug text-mist">{e.reason}</p>
                </li>
              ))}
            </ul>
          </Panel>

          <Panel title="Development sequence" subtitle="Prove steps 1–4 together before adding hundreds of business integrations." bodyClass="p-0">
            <Table head={["#", "build", "critical proof"]}>
              {sequence.map((s: any) => (
                <tr key={s.step} className={cn("hover:bg-white/2", s.step <= 4 && "bg-cyan/4")}>
                  <Td className="mono text-cyan">{String(s.step).padStart(2, "0")}</Td>
                  <Td className="text-[11.5px] text-chalk">{s.build}</Td>
                  <Td className="text-[11.5px]">{s.proof}</Td>
                </tr>
              ))}
            </Table>
            <div className="border-t border-line p-3">
              <KV k="Highest priority" v="steps 1–4: control plane, hibernating sessions, durable work units, bounded parallelism" />
              <KV k="Experimental" v="PiHarness (Beta) and Pi Durable (experimental) behind a replaceable session interface" />
              <KV k="Portable alternative" v="DBOS on PostgreSQL instead of Workflows; OpenSandbox/Firecracker instead of managed sandboxes" />
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
