"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { AlertTriangle, Cpu, FlaskConical, Gauge, RotateCcw, Trash2, Zap } from "lucide-react";
import { useAos } from "@/lib/client/state";
import { Badge, Btn, Dot, Empty, KV, Meter, Panel, QueueTone, SectionTitle, Spark, Stat, Status, Table, Td } from "@/components/ui";
import { formatMicros, relativeTime } from "@/lib/format";
import { cn } from "@/lib/cn";

export default function SchedulerPage() {
  const { data, post, busy } = useAos();
  const [injecting, setInjecting] = useState<string | null>(null);
  const sched = data?.scheduler;
  const signals = sched?.signals ?? {};
  const limits = sched?.limits ?? {};
  const totals = sched?.totals ?? {};
  const queues = data?.queues ?? [];
  const metrics = data?.metrics ?? [];
  const models = data?.models ?? [];
  const sandboxes = data?.sandboxes ?? [];

  const series = {
    memory: useMemo(() => metrics.map((m: any) => m.residentMemoryMb), [metrics]),
    running: useMemo(() => metrics.map((m: any) => m.runningTasks), [metrics]),
    pending: useMemo(() => metrics.map((m: any) => m.pendingTasks), [metrics]),
    throughput: useMemo(() => metrics.map((m: any) => m.throughputPerSec), [metrics]),
    browser: useMemo(() => metrics.map((m: any) => m.browserMemMb), [metrics]),
    p95: useMemo(() => metrics.map((m: any) => m.p95Ms), [metrics]),
  };

  const allowed = Math.min(limits.provider ?? 0, limits.tenant ?? 0, limits.queue ?? 0, limits.sandbox ?? 0, limits.budget ?? 0);

  async function inject(mode: "worker" | "browser" | "duplicate") {
    setInjecting(mode);
    try {
      await post("/api/engine", { action: "failure", mode });
    } finally {
      setInjecting(null);
    }
  }

  return (
    <div className="space-y-5">
      <SectionTitle eyebrow="Layer 3–4 · universal work engine" title="The parallel execution scheduler">
        Optimizes verified work completed per unit of time, memory and cost — not the number of active agents. Four independent queues, bounded fan-out,
        and concurrency that adapts to observed latency, provider quotas, sandbox utilization, browser memory and tenant budget.
      </SectionTitle>

      <div className="flex flex-wrap gap-2">
        <Btn onClick={() => void post("/api/engine", { action: "tick", ticks: 6 })} disabled={busy}>
          <Zap size={12} /> advance 6 ticks
        </Btn>
        <Btn tone="rose" onClick={() => void inject("worker")} disabled={busy || injecting === "worker"}>
          <AlertTriangle size={12} /> kill a running worker
        </Btn>
        <Btn tone="amber" onClick={() => void inject("browser")} disabled={busy || injecting === "browser"}>
          <Gauge size={12} /> crash a browser process
        </Btn>
        <Btn tone="violet" onClick={() => void inject("duplicate")} disabled={busy || injecting === "duplicate"}>
          <FlaskConical size={12} /> replay a duplicate event
        </Btn>
        <div className="ml-auto flex gap-2">
          <Btn tone="dim" onClick={() => void post("/api/engine", { action: "toggle", running: !sched?.running })}>
            <Cpu size={12} /> {sched?.running ? "pause scheduler" : "resume scheduler"}
          </Btn>
          <Btn tone="dim" onClick={() => void post("/api/engine", { action: "reset" })}>
            <RotateCcw size={12} /> reset engine state
          </Btn>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Stat label="Tasks completed" value={totals.tasksCompleted ?? 0} tone="jade" hint={`${totals.tasksFailed ?? 0} failed · ${totals.deterministicSteps ?? 0} needed no model`} />
        <Stat label="Throughput" value={(totals.throughputPerSec ?? 0).toFixed(2)} unit="tasks/s" tone="cyan" sub={<Spark points={series.throughput} tone="cyan" height={20} />} />
        <Stat label="p95 task latency" value={signals.p95Ms ?? 0} unit="ms" tone="blue" sub={<Spark points={series.p95} tone="blue" height={20} />} />
        <Stat label="Queue wait p95" value={signals.queueWaitMs ?? 0} unit="ms" tone="amber" hint={`provider 429s: ${signals.provider429 ?? 0}`} />
        <Stat label="Total model spend" value={formatMicros(totals.costMicros ?? 0)} tone="violet" hint={`${totals.modelCalls ?? 0} calls · ${totals.tokensIn ?? 0}→${totals.tokensOut ?? 0} tok`} />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1fr_1.2fr]">
        <Panel title="Narrowest active constraint" subtitle="C_allowed = min(provider, tenant, queue, sandbox, budget)" icon={<Cpu size={14} className="text-cyan" />}>
          <div className="space-y-3">
            {Object.entries(limits)
              .filter(([k]) => ["provider", "tenant", "queue", "sandbox", "budget"].includes(k))
              .map(([k, v]) => (
                <Meter
                  key={k}
                  value={Number(v)}
                  max={96}
                  tone={Number(v) === allowed ? "amber" : "cyan"}
                  label={<span className="mono">{k}</span>}
                  right={`${v}${Number(v) === allowed ? " · binding" : ""}`}
                />
              ))}
            <div className="rounded-lg border border-line bg-abyss/70 p-3">
              <KV k="Permitted concurrency" v={<span className="text-cyan">{allowed}</span>} />
              <KV k="Browser memory ceiling" v={`${limits.browserMemoryMb ?? 0} MiB`} />
              <KV k="Hibernate after" v={`${limits.hibernateAfterSec ?? 0}s idle`} />
              <KV k="Error rate" v={`${Math.round((signals.errorRate ?? 0) * 100)}%`} />
              <KV k="Sandbox utilization" v={`${Math.round((signals.sandboxUtil ?? 0) * 100)}%`} />
              <KV k="Budget utilization" v={`${Math.round((signals.budgetUtil ?? 0) * 100)}%`} />
              <KV k="DB writes per task" v={signals.dbWritesPerTask ?? 0} />
            </div>
          </div>
        </Panel>

        <Panel title="Queues" subtitle="Do not let one pathological browser task consume resources meant for interactive conversations." bodyClass="p-0">
          <Table head={["queue", "active / limit", "ready", "pending", "blocked", "done", "p95"]}>
            {queues.map((q: any) => (
              <tr key={q.queue} className="hover:bg-white/2">
                <Td>
                  <span className="mono flex items-center gap-2 text-chalk">
                    <Dot tone={QueueTone(q.queue)} pulse={q.running > 0} />
                    {q.queue}
                  </span>
                  <span className="text-[10.5px] text-dim">
                    {q.queue === "interactive"
                      ? "chat, questions, approvals — lowest latency"
                      : q.queue === "io"
                        ? "research, API calls, extraction — high concurrency, low memory"
                        : q.queue === "compute"
                          ? "code, parsing, transforms — CPU and memory quotas"
                          : "Chrome/GUI — memory-aware concurrency"}
                  </span>
                </Td>
                <Td className="w-[190px]">
                  <Meter value={q.running} max={Math.max(1, q.limit)} tone={QueueTone(q.queue)} right={`${q.running}/${q.limit}`} />
                </Td>
                <Td className="mono">{q.ready}</Td>
                <Td className="mono">{q.pending}</Td>
                <Td className="mono">{q.blocked > 0 ? <span className="text-amber">{q.blocked}</span> : q.blocked}</Td>
                <Td className="mono">{q.done}</Td>
                <Td className="mono">{q.p95Ms}ms</Td>
              </tr>
            ))}
          </Table>
          <div className="grid gap-3 border-t border-line p-4 sm:grid-cols-3">
            <ChartCard label="Resident memory" unit="MiB" points={series.memory} tone="cyan" />
            <ChartCard label="Running tasks" unit="now" points={series.running} tone="violet" />
            <ChartCard label="Browser pool memory" unit="MiB" points={series.browser} tone="jade" />
          </div>
        </Panel>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.3fr_1fr]">
        <Panel title="Model router and gateway" subtitle="One gateway: routing, prompt-prefix cache, retries, fallback, spend accounting. Never call the strongest model by default." bodyClass="p-0">
          <Table head={["model", "tier", "in / out per 1k", "latency", "calls", "429s", "cache hits", "concurrency"]}>
            {models.map((m: any) => (
              <tr key={m.id} className={cn("hover:bg-white/2", !m.enabled && "opacity-45")}>
                <Td>
                  <span className="text-chalk">{m.name}</span>
                  <span className="mono block text-[10px] text-dim">{m.provider}</span>
                </Td>
                <Td><Badge tone={m.tier === "reasoning" ? "violet" : m.tier === "fast" ? "jade" : "cyan"}>{m.tier}</Badge></Td>
                <Td className="mono">${m.costPer1kIn} / ${m.costPer1kOut}</Td>
                <Td className="mono">{m.latencyMs}ms</Td>
                <Td className="mono">{m.calls}</Td>
                <Td className="mono">{m.rateLimited > 0 ? <span className="text-rose">{m.rateLimited}</span> : 0}</Td>
                <Td className="mono">{m.cachedHits}</Td>
                <Td className="mono">
                  {m.inFlight}/{m.concurrencyLimit}
                </Td>
              </tr>
            ))}
          </Table>
          <div className="border-t border-line p-3">
            <p className="mono text-[10.5px] uppercase tracking-[0.14em] text-dim">Model ladder</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {[
                ["classification", "small fast model or deterministic code"],
                ["structured extraction", "small model + schema validation"],
                ["large-scale research", "fast model per source"],
                ["strategic planning", "high-quality reasoning model"],
                ["coding", "coding-specialized agent"],
                ["visual interpretation", "vision-capable model"],
                ["verification", "independent evaluator + deterministic checks"],
                ["critical decision", "strong reasoning + human authorization"],
              ].map(([k, v]) => (
                <span key={k} className="mono rounded-md border border-line bg-panel2 px-2 py-1 text-[10.5px] text-mist">
                  <span className="text-cyan">{k}</span> → {v}
                </span>
              ))}
            </div>
          </div>
        </Panel>

        <div className="space-y-4">
          <Panel title="Execution capacity" subtitle="Pools scale to zero. Isolation is a choice per task, not a permanent estate." bodyClass="p-0">
            {sandboxes.length === 0 ? (
              <div className="p-4"><Empty>no sandboxes provisioned</Empty></div>
            ) : (
              <Table head={["flavor", "tier", "state", "vcpu / mem", "boot", "tasks", "egress"]}>
                {sandboxes.map((s: any) => (
                  <tr key={s.id} className="hover:bg-white/2">
                    <Td className="mono text-chalk">{s.flavor}</Td>
                    <Td>{s.tier}</Td>
                    <Td><Status value={s.state === "running" ? "running" : s.state === "sleeping" ? "hibernated" : "ready"} label={s.state} /></Td>
                    <Td className="mono">{s.vcpu} / {s.memoryMb} MiB</Td>
                    <Td className="mono">{s.bootMs}ms</Td>
                    <Td className="mono">{s.tasksRun}</Td>
                    <Td className="mono">{s.networkEgress === "denied" ? <span className="text-rose">denied</span> : <span className="text-jade">{s.networkEgress}</span>}</Td>
                  </tr>
                ))}
              </Table>
            )}
          </Panel>

          <Panel title="Adaptive decision log" subtitle="Feedback scheduling from control theory, not a fixed worker count." bodyClass="p-0">
            <ul className="max-h-[320px] divide-y divide-line/60 overflow-y-auto">
              {(sched?.decisions ?? []).map((d: string, i: number) => (
                <li key={i} className="mono px-4 py-2 text-[11px] leading-snug text-mist">
                  <span className="mr-2 text-cyan">▸</span>
                  {d}
                </li>
              ))}
              {(sched?.decisions ?? []).length === 0 && <li className="p-4"><Empty>no adaptations recorded yet</Empty></li>}
            </ul>
          </Panel>

          <Panel title="Failure injection results" subtitle="Kill workers after external operations and confirm durable recovery." icon={<Trash2 size={14} className="text-rose" />}>
            <KV k="Side-effect receipts" v={totals.sideEffects ?? 0} />
            <KV k="Unauthorized actions blocked" v={<span className="text-rose">{totals.unauthorizedBlocked ?? 0}</span>} />
            <KV k="Injection attempts quarantined" v={<span className="text-amber">{totals.injectionsBlocked ?? 0}</span>} />
            <KV k="Deliverables accepted / rejected" v={`${totals.deliverablesAccepted ?? 0} / ${totals.deliverablesRejected ?? 0}`} />
            <KV k="Last tick" v={relativeTime(sched?.lastTickAt)} />
            <p className="mt-2 text-[11px] leading-relaxed text-dim">
              Recovery contract: a lost worker re-queues the task from durable state; if a receipt already exists for the idempotency key, the external
              action is <span className="text-chalk">reconciled, not repeated</span>.
            </p>
            <Link href="/benchmark" className="mono mt-2 inline-block text-[11px] text-cyan hover:underline">
              run the full qualification harness →
            </Link>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function ChartCard({ label, unit, points, tone }: { label: string; unit: string; points: number[]; tone: "cyan" | "violet" | "jade" }) {
  const last = points[points.length - 1] ?? 0;
  return (
    <div className="rounded-lg border border-line bg-abyss/60 p-3">
      <div className="flex items-baseline justify-between">
        <span className="mono text-[10px] uppercase tracking-[0.14em] text-dim">{label}</span>
        <span className="mono text-[13px] text-chalk">
          {Math.round(last)} <span className="text-[10px] text-dim">{unit}</span>
        </span>
      </div>
      <div className="mt-1.5">
        <Spark points={points} tone={tone} height={30} />
      </div>
    </div>
  );
}
