"use client";

import { useEffect, useState } from "react";
import { ExternalLink, Eye, EyeOff, Globe2, MousePointerClick, Navigation, RefreshCcw, ShieldAlert, X } from "lucide-react";
import { useAos, useResource, postJSON } from "@/lib/client/state";
import { Badge, Btn, Dot, Empty, KV, Meter, Panel, SectionTitle, Stat, Status, Table, Td } from "@/components/ui";
import { relativeTime } from "@/lib/format";
import { cn } from "@/lib/cn";

export default function BrowserPage() {
  const { data, busy } = useAos();
  const { data: pool, loading, reload } = useResource<any>("/api/browser", { interval: 2500 });
  const [takeover, setTakeover] = useState<{ url: string; warning: string; contextId: string } | null>(null);
  const [navUrl, setNavUrl] = useState("");
  const agents = data?.agents ?? [];

  useEffect(() => {
    if (!pool) return;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pool]);

  const processes = pool?.browsers ?? [];
  const contexts = pool?.openContexts ?? [];

  async function doTakeover(contextId: string) {
    const res = await postJSON("/api/browser", { action: "takeover", contextId, operator: "operator" });
    setTakeover({ url: res.liveViewUrl, warning: res.warning, contextId });
    await reload();
  }

  return (
    <div className="space-y-5">
      <SectionTitle eyebrow="Layer 4 · elastic execution fabric" title="Browser pool">
        Pool the processes, isolate the contexts. A few warm Chromium processes serve every browser identity; each agent gets its own context so cookies,
        storage and cache never cross. Tabs share process memory, so tab counts and memory ceilings are enforced and unhealthy processes are recycled.
      </SectionTitle>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Stat label="Browser processes" value={pool?.processes ?? 0} tone="cyan" hint={`${pool?.warmProcesses ?? 0} warm and reusable`} />
        <Stat label="Isolated contexts" value={pool?.openContexts ?? 0} tone="violet" hint={`${pool?.authenticatedContexts ?? 0} holding live logins`} />
        <Stat label="Open tabs" value={pool?.tabs ?? 0} tone="blue" hint="shared process memory — ceilings enforced" />
        <Stat label="Pool memory" value={pool?.memoryMb ?? 0} unit="MiB" tone="amber" hint={`cold starts ${pool?.coldStarts ?? 0} · warm reuses ${pool?.warmReuses ?? 0}`} />
        <Stat label="Crashes / recycles" value={`${pool?.crashes ?? 0} / ${processes.reduce((a: number, b: any) => a + b.recycles, 0)}`} tone="rose" hint="processes replaced, contexts reopened" />
      </div>

      <div className="flex flex-wrap gap-2">
        <Btn tone="amber" onClick={() => void postJSON("/api/browser", { action: "recycle" }).then(reload)} disabled={busy}>
          <RefreshCcw size={12} /> recycle unhealthy processes
        </Btn>
        <Btn
          tone="violet"
          onClick={async () => {
            const agent = agents.find((a: any) => a.department === "operations") ?? agents[0];
            await postJSON("/api/browser", { action: "open", agentId: agent?.id, domain: "portal.example", label: `${agent?.name ?? "agent"} · manual context` });
            await reload();
          }}
        >
          <Globe2 size={12} /> open isolated context
        </Btn>
        {takeover && (
          <Btn tone="jade" onClick={async () => { await postJSON("/api/browser", { action: "end-takeover", contextId: takeover.contextId }); setTakeover(null); await reload(); }}>
            <EyeOff size={12} /> end takeover, resume agent
          </Btn>
        )}
      </div>

      {takeover && (
        <Panel
          title="Human takeover active"
          subtitle="You are driving the same browser the agent uses. Complete the login or MFA challenge; the agent resumes with your cookies."
          icon={<Eye size={14} className="text-jade" />}
          className="border-jade/40"
        >
          <div className="flex flex-wrap items-center gap-3">
            <a href={takeover.url} target="_blank" rel="noreferrer">
              <Btn tone="jade"><ExternalLink size={12} /> open live view</Btn>
            </a>
            <code className="mono max-w-full truncate rounded-md border border-line bg-abyss px-2 py-1 text-[11px] text-mist">{takeover.url}</code>
          </div>
          <p className="mt-2 flex items-start gap-2 rounded-lg border border-rose/30 bg-rose/8 px-3 py-2 text-[11.5px] leading-relaxed text-rose">
            <ShieldAlert size={14} className="mt-0.5 shrink-0" />
            {takeover.warning}
          </p>
        </Panel>
      )}

      <div className="grid gap-4 xl:grid-cols-[1fr_1.4fr]">
        <Panel title="Processes" subtitle="Warm capacity is shared. Billing follows provisioned memory while active plus CPU — idle processes scale toward zero." bodyClass="p-0">
          <div className="divide-y divide-line/60">
            {processes.map((b: any) => (
              <div key={b.id} className="px-4 py-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="mono flex items-center gap-2 text-[12px] text-chalk">
                    <Dot tone={b.state === "busy" ? "cyan" : b.state === "ready" ? "jade" : "dim"} pulse={b.state === "busy"} />
                    {b.label}
                  </span>
                  <Badge tone={b.state === "busy" ? "cyan" : "jade"}>{b.state}</Badge>
                </div>
                <div className="mt-2">
                  <Meter
                    value={b.processMemoryMb}
                    max={1024}
                    tone={b.processMemoryMb > 900 ? "rose" : b.processMemoryMb > 600 ? "amber" : "jade"}
                    label="process memory"
                    right={`${Math.round(b.processMemoryMb)} MiB`}
                  />
                </div>
                <div className="mono mt-2 flex flex-wrap gap-x-3 gap-y-1 text-[10.5px] text-dim">
                  <span>tabs {b.tabCount}/{b.maxTabs}</span>
                  <span>contexts {b.contextCount}</span>
                  <span>pages {b.pagesVisited}</span>
                  <span>warm reuses {b.warmReuses}</span>
                  <span>cold starts {b.coldStarts}</span>
                  <span>crashes {b.crashes}</span>
                  <span>recycles {b.recycles}</span>
                  <span>{b.engine}</span>
                </div>
              </div>
            ))}
            {!processes.length && <div className="p-4"><Empty>{loading ? "loading pool…" : "no browser processes"}</Empty></div>}
          </div>
        </Panel>

        <Panel title="Isolated contexts" subtitle="One context per agent identity per site. Authentication persists between turns without keeping a browser per agent." bodyClass="p-0">
          <Table head={["context", "identity", "domain", "auth", "tabs", "state", "actions"]}>
            {contexts.map((c: any) => (
              <tr key={c.id} className="hover:bg-white/2">
                <Td className="max-w-[210px]">
                  <span className="block truncate text-chalk">{c.label}</span>
                  <span className="mono block truncate text-[10px] text-dim">{c.id}</span>
                </Td>
                <Td className="text-[11.5px]">{c.agent?.name ?? <span className="text-dim">unassigned</span>}</Td>
                <Td className="mono text-[11px]">{c.domain}</Td>
                <Td>{c.authenticated ? <Badge tone="jade">logged in</Badge> : <Badge tone="dim">anonymous</Badge>}</Td>
                <Td className="mono text-[11px]">{c.tabs?.length ?? 0}</Td>
                <Td>
                  {c.humanTakeover ? <Badge tone="amber">human driving</Badge> : <Status value={c.state === "open" ? "running" : "hibernated"} label={c.state} />}
                </Td>
                <Td>
                  <div className="flex flex-wrap gap-1">
                    <Btn size="sm" tone={c.humanTakeover ? "amber" : "cyan"} onClick={() => (c.humanTakeover ? setTakeover(null) : void doTakeover(c.id))}>
                      {c.humanTakeover ? <EyeOff size={11} /> : <MousePointerClick size={11} />} {c.humanTakeover ? "release" : "take over"}
                    </Btn>
                    <Btn size="sm" tone="dim" onClick={async () => { await postJSON("/api/browser", { action: "close", contextId: c.id }); await reload(); }}>
                      <X size={11} /> close
                    </Btn>
                  </div>
                </Td>
              </tr>
            ))}
            {!contexts.length && <tr><Td colSpan={7}><Empty>no open contexts — the pool is idle and costs nothing</Empty></Td></tr>}
          </Table>

          <div className="flex flex-wrap items-end gap-2 border-t border-line p-3">
            <label className="flex-1">
              <span className="mono text-[10px] uppercase tracking-[0.14em] text-dim">drive a context (deterministic CDP step)</span>
              <input
                value={navUrl}
                onChange={(e) => setNavUrl(e.target.value)}
                placeholder="https://portal.example/invoices"
                className="mt-1 w-full rounded-lg border border-line2 bg-abyss px-2.5 py-1.5 text-[12px] text-chalk outline-none focus:border-cyan/60"
              />
            </label>
            <Btn
              disabled={!navUrl.trim() || !contexts[0]}
              onClick={async () => {
                await postJSON("/api/browser", { action: "navigate", contextId: contexts[0].id, url: navUrl.trim(), title: navUrl.trim() });
                setNavUrl("");
                await reload();
              }}
            >
              <Navigation size={12} /> navigate first context
            </Btn>
          </div>
        </Panel>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <Panel title="Automation strategy" subtitle="The best browser agent is usually a deterministic script with an intelligent fallback.">
          <ol className="space-y-2">
            {[
              ["1. APIs first", "If a typed API or connector exists, no browser is launched at all."],
              ["2. Playwright / CDP", "Known operations run as deterministic scripts against the accessibility tree."],
              ["3. Stagehand", "observe / act / extract only when selectors break or the page needs interpretation."],
              ["4. Vision models", "Screenshots and computer-use only for genuine visual ambiguity — never per click."],
              ["5. Human takeover", "Live View for MFA and consent; the agent resumes with the updated session."],
            ].map(([k, v]) => (
              <li key={k} className="rounded-lg border border-line bg-abyss/60 px-3 py-2">
                <p className="mono text-[11.5px] text-cyan">{k}</p>
                <p className="mt-0.5 text-[11.5px] leading-snug text-mist">{v}</p>
              </li>
            ))}
          </ol>
        </Panel>

        <Panel title="What the agent can do">
          <KV k="Open and navigate sites" v="yes" />
          <KV k="Click, type, scroll, inspect" v="yes" />
          <KV k="Read JS-rendered content" v="yes" />
          <KV k="Screenshots and recordings" v="yes → R2 artifacts" />
          <KV k="Persistent logins between turns" v="yes" />
          <KV k="Download and inspect files" v="yes" />
          <KV k="Drive internal app previews" v="yes" />
          <KV k="Human takeover of same session" v="yes (Live View)" />
          <KV k="Arbitrary local desktop apps" v="needs tier 2 microVM" />
        </Panel>

        <Panel title="Known limitations" className="border-amber/25">
          <ul className="space-y-2 text-[12px] leading-relaxed text-mist">
            <li className="flex gap-2"><span className="text-amber">▸</span> Tabs share one browser process and its memory. Heavy pages can crash the process; context isolation is <span className="text-chalk">not</span> an OS security boundary.</li>
            <li className="flex gap-2"><span className="text-amber">▸</span> Live View URLs are bearer credentials. Expose them only to authenticated humans — never to a model, never into task data.</li>
            <li className="flex gap-2"><span className="text-amber">▸</span> A simple tool adapter does not pause mid-run for approval. Durable mid-run approvals need a runtime that can suspend and resume while retaining the session.</li>
            <li className="flex gap-2"><span className="text-amber">▸</span> Persistent browsers are Chromium. Controlling an independently managed Chrome install requires connecting to its CDP endpoint.</li>
          </ul>
          <p className="mono mt-3 text-[10.5px] text-dim">last activity · {relativeTime(processes[0]?.lastUsedAt)}</p>
        </Panel>
      </div>
      <span className={cn("hidden")} />
    </div>
  );
}
