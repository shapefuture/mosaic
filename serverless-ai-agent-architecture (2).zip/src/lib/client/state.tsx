"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";

export type AosState = any;

type Ctx = {
  data: AosState | null;
  error: string | null;
  lastTickAt: string | null;
  live: boolean;
  setLive: (v: boolean) => void;
  refresh: () => Promise<void>;
  post: (url: string, body?: unknown) => Promise<any>;
  busy: boolean;
};

const AosContext = createContext<Ctx | null>(null);

export async function getJSON<T = any>(url: string): Promise<T> {
  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) throw new Error(`${res.status} ${await res.text().catch(() => "")}`);
  return res.json() as Promise<T>;
}

export async function postJSON<T = any>(url: string, body?: unknown): Promise<T> {
  const res = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
    cache: "no-store",
  });
  const payload = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((payload as any)?.error ?? `${res.status}`);
  return payload as T;
}

export function AosProvider({ children, interval = 2000 }: { children: ReactNode; interval?: number }) {
  const [data, setData] = useState<AosState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [live, setLive] = useState(true);
  const [busy, setBusy] = useState(false);
  const inFlight = useRef(false);

  const load = useCallback(async () => {
    if (inFlight.current) return;
    inFlight.current = true;
    try {
      const next = await getJSON("/api/state");
      setData(next);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "engine unreachable");
    } finally {
      inFlight.current = false;
    }
  }, []);

  useEffect(() => {
    void load();
    if (!live) return;
    const id = setInterval(() => void load(), interval);
    return () => clearInterval(id);
  }, [live, interval, load]);

  const post = useCallback(
    async (url: string, body?: unknown) => {
      setBusy(true);
      try {
        const result = await postJSON(url, body);
        await load();
        return result;
      } finally {
        setBusy(false);
      }
    },
    [load],
  );

  const value = useMemo<Ctx>(
    () => ({ data, error, lastTickAt: data?.scheduler?.lastTickAt ?? null, live, setLive, refresh: load, post, busy }),
    [data, error, live, load, post, busy],
  );

  return <AosContext.Provider value={value}>{children}</AosContext.Provider>;
}

export function useAos(): Ctx {
  const ctx = useContext(AosContext);
  if (!ctx) throw new Error("useAos must be used inside AosProvider");
  return ctx;
}

/** Local data fetching for detail pages, with optional polling. */
export function useResource<T = any>(url: string | null, opts?: { interval?: number; deps?: unknown[] }) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const deps = opts?.deps ?? [];

  const load = useCallback(async () => {
    if (!url) return;
    try {
      const next = await getJSON<T>(url);
      setData(next);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "request failed");
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, ...deps]);

  useEffect(() => {
    void load();
    if (!opts?.interval) return;
    const id = setInterval(() => void load(), opts.interval);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [load, opts?.interval]);

  return { data, error, loading, reload: load };
}
