import { NextResponse } from "next/server";

export function json(data: unknown, status = 200) {
  return NextResponse.json(data, { status, headers: { "cache-control": "no-store" } });
}

export function fail(message: string, status = 400, extra?: Record<string, unknown>) {
  return json({ error: message, ...extra }, status);
}

export async function readBody<T>(req: Request): Promise<T> {
  try {
    return (await req.json()) as T;
  } catch {
    return {} as T;
  }
}

/** Single-flight guard: the scheduler must never run two ticks concurrently. */
const globalForEngine = globalThis as typeof globalThis & { __aosTick?: Promise<unknown> };

export async function singleFlightTick<T>(fn: () => Promise<T>): Promise<T> {
  if (globalForEngine.__aosTick) {
    await globalForEngine.__aosTick.catch(() => undefined);
  }
  const promise = fn();
  globalForEngine.__aosTick = promise;
  try {
    return await promise;
  } finally {
    if (globalForEngine.__aosTick === promise) globalForEngine.__aosTick = undefined;
  }
}
