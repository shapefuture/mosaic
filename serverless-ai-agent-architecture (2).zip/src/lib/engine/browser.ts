import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { browserContexts, browserSessions } from "@/db/schema";
import { noise, uid } from "./util";

/**
 * Browser capacity: pool the processes, isolate the contexts.
 *
 * A small number of warm Chromium processes serve many agents. Each agent identity
 * gets its own context (cookies / storage / cache isolated). Tabs share the process
 * memory, so tab counts are bounded and unhealthy processes are recycled.
 *
 * Human takeover uses a Live View bearer token — it is never handed to a model and
 * never stored as ordinary task data.
 */

export type ContextTab = { id: string; url: string; title: string; state: string };

export async function ensurePool(size = 3): Promise<void> {
  const existing = await db.select({ id: browserSessions.id }).from(browserSessions);
  if (existing.length >= size) return;
  for (let i = existing.length; i < size; i += 1) {
    await db.insert(browserSessions).values({
      id: uid("brw"),
      label: `browser-run-${String(i + 1).padStart(2, "0")}`,
      state: "ready",
      processMemoryMb: 180 + Math.round(noise(60)),
      maxTabs: 6,
    });
  }
}

export async function poolStats() {
  const browsers = await db.select().from(browserSessions);
  const contexts = await db.select().from(browserContexts);
  const open = contexts.filter((c) => c.state === "open");
  return {
    browsers,
    contexts,
    processes: browsers.length,
    warmProcesses: browsers.filter((b) => b.state === "ready" || b.state === "busy").length,
    openContexts: open.length,
    authenticatedContexts: open.filter((c) => c.authenticated).length,
    tabs: browsers.reduce((a, b) => a + b.tabCount, 0),
    memoryMb: Math.round(browsers.reduce((a, b) => a + b.processMemoryMb, 0)),
    coldStarts: browsers.reduce((a, b) => a + b.coldStarts, 0),
    warmReuses: browsers.reduce((a, b) => a + b.warmReuses, 0),
    crashes: browsers.reduce((a, b) => a + b.crashes, 0),
    takeovers: open.filter((c) => c.humanTakeover).length,
  };
}

export async function acquireContext(input: { agentId?: string | null; domain: string; label: string }) {
  await ensurePool();
  const browsers = await db.select().from(browserSessions).where(eq(browserSessions.state, "ready"));
  const withCapacity = browsers
    .filter((b) => b.tabCount < b.maxTabs && b.processMemoryMb < 900)
    .sort((a, b) => a.tabCount - b.tabCount);

  let browser = withCapacity[0];
  let coldStart = false;
  if (!browser) {
    // No capacity: recycle the oldest unhealthy process rather than growing without bound.
    const all = await db.select().from(browserSessions);
    const victim = [...all].sort((a, b) => b.processMemoryMb - a.processMemoryMb)[0];
    if (victim) {
      await db
        .update(browserSessions)
        .set({
          state: "ready",
          tabCount: 0,
          processMemoryMb: 180 + Math.round(noise(40)),
          recycles: victim.recycles + 1,
        })
        .where(eq(browserSessions.id, victim.id));
      await db.update(browserContexts).set({ state: "recycled" }).where(eq(browserContexts.browserId, victim.id));
      browser = (await db.select().from(browserSessions).where(eq(browserSessions.id, victim.id)))[0];
      coldStart = true;
    }
  }
  if (!browser) {
    const id = uid("brw");
    await db.insert(browserSessions).values({ id, label: `browser-run-${id.slice(-4)}`, state: "ready", processMemoryMb: 210, coldStarts: 1 });
    browser = (await db.select().from(browserSessions).where(eq(browserSessions.id, id)))[0];
    coldStart = true;
  }

  // Reuse an existing isolated context for the same agent + domain when present.
  const reusable = await db
    .select()
    .from(browserContexts)
    .where(and(eq(browserContexts.browserId, browser.id), eq(browserContexts.domain, input.domain), eq(browserContexts.state, "open")));
  const existing = input.agentId ? reusable.find((c) => c.agentId === input.agentId) : undefined;
  if (existing) {
    await db
      .update(browserSessions)
      .set({ warmReuses: sql`${browserSessions.warmReuses} + 1`, lastUsedAt: new Date() })
      .where(eq(browserSessions.id, browser.id));
    return { contextId: existing.id, browserId: browser.id, reusedContext: true, coldStart: false, authenticated: existing.authenticated };
  }

  const contextId = uid("ctx");
  await db.insert(browserContexts).values({
    id: contextId,
    browserId: browser.id,
    agentId: input.agentId ?? null,
    label: input.label,
    domain: input.domain,
    authenticated: false,
    tabs: [],
    state: "open",
  });
  await db
    .update(browserSessions)
    .set({
      tabCount: sql`${browserSessions.tabCount} + 1`,
      contextCount: sql`${browserSessions.contextCount} + 1`,
      processMemoryMb: sql`${browserSessions.processMemoryMb} + ${28 + noise(40)}`,
      warmReuses: coldStart ? browserSessions.warmReuses : sql`${browserSessions.warmReuses} + 1`,
      coldStarts: coldStart ? sql`${browserSessions.coldStarts} + 1` : browserSessions.coldStarts,
      state: "busy",
      lastUsedAt: new Date(),
    })
    .where(eq(browserSessions.id, browser.id));

  return { contextId, browserId: browser.id, reusedContext: false, coldStart, authenticated: false };
}

export async function contextAct(contextId: string, action: { url?: string; title?: string; memoryMb?: number }) {
  const rows = await db.select().from(browserContexts).where(eq(browserContexts.id, contextId)).limit(1);
  const ctx = rows[0];
  if (!ctx) return null;
  const tabs: ContextTab[] = [...ctx.tabs];
  const url = action.url ?? tabs[tabs.length - 1]?.url ?? "about:blank";
  const existingTab = tabs.find((t) => t.url === url);
  if (existingTab) {
    existingTab.state = action.title ? "loaded" : "active";
    if (action.title) existingTab.title = action.title;
  } else {
    tabs.push({ id: uid("tab"), url, title: action.title ?? url, state: "loaded" });
  }
  await db
    .update(browserContexts)
    .set({ tabs, lastActionAt: new Date() })
    .where(eq(browserContexts.id, contextId));
  await db
    .update(browserSessions)
    .set({
      pagesVisited: sql`${browserSessions.pagesVisited} + 1`,
      processMemoryMb: sql`${browserSessions.processMemoryMb} + ${action.memoryMb ?? 18 + noise(30)}`,
      lastUsedAt: new Date(),
    })
    .where(eq(browserSessions.id, ctx.browserId));
  return tabs;
}

export async function markAuthenticated(contextId: string, authed = true) {
  await db.update(browserContexts).set({ authenticated: authed }).where(eq(browserContexts.id, contextId));
}

export async function releaseContext(contextId: string) {
  const rows = await db.select().from(browserContexts).where(eq(browserContexts.id, contextId)).limit(1);
  const ctx = rows[0];
  if (!ctx) return;
  await db.update(browserContexts).set({ state: "closed", humanTakeover: false }).where(eq(browserContexts.id, contextId));
  await db
    .update(browserSessions)
    .set({
      tabCount: sql`GREATEST(${browserSessions.tabCount} - 1, 0)`,
      processMemoryMb: sql`GREATEST(${browserSessions.processMemoryMb} - 24, 150)`,
      state: "ready",
    })
    .where(eq(browserSessions.id, ctx.browserId));
}

/** Human takeover: the operator drives the same browser the agent is using. */
export async function requestTakeover(contextId: string, operator: string) {
  const token = `lv_${uid("tok")}${uid("tok")}`;
  await db
    .update(browserContexts)
    .set({ humanTakeover: true, liveViewToken: token, state: "open" })
    .where(eq(browserContexts.id, contextId));
  return {
    liveViewUrl: `/api/browser/live-view?ctx=${contextId}&t=${token}`,
    token,
    warning:
      "Live View URLs are bearer credentials. Anyone holding one controls this browser and its logged-in sites. Never expose to a model or persist as task data.",
    operator,
  };
}

export async function endTakeover(contextId: string) {
  await db
    .update(browserContexts)
    .set({ humanTakeover: false, liveViewToken: null })
    .where(eq(browserContexts.id, contextId));
}

/** Health monitor: heavy pages crash shared processes; recycle before that happens. */
export async function recycleUnhealthy(thresholdMb = 950) {
  const browsers = await db.select().from(browserSessions);
  const unhealthy = browsers.filter((b) => b.processMemoryMb > thresholdMb || b.tabCount > b.maxTabs);
  for (const b of unhealthy) {
    await db
      .update(browserSessions)
      .set({ state: "ready", tabCount: 0, processMemoryMb: 190, recycles: b.recycles + 1, crashes: b.processMemoryMb > thresholdMb ? b.crashes + 1 : b.crashes })
      .where(eq(browserSessions.id, b.id));
    await db.update(browserContexts).set({ state: "recycled" }).where(and(eq(browserContexts.browserId, b.id), eq(browserContexts.state, "open")));
  }
  return unhealthy.length;
}
