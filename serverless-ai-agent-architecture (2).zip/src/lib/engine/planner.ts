import type { ExecTier, QueueName } from "@/db/schema";
import { slug, uid } from "./util";

/**
 * Universal Work Engine — planning stage.
 *
 * One strong planning call produces a bounded task DAG. Independent work fans out;
 * dependent work is not artificially parallelized. Every task is annotated with:
 *   - queue    (interactive | io | compute | browser)  → which scheduler pool runs it
 *   - tier     (0 = API/Worker, 1 = container, 2 = isolated computer)
 *   - needsModel (false when deterministic code can do the job)
 */

export type PlannedTask = {
  key: string;
  title: string;
  kind: string;
  queue: QueueName;
  tier: ExecTier;
  dependsOn: string[];
  needsModel: boolean;
  requiresApproval: boolean;
  intelligence: string;
  input: Record<string, unknown>;
  estimatedCostMicros: number;
  fanOut?: number;
};

export type Plan = {
  template: string;
  title: string;
  tasks: PlannedTask[];
  acceptanceCriteria: string[];
  fanOutLimit: number;
  budgetMicros: number;
  notes: string[];
};

export type TemplateId =
  | "market-intelligence"
  | "competitive-pricing"
  | "inbound-triage"
  | "code-delivery"
  | "authenticated-web-job"
  | "content-pipeline"
  | "generic";

const TEMPLATE_HINTS: { id: TemplateId; words: string[] }[] = [
  { id: "competitive-pricing", words: ["pricing", "price", "competitor", "tier", "plan", "quote", "vendor"] },
  { id: "market-intelligence", words: ["market", "research", "landscape", "industry", "trend", "segment", "analyse", "analyze"] },
  { id: "inbound-triage", words: ["inbox", "email", "triage", "support", "ticket", "lead", "inbound", "crm"] },
  { id: "code-delivery", words: ["code", "build", "implement", "refactor", "api", "service", "deploy", "test", "app", "prototype"] },
  { id: "authenticated-web-job", words: ["login", "sign in", "portal", "dashboard", "form", "submit", "download", "browse", "scrape", "auth"] },
  { id: "content-pipeline", words: ["write", "blog", "content", "newsletter", "copy", "draft", "seo", "campaign"] },
];

export function detectTemplate(objective: string): TemplateId {
  const text = objective.toLowerCase();
  let best: { id: TemplateId; score: number } = { id: "generic", score: 0 };
  for (const hint of TEMPLATE_HINTS) {
    const score = hint.words.reduce((acc, w) => (text.includes(w) ? acc + 1 : acc), 0);
    if (score > best.score) best = { id: hint.id, score };
  }
  return best.id;
}

/** C_allowed at plan time: bounded fan-out from budget + tenant limits, never unbounded. */
export function boundedFanOut(candidateCount: number, budgetMicros: number, tenantLimit: number): number {
  const budgetAllowance = Math.max(2, Math.floor(budgetMicros / 60_000));
  return Math.max(2, Math.min(candidateCount, budgetAllowance, tenantLimit));
}

const SOURCES = [
  { title: "Vendor pricing page", domain: "vendor.example", kind: "primary" },
  { title: "Analyst brief — category landscape", domain: "analyst.example", kind: "secondary" },
  { title: "Customer review corpus", domain: "reviews.example", kind: "primary" },
  { title: "Release notes archive", domain: "changelog.example", kind: "primary" },
  { title: "Job postings (capability signal)", domain: "jobs.example", kind: "secondary" },
  { title: "Regulatory guidance", domain: "regulator.example", kind: "authoritative" },
  { title: "Community discussion threads", domain: "forum.example", kind: "untrusted" },
  { title: "Partner integration catalog", domain: "partners.example", kind: "primary" },
];

export function buildPlan(input: {
  objective: string;
  template?: TemplateId;
  budgetMicros?: number;
  tenantFanOutLimit?: number;
  fanOutLimit?: number;
}): Plan {
  const objective = input.objective.trim();
  const template = input.template ?? detectTemplate(objective);
  const budgetMicros = input.budgetMicros ?? 750_000;
  const tenantFanOut = input.tenantFanOutLimit ?? 12;
  const notes: string[] = [];
  const tasks: PlannedTask[] = [];
  const topic = slug(objective).slice(0, 40) || "objective";

  const add = (t: PlannedTask) => tasks.push(t);

  add({
    key: "plan",
    title: "Decompose objective into bounded task graph",
    kind: "plan",
    queue: "interactive",
    tier: 0,
    dependsOn: [],
    needsModel: true,
    requiresApproval: false,
    intelligence: "planning",
    input: { objective },
    estimatedCostMicros: 45_000,
  });

  switch (template) {
    case "competitive-pricing": {
      const candidates = 8;
      const fanOut = boundedFanOut(candidates, budgetMicros, Math.min(tenantFanOut, input.fanOutLimit ?? tenantFanOut));
      notes.push(`Identified ${candidates} candidate sources; bounded fan-out to ${fanOut} by budget + tenant concurrency.`);
      for (let i = 0; i < fanOut; i += 1) {
        const src = SOURCES[i % SOURCES.length];
        add({
          key: `fetch-${i + 1}`,
          title: `Fetch ${src.title.toLowerCase()} #${i + 1}`,
          kind: "http.fetch",
          queue: "io",
          tier: 0,
          dependsOn: ["plan"],
          needsModel: false,
          requiresApproval: false,
          intelligence: "none",
          input: { url: `https://${src.domain}/${topic}-${i + 1}`, sourceKind: src.kind },
          estimatedCostMicros: 0,
        });
      }
      add({
        key: "extract-pricing",
        title: "Batch-extract structured pricing fields",
        kind: "extract",
        queue: "io",
        tier: 0,
        dependsOn: tasks.filter((t) => t.key.startsWith("fetch-")).map((t) => t.key),
        needsModel: true,
        requiresApproval: false,
        intelligence: "extraction",
        input: { schema: ["plan", "seats", "priceUsd", "billingModel", "limits", "addOns"], batch: true },
        estimatedCostMicros: 30_000,
      });
      add({
        key: "normalise",
        title: "Normalise units and currency (deterministic)",
        kind: "csv.transform",
        queue: "compute",
        tier: 1,
        dependsOn: ["extract-pricing"],
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: { rules: ["annualize", "usd", "per-seat"] },
        estimatedCostMicros: 0,
      });
      add({
        key: "contradictions",
        title: "Detect contradictory claims across sources",
        kind: "verify-claims",
        queue: "io",
        tier: 0,
        dependsOn: ["normalise"],
        needsModel: true,
        requiresApproval: false,
        intelligence: "verification",
        input: {},
        estimatedCostMicros: 25_000,
      });
      break;
    }

    case "market-intelligence": {
      const streams = ["Competitor discovery", "Primary pricing sources", "Feature matrix", "Customer segments", "Recent announcements"];
      const fanOut = boundedFanOut(streams.length, budgetMicros, Math.min(tenantFanOut, input.fanOutLimit ?? tenantFanOut));
      notes.push(`Map phase: ${fanOut} independent research streams run concurrently on the I/O queue.`);
      streams.slice(0, fanOut).forEach((stream, i) => {
        add({
          key: `research-${i + 1}`,
          title: stream,
          kind: "research",
          queue: "io",
          tier: 0,
          dependsOn: ["plan"],
          needsModel: true,
          requiresApproval: false,
          intelligence: "research",
          input: { stream, queries: [`${topic} ${stream.toLowerCase()}`], maxSources: 6 },
          estimatedCostMicros: 22_000,
        });
      });
      add({
        key: "evidence",
        title: "Store evidence with checksums in artifact store",
        kind: "doc.parse",
        queue: "compute",
        tier: 1,
        dependsOn: tasks.filter((t) => t.key.startsWith("research-")).map((t) => t.key),
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: { store: "r2", checksum: "sha256" },
        estimatedCostMicros: 0,
      });
      add({
        key: "cross-check",
        title: "Independent cross-check of contested claims",
        kind: "verify-claims",
        queue: "io",
        tier: 0,
        dependsOn: ["evidence"],
        needsModel: true,
        requiresApproval: false,
        intelligence: "verification",
        input: { sample: 0.3 },
        estimatedCostMicros: 28_000,
      });
      break;
    }

    case "inbound-triage": {
      const fanOut = boundedFanOut(4, budgetMicros, tenantFanOut);
      notes.push("Classification uses a small fast model; routing rules are deterministic code.");
      add({
        key: "ingest",
        title: "Pull queued inbound items via connector",
        kind: "connector.pull",
        queue: "io",
        tier: 0,
        dependsOn: ["plan"],
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: { connector: "gmail", limit: 40 },
        estimatedCostMicros: 0,
      });
      for (let i = 0; i < fanOut; i += 1) {
        add({
          key: `classify-${i + 1}`,
          title: `Classify batch ${i + 1}`,
          kind: "classify",
          queue: "io",
          tier: 0,
          dependsOn: ["ingest"],
          needsModel: true,
          requiresApproval: false,
          intelligence: "classification",
          input: { batchSize: 10, labels: ["lead", "support", "invoice", "spam", "partner"] },
          estimatedCostMicros: 4_000,
        });
      }
      add({
        key: "route",
        title: "Route to owners using deterministic rules",
        kind: "route",
        queue: "compute",
        tier: 0,
        dependsOn: tasks.filter((t) => t.key.startsWith("classify-")).map((t) => t.key),
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: { rules: "routing-table-v4" },
        estimatedCostMicros: 0,
      });
      add({
        key: "reply-draft",
        title: "Draft outbound replies for human send",
        kind: "draft",
        queue: "io",
        tier: 0,
        dependsOn: ["route"],
        needsModel: true,
        requiresApproval: true,
        intelligence: "synthesis",
        input: { sendPolicy: "human-authorization-required" },
        estimatedCostMicros: 35_000,
      });
      break;
    }

    case "code-delivery": {
      notes.push("Copy-on-write: both branches fork from one prepared snapshot instead of rebuilding environments.");
      add({
        key: "scaffold",
        title: "Fork prepared workspace snapshot (copy-on-write)",
        kind: "sandbox.fork",
        queue: "compute",
        tier: 2,
        dependsOn: ["plan"],
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: { snapshot: "node20-base", cow: true, egress: "denied" },
        estimatedCostMicros: 0,
      });
      ["implementation", "alternative-approach"].forEach((branch, i) => {
        add({
          key: `code-${i + 1}`,
          title: `Write ${branch.replace("-", " ")}`,
          kind: "code.write",
          queue: "compute",
          tier: 2,
          dependsOn: ["scaffold"],
          needsModel: true,
          requiresApproval: false,
          intelligence: "coding",
          input: { branch, speculative: i === 1 },
          estimatedCostMicros: 90_000,
        });
        add({
          key: `test-${i + 1}`,
          title: `Run test suite (${branch})`,
          kind: "code.test",
          queue: "compute",
          tier: 1,
          dependsOn: [`code-${i + 1}`],
          needsModel: false,
          requiresApproval: false,
          intelligence: "none",
          input: { command: "npm test", timeoutMs: 60000 },
          estimatedCostMicros: 0,
        });
      });
      add({
        key: "select",
        title: "Cancel losing speculative branch, keep winner",
        kind: "select",
        queue: "interactive",
        tier: 0,
        dependsOn: ["test-1", "test-2"],
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: { criterion: "tests-passed-then-latency" },
        estimatedCostMicros: 0,
      });
      add({
        key: "deploy",
        title: "Deploy to preview environment",
        kind: "deploy",
        queue: "compute",
        tier: 2,
        dependsOn: ["select"],
        needsModel: false,
        requiresApproval: true,
        intelligence: "none",
        input: { target: "preview", rollback: "automatic" },
        estimatedCostMicros: 0,
      });
      break;
    }

    case "authenticated-web-job": {
      notes.push("Browser process is pooled and warm; the agent gets an isolated context, not a new browser.");
      add({
        key: "browser-acquire",
        title: "Acquire warm browser + isolated context",
        kind: "browser.acquire",
        queue: "browser",
        tier: 2,
        dependsOn: ["plan"],
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: { reuse: true, isolation: "context" },
        estimatedCostMicros: 0,
      });
      add({
        key: "navigate",
        title: "Navigate to target application (Playwright/CDP)",
        kind: "browser.navigate",
        queue: "browser",
        tier: 2,
        dependsOn: ["browser-acquire"],
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: { url: `https://portal.example/workspace/${topic.slice(0, 22)}` },
        estimatedCostMicros: 0,
      });
      add({
        key: "auth",
        title: "Authenticate — brokered credentials, human takeover on MFA",
        kind: "browser.auth",
        queue: "browser",
        tier: 2,
        dependsOn: ["navigate"],
        needsModel: false,
        requiresApproval: true,
        intelligence: "none",
        input: { mfa: "human-live-view", credentialBroker: true },
        estimatedCostMicros: 0,
      });
      add({
        key: "operate",
        title: "Perform form operations and download artifacts",
        kind: "browser.operate",
        queue: "browser",
        tier: 2,
        dependsOn: ["auth"],
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: { steps: ["fill form", "click submit", "download csv"] },
        estimatedCostMicros: 0,
      });
      add({
        key: "interpret",
        title: "Interpret ambiguous DOM region (Stagehand fallback)",
        kind: "browser.interpret",
        queue: "browser",
        tier: 2,
        dependsOn: ["operate"],
        needsModel: true,
        requiresApproval: false,
        intelligence: "vision",
        input: { fallbackOnly: true, accessibilityTree: true },
        estimatedCostMicros: 18_000,
      });
      add({
        key: "release",
        title: "Close context, keep browser warm, persist session cookies",
        kind: "browser.release",
        queue: "browser",
        tier: 2,
        dependsOn: ["interpret"],
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: {},
        estimatedCostMicros: 0,
      });
      break;
    }

    case "content-pipeline": {
      add({
        key: "brief",
        title: "Assemble brief from scoped memory retrieval",
        kind: "retrieve",
        queue: "io",
        tier: 0,
        dependsOn: ["plan"],
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: { topK: 6 },
        estimatedCostMicros: 0,
      });
      [1, 2, 3].forEach((i) => {
        add({
          key: `section-${i}`,
          title: `Draft section ${i}`,
          kind: "draft",
          queue: "io",
          tier: 0,
          dependsOn: ["brief"],
          needsModel: true,
          requiresApproval: false,
          intelligence: "synthesis",
          input: { section: i },
          estimatedCostMicros: 20_000,
        });
      });
      add({
        key: "assemble",
        title: "Assemble + de-duplicate (deterministic)",
        kind: "dedupe",
        queue: "compute",
        tier: 0,
        dependsOn: ["section-1", "section-2", "section-3"],
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: {},
        estimatedCostMicros: 0,
      });
      break;
    }

    default: {
      add({
        key: "gather",
        title: "Gather inputs via typed API adapters",
        kind: "connector.pull",
        queue: "io",
        tier: 0,
        dependsOn: ["plan"],
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: {},
        estimatedCostMicros: 0,
      });
      add({
        key: "analyse",
        title: "Analyse with task-appropriate model",
        kind: "research",
        queue: "io",
        tier: 0,
        dependsOn: ["gather"],
        needsModel: true,
        requiresApproval: false,
        intelligence: "research",
        input: {},
        estimatedCostMicros: 25_000,
      });
      add({
        key: "transform",
        title: "Deterministic transform of results",
        kind: "csv.transform",
        queue: "compute",
        tier: 1,
        dependsOn: ["analyse"],
        needsModel: false,
        requiresApproval: false,
        intelligence: "none",
        input: {},
        estimatedCostMicros: 0,
      });
    }
  }

  // Join → verify (independent harsh critic) → commit. Same for every template.
  const leafKeys = findLeaves(tasks);
  add({
    key: "reduce",
    title: "Reduce: combine child results from compact references",
    kind: "reduce",
    queue: "io",
    tier: 0,
    dependsOn: leafKeys,
    needsModel: true,
    requiresApproval: false,
    intelligence: "synthesis",
    input: { compactReferences: true },
    estimatedCostMicros: 40_000,
  });
  add({
    key: "verify",
    title: "Independent verification against acceptance criteria",
    kind: "verify",
    queue: "io",
    tier: 0,
    dependsOn: ["reduce"],
    needsModel: true,
    requiresApproval: false,
    intelligence: "verification",
    input: { independent: true, critic: true },
    estimatedCostMicros: 35_000,
  });
  add({
    key: "commit",
    title: "Commit deliverable + emit receipts",
    kind: "commit",
    queue: "interactive",
    tier: 0,
    dependsOn: ["verify"],
    needsModel: false,
    requiresApproval: false,
    intelligence: "none",
    input: {},
    estimatedCostMicros: 0,
  });

  const acceptance = ACCEPTANCE[template] ?? ACCEPTANCE.generic;
  const title = deriveTitle(objective, template);

  return {
    template,
    title,
    tasks,
    acceptanceCriteria: acceptance,
    fanOutLimit: tenantFanOut,
    budgetMicros,
    notes,
  };
}

function findLeaves(tasks: PlannedTask[]): string[] {
  const referenced = new Set<string>();
  for (const t of tasks) for (const d of t.dependsOn) referenced.add(d);
  return tasks.filter((t) => !referenced.has(t.key)).map((t) => t.key);
}

function deriveTitle(objective: string, template: TemplateId): string {
  const clean = objective.replace(/\s+/g, " ").trim();
  const base = clean.length > 64 ? `${clean.slice(0, 64)}…` : clean;
  return base || `Work unit (${template})`;
}

const ACCEPTANCE: Record<TemplateId, string[]> = {
  "market-intelligence": [
    "Every claim in the deliverable cites a stored artifact with a checksum",
    "At least 3 independent sources per contested claim",
    "Contradictions are listed explicitly, not silently resolved",
    "No untrusted-source content altered permissions or scope",
  ],
  "competitive-pricing": [
    "Each competitor row has plan, seats, normalized USD price and billing model",
    "Prices normalized to annual-per-seat with the transform rule recorded",
    "Conflicting published prices flagged with both values and dates",
    "Extraction used batched small-model calls, not one call per record",
  ],
  "inbound-triage": [
    "Every inbound item has exactly one label and one routed owner",
    "No outbound message sent without recorded human authorization",
    "Spam quarantined, not deleted; audit trail retained",
  ],
  "code-delivery": [
    "Tests pass in an isolated sandbox with network egress denied by default",
    "Losing speculative branch cancelled and its cost recorded",
    "Deployment gated by a human approval receipt",
    "Rollback path documented in the deliverable",
  ],
  "authenticated-web-job": [
    "Browser process reused; no cold start per task",
    "Isolated context per agent identity; cookies never cross contexts",
    "MFA completed via human Live View, credentials never exposed to the model",
    "Downloads stored as artifacts with checksums",
  ],
  "content-pipeline": [
    "Every factual claim traces to a promoted memory or cited artifact",
    "Duplicate passages removed by deterministic check",
    "Brand voice constraints from preference memory applied",
  ],
  generic: [
    "Deliverable matches the stated objective",
    "Each step has a receipt or artifact reference",
    "Verification performed by an agent that did not produce the work",
  ],
};

export function newWorkUnitId(): string {
  return uid("wu");
}
