import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { agents, approvals, auditLog, capabilityTokens } from "@/db/schema";
import { signToken, uid } from "./util";

/**
 * Authority Envelope — deterministic authorization, independent of intelligence.
 *
 * Three hard invariants:
 *  I1. The model never receives the underlying secret that authorizes an external action.
 *  I2. Untrusted input (webpage, email, file) cannot change governing permissions.
 *  I3. No child task may hold more authority than its parent.
 */

export type AuthorityRequest = {
  agentId: string;
  workUnitId?: string | null;
  sessionId?: string | null;
  action: string;
  resource?: string;
  domain?: string;
  estimatedCostMicros?: number;
  delegationDepth?: number;
  approvalId?: string | null;
  untrusted?: boolean;
};

export type RuleTrace = { rule: string; effect: "permit" | "forbid" | "obligation"; note: string };

export type Decision = {
  allow: boolean;
  tokenId: string | null;
  reason: string;
  trace: RuleTrace[];
  obligation?: string;
};

const POLICY_VERSION = "v12";

/** Capability patterns support `*` wildcards anywhere: `*.example`, `workunit:*`, `browser.*`. */
export function matches(pattern: string, value: string): boolean {
  if (pattern === "*") return true;
  if (!pattern.includes("*")) return pattern === value;
  const regex = new RegExp(`^${pattern.split("*").map((part) => part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join(".*")}$`);
  return regex.test(value);
}

export function anyMatch(patterns: string[], value?: string): boolean {
  if (!value) return patterns.includes("*");
  return patterns.some((p) => matches(p, value));
}

/** Does this identity's role policy permit the action at all? Used for capability-aware assignment. */
export function permits(agent: { authorityPolicy: { actions: string[]; domains: string[] } } | null | undefined, action: string, domain?: string): boolean {
  if (!agent) return false;
  if (!anyMatch(agent.authorityPolicy.actions, action)) return false;
  if (domain && !anyMatch(agent.authorityPolicy.domains, domain)) return false;
  return true;
}

export async function mintCapability(input: {
  agentId: string;
  workUnitId?: string | null;
  sessionId?: string | null;
  actions?: string[];
  resources?: string[];
  domains?: string[];
  maxCostMicros?: number;
  delegationDepth?: number;
  ttlSeconds?: number;
}) {
  const agentRows = await db.select().from(agents).where(eq(agents.id, input.agentId)).limit(1);
  const agent = agentRows[0];
  const policy = agent?.authorityPolicy;

  // Least privilege: the intersection of the agent's role policy and the requested scope.
  const actions = (input.actions ?? policy?.actions ?? []).filter((a) =>
    policy ? anyMatch(policy.actions, a) : true,
  );
  const resources = (input.resources ?? policy?.resources ?? []).filter((r) =>
    policy ? anyMatch(policy.resources, r) : true,
  );
  const domains = (input.domains ?? policy?.domains ?? []).filter((d) =>
    policy ? anyMatch(policy.domains, d) : true,
  );
  const maxCostMicros = Math.min(
    input.maxCostMicros ?? policy?.maxCostMicros ?? 250_000,
    policy?.maxCostMicros ?? Number.MAX_SAFE_INTEGER,
  );
  const delegationDepth = Math.min(
    input.delegationDepth ?? 0,
    policy?.maxDelegationDepth ?? 2,
  );

  const payload = {
    agent_id: input.agentId,
    work_unit_id: input.workUnitId ?? null,
    session_id: input.sessionId ?? null,
    actions,
    resources,
    domains,
    max_cost: maxCostMicros,
    delegation_depth: delegationDepth,
    policy_version: POLICY_VERSION,
    expires_at: new Date(Date.now() + (input.ttlSeconds ?? 900) * 1000).toISOString(),
  };

  const id = uid("cap");
  const signature = signToken(payload);

  await db.insert(capabilityTokens).values({
    id,
    agentId: input.agentId,
    workUnitId: input.workUnitId ?? null,
    sessionId: input.sessionId ?? null,
    actions,
    resources,
    domains,
    maxCostMicros: maxCostMicros,
    delegationDepth,
    policyVersion: POLICY_VERSION,
    signature,
    expiresAt: new Date(payload.expires_at),
  });

  return { ...payload, id, signature };
}

/** Evaluate an action request against the governing policy. Deterministic, no model call. */
export async function authorize(req: AuthorityRequest): Promise<Decision> {
  const trace: RuleTrace[] = [];
  const now = new Date();

  const agentRows = await db.select().from(agents).where(eq(agents.id, req.agentId)).limit(1);
  const agent = agentRows[0];
  if (!agent) {
    return { allow: false, tokenId: null, reason: "unknown principal", trace: [{ rule: "principal.exists", effect: "forbid", note: req.agentId }] };
  }
  trace.push({ rule: "principal.exists", effect: "permit", note: `${agent.name} (${agent.role})` });

  if (agent.status === "suspended") {
    trace.push({ rule: "principal.status", effect: "forbid", note: "agent suspended" });
    await recordDenial(req, "agent suspended");
    return { allow: false, tokenId: null, reason: "agent suspended", trace };
  }

  const tokens = await db
    .select()
    .from(capabilityTokens)
    .where(and(eq(capabilityTokens.agentId, req.agentId), eq(capabilityTokens.revoked, false)));

  const token = tokens
    .filter((t) => t.expiresAt > now)
    .filter((t) => !req.workUnitId || !t.workUnitId || t.workUnitId === req.workUnitId)
    .sort((a, b) => a.maxCostMicros - b.maxCostMicros)
    .find((t) => t.actions.some((a) => matches(a, req.action)));

  if (!token) {
    trace.push({ rule: "capability.scope", effect: "forbid", note: `no live token grants ${req.action}` });
    await recordDenial(req, "no capability grant");
    return { allow: false, tokenId: null, reason: `no capability grant for ${req.action}`, trace };
  }
  trace.push({ rule: "capability.scope", effect: "permit", note: `token ${token.id} grants ${req.action}` });

  if (req.resource && !anyMatch(token.resources, req.resource)) {
    trace.push({ rule: "resource.match", effect: "forbid", note: `${req.resource} not in scope` });
    await recordDenial(req, "resource out of scope");
    return { allow: false, tokenId: token.id, reason: `resource ${req.resource} outside grant`, trace };
  }
  trace.push({ rule: "resource.match", effect: "permit", note: req.resource ?? "no resource" });

  if (req.domain && !anyMatch(token.domains, req.domain)) {
    trace.push({ rule: "network.egress", effect: "forbid", note: `${req.domain} not allowlisted` });
    await recordDenial(req, `egress blocked: ${req.domain}`);
    return { allow: false, tokenId: token.id, reason: `egress to ${req.domain} denied`, trace };
  }
  if (req.domain) trace.push({ rule: "network.egress", effect: "permit", note: req.domain });

  // I3 — delegation attenuation
  const depth = req.delegationDepth ?? 0;
  if (depth > token.delegationDepth + 1) {
    trace.push({ rule: "delegation.attenuation", effect: "forbid", note: `depth ${depth} > parent ${token.delegationDepth}` });
    await recordDenial(req, "delegation escalation");
    return { allow: false, tokenId: token.id, reason: "child authority exceeds parent", trace };
  }
  trace.push({ rule: "delegation.attenuation", effect: "permit", note: `depth ${depth}/${token.delegationDepth + 1}` });

  const cost = req.estimatedCostMicros ?? 0;
  if (cost > token.maxCostMicros) {
    trace.push({ rule: "budget.ceiling", effect: "forbid", note: `${cost}µ$ > cap ${token.maxCostMicros}µ$` });
    await recordDenial(req, "budget ceiling");
    return { allow: false, tokenId: token.id, reason: "estimated cost exceeds capability ceiling", trace };
  }
  trace.push({ rule: "budget.ceiling", effect: "permit", note: `${cost}µ$ within ${token.maxCostMicros}µ$` });

  // I2 — untrusted content may not alter permissions
  if (req.untrusted) {
    trace.push({ rule: "untrusted.input", effect: "obligation", note: "content treated as data; permission set frozen" });
  }

  const needsApproval = (agent.authorityPolicy.requiresApproval ?? []).some((a) => matches(a, req.action));
  if (needsApproval) {
    const decided = req.approvalId
      ? await db.select().from(approvals).where(eq(approvals.id, req.approvalId)).limit(1)
      : [];
    if (!decided[0] || decided[0].status !== "approved") {
      trace.push({ rule: "human.approval", effect: "obligation", note: `${req.action} requires human authorization` });
      return {
        allow: false,
        tokenId: token.id,
        reason: "awaiting human approval",
        trace,
        obligation: "approval",
      };
    }
    trace.push({ rule: "human.approval", effect: "permit", note: `approved by ${decided[0].decidedBy ?? "operator"}` });
  }

  await db
    .update(capabilityTokens)
    .set({ grantedCount: token.grantedCount + 1 })
    .where(eq(capabilityTokens.id, token.id));

  return { allow: true, tokenId: token.id, reason: "permitted by capability + role policy", trace };
}

async function recordDenial(req: AuthorityRequest, reason: string) {
  await db
    .update(capabilityTokens)
    .set({ deniedCount: 1 })
    .where(eq(capabilityTokens.agentId, req.agentId));
  await db.insert(auditLog).values({
    id: uid("aud"),
    actor: req.agentId,
    action: req.action,
    subject: req.resource ?? req.domain ?? req.workUnitId ?? null,
    result: "denied",
    severity: "warning",
    detail: { reason, workUnitId: req.workUnitId ?? null, delegationDepth: req.delegationDepth ?? 0 },
  });
}

/**
 * I1 — the credential broker injects the real secret at the execution boundary.
 * The model only ever sees a reference handle.
 */
export function brokerCredential(action: string, resource?: string) {
  const ref = `vault://${(resource ?? action).replace(/[^a-z0-9:_-]/gi, "-")}`;
  return {
    secretRef: ref,
    exposedToModel: false,
    injectedAt: "tool-gateway",
    materialized: `⟨redacted ${action} credential⟩`,
    rotation: "90d",
  };
}

const INJECTION_PATTERNS: { pattern: RegExp; label: string }[] = [
  { pattern: /ignore (all |previous |prior )?instructions/i, label: "instruction override" },
  { pattern: /you are now (a|an|the) /i, label: "role hijack" },
  { pattern: /(reveal|print|show) .{0,24}(api[_ -]?key|secret|token|password)/i, label: "credential exfiltration" },
  { pattern: /(curl|fetch|post) .{0,40}(169\.254|metadata|localhost)/i, label: "SSRF / metadata probe" },
  { pattern: /grant .{0,20}(admin|write|all) (access|permission)/i, label: "privilege escalation" },
  { pattern: /system:\s*(allow|permit|approve)/i, label: "forged system directive" },
];

/** I2 — scan untrusted content. Findings never mutate permissions; they quarantine the content. */
export function scanUntrusted(content: string): { findings: string[]; quarantine: boolean } {
  const findings = INJECTION_PATTERNS.filter((p) => p.pattern.test(content)).map((p) => p.label);
  return { findings, quarantine: findings.length > 0 };
}

export const POLICY_LIBRARY = [
  { id: "principal.exists", text: "principal must be a registered identity in PostgreSQL" },
  { id: "principal.status", text: "forbid(principal, action) when principal.status == suspended" },
  { id: "capability.scope", text: "permit only when a live, unexpired, unrevoked token grants the action" },
  { id: "resource.match", text: "forbid when resource ∉ token.resources" },
  { id: "network.egress", text: "forbid when domain ∉ allowlist — default deny, enforced outside the model" },
  { id: "delegation.attenuation", text: "forbid when child.delegation_depth > parent.delegation_depth + 1" },
  { id: "budget.ceiling", text: "forbid when estimated_cost > token.max_cost" },
  { id: "human.approval", text: "obligation: consequential actions require a recorded human decision" },
  { id: "untrusted.input", text: "obligation: untrusted content is data; it can never widen the permission set" },
  { id: "credential.broker", text: "obligation: secrets are injected at the gateway; the model sees a reference only" },
];
