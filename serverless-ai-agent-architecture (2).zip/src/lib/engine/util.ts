import { createHash, createHmac, randomBytes } from "crypto";

/* ------------------------------------------------------------------ ids */

export function uid(prefix: string): string {
  return `${prefix}_${randomBytes(6).toString("hex")}`;
}

export function shortId(): string {
  return randomBytes(4).toString("hex");
}

/* ------------------------------------------------------------- hashing */

export function checksum(input: string): string {
  return `sha256:${createHash("sha256").update(input).digest("hex").slice(0, 24)}`;
}

const SIGNING_KEY = process.env.AOS_AUTHORITY_KEY ?? "aos-v3-dev-authority-key";

export function signToken(payload: unknown): string {
  const body = typeof payload === "string" ? payload : JSON.stringify(payload);
  return createHmac("sha256", SIGNING_KEY).update(body).digest("base64url").slice(0, 32);
}

export function verifySignature(payload: unknown, signature: string): boolean {
  return signToken(payload) === signature;
}

/* ---------------------------------------------------------------- math */

export const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

export const sum = (xs: number[]) => xs.reduce((a, b) => a + b, 0);

export function percentile(xs: number[], p: number): number {
  if (!xs.length) return 0;
  const sorted = [...xs].sort((a, b) => a - b);
  const idx = clamp(Math.floor((p / 100) * sorted.length), 0, sorted.length - 1);
  return sorted[idx];
}

export function microsToCents(micros: number): number {
  return Math.round(micros / 10000);
}

export function formatMicros(micros: number): string {
  const dollars = micros / 1_000_000;
  if (dollars >= 1) return `$${dollars.toFixed(2)}`;
  return `$${dollars.toFixed(4)}`;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function formatDuration(ms: number): string {
  if (ms < 1000) return `${Math.round(ms)}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  return `${Math.floor(ms / 60000)}m ${Math.round((ms % 60000) / 1000)}s`;
}

export function timeAgo(date: Date | string | null | undefined): string {
  if (!date) return "—";
  const then = typeof date === "string" ? new Date(date) : date;
  const secs = Math.max(0, (Date.now() - then.getTime()) / 1000);
  if (secs < 5) return "just now";
  if (secs < 60) return `${Math.round(secs)}s ago`;
  if (secs < 3600) return `${Math.round(secs / 60)}m ago`;
  if (secs < 86400) return `${Math.round(secs / 3600)}h ago`;
  return `${Math.round(secs / 86400)}d ago`;
}

/* -------------------------------------------------- deterministic noise */

let seedState = 0x2f6e2b1;
export function noise(spread = 1): number {
  seedState = (seedState * 1664525 + 1013904223) % 4294967296;
  return (seedState / 4294967296) * spread;
}

export function pick<T>(xs: T[]): T {
  return xs[Math.floor(noise(xs.length)) % xs.length];
}

/* -------------------------------------------------- in-Postgres vectors */

const EMBED_DIM = 64;

/**
 * Lightweight deterministic embedding (hashing trick). pgvector is the target in
 * production; this keeps the portable deployment dependency-free while preserving
 * the same retrieval semantics (cosine similarity over a stored vector).
 */
export function embed(text: string): number[] {
  const vec = new Array<number>(EMBED_DIM).fill(0);
  const tokens = text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter(Boolean);
  for (const token of tokens) {
    const h = createHash("sha1").update(token).digest();
    const idx = h.readUInt16BE(0) % EMBED_DIM;
    const sign = h[2] % 2 === 0 ? 1 : -1;
    vec[idx] += sign * (1 + (h[3] % 3) * 0.25);
  }
  const norm = Math.sqrt(vec.reduce((a, b) => a + b * b, 0)) || 1;
  return vec.map((v) => Math.round((v / norm) * 1000) / 1000);
}

export function cosine(a: number[], b: number[]): number {
  if (!a.length || !b.length) return 0;
  const n = Math.min(a.length, b.length);
  let dot = 0;
  for (let i = 0; i < n; i += 1) dot += a[i] * b[i];
  return Math.round(dot * 1000) / 1000;
}

/* ------------------------------------------------------------ text gen */

export function titleCase(input: string): string {
  return input
    .split(/[\s_-]+/)
    .filter(Boolean)
    .map((w) => w[0].toUpperCase() + w.slice(1))
    .join(" ");
}

export function slug(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 48);
}
