import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { agents, organizations, sessionMessages, sessions, tasks, workUnits } from "@/db/schema";
import { authorize, brokerCredential, mintCapability, scanUntrusted } from "./authority";
import { buildContextPackage, searchMemory } from "./memory";
import { gatewayCall, type TaskIntelligence } from "./router";
import { wakeSession } from "./scheduler";
import { formatMicros, noise, pick, uid } from "./util";

/**
 * The session actor. One logical identity can own many concurrent sessions; each session
 * hibernates when idle and resumes from durable state (transcript + pending tool calls).
 */

type Intent = {
  id: string;
  label: string;
  intelligence: TaskIntelligence;
  action: string;
  tier: 0 | 1 | 2;
  tool?: string;
  domain?: string;
};

const INTENTS: { match: RegExp; intent: Intent }[] = [
  { match: /(price|pricing|cost|quote|competitor)/i, intent: { id: "pricing-lookup", label: "Pricing extraction", intelligence: "extraction", action: "http.get", tier: 0, tool: "http.fetch", domain: "vendor.example" } },
  { match: /(browse|open|site|portal|login|sign in|click|download)/i, intent: { id: "browser-job", label: "Authenticated browser operation", intelligence: "none", action: "browser.read", tier: 2, tool: "browser.navigate", domain: "portal.example" } },
  { match: /(code|implement|build|refactor|deploy|test|bug)/i, intent: { id: "code-job", label: "Isolated code execution", intelligence: "coding", action: "sandbox.exec", tier: 2, tool: "sandbox.exec" } },
  { match: /(research|market|analyse|analyze|landscape|segment)/i, intent: { id: "research-job", label: "Parallel research fan-out", intelligence: "research", action: "http.get", tier: 0, tool: "research.fanout" } },
  { match: /(delegate|assign|hand off|handoff|specialist)/i, intent: { id: "delegate", label: "Cross-agent delegation", intelligence: "planning", action: "workunit.plan", tier: 0, tool: "workunit.delegate" } },
  { match: /(remember|preference|memory|note that)/i, intent: { id: "memory-write", label: "Memory write", intelligence: "classification", action: "data.write", tier: 0, tool: "memory.write" } },
  { match: /(schedule|routine|daily|weekly|cron)/i, intent: { id: "schedule", label: "Durable routine registration", intelligence: "none", action: "data.write", tier: 0, tool: "schedule.register" } },
];

function detectIntent(content: string): Intent {
  for (const { match, intent } of INTENTS) if (match.test(content)) return intent;
  return { id: "question", label: "Direct answer from scoped memory", intelligence: "synthesis", action: "memory.read", tier: 0 };
}

export type TurnResult = {
  sessionId: string;
  sessionState: string;
  recovered: boolean;
  messages: { id: string; kind: string; content: string; createdAt: Date }[];
  telemetry: {
    intent: string;
    tier: number;
    model: string;
    tokensIn: number;
    tokensOut: number;
    costMicros: number;
    latencyMs: number;
    cached: boolean;
    contextBytes: number;
    memoryHits: number;
    authority: string;
    injectionFindings: string[];
    credential: string | null;
    tokenId?: string;
  };
};

export async function runTurn(input: { sessionId: string; content: string; actor?: string }): Promise<TurnResult | null> {
  const rows = await db.select().from(sessions).where(eq(sessions.id, input.sessionId)).limit(1);
  const session = rows[0];
  if (!session) return null;

  const woke = await wakeSession(session.id, "inbound message");
  const agentRows = await db.select().from(agents).where(eq(agents.id, session.agentId)).limit(1);
  const agent = agentRows[0];
  const orgRows = await db.select().from(organizations).limit(1);
  const org = orgRows[0];
  if (!agent || !org) return null;

  // I2 — user/web content is data. It can never widen the permission set.
  const scan = scanUntrusted(input.content);

  const userId = uid("msg");
  await db.insert(sessionMessages).values({
    id: userId,
    sessionId: session.id,
    kind: "user",
    content: scan.quarantine ? `${input.content}\n\n[quarantined: ${scan.findings.join(", ")} — treated as data, permissions unchanged]` : input.content,
    tokens: Math.round(input.content.length / 4),
  });

  const intent = detectIntent(input.content);
  const context = await buildContextPackage({ orgId: org.id, agentId: agent.id, objective: input.content });
  const hits = await searchMemory({ query: input.content, orgId: org.id, agentId: agent.id, topK: 4 });

  // Deterministic authorization for the turn's tool action.
  const liveToken = await mintCapability({
    agentId: agent.id,
    sessionId: session.id,
    actions: [intent.action, "memory.read", "data.write"],
    resources: [`session:${session.id}`, `agent:${agent.id}`],
    domains: intent.domain ? [intent.domain] : [],
    maxCostMicros: 120_000,
    delegationDepth: 0,
    ttlSeconds: 600,
  });

  const decision = await authorize({
    agentId: agent.id,
    sessionId: session.id,
    action: intent.action,
    resource: `session:${session.id}`,
    domain: intent.domain,
    estimatedCostMicros: 40_000,
    delegationDepth: 0,
  });

  const events: { id: string; kind: "tool" | "system" | "approval"; content: string; tool?: string; latencyMs: number; costMicros: number; tokens: number }[] = [];
  const credential = intent.domain ? brokerCredential(intent.action, intent.domain) : null;

  events.push({
    id: uid("msg"),
    kind: "system",
    content: `session resumed from ${woke?.wasEvicted ? "eviction" : session.state} · intent: ${intent.label} · tier ${intent.tier} · authority: ${decision.allow ? "permitted" : decision.reason}`,
    latencyMs: 2,
    costMicros: 0,
    tokens: 0,
  });

  if (context.records.length) {
    events.push({
      id: uid("msg"),
      kind: "tool",
      tool: "memory.retrieve",
      content: `Retrieved ${context.records.length} scoped records (${context.bytes} bytes of ${context.budgetBytes} budget): ${context.records.map((r) => r.subject).join(", ")}`,
      latencyMs: 6 + Math.round(noise(18)),
      costMicros: 0,
      tokens: 0,
    });
  }

  if (credential) {
    events.push({
      id: uid("msg"),
      kind: "tool",
      tool: "credential.broker",
      content: `${credential.secretRef} injected at the gateway — never exposed to the model`,
      latencyMs: 3,
      costMicros: 0,
      tokens: 0,
    });
  }

  if (scan.quarantine) {
    events.push({
      id: uid("msg"),
      kind: "system",
      content: `Injection patterns detected (${scan.findings.join(", ")}). Content quarantined; permission set frozen; no policy mutation performed.`,
      latencyMs: 1,
      costMicros: 0,
      tokens: 0,
    });
    await db.insert(sessionMessages).values({
      id: uid("aud"),
      sessionId: session.id,
      kind: "system",
      content: "untrusted-input scan recorded to audit log",
    });
  }

  let delegatedWorkUnitId: string | null = null;
  if (intent.id === "delegate" && decision.allow) {
    delegatedWorkUnitId = await delegate({ agentId: agent.id, orgId: org.id, objective: input.content, parentSessionId: session.id });
    events.push({
      id: uid("msg"),
      kind: "tool",
      tool: "workunit.delegate",
      content: `Child Work Unit ${delegatedWorkUnitId} created with attenuated authority (depth 1). It will fan out on the shared pool.`,
      latencyMs: 12,
      costMicros: 0,
      tokens: 0,
    });
  }

  const gw = await gatewayCall({
    intelligence: decision.allow ? intent.intelligence : "classification",
    promptChars: 1200 + context.bytes + input.content.length,
    expectedOutputChars: intent.id === "question" ? 1400 : 700,
    cacheKey: `${agent.id}:${intent.id}:${input.content.slice(0, 60)}`,
    budgetMicros: 60_000,
  });

  if (intent.tool && decision.allow) {
    events.push({
      id: uid("msg"),
      kind: "tool",
      tool: intent.tool,
      content: toolTrace(intent, input.content, gw.modelName),
      latencyMs: Math.round(gw.latencyMs * 0.4),
      costMicros: 0,
      tokens: 0,
    });
  }

  const reply = composeReply({ agent, intent, content: input.content, context, hits: hits.map((h) => h.memory.subject), decision: decision.reason, allowed: decision.allow, model: gw.modelName, delegatedWorkUnitId, quarantined: scan.quarantine });
  const assistantId = uid("msg");

  for (const ev of events) {
    await db.insert(sessionMessages).values({
      id: ev.id,
      sessionId: session.id,
      kind: ev.kind,
      content: ev.content,
      tool: ev.tool ?? null,
      tokens: ev.tokens,
      latencyMs: ev.latencyMs,
      costMicros: ev.costMicros,
    });
  }
  await db.insert(sessionMessages).values({
    id: assistantId,
    sessionId: session.id,
    kind: "assistant",
    content: reply,
    model: gw.modelName,
    tokens: gw.tokensIn + gw.tokensOut,
    latencyMs: gw.latencyMs,
    costMicros: gw.costMicros,
  });

  await db
    .update(sessions)
    .set({
      turns: session.turns + 1,
      tokens: session.tokens + gw.tokensIn + gw.tokensOut,
      storageBytes: session.storageBytes + reply.length + input.content.length + 512,
      contextBytes: context.bytes,
      lastActiveAt: new Date(),
      state: "resident",
      pendingToolCalls: intent.tool ? 1 : 0,
    })
    .where(eq(sessions.id, session.id));

  await db.update(organizations).set({ spentCents: org.spentCents + Math.round(gw.costMicros / 10000) }).where(eq(organizations.id, org.id));

  const all = await db.select().from(sessionMessages).where(eq(sessionMessages.sessionId, session.id)).orderBy(desc(sessionMessages.createdAt)).limit(24);

  return {
    sessionId: session.id,
    sessionState: "resident",
    recovered: Boolean(woke?.wasEvicted),
    messages: all.reverse().map((m) => ({ id: m.id, kind: m.kind, content: m.content, createdAt: m.createdAt })),
    telemetry: {
      intent: intent.label,
      tier: intent.tier,
      model: gw.modelName,
      tokensIn: gw.tokensIn,
      tokensOut: gw.tokensOut,
      costMicros: gw.costMicros,
      latencyMs: gw.latencyMs,
      cached: gw.cached,
      contextBytes: context.bytes,
      memoryHits: hits.length,
      authority: decision.allow ? "permitted" : decision.reason,
      injectionFindings: scan.findings,
      credential: credential?.secretRef ?? null,
      tokenId: liveToken.id,
    } as TurnResult["telemetry"],
  };
}

function toolTrace(intent: Intent, content: string, model: string): string {
  const snippet = content.slice(0, 60).replace(/\n/g, " ");
  switch (intent.id) {
    case "pricing-lookup":
      return `http.fetch ×${3 + Math.floor(noise(5))} (tier 0, parallel on the I/O queue) → deterministic parse → batched extraction via ${model} · "${snippet}…"`;
    case "browser-job":
      return `browser.acquire → warm process reused, isolated context opened → playwright/cdp steps → ${3 + Math.floor(noise(4))} pages, screenshots stored as artifacts`;
    case "code-job":
      return `sandbox.fork (copy-on-write snapshot) → microVM, egress denied → patch written by ${model} → test suite executed`;
    case "research-job":
      return `research.fanout: ${4 + Math.floor(noise(6))} independent streams dispatched concurrently; join at the dependency boundary; contested claims verified independently`;
    case "memory-write":
      return `memory.write → candidate fact stored with provenance; promotion requires corroboration by the background compiler`;
    case "schedule":
      return `schedule.register → durable routine stored; no polling loop is created, the scheduler fires it`;
    default:
      return `memory.retrieve → ${model} synthesis over compact references`;
  }
}

function composeReply(input: {
  agent: { name: string; role: string };
  intent: Intent;
  content: string;
  context: { records: { subject: string; excerpt: string; score: number }[]; bytes: number };
  hits: string[];
  decision: string;
  allowed: boolean;
  model: string;
  delegatedWorkUnitId: string | null;
  quarantined: boolean;
}): string {
  const { agent, intent, context, allowed, model, delegatedWorkUnitId, quarantined } = input;
  const evidence = context.records.slice(0, 3).map((r) => `  • ${r.subject} — ${r.excerpt.slice(0, 110)}… (score ${r.score})`);
  const parts: string[] = [];
  parts.push(`**${agent.name}** · ${agent.role} · session resumed from durable state.`);
  if (quarantined) {
    parts.push("Your message contained content matching known injection patterns. I treated it strictly as data: no permission changed, no policy was rewritten, and the attempt is in the audit log.");
  }
  if (!allowed) {
    parts.push(`I cannot execute that action myself — authorization returned: **${input.decision}**. I have raised it in the approval center; a human decision unblocks it. Agents request, they never self-authorize.`);
    return parts.join("\n\n");
  }
  parts.push(`Interpreted intent: **${intent.label}** — routed to the least capable sufficient execution tier (tier ${intent.tier}) and model (\`${model}\`).`);
  if (evidence.length) {
    parts.push(`Working memory assembled from ${context.records.length} scoped records (${context.bytes} bytes — not the whole knowledge base):\n${evidence.join("\n")}`);
  } else {
    parts.push("No relevant memory records yet; this turn's outcome will be offered to the background memory compiler.");
  }
  if (delegatedWorkUnitId) {
    parts.push(`Delegated as child Work Unit \`${delegatedWorkUnitId}\` with attenuated authority. It will fan out across the shared pool while this session hibernates.`);
  }
  parts.push(
    intent.tier === 0
      ? "Nothing booted for this turn: typed API calls and deterministic code only. The session will hibernate as soon as it goes idle, releasing all resident memory."
      : intent.tier === 1
        ? "A 256 MiB container handled the compute step and scaled back to zero immediately afterwards."
        : "An isolated environment was provisioned for this task only, then released. It is not kept warm on my behalf.",
  );
  return parts.join("\n\n");
}

async function delegate(input: { agentId: string; orgId: string; objective: string; parentSessionId: string }): Promise<string> {
  const parentAgent = (await db.select().from(agents).where(eq(agents.id, input.agentId)).limit(1))[0];
  const pool = await db.select().from(agents);
  const specialist =
    pool.find((a) => a.id !== input.agentId && a.department === (parentAgent?.department ?? "research")) ??
    pool.find((a) => a.id !== input.agentId) ??
    parentAgent;
  const id = uid("wu");
  await db.insert(workUnits).values({
    id,
    orgId: input.orgId,
    title: input.objective.slice(0, 90),
    objective: input.objective,
    template: "generic",
    ownerAgentId: specialist?.id ?? input.agentId,
    status: "planning",
    delegationDepth: 1,
    fanOutLimit: 8,
    budgetMicros: 400_000,
    priority: 6,
    acceptanceCriteria: ["Delegated authority never exceeds the parent grant", "Deliverable verified by an independent critic"],
  });
  if (specialist) {
    await mintCapability({
      agentId: specialist.id,
      workUnitId: id,
      actions: ["http.get", "data.write", "memory.read"],
      resources: [`workunit:${id}`],
      maxCostMicros: 200_000,
      delegationDepth: 0,
    });
  }
  return id;
}

export async function openSession(input: { agentId: string; title?: string; channel?: string; workUnitId?: string | null }) {
  const id = uid("ses");
  await db.insert(sessions).values({
    id,
    agentId: input.agentId,
    workUnitId: input.workUnitId ?? null,
    title: input.title ?? `Session ${pick(["alpha", "beta", "gamma", "delta"])}`,
    channel: input.channel ?? "web",
    state: "resident",
    residentMemoryMb: 40 + Math.round(noise(24)),
    lastActiveAt: new Date(),
  });
  await db.insert(sessionMessages).values({
    id: uid("msg"),
    sessionId: id,
    kind: "system",
    content: "Durable session opened. Transcript and tool state are persisted; the actor hibernates when idle and resumes exactly where it stopped.",
  });
  const agent = (await db.select().from(agents).where(eq(agents.id, input.agentId)).limit(1))[0];
  if (agent) await db.update(agents).set({ status: "active", residentMemoryMb: 44 }).where(eq(agents.id, agent.id));
  return id;
}

export async function sessionTranscript(sessionId: string) {
  return db.select().from(sessionMessages).where(eq(sessionMessages.sessionId, sessionId)).orderBy(sessionMessages.createdAt);
}

export async function activeTaskCount(agentId: string) {
  const rows = await db.select({ n: tasks.id }).from(tasks).where(eq(tasks.assignedAgentId, agentId));
  return rows.length;
}

export { formatMicros };
