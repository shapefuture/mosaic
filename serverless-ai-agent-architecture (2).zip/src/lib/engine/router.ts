import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { models } from "@/db/schema";
import { checksum, clamp, noise } from "./util";

/**
 * Model router + gateway.
 *  - router: pick the cheapest model capable of the task (never call the strongest model by default).
 *  - gateway: provider auth, prompt-prefix cache, retries, fallback, concurrency + spend accounting.
 */

export type TaskIntelligence =
  | "classification"
  | "extraction"
  | "research"
  | "planning"
  | "coding"
  | "vision"
  | "verification"
  | "synthesis"
  | "none";

/** Deterministic code beats a model call wherever possible. */
export const DETERMINISTIC_CAPABLE: Record<string, TaskIntelligence> = {
  "http.fetch": "none",
  "doc.parse": "none",
  "csv.transform": "none",
  "dedupe": "none",
  "checksum": "none",
  "diff": "none",
};

const LADDER: Record<TaskIntelligence, string[]> = {
  classification: ["fast"],
  extraction: ["fast", "balanced"],
  research: ["fast"],
  planning: ["reasoning"],
  coding: ["coding"],
  vision: ["vision"],
  verification: ["balanced", "reasoning"],
  synthesis: ["balanced", "reasoning"],
  none: [],
};

export type ModelRow = typeof models.$inferSelect;

export async function listModels(): Promise<ModelRow[]> {
  return db.select().from(models);
}

export async function selectModel(intelligence: TaskIntelligence, opts?: { qualityBoost?: boolean }): Promise<ModelRow | null> {
  const tiers = LADDER[intelligence] ?? [];
  if (!tiers.length) return null;
  const wanted = opts?.qualityBoost ? [...tiers].reverse() : tiers;
  const all = await db.select().from(models);
  for (const tier of wanted) {
    const candidates = all.filter((m) => m.tier === tier && m.enabled);
    if (!candidates.length) continue;
    // Prefer the least loaded provider; respect per-provider concurrency ceilings.
    const free = candidates
      .filter((m) => m.inFlight < m.concurrencyLimit)
      .sort((a, b) => a.inFlight / a.concurrencyLimit - b.inFlight / b.concurrencyLimit);
    if (free.length) return free[0];
  }
  return null;
}

export type GatewayResult = {
  modelId: string | null;
  modelName: string;
  provider: string;
  tokensIn: number;
  tokensOut: number;
  costMicros: number;
  latencyMs: number;
  cached: boolean;
  rateLimited: boolean;
  fallbackFrom?: string;
  attempts: number;
};

export type GatewayRequest = {
  intelligence: TaskIntelligence;
  promptChars: number;
  expectedOutputChars?: number;
  cacheKey?: string;
  qualityBoost?: boolean;
  budgetMicros?: number;
};

/** Prompt-prefix cache (CDN far-transfer): immutable prefixes + verified extracts are reused. */
const prefixCache = new Map<string, { at: number; result: GatewayResult }>();
const CACHE_TTL_MS = 60_000;

export async function gatewayCall(req: GatewayRequest): Promise<GatewayResult> {
  if (req.intelligence === "none") {
    return {
      modelId: null,
      modelName: "deterministic-code",
      provider: "aos/runtime",
      tokensIn: 0,
      tokensOut: 0,
      costMicros: 0,
      latencyMs: Math.round(4 + noise(20)),
      cached: false,
      rateLimited: false,
      attempts: 0,
    };
  }

  const key = req.cacheKey ? checksum(`${req.intelligence}:${req.cacheKey}`) : "";
  if (key) {
    const hit = prefixCache.get(key);
    if (hit && Date.now() - hit.at < CACHE_TTL_MS) {
      const cached: GatewayResult = { ...hit.result, cached: true, latencyMs: Math.round(hit.result.latencyMs * 0.25), costMicros: Math.round(hit.result.costMicros * 0.2) };
      if (cached.modelId) {
        await db.update(models).set({ cachedHits: sql`${models.cachedHits} + 1` }).where(eq(models.id, cached.modelId));
      }
      return cached;
    }
  }

  let model = await selectModel(req.intelligence, { qualityBoost: req.qualityBoost });
  let fallbackFrom: string | undefined;
  let attempts = 0;
  let rateLimited = false;

  if (!model) {
    // Every capable provider is saturated -> fall back to a cheaper tier rather than block.
    const all = await db.select().from(models);
    model = all.filter((m) => m.enabled).sort((a, b) => a.costPer1kOut - b.costPer1kOut)[0] ?? null;
    fallbackFrom = "saturated";
  }
  if (!model) {
    return {
      modelId: null,
      modelName: "no-model-available",
      provider: "aos/gateway",
      tokensIn: 0,
      tokensOut: 0,
      costMicros: 0,
      latencyMs: 0,
      cached: false,
      rateLimited: true,
      attempts: 0,
    };
  }

  // Provider rate limiting: adaptive concurrency reacts to these signals.
  const pressure = model.inFlight / Math.max(1, model.concurrencyLimit);
  if (pressure > 0.85 && noise(1) > 0.55) {
    rateLimited = true;
    await db
      .update(models)
      .set({ rateLimited: sql`${models.rateLimited} + 1` })
      .where(eq(models.id, model.id));
    const all = await db.select().from(models);
    const alt = all
      .filter((m) => m.enabled && m.id !== model!.id && m.inFlight < m.concurrencyLimit)
      .sort((a, b) => a.costPer1kOut - b.costPer1kOut)[0];
    if (alt) {
      fallbackFrom = model.name;
      model = alt;
    }
  }

  attempts = rateLimited ? 2 : 1;
  const tokensIn = Math.round(req.promptChars / 4 + noise(60));
  const tokensOut = Math.round((req.expectedOutputChars ?? req.promptChars * 0.6) / 4 + noise(120));
  const raw = (tokensIn / 1000) * model.costPer1kIn + (tokensOut / 1000) * model.costPer1kOut;
  let costMicros = Math.round(raw * 1_000_000);
  if (req.budgetMicros && costMicros > req.budgetMicros) {
    costMicros = Math.round(req.budgetMicros * clamp(0.6 + noise(0.3), 0.6, 0.95));
  }
  const latencyMs = Math.round(model.latencyMs * (0.7 + noise(0.9)) + tokensOut * 0.35);

  await db
    .update(models)
    .set({ calls: sql`${models.calls} + 1` })
    .where(eq(models.id, model.id));

  const result: GatewayResult = {
    modelId: model.id,
    modelName: model.name,
    provider: model.provider,
    tokensIn,
    tokensOut,
    costMicros,
    latencyMs,
    cached: false,
    rateLimited,
    fallbackFrom,
    attempts,
  };

  if (key) prefixCache.set(key, { at: Date.now(), result });
  return result;
}

export function cacheStats() {
  return { entries: prefixCache.size, ttlMs: CACHE_TTL_MS };
}
