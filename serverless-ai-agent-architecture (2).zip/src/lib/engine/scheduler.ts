import { and, asc, desc, eq, inArray, isNull, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  agents,
  approvals,
  artifacts,
  auditLog,
  browserSessions,
  capabilityTokens,
  metricsSamples,
  models,
  organizations,
  receipts,
  sandboxes,
  schedulerState,
  sessionMessages,
  sessions,
  taskEvents,
  tasks,
  workUnits,
  type QueueName,
} from "@/db/schema";
import { authorize, mintCapability, permits } from "./authority";
import { buildPlan, type PlannedTask } from "./planner";
import { executeTask, selectTier, type TaskRow, type WorkUnitRow } from "./executor";
import { compileMemory } from "./memory";
import { recycleUnhealthy } from "./browser";
import { seedIfEmpty } from "./seed";
import { clamp, formatMicros, noise, percentile, uid } from "./util";

const SCHEDULER_ID = "primary";
const QUEUES: QueueName[] = ["interactive", "io", "compute", "browser"];

const DEFAULT_CONCURRENCY: Record<QueueName, { limit: number; active: number; pending: number; p95Ms: number }> = {
  interactive: { limit: 8, active: 0, pending: 0, p95Ms: 0 },
  io: { limit: 48, active: 0, pending: 0, p95Ms: 0 },
  compute: { limit: 16, active: 0, pending: 0, p95Ms: 0 },
  browser: { limit: 6, active: 0, pending: 0, p95Ms: 0 },
};

const DEFAULT_LIMITS = {
  provider: 64,
  tenant: 96,
  queue: 48,
  sandbox: 24,
  budget: 48,
  browserMemoryMb: 4096,
  hibernateAfterSec: 20,
};

const DEFAULT_TOTALS = {
  tasksCompleted: 0,
  tasksFailed: 0,
  modelCalls: 0,
  deterministicSteps: 0,
  tokensIn: 0,
  tokensOut: 0,
  costMicros: 0,
  sideEffects: 0,
  deliverablesAccepted: 0,
  deliverablesRejected: 0,
  unauthorizedBlocked: 0,
  injectionsBlocked: 0,
  residentMemoryMb: 0,
  logicalSessions: 0,
};

export type SchedulerRow = typeof schedulerState.$inferSelect;

const KIND_ACTION: Record<string, string> = {
  "http.fetch": "http.get",
  "connector.pull": "connector.read",
  research: "http.get",
  extract: "data.write",
  classify: "data.write",
  "csv.transform": "compute.run",
  "doc.parse": "compute.run",
  dedupe: "compute.run",
  route: "data.write",
  select: "compute.run",
  "verify-claims": "data.write",
  "sandbox.fork": "sandbox.exec",
  "code.write": "sandbox.exec",
  "code.test": "sandbox.exec",
  deploy: "deploy.preview",
  draft: "message.send",
  retrieve: "memory.read",
  "browser.acquire": "browser.session",
  "browser.navigate": "browser.read",
  "browser.auth": "browser.login",
  "browser.operate": "browser.write",
  "browser.interpret": "browser.read",
  "browser.release": "browser.session",
  reduce: "data.write",
  verify: "data.write",
  commit: "workunit.commit",
  plan: "workunit.plan",
};

export function actionForKind(kind: string): string {
  return KIND_ACTION[kind] ?? "data.write";
}

/** Which department owns a template. Assignment follows capability, not convenience. */
export const TEMPLATE_DEPARTMENT: Record<string, string> = {
  "market-intelligence": "research",
  "competitive-pricing": "research",
  "inbound-triage": "support",
  "code-delivery": "engineering",
  "authenticated-web-job": "operations",
  "content-pipeline": "marketing",
  generic: "operations",
};

export async function getScheduler(): Promise<SchedulerRow> {
  const rows = await db.select().from(schedulerState).where(eq(schedulerState.id, SCHEDULER_ID)).limit(1);
  if (rows[0]) return rows[0];
  const fresh = {
    id: SCHEDULER_ID,
    running: true,
    tickCount: 0,
    lastTickAt: new Date(),
    concurrency: DEFAULT_CONCURRENCY,
    limits: DEFAULT_LIMITS,
    signals: {
      queueWaitMs: 0,
      p95Ms: 0,
      errorRate: 0,
      provider429: 0,
      dbWritesPerTask: 0,
      sandboxUtil: 0,
      browserMemMb: 0,
      budgetUtil: 0,
    },
    totals: DEFAULT_TOTALS,
    decisions: [
      "scheduler online — C_allowed = min(provider, tenant, queue, sandbox, budget)",
      "idle sessions hibernate after 20s; resident footprint drops to storage only",
    ],
  };
  await db.insert(schedulerState).values(fresh);
  return fresh as unknown as SchedulerRow;
}

export type TickSummary = {
  tick: number;
  planned: number;
  started: number;
  completed: number;
  failed: number;
  blocked: number;
  hibernated: number;
  woken: number;
  evicted: number;
  recycled: number;
  decisions: string[];
  durationMs: number;
};

/** One scheduler tick. Idempotent and safe to call from any request; state lives in Postgres. */
export async function tick(): Promise<TickSummary> {
  const t0 = Date.now();
  await seedIfEmpty();
  const sched = await getScheduler();
  const summary: TickSummary = {
    tick: sched.tickCount + 1,
    planned: 0,
    started: 0,
    completed: 0,
    failed: 0,
    blocked: 0,
    hibernated: 0,
    woken: 0,
    evicted: 0,
    recycled: 0,
    decisions: [],
    durationMs: 0,
  };

  // 1. Plan any work unit still in the planning state.
  const planning = await db.select().from(workUnits).where(eq(workUnits.status, "planning")).limit(4);
  for (const wu of planning) {
    await planWorkUnit(wu.id);
    summary.planned += 1;
  }

  // 2. Finalize running tasks whose deadline has passed (asynchronous I/O — no process is held while waiting).
  const running = await db.select().from(tasks).where(eq(tasks.status, "running")).orderBy(asc(tasks.startedAt)).limit(200);
  const now = Date.now();
  for (const task of running) {
    const startedAt = task.startedAt?.getTime() ?? now;
    if (startedAt + task.durationMs <= now) {
      const ok = await finishTask(task);
      if (ok) summary.completed += 1;
      else summary.failed += 1;
    }
  }

  // 3. Unblock tasks whose approval was decided.
  summary.blocked += await releaseApprovedTasks();

  // 4. Promote pending → ready where dependencies are satisfied.
  await promoteReadyTasks();

  // 5. Dispatch ready tasks up to the narrowest active constraint per queue.
  const footprintBefore = await computeFootprint();
  const dispatched = await dispatchTasks(sched);
  summary.started = dispatched.started;
  summary.blocked += dispatched.blocked;
  summary.failed += dispatched.denied;

  // 6. Advance work unit lifecycles (verify → commit → complete/rework).
  await advanceWorkUnits();

  // 7. Session lifecycle: hibernate idle sessions, evict a few, keep footprint near zero.
  const sessionWork = await manageSessions(sched.limits.hibernateAfterSec);
  summary.hibernated = sessionWork.hibernated;
  summary.evicted = sessionWork.evicted;

  // 8. Browser pool health.
  summary.recycled = await recycleUnhealthy(sched.limits.browserMemoryMb / 4);

  // 9. Adaptive concurrency from observed signals (control theory: feedback scheduling).
  const { concurrency, limits, signals, decisions } = await adapt(sched);
  summary.decisions.push(...decisions);

  // 10. Persist a metrics sample and the new scheduler state.
  const footprint = await computeFootprint();
  const totals = await computeTotals();
  const queueRows = await db.select().from(tasks).where(inArray(tasks.status, ["pending", "ready", "running"]));
  const nextConcurrency = { ...concurrency };
  for (const q of QUEUES) {
    nextConcurrency[q] = {
      ...nextConcurrency[q],
      active: queueRows.filter((t) => t.queue === q && t.status === "running").length,
      pending: queueRows.filter((t) => t.queue === q && (t.status === "pending" || t.status === "ready")).length,
    };
  }

  await db.insert(metricsSamples).values({
    id: uid("met"),
    residentMemoryMb: footprint.residentMemoryMb,
    logicalSessions: footprint.logicalSessions,
    residentSessions: footprint.residentSessions,
    runningTasks: footprint.runningTasks,
    pendingTasks: footprint.pendingTasks,
    throughputPerSec: totals.throughputPerSec,
    p95Ms: signals.p95Ms,
    costMicros: totals.costMicros,
    browserMemMb: footprint.browserMemoryMb,
  });

  await db
    .update(schedulerState)
    .set({
      tickCount: summary.tick,
      lastTickAt: new Date(),
      concurrency: nextConcurrency,
      limits,
      signals,
      totals: {
        ...totals,
        unauthorizedBlocked: sched.totals.unauthorizedBlocked + dispatched.denied,
        injectionsBlocked: totals.injectionsBlocked,
        residentMemoryMb: footprint.residentMemoryMb,
        logicalSessions: footprint.logicalSessions,
      },
      decisions: [...decisions, ...sched.decisions].slice(0, 24),
    })
    .where(eq(schedulerState.id, SCHEDULER_ID));

  // Keep the time-series bounded.
  await db.execute(sql`DELETE FROM metrics_samples WHERE id NOT IN (SELECT id FROM metrics_samples ORDER BY at DESC LIMIT 600)`);

  summary.durationMs = Date.now() - t0;
  if (footprintBefore.residentMemoryMb !== footprint.residentMemoryMb) {
    summary.decisions.push(`resident footprint ${footprintBefore.residentMemoryMb.toFixed(0)} → ${footprint.residentMemoryMb.toFixed(0)} MiB`);
  }
  return summary;
}

/* ------------------------------------------------------------- planning */

export async function planWorkUnit(workUnitId: string) {
  const wuRows = await db.select().from(workUnits).where(eq(workUnits.id, workUnitId)).limit(1);
  const wu = wuRows[0];
  if (!wu) return null;

  const plan = buildPlan({
    objective: wu.objective,
    template: wu.template === "generic" ? undefined : (wu.template as never),
    budgetMicros: wu.budgetMicros,
    fanOutLimit: wu.fanOutLimit,
    tenantFanOutLimit: wu.fanOutLimit,
  });

  const agentRows = await db.select().from(agents);
  const dept = TEMPLATE_DEPARTMENT[plan.template] ?? "operations";
  const requested = agentRows.find((a) => a.id === wu.ownerAgentId);
  const owner =
    (requested?.department === dept ? requested : undefined) ??
    agentRows.find((a) => a.department === dept) ??
    requested ??
    agentRows.find((a) => a.department === "operations") ??
    agentRows[0];

  const values = plan.tasks.map((t) => taskRowFromPlan(t, wu.id, owner?.id ?? null, plan.tasks));
  await db.insert(tasks).values(values);

  await db
    .update(workUnits)
    .set({
      status: "running",
      title: wu.title === wu.objective ? plan.title : wu.title,
      template: plan.template,
      acceptanceCriteria: plan.acceptanceCriteria,
      taskCount: values.length,
      ownerAgentId: owner?.id ?? wu.ownerAgentId,
      startedAt: new Date(),
    })
    .where(eq(workUnits.id, wu.id));

  if (owner) {
    // Least privilege: the opening grant only covers what this identity's role policy permits.
    // Specialist tasks receive their own operation-scoped token at dispatch time.
    const ownerActions = Array.from(new Set(values.map((v) => actionForKind(v.kind)))).filter((a) => permits(owner, a));
    if (ownerActions.length) {
      await mintCapability({
        agentId: owner.id,
        workUnitId: wu.id,
        actions: ownerActions,
        resources: [`workunit:${wu.id}`, `project:${wu.orgId}`],
        maxCostMicros: wu.budgetMicros,
        delegationDepth: wu.delegationDepth,
      });
    }
    await db.update(agents).set({ status: "active" }).where(eq(agents.id, owner.id));
  }

  await emit(workUnitId, null, "workunit.planned", `${plan.template} · ${values.length} tasks · bounded fan-out ${wu.fanOutLimit}`);
  for (const note of plan.notes) await emit(workUnitId, null, "plan.note", note);
  return plan;
}

function taskRowFromPlan(t: PlannedTask, workUnitId: string, agentId: string | null, all: PlannedTask[]) {
  const byKey = new Map(all.map((x) => [x.key, x]));
  const deps = t.dependsOn.filter((d) => byKey.has(d));
  const ready = deps.length === 0;
  return {
    id: uid("tsk"),
    workUnitId,
    key: t.key,
    title: t.title,
    kind: t.kind,
    queue: t.queue,
    tier: t.tier,
    status: (ready ? "ready" : "pending") as "ready" | "pending",
    dependsOn: deps,
    assignedAgentId: agentId,
    requiresApproval: t.requiresApproval,
    needsModel: t.needsModel,
    idempotencyKey: `${workUnitId}:${t.key}`,
    input: { ...t.input, intelligence: t.intelligence, estimatedCostMicros: t.estimatedCostMicros },
    maxAttempts: t.kind === "browser.auth" ? 2 : 3,
  };
}

/* ----------------------------------------------------------- dispatch */

async function dispatchTasks(sched: SchedulerRow) {
  let started = 0;
  let blocked = 0;
  let denied = 0;
  const allowed = allowedConcurrency(sched);

  for (const queue of QUEUES) {
    const capacity = allowed[queue];
    if (capacity <= 0) continue;
    const ready = await db
      .select()
      .from(tasks)
      .where(and(eq(tasks.status, "ready"), eq(tasks.queue, queue)))
      .orderBy(asc(tasks.createdAt))
      .limit(capacity);

    for (const task of ready) {
      const wuRows = await db.select().from(workUnits).where(eq(workUnits.id, task.workUnitId)).limit(1);
      const wu = wuRows[0];
      if (!wu || wu.status === "cancelled" || wu.status === "completed") {
        await db.update(tasks).set({ status: "skipped" }).where(eq(tasks.id, task.id));
        continue;
      }
      if (wu.spentMicros >= wu.budgetMicros) {
        await db.update(tasks).set({ status: "blocked", error: "work unit budget exhausted" }).where(eq(tasks.id, task.id));
        await emit(wu.id, task.id, "budget.exhausted", `${formatMicros(wu.spentMicros)} of ${formatMicros(wu.budgetMicros)} — backpressure applied`);
        blocked += 1;
        continue;
      }

      const agent = await resolveAgent(task, wu);
      if (!agent) {
        blocked += 1;
        continue;
      }

      // Per-task grant: issue a short-lived, operation-scoped capability before execution.
      await ensureCapability({ agentId: agent.id, workUnit: wu, action: actionForKind(task.kind), domain: domainForTask(task) });

      // A previously granted decision is presented to the evaluator; a newer pending request supersedes it.
      const taskApprovals = await db.select().from(approvals).where(eq(approvals.taskId, task.id));
      const latestApproval = taskApprovals.sort((a, b) => (b.createdAt?.getTime() ?? 0) - (a.createdAt?.getTime() ?? 0))[0];

      // Deterministic authorization before any execution — the agent cannot authorize itself.
      const decision = await authorize({
        agentId: agent.id,
        workUnitId: wu.id,
        action: actionForKind(task.kind),
        resource: `workunit:${wu.id}`,
        domain: domainForTask(task),
        estimatedCostMicros: (task.input.estimatedCostMicros as number) ?? 0,
        delegationDepth: wu.delegationDepth,
        approvalId: latestApproval?.status === "approved" ? latestApproval.id : undefined,
      });

      if (!decision.allow) {
        if (decision.obligation === "approval") {
          const existing = await db
            .select()
            .from(approvals)
            .where(and(eq(approvals.taskId, task.id), eq(approvals.status, "pending")))
            .limit(1);
          if (!existing[0]) {
            await db.insert(approvals).values({
              id: uid("apr"),
              workUnitId: wu.id,
              taskId: task.id,
              agentId: agent.id,
              action: actionForKind(task.kind),
              resource: `workunit:${wu.id}`,
              reason: `Capability policy requires human authorization for ${actionForKind(task.kind)}.`,
              risk: task.kind === "deploy" || task.kind === "draft" ? "high" : "medium",
            });
            await db.update(tasks).set({ status: "blocked", error: "awaiting human approval" }).where(eq(tasks.id, task.id));
            await db.update(workUnits).set({ status: "awaiting_approval" }).where(eq(workUnits.id, wu.id));
            await emit(wu.id, task.id, "approval.requested", `${actionForKind(task.kind)} escalated to the approval center`);
          }
          blocked += 1;
          continue;
        }
        await db.update(tasks).set({ status: "failed", error: decision.reason, attempts: task.attempts + 1 }).where(eq(tasks.id, task.id));
        await emit(wu.id, task.id, "authority.denied", decision.reason);
        denied += 1;
        continue;
      }

      const tier = selectTier({ ...task, kind: task.kind } as never);
      const estimate = estimateDuration(task, tier.tier);
      await db
        .update(tasks)
        .set({
          status: "running",
          attempts: task.attempts + 1,
          assignedAgentId: agent.id,
          startedAt: new Date(),
          durationMs: estimate,
          waitMs: Math.max(0, Date.now() - (task.createdAt?.getTime() ?? Date.now())),
          modelId: task.needsModel ? task.modelId : null,
        })
        .where(eq(tasks.id, task.id));

      if (tier.tier > 0) await allocateSandbox(tier.tier, tier.flavor);
      await emit(wu.id, task.id, "task.started", `queue ${task.queue} · tier ${tier.tier} (${tier.flavor}) · token ${decision.tokenId ?? "n/a"} · ETA ${estimate}ms`);
      await db.update(agents).set({ status: "active", residentMemoryMb: 42 + noise(18) }).where(eq(agents.id, agent.id));
      started += 1;
    }
  }
  return { started, blocked, denied };
}

function estimateDuration(task: TaskRow, tier: number): number {
  const base = task.needsModel ? 700 + noise(900) : 180 + noise(380);
  return Math.round(base * (1 + tier * 0.25));
}

function domainForTask(task: TaskRow): string | undefined {
  const url = task.input.url as string | undefined;
  if (url) return url.replace(/^https?:\/\//, "").split("/")[0];
  if (task.kind.startsWith("browser.")) return "portal.example";
  return undefined;
}

type AgentRowFull = typeof agents.$inferSelect;

const KIND_DEPARTMENT: [RegExp, string][] = [
  [/^browser\./, "operations"],
  [/^(code\.|sandbox\.|deploy)/, "engineering"],
  [/^(connector\.|classify|route)/, "support"],
  [/^(draft|retrieve)/, "marketing"],
  [/^(verify|verify-claims)/, "quality"],
  [/^(http\.fetch|research|extract|reduce)/, "research"],
];

/**
 * Capability-aware assignment: pick an identity whose role policy actually permits the action.
 * Verification is always routed to a critic that did not produce the work.
 */
async function resolveAgent(task: TaskRow, wu: WorkUnitRow): Promise<AgentRowFull | null> {
  const pool = await db.select().from(agents).where(sql`${agents.status} <> 'suspended'`);
  if (!pool.length) return null;
  const action = actionForKind(task.kind);
  const domain = domainForTask(task);
  const ok = (a: AgentRowFull) => permits(a, action, domain);

  if (task.kind === "verify" || task.kind === "verify-claims") {
    const critics = pool.filter((a) => a.department === "quality" && a.id !== wu.ownerAgentId && ok(a));
    if (critics.length) return critics[0];
  }

  const owner = pool.find((a) => a.id === wu.ownerAgentId);
  if (owner && ok(owner)) return owner;

  const deptRule = KIND_DEPARTMENT.find(([re]) => re.test(task.kind));
  if (deptRule) {
    const byDept = pool.find((a) => a.department === deptRule[1] && ok(a));
    if (byDept) return byDept;
  }

  const anyPermitted = pool.find(ok);
  return anyPermitted ?? owner ?? pool[0] ?? null;
}

/** Mint an operation-scoped capability if this identity does not already hold a live one for the action. */
async function ensureCapability(input: { agentId: string; workUnit: WorkUnitRow; action: string; domain?: string }) {
  const existing = await db
    .select()
    .from(capabilityTokens)
    .where(and(eq(capabilityTokens.agentId, input.agentId), eq(capabilityTokens.workUnitId, input.workUnit.id), eq(capabilityTokens.revoked, false)));
  const live = existing.find((t) => t.expiresAt > new Date() && t.actions.some((a) => a === input.action || a === "*" || a.endsWith("*")));
  if (live) return live.id;
  const remaining = Math.max(10_000, input.workUnit.budgetMicros - input.workUnit.spentMicros);
  const token = await mintCapability({
    agentId: input.agentId,
    workUnitId: input.workUnit.id,
    actions: [input.action, "memory.read"],
    resources: [`workunit:${input.workUnit.id}`],
    domains: input.domain ? [input.domain] : [],
    maxCostMicros: Math.min(remaining, 250_000),
    delegationDepth: input.workUnit.delegationDepth,
    ttlSeconds: 1800,
  });
  return token.id;
}

async function allocateSandbox(tier: number, flavor: string) {
  const rows = await db.select().from(sandboxes).where(eq(sandboxes.tier, tier)).limit(20);
  const free = rows.find((s) => s.state === "sleeping" || s.state === "idle");
  if (free) {
    await db
      .update(sandboxes)
      .set({ state: "running", tasksRun: free.tasksRun + 1, forks: free.forks + (flavor.includes("microvm") ? 1 : 0), lastUsedAt: new Date() })
      .where(eq(sandboxes.id, free.id));
    return free.id;
  }
  if (rows.length >= (tier === 2 ? 4 : 8)) return null; // bounded pool — scale to zero, not to infinity
  const id = uid("sbx");
  await db.insert(sandboxes).values({
    id,
    flavor,
    tier,
    state: "running",
    vcpu: tier === 2 ? 1 : tier === 1 ? 0.0625 : 0.0625,
    memoryMb: tier === 2 ? 128 : 256,
    diskMb: tier === 2 ? 1024 : 2048,
    bootMs: tier === 2 ? 122 : 340,
    networkEgress: tier === 2 ? "denied" : "allowlisted",
    tasksRun: 1,
    forks: flavor.includes("microvm") ? 1 : 0,
  });
  return id;
}

/* ---------------------------------------------------------- completion */

async function finishTask(task: TaskRow): Promise<boolean> {
  const wuRows = await db.select().from(workUnits).where(eq(workUnits.id, task.workUnitId)).limit(1);
  const wu = wuRows[0];
  if (!wu) return false;
  const agentRows = await db.select().from(agents).where(eq(agents.id, task.assignedAgentId ?? wu.ownerAgentId ?? "")).limit(1);
  const agent = agentRows[0];
  if (!agent) {
    await db.update(tasks).set({ status: "failed", error: "no agent identity resolved" }).where(eq(tasks.id, task.id));
    return false;
  }
  const tokenRows = await db.select().from(capabilityTokens).where(eq(capabilityTokens.workUnitId, wu.id)).limit(1);

  try {
    const result = await executeTask({ task, workUnit: wu, agent, tokenId: tokenRows[0]?.id ?? null });

    if (result.requiresApproval && result.approval) {
      const existing = await db.select().from(approvals).where(and(eq(approvals.taskId, task.id), eq(approvals.status, "pending"))).limit(1);
      if (!existing[0]) {
        await db.insert(approvals).values({
          id: uid("apr"),
          workUnitId: wu.id,
          taskId: task.id,
          agentId: agent.id,
          action: result.approval.action,
          resource: result.approval.resource ?? null,
          reason: result.approval.reason,
          risk: result.approval.risk,
        });
        await emit(wu.id, task.id, "approval.requested", `${result.approval.action} — ${result.approval.reason}`);
      }
      await db
        .update(tasks)
        .set({
          status: "blocked",
          error: "awaiting human approval",
          output: result.output,
          tokensIn: result.tokensIn,
          tokensOut: result.tokensOut,
          costMicros: result.costMicros,
          durationMs: result.durationMs,
        })
        .where(eq(tasks.id, task.id));
      await db.update(workUnits).set({ status: "awaiting_approval" }).where(eq(workUnits.id, wu.id));
      return false;
    }

    let artifactId: string | null = null;
    if (result.artifact) {
      artifactId = uid("art");
      const body = result.artifact.body;
      await db.insert(artifacts).values({
        id: artifactId,
        workUnitId: wu.id,
        taskId: task.id,
        title: result.artifact.title,
        kind: result.artifact.kind,
        mime: result.artifact.mime,
        uri: `r2://aos-artifacts/${wu.orgId}/${wu.id}/${artifactId}`,
        bytes: Buffer.byteLength(body),
        checksum: `sha256:${uid("x").replace("x_", "")}${uid("y").replace("y_", "")}`,
        body,
      });
      await emit(wu.id, task.id, "artifact.stored", `${result.artifact.title} → r2://${artifactId} (${Buffer.byteLength(body)} bytes)`);
    }

    if (result.receipt) {
      const existing = await db.select().from(receipts).where(eq(receipts.idempotencyKey, result.receipt.idempotencyKey)).limit(1);
      if (existing[0]) {
        await emit(wu.id, task.id, "side-effect.reconciled", `idempotency key ${result.receipt.idempotencyKey} already committed — replay suppressed`);
      } else {
        await db.insert(receipts).values({
          id: uid("rcp"),
          workUnitId: wu.id,
          taskId: task.id,
          agentId: agent.id,
          action: result.receipt.action,
          externalSystem: result.receipt.externalSystem,
          idempotencyKey: result.receipt.idempotencyKey,
          status: result.receipt.status,
          httpStatus: result.receipt.httpStatus ?? null,
          detail: result.receipt.detail ?? {},
        });
        await emit(wu.id, task.id, "side-effect.committed", `${result.receipt.action} → ${result.receipt.externalSystem}`);
      }
    }

    for (const ev of result.events) await emit(wu.id, task.id, ev.type, ev.detail);
    if (result.injectionFindings?.length) {
      await db.insert(auditLog).values({
        id: uid("aud"),
        actor: agent.id,
        action: "security.injection-blocked",
        subject: task.id,
        result: "blocked",
        severity: "warning",
        detail: { findings: result.injectionFindings },
      });
    }

    await db
      .update(tasks)
      .set({
        status: "done",
        output: result.output,
        artifactId,
        tokensIn: result.tokensIn,
        tokensOut: result.tokensOut,
        costMicros: result.costMicros,
        durationMs: result.durationMs,
        tier: result.tier,
        sandboxId: task.sandboxId,
        browserContextId: result.browserContextId ?? task.browserContextId,
        finishedAt: new Date(),
        error: null,
      })
      .where(eq(tasks.id, task.id));

    await db
      .update(workUnits)
      .set({
        doneCount: sql`${workUnits.doneCount} + 1`,
        spentMicros: sql`${workUnits.spentMicros} + ${result.costMicros}`,
        tokensIn: sql`${workUnits.tokensIn} + ${result.tokensIn}`,
        tokensOut: sql`${workUnits.tokensOut} + ${result.tokensOut}`,
        modelCalls: sql`${workUnits.modelCalls} + ${result.tokensIn > 0 ? 1 : 0}`,
        deterministicSteps: sql`${workUnits.deterministicSteps} + ${result.tokensIn === 0 ? 1 : 0}`,
      })
      .where(eq(workUnits.id, wu.id));

    await db
      .update(organizations)
      .set({ spentCents: sql`${organizations.spentCents} + ${Math.round(result.costMicros / 10000)}` })
      .where(eq(organizations.id, wu.orgId));

    await releaseSandbox(task);
    return true;
  } catch (err) {
    const message = err instanceof Error ? err.message : "execution error";
    if (task.attempts + 1 >= task.maxAttempts) {
      await db.update(tasks).set({ status: "failed", error: message, finishedAt: new Date() }).where(eq(tasks.id, task.id));
      await emit(wu.id, task.id, "task.failed", message);
      return false;
    }
    await db.update(tasks).set({ status: "ready", attempts: task.attempts + 1, error: message }).where(eq(tasks.id, task.id));
    await emit(wu.id, task.id, "task.retry", `attempt ${task.attempts + 1}/${task.maxAttempts} — ${message}`);
    return false;
  }
}

async function releaseSandbox(task: TaskRow) {
  if (task.tier === 0) return;
  const rows = await db.select().from(sandboxes).where(eq(sandboxes.state, "running")).limit(10);
  const victim = rows[rows.length - 1];
  if (victim) await db.update(sandboxes).set({ state: "sleeping" }).where(eq(sandboxes.id, victim.id));
}

async function releaseApprovedTasks(): Promise<number> {
  const approved = await db.select().from(approvals).where(eq(approvals.status, "approved")).limit(50);
  let released = 0;
  for (const approval of approved) {
    if (!approval.taskId) continue;
    const rows = await db.select().from(tasks).where(and(eq(tasks.id, approval.taskId), eq(tasks.status, "blocked"))).limit(1);
    const task = rows[0];
    if (!task) continue;
    const superseded = await db
      .select({ id: approvals.id })
      .from(approvals)
      .where(and(eq(approvals.taskId, approval.taskId), eq(approvals.status, "pending")))
      .limit(1);
    if (superseded[0]) continue; // a newer authorization request supersedes this grant
    await db.update(tasks).set({ status: "ready", error: null }).where(eq(tasks.id, task.id));
    await emit(task.workUnitId, task.id, "approval.granted", `${approval.action} authorized by ${approval.decidedBy ?? "operator"}`);
    released += 1;
  }
  const deniedRows = await db.select().from(approvals).where(eq(approvals.status, "denied")).limit(50);
  for (const approval of deniedRows) {
    if (!approval.taskId) continue;
    const rows = await db.select().from(tasks).where(and(eq(tasks.id, approval.taskId), eq(tasks.status, "blocked"))).limit(1);
    if (!rows[0]) continue;
    await db.update(tasks).set({ status: "skipped", error: `denied by human: ${approval.decisionNote ?? "no note"}` }).where(eq(tasks.id, approval.taskId));
    await emit(rows[0].workUnitId, approval.taskId, "approval.denied", approval.decisionNote ?? "operator denied the action");
  }
  const stillBlocked = await db.select({ id: tasks.id }).from(tasks).where(eq(tasks.status, "blocked"));
  if (!stillBlocked.length) {
    await db.update(workUnits).set({ status: "running" }).where(eq(workUnits.status, "awaiting_approval"));
  }
  return released;
}

async function promoteReadyTasks() {
  const pending = await db.select().from(tasks).where(eq(tasks.status, "pending")).limit(400);
  if (!pending.length) return;
  const byWu = new Map<string, TaskRow[]>();
  for (const t of pending) {
    const list = byWu.get(t.workUnitId) ?? [];
    list.push(t);
    byWu.set(t.workUnitId, list);
  }
  for (const [wuId, list] of byWu) {
    const all = await db.select().from(tasks).where(eq(tasks.workUnitId, wuId));
    const statusByKey = new Map(all.map((t) => [t.key, t.status]));
    const promote = list.filter((t) =>
      t.dependsOn.every((dep) => statusByKey.get(dep) === "done" || statusByKey.get(dep) === "skipped"),
    );
    const failedDeps = list.filter((t) => t.dependsOn.some((dep) => statusByKey.get(dep) === "failed"));
    if (promote.length) {
      await db.update(tasks).set({ status: "ready" }).where(inArray(tasks.id, promote.map((t) => t.id)));
    }
    for (const t of failedDeps) {
      await db.update(tasks).set({ status: "failed", error: "upstream dependency failed" }).where(eq(tasks.id, t.id));
    }
  }
}

/* --------------------------------------------------- work unit lifecycle */

async function advanceWorkUnits() {
  const active = await db.select().from(workUnits).where(inArray(workUnits.status, ["running", "awaiting_approval", "verifying"])).limit(20);
  for (const wu of active) {
    const all = await db.select().from(tasks).where(eq(tasks.workUnitId, wu.id));
    if (!all.length) continue;
    const done = all.filter((t) => t.status === "done").length;
    const failed = all.filter((t) => t.status === "failed").length;
    const running = all.filter((t) => t.status === "running").length;
    const parallelism = running;
    if (parallelism > wu.maxParallelismObserved) {
      await db.update(workUnits).set({ maxParallelismObserved: parallelism }).where(eq(workUnits.id, wu.id));
    }
    await db.update(workUnits).set({ doneCount: done }).where(eq(workUnits.id, wu.id));

    if (failed > 0 && running === 0 && all.every((t) => ["done", "failed", "skipped"].includes(t.status))) {
      await db.update(workUnits).set({ status: "failed", completedAt: new Date() }).where(eq(workUnits.id, wu.id));
      await emit(wu.id, null, "workunit.failed", `${failed} task(s) exhausted retries — durable state preserved for recovery`);
      await recordDelivery(wu, false);
      continue;
    }

    if (all.every((t) => ["done", "skipped"].includes(t.status))) {
      const verify = all.find((t) => t.key === "verify");
      const verdict = (verify?.output as { verdict?: string } | undefined)?.verdict ?? "accepted";
      if (verdict === "rejected") {
        const reworked = all.some((t) => t.key === "rework");
        if (!reworked) {
          await spawnRework(wu, all);
        } else {
          await db.update(workUnits).set({ status: "rejected", completedAt: new Date() }).where(eq(workUnits.id, wu.id));
          await emit(wu.id, null, "workunit.rejected", "second verification pass still fails acceptance criteria");
          await recordDelivery(wu, false);
        }
        continue;
      }
      await db
        .update(workUnits)
        .set({
          status: "completed",
          completedAt: new Date(),
          verification: (verify?.output as never) ?? { verdict: "accepted", score: 100, checks: [] },
        })
        .where(eq(workUnits.id, wu.id));
      await emit(wu.id, null, "workunit.completed", `verified deliverable committed · ${done} tasks · ${formatMicros(wu.spentMicros)}`);
      await recordDelivery(wu, true);
      // Background memory compiler — never in the critical path of a conversation.
      await compileMemory(wu, all).catch(() => undefined);
    }
  }
}

async function spawnRework(wu: WorkUnitRow, all: TaskRow[]) {
  const gaps = ((all.find((t) => t.key === "verify")?.output as { gaps?: string[] } | undefined)?.gaps ?? []).slice(0, 2);
  const reduceTask = all.find((t) => t.key === "reduce");
  const reworkId = uid("tsk");
  await db.insert(tasks).values({
    id: reworkId,
    workUnitId: wu.id,
    key: "rework",
    title: `Rework: address ${gaps.length || 1} verification gap(s)`,
    kind: "reduce",
    queue: "io",
    tier: 0,
    status: "ready",
    dependsOn: [],
    assignedAgentId: reduceTask?.assignedAgentId ?? wu.ownerAgentId,
    needsModel: true,
    input: { gaps, intelligence: "synthesis", rework: true, compactReferences: true },
    idempotencyKey: `${wu.id}:rework`,
    maxAttempts: 2,
  });
  const verifyTask = all.find((t) => t.key === "verify");
  const commitTask = all.find((t) => t.key === "commit");
  if (verifyTask) await db.update(tasks).set({ status: "pending", dependsOn: ["rework"], output: {} }).where(eq(tasks.id, verifyTask.id));
  if (commitTask) await db.update(tasks).set({ status: "pending", output: {} }).where(eq(tasks.id, commitTask.id));
  await db.update(workUnits).set({ status: "verifying", taskCount: sql`${workUnits.taskCount} + 1` }).where(eq(workUnits.id, wu.id));
  await emit(wu.id, reworkId, "verify.rework", `critic rejected the deliverable — gaps: ${gaps.join("; ") || "unspecified"}`);
}

async function recordDelivery(wu: typeof workUnits.$inferSelect, accepted: boolean) {
  if (!wu.ownerAgentId) return;
  await db
    .update(agents)
    .set({
      completedWorkUnits: sql`${agents.completedWorkUnits} + 1`,
      acceptedDeliverables: sql`${agents.acceptedDeliverables} + ${accepted ? 1 : 0}`,
      rejectedDeliverables: sql`${agents.rejectedDeliverables} + ${accepted ? 0 : 1}`,
      spentCents: sql`${agents.spentCents} + ${Math.round(wu.spentMicros / 10000)}`,
    })
    .where(eq(agents.id, wu.ownerAgentId));
}

/* ------------------------------------------------------ session lifecycle */

async function manageSessions(hibernateAfterSec: number) {
  let hibernated = 0;
  let evicted = 0;
  const cutoff = new Date(Date.now() - hibernateAfterSec * 1000);
  const idle = await db
    .select()
    .from(sessions)
    .where(and(eq(sessions.state, "resident"), sql`${sessions.lastActiveAt} < ${cutoff}`))
    .limit(400);
  for (const s of idle) {
    await db
      .update(sessions)
      .set({
        state: "hibernated",
        residentMemoryMb: 0,
        hibernatedAt: new Date(),
        hibernations: s.hibernations + 1,
        pendingToolCalls: 0,
      })
      .where(eq(sessions.id, s.id));
    hibernated += 1;
  }
  // Simulate platform eviction of a few hibernated actors — durable state survives.
  const hibernatedRows = await db.select().from(sessions).where(eq(sessions.state, "hibernated")).limit(200);
  const toEvict = hibernatedRows.filter(() => noise(1) > 0.965).slice(0, 12);
  for (const s of toEvict) {
    await db.update(sessions).set({ state: "evicted", residentMemoryMb: 0, evictions: s.evictions + 1 }).where(eq(sessions.id, s.id));
    evicted += 1;
  }
  // Agents with no resident session return to a hibernating identity (storage, not compute).
  const activeAgents = await db.select().from(agents).where(eq(agents.status, "active"));
  for (const agent of activeAgents) {
    const running = await db
      .select({ id: tasks.id })
      .from(tasks)
      .where(and(eq(tasks.assignedAgentId, agent.id), eq(tasks.status, "running")))
      .limit(1);
    const resident = await db
      .select({ id: sessions.id })
      .from(sessions)
      .where(and(eq(sessions.agentId, agent.id), eq(sessions.state, "resident")))
      .limit(1);
    if (!running[0] && !resident[0]) {
      await db.update(agents).set({ status: "hibernating", residentMemoryMb: 0 }).where(eq(agents.id, agent.id));
    }
  }
  return { hibernated, evicted };
}

export async function wakeSession(sessionId: string, reason = "inbound message") {
  const rows = await db.select().from(sessions).where(eq(sessions.id, sessionId)).limit(1);
  const session = rows[0];
  if (!session) return null;
  const wasEvicted = session.state === "evicted";
  const memoryMb = 38 + noise(26);
  await db
    .update(sessions)
    .set({
      state: "resident",
      residentMemoryMb: memoryMb,
      lastActiveAt: new Date(),
      hibernatedAt: null,
      wakes: session.wakes + 1,
      recoveries: session.recoveries + (wasEvicted ? 1 : 0),
    })
    .where(eq(sessions.id, sessionId));
  await db.update(agents).set({ status: "active", residentMemoryMb: memoryMb }).where(eq(agents.id, session.agentId));
  return { session, wasEvicted, memoryMb, reason };
}

export async function hibernateSession(sessionId: string) {
  const rows = await db.select().from(sessions).where(eq(sessions.id, sessionId)).limit(1);
  if (!rows[0]) return null;
  await db
    .update(sessions)
    .set({ state: "hibernated", residentMemoryMb: 0, hibernatedAt: new Date(), hibernations: rows[0].hibernations + 1 })
    .where(eq(sessions.id, sessionId));
  return rows[0];
}

/* ---------------------------------------------------- adaptive scheduler */

function allowedConcurrency(sched: SchedulerRow): Record<QueueName, number> {
  const out = {} as Record<QueueName, number>;
  for (const q of QUEUES) {
    out[q] = Math.max(0, Math.min(sched.limits.provider, sched.limits.tenant, sched.limits.queue, sched.limits.sandbox, sched.limits.budget, sched.concurrency[q].limit));
  }
  return out;
}

async function adapt(sched: SchedulerRow) {
  const decisions: string[] = [];
  const recent = await db
    .select()
    .from(tasks)
    .where(sql`${tasks.finishedAt} > NOW() - INTERVAL '90 seconds'`)
    .limit(500);
  const durations = recent.map((t) => t.durationMs).filter((d) => d > 0);
  const waits = recent.map((t) => t.waitMs);
  const p95 = percentile(durations, 95);
  const queueWait = percentile(waits, 95);
  const errorRate = recent.length ? recent.filter((t) => t.status === "failed").length / recent.length : 0;
  const modelRows = await db.select().from(models);
  const provider429Total = modelRows.reduce((a, m) => a + m.rateLimited, 0);
  const previousTotal = (sched.signals as { provider429Total?: number }).provider429Total ?? provider429Total;
  const recent429 = Math.max(0, provider429Total - previousTotal);
  const provider429 = recent429;
  const pendingCount = (
    await db.select({ n: sql<number>`count(*)::int` }).from(tasks).where(inArray(tasks.status, ["pending", "ready"]))
  )[0]?.n ?? 0;
  const browserRows = await db.select().from(browserSessions);
  const browserMem = browserRows.reduce((a, b) => a + b.processMemoryMb, 0);
  const sbxRows = await db.select().from(sandboxes);
  const sandboxUtil = sbxRows.length ? sbxRows.filter((s) => s.state === "running").length / sbxRows.length : 0;
  const orgRows = await db.select().from(organizations);
  const budgetUtil = orgRows.length ? orgRows[0].spentCents / Math.max(1, orgRows[0].budgetCents) : 0;
  const dbWritesPerTask = recent.length ? (await countEvents()) / Math.max(1, recent.length) : 0;

  const concurrency = { ...sched.concurrency };
  const limits = { ...sched.limits };

  // I/O queue: scale up while providers are healthy, back off on recent 429s, decay when idle.
  const io = { ...concurrency.io };
  if (recent429 > 3 || errorRate > 0.25) {
    io.limit = clamp(Math.round(io.limit * 0.7), 8, 96);
    decisions.push(`io concurrency ↓ ${io.limit} (recent provider 429s=${recent429}, error rate ${(errorRate * 100).toFixed(1)}%)`);
  } else if (queueWait > 1200 && pendingCount > io.limit) {
    io.limit = clamp(io.limit + 6, 8, 96);
    decisions.push(`io concurrency ↑ ${io.limit} (p95 queue wait ${Math.round(queueWait)}ms, ${pendingCount} tasks waiting, providers healthy)`);
  } else if (queueWait < 300 && io.limit > 48) {
    io.limit = clamp(io.limit - 4, 8, 96);
    decisions.push(`io concurrency ↓ ${io.limit} (queue drained, releasing capacity)`);
  }
  io.p95Ms = Math.round(p95);
  concurrency.io = io;

  // Browser queue: memory-aware, never exceed the ceiling.
  const br = { ...concurrency.browser };
  if (browserMem > limits.browserMemoryMb * 0.8) {
    br.limit = clamp(br.limit - 1, 1, 24);
    decisions.push(`browser concurrency ↓ ${br.limit} (pool memory ${Math.round(browserMem)} MiB near ceiling ${limits.browserMemoryMb} MiB)`);
  } else if (browserMem < limits.browserMemoryMb * 0.4 && queueWait > 400) {
    br.limit = clamp(br.limit + 1, 1, 24);
    decisions.push(`browser concurrency ↑ ${br.limit} (pool memory headroom recovered)`);
  }
  concurrency.browser = br;

  // Compute queue: bound by sandbox utilization.
  const cp = { ...concurrency.compute };
  if (sandboxUtil > 0.85) {
    cp.limit = clamp(cp.limit - 2, 2, 64);
    decisions.push(`compute concurrency ↓ ${cp.limit} (sandbox utilization ${(sandboxUtil * 100).toFixed(0)}%)`);
  } else if (sandboxUtil < 0.5) {
    cp.limit = clamp(cp.limit + 2, 2, 64);
  }
  concurrency.compute = cp;

  // Interactive queue always keeps the lowest latency; weighted fair scheduling on budget pressure.
  const it = { ...concurrency.interactive };
  it.limit = budgetUtil > 0.9 ? clamp(it.limit - 1, 2, 32) : clamp(it.limit + (queueWait > 800 ? 1 : 0), 2, 32);
  if (budgetUtil > 0.9) decisions.push(`tenant budget ${(budgetUtil * 100).toFixed(0)}% consumed — weighted fair scheduling throttles bulk queues first`);
  concurrency.interactive = it;

  limits.budget = budgetUtil > 0.95 ? 8 : budgetUtil > 0.8 ? 24 : 48;
  limits.provider = Math.max(8, 64 - Math.min(48, provider429 * 2));
  limits.sandbox = clamp(Math.round(8 + (1 - sandboxUtil) * 24), 4, 32);

  return {
    concurrency,
    limits,
    signals: {
      queueWaitMs: Math.round(queueWait),
      p95Ms: Math.round(p95),
      errorRate: Math.round(errorRate * 1000) / 1000,
      provider429,
      provider429Total,
      dbWritesPerTask: Math.round(dbWritesPerTask * 10) / 10,
      sandboxUtil: Math.round(sandboxUtil * 100) / 100,
      browserMemMb: Math.round(browserMem),
      budgetUtil: Math.round(budgetUtil * 1000) / 1000,
    },
    decisions,
  };
}

async function countEvents(): Promise<number> {
  const rows = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(taskEvents)
    .where(sql`${taskEvents.at} > NOW() - INTERVAL '90 seconds'`);
  return rows[0]?.n ?? 0;
}

/* ----------------------------------------------------------- footprints */

export async function computeFootprint() {
  const sessionRows = await db.select().from(sessions);
  const runningTasks = await db.select().from(tasks).where(eq(tasks.status, "running"));
  const browserRows = await db.select().from(browserSessions);
  const sandboxRows = await db.select().from(sandboxes).where(eq(sandboxes.state, "running"));
  const residentSessions = sessionRows.filter((s) => s.state === "resident");
  const sessionMemory = residentSessions.reduce((a, s) => a + s.residentMemoryMb, 0);
  const taskMemory = runningTasks.reduce((a, t) => a + (t.tier === 2 ? 128 : t.tier === 1 ? 256 : 8), 0);
  const browserMemory = browserRows.reduce((a, b) => a + b.processMemoryMb, 0);
  const sandboxMemory = sandboxRows.reduce((a, s) => a + s.memoryMb, 0);
  return {
    logicalSessions: sessionRows.length,
    residentSessions: residentSessions.length,
    hibernatedSessions: sessionRows.filter((s) => s.state === "hibernated").length,
    evictedSessions: sessionRows.filter((s) => s.state === "evicted").length,
    runningTasks: runningTasks.length,
    pendingTasks: (await db.select({ n: sql<number>`count(*)::int` }).from(tasks).where(inArray(tasks.status, ["pending", "ready", "blocked"])))[0]?.n ?? 0,
    sessionMemoryMb: Math.round(sessionMemory),
    taskMemoryMb: Math.round(taskMemory),
    browserMemoryMb: Math.round(browserMemory),
    sandboxMemoryMb: Math.round(sandboxMemory),
    residentMemoryMb: Math.round(sessionMemory + taskMemory + browserMemory + sandboxMemory),
    idleCostPerSessionMb: 0,
    naiveFootprintMb: sessionRows.length * 512 + browserRows.length * 1024,
  };
}

async function computeTotals() {
  const done = await db
    .select({
      n: sql<number>`count(*)::int`,
      cost: sql<number>`coalesce(sum(cost_micros),0)::int`,
      tin: sql<number>`coalesce(sum(tokens_in),0)::int`,
      tout: sql<number>`coalesce(sum(tokens_out),0)::int`,
    })
    .from(tasks)
    .where(eq(tasks.status, "done"));
  const failed = await db.select({ n: sql<number>`count(*)::int` }).from(tasks).where(eq(tasks.status, "failed"));
  const sideEffects = await db.select({ n: sql<number>`count(*)::int` }).from(receipts);
  const accepted = await db.select({ n: sql<number>`count(*)::int` }).from(workUnits).where(eq(workUnits.status, "completed"));
  const rejected = await db.select({ n: sql<number>`count(*)::int` }).from(workUnits).where(inArray(workUnits.status, ["rejected", "failed"]));
  const deterministic = await db.select({ n: sql<number>`count(*)::int` }).from(tasks).where(and(eq(tasks.status, "done"), eq(tasks.needsModel, false)));
  const modelCallsRows = await db.select({ n: sql<number>`coalesce(sum(calls),0)::int` }).from(models);
  const blocked = await db.select({ n: sql<number>`count(*)::int` }).from(auditLog).where(eq(auditLog.result, "denied"));
  const injections = await db.select({ n: sql<number>`count(*)::int` }).from(auditLog).where(eq(auditLog.action, "security.injection-blocked"));
  const windowStart = Date.now() - 60_000;
  const recentDone = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(tasks)
    .where(and(eq(tasks.status, "done"), sql`${tasks.finishedAt} > ${new Date(windowStart)}`));
  return {
    tasksCompleted: done[0]?.n ?? 0,
    tasksFailed: failed[0]?.n ?? 0,
    modelCalls: modelCallsRows[0]?.n ?? 0,
    deterministicSteps: deterministic[0]?.n ?? 0,
    tokensIn: done[0]?.tin ?? 0,
    tokensOut: done[0]?.tout ?? 0,
    costMicros: done[0]?.cost ?? 0,
    sideEffects: sideEffects[0]?.n ?? 0,
    deliverablesAccepted: accepted[0]?.n ?? 0,
    deliverablesRejected: rejected[0]?.n ?? 0,
    unauthorizedBlocked: blocked[0]?.n ?? 0,
    injectionsBlocked: injections[0]?.n ?? 0,
    throughputPerSec: Math.round(((recentDone[0]?.n ?? 0) / 60) * 100) / 100,
    costPerDeliverableMicros: accepted[0]?.n ? Math.round((done[0]?.cost ?? 0) / accepted[0].n) : 0,
  };
}

/* -------------------------------------------------------------- helpers */

export async function emit(workUnitId: string, taskId: string | null, type: string, detail: string) {
  await db.insert(taskEvents).values({ id: uid("evt"), workUnitId, taskId, type, detail });
}

/** Failure injection: a worker disappears mid-task. Durable state must survive. */
export async function injectFailure(mode: "worker" | "browser" | "duplicate" = "worker") {
  if (mode === "worker") {
    const running = await db.select().from(tasks).where(eq(tasks.status, "running")).orderBy(desc(tasks.startedAt)).limit(1);
    const task = running[0];
    if (!task) return { injected: false, reason: "no running task to kill" };
    const recoverable = task.attempts < task.maxAttempts;
    await db
      .update(tasks)
      .set({
        status: recoverable ? "ready" : "failed",
        error: recoverable ? null : "worker disappeared; retries exhausted",
        startedAt: null,
      })
      .where(eq(tasks.id, task.id));
    await emit(task.workUnitId, task.id, "failure.worker-lost", recoverable ? "task re-queued from durable state — no work unit lost" : "retries exhausted, work unit marked failed");
    const existingReceipt = await db.select().from(receipts).where(eq(receipts.taskId, task.id)).limit(1);
    if (existingReceipt[0]) {
      await db.update(receipts).set({ replayed: true }).where(eq(receipts.id, existingReceipt[0].id));
      await emit(task.workUnitId, task.id, "side-effect.reconciled", `idempotency key ${existingReceipt[0].idempotencyKey} matched — external action not repeated`);
    }
    return { injected: true, mode, taskId: task.id, recoverable, reconciled: Boolean(existingReceipt[0]) };
  }
  if (mode === "browser") {
    const browsers = await db.select().from(browserSessions).limit(1);
    const b = browsers[0];
    if (!b) return { injected: false, reason: "no browser process" };
    await db.update(browserSessions).set({ crashes: b.crashes + 1, state: "ready", tabCount: 0, processMemoryMb: 190 }).where(eq(browserSessions.id, b.id));
    await db.insert(auditLog).values({
      id: uid("aud"),
      actor: b.id,
      action: "failure.browser-crash",
      subject: b.label,
      result: "recovered",
      severity: "warning",
      detail: { recycled: true, contextsLost: b.contextCount },
    });
    return { injected: true, mode, browserId: b.id, note: "process recycled; contexts reopened from durable cookies" };
  }
  const lastEvent = await db.select().from(taskEvents).orderBy(desc(taskEvents.at)).limit(1);
  return { injected: true, mode, duplicated: lastEvent[0]?.id ?? null, note: "duplicate event delivered; idempotency key suppressed the second side effect" };
}

export async function setSchedulerRunning(running: boolean) {
  await db.update(schedulerState).set({ running }).where(eq(schedulerState.id, SCHEDULER_ID));
}

export async function resetEngine() {
  await db.delete(metricsSamples);
  await db.delete(taskEvents);
  await db.delete(receipts);
  await db.delete(artifacts);
  await db.delete(approvals);
  await db.delete(capabilityTokens);
  await db.delete(tasks);
  await db.delete(workUnits);
  await db.delete(sessionMessages);
  await db.delete(sessions);
  await db.delete(auditLog);
  await db.update(models).set({ calls: 0, rateLimited: 0, cachedHits: 0, inFlight: 0 });
  await db.update(organizations).set({ spentCents: 0 });
  await db.update(agents).set({ status: "hibernating", residentMemoryMb: 0, completedWorkUnits: 0, acceptedDeliverables: 0, rejectedDeliverables: 0, spentCents: 0 });
  await db.delete(schedulerState).where(eq(schedulerState.id, SCHEDULER_ID));
  await db.update(browserSessions).set({ tabCount: 0, processMemoryMb: 190, state: "ready", crashes: 0, recycles: 0 });
  return { ok: true };
}

export { isNull };
