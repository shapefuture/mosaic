import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  agents,
  browserContexts,
  browserSessions,
  connectors,
  deliverySlices,
  memories,
  models,
  organizations,
  sandboxes,
  schedules,
  sessions,
} from "@/db/schema";
import { ensurePool } from "./browser";
import { embed, uid } from "./util";

/** Idempotent bootstrap: identity records, catalogs and pools. No per-agent processes. */
export async function seedIfEmpty(): Promise<{ seeded: boolean }> {
  const count = await db.select({ n: sql<number>`count(*)::int` }).from(organizations);
  if ((count[0]?.n ?? 0) > 0) return { seeded: false };

  const orgId = "org_northwind";
  await db.insert(organizations).values({
    id: orgId,
    name: "Northwind Intelligence",
    slug: "northwind",
    budgetCents: 250000,
    fairnessWeight: 1,
  });

  const agentDefs = [
    {
      name: "Aria Vale",
      role: "Market Research Analyst",
      department: "research",
      capabilities: ["http.get", "research", "extract", "data.write"],
      policy: { planning: "reasoning", extraction: "fast", synthesis: "balanced", vision: "vision", coding: "coding" },
      authority: {
        actions: ["http.get", "data.write", "memory.read", "workunit.plan", "workunit.commit"],
        resources: ["project:market-intelligence", "workunit:*"],
        domains: ["*.example", "analyst.example"],
        maxCostMicros: 400000,
        maxDelegationDepth: 2,
        requiresApproval: ["message.send", "deploy.preview"],
      },
      skills: [{ name: "source-triangulation", version: "2.1.0", source: "curated", verified: true }],
    },
    {
      name: "Bram Ostrowski",
      role: "Competitive Pricing Specialist",
      department: "research",
      capabilities: ["http.get", "extract", "csv.transform", "data.write"],
      policy: { planning: "balanced", extraction: "fast", synthesis: "balanced", vision: "vision", coding: "coding" },
      authority: {
        actions: ["http.get", "data.write", "compute.run", "memory.read"],
        resources: ["project:pricing", "workunit:*"],
        domains: ["vendor.example", "reviews.example"],
        maxCostMicros: 250000,
        maxDelegationDepth: 1,
        requiresApproval: ["message.send"],
      },
      skills: [{ name: "price-normalisation", version: "1.4.2", source: "compiled", verified: true }],
    },
    {
      name: "Cleo Marchetti",
      role: "Verification Critic",
      department: "quality",
      capabilities: ["verification", "data.write", "memory.read"],
      policy: { planning: "reasoning", extraction: "balanced", synthesis: "reasoning", vision: "vision", coding: "coding" },
      authority: {
        actions: ["data.write", "memory.read", "workunit.commit"],
        resources: ["workunit:*"],
        domains: [],
        maxCostMicros: 200000,
        maxDelegationDepth: 0,
        requiresApproval: [],
      },
      skills: [
        { name: "blind-comparison", version: "3.0.1", source: "curated", verified: true },
        { name: "acceptance-criteria-audit", version: "1.2.0", source: "compiled", verified: true },
      ],
    },
    {
      name: "Dmitri Kane",
      role: "Software Engineer",
      department: "engineering",
      capabilities: ["sandbox.exec", "code", "compute.run", "data.write"],
      policy: { planning: "reasoning", extraction: "fast", synthesis: "balanced", vision: "vision", coding: "coding" },
      authority: {
        actions: ["sandbox.exec", "compute.run", "data.write", "http.get"],
        resources: ["repo:*", "workunit:*"],
        domains: ["registry.npmjs.org"],
        maxCostMicros: 900000,
        maxDelegationDepth: 2,
        requiresApproval: ["deploy.preview"],
      },
      skills: [{ name: "cow-workspace-fork", version: "1.0.3", source: "compiled", verified: true }],
    },
    {
      name: "Esi Boateng",
      role: "Browser Operations Agent",
      department: "operations",
      capabilities: ["browser", "http.get", "data.write"],
      policy: { planning: "balanced", extraction: "fast", synthesis: "balanced", vision: "vision", coding: "coding" },
      authority: {
        actions: ["browser.session", "browser.read", "browser.write", "browser.login", "data.write"],
        resources: ["browser:*", "workunit:*"],
        domains: ["portal.example", "supplier.example"],
        maxCostMicros: 300000,
        maxDelegationDepth: 1,
        requiresApproval: ["browser.login", "browser.live-view"],
      },
      skills: [
        { name: "playwright-cdp-flows", version: "4.2.0", source: "curated", verified: true },
        { name: "stagehand-fallback", version: "0.9.1", source: "experimental", verified: false },
      ],
    },
    {
      name: "Farid Nazari",
      role: "Inbound Triage Operator",
      department: "support",
      capabilities: ["connector.read", "classify", "route", "data.write"],
      policy: { planning: "fast", extraction: "fast", synthesis: "balanced", vision: "vision", coding: "coding" },
      authority: {
        actions: ["connector.read", "data.write", "compute.run", "memory.read"],
        resources: ["inbox:*", "crm:*"],
        domains: [],
        maxCostMicros: 120000,
        maxDelegationDepth: 1,
        requiresApproval: ["message.send"],
      },
      skills: [{ name: "routing-table-v4", version: "4.0.0", source: "curated", verified: true }],
    },
    {
      name: "Greta Lund",
      role: "Content Strategist",
      department: "marketing",
      capabilities: ["draft", "retrieve", "data.write", "memory.read"],
      policy: { planning: "balanced", extraction: "fast", synthesis: "reasoning", vision: "vision", coding: "coding" },
      authority: {
        actions: ["memory.read", "data.write", "http.get"],
        resources: ["brand:*", "workunit:*"],
        domains: ["*.example"],
        maxCostMicros: 250000,
        maxDelegationDepth: 1,
        requiresApproval: ["message.send"],
      },
      skills: [{ name: "brand-voice-v2", version: "2.0.4", source: "curated", verified: true }],
    },
    {
      name: "Hugo Almeida",
      role: "Operations Planner",
      department: "operations",
      capabilities: ["workunit.plan", "data.write", "memory.read", "connector.read"],
      policy: { planning: "reasoning", extraction: "fast", synthesis: "balanced", vision: "vision", coding: "coding" },
      authority: {
        actions: ["workunit.plan", "workunit.commit", "data.write", "memory.read", "connector.read"],
        resources: ["project:*", "workunit:*"],
        domains: ["*.example"],
        maxCostMicros: 500000,
        maxDelegationDepth: 3,
        requiresApproval: ["deploy.preview", "message.send"],
      },
      skills: [{ name: "bounded-fanout-planner", version: "2.2.0", source: "compiled", verified: true }],
    },
    {
      name: "Ivy Sørensen",
      role: "Security Steward",
      department: "governance",
      capabilities: ["audit", "data.write", "memory.read"],
      policy: { planning: "balanced", extraction: "fast", synthesis: "balanced", vision: "vision", coding: "coding" },
      authority: {
        actions: ["audit.read", "data.write", "memory.read"],
        resources: ["audit:*", "policy:*"],
        domains: [],
        maxCostMicros: 100000,
        maxDelegationDepth: 0,
        requiresApproval: [],
      },
      skills: [{ name: "injection-red-team", version: "1.6.0", source: "curated", verified: true }],
    },
    {
      name: "Jonas Weber",
      role: "Finance Analyst",
      department: "finance",
      capabilities: ["connector.read", "extract", "data.write"],
      policy: { planning: "balanced", extraction: "fast", synthesis: "balanced", vision: "vision", coding: "coding" },
      authority: {
        actions: ["connector.read", "data.write", "compute.run"],
        resources: ["ledger:*", "invoice:*"],
        domains: ["billing.example"],
        maxCostMicros: 150000,
        maxDelegationDepth: 1,
        requiresApproval: ["payment.execute"],
      },
      skills: [{ name: "cost-per-deliverable", version: "1.1.0", source: "compiled", verified: true }],
    },
  ];

  const agentIds: string[] = [];
  for (const def of agentDefs) {
    const id = `agt_${def.name.split(" ")[0].toLowerCase()}_${uid("x").slice(2, 6)}`;
    agentIds.push(id);
    await db.insert(agents).values({
      id,
      orgId,
      name: def.name,
      role: def.role,
      department: def.department,
      reportsTo: null,
      capabilities: def.capabilities,
      skills: def.skills,
      modelPolicy: def.policy as never,
      authorityPolicy: def.authority as never,
      memoryScope: def.department === "quality" ? "org" : "agent",
      budgetCents: 5000,
      status: "hibernating",
      residentMemoryMb: 0,
    });
  }
  // Org chart: the planner reports to nobody, specialists report to the planner.
  await db.update(agents).set({ reportsTo: agentIds[7] }).where(sql`${agents.department} <> 'operations'`);

  /**
   * Role policies are deliberately broad enough for the department's own work and nothing more.
   * Least privilege is still enforced per operation by the capability token minted at dispatch.
   */
  const DEPARTMENT_POLICY: Record<string, { actions: string[]; domains: string[]; maxCostMicros: number; maxDelegationDepth: number; requiresApproval: string[] }> = {
    research: { actions: ["http.get", "data.write", "memory.read", "compute.run", "workunit.plan", "workunit.commit"], domains: ["*.example"], maxCostMicros: 400000, maxDelegationDepth: 2, requiresApproval: ["message.send"] },
    quality: { actions: ["data.write", "memory.read", "audit.read", "workunit.commit"], domains: [], maxCostMicros: 200000, maxDelegationDepth: 0, requiresApproval: [] },
    engineering: { actions: ["sandbox.exec", "compute.run", "data.write", "http.get", "workunit.commit", "deploy.preview"], domains: ["registry.npmjs.org", "*.example"], maxCostMicros: 900000, maxDelegationDepth: 2, requiresApproval: ["deploy.preview"] },
    operations: { actions: ["browser.session", "browser.read", "browser.write", "browser.login", "http.get", "data.write", "compute.run", "memory.read", "workunit.plan", "workunit.commit"], domains: ["portal.example", "supplier.example", "*.example"], maxCostMicros: 500000, maxDelegationDepth: 3, requiresApproval: ["browser.login", "browser.live-view", "deploy.preview"] },
    support: { actions: ["connector.read", "data.write", "compute.run", "memory.read", "message.send", "workunit.commit", "workunit.plan"], domains: [], maxCostMicros: 200000, maxDelegationDepth: 1, requiresApproval: ["message.send"] },
    marketing: { actions: ["memory.read", "data.write", "http.get", "compute.run", "message.send", "workunit.commit", "workunit.plan"], domains: ["*.example"], maxCostMicros: 300000, maxDelegationDepth: 1, requiresApproval: ["message.send"] },
    governance: { actions: ["audit.read", "data.write", "memory.read", "workunit.commit"], domains: [], maxCostMicros: 150000, maxDelegationDepth: 0, requiresApproval: [] },
    finance: { actions: ["connector.read", "data.write", "compute.run", "memory.read", "workunit.commit"], domains: ["billing.example", "*.example"], maxCostMicros: 250000, maxDelegationDepth: 1, requiresApproval: ["payment.execute", "message.send"] },
  };
  for (const [dept, policy] of Object.entries(DEPARTMENT_POLICY)) {
    const deptAgents = await db.select().from(agents).where(eq(agents.department, dept));
    for (const row of deptAgents) {
      await db
        .update(agents)
        .set({
          authorityPolicy: {
            actions: policy.actions,
            resources: Array.from(new Set([...row.authorityPolicy.resources, "workunit:*", "project:*", "session:*", "memory:*"])),
            domains: policy.domains,
            maxCostMicros: Math.max(row.authorityPolicy.maxCostMicros, policy.maxCostMicros),
            maxDelegationDepth: policy.maxDelegationDepth,
            requiresApproval: policy.requiresApproval,
          } as never,
        })
        .where(eq(agents.id, row.id));
    }
  }

  await db.insert(models).values([
    { id: "mdl_fast", provider: "workers-ai", name: "nimbus-flash-8b", tier: "fast", costPer1kIn: 0.00008, costPer1kOut: 0.00016, latencyMs: 260, contextWindow: 32000, concurrencyLimit: 64 },
    { id: "mdl_balanced", provider: "ai-gateway", name: "atlas-balanced-70b", tier: "balanced", costPer1kIn: 0.0006, costPer1kOut: 0.0018, latencyMs: 720, contextWindow: 200000, concurrencyLimit: 32 },
    { id: "mdl_reasoning", provider: "ai-gateway", name: "atlas-reasoning-xl", tier: "reasoning", costPer1kIn: 0.003, costPer1kOut: 0.012, latencyMs: 1800, contextWindow: 200000, concurrencyLimit: 12 },
    { id: "mdl_coding", provider: "ai-gateway", name: "forge-code-32b", tier: "coding", costPer1kIn: 0.0012, costPer1kOut: 0.004, latencyMs: 950, contextWindow: 128000, concurrencyLimit: 16 },
    { id: "mdl_vision", provider: "ai-gateway", name: "lumen-vision-7b", tier: "vision", costPer1kIn: 0.002, costPer1kOut: 0.006, latencyMs: 1100, contextWindow: 64000, concurrencyLimit: 8 },
    { id: "mdl_local", provider: "self-hosted/vllm", name: "qwen-dense-14b (paged-attention)", tier: "balanced", costPer1kIn: 0.0002, costPer1kOut: 0.0005, latencyMs: 480, contextWindow: 64000, concurrencyLimit: 24, enabled: false },
  ]);

  await db.insert(connectors).values([
    { id: "con_gmail", provider: "Google Workspace", identity: "gmail", category: "communication", protocol: "typed-api", authType: "oauth2", supportedActions: ["message.read", "message.send", "label.write"], permissionSchema: ["mailbox.readonly", "mailbox.send"], rateLimitRps: 20, approvalRequired: true, eventSubscriptions: ["message.received"], health: "healthy", docs: "https://developers.google.com/gmail/api" },
    { id: "con_slack", provider: "Slack", identity: "slack", category: "communication", protocol: "typed-api", authType: "oauth2", supportedActions: ["channel.post", "channel.read", "user.dm"], permissionSchema: ["chat:write", "channels:read"], rateLimitRps: 30, approvalRequired: true, eventSubscriptions: ["message.posted", "reaction.added"], health: "healthy", docs: "https://api.slack.com" },
    { id: "con_notion", provider: "Notion", identity: "notion", category: "knowledge", protocol: "mcp", authType: "integration-token", supportedActions: ["page.read", "page.write", "database.query"], permissionSchema: ["content.read", "content.write"], rateLimitRps: 12, approvalRequired: false, eventSubscriptions: ["page.updated"], health: "healthy", docs: "https://developers.notion.com" },
    { id: "con_hubspot", provider: "HubSpot", identity: "crm", category: "revenue", protocol: "openapi", authType: "private-app", supportedActions: ["contact.read", "contact.write", "deal.write"], permissionSchema: ["crm.objects.contacts.read", "crm.objects.deals.write"], rateLimitRps: 15, approvalRequired: true, eventSubscriptions: ["deal.stage.changed"], health: "degraded", docs: "https://developers.hubspot.com" },
    { id: "con_stripe", provider: "Stripe", identity: "billing", category: "finance", protocol: "typed-api", authType: "restricted-key", supportedActions: ["invoice.read", "subscription.read", "refund.execute"], permissionSchema: ["invoices:read", "refunds:write"], rateLimitRps: 40, approvalRequired: true, eventSubscriptions: ["invoice.paid"], health: "healthy", docs: "https://stripe.com/docs/api" },
    { id: "con_github", provider: "GitHub", identity: "source-control", category: "engineering", protocol: "typed-api", authType: "fine-grained-pat", supportedActions: ["repo.read", "pr.write", "workflow.dispatch"], permissionSchema: ["contents:write", "pull_requests:write"], rateLimitRps: 25, approvalRequired: false, eventSubscriptions: ["push", "pull_request.opened"], health: "healthy", docs: "https://docs.github.com/rest" },
    { id: "con_jira", provider: "Atlassian", identity: "issue-tracker", category: "engineering", protocol: "openapi", authType: "oauth2", supportedActions: ["issue.read", "issue.write", "board.read"], permissionSchema: ["manage:jira-issue"], rateLimitRps: 10, approvalRequired: false, eventSubscriptions: ["issue.updated"], health: "healthy", docs: "https://developer.atlassian.com" },
    { id: "con_snowflake", provider: "Snowflake", identity: "warehouse", category: "data", protocol: "typed-api", authType: "keypair-jwt", supportedActions: ["query.run", "table.read"], permissionSchema: ["USAGE", "SELECT"], rateLimitRps: 8, approvalRequired: false, eventSubscriptions: [], health: "healthy", docs: "https://docs.snowflake.com" },
    { id: "con_figma", provider: "Figma", identity: "design", category: "product", protocol: "mcp", authType: "oauth2", supportedActions: ["file.read", "comment.write"], permissionSchema: ["file_content:read"], rateLimitRps: 6, approvalRequired: false, eventSubscriptions: ["comment.created"], health: "healthy", docs: "https://www.figma.com/developers/api" },
    { id: "con_zendesk", provider: "Zendesk", identity: "support", category: "support", protocol: "openapi", authType: "api-token", supportedActions: ["ticket.read", "ticket.write", "macro.run"], permissionSchema: ["tickets:write"], rateLimitRps: 18, approvalRequired: true, eventSubscriptions: ["ticket.created"], health: "healthy", docs: "https://developer.zendesk.com/api-reference" },
  ]);

  await ensurePool(3);
  await db.insert(browserContexts).values({
    id: uid("ctx"),
    browserId: (await db.select({ id: browserSessions.id }).from(browserSessions).limit(1))[0]?.id ?? "brw_seed",
    agentId: agentIds[4],
    label: "Supplier portal — persistent login",
    domain: "portal.example",
    authenticated: true,
    tabs: [
      { id: uid("tab"), url: "https://portal.example/dashboard", title: "Supplier dashboard", state: "loaded" },
      { id: uid("tab"), url: "https://portal.example/invoices", title: "Invoices", state: "loaded" },
    ],
    state: "open",
  });

  await db.insert(sandboxes).values([
    { id: uid("sbx"), flavor: "container/lite", tier: 1, state: "sleeping", vcpu: 0.0625, memoryMb: 256, diskMb: 2048, bootMs: 340, networkEgress: "allowlisted" },
    { id: uid("sbx"), flavor: "container/basic", tier: 1, state: "sleeping", vcpu: 0.25, memoryMb: 1024, diskMb: 4096, bootMs: 620, networkEgress: "allowlisted" },
    { id: uid("sbx"), flavor: "firecracker/microvm", tier: 2, state: "sleeping", vcpu: 1, memoryMb: 128, diskMb: 1024, bootMs: 122, networkEgress: "denied" },
    { id: uid("sbx"), flavor: "firecracker/microvm", tier: 2, state: "sleeping", vcpu: 1, memoryMb: 128, diskMb: 1024, bootMs: 118, forks: 2, networkEgress: "denied" },
  ]);

  await db.insert(schedules).values([
    { id: uid("sch"), agentId: agentIds[1], name: "Nightly competitor price sweep", cron: "0 3 * * *", template: "competitive-pricing", objective: "Refresh competitor pricing table and flag any change greater than 5%", enabled: true, runs: 41, nextRunAt: new Date(Date.now() + 3600_000) },
    { id: uid("sch"), agentId: agentIds[5], name: "Inbox triage every 15 minutes", cron: "*/15 * * * *", template: "inbound-triage", objective: "Triage inbound mailbox, route to owners, draft replies for approval", enabled: true, runs: 1204, nextRunAt: new Date(Date.now() + 600_000) },
    { id: uid("sch"), agentId: agentIds[0], name: "Weekly market brief", cron: "0 8 * * 1", template: "market-intelligence", objective: "Produce the weekly market intelligence brief with cited evidence", enabled: true, runs: 12, nextRunAt: new Date(Date.now() + 86400_000) },
  ]);

  const seedMemories: { kind: "preference" | "episodic" | "semantic" | "procedural"; subject: string; content: string; agentId?: string; trust?: string; promoted?: boolean }[] = [
    { kind: "preference", subject: "Reporting style", content: "Executive summaries lead with the decision, then evidence. Tables over prose for pricing.", trust: "verified", promoted: true },
    { kind: "preference", subject: "Escalation threshold", content: "Any external communication, payment or deployment requires human authorization before execution.", trust: "verified", promoted: true },
    { kind: "semantic", subject: "Category structure", content: "The category splits into three buying segments: self-serve teams, mid-market with procurement, and regulated enterprise.", trust: "verified", promoted: true },
    { kind: "semantic", subject: "Pricing norm", content: "Median published entry price is $29/seat/month billed annually; usage tiers start above 50k events.", trust: "verified", promoted: true },
    { kind: "semantic", subject: "Competitor motion", content: "Two incumbents moved to hybrid pricing in the last two quarters; one withdrew a free tier.", trust: "candidate" },
    { kind: "episodic", subject: "Q3 pricing refresh", content: "Swept 41 sources in parallel; 3 contradictory prices resolved by preferring primary vendor pages.", agentId: agentIds[1] },
    { kind: "episodic", subject: "Portal login failure", content: "MFA challenge blocked the run until an operator completed Live View takeover; session cookies then persisted for 14 days.", agentId: agentIds[4] },
    { kind: "procedural", subject: "Bounded research fan-out", content: "Generate queries once → parallel fetch on the I/O queue → deterministic extraction → batch structured fields → reason only over contested claims → synthesize → independent verify.", trust: "verified", promoted: true },
    { kind: "procedural", subject: "Copy-on-write coding branch", content: "Fork the prepared snapshot, run speculative branches in parallel microVMs with egress denied, cancel the loser, keep the receipt.", trust: "verified", promoted: true },
    { kind: "procedural", subject: "Browser context hygiene", content: "Reuse warm processes, one isolated context per agent identity, cap tabs at 6, recycle when process memory exceeds 950 MiB.", trust: "verified", promoted: true },
    { kind: "semantic", subject: "Deterministic-first rule", content: "Classification of 100 records uses one batched small-model call or a parser — never 100 reasoning calls.", trust: "verified", promoted: true },
    { kind: "preference", subject: "Cost ceiling", content: "Target under $0.85 of model spend per verified deliverable; alert when a work unit crosses 80% of budget.", trust: "verified", promoted: true },
  ];
  for (const m of seedMemories) {
    await db.insert(memories).values({
      id: uid("mem"),
      orgId,
      agentId: m.agentId ?? null,
      kind: m.kind,
      scope: m.agentId ? "agent" : "org",
      subject: m.subject,
      content: m.content,
      confidence: m.promoted ? 0.92 : 0.68,
      trust: m.trust ?? "candidate",
      promoted: m.promoted ?? false,
      embedding: embed(`${m.subject} ${m.content}`),
      provenance: { method: "seed" },
      validFrom: new Date(),
    });
  }

  // Session population: a handful resident, most hibernated — identity without compute.
  const sessionDefs = [
    { agent: 0, title: "Market brief working session", state: "resident" as const },
    { agent: 4, title: "Supplier portal automation", state: "resident" as const },
    { agent: 5, title: "Inbox triage — 15 min routine", state: "hibernated" as const },
    { agent: 3, title: "Refactor billing adapter", state: "hibernated" as const },
    { agent: 2, title: "Critic review queue", state: "hibernated" as const },
    { agent: 7, title: "Weekly planning standby", state: "evicted" as const },
    { agent: 1, title: "Pricing sweep standby", state: "hibernated" as const },
    { agent: 6, title: "Campaign draft", state: "hibernated" as const },
  ];
  for (const s of sessionDefs) {
    const resident = s.state === "resident";
    await db.insert(sessions).values({
      id: uid("ses"),
      agentId: agentIds[s.agent],
      title: s.title,
      state: s.state,
      residentMemoryMb: resident ? 42 + Math.round(Math.random() * 22) : 0,
      storageBytes: 18_000 + Math.round(Math.random() * 90_000),
      turns: Math.round(Math.random() * 24),
      wakes: Math.round(Math.random() * 12),
      hibernations: Math.round(Math.random() * 12),
      evictions: s.state === "evicted" ? 1 : 0,
      lastActiveAt: resident ? new Date() : new Date(Date.now() - 120_000),
      hibernatedAt: resident ? null : new Date(Date.now() - 110_000),
    });
  }

  await db.insert(deliverySlices).values([
    { id: uid("slc"), step: 1, root: "control-plane", title: "Postgres + artifact store + pooling: a small reliable control plane", acceptanceCriteria: ["All authoritative records in PostgreSQL", "Artifacts referenced by URI + checksum", "No per-agent process exists"], evidence: ["drizzle schema pushed", "/api/state returns live counts"], status: "verified", verifiedBy: "independent-verifier" },
    { id: uid("slc"), step: 2, root: "sessions", title: "Durable hibernating sessions", acceptanceCriteria: ["Idle sessions hold 0 MiB resident memory", "Wake restores transcript + pending tool state", "Eviction is recoverable"], evidence: ["session lifecycle in scheduler.manageSessions", "wake/eviction counters exposed in UI"], status: "verified" },
    { id: uid("slc"), step: 3, root: "work-engine", title: "Work Units and durable task contracts", acceptanceCriteria: ["Task DAG persists across worker loss", "Retries use idempotency keys", "Delegation attenuates authority"], evidence: ["failure injection reconciles receipts", "task_events ledger"], status: "verified" },
    { id: uid("slc"), step: 4, root: "scheduler", title: "Queues and adaptive scheduler", acceptanceCriteria: ["Four independent queues", "C_allowed = min(provider, tenant, queue, sandbox, budget)", "Concurrency reacts to 429s, memory and wait time"], evidence: ["scheduler.adapt decisions log", "live queue panel"], status: "verified" },
    { id: uid("slc"), step: 5, root: "intelligence", title: "Model router and gateway", acceptanceCriteria: ["Cheapest capable model selected per task", "Deterministic steps make zero model calls", "Prompt-prefix cache and fallback on 429"], evidence: ["router ladder table", "gateway cache-hit events"], status: "verified" },
    { id: uid("slc"), step: 6, root: "browser", title: "Reusable browser execution", acceptanceCriteria: ["Processes pooled, contexts isolated", "Tab and memory ceilings enforced", "Human Live View takeover works"], evidence: ["browser pool page", "takeover endpoint returns bearer token + warning"], status: "verified" },
    { id: uid("slc"), step: 7, root: "execution", title: "Three execution tiers with selectable isolation", acceptanceCriteria: ["Tier 0 boots nothing", "Containers scale to zero", "microVM egress denied by default"], evidence: ["executor.selectTier decision log per task"], status: "verified" },
    { id: uid("slc"), step: 8, root: "memory", title: "Memory compiler + in-database vectors", acceptanceCriteria: ["Compilation runs off the critical path", "Duplicates merged, contradictions marked contested", "Promotion requires corroboration"], evidence: ["memory.compileMemory report per work unit"], status: "verified" },
    { id: uid("slc"), step: 9, root: "operations", title: "Connectors, skills, schedules, webhooks", acceptanceCriteria: ["Central connector catalog filters per-role capabilities", "Skills are versioned", "Routines run from the durable scheduler"], evidence: ["connector catalog page", "schedules seeded"], status: "verified" },
    { id: uid("slc"), step: 10, root: "governance", title: "Evaluation, authority and audit", acceptanceCriteria: ["Zero unauthorized side effects", "Injection attempts quarantined, permissions frozen", "Every deliverable checked against acceptance criteria"], evidence: ["benchmark harness red-team scenario", "audit_log denials"], status: "verified" },
  ]);

  return { seeded: true };
}
