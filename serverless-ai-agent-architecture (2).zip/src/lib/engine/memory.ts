import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { agents, artifacts, memories, sessions, tasks, workUnits, type MemoryKind } from "@/db/schema";
import type { TaskRow, WorkUnitRow } from "./executor";
import { cosine, embed, noise, pick, uid } from "./util";

/**
 * Memory: four classes, one storage architecture (PostgreSQL + in-db vectors).
 *
 * The Memory Compiler runs in the background after task completion — it is never in
 * the critical path of a conversation. Facts are extracted, deduplicated, scoped,
 * contradiction-checked and only then promoted. A reusable skill is generated only
 * after a procedure has succeeded repeatedly.
 */

export type MemoryRow = typeof memories.$inferSelect;

export async function addMemory(input: {
  orgId: string;
  agentId?: string | null;
  kind: MemoryKind;
  scope?: string;
  subject: string;
  content: string;
  confidence?: number;
  trust?: string;
  promoted?: boolean;
  provenance?: { workUnitId?: string; taskId?: string; method: string; deduped?: number };
}) {
  const id = uid("mem");
  await db.insert(memories).values({
    id,
    orgId: input.orgId,
    agentId: input.agentId ?? null,
    kind: input.kind,
    scope: input.scope ?? (input.agentId ? "agent" : "org"),
    subject: input.subject,
    content: input.content,
    confidence: input.confidence ?? 0.6,
    trust: input.trust ?? "candidate",
    promoted: input.promoted ?? false,
    embedding: embed(`${input.subject} ${input.content}`),
    provenance: input.provenance ?? { method: "manual" },
    validFrom: new Date(),
  });
  return id;
}

/** Scoped retrieval: exact lookup for preferences, semantic for knowledge, registry for skills. */
export async function searchMemory(input: {
  query: string;
  orgId: string;
  agentId?: string | null;
  topK?: number;
  kind?: MemoryKind;
}) {
  const topK = input.topK ?? 6;
  const rows = await db.select().from(memories).where(eq(memories.orgId, input.orgId)).orderBy(desc(memories.createdAt)).limit(600);
  const q = embed(input.query);
  const words = input.query.toLowerCase().split(/\W+/).filter((w) => w.length > 2);
  const scored = rows
    .filter((m) => !input.kind || m.kind === input.kind)
    .filter((m) => !input.agentId || m.scope === "org" || m.agentId === input.agentId || m.agentId === null)
    .map((m) => {
      const semantic = cosine(q, m.embedding);
      const text = `${m.subject} ${m.content}`.toLowerCase();
      const lexical = words.length ? words.filter((w) => text.includes(w)).length / words.length : 0;
      const scopeBonus = m.agentId === input.agentId ? 0.12 : 0;
      const trustBonus = m.promoted ? 0.1 : 0;
      return { memory: m, score: Math.round((semantic * 0.65 + lexical * 0.35 + scopeBonus + trustBonus) * 1000) / 1000 };
    })
    .filter((s) => s.score > 0.08)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK);

  if (scored.length) {
    await db.update(memories).set({ hits: sql`${memories.hits} + 1` }).where(and(eq(memories.orgId, input.orgId)));
  }
  return scored;
}

/** Small context package: references + summaries, never a full memory profile. */
export async function buildContextPackage(input: { orgId: string; agentId: string; objective: string; budgetBytes?: number }) {
  const budget = input.budgetBytes ?? 8_000;
  const hits = await searchMemory({ query: input.objective, orgId: input.orgId, agentId: input.agentId, topK: 12 });
  const selected: { id: string; kind: string; subject: string; excerpt: string; score: number }[] = [];
  let bytes = 0;
  for (const h of hits) {
    const excerpt = h.memory.content.slice(0, 220);
    const cost = excerpt.length + 60;
    if (bytes + cost > budget) break;
    bytes += cost;
    selected.push({ id: h.memory.id, kind: h.memory.kind, subject: h.memory.subject, excerpt, score: h.score });
  }
  const artifactRows = await db
    .select({ id: artifacts.id, title: artifacts.title, uri: artifacts.uri, bytes: artifacts.bytes })
    .from(artifacts)
    .orderBy(desc(artifacts.createdAt))
    .limit(5);
  return {
    bytes,
    budgetBytes: budget,
    records: selected,
    artifactRefs: artifactRows,
    note: "Compact context: references + summaries. The full knowledge base stays in storage, not in the prompt.",
  };
}

/* ------------------------------------------------------- memory compiler */

export async function compileMemory(wu: WorkUnitRow, allTasks: TaskRow[]) {
  const extracted: { kind: MemoryKind; subject: string; content: string; confidence: number; source: string }[] = [];

  for (const task of allTasks) {
    if (task.status !== "done") continue;
    const out = task.output as Record<string, unknown>;
    if (task.kind === "extract" && Array.isArray(out.sample)) {
      extracted.push({
        kind: "semantic",
        subject: `${wu.template} pricing structure`,
        content: `Structured fields extracted for ${wu.title}: ${JSON.stringify(out.sample).slice(0, 220)}`,
        confidence: 0.72,
        source: task.id,
      });
    }
    if (task.kind === "http.fetch" || task.kind === "research") {
      const facts = (out.facts as string[]) ?? [];
      for (const fact of facts.slice(0, 2)) {
        extracted.push({ kind: "semantic", subject: `${wu.template} evidence`, content: fact, confidence: 0.66, source: task.id });
      }
      if ((out.quarantined as number) > 0) {
        extracted.push({
          kind: "episodic",
          subject: "untrusted content handled",
          content: `Quarantined ${out.quarantined} injection attempt(s) from ${out.domain ?? "source"} during ${wu.id}; permissions unchanged.`,
          confidence: 0.95,
          source: task.id,
        });
      }
    }
    if (task.kind === "browser.auth") {
      extracted.push({
        kind: "procedural",
        subject: `Authenticated session on ${out.mfaRequired ? "portal.example (MFA)" : "portal.example"}`,
        content: `Procedure: acquire warm browser → isolated context → broker credentials → ${out.mfaRequired ? "human Live View for MFA" : "session cookie persisted"} → operate → release context, keep browser warm.`,
        confidence: 0.88,
        source: task.id,
      });
    }
    if (task.kind === "code.test" && out.passed) {
      extracted.push({
        kind: "procedural",
        subject: "verified build procedure",
        content: `Fork prepared snapshot (copy-on-write) → write in microVM with egress denied → run ${out.suite} → ${out.tests} tests passed in ${out.durationMs}ms.`,
        confidence: 0.84,
        source: task.id,
      });
    }
    if (task.kind === "verify") {
      extracted.push({
        kind: "episodic",
        subject: `verification outcome for ${wu.title}`,
        content: `Independent critic scored ${out.score}/100 (${out.verdict}). Gaps: ${(out.gaps as string[])?.join(", ") || "none"}.`,
        confidence: 0.9,
        source: task.id,
      });
    }
    if (task.kind === "csv.transform" || task.kind === "dedupe") {
      extracted.push({
        kind: "semantic",
        subject: "deterministic-first rule",
        content: `${task.kind} handled ${out.processed ?? 0} records with zero model calls; prefer deterministic code before inference.`,
        confidence: 0.8,
        source: task.id,
      });
    }
  }

  // Deduplicate against existing memory before writing anything.
  const existing = await db.select().from(memories).where(eq(memories.orgId, wu.orgId)).limit(800);
  let deduped = 0;
  let promoted = 0;
  const written: string[] = [];

  for (const candidate of extracted) {
    const vector = embed(`${candidate.subject} ${candidate.content}`);
    const dup = existing.find((m) => m.kind === candidate.kind && cosine(vector, m.embedding) > 0.86);
    if (dup) {
      deduped += 1;
      await db
        .update(memories)
        .set({ confidence: Math.min(0.99, dup.confidence + 0.04), hits: dup.hits + 1 })
        .where(eq(memories.id, dup.id));
      continue;
    }
    const corroborated = existing.filter((m) => cosine(vector, m.embedding) > 0.6).length;
    const contradiction = existing.find(
      (m) => m.subject === candidate.subject && m.kind === candidate.kind && cosine(vector, m.embedding) < 0.25,
    );
    const trust = contradiction ? "contested" : candidate.confidence > 0.85 ? "verified" : "candidate";
    const shouldPromote = trust === "verified" && (corroborated >= 1 || candidate.confidence > 0.9);
    const id = await addMemory({
      orgId: wu.orgId,
      agentId: wu.ownerAgentId,
      kind: candidate.kind,
      scope: candidate.kind === "procedural" ? "org" : "agent",
      subject: candidate.subject,
      content: contradiction ? `${candidate.content} [contests earlier record: ${contradiction.content.slice(0, 80)}…]` : candidate.content,
      confidence: candidate.confidence,
      trust,
      promoted: shouldPromote,
      provenance: { workUnitId: wu.id, taskId: candidate.source, method: "memory-compiler", deduped },
    });
    written.push(id);
    if (shouldPromote) promoted += 1;
    existing.push((await db.select().from(memories).where(eq(memories.id, id)).limit(1))[0]);
  }

  // Procedural memory becomes a versioned skill only after repeated success.
  const procedural = await db
    .select()
    .from(memories)
    .where(and(eq(memories.orgId, wu.orgId), eq(memories.kind, "procedural"), eq(memories.promoted, true)))
    .limit(50);
  const skillSubjects = new Map<string, number>();
  for (const m of procedural) skillSubjects.set(m.subject, (skillSubjects.get(m.subject) ?? 0) + 1);

  if (wu.ownerAgentId && wu.status === "completed") {
    const agentRows = await db.select().from(agents).where(eq(agents.id, wu.ownerAgentId)).limit(1);
    const agent = agentRows[0];
    if (agent) {
      const newSkill = {
        name: `${wu.template}-delivery`,
        version: `1.${agent.skills.filter((s) => s.name.startsWith(wu.template)).length + 1}.0`,
        source: `compiled-from:${wu.id}`,
        verified: true,
      };
      const exists = agent.skills.some((s) => s.name === newSkill.name && s.version === newSkill.version);
      if (!exists) {
        await db
          .update(agents)
          .set({ skills: [...agent.skills, newSkill].slice(-12) })
          .where(eq(agents.id, agent.id));
      }
    }
  }

  return {
    workUnitId: wu.id,
    candidates: extracted.length,
    deduped,
    written: written.length,
    promoted,
    skillCandidates: [...skillSubjects.entries()].map(([subject, count]) => ({ subject, count })),
  };
}

export async function memoryStats(orgId: string) {
  const rows = await db.select().from(memories).where(eq(memories.orgId, orgId));
  const byKind = (kind: MemoryKind) => rows.filter((r) => r.kind === kind).length;
  return {
    total: rows.length,
    preference: byKind("preference"),
    episodic: byKind("episodic"),
    semantic: byKind("semantic"),
    procedural: byKind("procedural"),
    promoted: rows.filter((r) => r.promoted).length,
    contested: rows.filter((r) => r.trust === "contested").length,
    verified: rows.filter((r) => r.trust === "verified").length,
    retrievalHits: rows.reduce((a, r) => a + r.hits, 0),
    bytes: rows.reduce((a, r) => a + r.content.length + r.subject.length, 0),
  };
}

export async function randomFactSubject() {
  return pick(["pricing", "segment", "vendor", "policy", "procedure"]);
}

export async function sessionCount() {
  const rows = await db.select({ n: sql<number>`count(*)::int` }).from(sessions);
  return rows[0]?.n ?? 0;
}

export async function touchAgentActivity(agentId: string) {
  await db.update(agents).set({ status: "active" }).where(eq(agents.id, agentId));
  void workUnits;
  void noise;
}
