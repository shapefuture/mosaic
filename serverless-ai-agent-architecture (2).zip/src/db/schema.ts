import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/**
 * AOS v3 — canonical system of record.
 *
 * Boundary rules (from the architecture):
 *  - PostgreSQL holds authoritative organizational + work records (this file).
 *  - Session transcript / turn state is modelled by `sessions` + `session_messages`
 *    (stand-in for Durable Object SQLite in the portable deployment).
 *  - Large objects live in the artifact store (R2 abstraction); the row holds a URI + checksum.
 *  - No separate graph / vector / broker service: semantic retrieval uses in-Postgres vectors.
 */

export const organizations = pgTable("organizations", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  budgetCents: integer("budget_cents").notNull().default(250000),
  spentCents: integer("spent_cents").notNull().default(0),
  fairnessWeight: real("fairness_weight").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type AgentStatus = "active" | "hibernating" | "suspended";

/** A logical agent = identity + role + capabilities + knowledge. It is NOT a process. */
export const agents = pgTable(
  "agents",
  {
    id: text("id").primaryKey(),
    orgId: text("org_id")
      .notNull()
      .references(() => organizations.id),
    name: text("name").notNull(),
    role: text("role").notNull(),
    department: text("department").notNull(),
    reportsTo: text("reports_to"),
    systemProfileVersion: text("system_profile_version").notNull().default("v3.0"),
    capabilities: jsonb("capabilities").$type<string[]>().notNull().default([]),
    skills: jsonb("skills")
      .$type<{ name: string; version: string; source: string; verified: boolean }[]>()
      .notNull()
      .default([]),
    modelPolicy: jsonb("model_policy")
      .$type<{ planning: string; extraction: string; synthesis: string; vision: string; coding: string }>()
      .notNull(),
    memoryScope: text("memory_scope").notNull().default("agent"),
    authorityPolicy: jsonb("authority_policy")
      .$type<{
        actions: string[];
        resources: string[];
        domains: string[];
        maxCostMicros: number;
        maxDelegationDepth: number;
        requiresApproval: string[];
      }>()
      .notNull(),
    budgetCents: integer("budget_cents").notNull().default(5000),
    spentCents: integer("spent_cents").notNull().default(0),
    status: text("status").$type<AgentStatus>().notNull().default("hibernating"),
    residentMemoryMb: real("resident_memory_mb").notNull().default(0),
    completedWorkUnits: integer("completed_work_units").notNull().default(0),
    acceptedDeliverables: integer("accepted_deliverables").notNull().default(0),
    rejectedDeliverables: integer("rejected_deliverables").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("agents_org_idx").on(t.orgId), index("agents_dept_idx").on(t.department)],
);

export type SessionState = "resident" | "waking" | "hibernated" | "evicted";

/**
 * A durable, hibernating session actor. One logical agent may own many concurrent sessions.
 * When idle the session holds storage, not compute: resident_memory_mb -> 0.
 */
export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    agentId: text("agent_id")
      .notNull()
      .references(() => agents.id),
    workUnitId: text("work_unit_id"),
    title: text("title").notNull(),
    channel: text("channel").notNull().default("web"),
    state: text("state").$type<SessionState>().notNull().default("resident"),
    queue: text("queue").notNull().default("interactive"),
    turns: integer("turns").notNull().default(0),
    tokens: integer("tokens").notNull().default(0),
    storageBytes: integer("storage_bytes").notNull().default(0),
    residentMemoryMb: real("resident_memory_mb").notNull().default(0),
    contextBytes: integer("context_bytes").notNull().default(0),
    wakes: integer("wakes").notNull().default(0),
    hibernations: integer("hibernations").notNull().default(0),
    evictions: integer("evictions").notNull().default(0),
    recoveries: integer("recoveries").notNull().default(0),
    pendingToolCalls: integer("pending_tool_calls").notNull().default(0),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true }).notNull().defaultNow(),
    hibernatedAt: timestamp("hibernated_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("sessions_agent_idx").on(t.agentId), index("sessions_state_idx").on(t.state)],
);

export const sessionMessages = pgTable(
  "session_messages",
  {
    id: text("id").primaryKey(),
    sessionId: text("session_id")
      .notNull()
      .references(() => sessions.id, { onDelete: "cascade" }),
    kind: text("kind").$type<"user" | "assistant" | "tool" | "system" | "approval">().notNull(),
    content: text("content").notNull(),
    model: text("model"),
    tokens: integer("tokens").notNull().default(0),
    latencyMs: integer("latency_ms").notNull().default(0),
    costMicros: integer("cost_micros").notNull().default(0),
    tool: text("tool"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("messages_session_idx").on(t.sessionId)],
);

export type WorkUnitStatus =
  | "planning"
  | "running"
  | "awaiting_approval"
  | "verifying"
  | "completed"
  | "rejected"
  | "failed"
  | "cancelled";

/** A durable business task graph (Cloudflare Workflow / DBOS equivalent). */
export const workUnits = pgTable(
  "work_units",
  {
    id: text("id").primaryKey(),
    orgId: text("org_id")
      .notNull()
      .references(() => organizations.id),
    parentWorkUnitId: text("parent_work_unit_id"),
    title: text("title").notNull(),
    objective: text("objective").notNull(),
    template: text("template").notNull().default("generic"),
    ownerAgentId: text("owner_agent_id").references(() => agents.id),
    status: text("status").$type<WorkUnitStatus>().notNull().default("planning"),
    priority: integer("priority").notNull().default(5),
    delegationDepth: integer("delegation_depth").notNull().default(0),
    fanOutLimit: integer("fan_out_limit").notNull().default(12),
    acceptanceCriteria: jsonb("acceptance_criteria").$type<string[]>().notNull().default([]),
    budgetMicros: integer("budget_micros").notNull().default(750000),
    spentMicros: integer("spent_micros").notNull().default(0),
    tokensIn: integer("tokens_in").notNull().default(0),
    tokensOut: integer("tokens_out").notNull().default(0),
    modelCalls: integer("model_calls").notNull().default(0),
    deterministicSteps: integer("deterministic_steps").notNull().default(0),
    taskCount: integer("task_count").notNull().default(0),
    doneCount: integer("done_count").notNull().default(0),
    maxParallelismObserved: integer("max_parallelism_observed").notNull().default(0),
    verification: jsonb("verification")
      .$type<{
        verdict: "accepted" | "rejected" | "pending";
        score: number;
        checks: { name: string; passed: boolean; detail: string }[];
        criticAgentId?: string;
        gaps?: string[];
      }>()
      .notNull()
      .default({ verdict: "pending", score: 0, checks: [] }),
    startedAt: timestamp("started_at", { withTimezone: true }),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("wu_status_idx").on(t.status), index("wu_org_idx").on(t.orgId)],
);

export type TaskStatus = "pending" | "ready" | "running" | "done" | "failed" | "blocked" | "skipped";
export type QueueName = "interactive" | "io" | "compute" | "browser";
export type ExecTier = 0 | 1 | 2;

export const tasks = pgTable(
  "tasks",
  {
    id: text("id").primaryKey(),
    workUnitId: text("work_unit_id")
      .notNull()
      .references(() => workUnits.id, { onDelete: "cascade" }),
    key: text("key").notNull(),
    title: text("title").notNull(),
    kind: text("kind").notNull(),
    queue: text("queue").$type<QueueName>().notNull().default("io"),
    tier: integer("tier").$type<ExecTier>().notNull().default(0),
    status: text("status").$type<TaskStatus>().notNull().default("pending"),
    dependsOn: jsonb("depends_on").$type<string[]>().notNull().default([]),
    assignedAgentId: text("assigned_agent_id"),
    attempts: integer("attempts").notNull().default(0),
    maxAttempts: integer("max_attempts").notNull().default(3),
    requiresApproval: boolean("requires_approval").notNull().default(false),
    needsModel: boolean("needs_model").notNull().default(true),
    modelId: text("model_id"),
    idempotencyKey: text("idempotency_key"),
    input: jsonb("input").$type<Record<string, unknown>>().notNull().default({}),
    output: jsonb("output").$type<Record<string, unknown>>().notNull().default({}),
    artifactId: text("artifact_id"),
    sandboxId: text("sandbox_id"),
    browserContextId: text("browser_context_id"),
    tokensIn: integer("tokens_in").notNull().default(0),
    tokensOut: integer("tokens_out").notNull().default(0),
    costMicros: integer("cost_micros").notNull().default(0),
    durationMs: integer("duration_ms").notNull().default(0),
    waitMs: integer("wait_ms").notNull().default(0),
    error: text("error"),
    startedAt: timestamp("started_at", { withTimezone: true }),
    finishedAt: timestamp("finished_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("tasks_wu_idx").on(t.workUnitId),
    index("tasks_status_idx").on(t.status),
    index("tasks_queue_idx").on(t.queue),
    uniqueIndex("tasks_wu_key_idx").on(t.workUnitId, t.key),
  ],
);

/** Only meaningful boundaries are persisted — not every streamed token or UI event. */
export const taskEvents = pgTable(
  "task_events",
  {
    id: text("id").primaryKey(),
    workUnitId: text("work_unit_id").notNull(),
    taskId: text("task_id"),
    type: text("type").notNull(),
    detail: text("detail"),
    at: timestamp("at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("events_wu_idx").on(t.workUnitId)],
);

export const artifacts = pgTable(
  "artifacts",
  {
    id: text("id").primaryKey(),
    workUnitId: text("work_unit_id"),
    taskId: text("task_id"),
    title: text("title").notNull(),
    kind: text("kind").notNull().default("document"),
    uri: text("uri").notNull(),
    mime: text("mime").notNull().default("text/markdown"),
    bytes: integer("bytes").notNull().default(0),
    checksum: text("checksum").notNull(),
    body: text("body"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("artifacts_wu_idx").on(t.workUnitId)],
);

export type MemoryKind = "preference" | "episodic" | "semantic" | "procedural";

export const memories = pgTable(
  "memories",
  {
    id: text("id").primaryKey(),
    orgId: text("org_id").notNull(),
    agentId: text("agent_id"),
    kind: text("kind").$type<MemoryKind>().notNull(),
    scope: text("scope").notNull().default("agent"),
    subject: text("subject").notNull(),
    content: text("content").notNull(),
    confidence: real("confidence").notNull().default(0.5),
    trust: text("trust").notNull().default("candidate"),
    promoted: boolean("promoted").notNull().default(false),
    embedding: jsonb("embedding").$type<number[]>().notNull().default([]),
    provenance: jsonb("provenance")
      .$type<{ workUnitId?: string; taskId?: string; method: string; deduped?: number }>()
      .notNull()
      .default({ method: "manual" }),
    validFrom: timestamp("valid_from", { withTimezone: true }),
    validTo: timestamp("valid_to", { withTimezone: true }),
    hits: integer("hits").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("mem_org_idx").on(t.orgId), index("mem_kind_idx").on(t.kind)],
);

export const approvals = pgTable(
  "approvals",
  {
    id: text("id").primaryKey(),
    workUnitId: text("work_unit_id").notNull(),
    taskId: text("task_id"),
    agentId: text("agent_id"),
    action: text("action").notNull(),
    resource: text("resource"),
    reason: text("reason").notNull(),
    risk: text("risk").notNull().default("medium"),
    status: text("status").$type<"pending" | "approved" | "denied">().notNull().default("pending"),
    decisionNote: text("decision_note"),
    decidedBy: text("decided_by"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    decidedAt: timestamp("decided_at", { withTimezone: true }),
  },
  (t) => [index("approvals_status_idx").on(t.status)],
);

/** Scoped, short-lived capability token — an agent may request an action, never authorize itself. */
export const capabilityTokens = pgTable(
  "capability_tokens",
  {
    id: text("id").primaryKey(),
    agentId: text("agent_id").notNull(),
    workUnitId: text("work_unit_id"),
    sessionId: text("session_id"),
    actions: jsonb("actions").$type<string[]>().notNull().default([]),
    resources: jsonb("resources").$type<string[]>().notNull().default([]),
    domains: jsonb("domains").$type<string[]>().notNull().default([]),
    maxCostMicros: integer("max_cost_micros").notNull().default(0),
    delegationDepth: integer("delegation_depth").notNull().default(0),
    policyVersion: text("policy_version").notNull().default("v12"),
    signature: text("signature").notNull(),
    revoked: boolean("revoked").notNull().default(false),
    deniedCount: integer("denied_count").notNull().default(0),
    grantedCount: integer("granted_count").notNull().default(0),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("cap_agent_idx").on(t.agentId)],
);

/** Immutable receipt for every external side effect (idempotency + audit). */
export const receipts = pgTable(
  "receipts",
  {
    id: text("id").primaryKey(),
    workUnitId: text("work_unit_id"),
    taskId: text("task_id"),
    agentId: text("agent_id"),
    action: text("action").notNull(),
    externalSystem: text("external_system").notNull(),
    idempotencyKey: text("idempotency_key").notNull(),
    status: text("status").notNull().default("ok"),
    httpStatus: integer("http_status"),
    replayed: boolean("replayed").notNull().default(false),
    detail: jsonb("detail").$type<Record<string, unknown>>().notNull().default({}),
    at: timestamp("at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("receipts_wu_idx").on(t.workUnitId), uniqueIndex("receipts_idem_idx").on(t.idempotencyKey)],
);

export const auditLog = pgTable(
  "audit_log",
  {
    id: text("id").primaryKey(),
    at: timestamp("at", { withTimezone: true }).notNull().defaultNow(),
    actor: text("actor").notNull(),
    action: text("action").notNull(),
    subject: text("subject"),
    result: text("result").notNull().default("ok"),
    severity: text("severity").notNull().default("info"),
    detail: jsonb("detail").$type<Record<string, unknown>>().notNull().default({}),
  },
  (t) => [index("audit_at_idx").on(t.at)],
);

export const connectors = pgTable("connectors", {
  id: text("id").primaryKey(),
  provider: text("provider").notNull(),
  identity: text("identity").notNull(),
  category: text("category").notNull(),
  protocol: text("protocol").notNull().default("typed-api"),
  authType: text("auth_type").notNull().default("oauth2"),
  supportedActions: jsonb("supported_actions").$type<string[]>().notNull().default([]),
  permissionSchema: jsonb("permission_schema").$type<string[]>().notNull().default([]),
  rateLimitRps: integer("rate_limit_rps").notNull().default(10),
  approvalRequired: boolean("approval_required").notNull().default(false),
  eventSubscriptions: jsonb("event_subscriptions").$type<string[]>().notNull().default([]),
  health: text("health").notNull().default("healthy"),
  docs: text("docs"),
});

export const models = pgTable("models", {
  id: text("id").primaryKey(),
  provider: text("provider").notNull(),
  name: text("name").notNull(),
  tier: text("tier").notNull(),
  costPer1kIn: real("cost_per_1k_in").notNull(),
  costPer1kOut: real("cost_per_1k_out").notNull(),
  latencyMs: integer("latency_ms").notNull().default(600),
  contextWindow: integer("context_window").notNull().default(128000),
  concurrencyLimit: integer("concurrency_limit").notNull().default(24),
  inFlight: integer("in_flight").notNull().default(0),
  calls: integer("calls").notNull().default(0),
  rateLimited: integer("rate_limited").notNull().default(0),
  cachedHits: integer("cached_hits").notNull().default(0),
  enabled: boolean("enabled").notNull().default(true),
});

export const browserSessions = pgTable("browser_sessions", {
  id: text("id").primaryKey(),
  label: text("label").notNull(),
  engine: text("engine").notNull().default("browser-run/chromium"),
  state: text("state").notNull().default("ready"),
  processMemoryMb: real("process_memory_mb").notNull().default(0),
  tabCount: integer("tab_count").notNull().default(0),
  maxTabs: integer("max_tabs").notNull().default(6),
  contextCount: integer("context_count").notNull().default(0),
  crashes: integer("crashes").notNull().default(0),
  recycles: integer("recycles").notNull().default(0),
  pagesVisited: integer("pages_visited").notNull().default(0),
  coldStarts: integer("cold_starts").notNull().default(0),
  warmReuses: integer("warm_reuses").notNull().default(0),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Isolated browser context: cookies/storage per agent session, shared browser process. */
export const browserContexts = pgTable("browser_contexts", {
  id: text("id").primaryKey(),
  browserId: text("browser_id")
    .notNull()
    .references(() => browserSessions.id, { onDelete: "cascade" }),
  agentId: text("agent_id"),
  label: text("label").notNull(),
  domain: text("domain").notNull(),
  authenticated: boolean("authenticated").notNull().default(false),
  tabs: jsonb("tabs")
    .$type<{ id: string; url: string; title: string; state: string }[]>()
    .notNull()
    .default([]),
  state: text("state").notNull().default("open"),
  humanTakeover: boolean("human_takeover").notNull().default(false),
  liveViewToken: text("live_view_token"),
  lastActionAt: timestamp("last_action_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Ephemeral execution capacity: Workers (tier 0), Containers (tier 1), microVMs (tier 2). */
export const sandboxes = pgTable("sandboxes", {
  id: text("id").primaryKey(),
  flavor: text("flavor").notNull(),
  tier: integer("tier").notNull(),
  state: text("state").notNull().default("sleeping"),
  vcpu: real("vcpu").notNull().default(0.0625),
  memoryMb: integer("memory_mb").notNull().default(256),
  diskMb: integer("disk_mb").notNull().default(2048),
  bootMs: integer("boot_ms").notNull().default(120),
  forks: integer("forks").notNull().default(0),
  tasksRun: integer("tasks_run").notNull().default(0),
  networkEgress: text("network_egress").notNull().default("denied"),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }).notNull().defaultNow(),
});

export const schedules = pgTable("schedules", {
  id: text("id").primaryKey(),
  agentId: text("agent_id").notNull(),
  name: text("name").notNull(),
  cron: text("cron").notNull(),
  template: text("template").notNull(),
  objective: text("objective").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  runs: integer("runs").notNull().default(0),
  nextRunAt: timestamp("next_run_at", { withTimezone: true }),
});

/** Singleton adaptive scheduler state: C_allowed = min(provider, tenant, queue, sandbox, budget). */
export const schedulerState = pgTable("scheduler_state", {
  id: text("id").primaryKey(),
  running: boolean("running").notNull().default(true),
  tickCount: integer("tick_count").notNull().default(0),
  lastTickAt: timestamp("last_tick_at", { withTimezone: true }),
  concurrency: jsonb("concurrency")
    .$type<Record<QueueName, { limit: number; active: number; pending: number; p95Ms: number }>>()
    .notNull(),
  limits: jsonb("limits")
    .$type<{
      provider: number;
      tenant: number;
      queue: number;
      sandbox: number;
      budget: number;
      browserMemoryMb: number;
      hibernateAfterSec: number;
    }>()
    .notNull(),
  signals: jsonb("signals")
    .$type<{
      queueWaitMs: number;
      p95Ms: number;
      errorRate: number;
      provider429: number;
      provider429Total?: number;
      dbWritesPerTask: number;
      sandboxUtil: number;
      browserMemMb: number;
      budgetUtil: number;
    }>()
    .notNull(),
  totals: jsonb("totals")
    .$type<{
      tasksCompleted: number;
      tasksFailed: number;
      modelCalls: number;
      deterministicSteps: number;
      tokensIn: number;
      tokensOut: number;
      costMicros: number;
      sideEffects: number;
      deliverablesAccepted: number;
      deliverablesRejected: number;
      unauthorizedBlocked: number;
      injectionsBlocked: number;
      residentMemoryMb: number;
      logicalSessions: number;
    }>()
    .notNull(),
  decisions: jsonb("decisions").$type<string[]>().notNull().default([]),
});

export const metricsSamples = pgTable(
  "metrics_samples",
  {
    id: text("id").primaryKey(),
    at: timestamp("at", { withTimezone: true }).notNull().defaultNow(),
    residentMemoryMb: real("resident_memory_mb").notNull().default(0),
    logicalSessions: integer("logical_sessions").notNull().default(0),
    residentSessions: integer("resident_sessions").notNull().default(0),
    runningTasks: integer("running_tasks").notNull().default(0),
    pendingTasks: integer("pending_tasks").notNull().default(0),
    throughputPerSec: real("throughput_per_sec").notNull().default(0),
    p95Ms: real("p95_ms").notNull().default(0),
    costMicros: integer("cost_micros").notNull().default(0),
    browserMemMb: real("browser_mem_mb").notNull().default(0),
  },
  (t) => [index("metrics_at_idx").on(t.at)],
);

/** Benchmark runs for the AOS capacity qualification harness. */
export const benchmarkRuns = pgTable("benchmark_runs", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  status: text("status").notNull().default("completed"),
  scenario: text("scenario").notNull(),
  targets: jsonb("targets").$type<Record<string, number>>().notNull().default({}),
  measured: jsonb("measured").$type<Record<string, number>>().notNull().default({}),
  checks: jsonb("checks")
    .$type<{ name: string; passed: boolean; detail: string }[]>()
    .notNull()
    .default([]),
  durationMs: integer("duration_ms").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Delivery slices: bounded vertical increments with acceptance criteria + evidence. */
export const deliverySlices = pgTable("delivery_slices", {
  id: text("id").primaryKey(),
  step: integer("step").notNull(),
  root: text("root").notNull(),
  title: text("title").notNull(),
  acceptanceCriteria: jsonb("acceptance_criteria").$type<string[]>().notNull().default([]),
  evidence: jsonb("evidence").$type<string[]>().notNull().default([]),
  status: text("status").notNull().default("verified"),
  verifiedBy: text("verified_by").notNull().default("independent-verifier"),
});
