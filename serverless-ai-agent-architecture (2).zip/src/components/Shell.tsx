"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Activity,
  Brain,
  Cpu,
  FlaskConical,
  Gauge,
  Globe2,
  Layers,
  MessagesSquare,
  Network,
  Pause,
  Play,
  Plug,
  ShieldCheck,
  Users,
} from "lucide-react";
import { useAos } from "@/lib/client/state";
import { cn } from "@/lib/cn";
import { Btn, Dot } from "@/components/ui";

const NAV = [
  { href: "/", label: "Control plane", icon: Gauge, group: "operate" },
  { href: "/work", label: "Work engine", icon: Network, group: "operate" },
  { href: "/scheduler", label: "Scheduler", icon: Cpu, group: "operate" },
  { href: "/agents", label: "Agent registry", icon: Users, group: "workforce" },
  { href: "/sessions", label: "Sessions", icon: MessagesSquare, group: "workforce" },
  { href: "/browser", label: "Browser pool", icon: Globe2, group: "workforce" },
  { href: "/memory", label: "Memory", icon: Brain, group: "intelligence" },
  { href: "/catalog", label: "Models & connectors", icon: Plug, group: "intelligence" },
  { href: "/security", label: "Authority", icon: ShieldCheck, group: "govern" },
  { href: "/benchmark", label: "Qualification", icon: FlaskConical, group: "govern" },
  { href: "/architecture", label: "Architecture", icon: Layers, group: "govern" },
];

const GROUPS: Record<string, string> = {
  operate: "Execution",
  workforce: "Workforce",
  intelligence: "Intelligence",
  govern: "Governance",
};

export function Shell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { data, live, setLive, error, post, busy } = useAos();
  const footprint = data?.footprint;
  const totals = data?.scheduler?.totals;

  const groups = Array.from(new Set(NAV.map((n) => n.group)));

  return (
    <div className="flex min-h-screen">
      <aside className="sticky top-0 hidden h-screen w-[228px] shrink-0 flex-col border-r border-line bg-abyss/80 backdrop-blur lg:flex">
        <div className="border-b border-line px-4 py-4">
          <p className="mono text-[10px] uppercase tracking-[0.24em] text-cyan">AOS v3</p>
          <p className="mt-1 text-[13px] font-semibold leading-tight text-chalk">Hibernating agent operating system</p>
          <p className="mt-1.5 text-[11px] leading-snug text-dim">Millions of identities. Thousands of concurrent tasks. A tiny always-on footprint.</p>
        </div>

        <nav className="flex-1 overflow-y-auto px-2 py-3">
          {groups.map((group) => (
            <div key={group} className="mb-3">
              <p className="mono px-2 py-1 text-[9.5px] uppercase tracking-[0.18em] text-dim/80">{GROUPS[group]}</p>
              {NAV.filter((n) => n.group === group).map((item) => {
                const active = pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href));
                const Icon = item.icon;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "group flex items-center gap-2.5 rounded-lg px-2 py-1.5 text-[12.5px] transition-colors",
                      active ? "bg-cyan/10 text-cyan" : "text-mist hover:bg-white/4 hover:text-chalk",
                    )}
                  >
                    <Icon size={14} strokeWidth={1.8} className={active ? "text-cyan" : "text-dim group-hover:text-mist"} />
                    {item.label}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>

        <div className="border-t border-line px-4 py-3">
          <div className="flex items-center justify-between">
            <span className="mono flex items-center gap-1.5 text-[10.5px] uppercase tracking-[0.12em] text-dim">
              <Dot tone={error ? "rose" : live ? "jade" : "amber"} pulse={!error && live} />
              {error ? "engine error" : live ? "live" : "paused"}
            </span>
            <span className="mono text-[10.5px] text-dim">tick {data?.scheduler?.tickCount ?? 0}</span>
          </div>
          <p className="mt-2 text-[10.5px] leading-relaxed text-dim/80">
            No daemon runs per agent. Every poll advances durable state in PostgreSQL.
          </p>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 border-b border-line bg-void/88 backdrop-blur-md">
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2 px-4 py-2.5 lg:px-6">
            <div className="flex items-center gap-2 lg:hidden">
              <span className="mono text-[11px] font-semibold tracking-[0.2em] text-cyan">AOS v3</span>
            </div>

            <HeaderStat label="Resident footprint" value={`${footprint?.residentMemoryMb ?? 0}`} unit="MiB" tone="cyan" />
            <HeaderStat label="Logical sessions" value={`${footprint?.logicalSessions ?? 0}`} sub={`${footprint?.residentSessions ?? 0} resident`} />
            <HeaderStat label="Concurrent tasks" value={`${footprint?.runningTasks ?? 0}`} sub={`${footprint?.pendingTasks ?? 0} queued`} tone="violet" />
            <HeaderStat label="Deliverables" value={`${totals?.deliverablesAccepted ?? 0}`} sub={`${totals?.deliverablesRejected ?? 0} rejected`} tone="jade" />
            <HeaderStat label="Model spend" value={`$${((totals?.costMicros ?? 0) / 1_000_000).toFixed(2)}`} sub={`${totals?.modelCalls ?? 0} calls`} tone="amber" />
            <HeaderStat label="Blocked" value={`${totals?.unauthorizedBlocked ?? 0}`} sub="unauthorized" tone="rose" />

            <div className="ml-auto flex items-center gap-2">
              <Btn size="sm" tone={live ? "amber" : "jade"} onClick={() => setLive(!live)} title={live ? "Pause the live poll" : "Resume the live poll"}>
                {live ? <Pause size={12} /> : <Play size={12} />}
                {live ? "pause" : "resume"}
              </Btn>
              <Btn size="sm" onClick={() => void post("/api/engine", { action: "tick", ticks: 1 })} disabled={busy} title="Advance the scheduler once">
                <Activity size={12} /> tick
              </Btn>
            </div>
          </div>

          <nav className="flex gap-1 overflow-x-auto border-t border-line px-3 py-1.5 lg:hidden">
            {NAV.map((item) => {
              const active = pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href));
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn("mono shrink-0 rounded-md px-2 py-1 text-[10.5px] uppercase tracking-[0.1em]", active ? "bg-cyan/12 text-cyan" : "text-dim")}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          {error && <div className="mono border-t border-rose/30 bg-rose/8 px-4 py-1.5 text-[11px] text-rose">engine unreachable: {error}</div>}
        </header>

        <main className="min-w-0 flex-1 px-4 py-5 lg:px-6 lg:py-6">{children}</main>

        <footer className="border-t border-line px-4 py-4 lg:px-6">
          <p className="mono text-[10.5px] leading-relaxed text-dim">
            AOS v3 · identity ≠ process · PostgreSQL is the system of record · sessions hibernate · work units are durable DAGs · execution is tiered ·
            authority is deterministic · verification is independent
          </p>
        </footer>
      </div>
    </div>
  );
}

function HeaderStat({ label, value, unit, sub, tone = "chalk" }: { label: string; value: string; unit?: string; sub?: string; tone?: "cyan" | "violet" | "jade" | "amber" | "rose" | "chalk" }) {
  const color = { cyan: "text-cyan", violet: "text-violet", jade: "text-jade", amber: "text-amber", rose: "text-rose", chalk: "text-chalk" }[tone];
  return (
    <div className="min-w-0">
      <p className="mono text-[9.5px] uppercase tracking-[0.14em] text-dim">{label}</p>
      <p className="mono flex items-baseline gap-1 text-[15px] font-semibold leading-tight">
        <span className={color}>{value}</span>
        {unit && <span className="text-[10px] text-dim">{unit}</span>}
        {sub && <span className="ml-1 text-[10px] font-normal text-dim">{sub}</span>}
      </p>
    </div>
  );
}
