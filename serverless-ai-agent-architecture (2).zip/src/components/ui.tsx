"use client";

import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export type Tone = "cyan" | "jade" | "amber" | "rose" | "violet" | "blue" | "dim";

const TONE_TEXT: Record<Tone, string> = {
  cyan: "text-cyan",
  jade: "text-jade",
  amber: "text-amber",
  rose: "text-rose",
  violet: "text-violet",
  blue: "text-blue",
  dim: "text-dim",
};

const TONE_BG: Record<Tone, string> = {
  cyan: "bg-cyan/12 border-cyan/35",
  jade: "bg-jade/12 border-jade/35",
  amber: "bg-amber/12 border-amber/35",
  rose: "bg-rose/12 border-rose/35",
  violet: "bg-violet/12 border-violet/35",
  blue: "bg-blue/12 border-blue/35",
  dim: "bg-white/4 border-line",
};

const TONE_SOLID: Record<Tone, string> = {
  cyan: "bg-cyan",
  jade: "bg-jade",
  amber: "bg-amber",
  rose: "bg-rose",
  violet: "bg-violet",
  blue: "bg-blue",
  dim: "bg-dim",
};

export function Panel({
  title,
  subtitle,
  right,
  children,
  className,
  bodyClass,
  icon,
}: {
  title?: ReactNode;
  subtitle?: ReactNode;
  right?: ReactNode;
  children?: ReactNode;
  className?: string;
  bodyClass?: string;
  icon?: ReactNode;
}) {
  return (
    <section className={cn("rounded-xl border border-line bg-panel/80 hairline backdrop-blur-[2px]", className)}>
      {(title || right) && (
        <header className="flex items-start justify-between gap-3 border-b border-line px-4 py-3">
          <div className="min-w-0">
            <h2 className="flex items-center gap-2 text-[13px] font-semibold tracking-[0.02em] text-chalk">
              {icon}
              {title}
            </h2>
            {subtitle && <p className="mt-1 text-[11.5px] leading-relaxed text-dim">{subtitle}</p>}
          </div>
          {right && <div className="shrink-0">{right}</div>}
        </header>
      )}
      <div className={cn("p-4", bodyClass)}>{children}</div>
    </section>
  );
}

export function Stat({
  label,
  value,
  unit,
  hint,
  tone = "cyan",
  sub,
}: {
  label: ReactNode;
  value: ReactNode;
  unit?: ReactNode;
  hint?: ReactNode;
  tone?: Tone;
  sub?: ReactNode;
}) {
  return (
    <div className="rounded-xl border border-line bg-panel/70 px-4 py-3 hairline">
      <p className="text-[10.5px] uppercase tracking-[0.14em] text-dim">{label}</p>
      <p className="mt-1.5 flex items-baseline gap-1.5">
        <span className={cn("mono text-[26px] font-semibold leading-none", TONE_TEXT[tone])}>{value}</span>
        {unit && <span className="mono text-[11px] text-mist">{unit}</span>}
      </p>
      {sub && <div className="mt-1.5 text-[11px] text-mist">{sub}</div>}
      {hint && <p className="mt-1 text-[11px] leading-snug text-dim">{hint}</p>}
    </div>
  );
}

export function Badge({ children, tone = "dim", className }: { children: ReactNode; tone?: Tone; className?: string }) {
  return (
    <span className={cn("mono inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10.5px] uppercase tracking-[0.08em]", TONE_BG[tone], TONE_TEXT[tone], className)}>
      {children}
    </span>
  );
}

export function Dot({ tone = "cyan", pulse }: { tone?: Tone; pulse?: boolean }) {
  return <span className={cn("inline-block h-1.5 w-1.5 rounded-full", TONE_SOLID[tone], pulse && "pulse-dot")} />;
}

export function Btn({
  children,
  onClick,
  tone = "cyan",
  size = "md",
  disabled,
  active,
  type = "button",
  title,
  className,
}: {
  children: ReactNode;
  onClick?: () => void;
  tone?: Tone;
  size?: "sm" | "md";
  disabled?: boolean;
  active?: boolean;
  type?: "button" | "submit";
  title?: string;
  className?: string;
}) {
  return (
    <button
      type={type}
      title={title}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "mono inline-flex items-center justify-center gap-1.5 rounded-lg border transition-colors",
        size === "sm" ? "px-2 py-1 text-[10.5px]" : "px-3 py-1.5 text-[11.5px]",
        active
          ? "border-cyan/60 bg-cyan/18 text-cyan"
          : cn("border-line2 bg-panel2 text-mist hover:border-cyan/45 hover:text-chalk", TONE_TEXT[tone] && "hover:text-chalk"),
        disabled && "cursor-not-allowed opacity-40 hover:border-line2 hover:text-mist",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Meter({ value, max = 100, tone = "cyan", label, right }: { value: number; max?: number; tone?: Tone; label?: ReactNode; right?: ReactNode }) {
  const pct = max > 0 ? Math.min(100, Math.max(0, (value / max) * 100)) : 0;
  return (
    <div>
      {(label || right) && (
        <div className="mb-1 flex items-center justify-between text-[11px] text-mist">
          <span>{label}</span>
          <span className="mono text-dim">{right}</span>
        </div>
      )}
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-line/70">
        <div className={cn("h-full rounded-full transition-all duration-500", TONE_SOLID[tone])} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function Spark({ points, tone = "cyan", height = 34, fill = true }: { points: number[]; tone?: Tone; height?: number; fill?: boolean }) {
  if (!points.length) return <div className="mono text-[11px] text-dim">awaiting samples…</div>;
  const max = Math.max(...points, 1);
  const min = Math.min(...points, 0);
  const span = max - min || 1;
  const step = 100 / Math.max(1, points.length - 1);
  const coords = points.map((p, i) => `${(i * step).toFixed(2)},${(height - ((p - min) / span) * (height - 4) - 2).toFixed(2)}`);
  const stroke = { cyan: "#22d3ee", jade: "#34d399", amber: "#fbbf24", rose: "#fb7185", violet: "#a78bfa", blue: "#60a5fa", dim: "#5d6f8e" }[tone];
  return (
    <svg viewBox={`0 0 100 ${height}`} preserveAspectRatio="none" className="w-full" style={{ height }}>
      {fill && <polygon points={`0,${height} ${coords.join(" ")} 100,${height}`} fill={stroke} opacity={0.12} />}
      <polyline points={coords.join(" ")} fill="none" stroke={stroke} strokeWidth={1.4} vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

export function Table({ head, children, className }: { head: ReactNode[]; children: ReactNode; className?: string }) {
  return (
    <div className={cn("overflow-x-auto", className)}>
      <table className="w-full border-collapse text-left">
        <thead>
          <tr className="border-b border-line">
            {head.map((h, i) => (
              <th key={i} className="mono whitespace-nowrap px-3 py-2 text-[10px] font-medium uppercase tracking-[0.12em] text-dim">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-line/60">{children}</tbody>
      </table>
    </div>
  );
}

export function Td({ children, className, colSpan }: { children?: ReactNode; className?: string; colSpan?: number }) {
  return (
    <td colSpan={colSpan} className={cn("px-3 py-2 align-middle text-[12px] text-mist", className)}>
      {children}
    </td>
  );
}

export function KV({ k, v, mono = true }: { k: ReactNode; v: ReactNode; mono?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-3 border-b border-line/50 py-1.5 last:border-0">
      <span className="text-[11px] uppercase tracking-[0.1em] text-dim">{k}</span>
      <span className={cn("text-right text-[12px] text-chalk", mono && "mono")}>{v}</span>
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="mono rounded-lg border border-dashed border-line px-4 py-6 text-center text-[11.5px] text-dim">{children}</div>;
}

const STATUS_TONE: Record<string, Tone> = {
  planning: "violet",
  running: "cyan",
  awaiting_approval: "amber",
  verifying: "blue",
  completed: "jade",
  rejected: "rose",
  failed: "rose",
  cancelled: "dim",
  pending: "dim",
  ready: "blue",
  blocked: "amber",
  done: "jade",
  skipped: "dim",
  resident: "cyan",
  waking: "blue",
  hibernated: "violet",
  evicted: "dim",
  active: "jade",
  suspended: "rose",
  pendingApproval: "amber",
};

export function Status({ value, label }: { value: string; label?: string }) {
  const tone = STATUS_TONE[value] ?? "dim";
  return (
    <Badge tone={tone}>
      <Dot tone={tone} pulse={value === "running" || value === "resident"} />
      {label ?? value.replace(/_/g, " ")}
    </Badge>
  );
}

export function SectionTitle({ eyebrow, title, children }: { eyebrow?: string; title: ReactNode; children?: ReactNode }) {
  return (
    <div className="mb-4">
      {eyebrow && <p className="mono text-[10.5px] uppercase tracking-[0.2em] text-cyan/80">{eyebrow}</p>}
      <h1 className="mt-1.5 text-[22px] font-semibold tracking-[-0.015em] text-chalk">{title}</h1>
      {children && <div className="mt-2 max-w-3xl text-[12.5px] leading-relaxed text-mist">{children}</div>}
    </div>
  );
}

export function QueueTone(queue: string): Tone {
  return ({ interactive: "amber", io: "cyan", compute: "violet", browser: "jade" } as Record<string, Tone>)[queue] ?? "dim";
}
