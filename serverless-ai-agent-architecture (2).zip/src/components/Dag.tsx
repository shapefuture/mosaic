"use client";

import { useMemo } from "react";
import { cn } from "@/lib/cn";
import { Dot } from "@/components/ui";

export type DagTask = {
  id: string;
  key: string;
  title: string;
  status: string;
  queue: string;
  tier: number;
  dependsOn: string[];
  costMicros?: number;
  durationMs?: number;
  needsModel?: boolean;
};

const NODE_W = 206;
const NODE_H = 54;
const GAP_X = 46;
const GAP_Y = 12;

const STATUS_COLOR: Record<string, string> = {
  done: "#34d399",
  running: "#22d3ee",
  ready: "#60a5fa",
  pending: "#3a4a68",
  blocked: "#fbbf24",
  failed: "#fb7185",
  skipped: "#4b5568",
};

const QUEUE_COLOR: Record<string, string> = {
  interactive: "#fbbf24",
  io: "#22d3ee",
  compute: "#a78bfa",
  browser: "#34d399",
};

/** Layered DAG: fan-out is visible, dependencies are explicit, the join boundary is a single node. */
export function Dag({ tasks, selected, onSelect }: { tasks: DagTask[]; selected?: string | null; onSelect?: (id: string) => void }) {
  const { layers, positions, edges, width, height } = useMemo(() => {
    const byKey = new Map(tasks.map((t) => [t.key, t]));
    const depth = new Map<string, number>();
    const compute = (key: string, seen = new Set<string>()): number => {
      if (depth.has(key)) return depth.get(key)!;
      if (seen.has(key)) return 0;
      seen.add(key);
      const task = byKey.get(key);
      const deps = (task?.dependsOn ?? []).filter((d) => byKey.has(d));
      const d = deps.length ? Math.max(...deps.map((dep) => compute(dep, seen))) + 1 : 0;
      depth.set(key, d);
      return d;
    };
    tasks.forEach((t) => compute(t.key));

    const grouped = new Map<number, DagTask[]>();
    for (const t of tasks) {
      const d = depth.get(t.key) ?? 0;
      grouped.set(d, [...(grouped.get(d) ?? []), t]);
    }
    const layerKeys = [...grouped.keys()].sort((a, b) => a - b);
    const maxRows = Math.max(1, ...layerKeys.map((k) => grouped.get(k)!.length));
    const positions = new Map<string, { x: number; y: number; task: DagTask }>();
    const layers: { depth: number; tasks: DagTask[] }[] = [];

    layerKeys.forEach((d, colIndex) => {
      const items = grouped.get(d)!;
      const x = colIndex * (NODE_W + GAP_X);
      const startY = ((maxRows - items.length) * (NODE_H + GAP_Y)) / 2;
      items.forEach((task, i) => {
        positions.set(task.key, { x, y: startY + i * (NODE_H + GAP_Y), task });
      });
      layers.push({ depth: d, tasks: items });
    });

    const edges: { from: string; to: string; d: string; active: boolean }[] = [];
    for (const task of tasks) {
      const to = positions.get(task.key);
      if (!to) continue;
      for (const dep of task.dependsOn) {
        const from = positions.get(dep);
        if (!from) continue;
        const x1 = from.x + NODE_W;
        const y1 = from.y + NODE_H / 2;
        const x2 = to.x;
        const y2 = to.y + NODE_H / 2;
        const midX = x1 + (x2 - x1) / 2;
        edges.push({
          from: dep,
          to: task.key,
          d: `M ${x1} ${y1} C ${midX} ${y1}, ${midX} ${y2}, ${x2} ${y2}`,
          active: from.task.status === "done" && (to.task.status === "running" || to.task.status === "done"),
        });
      }
    }

    return {
      layers,
      positions,
      edges,
      width: layerKeys.length * NODE_W + (layerKeys.length - 1) * GAP_X,
      height: maxRows * NODE_H + (maxRows - 1) * GAP_Y,
    };
  }, [tasks]);

  if (!tasks.length) return null;

  return (
    <div className="overflow-x-auto pb-2">
      <div className="relative" style={{ width, height }}>
        <svg className="pointer-events-none absolute inset-0" width={width} height={height}>
          {edges.map((e, i) => (
            <path
              key={i}
              d={e.d}
              fill="none"
              stroke={e.active ? "#22d3ee" : "#243352"}
              strokeWidth={e.active ? 1.5 : 1}
              strokeDasharray={e.active ? undefined : "3 3"}
              opacity={e.active ? 0.85 : 0.6}
            />
          ))}
        </svg>
        {[...positions.values()].map(({ x, y, task }) => {
          const isSel = selected === task.id;
          return (
            <button
              key={task.key}
              onClick={() => onSelect?.(task.id)}
              style={{ left: x, top: y, width: NODE_W, height: NODE_H }}
              className={cn(
                "absolute rounded-lg border px-2.5 py-1.5 text-left transition-all",
                isSel ? "border-cyan/70 bg-cyan/10 shadow-[0_0_0_1px_rgba(34,211,238,0.25)]" : "border-line bg-panel2/90 hover:border-line2",
              )}
            >
              <div className="flex items-center gap-1.5">
                <Dot tone={task.status === "running" ? "cyan" : "dim"} pulse={task.status === "running"} />
                <span className="mono truncate text-[11px] text-chalk">{task.key}</span>
                <span className="mono ml-auto shrink-0 text-[9.5px] uppercase tracking-[0.08em]" style={{ color: STATUS_COLOR[task.status] ?? "#5d6f8e" }}>
                  {task.status}
                </span>
              </div>
              <p className="mt-0.5 truncate text-[10.5px] text-mist">{task.title}</p>
              <div className="mono mt-0.5 flex items-center gap-2 text-[9.5px] text-dim">
                <span style={{ color: QUEUE_COLOR[task.queue] ?? "#5d6f8e" }}>{task.queue}</span>
                <span>tier {task.tier}</span>
                <span>{task.needsModel ? "model" : "deterministic"}</span>
              </div>
            </button>
          );
        })}
      </div>
      <div className="mono mt-2 flex flex-wrap items-center gap-3 text-[10px] text-dim">
        {Object.entries(STATUS_COLOR).map(([status, color]) => (
          <span key={status} className="flex items-center gap-1.5">
            <span className="inline-block h-1.5 w-1.5 rounded-full" style={{ background: color }} />
            {status}
          </span>
        ))}
        <span className="ml-auto">layers = dependency depth · fan-out is bounded by C_allowed</span>
      </div>
    </div>
  );
}
