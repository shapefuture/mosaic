/* eslint-disable @typescript-eslint/no-explicit-any */
import Link from "next/link";
import { notFound } from "next/navigation";
import { pool } from "@/db";
import { Shell } from "@/components/Shell";
import { Card, Chip, Markdown, PageHeader, Stat, ago, micro } from "@/components/ui";
import { ApprovalButtons, CancelButton } from "@/components/Controls";
import { verifyAuthority } from "@/lib/security/authority";
import { OPS } from "@/lib/engine/planner";

export const dynamic = "force-dynamic";

const dur = (a: string | null, b: string | null) => (a && b ? `${Math.max(0, new Date(b).getTime() - new Date(a).getTime())} ms` : "");

function summarize(t: any): string {
  const o = t.output;
  if (!o) return "";
  if (o.passed !== undefined) return `verification ${o.passed ? "PASSED" : "FAILED"} · ${o.rounds?.length ?? 0} gauntlet round(s) · ${o.evidenceChecked ?? 0} evidence snapshot(s) re-read`;
  if (o.url && o.sha) return `${o.title} · ${o.prices?.length ?? 0} prices · ${o.facts?.length ?? 0} facts${o.injection?.length ? ` · ⚠ ${o.injection.length} injection pattern(s) quarantined` : ""}`;
  if (o.sources && o.contradictions) return `${o.sources.length} sources reduced · ${o.contradictions.length} contradiction(s) · ${o.sources.filter((s: any) => s.quarantined).length} quarantined`;
  if (o.markdown) return `${o.degraded ? "deterministic" : "model-assisted"} draft · ${o.markdown.length} chars`;
  if (o.download) return `downloaded ${o.download.name} (${o.download.bytes} B, sha ${String(o.download.sha256).slice(0, 10)}…)`;
  if (o.page) return `${o.page.title} · ${o.page.url}`;
  if (o.urls) return `${o.urls.length} URL(s)`;
  if (o.queries) return o.queries.join(" | ");
  if (o.refs) return `${o.refs.length} memory reference(s), 0 model calls`;
  if (o.total !== undefined) return `${o.rows} rows · total ${o.total}`;
  if (o.text) return String(o.text).slice(0, 140);
  return "";
}

export default async function WorkPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/.test(id)) notFound();
  const wu = (await pool.query("SELECT w.*, a.name AS owner, a.role FROM work_units w JOIN agents a ON a.id=w.owner_agent_id WHERE w.id=$1", [id])).rows[0];
  if (!wu) notFound();
  const [tasksR, rcpt, arts, appr] = await Promise.all([
    pool.query("SELECT t.*, a.name AS agent_name FROM tasks t LEFT JOIN agents a ON a.id=t.agent_id WHERE t.work_unit_id=$1 ORDER BY t.queued_at, t.key", [id]),
    pool.query("SELECT id, action, resource, decision, actor, created_at, side_effect FROM receipts WHERE work_unit_id=$1 ORDER BY id DESC LIMIT 25", [id]),
    pool.query("SELECT name, kind, sha256, bytes FROM artifacts WHERE work_unit_id=$1", [id]),
    pool.query("SELECT * FROM approvals WHERE work_unit_id=$1 AND status='pending'", [id]),
  ]);
  const tasks = tasksR.rows as any[];
  const auth = verifyAuthority(wu.authority_token);
  const big = tasks.length > 80;
  // layer tasks by dependency depth
  const depth = new Map<string, number>();
  const byKey = new Map(tasks.map((t) => [t.key, t]));
  const d = (k: string): number => { if (depth.has(k)) return depth.get(k)!; depth.set(k, 0); const t = byKey.get(k); const v = t && t.deps.length ? 1 + Math.max(...t.deps.map((x: string) => (byKey.has(x) ? d(x) : 0))) : 0; depth.set(k, v); return v; };
  tasks.forEach((t) => d(t.key));
  const layers: any[][] = [];
  const shown = big ? tasks.filter((t) => t.status !== "succeeded").slice(0, 30).concat(tasks.filter((t) => t.status === "succeeded").slice(0, 10)) : tasks;
  shown.forEach((t) => (layers[depth.get(t.key) ?? 0] ??= []).push(t));
  const counts = tasks.reduce((a: Record<string, number>, t) => ((a[t.status] = (a[t.status] ?? 0) + 1), a), {});
  const waits = tasks.filter((t) => t.started_at && t.ready_at).map((t) => new Date(t.started_at).getTime() - new Date(t.ready_at).getTime());
  const gaunt = (wu.result?.gauntlet ?? []) as any[];

  return (
    <Shell path="/work">
      <PageHeader
        title={wu.objective.length > 90 ? wu.objective.slice(0, 90) + "…" : wu.objective}
        sub={<span>{wu.template} · owned by {wu.owner} ({wu.role}) · created {ago(wu.created_at)} · <Link href="/" className="text-emerald-300 hover:underline">all work</Link></span>}
        right={<div className="flex items-center gap-3"><Chip s={wu.status} />{wu.status === "running" && <CancelButton id={id} />}</div>}
      />
      {wu.error && <div className="mb-4 rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 text-sm text-rose-200">{wu.error}</div>}
      {wu.result?.degraded && <div className="mb-4 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-sm text-amber-200">Degraded mode: no model was available for at least one step, so a deterministic fallback produced that output. Set a model key for model-assisted synthesis and reasoning.</div>}
      {appr.rows.map((a: any) => (
        <div key={a.id} className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-violet-500/30 bg-violet-500/10 p-3">
          <div className="text-sm text-violet-100">{a.kind === "human_takeover" ? "Human takeover needed: " : "Approval needed: "}{a.payload.reason ?? a.payload.title}</div>
          <div className="flex items-center gap-3">{a.kind === "human_takeover" && <Link href="/browser" className="text-sm text-emerald-300 hover:underline">Open the shared browser →</Link>}<ApprovalButtons id={a.id} resume={a.kind === "human_takeover"} /></div>
        </div>
      ))}
      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat label="Tasks" value={tasks.length} sub={Object.entries(counts).map(([k, v]) => `${v} ${k}`).join(" · ")} />
        <Stat label="Model calls" value={wu.result?.modelCalls ?? "…"} sub="deterministic where possible" />
        <Stat label="Spend" value={micro(wu.spent_micro)} sub={`budget ${micro(wu.budget_micro)}`} />
        <Stat label="Queue wait p50" value={waits.length ? `${Math.round([...waits].sort((a, b) => a - b)[Math.floor(waits.length / 2)])} ms` : "-"} />
        <Stat label="Authority" value={auth.ok ? `${auth.authority.actions.length} actions` : "invalid"} sub={auth.ok ? `depth ${auth.authority.delegation_depth} · ${auth.authority.policy_version}` : (auth as any).reason} />
      </div>

      {wu.deliverable && (
        <Card title={wu.status === "completed" ? "Deliverable (verified)" : "Draft (NOT accepted)"} right={<Chip s={wu.status === "completed" ? "completed" : "failed"}>{wu.status === "completed" ? "passed verification" : "failed verification"}</Chip>} className="mb-6">
          <Markdown text={wu.deliverable} />
        </Card>
      )}

      <div className="grid gap-6 xl:grid-cols-[1.5fr_1fr]">
        <Card title="Task graph" right={<span className="text-xs text-slate-500">{big ? `showing ${shown.length} of ${tasks.length}` : "columns = dependency depth"}</span>}>
          <div className="space-y-4">
            {layers.map((layer, i) => layer && (
              <div key={i}>
                <div className="mb-2 text-[11px] uppercase tracking-wider text-slate-500">Stage {i + 1}{layer.length > 1 ? ` · ${layer.length} in parallel` : ""}</div>
                <div className="grid gap-2 md:grid-cols-2">
                  {layer.map((t) => (
                    <div key={t.id} className="rounded-lg border border-white/10 bg-black/20 p-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 text-sm font-medium text-white">{t.title}</div>
                        <Chip s={t.status} />
                      </div>
                      <div className="mt-1 flex flex-wrap gap-x-3 text-[11px] text-slate-500">
                        <span>{t.op}</span><span>queue {t.queue}</span><span>tier {t.tier}</span>{t.agent_name && <span>{t.agent_name}</span>}
                        {t.attempts > 1 && <span className="text-amber-300">attempt {t.attempts}</span>}{dur(t.started_at, t.finished_at) && <span>{dur(t.started_at, t.finished_at)}</span>}
                      </div>
                      {summarize(t) && <div className="mt-2 text-xs text-slate-300">{summarize(t)}</div>}
                      {t.error && <div className="mt-2 text-xs text-rose-300">{t.error}</div>}
                      {t.output && !big && (
                        <details className="mt-2"><summary className="cursor-pointer text-[11px] text-slate-500">output</summary>
                          <pre className="mt-1 max-h-48 overflow-auto rounded bg-black/40 p-2 text-[11px] text-slate-400">{JSON.stringify({ ...t.output, markdown: t.output.markdown ? "(see deliverable)" : undefined }, null, 1).slice(0, 2500)}</pre>
                        </details>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Card>
        <div className="space-y-6">
          {gaunt.length > 0 && (
            <Card title="Gauntlet loop" right={<span className="text-xs text-slate-500">independent critic · blind A/B</span>}>
              <ol className="space-y-3">
                {gaunt.map((r) => (
                  <li key={r.round} className="text-sm">
                    <div className="flex items-center justify-between"><span className="font-medium text-white">Round {r.round}</span><Chip s={r.gaps.length ? "ready" : "succeeded"}>{r.gaps.length ? `${r.gaps.length} gap(s)` : "no gaps: bar met"}</Chip></div>
                    {r.gaps.map((g: any) => <div key={g.id} className="mt-1 text-xs text-slate-400">✗ {g.message}</div>)}
                    {r.applied?.length > 0 && <div className="mt-1 text-xs text-emerald-300/80">builder fixed: {r.applied.join(", ")}</div>}
                    {r.blind && <div className="mt-1 text-xs text-slate-500">blind verdict: critic picked {r.blind.picked} → the <b>{r.blind.pickedIs}</b> version (A={r.blind.labels.A}, weights {r.blind.weightA} vs {r.blind.weightB})</div>}
                  </li>
                ))}
              </ol>
              <p className="mt-3 text-xs text-slate-500">Bar: {wu.bar}</p>
            </Card>
          )}
          {arts.rows.length > 0 && (
            <Card title="Artifacts (content-addressed)">
              {arts.rows.map((a: any) => <div key={a.sha256} className="text-sm text-slate-300">{a.name} <span className="text-xs text-slate-500">{a.bytes} B · sha256 {a.sha256.slice(0, 16)}…</span></div>)}
            </Card>
          )}
          <Card title="Receipts" right={<Link href="/governance" className="text-xs text-emerald-300 hover:underline">full ledger</Link>}>
            <ul className="space-y-1.5">
              {rcpt.rows.map((r: any) => (
                <li key={r.id} className="flex items-center justify-between gap-2 text-xs">
                  <span className="min-w-0 truncate text-slate-300">{r.action} <span className="text-slate-500">{String(r.resource).slice(0, 40)}</span></span>
                  <span className="flex shrink-0 items-center gap-1">{r.actor === "human" && <Chip s="active">human</Chip>}{r.side_effect && <Chip s="partial">effect</Chip>}<Chip s={r.decision} /></span>
                </li>
              ))}
              {rcpt.rows.length === 0 && <li className="text-xs text-slate-500">none yet</li>}
            </ul>
          </Card>
          <Card title="Execution plan legend">
            <ul className="space-y-1 text-xs text-slate-400">
              {[...new Set(tasks.map((t) => t.op))].map((op) => <li key={op}><span className="text-slate-200">{op}</span> - {OPS[op]?.label}</li>)}
            </ul>
          </Card>
        </div>
      </div>
    </Shell>
  );
}
