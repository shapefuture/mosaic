import Link from "next/link";
import { pool } from "@/db";
import { Shell } from "@/components/Shell";
import { Card, Chip, PageHeader, Stat, ago, micro } from "@/components/ui";
import { ApprovalButtons, CreateWorkForm } from "@/components/Controls";
import { gatewayConfig } from "@/lib/gateway/model";

export const dynamic = "force-dynamic";

export default async function Home() {
  const [stats, queues, work, approvals] = await Promise.all([
    pool.query(`SELECT (SELECT count(*)::int FROM agents) agents,
      (SELECT count(*)::int FROM sessions WHERE status='hibernated') hib,
      (SELECT count(*)::int FROM sessions WHERE status='active') act,
      (SELECT count(*)::int FROM tasks WHERE status='running') running,
      (SELECT count(*)::int FROM work_units WHERE status='completed' AND template NOT IN ('bench','test')) done,
      (SELECT COALESCE(sum(spent_micro),0)::bigint FROM work_units) spent,
      (SELECT count(*)::int FROM receipts) receipts`),
    pool.query(`SELECT q.*, (SELECT count(*)::int FROM tasks t WHERE t.queue=q.queue AND t.status='running') running, (SELECT count(*)::int FROM tasks t WHERE t.queue=q.queue AND t.status='ready') ready FROM queue_state q ORDER BY array_position(ARRAY['interactive','io','compute','browser'], q.queue)`),
    pool.query(`SELECT w.id, w.template, w.objective, w.status, w.created_at, a.name AS owner,
      (SELECT count(*)::int FROM tasks t WHERE t.work_unit_id=w.id) total,
      (SELECT count(*)::int FROM tasks t WHERE t.work_unit_id=w.id AND t.status IN ('succeeded','skipped')) done
      FROM work_units w JOIN agents a ON a.id=w.owner_agent_id WHERE w.template NOT IN ('bench','test') ORDER BY w.created_at DESC LIMIT 8`),
    pool.query(`SELECT a.id, a.kind, a.payload, a.requested_at, t.title FROM approvals a JOIN tasks t ON t.id=a.task_id WHERE a.status='pending' ORDER BY a.requested_at DESC LIMIT 5`),
  ]);
  const s = stats.rows[0];
  const gw = gatewayConfig();
  return (
    <Shell path="/">
      <PageHeader title="Command center" sub="Millions of identities, thousands of concurrent tasks, a tiny always-on footprint. An agent is a database record; a shared worker pool executes durable task graphs, then everything goes back to sleep." />
      {!gw.configured && (
        <div className="mb-5 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-sm text-amber-200">
          No model key configured (<code>AI_GATEWAY_API_KEY</code> or <code>OPENAI_API_KEY</code>). Planning, fetching, extraction, reduction and verification are deterministic and fully working; synthesis and breakthrough reasoning run in clearly labelled deterministic/worksheet mode until a key is set.
        </div>
      )}
      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-6">
        <Stat label="Agent identities" value={s.agents} sub="0 resident processes" />
        <Stat label="Hibernated sessions" value={s.hib.toLocaleString()} sub={`${s.act} active now`} />
        <Stat label="Running tasks" value={s.running} sub="shared worker pool" />
        <Stat label="Work units done" value={s.done} />
        <Stat label="Model spend" value={micro(s.spent)} sub={gw.configured ? "live gateway" : "local fallback: $0"} />
        <Stat label="Audit receipts" value={Number(s.receipts).toLocaleString()} sub="hash-chained" />
      </div>
      {approvals.rows.length > 0 && (
        <Card title="Waiting on a human" className="mb-6 border-violet-500/30">
          <div className="space-y-3">
            {approvals.rows.map((a) => (
              <div key={a.id} className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-sm text-white">{a.title} <Chip s={a.kind === "human_takeover" ? "awaiting_approval" : "pending"}>{a.kind === "human_takeover" ? "human takeover" : "approval"}</Chip></div>
                  <div className="text-xs text-slate-400">{String(a.payload.reason ?? "")}</div>
                </div>
                <div className="flex items-center gap-2">
                  {a.kind === "human_takeover" && <Link href="/browser" className="text-sm text-emerald-300 hover:underline">Open browser →</Link>}
                  <ApprovalButtons id={a.id} resume={a.kind === "human_takeover"} />
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
      <div className="grid gap-6 xl:grid-cols-[1.2fr_1fr]">
        <div className="space-y-6">
          <Card title="New Work Unit"><CreateWorkForm /></Card>
          <Card title="Recent work units" right={<span className="text-xs text-slate-500">Plan → fan-out → execute → join → verify → commit</span>}>
            {work.rows.length === 0 ? <p className="text-sm text-slate-400">Nothing yet. Create a Work Unit above, or run the acceptance suite on the Governance page.</p> : (
              <ul className="divide-y divide-white/5">
                {work.rows.map((w) => (
                  <li key={w.id}>
                    <Link href={`/work/${w.id}`} className="flex items-center justify-between gap-3 py-3 hover:bg-white/[0.03]">
                      <div className="min-w-0">
                        <div className="truncate text-sm text-white">{w.objective}</div>
                        <div className="text-xs text-slate-500">{w.template} · {w.owner} · {ago(w.created_at)}</div>
                      </div>
                      <div className="flex shrink-0 items-center gap-3">
                        <span className="text-xs text-slate-400">{w.done}/{w.total}</span>
                        <Chip s={w.status} />
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
        <Card title="Adaptive queues" right={<span className="text-xs text-slate-500">C_allowed = min(provider, queue, tenant, sandbox, budget)</span>}>
          <div className="space-y-4">
            {queues.rows.map((q) => (
              <div key={q.queue}>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <span className="font-medium text-white">{q.queue}</span>
                  <span className="text-xs text-slate-400">{q.running} running · {q.ready} waiting · limit {q.concurrency}/{q.max_concurrency}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-sky-400" style={{ width: `${Math.min(100, (q.running / Math.max(1, q.concurrency)) * 100)}%` }} />
                </div>
                <div className="mt-1 text-[11px] text-slate-500">p50 {Math.round(q.p50_ms)} ms · p95 {Math.round(q.p95_ms)} ms · error EWMA {(q.err_rate * 100).toFixed(0)}% · {q.completed} ok / {q.failed} failed</div>
              </div>
            ))}
          </div>
          <p className="mt-4 text-xs leading-relaxed text-slate-500">A feedback controller halves a queue&apos;s limit when its error rate spikes and grows it while there is backlog and the p95 is healthy. Interactive work never shares a queue with browser tasks.</p>
        </Card>
      </div>
    </Shell>
  );
}
