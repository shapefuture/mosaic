/* eslint-disable @typescript-eslint/no-explicit-any */
import { pool } from "@/db";
import { Shell } from "@/components/Shell";
import { Card, Chip, PageHeader, Stat, ago } from "@/components/ui";
import { RunBench } from "@/components/Controls";
import { gatewayConfig, providerState } from "@/lib/gateway/model";

export const dynamic = "force-dynamic";

const ADAPTERS = [
  ["Durable workflow", "Postgres DAG + lease scheduler (this app)", "Cloudflare Workflows · DBOS", "active"],
  ["Agent session storage", "Postgres hibernating sessions (this app)", "Agents SDK + PiHarness / Durable Object SQLite", "adapter"],
  ["Browser provider", "HTTP+DOM persistent contexts (this app)", "Browser Run / Playwright CDP / Browserbase", "adapter"],
  ["Code sandbox", "Tier-1 node:vm lite sandbox (this app)", "Cloudflare Containers · OpenSandbox · Firecracker", "adapter"],
  ["Object storage", "Content-addressed Postgres objects (this app)", "R2 / S3", "adapter"],
] as const;

const TIERS = [
  ["Tier 0 · no computer", "HTTP gateway, DB, deterministic functions, model gateway", "default", "active"],
  ["Tier 1 · lightweight", "node:vm sandbox (no I/O, CPU timeout) and pooled HTTP+DOM browser contexts", "compute / browser queues", "active"],
  ["Tier 2 · isolated computer", "Firecracker microVM / graphical desktop for untrusted code and native apps", "requires KVM hosts", "external"],
] as const;

export default async function Capacity() {
  const [qs, bench] = await Promise.all([
    pool.query("SELECT * FROM queue_state ORDER BY array_position(ARRAY['interactive','io','compute','browser'], queue)"),
    pool.query("SELECT * FROM benchmarks ORDER BY created_at DESC LIMIT 1"),
  ]);
  const b = bench.rows[0];
  const r = (b?.results ?? {}) as any;
  const gw = gatewayConfig();
  const pv = providerState();
  const Row = ({ k, v }: { k: string; v: any }) => <div className="flex justify-between gap-3 border-b border-white/5 py-1 text-sm"><span className="text-slate-400">{k}</span><span className="text-right text-slate-100">{v}</span></div>;
  return (
    <Shell path="/capacity">
      <PageHeader title="Capacity qualification" sub="Real measurements of this deployment, not platform claims. The metric that matters is verified work per GB of active memory and per dollar." />
      <Card title="Benchmark runner" className="mb-6" right={b && <Chip s={b.status === "done" ? "succeeded" : b.status === "failed" ? "failed" : "running"}>{b.status}</Chip>}>
        <RunBench running={b?.status === "running"} />
        <p className="mt-2 text-xs text-slate-500">1) N idle logical sessions (storage only; wake a sample and verify they return to sleep) · 2) M simultaneous I/O-bound tasks through the bounded scheduler · 3) K independent real HTTP subtasks. Bench data is excluded from normal views.</p>
      </Card>
      {b && (
        <div className="mb-6 grid gap-6 xl:grid-cols-3">
          <Card title="1 · Idle sessions" right={<span className="text-xs text-slate-500">{ago(b.created_at)}</span>}>
            {r.idleSessions ? (
              <>
                <Row k="Logical sessions" v={r.idleSessions.logicalSessions.toLocaleString()} />
                <Row k="Resident processes per session" v={r.idleSessions.residentProcessesPerSession} />
                <Row k="Active at rest / after waking sample" v={`${r.idleSessions.activeAtRest} / ${r.idleSessions.activeAfterWake}`} />
                <Row k="Sessions table size" v={`${r.idleSessions.tableMb} MB (${r.idleSessions.bytesPerSession} B each)`} />
                <Row k="Bulk create" v={`${r.idleSessions.createdMs} ms`} />
                <Row k={`Wake→turn→hibernate (${r.idleSessions.wokeAndHibernated})`} v={`p50 ${r.idleSessions.wakeTurnP50Ms} ms · p95 ${r.idleSessions.wakeTurnP95Ms} ms`} />
                <Row k="Avg RSS delta per turn" v={`${r.idleSessions.avgRssDeltaKbPerTurn} KB`} />
              </>
            ) : <p className="text-sm text-slate-400">running…</p>}
          </Card>
          <Card title="2 · Simultaneous I/O-bound tasks">
            {r.ioParallel ? (
              <>
                <Row k="Tasks / status" v={`${r.ioParallel.tasks} / ${r.ioParallel.status}`} />
                <Row k="Wall time" v={`${r.ioParallel.wallMs} ms`} />
                <Row k="Throughput" v={`${r.ioParallel.throughputPerSec} tasks/s`} />
                <Row k="Queue wait p50 / p95" v={`${r.ioParallel.queueWaitP50Ms} / ${r.ioParallel.queueWaitP95Ms} ms`} />
                <Row k="Peak concurrent tasks" v={r.ioParallel.peakConcurrentTasks} />
                <Row k="io queue limit after run" v={r.ioParallel.ioQueueConcurrencyAfter} />
                <Row k="DB transactions per task (≈, whole cluster)" v={r.ioParallel.dbTransactionsPerTask} />
                <Row k="Peak RSS delta" v={`${r.ioParallel.rssPeakDeltaMb} MB`} />
                <Row k="Succeeded / failed" v={`${r.ioParallel.succeeded} / ${r.ioParallel.failed}`} />
              </>
            ) : <p className="text-sm text-slate-400">waiting…</p>}
          </Card>
          <Card title="3 · Independent real subtasks (HTTP)">
            {r.fanout ? (
              <>
                <Row k="Subtasks / status" v={`${r.fanout.subtasks} / ${r.fanout.status}`} />
                <Row k="Wall time" v={`${r.fanout.wallMs} ms`} />
                <Row k="Throughput" v={`${r.fanout.throughputPerSec} reads/s`} />
                <Row k="Queue wait p50 / p95" v={`${r.fanout.queueWaitP50Ms} / ${r.fanout.queueWaitP95Ms} ms`} />
                <Row k="Run time p50 / p95" v={`${r.fanout.runP50Ms} / ${r.fanout.runP95Ms} ms`} />
                <Row k="Peak concurrent tasks" v={r.fanout.peakConcurrentTasks} />
                <Row k="DB transactions per task (≈)" v={r.fanout.dbTransactionsPerTask} />
                <Row k="Succeeded / failed" v={`${r.fanout.succeeded} / ${r.fanout.failed}`} />
              </>
            ) : <p className="text-sm text-slate-400">waiting…</p>}
          </Card>
        </div>
      )}
      {b?.status === "failed" && <div className="mb-6 rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 text-sm text-rose-200">Benchmark failed: {r.error}</div>}
      <div className="grid gap-6 xl:grid-cols-2">
        <Card title="Adaptive scheduler state">
          <table className="w-full text-left text-xs">
            <thead><tr className="text-slate-500"><th className="py-1">queue</th><th>limit</th><th>min–max</th><th>cap</th><th>p95</th><th>err</th><th>ok/fail</th></tr></thead>
            <tbody>{qs.rows.map((q: any) => <tr key={q.queue} className="border-t border-white/5"><td className="py-1.5 text-white">{q.queue}</td><td>{q.concurrency}</td><td>{q.min_concurrency}–{q.max_concurrency}</td><td>{q.provider_cap}</td><td>{Math.round(q.p95_ms)} ms</td><td>{(q.err_rate * 100).toFixed(0)}%</td><td>{q.completed}/{q.failed}</td></tr>)}</tbody>
          </table>
          <p className="mt-3 text-xs text-slate-500">C_allowed = min(C_provider, C_tenant, C_queue, C_sandbox, C_budget). Tenant and budget are enforced inside the claim query; sandbox is the browser pool&apos;s tab ceiling. Model provider concurrency: {pv.inflight}/{pv.limit} in flight, {pv.waiting} waiting ({gw.configured ? "live" : "no key: local fallback"}).</p>
        </Card>
        <Card title="Execution tiers">
          <div className="space-y-3">
            {TIERS.map(([n, d, u, s]) => <div key={n} className="rounded-lg bg-black/20 p-3"><div className="flex items-center justify-between"><span className="text-sm font-medium text-white">{n}</span><Chip s={s}>{s === "active" ? "available" : "not configured"}</Chip></div><div className="text-xs text-slate-400">{d}</div><div className="text-[11px] text-slate-500">{u}</div></div>)}
          </div>
        </Card>
      </div>
      <Card title="Replaceable adapters (portable Postgres-first target, Cloudflare-native swap points)" className="mt-6">
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
          {ADAPTERS.map(([n, impl, alt, s]) => <div key={n} className="rounded-lg border border-white/10 bg-black/20 p-3"><div className="flex items-center justify-between"><span className="text-sm font-medium text-white">{n}</span><Chip s={s} /></div><div className="mt-1 text-xs text-slate-300">{impl}</div><div className="mt-1 text-[11px] text-slate-500">swap: {alt}</div></div>)}
        </div>
        <p className="mt-3 text-xs text-slate-500">Cloudflare PiHarness, Durable Objects, Workflows, Queues, Containers and Browser Run require a Cloudflare account and cannot run inside this environment. The business model (identities, Work Units, authority, verification) is identical across both targets.</p>
      </Card>
    </Shell>
  );
}
