/* eslint-disable @typescript-eslint/no-explicit-any */
import Link from "next/link";
import { pool } from "@/db";
import { Shell } from "@/components/Shell";
import { Card, Chip, PageHeader, ago } from "@/components/ui";
import { ApprovalButtons, RunQualify } from "@/components/Controls";
import { verifyChain } from "@/lib/security/ledger";

export const dynamic = "force-dynamic";

export default async function Governance() {
  const [appr, run, rc, pol, cred, conn, chain] = await Promise.all([
    pool.query(`SELECT a.*, t.title, w.objective FROM approvals a JOIN tasks t ON t.id=a.task_id JOIN work_units w ON w.id=a.work_unit_id WHERE a.status='pending' ORDER BY a.requested_at`),
    pool.query("SELECT * FROM qualification_runs ORDER BY created_at DESC LIMIT 1"),
    pool.query("SELECT id, action, resource, decision, actor, side_effect, created_at, left(hash,10) h FROM receipts ORDER BY id DESC LIMIT 30"),
    pool.query("SELECT * FROM policies ORDER BY action"),
    pool.query("SELECT key, domains, created_at FROM credentials"),
    pool.query("SELECT * FROM connectors ORDER BY key"),
    verifyChain(1000),
  ]);
  const latest = run.rows[0];
  const checks = (latest?.results ?? []) as { id: string; title: string; passed: boolean; evidence: string; ms: number }[];
  return (
    <Shell path="/governance">
      <PageHeader title="Governance" sub="Authority is deterministic and lives outside the model: signed capability tokens, a default-deny gateway, org forbid rules, a credential broker, hash-chained receipts, and human approvals. An agent can request an action; it cannot authorize itself." />
      <Card title="Approval center" className="mb-6" right={<Chip s={appr.rowCount ? "awaiting_approval" : "succeeded"}>{appr.rowCount ? `${appr.rowCount} waiting` : "clear"}</Chip>}>
        {appr.rows.length === 0 ? <p className="text-sm text-slate-400">No pending approvals. Tasks that use brokered credentials or run operator-supplied code pause here.</p> : (
          <div className="space-y-3">
            {appr.rows.map((a: any) => (
              <div key={a.id} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-white/10 p-3">
                <div><div className="text-sm text-white">{a.title} <Chip s="awaiting_approval">{a.kind === "human_takeover" ? "human takeover" : "approval"}</Chip></div><div className="text-xs text-slate-400">{a.payload.reason} · <Link className="text-emerald-300 hover:underline" href={`/work/${a.work_unit_id}`}>{String(a.objective).slice(0, 60)}</Link></div></div>
                <div className="flex items-center gap-3">{a.kind === "human_takeover" && <Link href="/browser" className="text-sm text-emerald-300 hover:underline">Browser →</Link>}<ApprovalButtons id={a.id} resume={a.kind === "human_takeover"} /></div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card title="Acceptance & red-team suite" className="mb-6" right={latest && <span className="text-xs text-slate-500">last run {ago(latest.created_at)} · {latest.passed}/{latest.passed + latest.failed} passed</span>}>
        <p className="mb-3 text-sm text-slate-400">Live checks against this running system: privilege escalation, token forgery, SSRF, prompt injection, credential leakage, cross-agent access, worker death after a side effect, duplicate events, unbounded fan-out, tamper-evident ledger, idle footprint, and an end-to-end verified browser + research run with a human takeover. Results are persisted, not mocked.</p>
        <RunQualify />
        {checks.length > 0 && (
          <div className="mt-4 divide-y divide-white/5">
            {checks.map((c) => (
              <div key={c.id} className="flex gap-3 py-2.5">
                <div className="pt-0.5"><Chip s={c.passed ? "succeeded" : "failed"}>{c.passed ? "PASS" : "FAIL"}</Chip></div>
                <div className="min-w-0"><div className="text-sm text-white">{c.title}</div><div className="break-words text-xs text-slate-400">{c.evidence} <span className="text-slate-600">({c.ms} ms)</span></div></div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <div className="grid gap-6 xl:grid-cols-2">
        <Card title="Receipt ledger" right={<Chip s={chain.intact ? "succeeded" : "failed"}>{chain.intact ? `chain intact · ${chain.checked} checked` : `broken at ${chain.brokenAt}`}</Chip>}>
          <div className="max-h-96 overflow-auto">
            <table className="w-full text-left text-xs">
              <thead><tr className="text-slate-500"><th className="py-1">#</th><th>action</th><th>resource</th><th>by</th><th></th></tr></thead>
              <tbody>
                {rc.rows.map((r: any) => (
                  <tr key={r.id} className="border-t border-white/5"><td className="py-1 pr-2 text-slate-500">{r.id}</td><td className="pr-2 text-slate-200">{r.action}{r.side_effect ? " ⚑" : ""}</td><td className="max-w-[160px] truncate pr-2 text-slate-400">{r.resource}</td><td className="pr-2 text-slate-400">{r.actor}</td><td><Chip s={r.decision} /></td></tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-2 text-[11px] text-slate-500">Only meaningful boundaries are recorded: authorizations, side effects, approvals, commits. Never streamed tokens. ⚑ = external side effect with idempotency key.</p>
        </Card>
        <div className="space-y-6">
          <Card title="Org forbid rules (always override permit)">
            <ul className="space-y-1.5 text-sm">{pol.rows.map((p: any) => <li key={p.id} className="flex justify-between gap-2"><span className="text-slate-200">forbid <code className="text-rose-300">{p.action}</code> on <code className="text-rose-300">{p.resource_pattern}</code></span><span className="text-xs text-slate-500">{p.description}</span></li>)}</ul>
          </Card>
          <Card title="Credential broker vault">
            {cred.rows.map((c: any) => <div key={c.key} className="flex items-center justify-between text-sm"><span className="text-slate-200">{`{{cred:${c.key}.*}}`}</span><span className="text-xs text-slate-400">bound to {c.domains.join(", ")} · AES-256-GCM · value never shown</span></div>)}
            <p className="mt-2 text-xs text-slate-500">Models only ever see placeholders. The broker substitutes the real value at the execution boundary, and only for domains the credential is bound to.</p>
          </Card>
        </div>
      </div>

      <Card title="Connector catalog" className="mt-6" right={<span className="text-xs text-slate-500">one shared gateway, filtered per agent by capability</span>}>
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {conn.rows.map((c: any) => (
            <div key={c.key} className="rounded-lg border border-white/10 bg-black/20 p-3">
              <div className="flex items-center justify-between"><span className="text-sm font-medium text-white">{c.key}</span><Chip s="succeeded">{c.health}</Chip></div>
              <div className="text-xs text-slate-500">{c.provider} · auth {c.auth_type} · {c.rate_limit_per_min}/min</div>
              <div className="mt-1 text-[11px] text-slate-400">{c.supported_actions.join(", ")}</div>
              {c.approval_required.length > 0 && <div className="mt-1 text-[11px] text-violet-300">approval: {c.approval_required.join(", ")}</div>}
              <div className="mt-1 text-[11px] text-slate-500">{c.docs}</div>
            </div>
          ))}
        </div>
      </Card>
    </Shell>
  );
}
