/* eslint-disable @typescript-eslint/no-explicit-any */
import Link from "next/link";
import { pool } from "@/db";
import { Shell } from "@/components/Shell";
import { Card, Chip, PageHeader, Stat, ago, micro } from "@/components/ui";
import { SessionChat } from "@/components/Controls";

export const dynamic = "force-dynamic";

export default async function AgentsPage({ searchParams }: { searchParams: Promise<{ s?: string }> }) {
  const { s } = await searchParams;
  const agents = (await pool.query(`SELECT a.*, 
      (SELECT count(*)::int FROM tasks t WHERE t.agent_id=a.id AND t.status='running') running,
      (SELECT count(*)::int FROM sessions x WHERE x.agent_id=a.id AND x.title NOT LIKE 'bench-session-%') sessions,
      (SELECT count(*)::int FROM tasks t WHERE t.agent_id=a.id AND t.status='succeeded') done FROM agents a ORDER BY a.created_at, a.slug`)).rows as any[];
  const counts = (await pool.query("SELECT count(*)::int total, count(*) FILTER (WHERE status='hibernated')::int hib, count(*) FILTER (WHERE status='active')::int act, COALESCE(max(wake_count),0)::int maxwake FROM sessions")).rows[0];
  const sessions = (await pool.query("SELECT s.id, s.title, s.status, s.turn_count, s.wake_count, s.last_active_at, a.name FROM sessions s JOIN agents a ON a.id=s.agent_id WHERE s.title NOT LIKE 'bench-session-%' ORDER BY s.last_active_at DESC LIMIT 12")).rows;
  const selected = s ? (await pool.query("SELECT id, title, status, transcript FROM sessions WHERE id=$1", [s])).rows[0] : sessions[0] ? (await pool.query("SELECT id, title, status, transcript FROM sessions WHERE id=$1", [sessions[0].id])).rows[0] : null;
  const children = (id: string | null) => agents.filter((a) => (a.manager_id ?? null) === id);
  const Node = ({ a, level }: { a: any; level: number }) => (
    <div style={{ marginLeft: level * 20 }} className="mb-2">
      <div className="rounded-lg border border-white/10 bg-black/20 p-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div><span className="font-medium text-white">{a.name}</span> <span className="text-xs text-slate-500">{a.role} · {a.slug}</span></div>
          <div className="flex items-center gap-2"><Chip s={a.running ? "running" : "hibernated"}>{a.running ? `${a.running} running` : "asleep"}</Chip></div>
        </div>
        <div className="mt-2 grid gap-1 text-[11px] text-slate-400 md:grid-cols-2">
          <div>actions: <span className="text-slate-300">{a.authority_policy.actions.join(", ")}</span></div>
          <div>domains: <span className="text-slate-300">{a.authority_policy.domains.join(", ") || "none"}</span></div>
          <div>delegation depth {a.authority_policy.delegationDepth} · {a.sessions} session(s) · {a.done} tasks done · spent {micro(a.spent_micro)}</div>
          <div>skills: <span className="text-slate-300">{a.skills.join(", ") || "-"}</span></div>
        </div>
      </div>
      {children(a.id).map((c) => <Node key={c.id} a={c} level={level + 1} />)}
    </div>
  );
  return (
    <Shell path="/agents">
      <PageHeader title="Agents & sessions" sub="Identity, role, capabilities and authority live in Postgres. A session wakes for a turn, commits its transcript and hibernates. Nothing here is a process." />
      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Agent identities" value={agents.length} sub="rows, not processes" />
        <Stat label="Logical sessions" value={Number(counts.total).toLocaleString()} sub={`${Number(counts.hib).toLocaleString()} hibernated`} />
        <Stat label="Active sessions" value={counts.act} sub="only while a turn runs" />
        <Stat label="Most wakes (one session)" value={counts.maxwake} />
      </div>
      <div className="grid gap-6 xl:grid-cols-2">
        <Card title="Organization chart & authority policies">{children(null).map((a) => <Node key={a.id} a={a} level={0} />)}</Card>
        <div className="space-y-6">
          <Card title="Sessions">
            <div className="mb-3 flex flex-wrap gap-2">
              {sessions.map((x) => (
                <Link key={x.id} href={`/agents?s=${x.id}`} className={`rounded-lg border px-2.5 py-1.5 text-xs ${selected?.id === x.id ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-200" : "border-white/10 text-slate-300 hover:bg-white/5"}`}>
                  {x.name} <span className="text-slate-500">· {x.turn_count} turns · {ago(x.last_active_at)}</span> <Chip s={x.status} />
                </Link>
              ))}
            </div>
            {selected && <SessionChat sessionId={selected.id} transcript={selected.transcript.slice(-30)} />}
            <p className="mt-3 text-xs text-slate-500">Message the Chief of Staff to delegate: its child Work Units inherit an attenuated slice of its authority. Specialists run under their own, narrower policy.</p>
          </Card>
        </div>
      </div>
    </Shell>
  );
}
