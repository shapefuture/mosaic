import { sendMessage } from "@/lib/engine/sessions";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = (await req.json().catch(() => ({}))) as { text?: string };
  if (!body.text?.trim()) return Response.json({ error: "text required" }, { status: 400 });
  try {
    return Response.json(await sendMessage(id, body.text));
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 404 });
  }
}
