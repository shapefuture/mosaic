import { rand } from "@/lib/util";
import { browserAct, browserView, getContextById, mintLiveToken, verifyLiveToken, type BrowserAction } from "@/lib/tools/browser";

export const dynamic = "force-dynamic";

/**
 * Human-facing browser control. Two entry points:
 *  - { token, action }  : Live View (bearer link, time-limited, revocable)
 *  - { contextId, mint: true } : mint a Live View link for an authenticated operator
 * Agent-facing browser ops never return these links.
 */
export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { token?: string; contextId?: string; mint?: boolean; action?: BrowserAction };
  if (body.mint && body.contextId) {
    const ctx = await getContextById(body.contextId);
    if (!ctx) return Response.json({ error: "no such context" }, { status: 404 });
    return Response.json({ url: `/browser/live/${mintLiveToken(ctx)}`, expiresInSec: 900 });
  }
  if (!body.token || !body.action) return Response.json({ error: "token and action required" }, { status: 400 });
  const ctx = await verifyLiveToken(body.token);
  if (!ctx) return Response.json({ error: "Live View link is invalid, expired or revoked" }, { status: 403 });
  try {
    await browserAct(ctx.id, body.action, { actor: "human", allowHost: () => true, idemKey: body.action.do === "submit" ? `human:${rand(6)}` : undefined });
    return Response.json({ view: await browserView(ctx.id) });
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 400 });
  }
}
