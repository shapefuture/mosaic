import { ensureSeed } from "@/lib/engine/seed";
import { startBenchmark } from "@/lib/engine/bench";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { sessions?: number; ioTasks?: number; fanout?: number };
  const orgId = await ensureSeed();
  const id = await startBenchmark(orgId, body);
  return Response.json({ id });
}
