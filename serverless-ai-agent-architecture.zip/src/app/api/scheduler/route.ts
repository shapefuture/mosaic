import { ensureLiveness, schedulerStatus } from "@/lib/engine/scheduler";
import { ensureSeed } from "@/lib/engine/seed";

export const dynamic = "force-dynamic";

/** Poked by the UI while work is active (and usable as an external cron). No resident supervisor required. */
export async function GET() {
  await ensureSeed();
  await ensureLiveness();
  return Response.json(schedulerStatus());
}
