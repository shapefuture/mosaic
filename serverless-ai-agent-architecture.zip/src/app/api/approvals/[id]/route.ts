import { decideApproval } from "@/lib/engine/scheduler";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = (await req.json().catch(() => ({}))) as { approve?: boolean; note?: string };
  const r = await decideApproval(id, body.approve !== false, body.note);
  return Response.json(r, { status: r.ok ? 200 : 404 });
}
