import { pool } from "@/db";
import { ensureSeed } from "@/lib/engine/seed";
import { runQualification } from "@/lib/engine/qualify";

export const dynamic = "force-dynamic";
export const maxDuration = 180;

export async function GET() {
  const r = await pool.query("SELECT * FROM qualification_runs ORDER BY created_at DESC LIMIT 1");
  return Response.json({ latest: r.rows[0] ?? null });
}

export async function POST() {
  const orgId = await ensureSeed();
  const checks = await runQualification(orgId);
  return Response.json({ checks, passed: checks.filter((c) => c.passed).length, total: checks.length });
}
