import { ensureSeed } from "@/lib/engine/seed";
import { choosePlan } from "@/lib/engine/planner";
import { createWorkUnit } from "@/lib/engine/scheduler";
import { pool } from "@/db";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed();
  const r = await pool.query(
    "SELECT id, template, objective, status, spent_micro, budget_micro, created_at, completed_at FROM work_units WHERE template NOT IN ('bench','test') ORDER BY created_at DESC LIMIT 50",
  );
  return Response.json({ workUnits: r.rows });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { objective?: string; template?: string; urls?: string[] | string; code?: string; data?: string; idempotencyKey?: string };
  const objective = (body.objective ?? "").trim();
  if (objective.length < 3 && !body.code) return Response.json({ error: "objective is required" }, { status: 400 });
  const orgId = await ensureSeed();
  let data: unknown = {};
  if (body.data) {
    try {
      data = JSON.parse(body.data);
    } catch {
      return Response.json({ error: "data must be valid JSON" }, { status: 400 });
    }
  }
  const urls = (Array.isArray(body.urls) ? body.urls : String(body.urls ?? "").split(/\s+/)).filter((u) => /^https?:\/\//.test(u));
  try {
    const plan = choosePlan(objective || "Run sandboxed computation", { template: body.template, urls, code: body.code, data });
    const r = await createWorkUnit({ orgId, plan, objective: objective || "Run sandboxed computation", idempotencyKey: body.idempotencyKey });
    return Response.json({ id: r.id, duplicate: r.duplicate, template: plan.template, tasks: plan.specs.length });
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 400 });
  }
}
