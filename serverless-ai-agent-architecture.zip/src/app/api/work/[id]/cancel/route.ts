import { cancelWorkUnit } from "@/lib/engine/scheduler";

export const dynamic = "force-dynamic";

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await cancelWorkUnit(id);
  return Response.json({ ok: true });
}
