import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "AOS v3 · Hibernating agent operating system",
  description: "Event-driven, massively parallel agent OS: durable identities, hibernating sessions, bounded scheduler, persistent browsers, verified outcomes.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#070b14] text-slate-200 antialiased">{children}</body>
    </html>
  );
}
