/* eslint-disable @typescript-eslint/no-explicit-any */
import { pool } from "@/db";
import { Shell } from "@/components/Shell";
import { Card, Chip, PageHeader, Stat } from "@/components/ui";

export const dynamic = "force-dynamic";

const PHASES: Record<number, string> = {
  1: "Identity", 2: "Sessions", 3: "Work engine", 4: "Scheduler", 5: "Intelligence", 6: "Browser", 7: "Execution tiers",
  8: "Data & memory", 9: "Security", 10: "Quality & governance", 11: "Method & tracking",
};

export default async function Delivery() {
  const [reqs, run] = await Promise.all([
    pool.query("SELECT * FROM requirements ORDER BY phase, id"),
    pool.query("SELECT results, created_at FROM qualification_runs ORDER BY created_at DESC LIMIT 1"),
  ]);
  const checks = new Map<string, any>(((run.rows[0]?.results ?? []) as any[]).map((c) => [c.id, c]));
  const rows = reqs.rows as any[];
  const n = (s: string) => rows.filter((r) => r.status === s).length;
  const phases = [...new Set(rows.map((r) => r.phase))];
  return (
    <Shell path="/delivery">
      <PageHeader title="Delivery tracker" sub="Every requirement from the AOS v3 specification, mapped to evidence. A written plan, a polished slice or a green badge is not delivery: 'delivered' rows point at running code, and most link to a live check you can re-run on the Governance page. Anything that needs outside infrastructure is marked honestly, with its blocker." />
      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat label="Requirements" value={rows.length} />
        <Stat label="Delivered" value={n("delivered")} sub="running code in this app" />
        <Stat label="Adapter" value={n("adapter")} sub="local impl + swap point" />
        <Stat label="Partial" value={n("partial")} />
        <Stat label="External" value={n("external")} sub="needs outside infra" />
      </div>
      <div className="space-y-6">
        {phases.map((p) => (
          <Card key={p} title={`Phase ${p} · ${PHASES[p] ?? ""}`}>
            <div className="divide-y divide-white/5">
              {rows.filter((r) => r.phase === p).map((r) => {
                const c = r.check_id ? checks.get(r.check_id) : null;
                return (
                  <div key={r.id} className="grid gap-2 py-3 md:grid-cols-[70px_1fr_auto]">
                    <div className="text-xs text-slate-500">{r.id}</div>
                    <div>
                      <div className="text-sm font-medium text-white">{r.title}</div>
                      <div className="text-xs text-slate-400">{r.description}</div>
                      <div className="mt-1 text-xs text-slate-300">Evidence: {r.evidence}</div>
                      {r.blocker && <div className="mt-1 text-xs text-amber-300">Blocker: {r.blocker}</div>}
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <Chip s={r.status} />
                      {r.check_id && <span className="text-[11px] text-slate-500">live check: {c ? <b className={c.passed ? "text-emerald-300" : "text-rose-300"}>{c.passed ? "pass" : "FAIL"}</b> : "not run yet"}</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        ))}
      </div>
      <Card title="Method: how the supplied skills were applied" className="mt-6">
        <ul className="space-y-2 text-sm text-slate-300">
          <li><b className="text-white">Gauntlet loop</b> → the verifier. A builder and a separate critic with fresh context; the critic inspects the actual output against a named bar, compares previous vs revised blind with labels shuffled, and the loop continues until zero gaps or no improvement. Soft praise is impossible: hard gates only.</li>
          <li><b className="text-white">Full-plan delivery</b> → this tracker. The whole roadmap is recovered into requirements with evidence, honest blockers and live checks; status comes from the system, not from a plan; the verifier is independent of the builder.</li>
          <li><b className="text-white">Breakthrough engine</b> → the breakthrough template: dossier, five independent forced-lens solvers (reformulation, false constraint, TRIZ contradiction, maintaining force, far-transfer isomorph), a separate red team, then convergence to decisions with cheapest decisive tests.</li>
          <li><b className="text-white">AAA V7 spec</b> → the URL returned 404 and could not be read, so nothing was derived from it. Send the document if you want it applied.</li>
        </ul>
      </Card>
    </Shell>
  );
}
