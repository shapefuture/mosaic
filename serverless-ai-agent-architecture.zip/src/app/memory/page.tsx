/* eslint-disable @typescript-eslint/no-explicit-any */
import { pool } from "@/db";
import { Shell } from "@/components/Shell";
import { Card, Chip, PageHeader, ago } from "@/components/ui";
import { retrieveContext } from "@/lib/engine/memory";
import { ensureSeed } from "@/lib/engine/seed";

export const dynamic = "force-dynamic";

export default async function MemoryPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  const orgId = await ensureSeed();
  const [mems, skills, refs] = await Promise.all([
    pool.query("SELECT id, kind, scope, subject, content, trust, status, hits, source_url, created_at FROM memories ORDER BY created_at DESC LIMIT 60"),
    pool.query("SELECT id, name, version, description, status, tests, procedure, created_at FROM skills ORDER BY created_at DESC LIMIT 20"),
    q ? retrieveContext(orgId, q, null, 8) : Promise.resolve([]),
  ]);
  const by = (s: string) => mems.rows.filter((m: any) => m.status === s).length;
  return (
    <Shell path="/memory">
      <PageHeader title="Memory & skills" sub="Working memory stays tiny: an agent receives a handful of references, never a rebuilt profile. A background Memory Compiler turns finished work into candidates, checks contradictions, and promotes only corroborated, uncontested facts." />
      <div className="mb-6 grid gap-6 xl:grid-cols-[1fr_1fr]">
        <Card title="Retrieve a compact context package" right={<span className="text-xs text-slate-500">curated only · Postgres full-text · org scope</span>}>
          <form className="flex gap-2"><input name="q" defaultValue={q} placeholder="e.g. Acme Pro price" className="min-w-0 flex-1 rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm text-white outline-none" /><button className="rounded-lg bg-emerald-500 px-3 py-2 text-sm font-medium text-slate-950">Search</button></form>
          {q && <ul className="mt-3 space-y-2 text-sm">{refs.length ? refs.map((r) => <li key={r.id} className="rounded-lg bg-black/20 p-2 text-slate-200">{r.content} <span className="text-xs text-slate-500">trust {r.trust}</span></li>) : <li className="text-slate-400">No curated memory matches. Candidates and contested facts are never retrieved.</li>}</ul>}
        </Card>
        <Card title="Compiler status">
          <div className="grid grid-cols-3 gap-3 text-center">
            {[["curated", by("curated")], ["candidate", by("candidate")], ["contested", by("contested")]].map(([k, v]) => <div key={k as string} className="rounded-lg bg-black/20 p-3"><div className="text-2xl font-semibold text-white">{v}</div><Chip s={k as string} /></div>)}
          </div>
          <p className="mt-3 text-xs text-slate-500">Same entity + same value from ≥2 sources → curated. Same entity with different values → contested, never promoted. Content from sources that tripped the injection detector is never promoted.</p>
        </Card>
      </div>
      <div className="grid gap-6 xl:grid-cols-[1.4fr_1fr]">
        <Card title="Memory records">
          {mems.rows.length === 0 ? <p className="text-sm text-slate-400">Empty. Complete a research Work Unit and the compiler populates this in the background.</p> : (
            <div className="max-h-[560px] overflow-auto">
              <table className="w-full text-left text-xs">
                <thead><tr className="text-slate-500"><th className="py-1">status</th><th>kind</th><th>content</th><th>hits</th><th></th></tr></thead>
                <tbody>{mems.rows.map((m: any) => <tr key={m.id} className="border-t border-white/5 align-top"><td className="py-1.5 pr-2"><Chip s={m.status} /></td><td className="pr-2 text-slate-400">{m.kind}<br />{m.scope}</td><td className="pr-2 text-slate-200">{m.content}</td><td className="pr-2 text-slate-400">{m.hits}</td><td className="text-slate-500">{ago(m.created_at)}</td></tr>)}</tbody>
              </table>
            </div>
          )}
        </Card>
        <Card title="Procedural memory: versioned skills">
          {skills.rows.length === 0 ? <p className="text-sm text-slate-400">Skills are generated only after a verified successful run, and only if the distilled procedure tests clean.</p> : (
            <div className="space-y-3">
              {skills.rows.map((s: any) => (
                <div key={s.id} className="rounded-lg border border-white/10 bg-black/20 p-3">
                  <div className="flex items-center justify-between"><span className="text-sm font-medium text-white">{s.name} <span className="text-xs text-slate-500">v{s.version}</span></span><Chip s={s.status} /></div>
                  <div className="text-xs text-slate-400">{s.description}</div>
                  <div className="mt-1 text-[11px] text-slate-500">{(s.procedure.steps ?? []).map((x: any) => x.op).join(" → ")}</div>
                  <div className="mt-1 text-[11px] text-slate-500">tests: dag valid {String(s.tests.dagValid)} · gauntlet passed {String(s.tests.gauntletPassed)} · hash {s.tests.procedureHash}</div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </Shell>
  );
}
