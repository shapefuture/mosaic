/* eslint-disable @typescript-eslint/no-explicit-any */
import { pool } from "@/db";
import { Shell } from "@/components/Shell";
import { Card, Chip, PageHeader, Stat, ago } from "@/components/ui";
import { ApprovalButtons, LiveLinkButton } from "@/components/Controls";
import { MAX_TABS_PER_CONTEXT, MAX_TABS_PER_PROCESS, POOL_SIZE } from "@/lib/tools/browser";

export const dynamic = "force-dynamic";

export default async function BrowserPage() {
  const ctxs = (await pool.query(`SELECT b.*, a.name AS agent_name FROM browser_contexts b JOIN agents a ON a.id=b.agent_id ORDER BY b.updated_at DESC`)).rows as any[];
  const takeovers = (await pool.query(`SELECT a.*, t.title FROM approvals a JOIN tasks t ON t.id=a.task_id WHERE a.kind='human_takeover' AND a.status='pending'`)).rows as any[];
  const procs = Array.from({ length: POOL_SIZE }, (_, i) => {
    const id = `bp-${i + 1}`;
    const mine = ctxs.filter((c) => c.process_id === id);
    return { id, contexts: mine.length, tabs: mine.reduce((a, c) => a + c.tabs.length, 0) };
  });
  return (
    <Shell path="/browser">
      <PageHeader title="Persistent browsers" sub="Each agent has its own browser identity (cookies, tabs, downloads) that survives across turns and tasks. Identities are packed onto a small pool of processes with tab ceilings. A human can take over the same logged-in session." />
      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Browser identities" value={ctxs.length} sub="isolated cookie jars" />
        <Stat label="Pooled processes" value={POOL_SIZE} sub={`≤ ${MAX_TABS_PER_PROCESS} tabs each, ≤ ${MAX_TABS_PER_CONTEXT} per identity`} />
        <Stat label="Open tabs" value={ctxs.reduce((a, c) => a + c.tabs.length, 0)} />
        <Stat label="Takeovers waiting" value={takeovers.length} />
      </div>
      {takeovers.map((t) => (
        <Card key={t.id} title="Human takeover requested" className="mb-6 border-violet-500/40">
          <p className="text-sm text-slate-200">{t.payload.reason}</p>
          <p className="mt-1 text-xs text-slate-400">Task: {t.title}. For the demo CRM, the one-time code is <code className="rounded bg-white/10 px-1">424242</code>. Open Live View, enter it, then resume the task.</p>
          <div className="mt-3 flex flex-wrap items-center gap-3"><LiveLinkButton contextId={t.payload.contextId} label="Open Live View (takeover)" /><ApprovalButtons id={t.id} resume /></div>
        </Card>
      ))}
      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <Card title="Process pool">
          <div className="space-y-3">
            {procs.map((p) => (
              <div key={p.id}>
                <div className="mb-1 flex justify-between text-sm"><span className="text-white">{p.id}</span><span className="text-xs text-slate-400">{p.contexts} identities · {p.tabs}/{MAX_TABS_PER_PROCESS} tabs</span></div>
                <div className="h-2 rounded-full bg-white/10"><div className="h-full rounded-full bg-sky-400" style={{ width: `${Math.min(100, (p.tabs / MAX_TABS_PER_PROCESS) * 100)}%` }} /></div>
              </div>
            ))}
          </div>
          <p className="mt-4 text-xs leading-relaxed text-slate-500">This adapter drives pages over HTTP + DOM parsing (deterministic, cheap). JavaScript-rendered or visual pages need the CDP adapter (Browser Run / Playwright / Stagehand / Midscene), which implements the same <code>BrowserAction</code> interface. Contexts isolate cookies, not memory; process-level isolation needs separate processes.</p>
        </Card>
        <Card title="Identities">
          {ctxs.length === 0 ? <p className="text-sm text-slate-400">No browser identity yet. Run the “Browser + human MFA” sample from the Command page.</p> : (
            <div className="space-y-3">
              {ctxs.map((c) => (
                <div key={c.id} className="rounded-lg border border-white/10 bg-black/20 p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="text-sm text-white">{c.agent_name} <span className="text-xs text-slate-500">· {c.process_id} · updated {ago(c.updated_at)}</span></div>
                    <LiveLinkButton contextId={c.id} />
                  </div>
                  <div className="mt-2 text-xs text-slate-400">
                    {c.tabs.length} tab(s): {c.tabs.map((t: any) => t.title).join(" · ") || "none"}
                  </div>
                  <div className="mt-1 flex flex-wrap gap-1.5 text-[11px]">
                    {Object.entries(c.cookies).map(([h, ck]: any) => <Chip key={h} s="active">{h}: {Object.keys(ck).join(", ")}</Chip>)}
                    {c.downloads.map((d: any, i: number) => <Chip key={i} s="adapter">⬇ {d.name}</Chip>)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </Shell>
  );
}
