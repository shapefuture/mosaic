import Link from "next/link";
import { BrowserConsole } from "@/components/BrowserConsole";
import { browserView, verifyLiveToken } from "@/lib/tools/browser";

export const dynamic = "force-dynamic";

export default async function LivePage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const ctx = await verifyLiveToken(decodeURIComponent(token));
  const view = ctx ? await browserView(ctx.id) : null;
  return (
    <div className="min-h-screen bg-[#070b14] p-4 text-slate-200 md:p-8">
      <div className="mx-auto max-w-6xl">
        <div className="mb-4 flex items-center justify-between">
          <h1 className="text-xl font-semibold text-white">Live View · human takeover</h1>
          <Link href="/browser" className="text-sm text-emerald-300 hover:underline">← Browser pool</Link>
        </div>
        {!view ? (
          <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-6 text-rose-200">This Live View link is invalid, expired, or was revoked because the agent task resumed.</div>
        ) : (
          <BrowserConsole token={decodeURIComponent(token)} initial={JSON.parse(JSON.stringify(view))} />
        )}
      </div>
    </div>
  );
}
