import { pool } from "@/db";
import { sha256, sleep } from "@/lib/util";

/**
 * Model router + gateway. Deterministic code is preferred; the model is only called where it adds value.
 * Provider: any OpenAI-compatible endpoint (including Cloudflare AI Gateway / agentgateway) via env:
 *   AI_GATEWAY_BASE_URL (default https://api.openai.com/v1), AI_GATEWAY_API_KEY or OPENAI_API_KEY.
 * With no key configured the gateway reports `local` and callers use deterministic fallbacks (degraded=true).
 */
export type TaskKind = "classify" | "extract" | "research" | "plan" | "synthesize" | "reason" | "verify";

const LADDER: Record<TaskKind, "small" | "strong"> = {
  classify: "small",
  extract: "small",
  research: "small",
  plan: "strong",
  synthesize: "strong",
  reason: "strong",
  verify: "strong",
};
const PRICE_PER_MTOK: Record<string, [number, number]> = {
  small: [0.15, 0.6],
  strong: [2.5, 10],
};

export function gatewayConfig() {
  const key = process.env.AI_GATEWAY_API_KEY ?? process.env.OPENAI_API_KEY ?? "";
  return {
    configured: !!key,
    baseUrl: (process.env.AI_GATEWAY_BASE_URL ?? "https://api.openai.com/v1").replace(/\/$/, ""),
    key,
    models: {
      small: process.env.AOS_MODEL_SMALL ?? "gpt-4o-mini",
      strong: process.env.AOS_MODEL_STRONG ?? "gpt-4o",
    },
  };
}

export const routeModel = (kind: TaskKind) => LADDER[kind];

// Provider-level concurrency limiter that backs off on 429s.
const provider = { limit: 6, inflight: 0, waiters: [] as (() => void)[] };
async function acquire() {
  if (provider.inflight < provider.limit) {
    provider.inflight++;
    return;
  }
  await new Promise<void>((r) => provider.waiters.push(r));
  provider.inflight++;
}
function release() {
  provider.inflight--;
  provider.waiters.shift()?.();
}
export const providerState = () => ({ limit: provider.limit, inflight: provider.inflight, waiting: provider.waiters.length });

export type Completion = { text: string; model: string; cached: boolean; degraded: boolean; costMicro: number };

export async function complete(input: {
  kind: TaskKind;
  system: string;
  prompt: string;
  workUnitId?: string | null;
  agentId?: string | null;
  maxTokens?: number;
}): Promise<Completion> {
  const cfg = gatewayConfig();
  if (!cfg.configured) return { text: "", model: "local-deterministic", cached: false, degraded: true, costMicro: 0 };
  const tier = routeModel(input.kind);
  const model = cfg.models[tier];
  const key = sha256([model, input.system, input.prompt].join("\u0000"));
  const hit = await pool.query("SELECT response, tokens_in, tokens_out FROM llm_cache WHERE key=$1", [key]);
  if (hit.rows[0]) {
    await pool.query(
      "INSERT INTO usage_ledger (work_unit_id, agent_id, kind, model, cached) VALUES ($1,$2,$3,$4,true)",
      [input.workUnitId ?? null, input.agentId ?? null, input.kind, model],
    );
    return { text: hit.rows[0].response, model, cached: true, degraded: false, costMicro: 0 };
  }
  let lastErr = "";
  for (let attempt = 0; attempt < 3; attempt++) {
    await acquire();
    try {
      const res = await fetch(`${cfg.baseUrl}/chat/completions`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${cfg.key}` },
        body: JSON.stringify({
          model,
          max_tokens: input.maxTokens ?? 900,
          temperature: 0.2,
          messages: [
            { role: "system", content: input.system },
            { role: "user", content: input.prompt },
          ],
        }),
        signal: AbortSignal.timeout(45000),
      });
      if (res.status === 429 || res.status >= 500) {
        if (res.status === 429) provider.limit = Math.max(1, Math.floor(provider.limit / 2));
        lastErr = `provider HTTP ${res.status}`;
        await sleep(400 * 2 ** attempt);
        continue;
      }
      if (!res.ok) throw new Error(`provider HTTP ${res.status}`);
      const j = (await res.json()) as { choices: { message: { content: string } }[]; usage?: { prompt_tokens: number; completion_tokens: number } };
      const text = j.choices?.[0]?.message?.content ?? "";
      const tin = j.usage?.prompt_tokens ?? Math.ceil(input.prompt.length / 4);
      const tout = j.usage?.completion_tokens ?? Math.ceil(text.length / 4);
      const [pi, po] = PRICE_PER_MTOK[tier];
      const costMicro = Math.round(tin * pi + tout * po);
      provider.limit = Math.min(6, provider.limit + 1);
      await pool.query(
        "INSERT INTO llm_cache (key, response, model, tokens_in, tokens_out) VALUES ($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING",
        [key, text, model, tin, tout],
      );
      await pool.query(
        "INSERT INTO usage_ledger (work_unit_id, agent_id, kind, model, tokens_in, tokens_out, cost_micro) VALUES ($1,$2,$3,$4,$5,$6,$7)",
        [input.workUnitId ?? null, input.agentId ?? null, input.kind, model, tin, tout, costMicro],
      );
      return { text, model, cached: false, degraded: false, costMicro };
    } catch (e) {
      lastErr = (e as Error).message;
      await sleep(300 * 2 ** attempt);
    } finally {
      release();
    }
  }
  // Authorized fallback: degrade to deterministic path rather than fail the Work Unit.
  return { text: "", model: `fallback(${lastErr})`, cached: false, degraded: true, costMicro: 0 };
}
