/* eslint-disable @typescript-eslint/no-explicit-any */
import { randomUUID } from "node:crypto";
import { pool } from "@/db";
import { Fatal, glob, rand, percentile, sleep } from "@/lib/util";
import { type Authority, attenuate, signAuthority, verifyAuthority, POLICY_VERSION } from "@/lib/security/authority";
import { receipt } from "@/lib/security/ledger";
import { revokeLiveLinks } from "@/lib/tools/browser";
import { EXECUTORS, type OpCtx, type OpResult, type TaskRow, type WuRow } from "./executors";
import { verifyGauntlet } from "./verifyop";
import { compileMemory } from "./memory";
import { MAX_SPAWN, MAX_TASKS_PER_UNIT, OPS, type Plan, type TaskSpec, validateDag } from "./planner";

const ALL: Record<string, (c: OpCtx) => Promise<OpResult>> = { ...EXECUTORS, "verify.gauntlet": verifyGauntlet };

/** Baseline concurrency limits per queue. The feedback controller moves within [min,max]. */
export const QUEUE_DEFAULTS: Record<string, { c: number; min: number; max: number; provider: number }> = {
  interactive: { c: 8, min: 2, max: 16, provider: 32 },
  io: { c: 32, min: 4, max: 128, provider: 256 },
  compute: { c: 4, min: 1, max: 8, provider: 16 },
  browser: { c: 2, min: 1, max: 4, provider: 8 },
};

const WORKER = `w-${process.pid}-${rand(3)}`;
const inflight = new Set<Promise<void>>();
type Win = { lat: number[]; ok: number; fail: number; batchOk: number; batchFail: number; err: number };
const win: Record<string, Win> = {};
const g = globalThis as any;
g.__aos ??= { draining: false, ticks: 0, lastTickAt: 0 };

export const schedulerStatus = () => ({ draining: !!g.__aos.draining, ticks: g.__aos.ticks as number, inflight: inflight.size, worker: WORKER });

// ------------------------------------------------------------------ creation
export async function buildRootAuthority(agent: { id: string; authorityPolicy: any }, workUnitId: string, budgetMicro: number, sessionId?: string): Promise<Authority> {
  const p = agent.authorityPolicy;
  return {
    jti: rand(8), agent_id: agent.id, work_unit_id: workUnitId, session_id: sessionId,
    actions: p.actions, resources: p.resources, domains: p.domains,
    max_cost: Math.min(budgetMicro, p.maxCostMicro), expires_at: Math.floor(Date.now() / 1000) + 3600,
    delegation_depth: p.delegationDepth, policy_version: POLICY_VERSION,
  };
}

export async function createWorkUnit(input: {
  orgId: string;
  plan: Plan;
  objective: string;
  ownerAgentId?: string;
  sessionId?: string;
  idempotencyKey?: string;
  budgetMicro?: number;
  delegatedFromAgentId?: string;
  maxTasks?: number;
}): Promise<{ id: string; duplicate: boolean }> {
  if (input.idempotencyKey) {
    const ex = await pool.query("SELECT id FROM work_units WHERE idempotency_key=$1", [input.idempotencyKey]);
    if (ex.rows[0]) return { id: ex.rows[0].id, duplicate: true };
  }
  validateDag(input.plan.specs, input.maxTasks ?? MAX_TASKS_PER_UNIT);
  const agentRows = (await pool.query("SELECT id, slug, authority_policy AS \"authorityPolicy\" FROM agents WHERE org_id=$1", [input.orgId])).rows;
  const bySlug = new Map<string, any>(agentRows.map((a) => [a.slug, a]));
  const owner = input.ownerAgentId ? agentRows.find((a) => a.id === input.ownerAgentId) : bySlug.get(input.plan.ownerSlug);
  if (!owner) throw new Fatal(`no agent available for role ${input.plan.ownerSlug}`);
  const id = randomUUID();
  const budget = input.budgetMicro ?? input.plan.budgetMicro;
  let root = await buildRootAuthority(owner, id, budget, input.sessionId);
  if (input.delegatedFromAgentId) {
    const mgr = agentRows.find((a) => a.id === input.delegatedFromAgentId);
    if (mgr) {
      const mgrAuth = await buildRootAuthority(mgr, id, budget, input.sessionId);
      root = attenuate(mgrAuth, { agent_id: owner.id, work_unit_id: id, session_id: input.sessionId, actions: owner.authorityPolicy.actions, resources: owner.authorityPolicy.resources, domains: owner.authorityPolicy.domains, max_cost: root.max_cost }, false);
      root.delegation_depth = Math.min(root.delegation_depth, owner.authorityPolicy.delegationDepth);
    }
  }
  const ins = await pool.query(
    `INSERT INTO work_units (id, org_id, owner_agent_id, session_id, idempotency_key, template, objective, params, criteria, bar, authority_token, budget_micro)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) ON CONFLICT (idempotency_key) DO NOTHING RETURNING id`,
    [id, input.orgId, owner.id, input.sessionId ?? null, input.idempotencyKey ?? null, input.plan.template, input.objective, JSON.stringify(input.plan.params), JSON.stringify(input.plan.criteria), input.plan.bar, signAuthority(root), budget],
  );
  if (!ins.rowCount) {
    const ex = await pool.query("SELECT id FROM work_units WHERE idempotency_key=$1", [input.idempotencyKey]);
    return { id: ex.rows[0].id, duplicate: true };
  }
  await insertTasks(id, input.plan.specs, bySlug);
  await receipt({ workUnitId: id, agentId: owner.id, actor: input.sessionId ? "agent" : "system", action: "work_unit.created", resource: `wu:${id}`, detail: { template: input.plan.template, tasks: input.plan.specs.length, authority: { jti: root.jti, parent: root.parent_jti, depth: root.delegation_depth, actions: root.actions.length } } });
  kick();
  return { id, duplicate: false };
}

async function insertTasks(workUnitId: string, specs: TaskSpec[], bySlug: Map<string, any>, client = pool) {
  for (let i = 0; i < specs.length; i += 200) {
    const chunk = specs.slice(i, i + 200);
    const vals: any[] = [];
    const rows = chunk.map((s, j) => {
      const o = OPS[s.op];
      const b = j * 12;
      vals.push(workUnitId, s.key, s.title, s.op, o.queue, o.tier, bySlug.get(s.agentSlug ?? "")?.id ?? null, JSON.stringify(s.input ?? {}), JSON.stringify(s.deps ?? []), !!s.softDeps, s.priority ?? 5, !!s.requiresApproval);
      return `($${b + 1},$${b + 2},$${b + 3},$${b + 4},$${b + 5},$${b + 6},$${b + 7},$${b + 8},$${b + 9},$${b + 10},$${b + 11},$${b + 12})`;
    });
    await client.query(
      `INSERT INTO tasks (work_unit_id, key, title, op, queue, tier, agent_id, input, deps, soft_deps, priority, requires_approval) VALUES ${rows.join(",")} ON CONFLICT (work_unit_id, key) DO NOTHING`,
      vals,
    );
  }
}

// ------------------------------------------------------------------ tick
export async function tick(): Promise<{ busy: boolean; claimed: number }> {
  g.__aos.ticks++;
  g.__aos.lastTickAt = Date.now();
  await reapLeases();
  await propagateFailures();
  await promote();
  await finalizeDone();
  const claimed = await claimAndDispatch();
  const busy = (await pool.query(`SELECT 1 FROM tasks t JOIN work_units w ON w.id=t.work_unit_id WHERE w.status='running' AND t.status IN ('pending','ready','running') LIMIT 1`)).rowCount! > 0;
  return { busy, claimed };
}

async function reapLeases() {
  const r = await pool.query(
    `UPDATE tasks SET status = CASE WHEN attempts >= max_attempts THEN 'failed' ELSE 'ready' END,
       error='lease expired: worker lost', worker_id=NULL, lease_until=NULL, ready_at=now(),
       finished_at = CASE WHEN attempts >= max_attempts THEN now() ELSE NULL END
     WHERE status='running' AND lease_until < now() RETURNING id, work_unit_id, status`,
  );
  for (const row of r.rows) await receipt({ workUnitId: row.work_unit_id, taskId: row.id, actor: "system", action: "task.lease_recovered", resource: row.id, detail: { next: row.status } });
}

async function propagateFailures() {
  await pool.query(
    `UPDATE tasks t SET status='cancelled', error='upstream dependency failed', finished_at=now()
     WHERE t.status='pending' AND NOT t.soft_deps AND EXISTS (
       SELECT 1 FROM jsonb_array_elements_text(t.deps) d(key) JOIN tasks p ON p.work_unit_id=t.work_unit_id AND p.key=d.key
       WHERE p.status IN ('failed','cancelled'))`,
  );
}

async function promote() {
  const r = await pool.query(
    `UPDATE tasks t SET
       status = CASE WHEN t.requires_approval AND t.approval_state='none' THEN 'awaiting_approval' ELSE 'ready' END,
       approval_state = CASE WHEN t.requires_approval AND t.approval_state='none' THEN 'pending' ELSE t.approval_state END,
       ready_at = now()
     WHERE t.status='pending'
       AND EXISTS (SELECT 1 FROM work_units w WHERE w.id=t.work_unit_id AND w.status='running')
       AND NOT EXISTS (
         SELECT 1 FROM jsonb_array_elements_text(t.deps) d(key)
         WHERE NOT EXISTS (SELECT 1 FROM tasks p WHERE p.work_unit_id=t.work_unit_id AND p.key=d.key
           AND (p.status IN ('succeeded','skipped') OR (t.soft_deps AND p.status IN ('failed','cancelled')))))
     RETURNING t.id, t.work_unit_id, t.status, t.title, t.op`,
  );
  for (const row of r.rows.filter((x) => x.status === "awaiting_approval")) {
    await pool.query("INSERT INTO approvals (work_unit_id, task_id, kind, payload) VALUES ($1,$2,'task',$3)", [row.work_unit_id, row.id, JSON.stringify({ title: row.title, op: row.op, reason: "Task requires human authorization before it may run." })]);
    await receipt({ workUnitId: row.work_unit_id, taskId: row.id, actor: "system", action: "approval.requested", resource: row.title });
  }
}

async function claimAndDispatch() {
  const qs = (await pool.query("SELECT * FROM queue_state")).rows;
  const counts = (await pool.query("SELECT queue, status, count(*)::int AS n FROM tasks WHERE status IN ('ready','running') GROUP BY queue, status")).rows;
  let total = 0;
  for (const q of qs) {
    const running = counts.find((c) => c.queue === q.queue && c.status === "running")?.n ?? 0;
    const ready = counts.find((c) => c.queue === q.queue && c.status === "ready")?.n ?? 0;
    // C_allowed = min(provider, queue, [tenant, budget inside the claim]); sandbox ceiling is the browser pool itself.
    let room = Math.min(q.concurrency, q.provider_cap) - running;
    if (room <= 0 || !ready) continue;
    const orgs = (
      await pool.query(
        `SELECT w.org_id, o.tenant_concurrency,
           (SELECT count(*)::int FROM tasks r JOIN work_units rw ON rw.id=r.work_unit_id WHERE rw.org_id=w.org_id AND r.status='running') AS running
         FROM tasks t JOIN work_units w ON w.id=t.work_unit_id JOIN organizations o ON o.id=w.org_id
         WHERE t.status='ready' AND t.queue=$1 AND t.ready_at<=now() AND w.status='running' AND w.spent_micro<w.budget_micro
         GROUP BY w.org_id, o.tenant_concurrency ORDER BY 3 ASC`,
        [q.queue],
      )
    ).rows;
    for (const org of orgs) {
      const share = Math.max(1, Math.ceil(room / orgs.length));
      const take = Math.min(share, room, org.tenant_concurrency - org.running);
      if (take <= 0) continue;
      const r = await pool.query(
        `WITH cand AS (
           SELECT t.id FROM tasks t JOIN work_units w ON w.id=t.work_unit_id
           WHERE t.status='ready' AND t.queue=$1 AND t.ready_at<=now() AND w.org_id=$2 AND w.status='running' AND w.spent_micro<w.budget_micro
           ORDER BY t.priority DESC, t.ready_at ASC LIMIT $3 FOR UPDATE OF t SKIP LOCKED)
         UPDATE tasks SET status='running', worker_id=$4, lease_until=now()+interval '45 seconds', started_at=now(), attempts=attempts+1, error=NULL
         WHERE id IN (SELECT id FROM cand) RETURNING id, work_unit_id, key, op, input, agent_id, attempts, deps, queue`,
        [q.queue, org.org_id, take, WORKER],
      );
      room -= r.rowCount ?? 0;
      total += r.rowCount ?? 0;
      for (const row of r.rows) launch(row as TaskRow & { queue: string });
      if (room <= 0) break;
    }
  }
  await adapt(qs, counts);
  return total;
}

function launch(row: TaskRow & { queue: string }) {
  const p: Promise<void> = runTask(row)
    .catch((e) => console.error("[aos] task runner crashed", e))
    .finally(() => inflight.delete(p));
  inflight.add(p);
}

// ------------------------------------------------------------------ execution
async function runTask(row: TaskRow & { queue: string }) {
  const t0 = Date.now();
  const w = (win[row.queue] ??= { lat: [], ok: 0, fail: 0, batchOk: 0, batchFail: 0, err: 0 });
  const hb = setInterval(() => {
    pool.query("UPDATE tasks SET lease_until=now()+interval '45 seconds' WHERE id=$1 AND worker_id=$2 AND attempts=$3 AND status='running'", [row.id, WORKER, row.attempts]).catch(() => {});
  }, 15000);
  try {
    const ctx = await buildCtx(row);
    const exec = ALL[row.op];
    if (!exec) throw new Fatal(`no executor for ${row.op}`);
    const res = await exec(ctx);
    await commitSuccess(row, res);
    w.batchOk++;
    w.ok++;
  } catch (e) {
    await commitFailure(row, e);
    if (!(e instanceof Fatal)) w.batchFail++; // policy denials are correct behaviour, not provider health signals
    w.fail++;
  } finally {
    clearInterval(hb);
    w.lat.push(Date.now() - t0);
    if (w.lat.length > 200) w.lat.splice(0, w.lat.length - 200);
  }
}

async function buildCtx(row: TaskRow): Promise<OpCtx> {
  const wu = (await pool.query("SELECT id, org_id, owner_agent_id, objective, template, criteria, params, authority_token FROM work_units WHERE id=$1", [row.work_unit_id])).rows[0];
  if (!wu) throw new Fatal("work unit vanished");
  const v = verifyAuthority(wu.authority_token);
  if (!v.ok) throw new Fatal(`root capability invalid: ${v.reason}`);
  const agentId = row.agent_id ?? wu.owner_agent_id;
  // Each task runs under the intersection of: the op's needs, the executing agent's own policy, and the root capability.
  const pol = (await pool.query("SELECT authority_policy FROM agents WHERE id=$1", [agentId])).rows[0]?.authority_policy as { actions: string[] } | undefined;
  const needed = (OPS[row.op]?.actions ?? []).filter((a) => !pol || pol.actions.some((p) => glob(p, a)));
  const child = attenuate(v.authority, { agent_id: agentId, work_unit_id: wu.id, actions: needed }, false);
  const deps: Record<string, any> = {};
  if (row.deps.length) {
    const r = await pool.query("SELECT key, output FROM tasks WHERE work_unit_id=$1 AND key = ANY($2::text[])", [row.work_unit_id, row.deps]);
    for (const d of r.rows) deps[d.key] = d.output;
  }
  return { task: row, wu: wu as WuRow, orgId: wu.org_id, agentId, token: signAuthority(child), authority: child, deps };
}

async function commitSuccess(row: TaskRow, res: OpResult) {
  const c = await pool.connect();
  try {
    await c.query("BEGIN");
    if (res.needsHuman) {
      const u = await c.query(
        `UPDATE tasks SET status='awaiting_approval', approval_state='pending', output=$3, attempts=GREATEST(attempts-1,0), worker_id=NULL, lease_until=NULL
         WHERE id=$1 AND worker_id=$2 AND attempts=$4 AND status='running' RETURNING id`,
        [row.id, WORKER, JSON.stringify(res.output), row.attempts],
      );
      if (!u.rowCount) return void (await c.query("ROLLBACK"));
      await c.query("INSERT INTO approvals (work_unit_id, task_id, kind, payload) VALUES ($1,$2,'human_takeover',$3)", [row.work_unit_id, row.id, JSON.stringify({ reason: res.needsHuman.reason, contextId: res.needsHuman.contextId })]);
      await c.query("COMMIT");
      await receipt({ workUnitId: row.work_unit_id, taskId: row.id, actor: "system", action: "human_takeover.requested", resource: res.needsHuman.contextId });
      return;
    }
    const u = await c.query(
      `UPDATE tasks SET status='succeeded', output=$3, cost_micro=$4, finished_at=now(), lease_until=NULL, error=NULL
       WHERE id=$1 AND worker_id=$2 AND attempts=$5 AND status='running' RETURNING id`,
      [row.id, WORKER, JSON.stringify(res.output), res.costMicro ?? 0, row.attempts],
    );
    if (!u.rowCount) {
      await c.query("ROLLBACK"); // fenced: a zombie worker may not overwrite a recovered task
      await receipt({ workUnitId: row.work_unit_id, taskId: row.id, actor: "system", action: "commit.fenced", resource: row.id, decision: "deny", detail: { worker: WORKER } });
      return;
    }
    if (res.spawn) {
      const cnt = (await c.query("SELECT count(*)::int AS n FROM tasks WHERE work_unit_id=$1", [row.work_unit_id])).rows[0].n as number;
      const specs = res.spawn.tasks.slice(0, MAX_SPAWN);
      if (cnt + specs.length > MAX_TASKS_PER_UNIT) throw new Fatal("fan-out would exceed task budget");
      const slugs = (await c.query("SELECT a.id, a.slug FROM agents a JOIN work_units w ON w.org_id=a.org_id WHERE w.id=$1", [row.work_unit_id])).rows;
      await insertTasks(row.work_unit_id, specs, new Map(slugs.map((a) => [a.slug, a])), c as any);
      await c.query(`UPDATE tasks SET deps = deps || $3::jsonb WHERE work_unit_id=$1 AND key=$2 AND status='pending'`, [row.work_unit_id, res.spawn.joinKey, JSON.stringify(specs.map((s) => s.key))]);
    }
    if (res.costMicro) {
      await c.query("UPDATE work_units SET spent_micro = spent_micro + $2 WHERE id=$1", [row.work_unit_id, res.costMicro]);
      await c.query("UPDATE organizations SET spent_micro = spent_micro + $2 WHERE id=(SELECT org_id FROM work_units WHERE id=$1)", [row.work_unit_id, res.costMicro]);
    }
    await c.query("COMMIT");
  } catch (e) {
    await c.query("ROLLBACK").catch(() => {});
    throw e;
  } finally {
    c.release();
  }
}

async function commitFailure(row: TaskRow, e: unknown) {
  const msg = (e instanceof Error ? e.message : String(e)).slice(0, 500);
  const retry = !(e instanceof Fatal);
  await pool.query(
    `UPDATE tasks SET
       status = CASE WHEN $3::boolean AND attempts < max_attempts THEN 'ready' ELSE 'failed' END,
       error=$4, worker_id=NULL, lease_until=NULL,
       ready_at = now() + (power(2, attempts) * 200 || ' milliseconds')::interval,
       finished_at = CASE WHEN $3::boolean AND attempts < max_attempts THEN NULL ELSE now() END
     WHERE id=$1 AND worker_id=$2 AND attempts=$5 AND status='running'`,
    [row.id, WORKER, retry, msg, row.attempts],
  );
}

// ------------------------------------------------------------------ adaptive concurrency (feedback control)
async function adapt(qs: any[], counts: any[]) {
  for (const q of qs) {
    const w = win[q.queue];
    if (!w || w.batchOk + w.batchFail + 0 === 0) {
      // slow recovery toward baseline when the queue is quiet
      const base = QUEUE_DEFAULTS[q.queue]?.c ?? q.concurrency;
      const backlog = counts.find((c) => c.queue === q.queue && c.status === "ready")?.n ?? 0;
      if (w && !backlog && q.concurrency < base) await pool.query("UPDATE queue_state SET concurrency=concurrency+1, updated_at=now() WHERE queue=$1", [q.queue]);
      continue;
    }
    const batch = w.batchOk + w.batchFail;
    w.err = 0.7 * w.err + 0.3 * (w.batchFail / batch);
    const okN = w.batchOk, failN = w.batchFail;
    w.batchOk = 0;
    w.batchFail = 0;
    const running = counts.find((c) => c.queue === q.queue && c.status === "running")?.n ?? 0;
    const backlog = counts.find((c) => c.queue === q.queue && c.status === "ready")?.n ?? 0;
    const p50 = percentile(w.lat, 0.5), p95 = percentile(w.lat, 0.95);
    let c = q.concurrency as number;
    if (w.err > 0.3 && batch >= 3) c = Math.max(q.min_concurrency, Math.floor(c / 2)); // multiplicative decrease
    else if (backlog > 0 && running + backlog >= c && w.err < 0.1 && p95 < 15000) c = Math.min(q.max_concurrency, q.provider_cap, c + Math.max(1, Math.ceil(c * 0.2))); // additive-ish increase
    await pool.query("UPDATE queue_state SET concurrency=$2, p50_ms=$3, p95_ms=$4, err_rate=$5, completed=completed+$6, failed=failed+$7, updated_at=now() WHERE queue=$1", [q.queue, c, p50, p95, w.err, okN, failN]);
  }
}

// ------------------------------------------------------------------ finalization
async function finalizeDone() {
  await pool.query(
    `UPDATE tasks SET status='cancelled', error='budget exhausted', finished_at=now()
     WHERE status IN ('pending','ready') AND work_unit_id IN (SELECT id FROM work_units WHERE status='running' AND spent_micro>=budget_micro)`,
  );
  const done = await pool.query(
    `SELECT w.id FROM work_units w WHERE w.status='running' AND NOT EXISTS (
       SELECT 1 FROM tasks t WHERE t.work_unit_id=w.id AND t.status IN ('pending','ready','running','awaiting_approval'))`,
  );
  for (const r of done.rows) await finalize(r.id);
}

async function finalize(id: string) {
  const tasks = (await pool.query("SELECT key, status, output, error, cost_micro, op FROM tasks WHERE work_unit_id=$1", [id])).rows;
  if (!tasks.length || tasks.some((t) => ["pending", "ready", "running", "awaiting_approval"].includes(t.status))) return; // lost a race with task insertion
  const verify = tasks.find((t) => t.key === "verify");
  const firstFail = tasks.find((t) => t.status === "failed" || t.status === "cancelled");
  let status = "completed";
  let error: string | null = null;
  let deliverable: string | null = null;
  if (verify) {
    if (verify.status === "succeeded" && verify.output?.passed) deliverable = verify.output.markdown;
    else {
      status = "failed";
      deliverable = verify.output?.markdown ?? null;
      error = verify.status === "succeeded" ? `verification failed: ${(verify.output.gaps ?? []).map((x: any) => x.id).join(", ") || "unknown gap"}` : `verification did not run - ${firstFail?.key ?? "upstream"}: ${firstFail?.error ?? "failed"}`;
    }
  } else {
    if (tasks.some((t) => t.status === "failed")) {
      status = "failed";
      error = `${firstFail?.key}: ${firstFail?.error}`;
    }
    const comp = tasks.find((t) => t.key === "compute");
    if (comp?.output) deliverable = "```json\n" + JSON.stringify(comp.output.result, null, 2) + "\n```";
  }
  const degraded = tasks.some((t) => t.output?.degraded === true);
  const result = {
    degraded,
    gauntlet: verify?.output?.rounds ?? null,
    modelCalls: tasks.reduce((a, t) => a + (Number(t.output?.modelCalls) || 0), 0),
    tasks: { total: tasks.length, succeeded: tasks.filter((t) => t.status === "succeeded").length, failed: tasks.filter((t) => t.status === "failed").length, cancelled: tasks.filter((t) => t.status === "cancelled").length },
  };
  const u = await pool.query(
    "UPDATE work_units SET status=$2, deliverable=$3, result=$4, error=$5, completed_at=now() WHERE id=$1 AND status='running' AND NOT EXISTS (SELECT 1 FROM tasks t WHERE t.work_unit_id=$1 AND t.status IN ('pending','ready','running','awaiting_approval')) RETURNING template, owner_agent_id",
    [id, status, deliverable, JSON.stringify(result), error],
  );
  if (!u.rowCount) return;
  await receipt({ workUnitId: id, agentId: u.rows[0].owner_agent_id, actor: "system", action: "work_unit.commit", resource: `wu:${id}`, decision: status === "completed" ? "allow" : "deny", detail: { status, error } });
  if (!["bench", "test"].includes(u.rows[0].template)) void compileMemory(id).catch((e) => console.error("[aos] memory compile failed", e));
}

// ------------------------------------------------------------------ human decisions
export async function decideApproval(approvalId: string, approve: boolean, note?: string) {
  const a = (await pool.query("UPDATE approvals SET status=$2, note=$3, decided_at=now() WHERE id=$1 AND status='pending' RETURNING *", [approvalId, approve ? "approved" : "denied", note ?? null])).rows[0];
  if (!a) return { ok: false as const, error: "approval not found or already decided" };
  if (a.kind === "human_takeover" && a.payload?.contextId) await revokeLiveLinks(a.payload.contextId); // Live View bearer links die on resolve
  if (approve) {
    await pool.query("UPDATE tasks SET status='ready', approval_state='granted', ready_at=now() WHERE id=$1 AND status='awaiting_approval'", [a.task_id]);
  } else {
    await pool.query("UPDATE tasks SET status='cancelled', approval_state='denied', error='denied by human', finished_at=now() WHERE id=$1", [a.task_id]);
  }
  await receipt({ workUnitId: a.work_unit_id, taskId: a.task_id, actor: "human", action: `approval.${approve ? "granted" : "denied"}`, resource: a.kind, detail: { note: note ?? null } });
  kick();
  return { ok: true as const };
}

export async function cancelWorkUnit(id: string) {
  await pool.query("UPDATE work_units SET status='cancelled', completed_at=now(), error='cancelled by human' WHERE id=$1 AND status='running'", [id]);
  await pool.query("UPDATE tasks SET status='cancelled', finished_at=now(), error='work unit cancelled' WHERE work_unit_id=$1 AND status IN ('pending','ready','running','awaiting_approval')", [id]);
  await pool.query("UPDATE approvals SET status='denied', decided_at=now() WHERE work_unit_id=$1 AND status='pending'", [id]);
  await receipt({ workUnitId: id, actor: "human", action: "work_unit.cancelled", resource: `wu:${id}` });
}

// ------------------------------------------------------------------ drain loop (event-driven, no timers when idle)
export function kick() {
  if (g.__aos.draining) return;
  g.__aos.draining = true;
  void drain()
    .catch((e) => console.error("[aos] drain error", e))
    .finally(async () => {
      g.__aos.draining = false;
      const again = await pool.query(`SELECT 1 FROM tasks t JOIN work_units w ON w.id=t.work_unit_id WHERE w.status='running' AND t.status IN ('pending','ready','running') LIMIT 1`).catch(() => ({ rowCount: 0 }));
      if (again.rowCount) kick();
    });
}

async function drain() {
  let idle = 0;
  while (idle < 3) {
    let busy = false;
    try {
      busy = (await tick()).busy;
    } catch (e) {
      console.error("[aos] tick failed", (e as Error).message);
    }
    idle = busy || inflight.size ? 0 : idle + 1;
    await sleep(busy ? 80 : 150);
  }
}

/** Called from page loads / health polling: recovers work after a restart without a resident supervisor. */
export async function ensureLiveness() {
  if (g.__aos.draining) return;
  const r = await pool.query(`SELECT 1 FROM tasks t JOIN work_units w ON w.id=t.work_unit_id WHERE w.status='running' AND t.status IN ('pending','ready','running') LIMIT 1`);
  if (r.rowCount) kick();
}

/** Wait helper for tests and benchmarks. */
export async function waitForWorkUnit(id: string, timeoutMs = 30000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    const r = await pool.query("SELECT status FROM work_units WHERE id=$1", [id]);
    if (r.rows[0] && r.rows[0].status !== "running") return r.rows[0].status as string;
    kick();
    await sleep(120);
  }
  return "timeout";
}
