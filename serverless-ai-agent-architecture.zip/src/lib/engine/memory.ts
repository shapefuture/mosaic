import { pool } from "@/db";
import { sha256 } from "@/lib/util";
import { validateDag } from "./planner";

export type MemoryRef = { id: string; kind: string; subject: string; content: string; trust: number; sourceUrl: string | null };

const tokens = (q: string) =>
  [...new Set(q.toLowerCase().match(/[a-z0-9]{3,}/g) ?? [])].slice(0, 12);

/** Compact working memory: a handful of references, never a profile rebuild. */
export async function retrieveContext(orgId: string, query: string, agentId?: string | null, limit = 5): Promise<MemoryRef[]> {
  const t = tokens(query);
  if (!t.length) return [];
  const { rows } = await pool.query(
    `SELECT id, kind, subject, content, trust, source_url AS "sourceUrl",
            ts_rank(to_tsvector('english', content), to_tsquery('english', $2)) AS r
     FROM memories
     WHERE org_id=$1 AND status='curated'
       AND (scope='org' OR (scope='agent' AND scope_ref=$3))
       AND to_tsvector('english', content) @@ to_tsquery('english', $2)
     ORDER BY r DESC, trust DESC LIMIT $4`,
    [orgId, t.join(" | "), agentId ?? "", limit],
  );
  return rows;
}

type AnalysisSource = { id: string; url: string; entity: string; sha: string; quarantined: boolean; prices: { label: string; amount: number; unit: string }[] };

/** Background Memory Compiler: candidate -> dedupe -> contradiction check -> promote. Off the critical path. */
export async function compileMemory(workUnitId: string) {
  const wu = (await pool.query("SELECT * FROM work_units WHERE id=$1", [workUnitId])).rows[0];
  if (!wu) return;
  const orgId = wu.org_id as string;
  const analysis = (await pool.query("SELECT output FROM tasks WHERE work_unit_id=$1 AND key='analyze' AND status='succeeded'", [workUnitId])).rows[0]?.output as
    | { sources?: AnalysisSource[] }
    | undefined;
  const subjects = new Set<string>();
  for (const s of analysis?.sources ?? []) {
    if (s.quarantined) continue; // untrusted content is never promoted
    for (const p of s.prices ?? []) {
      const subject = `${s.entity}:${p.label}`.toLowerCase();
      const value = `${p.amount}/${p.unit || "once"}`;
      const content = `${s.entity} ${p.label} costs $${p.amount}${p.unit ? "/" + p.unit : ""} (source ${s.url})`;
      subjects.add(subject);
      await pool.query(
        `INSERT INTO memories (org_id, scope, kind, subject, value, content, content_hash, source_url, evidence_sha, work_unit_id, trust, status)
         VALUES ($1,'org','semantic',$2,$3,$4,$5,$6,$7,$8,0.5,'candidate')
         ON CONFLICT (org_id, content_hash) DO UPDATE SET hits = memories.hits + 1`,
        [orgId, subject, value, content, sha256(orgId + subject + value + s.url), s.url, s.sha, workUnitId],
      );
    }
  }
  // Contradiction validation + promotion per subject.
  for (const subject of subjects) {
    const { rows } = await pool.query("SELECT id, value, source_url, hits FROM memories WHERE org_id=$1 AND subject=$2 AND kind='semantic' AND status<>'rejected'", [orgId, subject]);
    const values = new Set(rows.map((r) => r.value));
    if (values.size > 1) {
      await pool.query("UPDATE memories SET status='contested', trust=0.3 WHERE org_id=$1 AND subject=$2", [orgId, subject]);
      continue;
    }
    const sources = new Set(rows.map((r) => r.source_url));
    const hits = rows.reduce((a, r) => a + (r.hits as number), 0);
    if (sources.size >= 2 || hits >= 2) await pool.query("UPDATE memories SET status='curated', trust=0.85 WHERE org_id=$1 AND subject=$2", [orgId, subject]);
  }
  // Episodic memory: outcome of the work unit, scoped to the owning agent.
  const content = `Work unit "${String(wu.objective).slice(0, 140)}" (${wu.template}) ${wu.status}${wu.error ? ": " + wu.error : ""}.`;
  await pool.query(
    `INSERT INTO memories (org_id, scope, scope_ref, kind, subject, content, content_hash, work_unit_id, trust, status)
     VALUES ($1,'agent',$2,'episodic',$3,$4,$5,$6,1,'curated') ON CONFLICT (org_id, content_hash) DO NOTHING`,
    [orgId, wu.owner_agent_id, `wu:${wu.template}`, content, sha256("episode" + workUnitId), workUnitId],
  );
  await maybeCreateSkill(wu);
}

/** Procedural memory: generate a versioned skill only after the run verified successfully and the procedure tests clean. */
async function maybeCreateSkill(wu: Record<string, unknown>) {
  if (wu.status !== "completed" || wu.template === "compute" || wu.template === "bench") return;
  const t = (await pool.query("SELECT key, title, op, deps, soft_deps, input, requires_approval FROM tasks WHERE work_unit_id=$1 ORDER BY queued_at", [wu.id])).rows;
  const specs = t.map((r) => ({ key: r.key, title: r.title, op: r.op, deps: r.deps, softDeps: r.soft_deps, requiresApproval: r.requires_approval }));
  // Fan-out reads are folded into one parametric step so the skill is reusable for any source count.
  const folded = specs.filter((s) => !/^read_\d+$/.test(s.key)).map((s) => ({ key: s.key, op: s.op, deps: (s.deps as string[]).filter((d) => !/^read_\d+$/.test(d)).concat((s.deps as string[]).some((d) => /^read_\d+$/.test(d)) ? ["read_*"] : []) }));
  if (specs.some((s) => /^read_\d+$/.test(s.key))) folded.unshift({ key: "read_*", op: "web.read", deps: [] });
  const procedure = { template: wu.template, criteria: wu.criteria, bar: wu.bar, steps: folded };
  let dagOk = true;
  try {
    validateDag(specs.map((s) => ({ ...s, deps: s.deps as string[] })));
  } catch {
    dagOk = false;
  }
  const name = `${wu.template}-playbook`;
  const hash = sha256(JSON.stringify(procedure));
  const latest = (await pool.query("SELECT version, procedure FROM skills WHERE org_id=$1 AND name=$2 ORDER BY version DESC LIMIT 1", [wu.org_id, name])).rows[0];
  if (latest && sha256(JSON.stringify(latest.procedure)) === hash) return;
  const tests = { dagValid: dagOk, verifiedRun: wu.id, gauntletPassed: true, procedureHash: hash.slice(0, 12) };
  await pool.query(
    `INSERT INTO skills (org_id, name, version, description, procedure, status, tests, source_work_unit_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT DO NOTHING`,
    [wu.org_id, name, (latest?.version ?? 0) + 1, `Verified procedure distilled from "${String(wu.objective).slice(0, 80)}"`, JSON.stringify(procedure), dagOk ? "active" : "draft", JSON.stringify(tests), wu.id],
  );
}
