/* eslint-disable @typescript-eslint/no-explicit-any */
import { pool } from "@/db";
import { rand, sleep, PolicyDenied } from "@/lib/util";
import { EscalationError, type Authority, attenuate, signAuthority, verifyAuthority } from "@/lib/security/authority";
import { authorize } from "@/lib/security/policy";
import { receipt, verifyChain } from "@/lib/security/ledger";
import { safeFetch } from "@/lib/tools/http";
import { browserAct, getContextById, mintLiveToken, verifyLiveToken } from "@/lib/tools/browser";
import { appOrigin } from "@/lib/util";
import { type Plan, type TaskSpec, planCrm, planResearch, validateDag } from "./planner";
import { createWorkUnit, decideApproval, schedulerStatus, waitForWorkUnit } from "./scheduler";
import { gauntlet } from "./verify";
import { sendMessage } from "./sessions";

export type Check = { id: string; title: string; passed: boolean; evidence: string; ms: number };

const mkAuth = (o: Partial<Authority> = {}): Authority => ({
  jti: rand(4), agent_id: "agent-a", work_unit_id: "wu-test", actions: ["http.get"], resources: ["project:alpha"], domains: ["approved.example"],
  max_cost: 1000, expires_at: Math.floor(Date.now() / 1000) + 600, delegation_depth: 2, policy_version: "test", ...o,
});

export function syntheticPlan(specs: TaskSpec[], template = "test", ownerSlug = "research-analyst"): Plan {
  return { template, specs, criteria: {}, bar: "synthetic", ownerSlug, params: {}, budgetMicro: 5_000_000 };
}

async function timed(id: string, title: string, fn: () => Promise<{ ok: boolean; evidence: string }>): Promise<Check> {
  const t0 = Date.now();
  try {
    const r = await fn();
    return { id, title, passed: r.ok, evidence: r.evidence, ms: Date.now() - t0 };
  } catch (e) {
    return { id, title, passed: false, evidence: `threw: ${(e as Error).message}`, ms: Date.now() - t0 };
  }
}

async function driveCrm(orgId: string) {
  const { id } = await createWorkUnit({ orgId, plan: planCrm("Log in to the CRM and export the pipeline"), objective: "Log in to the CRM and export the pipeline (qualification run)" });
  let takeover = false;
  let liveRevoked: boolean | null = null;
  let approvedTask = false;
  const t0 = Date.now();
  while (Date.now() - t0 < 45000) {
    const st = (await pool.query("SELECT status FROM work_units WHERE id=$1", [id])).rows[0]?.status;
    if (st !== "running") break;
    const pend = (await pool.query("SELECT * FROM approvals WHERE work_unit_id=$1 AND status='pending'", [id])).rows;
    for (const a of pend) {
      if (a.kind === "task") {
        approvedTask = true;
        await decideApproval(a.id, true, "qualification: auto-approve credential use");
      } else if (a.payload?.contextId) {
        const ctx = await getContextById(a.payload.contextId);
        if (!ctx) continue;
        const old = mintLiveToken(ctx);
        const h = { actor: "human" as const, allowHost: () => true, workUnitId: id };
        await browserAct(ctx.id, { do: "type", form: 0, field: "code", value: "424242" }, h);
        await browserAct(ctx.id, { do: "submit", form: 0 }, { ...h, idemKey: `human:${rand(6)}` });
        await decideApproval(a.id, true, "human completed MFA in Live View");
        takeover = true;
        liveRevoked = (await verifyLiveToken(old)) === null;
      }
    }
    await sleep(120);
  }
  const status = await waitForWorkUnit(id, 10000);
  return { id, status, takeover, liveRevoked, approvedTask };
}

export async function runQualification(orgId: string): Promise<Check[]> {
  const checks: Check[] = [];
  // Long-running scenarios start first and run concurrently with the cheap checks.
  const researchUrls = ["acme-pricing", "acme-features", "globex-pricing", "injection"].map((s) => `${appOrigin()}/api/demo/pages/${s}`);
  const researchP = createWorkUnit({ orgId, plan: planResearch("Compare Acme, Globex and Hooli pricing for the Pro tier", researchUrls), objective: "Compare Acme, Globex and Hooli pricing for the Pro tier (qualification run)" }).then((r) => waitForWorkUnit(r.id, 40000).then((status) => ({ id: r.id, status })));
  const crmP = driveCrm(orgId);

  checks.push(await timed("attenuation", "No child task can hold more authority than its parent", async () => {
    const parent = mkAuth();
    let strictBlocked = false, depthBlocked = false;
    try { attenuate(parent, { agent_id: "c", work_unit_id: "w", actions: ["http.get", "admin.delete"] }, true); } catch (e) { strictBlocked = e instanceof EscalationError; }
    const clamped = attenuate(parent, { agent_id: "c", work_unit_id: "w", actions: ["http.get", "admin.delete"], domains: ["approved.example", "evil.example"], max_cost: 10 ** 9 });
    try { attenuate(mkAuth({ delegation_depth: 0 }), { agent_id: "c", work_unit_id: "w" }); } catch (e) { depthBlocked = e instanceof EscalationError; }
    const ok = strictBlocked && depthBlocked && clamped.actions.join() === "http.get" && clamped.domains.join() === "approved.example" && clamped.max_cost === 1000 && clamped.delegation_depth === 1;
    return { ok, evidence: `strict escalation refused=${strictBlocked}; depth-exhausted refused=${depthBlocked}; clamped actions=[${clamped.actions}] domains=[${clamped.domains}] max_cost=${clamped.max_cost}` };
  }));

  checks.push(await timed("tamper", "A tampered capability token is rejected (an agent cannot self-authorize)", async () => {
    const tok = signAuthority(mkAuth());
    const [body, sig] = tok.split(".");
    const forged = JSON.parse(Buffer.from(body, "base64url").toString());
    forged.actions = ["*"];
    const bad = verifyAuthority(`${Buffer.from(JSON.stringify(forged)).toString("base64url")}.${sig}`);
    return { ok: !bad.ok && verifyAuthority(tok).ok, evidence: `forged token -> ${bad.ok ? "ACCEPTED" : (bad as any).reason}` };
  }));

  checks.push(await timed("expiry", "Expired capabilities are rejected", async () => {
    const v = verifyAuthority(signAuthority(mkAuth({ expires_at: Math.floor(Date.now() / 1000) - 5 })));
    return { ok: !v.ok, evidence: v.ok ? "accepted expired token" : (v as any).reason };
  }));

  checks.push(await timed("domain", "Gateway denies off-allowlist domains; org forbid rules override permit", async () => {
    const t = signAuthority(mkAuth());
    const bad = await authorize({ token: t, action: "http.get", domain: "evil.example" });
    const good = await authorize({ token: t, action: "http.get", domain: "approved.example" });
    const wide = signAuthority(mkAuth({ domains: ["*"] }));
    const meta = await authorize({ token: wide, action: "http.get", domain: "169.254.169.254" });
    const noAction = await authorize({ token: t, action: "browser.submit", domain: "approved.example" });
    return { ok: !bad.allow && good.allow && !meta.allow && !noAction.allow, evidence: `off-list: ${bad.reason}; allowed: ${good.reason}; metadata with '*' grant: ${meta.reason}; ungranted action: ${noAction.reason}` };
  }));

  checks.push(await timed("ssrf", "Fetch gateway blocks private networks, loopback and non-HTTP schemes", async () => {
    const tries = ["http://169.254.169.254/latest/meta-data", "http://127.0.0.1:5432/", "http://10.0.0.5/admin", "file:///etc/passwd", "http://[::1]/"];
    const blocked: string[] = [];
    for (const u of tries) {
      try { await safeFetch(u, { allowHost: () => true, timeoutMs: 1500 }); } catch (e) { if (e instanceof PolicyDenied) blocked.push(new URL(u).protocol === "file:" ? "file" : new URL(u).hostname); }
    }
    return { ok: blocked.length === tries.length, evidence: `${blocked.length}/${tries.length} blocked: ${blocked.join(", ")}` };
  }));

  checks.push(await timed("cross-agent", "One agent's resources cannot be reached with another agent's capability", async () => {
    const a = signAuthority(mkAuth({ resources: ["browser:ctx/agent-a"] }));
    const own = await authorize({ token: a, action: "http.get", resource: "browser:ctx/agent-a" });
    const other = await authorize({ token: a, action: "http.get", resource: "browser:ctx/agent-b" });
    return { ok: own.allow && !other.allow, evidence: `own=${own.reason}; other=${other.reason}` };
  }));

  checks.push(await timed("gauntlet-catches", "Verifier catches unsupported figures, dangling citations, uncited claims; loop repairs or refuses", async () => {
    const evidence = [{ id: "S1", url: "x://a", sha: "a", text: "Acme Pro costs $49 per month" }];
    const draft = "# T\n\n## Executive summary\n- Acme Pro is $49 [S1]\n- Acme made $999 profit [S1]\n- Unsupported claim\n- Another [S9]\n\n## Findings\n- Pro is $49 [S1]\n";
    const base = { evidence, quarantined: [], derivedNumbers: [], sectionFixers: { Contradictions: "- none found" } };
    const fixed = gauntlet({ ...base, markdown: draft + "\n## Evidence index\n- S1", criteria: { minSources: 1, requiredSections: ["Executive summary", "Findings", "Contradictions"], requireCitations: true, noUnsupportedNumbers: true } });
    const refused = gauntlet({ ...base, markdown: "## Findings\n- x [S1]", criteria: { minSources: 3, requiredSections: ["Findings"], requireCitations: true } });
    const ok = fixed.passed && !fixed.markdown.includes("$999") && fixed.rounds.some((r) => r.blind) && !refused.passed;
    return { ok, evidence: `repaired in ${fixed.rounds.length} round(s), blind verdicts=${fixed.rounds.filter((r) => r.blind).map((r) => r.blind!.pickedIs).join(",")}; unfixable (too few sources) refused=${!refused.passed}` };
  }));

  checks.push(await timed("idempotent-effect", "A repeated external side effect is suppressed, not re-executed", async () => {
    const key = `qual-effect-${rand(5)}`;
    const a = await receipt({ action: "synthetic.effect", resource: key, sideEffect: true, idempotencyKey: key });
    const b = await receipt({ action: "synthetic.effect", resource: key, sideEffect: true, idempotencyKey: key });
    const n = (await pool.query("SELECT count(*)::int n FROM receipts WHERE side_effect AND idempotency_key=$1", [key])).rows[0].n;
    return { ok: !a.duplicate && b.duplicate && n === 1, evidence: `first duplicate=${a.duplicate}, second duplicate=${b.duplicate}, rows=${n}` };
  }));

  checks.push(await timed("dup-event", "A duplicated trigger event creates exactly one Work Unit", async () => {
    const key = `qual-dup-${rand(5)}`;
    const mk = () => createWorkUnit({ orgId, idempotencyKey: key, objective: "dup event", plan: syntheticPlan([{ key: "a", title: "noop", op: "synthetic.sleep", input: { ms: 5 }, agentSlug: "research-analyst" }]) });
    const [x, y] = await Promise.all([mk(), mk()]);
    const n = (await pool.query("SELECT count(*)::int n FROM work_units WHERE idempotency_key=$1", [key])).rows[0].n;
    return { ok: x.id === y.id && n === 1 && (x.duplicate || y.duplicate), evidence: `same id=${x.id === y.id}, rows=${n}, concurrent duplicate flagged=${x.duplicate || y.duplicate}` };
  }));

  checks.push(await timed("failure-recovery", "Worker death after a side effect: task recovered, effect not repeated, zombie commit fenced", async () => {
    const key = `qual-chaos-${rand(5)}`;
    const { id } = await createWorkUnit({ orgId, objective: "chaos: kill the worker mid-task", plan: syntheticPlan([{ key: "effect", title: "side effect then long work", op: "synthetic.sidefx", input: { key, ms: 1800 }, agentSlug: "research-analyst" }, { key: "after", title: "downstream task", op: "synthetic.sleep", deps: ["effect"], input: { ms: 20 }, agentSlug: "research-analyst" }]) });
    let killed = false;
    for (let i = 0; i < 80 && !killed; i++) {
      await sleep(60);
      const r = await pool.query("UPDATE tasks SET worker_id='dead-worker', lease_until=now()-interval '1 second' WHERE work_unit_id=$1 AND key='effect' AND status='running' RETURNING id", [id]);
      killed = (r.rowCount ?? 0) > 0;
    }
    const status = await waitForWorkUnit(id, 20000);
    await sleep(1800); // let the zombie finish and attempt its commit
    const t = (await pool.query("SELECT status, attempts, output FROM tasks WHERE work_unit_id=$1 AND key='effect'", [id])).rows[0];
    const effects = (await pool.query("SELECT count(*)::int n FROM receipts WHERE side_effect AND idempotency_key=$1", [key])).rows[0].n;
    const rec = (await pool.query("SELECT action FROM receipts WHERE work_unit_id=$1 AND action IN ('task.lease_recovered','commit.fenced')", [id])).rows.map((r) => r.action);
    const ok = killed && status === "completed" && effects === 1 && t.attempts >= 2 && rec.includes("task.lease_recovered");
    return { ok, evidence: `killed=${killed}, work unit=${status}, attempts=${t?.attempts}, side-effect receipts=${effects}, recovery receipts=[${rec.join(", ")}]` };
  }));

  checks.push(await timed("bounded-fanout", "Fan-out is bounded: unbounded plans refused; burst never exceeds queue ceilings", async () => {
    let refused = false;
    try { validateDag(Array.from({ length: 1001 }, (_, i) => ({ key: `k${i}`, title: "t", op: "synthetic.sleep" }))); } catch { refused = true; }
    const specs: TaskSpec[] = Array.from({ length: 90 }, (_, i) => ({ key: `b${i}`, title: `burst ${i}`, op: "synthetic.sleep", input: { ms: 90 }, agentSlug: "research-analyst" }));
    const { id } = await createWorkUnit({ orgId, plan: syntheticPlan(specs), objective: "burst of 90 independent tasks" });
    let peak = 0, done = false;
    const sampler = (async () => { while (!done) { const n = (await pool.query("SELECT count(*)::int n FROM tasks WHERE queue='io' AND status='running'")).rows[0].n; peak = Math.max(peak, n); await sleep(15); } })();
    const status = await waitForWorkUnit(id, 30000);
    done = true; await sampler;
    const q = (await pool.query("SELECT concurrency, max_concurrency, provider_cap FROM queue_state WHERE queue='io'")).rows[0];
    const ceiling = Math.min(q.max_concurrency, q.provider_cap);
    return { ok: refused && status === "completed" && peak <= ceiling && peak > 1, evidence: `1001-task plan refused=${refused}; 90 tasks ${status}; peak concurrent=${peak} (ceiling ${ceiling}, controller now at ${q.concurrency})` };
  }));

  // ---- scenario results
  const research = await researchP;
  checks.push(await timed("injection", "Instruction-like text in a fetched page is quarantined and cannot alter permissions", async () => {
    const wu = (await pool.query("SELECT authority_token, deliverable, status FROM work_units WHERE id=$1", [research.id])).rows[0];
    const an = (await pool.query("SELECT output FROM tasks WHERE work_unit_id=$1 AND key='analyze'", [research.id])).rows[0]?.output;
    const q = (an?.sources ?? []).filter((s: any) => s.quarantined);
    const root = verifyAuthority(wu.authority_token);
    const md: string = wu.deliverable ?? "";
    const exec = md.split("## Findings")[0];
    const leaked = q.some((s: any) => exec.includes(`[${s.id}]`) && !exec.includes("Security"));
    const reads = (await pool.query("SELECT count(*)::int n FROM tasks WHERE work_unit_id=$1 AND op='web.read' AND (output->>'untrusted')='true'", [research.id])).rows[0].n;
    const ok = q.length === 1 && !leaked && root.ok && !root.authority.actions.includes("*") && /Security notes/.test(md) && reads >= 3;
    return { ok, evidence: `${q.length} source quarantined; findings cite it=${leaked}; root capability unchanged (${root.ok ? root.authority.actions.length : 0} actions); web content flagged untrusted on ${reads} reads` };
  }));

  checks.push(await timed("verified-deliverable", "Research Work Unit ends in a deliverable that passed independent verification, with contradictions surfaced", async () => {
    const wu = (await pool.query("SELECT status, deliverable, result FROM work_units WHERE id=$1", [research.id])).rows[0];
    const md: string = wu.deliverable ?? "";
    const ok = wu.status === "completed" && /\$49\/month/.test(md) && /\$59\/month/.test(md) && /## Contradictions/.test(md) && /Acme/.test(md);
    const rounds = (wu.result?.gauntlet ?? []).length;
    return { ok, evidence: `status=${wu.status}; contradiction Acme Pro $49 vs $59 surfaced=${/\$59\/month/.test(md)}; gauntlet rounds=${rounds}; model calls=${wu.result?.modelCalls ?? 0}` };
  }));

  const crm = await crmP;
  checks.push(await timed("browser-persistence", "Persistent browser: login, human MFA takeover, resume, export; Live View link revoked on resume", async () => {
    const wu = (await pool.query("SELECT status, result FROM work_units WHERE id=$1", [crm.id])).rows[0];
    const an = (await pool.query("SELECT output FROM tasks WHERE work_unit_id=$1 AND key='analyze'", [crm.id])).rows[0]?.output;
    const ck = (await pool.query("SELECT cookies FROM browser_contexts WHERE agent_id=(SELECT owner_agent_id FROM work_units WHERE id=$1)", [crm.id])).rows[0]?.cookies ?? {};
    const names = Object.values(ck).flatMap((c: any) => Object.keys(c));
    const humanReceipts = (await pool.query("SELECT count(*)::int n FROM receipts WHERE work_unit_id=$1 AND actor='human'", [crm.id])).rows[0].n;
    const ok = wu.status === "completed" && an?.total === 491050 && names.includes("crm_sid") && names.includes("crm_mfa") && crm.approvedTask && (crm.takeover ? crm.liveRevoked === true : true);
    return { ok, evidence: `status=${wu.status}; takeover requested=${crm.takeover}; live link revoked=${crm.liveRevoked}; cookies persisted=[${names.join(", ")}]; export total reconciles=${an?.total}; human-actor receipts=${humanReceipts}` };
  }));

  checks.push(await timed("credential", "The model never sees the secret: placeholders only, domain-bound, encrypted at rest", async () => {
    const needle = "s3cr3t-pa55";
    const q = async (sql: string) => (await pool.query(sql, [`%${needle}%`])).rows[0].n as number;
    const hits = (await Promise.all([
      q("SELECT count(*)::int n FROM tasks WHERE input::text LIKE $1 OR output::text LIKE $1 OR error LIKE $1"),
      q("SELECT count(*)::int n FROM receipts WHERE detail::text LIKE $1 OR resource LIKE $1"),
      q("SELECT count(*)::int n FROM work_units WHERE deliverable LIKE $1 OR result::text LIKE $1 OR params::text LIKE $1"),
      q("SELECT count(*)::int n FROM sessions WHERE transcript::text LIKE $1"),
      q("SELECT count(*)::int n FROM browser_contexts WHERE tabs::text LIKE $1 OR cookies::text LIKE $1"),
      q("SELECT count(*)::int n FROM credentials WHERE secret_enc LIKE $1"),
      q("SELECT count(*)::int n FROM llm_cache WHERE response LIKE $1"),
    ])).reduce((a, b) => a + b, 0);
    const placeholder = (await pool.query("SELECT count(*)::int n FROM tasks WHERE input::text LIKE '%{{cred:demo-crm.password}}%'")).rows[0].n;
    const used = (await pool.query("SELECT count(*)::int n FROM receipts WHERE action='credential.use' AND decision='allow'")).rows[0].n;
    // Domain binding: the vault refuses to resolve a credential for a host it is not bound to.
    let bound = false;
    try { const { resolvePlaceholders } = await import("@/lib/tools/vault"); await resolvePlaceholders(orgId, "{{cred:demo-crm.password}}", "evil.example", {}); } catch (e) { bound = e instanceof PolicyDenied; }
    return { ok: hits === 0 && placeholder > 0 && used > 0 && bound, evidence: `plaintext occurrences across tasks/receipts/results/transcripts/browser state/vault/cache = ${hits}; placeholder tasks=${placeholder}; brokered uses audited=${used}; wrong-domain resolution refused=${bound}` };
  }));

  checks.push(await timed("chain", "Receipt ledger is a tamper-evident hash chain", async () => {
    const v = await verifyChain(2000);
    return { ok: v.intact && v.checked >= 10, evidence: `${v.checked} receipts checked, intact=${v.intact}${v.brokenAt ? ", broken at " + v.brokenAt : ""}` };
  }));

  checks.push(await timed("idle-footprint", "Idle agents cost storage, not compute: no resident sessions, scheduler loop stops", async () => {
    const s = (await pool.query("SELECT id FROM sessions WHERE title NOT LIKE 'bench-session-%' ORDER BY created_at LIMIT 1")).rows[0];
    const turn = await sendMessage(s.id, "/status");
    for (let i = 0; i < 40 && schedulerStatus().draining; i++) await sleep(150);
    const active = (await pool.query("SELECT count(*)::int n FROM sessions WHERE status='active'")).rows[0].n;
    const hib = (await pool.query("SELECT count(*)::int n, (SELECT count(*)::int FROM agents) agents FROM sessions WHERE status='hibernated'")).rows[0];
    const sch = schedulerStatus();
    const st = (await pool.query("SELECT status FROM sessions WHERE id=$1", [s.id])).rows[0].status;
    return { ok: active === 0 && st === "hibernated" && !sch.draining && sch.inflight === 0, evidence: `active sessions=${active}, hibernated=${hib.n} across ${hib.agents} agent identities (0 resident processes); a woken session returned to '${st}' in ${turn.ms} ms; scheduler loop running=${sch.draining}, in-flight=${sch.inflight}` };
  }));

  const order = ["attenuation", "tamper", "expiry", "domain", "ssrf", "injection", "credential", "cross-agent", "failure-recovery", "idempotent-effect", "dup-event", "bounded-fanout", "idle-footprint", "verified-deliverable", "chain", "browser-persistence", "gauntlet-catches"];
  checks.sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id));
  const passed = checks.filter((c) => c.passed).length;
  await pool.query("INSERT INTO qualification_runs (results, passed, failed) VALUES ($1,$2,$3)", [JSON.stringify(checks), passed, checks.length - passed]);
  return checks;
}
