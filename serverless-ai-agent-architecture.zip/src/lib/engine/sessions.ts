import { pool } from "@/db";
import { complete, gatewayConfig } from "@/lib/gateway/model";
import { sha256 } from "@/lib/util";
import { choosePlan, extractUrls } from "./planner";
import { retrieveContext } from "./memory";
import { createWorkUnit } from "./scheduler";

/**
 * Hibernating session runtime (local implementation of the SessionRuntime interface).
 * A turn: wake -> load only the tail of the transcript -> act -> commit -> hibernate.
 * Nothing stays resident between turns. A PiHarness / Durable Object adapter implements the same function.
 */
export async function sendMessage(sessionId: string, text: string) {
  const t0 = performance.now();
  const rss0 = process.memoryUsage().rss;
  const woke = await pool.query(
    "UPDATE sessions SET status='active', wake_count=wake_count+1 WHERE id=$1 RETURNING id, agent_id, org_id, (SELECT slug FROM agents WHERE id=sessions.agent_id) AS slug, (SELECT role FROM agents WHERE id=sessions.agent_id) AS role, (SELECT name FROM agents WHERE id=sessions.agent_id) AS name",
    [sessionId],
  );
  const s = woke.rows[0];
  if (!s) throw new Error("session not found");
  const tail = (await pool.query("SELECT COALESCE(jsonb_path_query_array(transcript, '$[last-5 to last]'), '[]'::jsonb) AS tail FROM sessions WHERE id=$1", [sessionId]).catch(() => ({ rows: [{ tail: [] }] }))).rows[0]?.tail ?? [];
  let reply = "";
  let workUnitId: string | null = null;
  try {
    const trimmed = text.trim();
    const urls = extractUrls(trimmed);
    if (/^\/status\b/i.test(trimmed)) {
      const r = (await pool.query("SELECT status, count(*)::int n FROM work_units WHERE org_id=$1 GROUP BY status", [s.org_id])).rows;
      reply = r.length ? `Work units: ${r.map((x) => `${x.n} ${x.status}`).join(", ")}.` : "No work units yet.";
    } else if (/^\/remember\b/i.test(trimmed)) {
      const content = trimmed.replace(/^\/remember\s*/i, "").slice(0, 400);
      if (!content) reply = "Usage: /remember <something to keep>";
      else {
        await pool.query(
          `INSERT INTO memories (org_id, scope, scope_ref, kind, subject, content, content_hash, trust, status)
           VALUES ($1,'agent',$2,'preference','preference',$3,$4,0.9,'curated') ON CONFLICT (org_id, content_hash) DO UPDATE SET hits=memories.hits+1`,
          [s.org_id, s.agent_id, content, sha256(s.agent_id + content)],
        );
        reply = "Saved to my scoped memory (agent scope). It will be retrieved as a reference when relevant.";
      }
    } else if (/^\/recall\b/i.test(trimmed)) {
      const refs = await retrieveContext(s.org_id, trimmed.replace(/^\/recall\s*/i, ""), s.agent_id, 5);
      reply = refs.length ? refs.map((r) => `• ${r.content}`).join("\n") : "Nothing relevant in curated memory.";
    } else if (urls.length || /^(research|compare|analy[sz]e|investigate)\b/i.test(trimmed) || /\bcrm\b/i.test(trimmed) || /^\/breakthrough\b/i.test(trimmed) || /\b(stuck|impossible|keeps coming back)\b/i.test(trimmed)) {
      const objective = trimmed.replace(/^\/breakthrough\s*/i, "");
      const plan = /^\/breakthrough\b/i.test(trimmed) ? choosePlan(objective, { template: "breakthrough" }) : choosePlan(objective);
      const wu = await createWorkUnit({
        orgId: s.org_id, plan, objective, sessionId, ownerAgentId: undefined,
        delegatedFromAgentId: s.slug === "chief-of-staff" ? s.agent_id : undefined,
      });
      workUnitId = wu.id;
      reply = `Started a **${plan.template}** Work Unit with ${plan.specs.length} tasks. I'm hibernating now; the shared worker pool executes the graph. Track it at /work/${wu.id}.`;
    } else if (gatewayConfig().configured) {
      const refs = await retrieveContext(s.org_id, trimmed, s.agent_id, 3);
      const r = await complete({
        kind: "classify", agentId: s.agent_id, maxTokens: 300,
        system: `You are ${s.name} (${s.role}) in an agent operating system. Be brief. Suggest starting a Work Unit when the user needs research, browser work or analysis.`,
        prompt: `Recent: ${JSON.stringify(tail).slice(0, 1200)}\nMemory: ${refs.map((m) => m.content).join(" | ")}\nUser: ${trimmed}`,
      });
      reply = r.text || "I couldn't reach the model gateway; try a command.";
    } else {
      reply = `I'm ${s.name}. Commands: paste URLs or say "research <topic>" to start a research Work Unit; "log in to the CRM and export the pipeline"; "/breakthrough <stuck problem>"; "/remember <fact>"; "/recall <query>"; "/status".`;
    }
  } finally {
    const now = new Date().toISOString();
    await pool.query(
      `UPDATE sessions SET transcript = transcript || $2::jsonb, status='hibernated', turn_count=turn_count+1, last_active_at=now() WHERE id=$1`,
      [sessionId, JSON.stringify([{ role: "user", content: text.slice(0, 2000), at: now }, { role: "agent", content: reply, at: now }])],
    );
  }
  return { reply, workUnitId, ms: Math.round(performance.now() - t0), rssDeltaKb: Math.round((process.memoryUsage().rss - rss0) / 1024) };
}
