import { Fatal } from "@/lib/util";

export const QUEUES = ["interactive", "io", "compute", "browser"] as const;
export type QueueName = (typeof QUEUES)[number];

export type TaskSpec = {
  key: string;
  title: string;
  op: string;
  deps?: string[];
  softDeps?: boolean;
  input?: Record<string, unknown>;
  agentSlug?: string;
  priority?: number;
  requiresApproval?: boolean;
  maxAttempts?: number;
};

/** Op registry: which queue, which execution tier, which authority actions each op needs. */
export const OPS: Record<string, { queue: QueueName; tier: 0 | 1 | 2; actions: string[]; label: string }> = {
  "memory.context": { queue: "interactive", tier: 0, actions: ["memory.read"], label: "Retrieve compact context (no model)" },
  "plan.queries": { queue: "interactive", tier: 0, actions: ["compute.run"], label: "Derive search queries (deterministic)" },
  "search.wiki": { queue: "io", tier: 0, actions: ["http.get"], label: "Search source discovery (HTTP API)" },
  discover: { queue: "interactive", tier: 0, actions: ["compute.run"], label: "Merge sources, bounded fan-out" },
  "web.read": { queue: "io", tier: 0, actions: ["http.get"], label: "Fetch + deterministic extraction" },
  "analyze.facts": { queue: "compute", tier: 1, actions: ["compute.run"], label: "Map/reduce facts, prices, contradictions" },
  "analyze.csv": { queue: "compute", tier: 1, actions: ["compute.run"], label: "Aggregate CSV artifact" },
  "llm.synthesize": { queue: "io", tier: 0, actions: ["model.call"], label: "Synthesis (routed model or deterministic)" },
  "verify.gauntlet": { queue: "compute", tier: 1, actions: ["verify.run"], label: "Independent verifier + gauntlet loop" },
  "compute.js": { queue: "compute", tier: 1, actions: ["compute.run"], label: "Tier-1 sandboxed JS" },
  "browser.run": { queue: "browser", tier: 1, actions: ["browser.*", "credential.use", "http.get"], label: "Persistent browser script" },
  "reason.dossier": { queue: "io", tier: 0, actions: ["model.call"], label: "Breakthrough dossier" },
  "reason.lens": { queue: "io", tier: 0, actions: ["model.call"], label: "Independent forced-lens solver" },
  "reason.redteam": { queue: "io", tier: 0, actions: ["model.call"], label: "Red team: try to kill each candidate" },
  "reason.converge": { queue: "io", tier: 0, actions: ["model.call"], label: "Converge to decisions + decisive tests" },
  "synthetic.sleep": { queue: "io", tier: 0, actions: ["synthetic.run"], label: "Synthetic I/O wait (benchmarks)" },
  "synthetic.sidefx": { queue: "io", tier: 0, actions: ["synthetic.run"], label: "Synthetic side effect (failure injection)" },
};

export const MAX_TASKS_PER_UNIT = 1000;
export const MAX_SPAWN = 50;

export function validateDag(specs: TaskSpec[], max = MAX_TASKS_PER_UNIT) {
  if (specs.length === 0) throw new Fatal("empty plan");
  if (specs.length > max) throw new Fatal(`unbounded fan-out refused: ${specs.length} > ${max} tasks`);
  const keys = new Set<string>();
  for (const s of specs) {
    if (keys.has(s.key)) throw new Fatal(`duplicate task key ${s.key}`);
    keys.add(s.key);
    if (!OPS[s.op]) throw new Fatal(`unknown op ${s.op}`);
  }
  const indeg = new Map<string, number>();
  for (const s of specs) {
    for (const d of s.deps ?? []) if (!keys.has(d)) throw new Fatal(`task ${s.key} depends on unknown ${d}`);
    indeg.set(s.key, (s.deps ?? []).length);
  }
  const q = [...indeg.entries()].filter(([, n]) => n === 0).map(([k]) => k);
  let seen = 0;
  while (q.length) {
    const k = q.pop()!;
    seen++;
    for (const s of specs) if ((s.deps ?? []).includes(k)) {
      const n = (indeg.get(s.key) ?? 0) - 1;
      indeg.set(s.key, n);
      if (n === 0) q.push(s.key);
    }
  }
  if (seen !== specs.length) throw new Fatal("task graph contains a cycle");
}

export type Plan = {
  template: string;
  specs: TaskSpec[];
  criteria: Record<string, unknown>;
  bar: string;
  ownerSlug: string;
  params: Record<string, unknown>;
  budgetMicro: number;
};

export function extractUrls(text: string): string[] {
  return [...new Set(text.match(/https?:\/\/[^\s)"'<>]+/g) ?? [])].map((u) => u.replace(/[.,;]+$/, ""));
}

export function planResearch(objective: string, urls: string[]): Plan {
  const clean = urls.slice(0, 12);
  const specs: TaskSpec[] = [{ key: "context", title: "Retrieve relevant organizational memory", op: "memory.context", agentSlug: "research-analyst", priority: 8 }];
  let analyzeDeps: string[];
  if (clean.length) {
    clean.forEach((u, i) =>
      specs.push({ key: `read_${i + 1}`, title: `Read ${new URL(u).hostname}${new URL(u).pathname.slice(0, 30)}`, op: "web.read", input: { url: u }, agentSlug: "research-analyst", maxAttempts: 3 }),
    );
    analyzeDeps = clean.map((_, i) => `read_${i + 1}`);
  } else {
    specs.push({ key: "queries", title: "Derive search queries once", op: "plan.queries", input: { objective }, agentSlug: "research-analyst", priority: 8 });
    for (let i = 0; i < 3; i++)
      specs.push({ key: `search_${i + 1}`, title: `Discover sources (query ${i + 1})`, op: "search.wiki", deps: ["queries"], input: { index: i }, agentSlug: "research-analyst" });
    specs.push({ key: "discover", title: "Merge sources and fan out reads", op: "discover", deps: ["search_1", "search_2", "search_3"], softDeps: true, agentSlug: "research-analyst", input: { max: 6 } });
    analyzeDeps = ["discover"];
  }
  specs.push(
    { key: "analyze", title: "Reduce: facts, price table, contradictions", op: "analyze.facts", deps: analyzeDeps, softDeps: true, agentSlug: "data-engineer" },
    { key: "synthesize", title: "Synthesize brief", op: "llm.synthesize", deps: ["analyze", "context"], softDeps: true, input: { mode: "research", objective }, agentSlug: "research-analyst" },
    { key: "verify", title: "Independent verification (gauntlet)", op: "verify.gauntlet", deps: ["synthesize"], input: { mode: "research" }, agentSlug: "verifier", priority: 7 },
  );
  return {
    template: "research",
    specs,
    ownerSlug: "research-analyst",
    params: { urls: clean },
    budgetMicro: 500_000,
    bar: "Analyst-grade brief: every figure traceable to a fetched, hash-addressed source snapshot; contradictions surfaced; instruction-like content in sources quarantined; no unsupported numbers.",
    criteria: {
      minSources: clean.length === 1 ? 1 : 2,
      requiredSections: ["Executive summary", "Findings", "Contradictions", "Open questions", "Evidence index"],
      requireCitations: true,
      noUnsupportedNumbers: true,
    },
  };
}

export function planCrm(objective: string): Plan {
  const o = "/api/demo/crm";
  const specs: TaskSpec[] = [
    {
      key: "login", title: "Log in using brokered credential (needs approval)", op: "browser.run", agentSlug: "browser-operator", requiresApproval: true,
      input: { steps: [
        { do: "goto", url: `${o}/login` },
        { do: "type", form: 0, field: "username", value: "{{cred:demo-crm.username}}" },
        { do: "type", form: 0, field: "password", value: "{{cred:demo-crm.password}}" },
        { do: "submit", form: 0 },
      ] },
    },
    {
      key: "gate", title: "Reach dashboard (human takes over for MFA if challenged)", op: "browser.run", deps: ["login"], agentSlug: "browser-operator",
      input: { steps: [{ do: "goto", url: `${o}/dashboard` }], expectTitle: "Dashboard", humanReason: "MFA challenge: enter the one-time code in the shared browser, then resume." },
    },
    {
      key: "export", title: "Download pipeline export", op: "browser.run", deps: ["gate"], agentSlug: "browser-operator",
      input: { steps: [{ do: "goto", url: `${o}/dashboard` }, { do: "download", linkText: "Export" }] },
    },
    { key: "analyze", title: "Aggregate exported CSV", op: "analyze.csv", deps: ["export"], agentSlug: "data-engineer" },
    { key: "synthesize", title: "Write pipeline report", op: "llm.synthesize", deps: ["analyze"], input: { mode: "crm", objective }, agentSlug: "research-analyst" },
    { key: "verify", title: "Independent verification (gauntlet)", op: "verify.gauntlet", deps: ["synthesize"], input: { mode: "crm" }, agentSlug: "verifier", priority: 7 },
  ];
  return {
    template: "browser-crm",
    specs,
    ownerSlug: "browser-operator",
    params: {},
    budgetMicro: 400_000,
    bar: "Operator-grade report: authenticated session reused across steps, figures reconcile to the downloaded export byte-for-byte, credentials never exposed to any model-visible text.",
    criteria: {
      minSources: 1,
      requiredSections: ["Executive summary", "Pipeline by stage", "Top accounts", "Evidence index"],
      requireCitations: true,
      noUnsupportedNumbers: true,
    },
  };
}

export const LENSES = [
  { key: "reframe", name: "Reformulation sweep", brief: "Restate the problem 4 different ways (as a queue, a market, a control loop, a constraint problem). Which framing makes it tractable?" },
  { key: "constraint", name: "False-constraint audit", brief: "List every 'we can't because...'. For each: who imposed it, why, does the reason still hold, is it physics or convention?" },
  { key: "contradiction", name: "Contradiction separation (TRIZ)", brief: "Find the parameter that needs two opposite values. Separate it in time, space, condition or system level. State the ideal final result." },
  { key: "force", name: "Maintaining-force analysis", brief: "Who gains from the status quo, who pays, who can veto? What reinforcing loop keeps it stuck? What rule change makes the desired behaviour each actor's best move?" },
  { key: "isomorph", name: "Far-transfer isomorph", brief: "Which solved problem in another field has the same causal structure (OS scheduling, MapReduce, copy-on-write, biology)? Map it component by component." },
];

export function planBreakthrough(objective: string): Plan {
  const specs: TaskSpec[] = [
    { key: "dossier", title: "Build dossier: goal ladder, constraints, failure autopsy", op: "reason.dossier", input: { objective }, agentSlug: "strategist" },
    ...LENSES.map<TaskSpec>((l) => ({ key: `lens_${l.key}`, title: `Solver: ${l.name}`, op: "reason.lens", deps: ["dossier"], input: { lens: l.key }, agentSlug: "strategist" })),
    { key: "redteam", title: "Red team: try to destroy every candidate", op: "reason.redteam", deps: LENSES.map((l) => `lens_${l.key}`), softDeps: true, agentSlug: "verifier" },
    { key: "converge", title: "Converge to decisions and decisive tests", op: "reason.converge", deps: ["redteam"], softDeps: true, agentSlug: "strategist", input: { objective } },
    { key: "verify", title: "Independent verification (gauntlet)", op: "verify.gauntlet", deps: ["converge"], input: { mode: "breakthrough" }, agentSlug: "verifier", priority: 7 },
  ];
  return {
    template: "breakthrough",
    specs,
    ownerSlug: "strategist",
    params: {},
    budgetMicro: 600_000,
    bar: "Decision memo: reframed problem, surviving options with kill-tests applied, explicit 'must be true' assumptions, and the cheapest decisive test for each decision.",
    criteria: { minSources: 0, requiredSections: ["Reframed problem", "Options", "Decisions", "Cheapest decisive tests"], requireCitations: false, noUnsupportedNumbers: false },
  };
}

export function planCompute(objective: string, code: string, data: unknown): Plan {
  return {
    template: "compute",
    specs: [{ key: "compute", title: "Run Tier-1 sandboxed code (needs approval)", op: "compute.js", input: { code, data }, agentSlug: "data-engineer", requiresApproval: true }],
    ownerSlug: "data-engineer",
    params: { code },
    budgetMicro: 50_000,
    bar: "Result is valid JSON produced under a CPU timeout with no I/O globals.",
    criteria: {},
  };
}

/** Pick a plan from the objective. Deterministic routing: no model call where code can decide. */
export function choosePlan(objective: string, opts: { template?: string; urls?: string[]; code?: string; data?: unknown } = {}): Plan {
  const urls = [...(opts.urls ?? []), ...extractUrls(objective)];
  const t = opts.template && opts.template !== "auto" ? opts.template : null;
  if (t === "compute" || (!t && opts.code)) return planCompute(objective, opts.code ?? "return data", opts.data ?? {});
  if (t === "browser-crm" || (!t && /\b(crm|log ?in|sign ?in|pipeline export)\b/i.test(objective) && !urls.length)) return planCrm(objective);
  if (t === "breakthrough" || (!t && /\b(stuck|impossible|intractable|keeps? coming back|breakthrough|can'?t agree|10x)\b/i.test(objective))) return planBreakthrough(objective);
  return planResearch(objective, urls);
}
