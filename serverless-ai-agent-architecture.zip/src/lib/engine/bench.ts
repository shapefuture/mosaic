/* eslint-disable @typescript-eslint/no-explicit-any */
import { pool } from "@/db";
import { percentile, sleep, appOrigin } from "@/lib/util";
import { createWorkUnit, schedulerStatus, waitForWorkUnit } from "./scheduler";
import { sendMessage } from "./sessions";
import { syntheticPlan } from "./qualify";
import type { TaskSpec } from "./planner";

/**
 * AOS capacity qualification: real measurements of THIS deployment (not claims about any platform).
 * 1) N idle logical sessions  2) M simultaneous I/O-bound tasks  3) K independent web.read subtasks.
 */
export async function startBenchmark(orgId: string, params: { sessions?: number; ioTasks?: number; fanout?: number } = {}) {
  const p = { sessions: Math.min(params.sessions ?? 2048, 10000), ioTasks: Math.min(params.ioTasks ?? 500, 1000), fanout: Math.min(params.fanout ?? 200, 1000) };
  const ins = await pool.query("INSERT INTO benchmarks (name, params) VALUES ('AOS capacity qualification',$1) RETURNING id", [JSON.stringify(p)]);
  const id = ins.rows[0].id as string;
  void run(id, orgId, p).catch(async (e) => {
    await pool.query("UPDATE benchmarks SET status='failed', results=COALESCE(results,'{}'::jsonb) || $2::jsonb, finished_at=now() WHERE id=$1", [id, JSON.stringify({ error: (e as Error).message })]);
  });
  return id;
}

async function save(id: string, patch: Record<string, unknown>) {
  await pool.query("UPDATE benchmarks SET results = COALESCE(results,'{}'::jsonb) || $2::jsonb WHERE id=$1", [id, JSON.stringify(patch)]);
}

async function sampled<T>(fn: () => Promise<T>) {
  let peakRunning = 0, peakRss = process.memoryUsage().rss, stop = false;
  const rss0 = peakRss;
  const loop = (async () => {
    while (!stop) {
      const n = (await pool.query("SELECT count(*)::int n FROM tasks WHERE status='running'")).rows[0].n as number;
      peakRunning = Math.max(peakRunning, n);
      peakRss = Math.max(peakRss, process.memoryUsage().rss);
      await sleep(25);
    }
  })();
  const xact0 = (await pool.query("SELECT xact_commit::bigint AS x FROM pg_stat_database WHERE datname=current_database()")).rows[0].x as string;
  const t0 = Date.now();
  const value = await fn();
  const ms = Date.now() - t0;
  const xact1 = (await pool.query("SELECT xact_commit::bigint AS x FROM pg_stat_database WHERE datname=current_database()")).rows[0].x as string;
  stop = true;
  await loop;
  return { value, ms, peakRunning, rssPeakDeltaMb: +((peakRss - rss0) / 1048576).toFixed(1), xacts: Number(xact1) - Number(xact0) };
}

async function taskStats(wuId: string) {
  const r = await pool.query("SELECT status, EXTRACT(EPOCH FROM (started_at - ready_at))*1000 AS wait, EXTRACT(EPOCH FROM (finished_at - started_at))*1000 AS run FROM tasks WHERE work_unit_id=$1", [wuId]);
  const waits = r.rows.filter((x) => x.wait !== null).map((x) => Number(x.wait));
  const runs = r.rows.filter((x) => x.run !== null).map((x) => Number(x.run));
  return {
    succeeded: r.rows.filter((x) => x.status === "succeeded").length,
    failed: r.rows.filter((x) => x.status !== "succeeded").length,
    queueWaitP50Ms: Math.round(percentile(waits, 0.5)), queueWaitP95Ms: Math.round(percentile(waits, 0.95)),
    runP50Ms: Math.round(percentile(runs, 0.5)), runP95Ms: Math.round(percentile(runs, 0.95)),
  };
}

async function run(id: string, orgId: string, p: { sessions: number; ioTasks: number; fanout: number }) {
  // ---- 1. idle sessions
  const agents = (await pool.query("SELECT id FROM agents WHERE org_id=$1", [orgId])).rows.map((r) => r.id as string);
  const have = (await pool.query("SELECT count(*)::int n FROM sessions WHERE title LIKE 'bench-session-%'")).rows[0].n as number;
  const t0 = Date.now();
  if (have < p.sessions)
    await pool.query(
      `INSERT INTO sessions (agent_id, org_id, title) SELECT ($3::uuid[])[1 + (i % $4::int)], $1, 'bench-session-' || i FROM generate_series($2::int, $5::int) i`,
      [orgId, have + 1, agents, agents.length, p.sessions],
    );
  const insertMs = Date.now() - t0;
  const size = (await pool.query("SELECT pg_total_relation_size('sessions')::bigint AS b, (SELECT count(*)::int FROM sessions WHERE title LIKE 'bench-session-%') AS n, (SELECT count(*)::int FROM sessions WHERE status='active') AS active")).rows[0];
  const sample = (await pool.query("SELECT id FROM sessions WHERE title LIKE 'bench-session-%' ORDER BY random() LIMIT 100")).rows.map((r) => r.id as string);
  const lat: number[] = [], rssd: number[] = [];
  for (const sid of sample) {
    const r = await sendMessage(sid, "/status");
    lat.push(r.ms);
    rssd.push(r.rssDeltaKb);
  }
  const active = (await pool.query("SELECT count(*)::int n FROM sessions WHERE status='active'")).rows[0].n;
  await save(id, {
    idleSessions: {
      logicalSessions: size.n, createdMs: insertMs, tableMb: +(Number(size.b) / 1048576).toFixed(2), bytesPerSession: Math.round(Number(size.b) / Math.max(1, size.n)),
      residentProcessesPerSession: 0, activeAtRest: size.active, wokeAndHibernated: sample.length, activeAfterWake: active,
      wakeTurnP50Ms: Math.round(percentile(lat, 0.5)), wakeTurnP95Ms: Math.round(percentile(lat, 0.95)), avgRssDeltaKbPerTurn: Math.round(rssd.reduce((a, b) => a + b, 0) / rssd.length),
    },
  });

  // ---- 2. simultaneous I/O-bound tasks
  const specs: TaskSpec[] = Array.from({ length: p.ioTasks }, (_, i) => ({ key: `io${i}`, title: `I/O wait ${i}`, op: "synthetic.sleep", input: { ms: 60 + ((i * 37) % 80) }, agentSlug: "research-analyst" }));
  const io = await sampled(async () => {
    const { id: wu } = await createWorkUnit({ orgId, plan: syntheticPlan(specs, "bench"), objective: `Benchmark: ${p.ioTasks} simultaneous I/O-bound tasks`, maxTasks: 1000 });
    const status = await waitForWorkUnit(wu, 120000);
    return { wu, status };
  });
  const ioStats = await taskStats(io.value.wu);
  const q = (await pool.query("SELECT concurrency FROM queue_state WHERE queue='io'")).rows[0];
  await save(id, {
    ioParallel: {
      tasks: p.ioTasks, status: io.value.status, wallMs: io.ms, throughputPerSec: +((ioStats.succeeded / io.ms) * 1000).toFixed(1), ...ioStats,
      peakConcurrentTasks: io.peakRunning, ioQueueConcurrencyAfter: q.concurrency, dbTransactionsPerTask: +(io.xacts / p.ioTasks).toFixed(1), rssPeakDeltaMb: io.rssPeakDeltaMb, workUnit: io.value.wu,
    },
  });

  // ---- 3. fan-out of real HTTP subtasks
  const pages = ["acme-pricing", "acme-features", "globex-pricing", "initech-pricing", "injection"];
  const fspecs: TaskSpec[] = Array.from({ length: p.fanout }, (_, i) => ({ key: `r${i}`, title: `read ${pages[i % 5]} #${i}`, op: "web.read", input: { url: `${appOrigin()}/api/demo/pages/${pages[i % 5]}?n=${i}` }, agentSlug: "research-analyst" }));
  const fan = await sampled(async () => {
    const { id: wu } = await createWorkUnit({ orgId, plan: syntheticPlan(fspecs, "bench"), objective: `Benchmark: ${p.fanout} independent web.read subtasks`, maxTasks: 1000 });
    return { wu, status: await waitForWorkUnit(wu, 180000) };
  });
  const fStats = await taskStats(fan.value.wu);
  await save(id, {
    fanout: { subtasks: p.fanout, status: fan.value.status, wallMs: fan.ms, throughputPerSec: +((fStats.succeeded / fan.ms) * 1000).toFixed(1), ...fStats, peakConcurrentTasks: fan.peakRunning, dbTransactionsPerTask: +(fan.xacts / p.fanout).toFixed(1), rssPeakDeltaMb: fan.rssPeakDeltaMb, workUnit: fan.value.wu },
    scheduler: schedulerStatus(),
  });
  await pool.query("UPDATE benchmarks SET status='done', finished_at=now() WHERE id=$1", [id]);
}
