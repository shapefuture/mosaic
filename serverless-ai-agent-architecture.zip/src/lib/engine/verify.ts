/**
 * Gauntlet verifier (independent of the builder). Hard gates cannot be averaged away:
 * the deliverable passes only when the critic finds zero gaps against the bar.
 *
 * Loop: critic inspects actual output -> names gaps -> builder fixes the biggest ones deterministically ->
 * critic compares previous vs revised BLIND (labels shuffled) -> keep only if strictly better.
 */
export type Gap = { id: string; weight: number; message: string; fixable: boolean };
export type Evidence = { id: string; url: string; sha: string; text: string };
export type Criteria = {
  minSources?: number;
  requiredSections?: string[];
  requireCitations?: boolean;
  noUnsupportedNumbers?: boolean;
};
export type GauntletInput = {
  markdown: string;
  criteria: Criteria;
  evidence: Evidence[];
  quarantined: string[];
  derivedNumbers: number[];
  sectionFixers: Record<string, string>;
};
export type Round = {
  round: number;
  gaps: { id: string; message: string }[];
  applied: string[];
  blind?: { labels: Record<string, "previous" | "revised">; picked: "A" | "B"; pickedIs: "previous" | "revised"; weightA: number; weightB: number };
  kept: boolean;
};

const CITE = /\[S(\d+)\]/g;
const sectionRe = (name: string) => new RegExp(`^##\\s+${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*$`, "im");

function sectionBody(md: string, name: string): string {
  const m = md.match(sectionRe(name));
  if (!m || m.index === undefined) return "";
  const rest = md.slice(m.index + m[0].length);
  const next = rest.search(/^##\s+/m);
  return next === -1 ? rest : rest.slice(0, next);
}

const num = (s: string) => Number(s.replace(/[$,]/g, ""));

export function critique(md: string, inp: GauntletInput): Gap[] {
  const gaps: Gap[] = [];
  const c = inp.criteria;
  for (const s of c.requiredSections ?? []) {
    if (!sectionRe(s).test(md)) gaps.push({ id: `missing_section:${s}`, weight: 3, message: `Missing required section "${s}"`, fixable: s in inp.sectionFixers });
  }
  const evIds = new Set(inp.evidence.map((e) => e.id));
  const cited = new Set([...md.matchAll(CITE)].map((m) => `S${m[1]}`));
  if ((c.minSources ?? 0) > 0 && [...cited].filter((x) => evIds.has(x)).length < (c.minSources ?? 0))
    gaps.push({ id: "too_few_sources", weight: 5, message: `Fewer than ${c.minSources} distinct, resolvable sources cited`, fixable: false });
  if (c.requireCitations) {
    for (const id of cited) if (!evIds.has(id)) gaps.push({ id: `bad_citation:${id}`, weight: 4, message: `Citation [${id}] does not resolve to any evidence snapshot`, fixable: true });
    const body = sectionBody(md, "Executive summary") + "\n" + sectionBody(md, "Findings");
    const bullets = body.split("\n").filter((l) => /^\s*[-*]\s+/.test(l));
    const uncited = bullets.filter((l) => !/\[S\d+\]/.test(l));
    if (uncited.length) gaps.push({ id: "uncited_bullet", weight: 3, message: `${uncited.length} finding(s) carry no citation`, fixable: true });
    const q = bullets.filter((l) => inp.quarantined.some((id) => l.includes(`[${id}]`)));
    if (q.length) gaps.push({ id: "quarantined_cited", weight: 5, message: `${q.length} finding(s) rely on a quarantined (injection-flagged) source`, fixable: true });
  }
  if (c.noUnsupportedNumbers) {
    const evText = inp.evidence.map((e) => e.text).join("\n");
    const known = new Set<number>(inp.derivedNumbers);
    for (const m of evText.matchAll(/\d[\d,]*(?:\.\d+)?/g)) known.add(num(m[0]));
    const bad = new Set<string>();
    for (const m of md.matchAll(/\$\s?\d[\d,]*(?:\.\d+)?/g)) if (!known.has(num(m[0]))) bad.add(m[0]);
    if (bad.size) gaps.push({ id: "unsupported_number", weight: 5, message: `Figures not found in any evidence: ${[...bad].slice(0, 5).join(", ")}`, fixable: true });
  }
  return gaps;
}

const weight = (g: Gap[]) => g.reduce((a, x) => a + x.weight, 0);

function applyFix(md: string, gap: Gap, inp: GauntletInput): string {
  const evIds = new Set(inp.evidence.map((e) => e.id));
  if (gap.id.startsWith("missing_section:")) {
    const name = gap.id.slice("missing_section:".length);
    const body = inp.sectionFixers[name];
    if (!body) return md;
    const idx = md.search(/^##\s+Evidence index/im);
    const block = `## ${name}\n${body}\n\n`;
    return idx === -1 ? `${md.trimEnd()}\n\n${block}` : md.slice(0, idx) + block + md.slice(idx);
  }
  if (gap.id.startsWith("bad_citation:")) return md.replace(new RegExp(`\\s?\\[${gap.id.split(":")[1]}\\]`, "g"), "");
  if (gap.id === "uncited_bullet" || gap.id === "quarantined_cited") {
    let withheld = 0;
    const lines = md.split("\n");
    let inScope = false;
    const out = lines.filter((l) => {
      if (/^##\s+/.test(l)) inScope = /^##\s+(Executive summary|Findings)\s*$/i.test(l);
      if (!inScope || !/^\s*[-*]\s+/.test(l)) return true;
      const drop = gap.id === "uncited_bullet" ? !/\[S\d+\]/.test(l) : inp.quarantined.some((id) => l.includes(`[${id}]`));
      if (drop) withheld++;
      return !drop;
    });
    const res = out.join("\n");
    return withheld ? `${res.trimEnd()}\n\n> ${withheld} statement(s) withheld by the verifier (uncited or from a quarantined source).\n` : res;
  }
  if (gap.id === "unsupported_number") {
    const evText = inp.evidence.map((e) => e.text).join("\n");
    const known = new Set<number>(inp.derivedNumbers);
    for (const m of evText.matchAll(/\d[\d,]*(?:\.\d+)?/g)) known.add(num(m[0]));
    void evIds;
    return md.replace(/\$\s?\d[\d,]*(?:\.\d+)?/g, (m) => (known.has(num(m)) ? m : "[unsupported figure removed]"));
  }
  return md;
}

export function gauntlet(inp: GauntletInput, maxRounds = 4) {
  let md = inp.markdown;
  const rounds: Round[] = [];
  for (let r = 1; r <= maxRounds; r++) {
    const gaps = critique(md, inp);
    if (!gaps.length) {
      rounds.push({ round: r, gaps: [], applied: [], kept: true });
      return { passed: true, markdown: md, rounds, gaps: [] as Gap[] };
    }
    const fixable = gaps.filter((g) => g.fixable).sort((a, b) => b.weight - a.weight);
    if (!fixable.length) {
      rounds.push({ round: r, gaps: gaps.map((g) => ({ id: g.id, message: g.message })), applied: [], kept: false });
      return { passed: false, markdown: md, rounds, gaps };
    }
    // Builder fixes every fixable gap this round; the critic then judges blind.
    let next = md;
    const applied: string[] = [];
    for (const g of fixable) {
      const n = applyFix(next, g, inp);
      if (n !== next) applied.push(g.id);
      next = n;
    }
    const wPrev = weight(gaps);
    const wNext = weight(critique(next, inp));
    const prevIsA = Math.random() < 0.5;
    const A = prevIsA ? wPrev : wNext;
    const B = prevIsA ? wNext : wPrev;
    const picked: "A" | "B" = A < B ? "A" : B < A ? "B" : prevIsA ? "A" : "B"; // ties go to previous
    const pickedIs = (picked === "A") === prevIsA ? "previous" : "revised";
    rounds.push({
      round: r,
      gaps: gaps.map((g) => ({ id: g.id, message: g.message })),
      applied,
      blind: { labels: { A: prevIsA ? "previous" : "revised", B: prevIsA ? "revised" : "previous" }, picked, pickedIs, weightA: A, weightB: B },
      kept: pickedIs === "revised",
    });
    if (pickedIs === "previous") return { passed: false, markdown: md, rounds, gaps };
    md = next;
  }
  const final = critique(md, inp);
  return { passed: final.length === 0, markdown: md, rounds, gaps: final };
}
