import { pool } from "@/db";
import { encryptSecret } from "@/lib/util";
import { QUEUE_DEFAULTS } from "./scheduler";

const g = globalThis as unknown as { __aosSeed?: Promise<string> };

/** Idempotent bootstrap. Returns the default organization id. */
export function ensureSeed(): Promise<string> {
  g.__aosSeed ??= seed().catch((e) => {
    g.__aosSeed = undefined;
    throw e;
  });
  return g.__aosSeed;
}

const ALL = ["http.get", "model.call", "memory.read", "compute.run", "verify.run", "synthetic.run", "browser.*", "credential.use"];

const AGENTS = [
  { slug: "chief-of-staff", name: "Chief of Staff", role: "Orchestrator", manager: null, actions: ALL, depth: 3, domains: ["*"], caps: ["delegate", "plan", "approve-routing"], skills: ["research-playbook", "browser-crm-playbook"] },
  { slug: "research-analyst", name: "Research Analyst", role: "Research", manager: "chief-of-staff", actions: ["http.get", "model.call", "memory.read", "compute.run", "synthetic.run", "verify.run"], depth: 2, domains: ["*"], caps: ["web.read", "synthesize"], skills: ["research-playbook"] },
  { slug: "data-engineer", name: "Data Engineer", role: "Data & compute", manager: "chief-of-staff", actions: ["compute.run", "http.get", "memory.read", "synthetic.run"], depth: 2, domains: ["*"], caps: ["map-reduce", "tier1-compute"], skills: [] },
  { slug: "browser-operator", name: "Browser Operator", role: "Authenticated browsing", manager: "chief-of-staff", actions: ["browser.*", "credential.use", "http.get", "compute.run", "memory.read", "model.call", "verify.run"], depth: 2, domains: ["127.0.0.1", "localhost", "*.acme.test"], caps: ["browser", "credential-broker"], skills: ["browser-crm-playbook"] },
  { slug: "strategist", name: "Strategist", role: "Planning & breakthroughs", manager: "chief-of-staff", actions: ["model.call", "memory.read", "compute.run", "verify.run"], depth: 2, domains: [], caps: ["reframe", "triz", "converge"], skills: ["breakthrough-playbook"] },
  { slug: "verifier", name: "Independent Verifier", role: "Quality & red team", manager: "chief-of-staff", actions: ["verify.run", "memory.read", "compute.run", "model.call"], depth: 1, domains: [], caps: ["gauntlet", "red-team"], skills: [] },
];

const CONNECTORS = [
  { key: "http-fetch", provider: "AOS fetch gateway", authType: "none", actions: ["http.get"], rate: 1200, approval: [], events: [], docs: "Bounded HTTP GET with SSRF guard, per-hop domain allowlist, 1.5 MB cap." },
  { key: "browser-pool", provider: "AOS browser pool (HTTP+DOM adapter)", authType: "context-cookies", actions: ["browser.goto", "browser.click", "browser.type", "browser.submit", "browser.download", "browser.newtab", "browser.switch", "browser.close", "browser.snapshot"], rate: 600, approval: ["browser.submit"], events: [], docs: "Persistent per-agent contexts packed onto a small process pool. CDP/Playwright adapter slot for JS-rendered pages." },
  { key: "tier1-sandbox", provider: "node:vm lite sandbox", authType: "none", actions: ["compute.run"], rate: 600, approval: ["compute.run:user-code"], events: [], docs: "Pure-JS execution, no I/O globals, CPU timeout. Not a hostile-code boundary." },
  { key: "model-gateway", provider: "OpenAI-compatible (AI Gateway / agentgateway)", authType: "api-key", actions: ["model.call"], rate: 300, approval: [], events: [], docs: "Task-aware model ladder, response cache, usage ledger, 429 back-off." },
  { key: "memory-store", provider: "PostgreSQL FTS", authType: "scoped-sql", actions: ["memory.read"], rate: 3000, approval: [], events: ["work_unit.completed"], docs: "Curated memories only; org + agent scopes." },
  { key: "wikipedia-search", provider: "Wikipedia opensearch", authType: "none", actions: ["http.get"], rate: 200, approval: [], events: [], docs: "Public source discovery without a search key." },
  { key: "demo-crm", provider: "Built-in demo CRM", authType: "credential-broker", actions: ["browser.goto", "browser.submit", "browser.download"], rate: 60, approval: ["credential.use"], events: [], docs: "Login + MFA + export used to demonstrate persistent sessions and human takeover." },
];

const FORBIDS = [
  { action: "http.*", pattern: "*169.254.169.254*", desc: "cloud metadata endpoint" },
  { action: "http.*", pattern: "*metadata.google.internal*", desc: "cloud metadata endpoint" },
  { action: "credential.use", pattern: "credential:prod-*", desc: "production credentials are human-only" },
  { action: "secret.*", pattern: "*", desc: "no agent may read raw secrets" },
];

const REQS: [string, number, string, string, string, string, string | null, string | null][] = [
  // id, phase, title, description, status, evidence, checkId, blocker
  ["R01", 1, "Agent = identity, not a process", "Agents are database records with role, capabilities, authority policy, budget.", "delivered", "agents table; /agents shows 0 resident processes per agent.", "idle-footprint", null],
  ["R02", 2, "Hibernating durable sessions", "Sessions wake for a turn, commit transcript, hibernate; thousands can exist idle.", "delivered", "sessions table + sendMessage wake/hibernate; capacity benchmark creates 2,048 idle sessions.", "idle-footprint", null],
  ["R03", 2, "Session runtime behind an interface", "PiHarness/Durable Objects replaceable without redesign.", "adapter", "Adapter registry on /capacity; local Postgres runtime implemented.", null, "PiHarness / Cloudflare Durable Objects need a Cloudflare account and Pi packages."],
  ["R04", 3, "Universal Work Engine: Plan→Fan-out→Execute→Join→Verify→Commit", "Durable DAG per Work Unit.", "delivered", "work_units + tasks tables; planner templates; scheduler promote/claim/finalize.", "verified-deliverable", null],
  ["R05", 3, "Dynamic fan-out and fan-in", "discover op spawns bounded child tasks and rewires the join.", "delivered", "spawn + join rewiring in commitSuccess; capped at 50 per spawn, 1,000 per unit.", "bounded-fanout", null],
  ["R06", 3, "Retries, deadlines, cancellation, recovery", "Leases, backoff, fenced commits, cancel.", "delivered", "reapLeases + fenced commit; chaos check kills a worker mid-task.", "failure-recovery", null],
  ["R07", 3, "Human approvals", "Task approval and human takeover gates.", "delivered", "approvals table; /governance approval center.", "browser-persistence", null],
  ["R08", 4, "Adaptive bounded scheduler with 4 queues", "interactive / io / compute / browser with feedback concurrency.", "delivered", "queue_state AIMD controller; C_allowed = min(provider, queue, tenant, budget, sandbox).", "bounded-fanout", null],
  ["R09", 4, "Weighted tenant fairness", "Claim loop shares queue room across orgs by in-flight load.", "delivered", "claimAndDispatch share + tenant_concurrency.", null, null],
  ["R10", 4, "Queue backend", "Durable Postgres queue (SKIP LOCKED) in place of Cloudflare Queues.", "adapter", "tasks table claim query.", null, "Cloudflare Queues requires a Cloudflare deployment; Postgres queue is the portable path."],
  ["R11", 5, "Model router + gateway", "Task-aware ladder, cache, usage ledger, 429 back-off, fallback.", "delivered", "src/lib/gateway/model.ts; usage_ledger table. Needs a key for live model calls.", null, "Set AI_GATEWAY_API_KEY or OPENAI_API_KEY to enable model calls; deterministic fallbacks run without it."],
  ["R12", 5, "No model call where code can do the job", "Planning, extraction, reduce, verification are deterministic.", "delivered", "Research runs report modelCalls per task; only synthesis and reasoning may call a model.", null, null],
  ["R13", 6, "Persistent browser identity per agent", "Cookies/tabs persist across tasks; pooled processes with tab ceilings.", "delivered", "browser_contexts; /browser; login→MFA→export demo.", "browser-persistence", null],
  ["R14", 6, "Human takeover via Live View", "Bearer link for authenticated humans, revoked on resume, never in agent output.", "delivered", "mintLiveToken / revokeLiveLinks; /browser/live/[token].", "browser-persistence", null],
  ["R15", 6, "Remote Chromium via CDP (Browser Run/Playwright/Stagehand/Midscene)", "JS-rendered and visual pages.", "adapter", "BrowserAction interface is the swap point.", null, "Needs a Chromium runtime (Browser Run or local Playwright browsers) not present in this environment."],
  ["R16", 7, "Tier 0 / Tier 1 execution", "Direct HTTP/tools by default; sandboxed JS for compute.", "delivered", "OPS registry tier field; node:vm sandbox with timeout.", null, null],
  ["R17", 7, "Tier 2 isolated microVMs", "Firecracker/OpenSandbox with snapshot/fork.", "external", "Provider slot listed on /capacity as not configured.", null, "Requires KVM hosts for Firecracker; cannot run in this sandbox."],
  ["R18", 8, "Single Postgres system of record", "Everything authoritative in Postgres; no Redis/Kafka/graph/vector DB.", "delivered", "Drizzle schema, 20 tables.", null, null],
  ["R19", 8, "Content-addressed artifact store", "URI+checksum in Postgres, content in object store.", "adapter", "objects/artifacts tables (S3/R2 adapter slot).", null, "R2/S3 bucket not provisioned; Postgres large-object stand-in used."],
  ["R20", 8, "Memory Compiler", "Candidate→dedupe→contradiction check→promote, off critical path.", "delivered", "compileMemory; /memory.", null, null],
  ["R21", 8, "Semantic retrieval", "Full-text search shipped; pgvector is the next index.", "partial", "GIN FTS index over memories; compact context package.", null, "pgvector extension and an embedding provider are not configured."],
  ["R22", 8, "Procedural memory / versioned skills", "Skill generated only after verified success and passing procedure test.", "delivered", "maybeCreateSkill; /memory skills tab.", null, null],
  ["R23", 9, "Signed capability tokens", "HMAC-signed, expiring, scoped authority envelopes.", "delivered", "src/lib/security/authority.ts.", "tamper", null],
  ["R24", 9, "No child more authority than parent", "Attenuation with strict/clamp modes.", "delivered", "attenuate(); escalation attempt is refused.", "attenuation", null],
  ["R25", 9, "Deterministic gateway authorization + org forbid rules", "Default deny; forbid always wins (Cedar-style).", "delivered", "authorize(); policies table.", "domain", null],
  ["R26", 9, "Credential broker", "Model sees placeholders only; secrets bound to domains.", "delivered", "vault.ts; AES-256-GCM at rest.", "credential", null],
  ["R27", 9, "Untrusted input cannot change permissions", "Injection detector, quarantine, untrusted flag.", "delivered", "extract.ts detectInjection; analyze quarantines.", "injection", null],
  ["R28", 9, "SSRF / egress control", "Private ranges blocked, per-hop allowlist.", "delivered", "assertPublicTarget.", "ssrf", null],
  ["R29", 9, "Immutable action receipts", "Hash-chained ledger of meaningful boundaries.", "delivered", "receipts table + verifyChain.", "chain", null],
  ["R30", 9, "Cedar engine / OpenFGA / SPIFFE", "Full external policy engines.", "external", "Cedar-style forbid rules implemented natively.", null, "Not warranted at this scale per the architecture; add when relationship model grows."],
  ["R31", 10, "Independent verification (gauntlet loop)", "Separate critic, blind A/B, loop until bar met; hard gates.", "delivered", "verify.ts + verifyop.ts.", "gauntlet-catches", null],
  ["R32", 10, "Idempotent external side effects", "Receipt-keyed side effects suppress duplicates on retry.", "delivered", "receipt(sideEffect, idempotencyKey).", "idempotent-effect", null],
  ["R33", 10, "Duplicate event safety", "Work Unit idempotency keys.", "delivered", "createWorkUnit idempotencyKey.", "dup-event", null],
  ["R34", 10, "Capacity qualification benchmark", "Idle sessions, 500 parallel I/O tasks, fan-out, memory per turn.", "delivered", "/capacity runs real measurements on this deployment.", null, null],
  ["R35", 10, "Security red-team + acceptance suite", "Live checks, persisted.", "delivered", "/governance runs 17 checks.", null, null],
  ["R36", 10, "OpenTelemetry / Inspect AI / BrowserGym", "External evaluation and tracing stacks.", "external", "Receipts + qualification runs cover in-app evidence.", null, "Needs an OTLP collector and eval harness outside this app."],
  ["R37", 11, "Breakthrough template", "Dossier→5 forced-lens solvers→red team→converge.", "delivered", "planBreakthrough; model-assisted when a key is set, worksheet mode otherwise.", null, null],
  ["R38", 11, "Delivery tracker", "Requirement→evidence mapping with honest blockers.", "delivered", "/delivery.", null, null],
];

async function seed(): Promise<string> {
  const c = await pool.connect();
  try {
    await c.query("SELECT pg_advisory_lock(7002)");
    const org = await c.query(
      `INSERT INTO organizations (slug, name) VALUES ('aos-demo','AOS Demo Organization')
       ON CONFLICT (slug) DO UPDATE SET slug=EXCLUDED.slug RETURNING id`,
    );
    const orgId = org.rows[0].id as string;
    const idBySlug = new Map<string, string>();
    for (const a of AGENTS) {
      const r = await c.query(
        `INSERT INTO agents (org_id, slug, name, role, manager_id, capabilities, model_policy, memory_scope, authority_policy, skills)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT (org_id, slug) DO UPDATE SET authority_policy=EXCLUDED.authority_policy, capabilities=EXCLUDED.capabilities, skills=EXCLUDED.skills, role=EXCLUDED.role RETURNING id`,
        [orgId, a.slug, a.name, a.role, a.manager ? idBySlug.get(a.manager) : null, JSON.stringify(a.caps), JSON.stringify({ research: "small", synthesize: "strong", reason: "strong" }), "org",
          JSON.stringify({ actions: a.actions, resources: ["project:*", "org:*", "wu:*"], domains: a.domains, maxCostMicro: 2_000_000, delegationDepth: a.depth }), JSON.stringify(a.skills)],
      );
      idBySlug.set(a.slug, r.rows[0].id);
    }
    for (const [queue, d] of Object.entries(QUEUE_DEFAULTS))
      await c.query("INSERT INTO queue_state (queue, concurrency, min_concurrency, max_concurrency, provider_cap) VALUES ($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING", [queue, d.c, d.min, d.max, d.provider]);
    for (const k of CONNECTORS)
      await c.query(
        `INSERT INTO connectors (key, provider, auth_type, supported_actions, rate_limit_per_min, approval_required, event_subscriptions, docs)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT (key) DO NOTHING`,
        [k.key, k.provider, k.authType, JSON.stringify(k.actions), k.rate, JSON.stringify(k.approval), JSON.stringify(k.events), k.docs],
      );
    await c.query("INSERT INTO credentials (org_id, key, secret_enc, domains) VALUES ($1,'demo-crm',$2,$3) ON CONFLICT DO NOTHING", [orgId, encryptSecret(JSON.stringify({ username: "analyst@acme.test", password: "s3cr3t-pa55" })), JSON.stringify(["127.0.0.1", "localhost"])]);
    const hasPol = await c.query("SELECT 1 FROM policies WHERE org_id=$1 LIMIT 1", [orgId]);
    if (!hasPol.rowCount)
      for (const f of FORBIDS) await c.query("INSERT INTO policies (org_id, effect, action, resource_pattern, description) VALUES ($1,'forbid',$2,$3,$4)", [orgId, f.action, f.pattern, f.desc]);
    for (const [id, phase, title, description, status, evidence, checkId, blocker] of REQS)
      await c.query(
        `INSERT INTO requirements (id, phase, title, description, status, evidence, check_id, blocker) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
         ON CONFLICT (id) DO UPDATE SET title=EXCLUDED.title, description=EXCLUDED.description, status=EXCLUDED.status, evidence=EXCLUDED.evidence, check_id=EXCLUDED.check_id, blocker=EXCLUDED.blocker`,
        [id, phase, title, description, status, evidence, checkId, blocker],
      );
    const has = await c.query("SELECT 1 FROM sessions WHERE org_id=$1 LIMIT 1", [orgId]);
    if (!has.rowCount)
      for (const a of AGENTS) await c.query("INSERT INTO sessions (agent_id, org_id, title) VALUES ($1,$2,$3)", [idBySlug.get(a.slug), orgId, `${a.name} · workspace`]);
    return orgId;
  } finally {
    await c.query("SELECT pg_advisory_unlock(7002)").catch(() => {});
    c.release();
  }
}

export async function getAgents(orgId: string) {
  const r = await pool.query("SELECT id, slug, name, role, manager_id, capabilities, authority_policy, skills, budget_micro, spent_micro FROM agents WHERE org_id=$1 ORDER BY created_at, slug", [orgId]);
  return r.rows;
}
