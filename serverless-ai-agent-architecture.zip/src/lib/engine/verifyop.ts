/* eslint-disable @typescript-eslint/no-explicit-any */
import { Fatal } from "@/lib/util";
import { receipt } from "@/lib/security/ledger";
import { authorize } from "@/lib/security/policy";
import { PolicyDenied } from "@/lib/util";
import { loadObject, type OpCtx, type OpResult } from "./executors";
import { type Evidence, gauntlet } from "./verify";

/**
 * Independent verification. It re-reads evidence from the object store (never trusting the builder's
 * copy), runs hard-gate checks, and loops builder-fix / blind-critic until the bar is met or no progress.
 */
export async function verifyGauntlet(ctx: OpCtx): Promise<OpResult> {
  const d = await authorize({ token: ctx.token, action: "verify.run" });
  if (!d.allow) throw new PolicyDenied(`verify.run denied: ${d.reason}`);
  const built = Object.values(ctx.deps).find((v) => v && typeof (v as any).markdown === "string") as any;
  if (!built) throw new Fatal("nothing to verify: no upstream deliverable");
  const evidence: Evidence[] = [];
  for (const e of (built.evidence ?? []) as { id: string; url: string; sha: string }[]) {
    evidence.push({ ...e, text: await loadObject(e.sha) });
  }
  const res = gauntlet({
    markdown: built.markdown,
    criteria: ctx.wu.criteria,
    evidence,
    quarantined: built.quarantined ?? [],
    derivedNumbers: built.derivedNumbers ?? [],
    sectionFixers: built.sectionFixers ?? {},
  });
  await receipt({
    workUnitId: ctx.wu.id, taskId: ctx.task.id, agentId: ctx.agentId, action: "verify.decision",
    resource: ctx.wu.id, decision: res.passed ? "allow" : "deny",
    detail: { rounds: res.rounds.length, gaps: res.gaps.map((g) => g.id) },
  });
  return {
    output: {
      passed: res.passed,
      markdown: res.markdown,
      rounds: res.rounds,
      gaps: res.gaps.map((g) => ({ id: g.id, message: g.message })),
      evidenceChecked: evidence.length,
      degraded: !!built.degraded,
      model: built.model ?? null,
    },
  };
}
