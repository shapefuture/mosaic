import { pool } from "@/db";
import { PolicyDenied, decryptSecret, glob } from "@/lib/util";
import { receipt } from "@/lib/security/ledger";

/**
 * Credential broker. The model only ever sees placeholders like {{cred:demo-crm.password}}.
 * Real values are substituted at the execution boundary and only for domains the credential is bound to.
 */
const PLACEHOLDER = /\{\{cred:([a-z0-9_-]+)\.([a-z0-9_]+)\}\}/gi;

export const hasPlaceholder = (v: string) => /\{\{cred:/.test(v);

export async function resolvePlaceholders(
  orgId: string,
  value: string,
  host: string,
  ctx: { workUnitId?: string | null; taskId?: string | null; agentId?: string | null; actor?: "agent" | "human" },
): Promise<string> {
  const matches = [...value.matchAll(PLACEHOLDER)];
  if (!matches.length) return value;
  let out = value;
  for (const m of matches) {
    const { rows } = await pool.query("SELECT secret_enc, domains FROM credentials WHERE org_id=$1 AND key=$2", [orgId, m[1]]);
    if (!rows[0]) throw new PolicyDenied(`unknown credential '${m[1]}'`);
    const domains = rows[0].domains as string[];
    if (!domains.some((d) => glob(d, host))) {
      await receipt({ ...ctx, action: "credential.use", resource: `credential:${m[1]}`, decision: "deny", detail: { host, reason: "domain binding" } });
      throw new PolicyDenied(`credential '${m[1]}' is not bound to ${host}`);
    }
    const secret = JSON.parse(decryptSecret(rows[0].secret_enc)) as Record<string, string>;
    if (!(m[2] in secret)) throw new PolicyDenied(`credential field '${m[2]}' missing`);
    out = out.replace(m[0], secret[m[2]]);
    await receipt({ ...ctx, action: "credential.use", resource: `credential:${m[1]}.${m[2]}`, detail: { host } });
  }
  return out;
}
