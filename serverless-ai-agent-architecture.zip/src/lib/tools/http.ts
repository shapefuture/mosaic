import dns from "node:dns/promises";
import net from "node:net";
import { Fatal, PolicyDenied } from "@/lib/util";

export type CookieJar = {
  header(host: string): string;
  store(host: string, setCookies: string[]): void;
};

export function isPrivateIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split(".").map(Number);
    return (
      a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127)
    );
  }
  const l = ip.toLowerCase();
  if (l === "::1" || l === "::") return true;
  if (l.startsWith("fc") || l.startsWith("fd") || l.startsWith("fe8") || l.startsWith("fe9") || l.startsWith("fea") || l.startsWith("feb")) return true;
  if (l.startsWith("::ffff:")) return isPrivateIp(l.slice(7));
  return false;
}

const LOOPBACK = new Set(["localhost", "127.0.0.1", "::1", "[::1]"]);

/** SSRF guard. Loopback is reachable only for the built-in demo origin (/api/demo/). */
export async function assertPublicTarget(u: URL) {
  if (u.protocol !== "http:" && u.protocol !== "https:") throw new PolicyDenied(`blocked protocol ${u.protocol}`);
  const host = u.hostname.replace(/^\[|\]$/g, "");
  if (LOOPBACK.has(u.hostname) || LOOPBACK.has(host)) {
    if (u.pathname.startsWith("/api/demo/")) return;
    throw new PolicyDenied("SSRF guard: loopback target blocked");
  }
  if (net.isIP(host)) {
    if (isPrivateIp(host)) throw new PolicyDenied("SSRF guard: private address blocked");
    return;
  }
  const addrs = await dns.lookup(host, { all: true }).catch(() => []);
  if (!addrs.length) throw new Fatal(`DNS resolution failed for ${host}`);
  if (addrs.some((a) => isPrivateIp(a.address))) throw new PolicyDenied("SSRF guard: host resolves to private address");
}

export type FetchResult = {
  status: number;
  url: string;
  contentType: string;
  buf: Buffer;
  text: string;
  headers: Headers;
};

export async function safeFetch(
  rawUrl: string,
  opts: {
    method?: string;
    headers?: Record<string, string>;
    body?: string;
    jar?: CookieJar;
    maxBytes?: number;
    timeoutMs?: number;
    maxRedirects?: number;
    /** Called for the initial URL and every redirect hop. */
    allowHost: (host: string) => boolean;
  },
): Promise<FetchResult> {
  let url = new URL(rawUrl);
  let method = opts.method ?? "GET";
  let body = opts.body;
  const maxRedirects = opts.maxRedirects ?? 4;
  for (let hop = 0; hop <= maxRedirects; hop++) {
    if (!opts.allowHost(url.hostname)) throw new PolicyDenied(`domain '${url.hostname}' not on allowlist`);
    await assertPublicTarget(url);
    const headers: Record<string, string> = {
      "user-agent": "AOS-v3/1.0 (+bounded-fetch)",
      accept: "text/html,application/json,text/plain,*/*;q=0.5",
      ...(opts.headers ?? {}),
    };
    const cookie = opts.jar?.header(url.hostname);
    if (cookie) headers.cookie = cookie;
    const res = await fetch(url, {
      method,
      headers,
      body: method === "GET" || method === "HEAD" ? undefined : body,
      redirect: "manual",
      signal: AbortSignal.timeout(opts.timeoutMs ?? 8000),
    });
    const sc = typeof res.headers.getSetCookie === "function" ? res.headers.getSetCookie() : [];
    if (sc.length) opts.jar?.store(url.hostname, sc);
    if (res.status >= 300 && res.status < 400 && res.headers.get("location")) {
      url = new URL(res.headers.get("location")!, url);
      if (res.status !== 307 && res.status !== 308) {
        method = "GET";
        body = undefined;
      }
      await res.arrayBuffer().catch(() => {});
      continue;
    }
    const ab = await res.arrayBuffer();
    const max = opts.maxBytes ?? 1_500_000;
    const buf = Buffer.from(ab.byteLength > max ? ab.slice(0, max) : ab);
    return {
      status: res.status,
      url: url.toString(),
      contentType: res.headers.get("content-type") ?? "",
      buf,
      text: buf.toString("utf8"),
      headers: res.headers,
    };
  }
  throw new Fatal("too many redirects");
}
