import { pool } from "@/db";
import { PolicyDenied, Fatal, hmac, sha256 } from "@/lib/util";
import { receipt } from "@/lib/security/ledger";
import { type CookieJar, safeFetch } from "./http";
import { extractPage } from "./extract";
import { hasPlaceholder, resolvePlaceholders } from "./vault";

/**
 * Persistent browser identities. Each agent owns one context (cookies + tabs) that survives across turns;
 * contexts are packed onto a small pool of "processes" with tab limits. This adapter drives pages over
 * HTTP + DOM parsing (deterministic, cheap). A CDP/Playwright/Browser Run adapter implements the same
 * BrowserAction interface for JS-rendered or visual pages.
 */
export const POOL_SIZE = Number(process.env.AOS_BROWSER_POOL ?? 2);
export const MAX_TABS_PER_CONTEXT = 4;
export const MAX_TABS_PER_PROCESS = 8;

export type Tab = {
  id: string;
  url: string;
  title: string;
  status: number;
  text: string;
  links: { i: number; text: string; href: string }[];
  forms: { i: number; action: string; method: string; fields: { name: string; type: string }[] }[];
  values: Record<string, string>;
  injection: string[];
  at: string;
};

export type BrowserAction =
  | { do: "goto"; url: string }
  | { do: "click"; link: number }
  | { do: "type"; form: number; field: string; value: string }
  | { do: "submit"; form: number }
  | { do: "newtab"; url?: string }
  | { do: "switch"; tab: number }
  | { do: "close"; tab: number }
  | { do: "download"; url?: string; link?: number }
  | { do: "snapshot" };

type Ctx = {
  id: string;
  agent_id: string;
  org_id: string;
  process_id: string;
  cookies: Record<string, Record<string, string>>;
  tabs: Tab[];
  active_tab: number;
  downloads: unknown[];
  live_epoch: number;
};

export async function getContext(agentId: string, orgId: string): Promise<Ctx> {
  const ex = await pool.query("SELECT * FROM browser_contexts WHERE agent_id=$1", [agentId]);
  if (ex.rows[0]) return ex.rows[0] as Ctx;
  const load = await pool.query(
    "SELECT process_id, COALESCE(SUM(jsonb_array_length(tabs)),0)::int AS n FROM browser_contexts GROUP BY process_id",
  );
  const counts = new Map<string, number>(load.rows.map((r) => [r.process_id as string, r.n as number]));
  let best = "bp-1";
  let bestN = Infinity;
  for (let i = 1; i <= POOL_SIZE; i++) {
    const n = counts.get(`bp-${i}`) ?? 0;
    if (n < bestN) {
      best = `bp-${i}`;
      bestN = n;
    }
  }
  const ins = await pool.query(
    `INSERT INTO browser_contexts (agent_id, org_id, process_id) VALUES ($1,$2,$3)
     ON CONFLICT (agent_id) DO UPDATE SET agent_id=EXCLUDED.agent_id RETURNING *`,
    [agentId, orgId, best],
  );
  return ins.rows[0] as Ctx;
}

export async function getContextById(id: string): Promise<Ctx | null> {
  const r = await pool.query("SELECT * FROM browser_contexts WHERE id=$1", [id]);
  return (r.rows[0] as Ctx) ?? null;
}

function makeJar(cookies: Ctx["cookies"]): CookieJar {
  return {
    header: (host) =>
      Object.entries(cookies[host] ?? {})
        .map(([k, v]) => `${k}=${v}`)
        .join("; "),
    store: (host, setCookies) => {
      const jar = (cookies[host] ??= {});
      for (const sc of setCookies) {
        const [pair, ...attrs] = sc.split(";");
        const eq = pair.indexOf("=");
        if (eq < 1) continue;
        const name = pair.slice(0, eq).trim();
        const val = pair.slice(eq + 1).trim();
        const expired = attrs.some((a) => /^\s*max-age\s*=\s*0/i.test(a)) || val === "";
        if (expired) delete jar[name];
        else jar[name] = val;
      }
    },
  };
}

const sanitizeTab = (t: Tab) => ({
  id: t.id,
  url: t.url,
  title: t.title,
  status: t.status,
  textPreview: t.text.slice(0, 1600),
  links: t.links.slice(0, 25),
  forms: t.forms.map((f) => ({
    ...f,
    fields: f.fields.map((x) => ({ ...x, value: t.values[`${f.i}.${x.name}`] ?? "" })),
  })),
  injection: t.injection,
});
export type TabView = ReturnType<typeof sanitizeTab>;

async function persist(ctx: Ctx) {
  await pool.query(
    `UPDATE browser_contexts SET cookies=$2, tabs=$3, active_tab=$4, downloads=$5, updated_at=now() WHERE id=$1`,
    [ctx.id, JSON.stringify(ctx.cookies), JSON.stringify(ctx.tabs), ctx.active_tab, JSON.stringify(ctx.downloads)],
  );
}

async function processTabLoad(processId: string) {
  const r = await pool.query(
    "SELECT COALESCE(SUM(jsonb_array_length(tabs)),0)::int AS n FROM browser_contexts WHERE process_id=$1",
    [processId],
  );
  return r.rows[0].n as number;
}

export type ActOpts = {
  actor: "agent" | "human";
  allowHost: (host: string) => boolean;
  workUnitId?: string | null;
  taskId?: string | null;
  idemKey?: string; // side-effect idempotency key for this step
};

async function load(ctx: Ctx, tab: Tab, url: string, opts: ActOpts, method = "GET", body?: string) {
  const jar = makeJar(ctx.cookies);
  const res = await safeFetch(url, {
    method,
    body,
    headers: body ? { "content-type": "application/x-www-form-urlencoded" } : undefined,
    jar,
    allowHost: opts.allowHost,
  });
  const isHtml = /html|xml/.test(res.contentType) || /^\s*</.test(res.text.slice(0, 40));
  if (isHtml) {
    const p = extractPage(res.text, res.url);
    Object.assign(tab, { url: res.url, title: p.title, status: res.status, text: p.text, links: p.links, forms: p.forms, injection: p.injection, values: {} });
  } else {
    Object.assign(tab, { url: res.url, title: res.contentType || "document", status: res.status, text: res.text.slice(0, 4000), links: [], forms: [], injection: [], values: {} });
  }
  tab.at = new Date().toISOString();
}

export async function browserAct(contextId: string, action: BrowserAction, opts: ActOpts) {
  const ctx = await getContextById(contextId);
  if (!ctx) throw new Fatal("browser context not found");
  const ident = { workUnitId: opts.workUnitId, taskId: opts.taskId, agentId: ctx.agent_id, actor: opts.actor };
  const blank = (): Tab => ({ id: sha256(Math.random() + "").slice(0, 6), url: "about:blank", title: "New tab", status: 0, text: "", links: [], forms: [], values: {}, injection: [], at: new Date().toISOString() });
  const active = () => {
    if (!ctx.tabs.length) ctx.tabs.push(blank());
    return ctx.tabs[Math.min(ctx.active_tab, ctx.tabs.length - 1)];
  };
  let download: { name: string; sha256: string; bytes: number } | undefined;
  let skipped = false;

  switch (action.do) {
    case "snapshot":
      break;
    case "newtab": {
      if (ctx.tabs.length >= MAX_TABS_PER_CONTEXT) throw new Fatal(`tab limit (${MAX_TABS_PER_CONTEXT}) reached for this context`);
      if ((await processTabLoad(ctx.process_id)) >= MAX_TABS_PER_PROCESS) throw new Fatal(`browser process ${ctx.process_id} is at its memory-aware tab ceiling`);
      const t = blank();
      ctx.tabs.push(t);
      ctx.active_tab = ctx.tabs.length - 1;
      if (action.url) await load(ctx, t, action.url, opts);
      break;
    }
    case "switch":
      if (action.tab < 0 || action.tab >= ctx.tabs.length) throw new Fatal("no such tab");
      ctx.active_tab = action.tab;
      break;
    case "close":
      if (action.tab < 0 || action.tab >= ctx.tabs.length) throw new Fatal("no such tab");
      ctx.tabs.splice(action.tab, 1);
      ctx.active_tab = Math.max(0, Math.min(ctx.active_tab, ctx.tabs.length - 1));
      break;
    case "goto":
      await load(ctx, active(), action.url, opts);
      break;
    case "click": {
      const t = active();
      const l = t.links.find((x) => x.i === action.link);
      if (!l) throw new Fatal(`no link #${action.link} on page`);
      await load(ctx, t, l.href, opts);
      break;
    }
    case "type": {
      const t = active();
      const f = t.forms.find((x) => x.i === action.form);
      if (!f || !f.fields.some((x) => x.name === action.field)) throw new Fatal(`no field '${action.field}' in form #${action.form}`);
      t.values[`${action.form}.${action.field}`] = action.value; // placeholders stay unresolved at rest
      break;
    }
    case "submit": {
      const t = active();
      const f = t.forms.find((x) => x.i === action.form);
      if (!f) throw new Fatal(`no form #${action.form}`);
      if (opts.idemKey) {
        const r = await receipt({ ...ident, action: "browser.submit", resource: f.action, sideEffect: true, idempotencyKey: opts.idemKey, detail: { method: f.method, fields: f.fields.map((x) => x.name) } });
        if (r.duplicate) {
          skipped = true;
          break;
        }
      }
      const host = new URL(f.action).hostname;
      const params = new URLSearchParams();
      for (const fld of f.fields) {
        let v = t.values[`${f.i}.${fld.name}`] ?? "";
        if (hasPlaceholder(v)) v = await resolvePlaceholders(ctx.org_id, v, host, ident);
        params.set(fld.name, v);
      }
      if (f.method === "GET") await load(ctx, t, `${f.action}${f.action.includes("?") ? "&" : "?"}${params}`, opts);
      else await load(ctx, t, f.action, opts, "POST", params.toString());
      break;
    }
    case "download": {
      const t = active();
      const url = action.url ?? t.links.find((x) => x.i === action.link)?.href;
      if (!url) throw new Fatal("download needs a url or link index");
      const res = await safeFetch(url, { jar: makeJar(ctx.cookies), allowHost: opts.allowHost, maxBytes: 3_000_000 });
      if (res.status >= 400) throw new Fatal(`download failed with HTTP ${res.status}`);
      const textual = /text|csv|json|xml/.test(res.contentType);
      const content = textual ? res.text : res.buf.toString("base64");
      const sha = sha256(res.buf);
      const name = decodeURIComponent(new URL(res.url).pathname.split("/").pop() || "download");
      await pool.query(
        "INSERT INTO objects (sha256, mime, bytes, content) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING",
        [sha, textual ? res.contentType || "text/plain" : "application/octet-stream;base64", res.buf.length, content],
      );
      if (opts.workUnitId)
        await pool.query(
          "INSERT INTO artifacts (work_unit_id, task_id, kind, name, sha256, bytes) VALUES ($1,$2,'download',$3,$4,$5)",
          [opts.workUnitId, opts.taskId ?? null, name, sha, res.buf.length],
        );
      download = { name, sha256: sha, bytes: res.buf.length };
      ctx.downloads.push({ ...download, at: new Date().toISOString() });
      await receipt({ ...ident, action: "browser.download", resource: url, detail: download });
      break;
    }
  }
  await persist(ctx);
  const t = active();
  return { tab: sanitizeTab(t), tabs: ctx.tabs.map((x, i) => ({ i, id: x.id, url: x.url, title: x.title })), activeTab: ctx.active_tab, download, skipped, processId: ctx.process_id };
}

export async function browserView(contextId: string) {
  const ctx = await getContextById(contextId);
  if (!ctx) return null;
  const t = ctx.tabs[Math.min(ctx.active_tab, ctx.tabs.length - 1)];
  return {
    id: ctx.id,
    agentId: ctx.agent_id,
    processId: ctx.process_id,
    tab: t ? sanitizeTab(t) : null,
    tabs: ctx.tabs.map((x, i) => ({ i, id: x.id, url: x.url, title: x.title })),
    activeTab: ctx.active_tab,
    cookieHosts: Object.entries(ctx.cookies).map(([h, c]) => ({ host: h, names: Object.keys(c) })),
    downloads: ctx.downloads as { name: string; sha256: string; bytes: number; at: string }[],
  };
}

// ---- Live View: bearer URL for authenticated humans only. Never returned by any agent-facing op. ----
export function mintLiveToken(ctx: { id: string; live_epoch: number }, ttlSec = 900) {
  const exp = Math.floor(Date.now() / 1000) + ttlSec;
  const body = `${ctx.id}.${exp}.${ctx.live_epoch}`;
  return `${body}.${hmac("live:" + body)}`;
}

export async function verifyLiveToken(token: string): Promise<Ctx | null> {
  const parts = token.split(".");
  if (parts.length !== 4) return null;
  const [id, exp, epoch, sig] = parts;
  if (hmac("live:" + `${id}.${exp}.${epoch}`) !== sig) return null;
  if (Number(exp) < Date.now() / 1000) return null;
  const ctx = await getContextById(id);
  if (!ctx || ctx.live_epoch !== Number(epoch)) return null;
  return ctx;
}

export const revokeLiveLinks = (contextId: string) =>
  pool.query("UPDATE browser_contexts SET live_epoch = live_epoch + 1 WHERE id=$1", [contextId]);

export { PolicyDenied };
