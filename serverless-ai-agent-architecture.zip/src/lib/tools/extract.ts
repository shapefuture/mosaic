import * as cheerio from "cheerio";

export type PricePoint = { label: string; amount: number; unit: string; raw: string };
export type Page = {
  title: string;
  entity: string;
  headings: string[];
  text: string;
  links: { i: number; text: string; href: string }[];
  forms: { i: number; action: string; method: string; fields: { name: string; type: string }[] }[];
  prices: PricePoint[];
  facts: string[];
  injection: string[];
};

const INJECTION = [
  /ignore (all |any )?(the )?(previous|prior|above|earlier) (instructions|rules|prompts?)/i,
  /disregard (all |any )?(the )?(previous|prior|above|your) (instructions|rules|policy|policies)/i,
  /you are now (a|an|in) /i,
  /(reveal|print|send|exfiltrate|email).{0,40}(password|secret|credential|api key|token)/i,
  /(grant|give) (yourself|me|this agent) .{0,20}(admin|permission|access|authority)/i,
  /<\s*\/?\s*system\s*>/i,
  /new (system )?instructions?:/i,
];

export function detectInjection(text: string): string[] {
  const hits: string[] = [];
  for (const re of INJECTION) {
    const m = text.match(re);
    if (m) {
      const i = m.index ?? 0;
      hits.push(text.slice(Math.max(0, i - 20), i + m[0].length + 40).replace(/\s+/g, " ").trim());
    }
  }
  return hits;
}

const PRICE = /(?:\$|USD\s?)(\d[\d,]*(?:\.\d{1,2})?)\s*(?:\/\s*|per\s+)?(mo(?:nth)?|yr|year|user|seat|month)?/i;

export function extractPage(html: string, baseUrl: string): Page {
  const $ = cheerio.load(html);
  $("script,style,noscript,template").remove();
  const title = $("title").first().text().trim() || $("h1").first().text().trim() || baseUrl;
  const entity = title.split(/\s[-|–—·:]\s/)[0].split(/\s+/)[0] || "unknown";
  const headings = $("h1,h2,h3")
    .map((_, e) => $(e).text().replace(/\s+/g, " ").trim())
    .get()
    .filter(Boolean)
    .slice(0, 20);
  const text = $("body").text().replace(/[ \t]+/g, " ").replace(/\n\s*\n+/g, "\n").trim().slice(0, 24000);

  const links = $("a[href]")
    .map((i, e) => {
      let href = $(e).attr("href") ?? "";
      try {
        href = new URL(href, baseUrl).toString();
      } catch {
        /* keep raw */
      }
      return { i, text: $(e).text().replace(/\s+/g, " ").trim().slice(0, 80), href };
    })
    .get()
    .slice(0, 60)
    .map((l, i) => ({ ...l, i }));

  const forms = $("form")
    .map((i, f) => {
      let action = $(f).attr("action") ?? baseUrl;
      try {
        action = new URL(action, baseUrl).toString();
      } catch {
        /* keep raw */
      }
      const fields = $(f)
        .find("input[name],select[name],textarea[name]")
        .map((_, el) => ({ name: $(el).attr("name") ?? "", type: $(el).attr("type") ?? el.tagName }))
        .get();
      return { i, action, method: ($(f).attr("method") ?? "GET").toUpperCase(), fields };
    })
    .get();

  const prices: PricePoint[] = [];
  const seen = new Set<string>();
  $("body *").each((_, el) => {
    const $el = $(el);
    if ($el.children().length > 0 && $el.children().text().match(/\$/)) return; // leaf-most only
    const own = $el.text().replace(/\s+/g, " ").trim();
    const m = own.match(PRICE);
    if (!m || own.length > 160) return;
    const container = $el.closest("section,article,li,tr,.plan,.card,div");
    let label = container.find("h1,h2,h3,h4,strong,th,.name").first().text().replace(/\s+/g, " ").trim();
    if (!label) label = own.replace(PRICE, "").replace(/[:\-–|]+/g, " ").trim();
    label = label.replace(/\bplan\b/i, "").trim().slice(0, 60) || "item";
    const amount = Number(m[1].replace(/,/g, ""));
    const unit = (m[2] ?? "").toLowerCase().replace(/^mo(nth)?$/, "month").replace(/^yr$/, "year");
    const k = `${label}|${amount}|${unit}`;
    if (seen.has(k)) return;
    seen.add(k);
    prices.push({ label, amount, unit, raw: m[0].trim() });
  });

  const sentences = text.split(/(?<=[.!?])\s+|\n/).map((s) => s.trim()).filter((s) => s.length > 25 && s.length < 240);
  const facts = sentences.filter((s) => /\d/.test(s) && !/^\$?\d+$/.test(s)).slice(0, 14);

  return { title, entity, headings, text, links, forms, prices, facts, injection: detectInjection(text) };
}
