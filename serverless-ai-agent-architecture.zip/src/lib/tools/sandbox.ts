import vm from "node:vm";

/**
 * Tier-1 "lite" execution: pure-JS, no I/O globals, no network, hard CPU timeout.
 * Data crosses the boundary as a JSON string and is parsed inside the context, so no
 * host-realm objects (and their constructors) are reachable. This is NOT a hostile-code
 * boundary; untrusted code belongs in Tier 2 (microVM provider adapter).
 */
export function runJs(code: string, data: unknown, timeoutMs = 1500): unknown {
  const ctx = vm.createContext(
    { __d: JSON.stringify(data ?? null) },
    { codeGeneration: { strings: false, wasm: false } },
  );
  const script = new vm.Script(
    `"use strict"; (function(){ const data = JSON.parse(__d); ${code}\n })()`,
    { filename: "aos-tier1.js" },
  );
  const out = script.runInContext(ctx, { timeout: timeoutMs });
  const json = vm.runInContext("JSON.stringify", ctx)(out === undefined ? null : out) as string;
  if (json && json.length > 200_000) throw new Error("result too large");
  return JSON.parse(json ?? "null");
}
