import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes } from "node:crypto";

export const sha256 = (s: string | Buffer) => createHash("sha256").update(s).digest("hex");
export const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
export const rand = (n = 6) => randomBytes(n).toString("hex");

export function percentile(arr: number[], p: number) {
  if (!arr.length) return 0;
  const s = [...arr].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.floor(p * s.length))];
}

/** Signing key for capability tokens. Set AOS_SIGNING_KEY in production. */
export function signingKey() {
  return process.env.AOS_SIGNING_KEY ?? sha256("aos-dev-key:" + (process.env.DATABASE_URL ?? ""));
}
export const hmac = (data: string) => createHmac("sha256", signingKey()).update(data).digest("base64url");

export const appOrigin = () => `http://127.0.0.1:${process.env.PORT ?? 3000}`;

export function usd(micro: number) {
  return `$${(micro / 1e6).toFixed(4)}`;
}

/** Glob match where * matches anything. */
export function glob(pattern: string, value: string) {
  if (pattern === "*") return true;
  const re = new RegExp("^" + pattern.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*") + "$");
  return re.test(value);
}

// AES-256-GCM for the credential vault.
const vaultKey = () => createHash("sha256").update("vault:" + signingKey()).digest();
export function encryptSecret(plain: string) {
  const iv = randomBytes(12);
  const c = createCipheriv("aes-256-gcm", vaultKey(), iv);
  const enc = Buffer.concat([c.update(plain, "utf8"), c.final()]);
  return [iv.toString("base64"), c.getAuthTag().toString("base64"), enc.toString("base64")].join(".");
}
export function decryptSecret(blob: string) {
  const [iv, tag, enc] = blob.split(".").map((p) => Buffer.from(p, "base64"));
  const d = createDecipheriv("aes-256-gcm", vaultKey(), iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(enc), d.final()]).toString("utf8");
}

export class Fatal extends Error {}
export class PolicyDenied extends Fatal {}
