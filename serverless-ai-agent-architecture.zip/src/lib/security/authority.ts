import { glob, hmac, rand } from "@/lib/util";

/** Signed capability token ("Authority Envelope"). An agent can request; it cannot self-authorize. */
export type Authority = {
  jti: string;
  parent_jti?: string;
  agent_id: string;
  work_unit_id: string;
  session_id?: string;
  actions: string[];
  resources: string[];
  domains: string[];
  max_cost: number; // micro-USD
  expires_at: number; // epoch seconds
  delegation_depth: number; // remaining delegations allowed
  policy_version: string;
};

export class EscalationError extends Error {}

export function signAuthority(a: Authority): string {
  const body = Buffer.from(JSON.stringify(a)).toString("base64url");
  return `${body}.${hmac(body)}`;
}

export function verifyAuthority(
  token: string,
): { ok: true; authority: Authority } | { ok: false; reason: string } {
  const [body, sig] = (token ?? "").split(".");
  if (!body || !sig) return { ok: false, reason: "malformed token" };
  if (hmac(body) !== sig) return { ok: false, reason: "invalid signature" };
  try {
    const a = JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as Authority;
    if (a.expires_at < Math.floor(Date.now() / 1000)) return { ok: false, reason: "token expired" };
    return { ok: true, authority: a };
  } catch {
    return { ok: false, reason: "unparseable token" };
  }
}

const covered = (parentPatterns: string[], child: string) =>
  parentPatterns.some((p) => glob(p, child));

/**
 * Derive a child authority. Invariant: no child has more authority than its parent.
 * strict=true throws if the child asks for anything outside the parent; strict=false clamps to the intersection.
 */
export function attenuate(
  parent: Authority,
  req: {
    agent_id: string;
    work_unit_id: string;
    session_id?: string;
    actions?: string[];
    resources?: string[];
    domains?: string[];
    max_cost?: number;
    expires_at?: number;
  },
  strict = false,
): Authority {
  if (parent.delegation_depth <= 0) throw new EscalationError("delegation depth exhausted");
  const pick = (want: string[] | undefined, have: string[], label: string) => {
    if (!want) return have;
    const ok = want.filter((w) => covered(have, w));
    if (strict && ok.length !== want.length)
      throw new EscalationError(`${label} exceed parent: ${want.filter((w) => !ok.includes(w)).join(", ")}`);
    return ok;
  };
  const max_cost = Math.min(req.max_cost ?? parent.max_cost, parent.max_cost);
  if (strict && req.max_cost && req.max_cost > parent.max_cost) throw new EscalationError("budget exceeds parent");
  if (strict && req.expires_at && req.expires_at > parent.expires_at) throw new EscalationError("expiry exceeds parent");
  return {
    jti: rand(8),
    parent_jti: parent.jti,
    agent_id: req.agent_id,
    work_unit_id: req.work_unit_id,
    session_id: req.session_id ?? parent.session_id,
    actions: pick(req.actions, parent.actions, "actions"),
    resources: pick(req.resources, parent.resources, "resources"),
    domains: pick(req.domains, parent.domains, "domains"),
    max_cost,
    expires_at: Math.min(req.expires_at ?? parent.expires_at, parent.expires_at),
    delegation_depth: parent.delegation_depth - 1,
    policy_version: parent.policy_version,
  };
}

export const POLICY_VERSION = "v3.1";
