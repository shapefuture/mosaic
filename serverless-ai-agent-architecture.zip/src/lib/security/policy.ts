import { pool } from "@/db";
import { glob } from "@/lib/util";
import { type Authority, verifyAuthority } from "./authority";

export type Decision = { allow: boolean; reason: string; authority?: Authority };

let cache: { at: number; rows: { action: string; resource_pattern: string; description: string }[] } | null = null;
async function forbids() {
  if (cache && Date.now() - cache.at < 5000) return cache.rows;
  const { rows } = await pool.query(
    "SELECT action, resource_pattern, description FROM policies WHERE enabled AND effect='forbid'",
  );
  cache = { at: Date.now(), rows };
  return rows;
}
export const invalidatePolicyCache = () => {
  cache = null;
};

/**
 * Deterministic authorization at the tool gateway. Default deny.
 * Permit comes from the signed capability; org-level forbid rules always win.
 */
export async function authorize(input: {
  token: string;
  action: string;
  resource?: string;
  target?: string;
  domain?: string;
  costMicro?: number;
  spentMicro?: number;
}): Promise<Decision> {
  const v = verifyAuthority(input.token);
  if (!v.ok) return { allow: false, reason: `capability rejected: ${v.reason}` };
  const a = v.authority;
  if (!a.actions.some((p) => glob(p, input.action)))
    return { allow: false, reason: `action '${input.action}' not granted`, authority: a };
  if (input.resource && !a.resources.some((p) => glob(p, input.resource!)))
    return { allow: false, reason: `resource '${input.resource}' outside scope`, authority: a };
  if (input.domain && !a.domains.some((p) => glob(p, input.domain!)))
    return { allow: false, reason: `domain '${input.domain}' not on allowlist`, authority: a };
  if (input.costMicro && (input.spentMicro ?? 0) + input.costMicro > a.max_cost)
    return { allow: false, reason: "cost ceiling exceeded", authority: a };
  const target = [input.resource, input.target, input.domain].filter(Boolean).join(" ");
  for (const f of await forbids()) {
    if (glob(f.action, input.action) && glob(f.resource_pattern, target || "*"))
      return { allow: false, reason: `forbidden by org policy: ${f.description}`, authority: a };
  }
  return { allow: true, reason: "permitted", authority: a };
}
