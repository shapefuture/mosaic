import { pool } from "@/db";
import { sha256 } from "@/lib/util";

export type ReceiptInput = {
  workUnitId?: string | null;
  taskId?: string | null;
  agentId?: string | null;
  actor?: "agent" | "human" | "system";
  action: string;
  resource?: string;
  decision?: "allow" | "deny";
  sideEffect?: boolean;
  idempotencyKey?: string | null;
  detail?: Record<string, unknown>;
};

/**
 * Append a hash-chained receipt. Only meaningful boundaries are recorded
 * (authorizations, side effects, approvals, commits) - never streamed tokens.
 * Returns { duplicate: true } when a side-effect idempotency key was already recorded.
 */
export async function receipt(r: ReceiptInput): Promise<{ id: number | null; duplicate: boolean }> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("SELECT pg_advisory_xact_lock(7001)");
    if (r.sideEffect && r.idempotencyKey) {
      const ex = await client.query(
        "SELECT id FROM receipts WHERE side_effect AND idempotency_key=$1 LIMIT 1",
        [r.idempotencyKey],
      );
      if (ex.rowCount) {
        await client.query("COMMIT");
        return { id: ex.rows[0].id, duplicate: true };
      }
    }
    const last = await client.query("SELECT hash FROM receipts ORDER BY id DESC LIMIT 1");
    const prev = last.rows[0]?.hash ?? "";
    const createdAt = new Date().toISOString();
    const payload = JSON.stringify([
      prev, r.workUnitId ?? null, r.taskId ?? null, r.agentId ?? null, r.actor ?? "agent",
      r.action, r.resource ?? "", r.decision ?? "allow", !!r.sideEffect, r.idempotencyKey ?? null,
      r.detail ?? {}, createdAt,
    ]);
    const hash = sha256(payload);
    const ins = await client.query(
      `INSERT INTO receipts (work_unit_id, task_id, agent_id, actor, action, resource, decision, side_effect, idempotency_key, detail, prev_hash, hash, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING id`,
      [
        r.workUnitId ?? null, r.taskId ?? null, r.agentId ?? null, r.actor ?? "agent", r.action,
        r.resource ?? "", r.decision ?? "allow", !!r.sideEffect, r.sideEffect ? (r.idempotencyKey ?? null) : null,
        JSON.stringify(r.detail ?? {}), prev, hash, createdAt,
      ],
    );
    await client.query("COMMIT");
    return { id: ins.rows[0].id, duplicate: false };
  } catch (e) {
    await client.query("ROLLBACK").catch(() => {});
    throw e;
  } finally {
    client.release();
  }
}

/** Verify the chain is intact (tamper evidence). Recomputes by chain linkage only. */
export async function verifyChain(limit = 500) {
  const { rows } = await pool.query(
    "SELECT id, prev_hash, hash FROM receipts ORDER BY id DESC LIMIT $1",
    [limit],
  );
  rows.reverse();
  let broken: number | null = null;
  for (let i = 1; i < rows.length; i++) {
    if (rows[i].prev_hash !== rows[i - 1].hash) {
      broken = rows[i].id;
      break;
    }
  }
  return { checked: rows.length, intact: broken === null, brokenAt: broken };
}
