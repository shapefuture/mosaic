import { sql } from "drizzle-orm";
import {
  bigint,
  bigserial,
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

const big = (name: string) => bigint(name, { mode: "number" });

/** Tenants. */
export const organizations = pgTable("organizations", {
  id: uuid("id").primaryKey().defaultRandom(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  tenantConcurrency: integer("tenant_concurrency").notNull().default(48),
  budgetMicro: big("budget_micro").notNull().default(50_000_000),
  spentMicro: big("spent_micro").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** A logical agent is an identity + role + capabilities, never a process. */
export const agents = pgTable(
  "agents",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orgId: uuid("org_id").notNull(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    role: text("role").notNull(),
    managerId: uuid("manager_id"),
    profileVersion: integer("profile_version").notNull().default(1),
    capabilities: jsonb("capabilities").$type<string[]>().notNull().default([]),
    modelPolicy: jsonb("model_policy").$type<Record<string, string>>().notNull().default({}),
    memoryScope: text("memory_scope").notNull().default("org"),
    authorityPolicy: jsonb("authority_policy")
      .$type<{
        actions: string[];
        resources: string[];
        domains: string[];
        maxCostMicro: number;
        delegationDepth: number;
      }>()
      .notNull(),
    skills: jsonb("skills").$type<string[]>().notNull().default([]),
    budgetMicro: big("budget_micro").notNull().default(5_000_000),
    spentMicro: big("spent_micro").notNull().default(0),
    status: text("status").notNull().default("idle"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("agents_org_slug").on(t.orgId, t.slug)],
);

/** Hibernating durable sessions. Transcript is stored, nothing is resident. */
export const sessions = pgTable(
  "sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    agentId: uuid("agent_id").notNull(),
    orgId: uuid("org_id").notNull(),
    title: text("title").notNull().default("Session"),
    status: text("status").notNull().default("hibernated"),
    transcript: jsonb("transcript")
      .$type<{ role: string; content: string; at: string }[]>()
      .notNull()
      .default([]),
    turnCount: integer("turn_count").notNull().default(0),
    wakeCount: integer("wake_count").notNull().default(0),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true }).notNull().defaultNow(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("sessions_agent").on(t.agentId), index("sessions_status").on(t.status)],
);

/** The durable business task: a Work Unit owns a task DAG. */
export const workUnits = pgTable(
  "work_units",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orgId: uuid("org_id").notNull(),
    ownerAgentId: uuid("owner_agent_id").notNull(),
    sessionId: uuid("session_id"),
    idempotencyKey: text("idempotency_key").unique(),
    template: text("template").notNull(),
    objective: text("objective").notNull(),
    params: jsonb("params").$type<Record<string, unknown>>().notNull().default({}),
    criteria: jsonb("criteria").$type<Record<string, unknown>>().notNull().default({}),
    bar: text("bar").notNull().default(""),
    status: text("status").notNull().default("running"),
    authorityToken: text("authority_token").notNull(),
    budgetMicro: big("budget_micro").notNull().default(500_000),
    spentMicro: big("spent_micro").notNull().default(0),
    deliverable: text("deliverable"),
    result: jsonb("result").$type<Record<string, unknown>>(),
    error: text("error"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    completedAt: timestamp("completed_at", { withTimezone: true }),
  },
  (t) => [index("wu_status").on(t.status), index("wu_org").on(t.orgId)],
);

export const tasks = pgTable(
  "tasks",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workUnitId: uuid("work_unit_id").notNull(),
    key: text("key").notNull(),
    title: text("title").notNull(),
    op: text("op").notNull(),
    queue: text("queue").notNull(),
    tier: integer("tier").notNull().default(0),
    agentId: uuid("agent_id"),
    input: jsonb("input").$type<Record<string, unknown>>().notNull().default({}),
    output: jsonb("output").$type<Record<string, unknown>>(),
    status: text("status").notNull().default("pending"),
    deps: jsonb("deps").$type<string[]>().notNull().default([]),
    softDeps: boolean("soft_deps").notNull().default(false),
    attempts: integer("attempts").notNull().default(0),
    maxAttempts: integer("max_attempts").notNull().default(3),
    leaseUntil: timestamp("lease_until", { withTimezone: true }),
    workerId: text("worker_id"),
    error: text("error"),
    priority: integer("priority").notNull().default(5),
    requiresApproval: boolean("requires_approval").notNull().default(false),
    approvalState: text("approval_state").notNull().default("none"),
    costMicro: big("cost_micro").notNull().default(0),
    queuedAt: timestamp("queued_at", { withTimezone: true }).notNull().defaultNow(),
    readyAt: timestamp("ready_at", { withTimezone: true }),
    startedAt: timestamp("started_at", { withTimezone: true }),
    finishedAt: timestamp("finished_at", { withTimezone: true }),
  },
  (t) => [
    uniqueIndex("tasks_wu_key").on(t.workUnitId, t.key),
    index("tasks_status_queue").on(t.status, t.queue),
    index("tasks_wu").on(t.workUnitId),
  ],
);

/** Adaptive per-queue concurrency state (feedback scheduler). */
export const queueState = pgTable("queue_state", {
  queue: text("queue").primaryKey(),
  concurrency: integer("concurrency").notNull(),
  minConcurrency: integer("min_concurrency").notNull(),
  maxConcurrency: integer("max_concurrency").notNull(),
  providerCap: integer("provider_cap").notNull(),
  p50Ms: real("p50_ms").notNull().default(0),
  p95Ms: real("p95_ms").notNull().default(0),
  errRate: real("err_rate").notNull().default(0),
  completed: integer("completed").notNull().default(0),
  failed: integer("failed").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Hash-chained audit ledger of meaningful boundaries only. */
export const receipts = pgTable(
  "receipts",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    workUnitId: uuid("work_unit_id"),
    taskId: uuid("task_id"),
    agentId: uuid("agent_id"),
    actor: text("actor").notNull().default("agent"),
    action: text("action").notNull(),
    resource: text("resource").notNull().default(""),
    decision: text("decision").notNull().default("allow"),
    sideEffect: boolean("side_effect").notNull().default(false),
    idempotencyKey: text("idempotency_key"),
    detail: jsonb("detail").$type<Record<string, unknown>>().notNull().default({}),
    prevHash: text("prev_hash").notNull().default(""),
    hash: text("hash").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("receipts_side_effect_key")
      .on(t.idempotencyKey)
      .where(sql`side_effect = true and idempotency_key is not null`),
    index("receipts_wu").on(t.workUnitId),
  ],
);

/** Content-addressed object storage (R2 stand-in). */
export const objects = pgTable("objects", {
  sha256: text("sha256").primaryKey(),
  mime: text("mime").notNull().default("text/plain"),
  bytes: integer("bytes").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const artifacts = pgTable(
  "artifacts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workUnitId: uuid("work_unit_id"),
    taskId: uuid("task_id"),
    kind: text("kind").notNull(),
    name: text("name").notNull(),
    sha256: text("sha256").notNull(),
    bytes: integer("bytes").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("artifacts_wu").on(t.workUnitId)],
);

export const memories = pgTable(
  "memories",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orgId: uuid("org_id").notNull(),
    scope: text("scope").notNull().default("org"),
    scopeRef: text("scope_ref").notNull().default(""),
    kind: text("kind").notNull().default("semantic"),
    subject: text("subject").notNull().default(""),
    value: text("value"),
    content: text("content").notNull(),
    contentHash: text("content_hash").notNull(),
    sourceUrl: text("source_url"),
    evidenceSha: text("evidence_sha"),
    workUnitId: uuid("work_unit_id"),
    trust: real("trust").notNull().default(0.5),
    status: text("status").notNull().default("candidate"),
    hits: integer("hits").notNull().default(1),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("memories_org_hash").on(t.orgId, t.contentHash),
    index("memories_fts").using("gin", sql`to_tsvector('english', ${t.content})`),
  ],
);

export const skills = pgTable(
  "skills",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orgId: uuid("org_id").notNull(),
    name: text("name").notNull(),
    version: integer("version").notNull().default(1),
    description: text("description").notNull().default(""),
    procedure: jsonb("procedure").$type<Record<string, unknown>>().notNull(),
    status: text("status").notNull().default("draft"),
    tests: jsonb("tests").$type<Record<string, unknown>>().notNull().default({}),
    sourceWorkUnitId: uuid("source_work_unit_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("skills_org_name_ver").on(t.orgId, t.name, t.version)],
);

export const connectors = pgTable("connectors", {
  id: uuid("id").primaryKey().defaultRandom(),
  key: text("key").notNull().unique(),
  provider: text("provider").notNull(),
  authType: text("auth_type").notNull(),
  supportedActions: jsonb("supported_actions").$type<string[]>().notNull(),
  rateLimitPerMin: integer("rate_limit_per_min").notNull().default(600),
  approvalRequired: jsonb("approval_required").$type<string[]>().notNull().default([]),
  eventSubscriptions: jsonb("event_subscriptions").$type<string[]>().notNull().default([]),
  health: text("health").notNull().default("healthy"),
  docs: text("docs").notNull().default(""),
});

/** Credential broker vault. Secrets are encrypted at rest, domain-bound, and never shown to a model. */
export const credentials = pgTable(
  "credentials",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orgId: uuid("org_id").notNull(),
    key: text("key").notNull(),
    secretEnc: text("secret_enc").notNull(),
    domains: jsonb("domains").$type<string[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("credentials_org_key").on(t.orgId, t.key)],
);

/** One persistent browser identity (cookies + tabs) per agent, pooled onto few processes. */
export const browserContexts = pgTable("browser_contexts", {
  id: uuid("id").primaryKey().defaultRandom(),
  agentId: uuid("agent_id").notNull().unique(),
  orgId: uuid("org_id").notNull(),
  processId: text("process_id").notNull(),
  cookies: jsonb("cookies").$type<Record<string, Record<string, string>>>().notNull().default({}),
  tabs: jsonb("tabs").$type<unknown[]>().notNull().default([]),
  activeTab: integer("active_tab").notNull().default(0),
  downloads: jsonb("downloads").$type<unknown[]>().notNull().default([]),
  liveEpoch: integer("live_epoch").notNull().default(1),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const approvals = pgTable(
  "approvals",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workUnitId: uuid("work_unit_id").notNull(),
    taskId: uuid("task_id").notNull(),
    kind: text("kind").notNull(),
    status: text("status").notNull().default("pending"),
    payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default({}),
    note: text("note"),
    requestedAt: timestamp("requested_at", { withTimezone: true }).notNull().defaultNow(),
    decidedAt: timestamp("decided_at", { withTimezone: true }),
  },
  (t) => [index("approvals_status").on(t.status)],
);

export const llmCache = pgTable("llm_cache", {
  key: text("key").primaryKey(),
  response: text("response").notNull(),
  model: text("model").notNull(),
  tokensIn: integer("tokens_in").notNull().default(0),
  tokensOut: integer("tokens_out").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const usageLedger = pgTable("usage_ledger", {
  id: bigserial("id", { mode: "number" }).primaryKey(),
  workUnitId: uuid("work_unit_id"),
  agentId: uuid("agent_id"),
  kind: text("kind").notNull(),
  model: text("model").notNull(),
  tokensIn: integer("tokens_in").notNull().default(0),
  tokensOut: integer("tokens_out").notNull().default(0),
  costMicro: big("cost_micro").notNull().default(0),
  cached: boolean("cached").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const benchmarks = pgTable("benchmarks", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  params: jsonb("params").$type<Record<string, unknown>>().notNull().default({}),
  status: text("status").notNull().default("running"),
  results: jsonb("results").$type<Record<string, unknown>>(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  finishedAt: timestamp("finished_at", { withTimezone: true }),
});

export const qualificationRuns = pgTable("qualification_runs", {
  id: uuid("id").primaryKey().defaultRandom(),
  results: jsonb("results").$type<unknown[]>().notNull(),
  passed: integer("passed").notNull().default(0),
  failed: integer("failed").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Cedar-style forbid rules evaluated deterministically at the tool gateway. */
export const policies = pgTable("policies", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: uuid("org_id").notNull(),
  effect: text("effect").notNull().default("forbid"),
  action: text("action").notNull(),
  resourcePattern: text("resource_pattern").notNull(),
  description: text("description").notNull().default(""),
  enabled: boolean("enabled").notNull().default(true),
});

/** Delivery tracker: every requirement of the approved roadmap mapped to evidence. */
export const requirements = pgTable("requirements", {
  id: text("id").primaryKey(),
  phase: integer("phase").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  status: text("status").notNull().default("delivered"),
  evidence: text("evidence").notNull().default(""),
  checkId: text("check_id"),
  blocker: text("blocker"),
});
