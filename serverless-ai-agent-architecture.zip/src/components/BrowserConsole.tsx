"use client";

import { useState, useTransition } from "react";
import { ghostBtn, primaryBtn } from "./Controls";

type View = {
  id: string;
  processId: string;
  tab: { title: string; url: string; status: number; textPreview: string; links: { i: number; text: string; href: string }[]; forms: { i: number; action: string; method: string; fields: { name: string; type: string; value: string }[] }[]; injection: string[] } | null;
  tabs: { i: number; url: string; title: string }[];
  activeTab: number;
  cookieHosts: { host: string; names: string[] }[];
};

export function BrowserConsole({ token, initial }: { token: string; initial: View }) {
  const [view, setView] = useState<View>(initial);
  const [url, setUrl] = useState("");
  const [err, setErr] = useState("");
  const [pending, start] = useTransition();
  const [vals, setVals] = useState<Record<string, string>>({});

  const act = (action: Record<string, unknown>) =>
    start(async () => {
      setErr("");
      const r = await fetch("/api/browser", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ token, action }) });
      const j = await r.json();
      if (!r.ok) return setErr(j.error ?? "failed");
      setView(j.view);
    });

  const tab = view.tab;
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div className="rounded-xl border border-white/10 bg-white/[0.03]">
        <div className="flex flex-wrap items-center gap-2 border-b border-white/10 p-3">
          {view.tabs.map((t) => (
            <button key={t.i} onClick={() => act({ do: "switch", tab: t.i })} className={`max-w-[180px] truncate rounded-md px-2 py-1 text-xs ${t.i === view.activeTab ? "bg-emerald-500/20 text-emerald-200" : "bg-white/5 text-slate-300"}`}>{t.title || t.url}</button>
          ))}
          <button onClick={() => act({ do: "newtab" })} className="rounded-md bg-white/5 px-2 py-1 text-xs text-slate-300">＋</button>
        </div>
        <form className="flex gap-2 border-b border-white/10 p-3" onSubmit={(e) => { e.preventDefault(); if (url) act({ do: "goto", url: url.startsWith("/") ? location.origin + url : url }); }}>
          <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder={tab?.url ?? "https://…"} className="min-w-0 flex-1 rounded-lg border border-white/10 bg-black/30 px-3 py-1.5 text-sm text-white outline-none" />
          <button className={primaryBtn} disabled={pending}>Go</button>
        </form>
        <div className="space-y-4 p-4">
          {err && <p className="text-sm text-rose-300">{err}</p>}
          {!tab ? <p className="text-sm text-slate-400">Empty browser. Enter a URL.</p> : (
            <>
              <div>
                <div className="text-xs text-slate-500">{tab.url} · HTTP {tab.status}</div>
                <h3 className="text-lg font-semibold text-white">{tab.title}</h3>
              </div>
              {tab.injection.length > 0 && <p className="rounded-lg bg-amber-500/10 p-2 text-xs text-amber-300">Page contains instruction-like text. Agents treat it as data only.</p>}
              <pre className="max-h-48 overflow-auto whitespace-pre-wrap rounded-lg bg-black/30 p-3 text-xs text-slate-300">{tab.textPreview}</pre>
              {tab.forms.map((f) => (
                <form key={f.i} className="space-y-2 rounded-lg border border-white/10 p-3" onSubmit={async (e) => {
                  e.preventDefault();
                  for (const fld of f.fields) { const v = vals[`${f.i}.${fld.name}`]; if (v !== undefined) await new Promise<void>((res) => { act({ do: "type", form: f.i, field: fld.name, value: v }); setTimeout(res, 150); }); }
                  act({ do: "submit", form: f.i });
                }}>
                  <div className="text-xs text-slate-400">Form #{f.i} → {f.method} {f.action}</div>
                  {f.fields.map((fld) => (
                    <input key={fld.name} type={fld.type === "password" ? "password" : "text"} placeholder={fld.name} value={vals[`${f.i}.${fld.name}`] ?? fld.value ?? ""} onChange={(e) => setVals({ ...vals, [`${f.i}.${fld.name}`]: e.target.value })} className="w-full rounded-lg border border-white/10 bg-black/30 px-3 py-1.5 text-sm text-white" />
                  ))}
                  <button className={primaryBtn} disabled={pending}>Submit</button>
                </form>
              ))}
              {tab.links.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {tab.links.slice(0, 12).map((l) => <button key={l.i} onClick={() => act({ do: "click", link: l.i })} className={ghostBtn}>{l.text || l.href}</button>)}
                </div>
              )}
            </>
          )}
        </div>
      </div>
      <div className="space-y-3 text-sm">
        <div className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
          <div className="text-xs uppercase tracking-wider text-slate-400">Browser identity</div>
          <div className="mt-1 text-slate-200">context {view.id.slice(0, 8)}</div>
          <div className="text-xs text-slate-500">pooled on process {view.processId}</div>
        </div>
        <div className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
          <div className="text-xs uppercase tracking-wider text-slate-400">Session cookies (names only)</div>
          {view.cookieHosts.length === 0 && <p className="mt-1 text-xs text-slate-500">none</p>}
          {view.cookieHosts.map((c) => <div key={c.host} className="mt-1 text-xs text-slate-300">{c.host}: {c.names.join(", ")}</div>)}
        </div>
        <p className="text-[11px] leading-relaxed text-amber-300/80">This link is a bearer credential: anyone holding it controls this logged-in browser. It expires in 15 minutes and is revoked the moment the agent task resumes.</p>
      </div>
    </div>
  );
}
