import type { ReactNode } from "react";

const CHIP: Record<string, string> = {
  succeeded: "bg-emerald-500/15 text-emerald-300 ring-emerald-500/30",
  completed: "bg-emerald-500/15 text-emerald-300 ring-emerald-500/30",
  delivered: "bg-emerald-500/15 text-emerald-300 ring-emerald-500/30",
  curated: "bg-emerald-500/15 text-emerald-300 ring-emerald-500/30",
  active: "bg-emerald-500/15 text-emerald-300 ring-emerald-500/30",
  allow: "bg-emerald-500/15 text-emerald-300 ring-emerald-500/30",
  approved: "bg-emerald-500/15 text-emerald-300 ring-emerald-500/30",
  running: "bg-sky-500/15 text-sky-300 ring-sky-500/30 animate-pulse",
  ready: "bg-amber-500/15 text-amber-300 ring-amber-500/30",
  candidate: "bg-amber-500/15 text-amber-300 ring-amber-500/30",
  partial: "bg-amber-500/15 text-amber-300 ring-amber-500/30",
  adapter: "bg-sky-500/15 text-sky-300 ring-sky-500/30",
  pending: "bg-slate-500/15 text-slate-300 ring-slate-500/30",
  hibernated: "bg-indigo-500/15 text-indigo-300 ring-indigo-500/30",
  draft: "bg-slate-500/15 text-slate-300 ring-slate-500/30",
  failed: "bg-rose-500/15 text-rose-300 ring-rose-500/30",
  deny: "bg-rose-500/15 text-rose-300 ring-rose-500/30",
  denied: "bg-rose-500/15 text-rose-300 ring-rose-500/30",
  contested: "bg-rose-500/15 text-rose-300 ring-rose-500/30",
  cancelled: "bg-zinc-500/15 text-zinc-400 ring-zinc-500/30",
  external: "bg-zinc-500/15 text-zinc-300 ring-zinc-500/30",
  awaiting_approval: "bg-violet-500/15 text-violet-300 ring-violet-500/30",
};

export function Chip({ s, children }: { s: string; children?: ReactNode }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ring-inset ${CHIP[s] ?? CHIP.pending}`}>
      {children ?? s.replace("_", " ")}
    </span>
  );
}

export function Card({ title, right, children, className = "" }: { title?: ReactNode; right?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`rounded-xl border border-white/10 bg-white/[0.03] ${className}`}>
      {title && (
        <header className="flex items-center justify-between gap-3 border-b border-white/10 px-4 py-3">
          <h2 className="text-sm font-semibold tracking-tight text-slate-100">{title}</h2>
          {right}
        </header>
      )}
      <div className="p-4">{children}</div>
    </section>
  );
}

export function Stat({ label, value, sub }: { label: string; value: ReactNode; sub?: ReactNode }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
      <div className="text-[11px] uppercase tracking-wider text-slate-400">{label}</div>
      <div className="mt-1 text-2xl font-semibold text-white">{value}</div>
      {sub && <div className="mt-1 text-xs text-slate-400">{sub}</div>}
    </div>
  );
}

export function PageHeader({ title, sub, right }: { title: string; sub?: ReactNode; right?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-white">{title}</h1>
        {sub && <p className="mt-1 max-w-3xl text-sm text-slate-400">{sub}</p>}
      </div>
      {right}
    </div>
  );
}

export const ago = (d: string | Date | null) => {
  if (!d) return "-";
  const s = Math.max(0, (Date.now() - new Date(d).getTime()) / 1000);
  if (s < 60) return `${Math.floor(s)}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
};

export const micro = (n: number) => `$${(Number(n) / 1e6).toFixed(4)}`;

function inline(text: string): ReactNode[] {
  return text.split(/(\*\*[^*]+\*\*|\[S\d+\]|`[^`]+`)/g).map((p, i) => {
    if (p.startsWith("**")) return <strong key={i} className="text-white">{p.slice(2, -2)}</strong>;
    if (/^\[S\d+\]$/.test(p)) return <span key={i} className="mx-0.5 rounded bg-sky-500/15 px-1 text-[11px] font-medium text-sky-300">{p.slice(1, -1)}</span>;
    if (p.startsWith("`")) return <code key={i} className="rounded bg-white/10 px-1 text-[12px]">{p.slice(1, -1)}</code>;
    return p;
  });
}

/** Tiny markdown renderer for deliverables (headings, bullets, tables, quotes). */
export function Markdown({ text }: { text: string }) {
  const lines = text.split("\n");
  const out: ReactNode[] = [];
  let i = 0;
  while (i < lines.length) {
    const l = lines[i];
    if (!l.trim()) { i++; continue; }
    if (l.startsWith("# ")) out.push(<h1 key={i} className="mt-2 text-xl font-semibold text-white">{inline(l.slice(2))}</h1>);
    else if (l.startsWith("## ")) out.push(<h2 key={i} className="mt-5 border-b border-white/10 pb-1 text-sm font-semibold uppercase tracking-wider text-emerald-300">{l.slice(3)}</h2>);
    else if (l.startsWith("### ")) out.push(<h3 key={i} className="mt-3 font-semibold text-slate-100">{l.slice(4)}</h3>);
    else if (l.startsWith("|")) {
      const rows: string[][] = [];
      while (i < lines.length && lines[i].startsWith("|")) {
        if (!/^\|[-| ]+\|$/.test(lines[i])) rows.push(lines[i].split("|").slice(1, -1).map((c) => c.trim()));
        i++;
      }
      out.push(
        <table key={`t${i}`} className="my-2 w-full text-left text-sm">
          <thead><tr>{rows[0].map((c, k) => <th key={k} className="border-b border-white/10 px-2 py-1 text-xs uppercase text-slate-400">{c}</th>)}</tr></thead>
          <tbody>{rows.slice(1).map((r, a) => <tr key={a} className="border-b border-white/5">{r.map((c, k) => <td key={k} className="px-2 py-1 text-slate-200">{inline(c)}</td>)}</tr>)}</tbody>
        </table>,
      );
      continue;
    } else if (/^\s*[-*]\s+/.test(l)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) { items.push(lines[i].replace(/^\s*[-*]\s+/, "")); i++; }
      out.push(<ul key={`u${i}`} className="my-1 list-disc space-y-1 pl-5 text-sm text-slate-200">{items.map((t, k) => <li key={k}>{inline(t)}</li>)}</ul>);
      continue;
    } else if (l.startsWith("> ")) out.push(<blockquote key={i} className="my-2 border-l-2 border-amber-400/60 pl-3 text-sm text-amber-200/90">{inline(l.slice(2))}</blockquote>);
    else out.push(<p key={i} className="my-1 text-sm text-slate-300">{inline(l.replace(/^_|_$/g, ""))}</p>);
    i++;
  }
  return <div>{out}</div>;
}
