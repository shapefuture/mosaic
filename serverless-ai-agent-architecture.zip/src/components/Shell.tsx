import Link from "next/link";
import type { ReactNode } from "react";
import { pool } from "@/db";
import { ensureSeed } from "@/lib/engine/seed";
import { ensureLiveness, schedulerStatus } from "@/lib/engine/scheduler";
import { gatewayConfig } from "@/lib/gateway/model";
import { AutoRefresh } from "./Controls";

const NAV = [
  ["/", "Command", "◎"],
  ["/agents", "Agents & sessions", "◉"],
  ["/browser", "Browser", "▣"],
  ["/governance", "Governance", "⛨"],
  ["/memory", "Memory & skills", "❖"],
  ["/capacity", "Capacity", "▤"],
  ["/delivery", "Delivery tracker", "✓"],
] as const;

export async function Shell({ children, path }: { children: ReactNode; path: string }) {
  await ensureSeed();
  await ensureLiveness();
  const s = (await pool.query(
    `SELECT (SELECT count(*)::int FROM tasks WHERE status IN ('running','ready','pending') AND work_unit_id IN (SELECT id FROM work_units WHERE status='running')) AS active,
            (SELECT count(*)::int FROM approvals WHERE status='pending') AS approvals`,
  )).rows[0] as { active: number; approvals: number };
  const sch = schedulerStatus();
  const gw = gatewayConfig();
  return (
    <div className="flex min-h-screen bg-[#070b14] text-slate-200">
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r border-white/10 bg-[#0a1020] p-4 md:flex">
        <Link href="/" className="mb-6 block">
          <div className="text-lg font-bold tracking-tight text-white">AOS <span className="text-emerald-400">v3</span></div>
          <div className="text-[11px] leading-tight text-slate-400">Hibernating, massively parallel agent OS</div>
        </Link>
        <nav className="space-y-1">
          {NAV.map(([href, label, icon]) => (
            <Link key={href} href={href} className={`flex items-center justify-between rounded-lg px-3 py-2 text-sm transition ${path === href ? "bg-emerald-500/15 text-emerald-300" : "text-slate-300 hover:bg-white/5"}`}>
              <span className="flex items-center gap-2"><span className="w-4 text-center opacity-70">{icon}</span>{label}</span>
              {href === "/governance" && s.approvals > 0 && <span className="rounded-full bg-violet-500 px-1.5 text-[10px] font-semibold text-white">{s.approvals}</span>}
            </Link>
          ))}
        </nav>
        <div className="mt-auto space-y-2 rounded-lg border border-white/10 bg-white/[0.03] p-3 text-[11px] text-slate-400">
          <div className="flex items-center justify-between"><span>Scheduler loop</span><span className={sch.draining ? "text-sky-300" : "text-slate-500"}>{sch.draining ? "draining" : "asleep"}</span></div>
          <div className="flex items-center justify-between"><span>Active tasks</span><span className="text-slate-200">{s.active}</span></div>
          <div className="flex items-center justify-between"><span>Model gateway</span><span className={gw.configured ? "text-emerald-300" : "text-amber-300"}>{gw.configured ? "live" : "local fallback"}</span></div>
        </div>
      </aside>
      <main className="min-w-0 flex-1 p-4 md:p-8">
        <nav className="mb-4 flex gap-2 overflow-x-auto md:hidden">
          {NAV.map(([href, label]) => (
            <Link key={href} href={href} className={`whitespace-nowrap rounded-full px-3 py-1 text-xs ${path === href ? "bg-emerald-500/20 text-emerald-300" : "bg-white/5 text-slate-300"}`}>{label}</Link>
          ))}
        </nav>
        <AutoRefresh active={s.active > 0 || s.approvals > 0} />
        {children}
      </main>
    </div>
  );
}
