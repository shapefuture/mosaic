"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState, useTransition } from "react";

export function AutoRefresh({ active, ms = 1500 }: { active: boolean; ms?: number }) {
  const router = useRouter();
  useEffect(() => {
    if (!active) return;
    const t = setInterval(async () => {
      await fetch("/api/scheduler").catch(() => {});
      router.refresh();
    }, ms);
    return () => clearInterval(t);
  }, [active, ms, router]);
  return null;
}

const btn = "rounded-lg px-3 py-1.5 text-sm font-medium transition disabled:opacity-50";
export const primaryBtn = `${btn} bg-emerald-500 text-slate-950 hover:bg-emerald-400`;
export const ghostBtn = `${btn} border border-white/15 text-slate-200 hover:bg-white/10`;

async function post(url: string, body?: unknown) {
  const r = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body ?? {}) });
  return { ok: r.ok, data: await r.json().catch(() => ({})) };
}

const SAMPLES: Record<string, { objective: string; template: string; urls?: string }> = {
  research: {
    template: "research",
    objective: "Compare Acme, Globex and Initech pricing for the Pro tier and flag contradictions",
    urls: "/api/demo/pages/acme-pricing\n/api/demo/pages/acme-features\n/api/demo/pages/globex-pricing\n/api/demo/pages/initech-pricing\n/api/demo/pages/injection",
  },
  crm: { template: "browser-crm", objective: "Log in to the CRM, pass the MFA gate with a human, export the pipeline and report on it" },
  breakthrough: { template: "breakthrough", objective: "Our onboarding backlog keeps coming back every quarter and nobody can agree on the cause" },
  topic: { template: "research", objective: "Research the history and pricing models of serverless computing" },
};

export function CreateWorkForm() {
  const router = useRouter();
  const [objective, setObjective] = useState(SAMPLES.research.objective);
  const [template, setTemplate] = useState("research");
  const [urls, setUrls] = useState(SAMPLES.research.urls ?? "");
  const [code, setCode] = useState("return { total: data.values.reduce((a, b) => a + b, 0) };");
  const [data, setData] = useState('{"values":[1,2,3,4]}');
  const [err, setErr] = useState("");
  const [pending, start] = useTransition();

  const load = (k: string) => {
    const s = SAMPLES[k];
    setObjective(s.objective);
    setTemplate(s.template);
    setUrls(s.urls ?? "");
  };
  const submit = () =>
    start(async () => {
      setErr("");
      const r = await post("/api/work", { objective, template, urls: template === "research" ? urls : undefined, code: template === "compute" ? code : undefined, data: template === "compute" ? data : undefined });
      if (!r.ok) return setErr(r.data.error ?? "failed");
      router.push(`/work/${r.data.id}`);
    });

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2 text-xs">
        <span className="text-slate-400">Try:</span>
        {[["research", "Research (demo sources + injection)"], ["crm", "Browser + human MFA"], ["breakthrough", "Breakthrough"], ["topic", "Open-web topic"]].map(([k, l]) => (
          <button key={k} onClick={() => load(k)} className="rounded-full border border-white/15 px-2.5 py-1 text-slate-300 hover:bg-white/10">{l}</button>
        ))}
      </div>
      <textarea value={objective} onChange={(e) => setObjective(e.target.value)} rows={2} className="w-full rounded-lg border border-white/10 bg-black/30 p-3 text-sm text-white outline-none focus:border-emerald-500/60" placeholder="Describe the outcome you want" />
      <div className="flex flex-wrap items-center gap-3">
        <label className="text-xs text-slate-400">Template</label>
        <select value={template} onChange={(e) => setTemplate(e.target.value)} className="rounded-lg border border-white/10 bg-black/40 px-2 py-1.5 text-sm text-white">
          <option value="research">Research (map/reduce)</option>
          <option value="browser-crm">Browser CRM export</option>
          <option value="breakthrough">Breakthrough engine</option>
          <option value="compute">Tier-1 compute</option>
        </select>
        <button onClick={submit} disabled={pending} className={primaryBtn}>{pending ? "Planning…" : "Create Work Unit"}</button>
      </div>
      {template === "research" && <textarea value={urls} onChange={(e) => setUrls(e.target.value)} rows={4} className="w-full rounded-lg border border-white/10 bg-black/30 p-3 font-mono text-xs text-slate-200 outline-none" placeholder="Optional source URLs (one per line). Leave empty to discover sources automatically." />}
      {template === "compute" && (
        <div className="grid gap-2 md:grid-cols-2">
          <textarea value={code} onChange={(e) => setCode(e.target.value)} rows={3} className="rounded-lg border border-white/10 bg-black/30 p-3 font-mono text-xs text-slate-200" />
          <textarea value={data} onChange={(e) => setData(e.target.value)} rows={3} className="rounded-lg border border-white/10 bg-black/30 p-3 font-mono text-xs text-slate-200" />
        </div>
      )}
      {err && <p className="text-sm text-rose-300">{err}</p>}
    </div>
  );
}

export function ApprovalButtons({ id, resume }: { id: string; resume?: boolean }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const act = (approve: boolean) => start(async () => { await post(`/api/approvals/${id}`, { approve }); router.refresh(); });
  return (
    <div className="flex gap-2">
      <button disabled={pending} onClick={() => act(true)} className={primaryBtn}>{resume ? "Resume task" : "Approve"}</button>
      <button disabled={pending} onClick={() => act(false)} className={ghostBtn}>{resume ? "Abort" : "Deny"}</button>
    </div>
  );
}

export function CancelButton({ id }: { id: string }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  return <button disabled={pending} onClick={() => start(async () => { await post(`/api/work/${id}/cancel`); router.refresh(); })} className={ghostBtn}>Cancel</button>;
}

export function LiveLinkButton({ contextId, label = "Open Live View" }: { contextId: string; label?: string }) {
  const [pending, start] = useTransition();
  return (
    <button disabled={pending} className={ghostBtn} onClick={() => start(async () => {
      const r = await post("/api/browser", { contextId, mint: true });
      if (r.ok) window.open(r.data.url, "_blank");
    })}>{label}</button>
  );
}

export function SessionChat({ sessionId, transcript }: { sessionId: string; transcript: { role: string; content: string }[] }) {
  const router = useRouter();
  const [text, setText] = useState("");
  const [meta, setMeta] = useState("");
  const [pending, start] = useTransition();
  const send = () => {
    if (!text.trim()) return;
    const t = text;
    setText("");
    start(async () => {
      const r = await post(`/api/sessions/${sessionId}/message`, { text: t });
      if (r.ok) setMeta(`woke → turn → hibernated in ${r.data.ms} ms (Δ RSS ${r.data.rssDeltaKb} KB)`);
      router.refresh();
    });
  };
  return (
    <div>
      <div className="mb-3 max-h-80 space-y-2 overflow-y-auto rounded-lg bg-black/30 p-3">
        {transcript.length === 0 && <p className="text-sm text-slate-500">No messages. This session is hibernated and costs only storage.</p>}
        {transcript.map((m, i) => (
          <div key={i} className={`max-w-[90%] whitespace-pre-wrap rounded-lg px-3 py-2 text-sm ${m.role === "user" ? "ml-auto bg-emerald-500/15 text-emerald-100" : "bg-white/5 text-slate-200"}`}>{m.content}</div>
        ))}
      </div>
      <div className="flex gap-2">
        <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder='Try: research https://… · "log in to the CRM" · /breakthrough … · /remember … · /recall …' className="min-w-0 flex-1 rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm text-white outline-none focus:border-emerald-500/60" />
        <button onClick={send} disabled={pending} className={primaryBtn}>{pending ? "…" : "Send"}</button>
      </div>
      {meta && <p className="mt-2 text-[11px] text-slate-500">{meta}</p>}
    </div>
  );
}

export function RunQualify() {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [err, setErr] = useState("");
  return (
    <div className="flex items-center gap-3">
      <button disabled={pending} className={primaryBtn} onClick={() => start(async () => {
        setErr("");
        const r = await post("/api/qualify");
        if (!r.ok) setErr("run failed");
        router.refresh();
      })}>{pending ? "Running 17 live checks… (~20s)" : "Run acceptance & red-team suite"}</button>
      {err && <span className="text-sm text-rose-300">{err}</span>}
    </div>
  );
}

export function RunBench({ running }: { running: boolean }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [p, setP] = useState({ sessions: 2048, ioTasks: 500, fanout: 200 });
  useEffect(() => {
    if (!running) return;
    const t = setInterval(() => router.refresh(), 1200);
    return () => clearInterval(t);
  }, [running, router]);
  const field = (k: keyof typeof p, label: string) => (
    <label className="text-xs text-slate-400">{label}
      <input type="number" value={p[k]} onChange={(e) => setP({ ...p, [k]: Number(e.target.value) })} className="ml-2 w-24 rounded border border-white/10 bg-black/40 px-2 py-1 text-white" />
    </label>
  );
  return (
    <div className="flex flex-wrap items-center gap-4">
      {field("sessions", "Idle sessions")}{field("ioTasks", "Parallel I/O tasks")}{field("fanout", "Fan-out reads")}
      <button disabled={pending || running} className={primaryBtn} onClick={() => start(async () => { await post("/api/bench", p); router.refresh(); })}>{running ? "Benchmark running…" : "Run capacity benchmark"}</button>
    </div>
  );
}
