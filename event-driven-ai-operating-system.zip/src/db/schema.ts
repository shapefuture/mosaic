import {
  pgTable,
  uuid,
  text,
  timestamp,
  integer,
  boolean,
  jsonb,
  real,
  bigint,
} from "drizzle-orm/pg-core";

export const agents = pgTable("aos_agents", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  systemProfileVersion: text("system_profile_version").notNull().default("v12"),
  capabilities: jsonb("capabilities").notNull().default([]),
  modelPolicy: jsonb("model_policy").notNull().default({}),
  memoryScope: text("memory_scope").notNull().default("org"),
  authorityPolicy: jsonb("authority_policy").notNull().default({}),
  skills: jsonb("skills").notNull().default([]),
  budget: real("budget").notNull().default(10),
  spend: real("spend").notNull().default(0),
  status: text("status").notNull().default("hibernating"),
  lastWakeAt: timestamp("last_wake_at"),
  wakeCount: integer("wake_count").notNull().default(0),
  activeMemoryKb: integer("active_memory_kb").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sessions = pgTable("aos_sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  agentId: uuid("agent_id").references(() => agents.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  state: text("state").notNull().default("hibernating"),
  transcript: jsonb("transcript").notNull().default([]),
  inbox: jsonb("inbox").notNull().default([]),
  pendingTools: jsonb("pending_tools").notNull().default([]),
  schedulingMeta: jsonb("scheduling_meta").notNull().default({}),
  sqliteSnapshot: text("sqlite_snapshot").notNull().default("{}"),
  wakeCount: integer("wake_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const workUnits = pgTable("aos_work_units", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: text("title").notNull(),
  objective: text("objective").notNull(),
  qualityBar: text("quality_bar").notNull().default(""),
  status: text("status").notNull().default("planned"),
  acceptanceCriteria: jsonb("acceptance_criteria").notNull().default([]),
  budget: real("budget").notNull().default(5),
  spend: real("spend").notNull().default(0),
  plannerModel: text("planner_model").notNull().default("reasoning-large"),
  missionRef: text("mission_ref"),
  gauntletRounds: integer("gauntlet_rounds").notNull().default(0),
  gauntletVerdict: text("gauntlet_verdict"),
  gauntletHistory: jsonb("gauntlet_history").notNull().default([]),
  planGraph: jsonb("plan_graph").notNull().default({}),
  verificationReport: jsonb("verification_report").notNull().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const tasks = pgTable("aos_tasks", {
  id: uuid("id").primaryKey().defaultRandom(),
  workUnitId: uuid("work_unit_id").references(() => workUnits.id, {
    onDelete: "cascade",
  }),
  agentId: uuid("agent_id").references(() => agents.id, { onDelete: "set null" }),
  sessionId: uuid("session_id").references(() => sessions.id, {
    onDelete: "set null",
  }),
  title: text("title").notNull(),
  kind: text("kind").notNull().default("research"),
  queue: text("queue").notNull().default("io"),
  status: text("status").notNull().default("queued"),
  tier: integer("tier").notNull().default(0),
  authorityToken: jsonb("authority_token").notNull().default({}),
  input: jsonb("input").notNull().default({}),
  output: jsonb("output"),
  evidence: jsonb("evidence").notNull().default({}),
  attempts: integer("attempts").notNull().default(0),
  maxRetries: integer("max_retries").notNull().default(2),
  dependsOn: jsonb("depends_on").notNull().default([]),
  cost: real("cost").notNull().default(0),
  durationMs: integer("duration_ms").notNull().default(0),
  idempotencyKey: text("idempotency_key").notNull().default(""),
  criticScore: integer("critic_score"),
  criticGap: text("critic_gap"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  startedAt: timestamp("started_at"),
  finishedAt: timestamp("finished_at"),
});

export const artifacts = pgTable("aos_artifacts", {
  id: uuid("id").primaryKey().defaultRandom(),
  workUnitId: uuid("work_unit_id").references(() => workUnits.id, {
    onDelete: "cascade",
  }),
  taskId: uuid("task_id").references(() => tasks.id, { onDelete: "set null" }),
  name: text("name").notNull(),
  kind: text("kind").notNull().default("report"),
  uri: text("uri").notNull().default(""),
  checksum: text("checksum").notNull().default(""),
  sizeBytes: integer("size_bytes").notNull().default(0),
  content: text("content").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const memories = pgTable("aos_memories", {
  id: uuid("id").primaryKey().defaultRandom(),
  agentId: uuid("agent_id").references(() => agents.id, { onDelete: "set null" }),
  scope: text("scope").notNull().default("org"),
  kind: text("kind").notNull().default("episodic"),
  content: text("content").notNull(),
  provenance: jsonb("provenance").notNull().default({}),
  trust: real("trust").notNull().default(0.5),
  promoted: boolean("promoted").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const skills = pgTable("aos_skills", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  version: text("version").notNull().default("v1"),
  description: text("description").notNull().default(""),
  codePackage: text("code_package").notNull().default(""),
  testReport: jsonb("test_report").notNull().default({}),
  status: text("status").notNull().default("candidate"),
  usageCount: integer("usage_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const approvals = pgTable("aos_approvals", {
  id: uuid("id").primaryKey().defaultRandom(),
  workUnitId: uuid("work_unit_id").references(() => workUnits.id, {
    onDelete: "cascade",
  }),
  taskId: uuid("task_id").references(() => tasks.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  requestedBy: text("requested_by").notNull().default("scheduler"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  decidedAt: timestamp("decided_at"),
});

export const receipts = pgTable("aos_receipts", {
  id: uuid("id").primaryKey().defaultRandom(),
  workUnitId: uuid("work_unit_id").references(() => workUnits.id, {
    onDelete: "cascade",
  }),
  taskId: uuid("task_id").references(() => tasks.id, { onDelete: "set null" }),
  agentId: uuid("agent_id").references(() => agents.id, { onDelete: "set null" }),
  action: text("action").notNull(),
  resource: text("resource").notNull().default(""),
  cost: real("cost").notNull().default(0),
  policyVersion: text("policy_version").notNull().default("v12"),
  tokenHash: text("token_hash").notNull().default(""),
  verdict: text("verdict").notNull().default("allow"),
  details: jsonb("details").notNull().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const browserSessions = pgTable("aos_browser_sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  agentId: uuid("agent_id").references(() => agents.id, { onDelete: "cascade" }),
  sessionId: uuid("session_id").references(() => sessions.id, {
    onDelete: "set null",
  }),
  status: text("status").notNull().default("hibernating"),
  tabs: jsonb("tabs").notNull().default([]),
  contextIsolated: boolean("context_isolated").notNull().default(true),
  liveViewUrl: text("live_view_url").notNull().default(""),
  liveViewExpires: timestamp("live_view_expires"),
  domainAllowlist: jsonb("domain_allowlist").notNull().default([]),
  memoryMb: integer("memory_mb").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastUsed: timestamp("last_used").notNull().defaultNow(),
});

export const connectors = pgTable("aos_connectors", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  provider: text("provider").notNull(),
  authType: text("auth_type").notNull().default("brokered"),
  supportedActions: jsonb("supported_actions").notNull().default([]),
  rateLimits: jsonb("rate_limits").notNull().default({}),
  approvalRequired: boolean("approval_required").notNull().default(false),
  health: text("health").notNull().default("healthy"),
  docs: text("docs").notNull().default(""),
});

export const missions = pgTable("aos_missions", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  scope: jsonb("scope").notNull().default({}),
  authorization: jsonb("authorization").notNull().default({}),
  requirementMap: jsonb("requirement_map").notNull().default([]),
  checks: jsonb("checks").notNull().default([]),
  handoff: jsonb("handoff").notNull().default({}),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const schedulerRuns = pgTable("aos_scheduler_runs", {
  id: bigint("id", { mode: "number" }).primaryKey().generatedAlwaysAsIdentity(),
  kind: text("kind").notNull(),
  payload: jsonb("payload").notNull().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
