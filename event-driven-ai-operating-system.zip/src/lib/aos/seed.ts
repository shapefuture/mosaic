import { db } from "@/db";
import { agents, connectors, skills, missions, memories, sessions, browserSessions } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function ensureSeed() {
  const existing = await db.select().from(agents).limit(1);
  if (existing.length > 0) {
    // backfill: every identity owns a hibernating session + browser identity (no process)
    const all = await db.select().from(agents);
    for (const a of all) {
      const ss = await db.select().from(sessions).where(eq(sessions.agentId, a.id)).limit(1);
      let sid: string | null = ss[0]?.id ?? null;
      if (!ss[0]) {
        const [s] = await db
          .insert(sessions)
          .values({ agentId: a.id, name: `${a.name}-main`, state: "hibernating", transcript: [], inbox: [] })
          .returning();
        sid = s.id;
      }
      const bs = await db.select().from(browserSessions).where(eq(browserSessions.agentId, a.id)).limit(1);
      if (!bs[0]) {
        await db.insert(browserSessions).values({
          agentId: a.id,
          sessionId: sid,
          status: "hibernating",
          tabs: [],
          domainAllowlist: ["approved.example"],
          memoryMb: 0,
        });
      }
    }
    return { seeded: false, backfilled: true };
  }
  const seedAgents = [
    {
      name: "planner-01",
      role: "Strategic Planner",
      capabilities: ["plan", "decompose", "route", "verify"],
      modelPolicy: { ladder: "reasoning-large for plans, small for rest", gateway: "ai-gateway" },
      skills: ["work-decomposition", "triz-separation"],
      budget: 25,
    },
    {
      name: "research-analyst-01",
      role: "Research Specialist",
      capabilities: ["http.get", "extract", "browser.read"],
      modelPolicy: { ladder: "fast per-source, strong synthesis", gateway: "ai-gateway" },
      skills: ["pricing-extraction", "evidence-store"],
      budget: 15,
    },
    {
      name: "browser-operator-01",
      role: "Browser Operator",
      capabilities: ["browser.read", "browser.act", "screenshot"],
      modelPolicy: { ladder: "playwright first, stagehand fallback", gateway: "ai-gateway" },
      skills: ["playwright-default", "stagehand-fallback", "midscene-visual"],
      budget: 12,
    },
    {
      name: "code-sandbox-01",
      role: "Coding Specialist",
      capabilities: ["code.exec", "transform", "test"],
      modelPolicy: { ladder: "coding-specialist", gateway: "ai-gateway" },
      skills: ["cow-snapshot", "deterministic-tests"],
      budget: 12,
    },
    {
      name: "verifier-01",
      role: "Independent Verifier",
      capabilities: ["verify", "critic", "blind-compare"],
      modelPolicy: { ladder: "independent evaluator + deterministic checks", gateway: "ai-gateway" },
      skills: ["gauntlet-critic", "acceptance-gates"],
      budget: 10,
    },
    {
      name: "memory-compiler-01",
      role: "Memory Compiler",
      capabilities: ["compile", "dedupe", "promote"],
      modelPolicy: { ladder: "background batch, no critical path", gateway: "ai-gateway" },
      skills: ["fact-extract", "skill-forge"],
      budget: 8,
    },
  ];
  for (const a of seedAgents) {
    await db.insert(agents).values({
      name: a.name,
      role: a.role,
      capabilities: a.capabilities,
      modelPolicy: a.modelPolicy,
      skills: a.skills,
      budget: a.budget,
      status: "hibernating",
    });
  }
  const seedConnectors = [
    { name: "stripe-pricing", provider: "stripe", supportedActions: ["http.get", "extract"], approvalRequired: false, docs: "Typed adapter; no browser needed." },
    { name: "web-fetch", provider: "http", supportedActions: ["http.get"], approvalRequired: false, docs: "Tier 0 lightweight fetch pool." },
    { name: "chromium-pool", provider: "browser-run", supportedActions: ["browser.read", "browser.act", "screenshot"], approvalRequired: false, docs: "Pooled Chromium, isolated contexts." },
    { name: "code-lite", provider: "containers", supportedActions: ["code.exec"], approvalRequired: false, docs: "256MiB lite, scale-to-zero." },
    { name: "payments-prod", provider: "stripe", supportedActions: ["payment.charge"], approvalRequired: true, docs: "High-impact; human approval gate." },
  ];
  for (const c of seedConnectors) {
    await db.insert(connectors).values({
      name: c.name,
      provider: c.provider,
      supportedActions: c.supportedActions,
      approvalRequired: c.approvalRequired,
      docs: c.docs,
      health: "healthy",
      rateLimits: { perMin: 120 },
    });
  }
  const seedSkills = [
    { name: "pricing-extraction", description: "Batch schema-validated pricing extraction; deterministic parser first.", codePackage: "extract(price, features) -> validated rows", status: "stable" },
    { name: "gauntlet-critic", description: "Harsh blind critic: A/B vs bar, binary pick, biggest gap.", codePackage: "critic(candidate, bar) -> {pick, gap}", status: "stable" },
    { name: "cow-snapshot", description: "Copy-on-write snapshot fork for parallel code branches.", codePackage: "fork(snapshot) -> branch", status: "stable" },
    { name: "triz-separation", description: "Contradiction -> separation principle -> invention mapping.", codePackage: "triz(problem, worsens)", status: "candidate" },
  ];
  for (const s of seedSkills) {
    await db.insert(skills).values({
      name: s.name,
      description: s.description,
      codePackage: s.codePackage,
      status: s.status,
      version: "v1",
      testReport: { tests: "4 passed" },
    });
  }
  await db.insert(missions).values({
    name: "AOS v3 bootstrap mission",
    scope: { objective: "Prove hibernating sessions + bounded DAG execution before adding integrations", roots: ["sessions", "work-engine", "scheduler", "verification"] },
    authorization: { coordinator: "human-operator", billing: "capped", external_contact: "approval-gated" },
    requirementMap: [
      { req: "2048 idle sessions cost ~0 active", task: "sessions" },
      { req: "100-1000 subtask fan-out bounded", task: "work-engine" },
      { req: "Blind gauntlet before commit", task: "verification" },
    ],
    checks: [[" Evidence required: receipts + artifacts + critic pick ", "no invented acceptance"]],
    handoff: { note: "No competing tracker; this mission is the single authority." },
    status: "active",
  });
  await db.insert(memories).values({
    scope: "org",
    kind: "semantic",
    content: "Tier 0 first: 80% of research completes with HTTP + deterministic parsers; browser only for JS/auth walls.",
    provenance: { from: "bootstrap", trust_path: "seed" },
    trust: 0.8,
    promoted: true,
  });
  return { seeded: true };
}
