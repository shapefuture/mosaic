import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "AOS v3 — Hibernating Parallel AI Operating System",
  description: "Millions of identities. Thousands of concurrent tasks. A tiny always-on footprint.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#070b14] text-slate-100 antialiased">{children}</body>
    </html>
  );
}
