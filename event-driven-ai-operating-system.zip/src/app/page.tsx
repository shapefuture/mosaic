"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

type Tab = "command" | "agents" | "work" | "browser" | "memory" | "govern" | "bench" | "arch";

const TABS: { k: Tab; label: string; hint: string }[] = [
  { k: "command", label: "Command Deck", hint: "footprint · queues · mission" },
  { k: "agents", label: "Agents", hint: "identities, not processes" },
  { k: "work", label: "Work Engine", hint: "DAG · fan-out · gauntlet" },
  { k: "browser", label: "Browser Fleet", hint: "pooled contexts + Live View" },
  { k: "memory", label: "Memory", hint: "compiler + skills" },
  { k: "govern", label: "Approvals & Audit", hint: "authority envelopes" },
  { k: "bench", label: "Benchmarks", hint: "qualification + TRIZ" },
  { k: "arch", label: "Architecture", hint: "stack + skill log" },
];

const STATUS_COLOR: Record<string, string> = {
  hibernating: "text-sky-300 border-sky-400/30 bg-sky-400/10",
  active: "text-lime-300 border-lime-400/30 bg-lime-400/10",
  alive: "text-lime-300 border-lime-400/30 bg-lime-400/10",
  queued: "text-slate-300 border-slate-400/30 bg-slate-400/10",
  running: "text-amber-300 border-amber-400/40 bg-amber-400/10",
  verifying: "text-cyan-300 border-cyan-400/40 bg-cyan-400/10",
  planned: "text-slate-300 border-slate-400/30 bg-slate-400/10",
  succeeded: "text-lime-300 border-lime-400/30 bg-lime-400/10",
  committed: "text-lime-200 border-lime-300/50 bg-lime-400/15",
  failed: "text-rose-300 border-rose-400/40 bg-rose-400/10",
  awaiting_approval: "text-orange-300 border-orange-400/40 bg-orange-400/10",
  pending: "text-orange-300 border-orange-400/40 bg-orange-400/10",
  approved: "text-lime-300 border-lime-400/30 bg-lime-400/10",
  rejected: "text-rose-300 border-rose-400/40 bg-rose-400/10",
  cancelled: "text-slate-400 border-slate-500/30 bg-slate-500/10",
};

function Chip({ s }: { s: string }) {
  const c = STATUS_COLOR[s] || STATUS_COLOR.queued;
  return <span className={`chip mono px-2 py-0.5 text-[11px] ${c}`}>{s}</span>;
}

async function api(path: string, init?: RequestInit) {
  const r = await fetch(path, { ...init, headers: { "content-type": "application/json", ...(init?.headers || {}) } });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((j as { error?: string }).error || `HTTP ${r.status}`);
  return j as never as Record<string, unknown>;
}

const WORK_TEMPLATES = [
  {
    name: "Market map",
    title: "Map the AI browser-agent market",
    objective: "Research the AI browser-agent market: identify competitors, gather primary pricing sources, extract feature lists, compare segments, locate announcements, flag contradictions.",
    bar: "A named analyst report (e.g. Gartner-style vendor map): blind A/B on coverage, rigor and provenance. Must cite primary pricing pages with effective dates.",
  },
  {
    name: "Pricing intel",
    title: "Competitor pricing extraction",
    objective: "Gather primary pricing sources for the top 6 competitors, extract structured pricing tiers, validate schema, and cross-check contradictory claims with browser verification.",
    bar: "Stripe's pricing page as reference bar: ours must match its density (tiers, dates, footnotes) and beat it blind on provenance.",
  },
  {
    name: "Login-gated op",
    title: "Authenticated CRM enrichment (login required)",
    objective: "Log in to the CRM, navigate to the enterprise segment, enrich 40 accounts, and export the CSV. Login and production export require human approval.",
    bar: "Prior approved CRM export: same schema, zero unapproved side effects, full receipt chain.",
  },
];

export default function AOSConsole() {
  const [tab, setTab] = useState<Tab>("command");
  const [sys, setSys] = useState<any>(null);
  const [agentsData, setAgentsData] = useState<any>(null);
  const [workList, setWorkList] = useState<any[]>([]);
  const [workDetail, setWorkDetail] = useState<any>(null);
  const [selectedWork, setSelectedWork] = useState<string>("");
  const [sessions, setSessions] = useState<any[]>([]);
  const [memData, setMemData] = useState<any>(null);
  const [gov, setGov] = useState<any>(null);
  const [brows, setBrows] = useState<any>(null);
  const [busy, setBusy] = useState<string>("");
  const [log, setLog] = useState<string[]>(["AOS v3 console boot: identity ≠ process. Workers are borrowed, never owned."]);
  const [execLog, setExecLog] = useState<any[]>([]);

  // forms
  const [agentName, setAgentName] = useState("research-analyst-02");
  const [agentRole, setAgentRole] = useState("Research Specialist");
  const [wuTitle, setWuTitle] = useState(WORK_TEMPLATES[0].title);
  const [wuObjective, setWuObjective] = useState(WORK_TEMPLATES[0].objective);
  const [wuBar, setWuBar] = useState(WORK_TEMPLATES[0].bar);
  const [chatAgent, setChatAgent] = useState("");
  const [chatText, setChatText] = useState("What browser capacity is warm right now?");
  const [chatReply, setChatReply] = useState("");
  const [browserUrl, setBrowserUrl] = useState("https://approved.example/pricing");
  const [memQuery, setMemQuery] = useState("");
  const [memAdd, setMemAdd] = useState("Playwright selectors for pricing tables beat screenshots 4:1 on cost.");
  const [trizP, setTrizP] = useState("More parallelism");
  const [trizW, setTrizW] = useState("limited memory");
  const [trizOut, setTrizOut] = useState<any>(null);
  const [bench, setBench] = useState<any>(null);
  const [sweepOut, setSweepOut] = useState<any>(null);
  const [takeover, setTakeover] = useState<any>(null);

  const push = useCallback((m: string) => setLog((l) => [`${new Date().toLocaleTimeString()} ${m}`, ...l].slice(0, 80)), []);

  const refreshSys = useCallback(async () => {
    const j: any = await api("/api/system");
    setSys(j);
  }, []);
  const refreshAgents = useCallback(async () => {
    const j: any = await api("/api/agents");
    setAgentsData(j);
    if (!chatAgent && j.agents?.[0]) setChatAgent(j.agents[0].id);
  }, [chatAgent]);
  const refreshWork = useCallback(async () => {
    const j: any = await api("/api/work");
    setWorkList(j.workUnits || []);
    if (!selectedWork && j.workUnits?.[0]) {
      setSelectedWork(j.workUnits[0].id);
    }
  }, [selectedWork]);
  const refreshDetail = useCallback(
    async (id?: string) => {
      const wid = id || selectedWork;
      if (!wid) return;
      const j: any = await api(`/api/work?id=${wid}`);
      setWorkDetail(j);
    },
    [selectedWork]
  );
  const refreshMem = useCallback(async (q?: string) => {
    const j: any = await api(`/api/memory${q ? `?q=${encodeURIComponent(q)}` : ""}`);
    setMemData(j);
  }, []);
  const refreshGov = useCallback(async () => {
    const j: any = await api("/api/governance");
    setGov(j);
  }, []);
  const refreshBrows = useCallback(async () => {
    const j: any = await api("/api/browser");
    setBrows(j);
  }, []);
  const refreshSessions = useCallback(async (agentId?: string) => {
    const j: any = await api(`/api/sessions${agentId ? `?agentId=${agentId}` : ""}`);
    setSessions(j.sessions || []);
  }, []);

  useEffect(() => {
    (async () => {
      try {
        await refreshSys();
        await refreshAgents();
        await refreshWork();
        await refreshMem();
        await refreshGov();
        await refreshBrows();
        await refreshSessions();
        push("Control plane synced: Postgres canonical, R2-sim artifacts, DO-SQLite snapshots.");
      } catch (e: any) {
        push(`sync error: ${e.message}`);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (selectedWork) refreshDetail(selectedWork);
  }, [selectedWork, refreshDetail]);

  const queues = sys?.queues;
  const stats = sys?.stats;

  const dagLevels = useMemo(() => {
    const ts: any[] = workDetail?.tasks || [];
    if (!ts.length) return [];
    const byId: Record<string, any> = Object.fromEntries(ts.map((t) => [t.id, t]));
    const depth = (t: any, seen: Set<string>): number => {
      if (seen.has(t.id)) return 0;
      seen.add(t.id);
      const deps: string[] = t.dependsOn || [];
      if (!deps.length) return 0;
      return 1 + Math.max(...deps.map((d) => (byId[d] ? depth(byId[d], seen) : 0)));
    };
    const m = new Map<number, any[]>();
    ts.forEach((t) => {
      const d = depth(t, new Set());
      if (!m.has(d)) m.set(d, []);
      m.get(d)!.push(t);
    });
    return [...m.entries()].sort((a, b) => a[0] - b[0]);
  }, [workDetail]);

  async function run(label: string, fn: () => Promise<void>) {
    setBusy(label);
    try {
      await fn();
    } catch (e: any) {
      push(`ERR ${label}: ${e.message}`);
    } finally {
      setBusy("");
    }
  }

  return (
    <div className="min-h-screen">
      {/* header */}
      <header className="border-b border-white/10 bg-[#0a0f1e]/90 sticky top-0 z-20 backdrop-blur">
        <div className="mx-auto max-w-7xl px-4 py-3 flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-amber-300 to-orange-600 font-black text-black">A</div>
            <div>
              <div className="font-extrabold tracking-tight text-lg leading-none">
                AOS <span className="text-amber-300">v3</span> <span className="text-slate-400 font-medium">· hibernating parallel AI OS</span>
              </div>
              <div className="mono text-[11px] text-slate-400 mt-1">
                Millions of identities · Thousands of concurrent tasks · Tiny always-on footprint
              </div>
            </div>
          </div>
          <div className="ml-auto flex flex-wrap items-center gap-2 mono text-[11px]">
            <span className="chip px-2.5 py-1 border-white/10 bg-white/5 text-slate-200">
              <span className="livedot inline-block h-1.5 w-1.5 rounded-full bg-lime-400 mr-1.5" />
              logical {stats?.agents ?? "—"} · active {stats?.activeAgents ?? "—"}
            </span>
            <span className="chip px-2.5 py-1 border-white/10 bg-white/5 text-slate-200">sessions {stats?.sessions ?? "—"} ({stats?.activeSessions ?? "—"} awake)</span>
            <span className="chip px-2.5 py-1 border-amber-400/30 bg-amber-400/10 text-amber-200">active mem {stats?.activeMemMb ?? 0} MiB</span>
            <span className="chip px-2.5 py-1 border-cyan-400/30 bg-cyan-400/10 text-cyan-200">queued {stats?.queued ?? 0}</span>
          </div>
        </div>
        <div className="mx-auto max-w-7xl px-4 pb-3 flex gap-2 overflow-x-auto scrollthin">
          {TABS.map((t) => (
            <button
              key={t.k}
              onClick={() => setTab(t.k)}
              className={`shrink-0 rounded-xl px-3.5 py-2 text-left border border-transparent hover:border-white/15 ${tab === t.k ? "tab-active" : "text-slate-300"}`}
            >
              <div className="text-[13px] font-bold leading-none">{t.label}</div>
              <div className="mono text-[10px] opacity-70 mt-1">{t.hint}</div>
            </button>
          ))}
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-5 space-y-4">
        {busy && (
          <div className="panel px-4 py-2.5 mono text-[12px] text-amber-200 flex items-center gap-2">
            <span className="livedot inline-block h-2 w-2 rounded-full bg-amber-400" /> {busy} — shared pool working; idle identities cost nothing…
          </div>
        )}

        {tab === "command" && (
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="panel p-5 lg:col-span-2 rise">
              <div className="text-[11px] mono uppercase tracking-[0.18em] text-amber-300/90">New Work Unit · Plan → Fan-out → Verify → Commit</div>
              <h2 className="mt-1 text-xl font-extrabold">File an outcome. The scheduler wakes only what it needs.</h2>
              <div className="mt-2 flex flex-wrap gap-2">
                {WORK_TEMPLATES.map((t) => (
                  <button
                    key={t.name}
                    onClick={() => {
                      setWuTitle(t.title);
                      setWuObjective(t.objective);
                      setWuBar(t.bar);
                    }}
                    className="btn-ghost rounded-lg px-2.5 py-1.5 text-[12px] text-slate-200"
                  >
                    {t.name}
                  </button>
                ))}
              </div>
              <label className="mono text-[11px] text-slate-400 mt-3 block">TITLE</label>
              <input value={wuTitle} onChange={(e) => setWuTitle(e.target.value)} className="mt-1 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[14px] outline-none focus:border-amber-400/60" />
              <label className="mono text-[11px] text-slate-400 mt-3 block">OBJECTIVE (planner gets ONE strong call)</label>
              <textarea value={wuObjective} onChange={(e) => setWuObjective(e.target.value)} rows={3} className="mt-1 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[13px] outline-none focus:border-amber-400/60" />
              <label className="mono text-[11px] text-slate-400 mt-3 block">QUALITY BAR — gauntlet-loop (named · fetchable · comparable)</label>
              <textarea value={wuBar} onChange={(e) => setWuBar(e.target.value)} rows={2} className="mt-1 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[13px] outline-none focus:border-amber-400/60" />
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  className="btn-amber rounded-xl px-4 py-2 text-[13px]"
                  onClick={() =>
                    run("filing work unit", async () => {
                      const j: any = await api("/api/work", { method: "POST", body: JSON.stringify({ action: "create", title: wuTitle, objective: wuObjective, qualityBar: wuBar }) });
                      push(`Work filed: ${j.workUnit.title} · bar pinned`);
                      await refreshWork();
                      setSelectedWork(j.workUnit.id);
                      setTab("work");
                    })
                  }
                >
                  File Work Unit
                </button>
                <button
                  className="btn-ghost rounded-xl px-4 py-2 text-[13px]"
                  onClick={() =>
                    run("seeding fleet", async () => {
                      await api("/api/system", { method: "POST", body: JSON.stringify({ action: "seed" }) });
                      await Promise.all([refreshSys(), refreshAgents(), refreshMem(), refreshBrows()]);
                      push("Seed ensured: 6 role agents, 5 connectors, 4 skills, mission, 1 memory.");
                    })
                  }
                >
                  Ensure seed
                </button>
              </div>
              <div className="mono text-[11px] text-slate-500 mt-3 leading-relaxed">
                full-plan-delivery: this mission is the single task authority. No competing boards. Evidence (receipts + artifacts + blind pick) is required — a written plan or green check alone never counts as delivery.
              </div>
            </div>

            <div className="space-y-4">
              <div className="panel p-5">
                <div className="mono text-[11px] uppercase tracking-[0.18em] text-cyan-300">Execution footprint</div>
                <div className="mt-2 grid grid-cols-2 gap-2 mono text-[12px]">
                  <div className="rounded-xl bg-black/30 border border-white/10 p-3"><div className="text-slate-400 text-[10px]">LOGICAL AGENTS</div><div className="text-xl font-black">{stats?.agents ?? "—"}</div></div>
                  <div className="rounded-xl bg-black/30 border border-white/10 p-3"><div className="text-slate-400 text-[10px]">ACTIVE WORKERS</div><div className="text-xl font-black text-amber-300">{stats?.activeAgents ?? 0}</div></div>
                  <div className="rounded-xl bg-black/30 border border-white/10 p-3"><div className="text-slate-400 text-[10px]">SESSIONS</div><div className="text-xl font-black">{stats?.sessions ?? "—"}</div><div className="text-[10px] text-slate-500">2,048 idle ≈ 0 workers</div></div>
                  <div className="rounded-xl bg-black/30 border border-white/10 p-3"><div className="text-slate-400 text-[10px]">BROWSERS</div><div className="text-xl font-black">{stats?.browsers ?? "—"}</div><div className="text-[10px] text-slate-500">pooled, contexts isolated</div></div>
                </div>
                <div className="mono text-[11px] text-slate-400 mt-3">Tiers: <span className="text-slate-200">T0 API/worker</span> · <span className="text-slate-200">T1 lite 256MiB</span> · <span className="text-slate-200">T2 microVM only when needed</span></div>
              </div>
              <div className="panel p-5">
                <div className="mono text-[11px] uppercase tracking-[0.18em] text-cyan-300">Queues · adaptive scheduler</div>
                <div className="mt-2 space-y-2">
                  {(["interactive", "io", "compute", "browser"] as const).map((q) => (
                    <div key={q} className="flex items-center gap-2 mono text-[12px]">
                      <span className="w-24 text-slate-300">{q}</span>
                      <div className="flex-1 h-2 rounded-full bg-white/5 overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-amber-400 to-cyan-400" style={{ width: `${Math.min(100, (queues?.depth?.[q] || 0) * 12 + 4)}%` }} />
                      </div>
                      <span className="text-slate-400 w-16 text-right">q{queues?.depth?.[q] ?? "—"} · ≤{queues?.caps?.[q] ?? "—"}</span>
                    </div>
                  ))}
                </div>
                <div className="mono text-[10px] text-slate-500 mt-2">C_allowed = min(provider, tenant, queue, sandbox, budget) · batches ≤ 6 (6-conn limit)</div>
              </div>
              <div className="panel p-5">
                <div className="mono text-[11px] uppercase tracking-[0.18em] text-lime-300">Live ops log</div>
                <div className="mt-2 max-h-44 overflow-auto scrollthin mono text-[11px] text-slate-300 space-y-1">
                  {log.map((l, i) => (
                    <div key={i} className="border-b border-white/5 pb-1">{l}</div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {tab === "agents" && (
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="panel p-5">
              <div className="mono text-[11px] uppercase tracking-[0.18em] text-amber-300">Register identity (storage, not a server)</div>
              <input value={agentName} onChange={(e) => setAgentName(e.target.value)} className="mt-2 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[13px]" placeholder="agent name" />
              <input value={agentRole} onChange={(e) => setAgentRole(e.target.value)} className="mt-2 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[13px]" placeholder="role" />
              <button
                className="btn-amber rounded-xl px-4 py-2 text-[13px] mt-3 w-full"
                onClick={() =>
                  run("registering agent", async () => {
                    await api("/api/agents", { method: "POST", body: JSON.stringify({ name: agentName, role: agentRole }) });
                    push(`Identity ${agentName} stored; 0 workers allocated.`);
                    await Promise.all([refreshAgents(), refreshSys(), refreshBrows()]);
                  })
                }
              >
                Register (hibernated by default)
              </button>
              <div className="mono text-[11px] text-slate-500 mt-3">Agent = id + role + capabilities + knowledge. Wakes load a compact context package, never the whole memory lake.</div>
              <div className="mono text-[11px] uppercase tracking-[0.18em] text-cyan-300 mt-5">Talk to a session (Pi-harness style)</div>
              <select value={chatAgent} onChange={(e) => setChatAgent(e.target.value)} className="mt-2 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[13px]">
                {(agentsData?.agents || []).map((a: any) => (
                  <option key={a.id} value={a.id}>{a.name} · {a.role}</option>
                ))}
              </select>
              <textarea value={chatText} onChange={(e) => setChatText(e.target.value)} rows={2} className="mt-2 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[13px]" />
              <button
                className="btn-ghost rounded-xl px-4 py-2 text-[13px] mt-2 w-full"
                onClick={() =>
                  run("agent turn", async () => {
                    const ss: any = await api(`/api/sessions?agentId=${chatAgent}`);
                    let sid = ss.sessions?.[0]?.id;
                    if (!sid) {
                      const c: any = await api("/api/sessions", { method: "POST", body: JSON.stringify({ agentId: chatAgent }) });
                      sid = c.session.id;
                    }
                    const r: any = await api("/api/sessions", { method: "PATCH", body: JSON.stringify({ id: sid, op: "message", message: chatText }) });
                    setChatReply(r.reply);
                    push(`Turn on ${sid.slice(0, 8)}: transcript +1, worker released.`);
                    await refreshSessions(chatAgent);
                  })
                }
              >
                Send turn (wake → reply → hibernate-ready)
              </button>
              {chatReply && <pre className="wrap mono text-[12px] text-lime-200 bg-black/40 border border-lime-400/20 rounded-xl p-3 mt-2">{chatReply}</pre>}
            </div>
            <div className="lg:col-span-2 space-y-3">
              {(agentsData?.agents || []).map((a: any) => (
                <div key={a.id} className="panel p-4 flex flex-wrap items-center gap-3 rise">
                  <div className="h-10 w-10 rounded-xl grid place-items-center font-black bg-white/5 border border-white/10">{a.name.slice(0, 1).toUpperCase()}</div>
                  <div className="min-w-[220px] flex-1">
                    <div className="font-bold text-[14px]">{a.name} <span className="text-slate-400 font-medium">· {a.role}</span></div>
                    <div className="mono text-[11px] text-slate-400 mt-0.5">caps: {((a.capabilities as string[]) || []).join(", ")} · wakes {a.wakeCount} · {a.sessionCount} sessions ({a.activeSessions} awake) · ${Number(a.spend || 0).toFixed(2)}/${a.budget}</div>
                  </div>
                  <Chip s={a.status} />
                  <div className="flex gap-2">
                    <button
                      className="btn-ghost rounded-lg px-3 py-1.5 text-[12px]"
                      onClick={() =>
                        run(`waking ${a.name}`, async () => {
                          await api("/api/agents", { method: "PATCH", body: JSON.stringify({ id: a.id, op: "wake" }) });
                          push(`${a.name} awake: compact context loaded; SQLite resumed.`);
                          await Promise.all([refreshAgents(), refreshSys()]);
                        })
                      }
                    >
                      Wake
                    </button>
                    <button
                      className="btn-ghost rounded-lg px-3 py-1.5 text-[12px]"
                      onClick={() =>
                        run(`hibernating ${a.name}`, async () => {
                          await api("/api/agents", { method: "PATCH", body: JSON.stringify({ id: a.id, op: "hibernate" }) });
                          push(`${a.name} asleep: worker released, snapshot kept.`);
                          await Promise.all([refreshAgents(), refreshSys()]);
                        })
                      }
                    >
                      Hibernate
                    </button>
                    <button
                      className="btn-ghost rounded-lg px-3 py-1.5 text-[12px]"
                      onClick={() =>
                        run("listing sessions", async () => {
                          await refreshSessions(a.id);
                        })
                      }
                    >
                      Sessions
                    </button>
                  </div>
                </div>
              ))}
              {sessions.length > 0 && (
                <div className="panel p-4">
                  <div className="mono text-[11px] uppercase tracking-[0.18em] text-cyan-300">Sessions (one DO per active conversation)</div>
                  <div className="mt-2 space-y-2">
                    {sessions.map((s: any) => (
                      <div key={s.id} className="rounded-xl bg-black/30 border border-white/10 p-3 flex flex-wrap items-center gap-2">
                        <span className="mono text-[12px] font-bold">{s.name}</span>
                        <Chip s={s.state} />
                        <span className="mono text-[11px] text-slate-400">turns {(s.transcript || []).length} · wakes {s.wakeCount}</span>
                        <span className="ml-auto flex gap-2">
                          <button className="btn-ghost rounded-lg px-2.5 py-1 text-[11px]" onClick={() => run("wake session", async () => { await api("/api/sessions", { method: "PATCH", body: JSON.stringify({ id: s.id, op: "wake" }) }); await refreshSessions(); })}>
                            Wake
                          </button>
                          <button className="btn-ghost rounded-lg px-2.5 py-1 text-[11px]" onClick={() => run("hibernate session", async () => { await api("/api/sessions", { method: "PATCH", body: JSON.stringify({ id: s.id, op: "hibernate" }) }); push(`Session ${s.name} snapshot persisted; eviction-safe.`); await refreshSessions(); })}>
                            Hibernate
                          </button>
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {tab === "work" && (
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="space-y-3">
              <div className="panel p-4">
                <div className="mono text-[11px] uppercase tracking-[0.18em] text-amber-300">Work Units ({workList.length})</div>
                <div className="mt-2 space-y-2 max-h-[520px] overflow-auto scrollthin">
                  {workList.map((w: any) => (
                    <button key={w.id} onClick={() => setSelectedWork(w.id)} className={`w-full text-left rounded-xl border p-3 ${selectedWork === w.id ? "border-amber-400/50 bg-amber-400/5" : "border-white/10 bg-black/20 hover:border-white/25"}`}>
                      <div className="flex items-center gap-2"><span className="font-bold text-[13px] flex-1">{w.title}</span><Chip s={w.status} /></div>
                      <div className="mono text-[11px] text-slate-400 mt-1">{w.doneCount}/{w.taskCount} tasks · ${Number(w.spend || 0).toFixed(2)}/${w.budget} · gauntlet {w.gauntletVerdict || "—"} ({w.gauntletRounds}r)</div>
                    </button>
                  ))}
                  {workList.length === 0 && <div className="mono text-[12px] text-slate-500">No work yet — file one from Command Deck.</div>}
                </div>
              </div>
            </div>
            <div className="lg:col-span-2 space-y-4">
              {!workDetail ? (
                <div className="panel p-6 mono text-slate-400 text-[13px]">Select a Work Unit.</div>
              ) : (
                <>
                  <div className="panel p-5 rise">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="text-lg font-extrabold flex-1">{workDetail.workUnit.title}</h2>
                      <Chip s={workDetail.workUnit.status} />
                      {workDetail.workUnit.gauntletVerdict && <Chip s={workDetail.workUnit.gauntletVerdict} />}
                    </div>
                    <p className="text-[13px] text-slate-300 mt-1">{workDetail.workUnit.objective}</p>
                    <div className="mono text-[11px] text-slate-400 mt-2">BAR: {workDetail.workUnit.qualityBar}</div>
                    <div className="mono text-[11px] text-slate-400 mt-1">ACCEPTANCE: {(workDetail.workUnit.acceptanceCriteria || []).join(" · ")}</div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      <button className="btn-ghost rounded-xl px-3.5 py-2 text-[12px]" onClick={() => run("planning DAG", async () => { const j: any = await api("/api/work", { method: "POST", body: JSON.stringify({ action: "plan", id: selectedWork }) }); setWorkDetail(j); push(`Planned ${j.tasks.length} nodes: plan→fanout(3)→join→verify→commit. No agent-per-task.`); await Promise.all([refreshSys(), refreshWork()]); })}>
                        1 · Plan DAG
                      </button>
                      <button className="btn-amber rounded-xl px-3.5 py-2 text-[12px]" onClick={() => run("bounded parallel execution", async () => { const j: any = await api("/api/work", { method: "POST", body: JSON.stringify({ action: "execute", id: selectedWork, wipLimit: 6 }) }); setWorkDetail(j); setExecLog(j.execLog || []); push(`Executed levels with ≤6/batch: ${(j.execLog || []).filter((e: any) => e.status === "succeeded").length} ok, ${(j.execLog || []).filter((e: any) => e.status === "awaiting_approval").length} parked.`); await Promise.all([refreshSys(), refreshWork(), refreshGov()]); })}>
                        2 · Execute (bounded)
                      </button>
                      <button className="btn-ghost rounded-xl px-3.5 py-2 text-[12px]" onClick={() => run("gauntlet round", async () => { const j: any = await api("/api/work", { method: "POST", body: JSON.stringify({ action: "gauntlet", id: selectedWork }) }); setWorkDetail(j); push(`Gauntlet: ${j.verdict} after ${j.workUnit.gauntletRounds} rounds (blind, harsh).`); await refreshWork(); })}>
                        3 · Gauntlet vs bar
                      </button>
                      <button className="btn-ghost rounded-xl px-3.5 py-2 text-[12px] border-lime-400/40" onClick={() => run("committing", async () => { try { const j: any = await api("/api/work", { method: "POST", body: JSON.stringify({ action: "commit", id: selectedWork }) }); setWorkDetail(j); push(`COMMITTED ✓ checksum ${j.artifacts?.find((a: any) => a.kind === "deliverable")?.checksum} · memory compiler ran async.`); await Promise.all([refreshSys(), refreshWork(), refreshMem(), refreshGov()]); } catch (e: any) { push(`Commit blocked (evidence gate): ${e.message}`); throw e; } })}>
                        4 · Commit
                      </button>
                    </div>
                    {execLog.length > 0 && (
                      <div className="mt-3 rounded-xl bg-black/40 border border-white/10 p-3 mono text-[11px] max-h-36 overflow-auto scrollthin">
                        {execLog.map((e: any, i: number) => (
                          <div key={i} className="flex gap-2 border-b border-white/5 py-1"><span className="text-amber-300 w-40 shrink-0 truncate">{e.title}</span><span className="text-slate-400">{e.queue}/T{e.tier}</span><span className="ml-auto text-slate-300">{e.ms}ms · ${e.cost} · {e.status}</span></div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="panel p-5">
                    <div className="mono text-[11px] uppercase tracking-[0.18em] text-cyan-300">Task DAG · independent work fans out, joins only at dependencies</div>
                    <div className="mt-3 space-y-3">
                      {dagLevels.map(([d, ts]: any, i: number) => (
                        <div key={i}>
                          <div className="mono text-[10px] text-slate-500 mb-1.5">LEVEL {d} · {ts.length} parallel · {i === 0 ? "planner (1 strong call)" : i === dagLevels.length - 1 ? "verify/commit" : "map / reduce"}</div>
                          <div className="grid gap-2 md:grid-cols-2">
                            {ts.map((t: any) => (
                              <div key={t.id} className="rounded-xl bg-black/30 border border-white/10 p-3">
                                <div className="flex items-center gap-2"><span className="text-[12px] font-bold flex-1">{t.title}</span><Chip s={t.status} /></div>
                                <div className="mono text-[10px] text-slate-500 mt-1">{t.kind} · {t.queue} · Tier {t.tier} · ${Number(t.cost || 0).toFixed(2)} · {t.durationMs}ms · tries {t.attempts}</div>
                                {t.criticScore != null && <div className="mono text-[10px] text-orange-300 mt-1">critic {t.criticScore} · gap: {t.criticGap}</div>}
                                {(t.evidence as any)?.notes && <div className="mono text-[10px] text-slate-400 mt-1">{((t.evidence as any).notes || []).join(" ")}</div>}
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                      {dagLevels.length === 0 && <div className="mono text-[12px] text-slate-500">Press “1 · Plan DAG”.</div>}
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="panel p-4">
                      <div className="mono text-[11px] uppercase tracking-[0.18em] text-amber-300">Gauntlet history (builder vs harsh blind critic)</div>
                      <div className="mt-2 space-y-2">
                        {((workDetail.workUnit.gauntletHistory as any[]) || []).map((g: any) => (
                          <div key={g.round} className={`rounded-xl border p-2.5 mono text-[11px] ${g.critic_pick === "ours" ? "border-lime-400/40 bg-lime-400/5" : "border-rose-400/30 bg-rose-400/5"}`}>
                            <div className="flex gap-2"><span className="font-black">R{g.round}</span><span className={g.critic_pick === "ours" ? "text-lime-300" : "text-rose-300"}>{g.critic_pick === "ours" ? "OURS WINS BLIND" : "BAR WINS"} · {g.score}</span></div>
                            <div className="text-slate-300 mt-1">gap: {g.biggest_gap}</div>
                          </div>
                        ))}
                        {((workDetail.workUnit.gauntletHistory as any[]) || []).length === 0 && <div className="mono text-[11px] text-slate-500">No rounds yet. Critic compares blind, labels stripped, binary pick — scores never average away a hard gate.</div>}
                      </div>
                    </div>
                    <div className="panel p-4">
                      <div className="mono text-[11px] uppercase tracking-[0.18em] text-cyan-300">Artifacts (R2-sim · Postgres holds hash+URI)</div>
                      <div className="mt-2 space-y-2 max-h-64 overflow-auto scrollthin">
                        {(workDetail.artifacts || []).map((a: any) => (
                          <details key={a.id} className="rounded-xl bg-black/30 border border-white/10 p-2.5">
                            <summary className="mono text-[11px] cursor-pointer"><span className="text-amber-300">{a.kind}</span> · {a.name} · <span className="text-slate-500">{a.checksum}</span></summary>
                            <pre className="wrap mono text-[11px] text-slate-300 mt-2 max-h-40 overflow-auto">{a.content?.slice(0, 1800)}</pre>
                            <div className="mono text-[10px] text-slate-500 mt-1">{a.uri} · {a.sizeBytes}B</div>
                          </details>
                        ))}
                        {(workDetail.artifacts || []).length === 0 && <div className="mono text-[11px] text-slate-500">Artifacts stream here during execution; reducer reads refs, not transcripts.</div>}
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {tab === "browser" && (
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="panel p-5">
              <div className="mono text-[11px] uppercase tracking-[0.18em] text-amber-300">Open in pooled browser (no new VM)</div>
              <select value={chatAgent} onChange={(e) => setChatAgent(e.target.value)} className="mt-2 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[13px]">
                {(agentsData?.agents || []).map((a: any) => (
                  <option key={a.id} value={a.id}>{a.name}</option>
                ))}
              </select>
              <input value={browserUrl} onChange={(e) => setBrowserUrl(e.target.value)} className="mt-2 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[13px] mono" />
              <button
                className="btn-amber rounded-xl px-4 py-2 text-[13px] mt-2 w-full"
                onClick={() =>
                  run("browser.open", async () => {
                    const j: any = await api("/api/browser", { method: "POST", body: JSON.stringify({ action: "open", agentId: chatAgent, url: browserUrl }) });
                    push(`Tab opened in pooled context: ${browserUrl} (${j.browser?.tabs?.length} tabs).`);
                    await Promise.all([refreshBrows(), refreshGov()]);
                  })
                }
              >
                Open tab (Playwright/CDP first)
              </button>
              <div className="mono text-[11px] text-slate-500 mt-2">Deterministic control first; Stagehand observe/act/extract only on DOM failure; Midscene only for visual-only UI. Tab cap 6 — heavy pages recycle the process.</div>
            </div>
            <div className="lg:col-span-2 space-y-3">
              <div className="panel p-4 mono text-[11px] text-slate-400">Pool: <span className="text-slate-200">{brows?.pool?.processes ?? 1} warm Chromium processes</span> · {brows?.pool?.note}</div>
              {(brows?.browsers || []).map((b: any) => (
                <div key={b.id} className="panel p-4 rise">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-bold text-[14px]">{b.agentName}</span>
                    <Chip s={b.status} />
                    <span className="mono text-[11px] text-slate-400">{b.tabsCount} tabs · {b.memoryMb} MiB · allow: {((b.domainAllowlist as string[]) || []).join(", ") || "—"}</span>
                    <span className="ml-auto flex gap-2">
                      <button className="btn-ghost rounded-lg px-2.5 py-1 text-[11px]" onClick={() => run("live view", async () => { const j: any = await api("/api/browser", { method: "POST", body: JSON.stringify({ action: "takeover", id: b.id }) }); setTakeover(j); push("Live View minted (bearer, 15m, human-only — never to model)."); })}>
                        Human takeover
                      </button>
                      <button className="btn-ghost rounded-lg px-2.5 py-1 text-[11px]" onClick={() => run("hibernate browser", async () => { await api("/api/browser", { method: "POST", body: JSON.stringify({ action: "hibernate", id: b.id }) }); push("Browser hibernated: cookies kept, process released."); await refreshBrows(); })}>
                        Hibernate
                      </button>
                      <button className="btn-ghost rounded-lg px-2.5 py-1 text-[11px]" onClick={() => run("recycle browser", async () => { await api("/api/browser", { method: "POST", body: JSON.stringify({ action: "recycle", id: b.id }) }); await refreshBrows(); })}>
                        Recycle
                      </button>
                    </span>
                  </div>
                  <div className="mt-2 grid gap-2 md:grid-cols-3">
                    {(b.tabs || []).map((t: any) => (
                      <div key={t.url} className="rounded-xl bg-black/30 border border-white/10 p-2.5">
                        <div className="mono text-[11px] font-bold truncate">{t.title}</div>
                        <div className="mono text-[10px] text-cyan-300 truncate">{t.url}</div>
                        <div className="mono text-[10px] text-slate-500 mt-1">isolated context · screenshot ✓ · CDP ✓</div>
                        <button className="mono text-[10px] text-rose-300 mt-1" onClick={() => run("close tab", async () => { await api("/api/browser", { method: "POST", body: JSON.stringify({ action: "close-tab", id: b.id, url: t.url }) }); await refreshBrows(); })}>
                          close tab
                        </button>
                      </div>
                    ))}
                    {(b.tabs || []).length === 0 && <div className="mono text-[11px] text-slate-500">No tabs — hibernating with session intact.</div>}
                  </div>
                </div>
              ))}
              {takeover && (
                <div className="panel p-4 border-amber-400/40">
                  <div className="mono text-[11px] uppercase tracking-widest text-amber-300">Live View — human bearer credential</div>
                  <div className="mono text-[12px] text-cyan-200 mt-1 break-all">{takeover.liveViewUrl}</div>
                  <div className="mono text-[11px] text-rose-300 mt-1">{takeover.warning}</div>
                  <div className="text-[12px] text-slate-300 mt-2">Flow: agent parks at login/MFA → you complete it in this browser → agent resumes with updated cookies in the same session.</div>
                </div>
              )}
            </div>
          </div>
        )}

        {tab === "memory" && (
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="panel p-5">
              <div className="mono text-[11px] uppercase tracking-[0.18em] text-amber-300">Memory compiler (async, off critical path)</div>
              <div className="flex gap-2 mt-2">
                <input value={memQuery} onChange={(e) => setMemQuery(e.target.value)} placeholder="search memories…" className="flex-1 rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[13px]" />
                <button className="btn-ghost rounded-xl px-3 py-2 text-[12px]" onClick={() => run("memory search", async () => { await refreshMem(memQuery); })}>Search</button>
              </div>
              <textarea value={memAdd} onChange={(e) => setMemAdd(e.target.value)} rows={2} className="mt-2 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[13px]" />
              <div className="flex gap-2 mt-2">
                <button className="btn-ghost rounded-xl px-3 py-2 text-[12px] flex-1" onClick={() => run("add memory", async () => { await api("/api/memory", { method: "POST", body: JSON.stringify({ action: "add", kind: "semantic", content: memAdd }) }); push("Candidate memory staged (unpromoted)."); await refreshMem(); })}>
                  Stage candidate
                </button>
                <button className="btn-amber rounded-xl px-3 py-2 text-[12px] flex-1" onClick={() => run("compiling memories", async () => { const j: any = await api("/api/memory", { method: "POST", body: JSON.stringify({ action: "compile" }) }); push(`Compiler: ${j.candidates} candidates → promoted 2${j.skill ? ` + forged ${j.skill.name}` : ""}.`); await Promise.all([refreshMem(), refreshGov()]); })}>
                  Run compiler
                </button>
              </div>
              <div className="mono text-[11px] text-slate-500 mt-3">Pipeline: extract → dedupe → scope → validate contradictions → promote → forge skill after tests. pgvector-first; Graphiti only if relational edges demonstrably fail.</div>
              <div className="grid grid-cols-4 gap-2 mt-3 mono text-center text-[11px]">
                {(["personal", "episodic", "semantic", "procedural"] as const).map((k) => (
                  <div key={k} className="rounded-xl bg-black/30 border border-white/10 p-2"><div className="text-slate-400 text-[10px]">{k}</div><div className="font-black text-[15px]">{memData?.byKind?.[k] ?? 0}</div></div>
                ))}
              </div>
            </div>
            <div className="lg:col-span-2 space-y-3">
              {(memData?.memories || []).map((m: any) => (
                <div key={m.id} className="panel p-3.5 flex gap-3 items-start rise">
                  <div className="flex-1">
                    <div className="flex items-center gap-2"><span className="mono text-[11px] text-cyan-300">{m.kind}</span><span className="mono text-[11px] text-slate-500">{m.scope} · trust {m.trust}</span>{m.promoted && <span className="chip mono px-2 py-0.5 text-[10px] text-lime-300 border-lime-400/30 bg-lime-400/10">promoted</span>}</div>
                    <div className="text-[13px] mt-1">{m.content}</div>
                    <div className="mono text-[10px] text-slate-500 mt-1">prov: {JSON.stringify(m.provenance)}</div>
                  </div>
                  <button className="btn-ghost rounded-lg px-2.5 py-1 text-[11px] shrink-0" onClick={() => run("toggle promote", async () => { await api("/api/memory", { method: "POST", body: JSON.stringify({ action: m.promoted ? "demote" : "promote", id: m.id }) }); await refreshMem(memQuery); })}>
                    {m.promoted ? "Demote" : "Promote"}
                  </button>
                </div>
              ))}
              <div className="panel p-4">
                <div className="mono text-[11px] uppercase tracking-[0.18em] text-cyan-300">Versioned skills ({(memData?.skills || []).length})</div>
                <div className="mt-2 grid gap-2 md:grid-cols-2">
                  {(memData?.skills || []).map((s: any) => (
                    <div key={s.id} className="rounded-xl bg-black/30 border border-white/10 p-3">
                      <div className="flex items-center gap-2"><span className="font-bold text-[13px]">{s.name}</span><span className="mono text-[10px] text-slate-500">{s.version}</span><Chip s={s.status === "stable" ? "succeeded" : "queued"} /></div>
                      <div className="text-[12px] text-slate-300 mt-1">{s.description}</div>
                      <div className="mono text-[10px] text-slate-500 mt-1">{s.codePackage} · used {s.usageCount}× · {JSON.stringify(s.testReport)}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {tab === "govern" && (
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="panel p-5">
              <div className="mono text-[11px] uppercase tracking-[0.18em] text-orange-300">Approval center ({(gov?.approvals || []).filter((a: any) => a.status === "pending").length} pending)</div>
              <div className="mt-2 space-y-2">
                {(gov?.approvals || []).map((a: any) => (
                  <div key={a.id} className="rounded-xl bg-black/30 border border-white/10 p-3">
                    <div className="flex items-center gap-2"><span className="font-bold text-[13px] flex-1">{a.title}</span><Chip s={a.status} /></div>
                    <div className="text-[12px] text-slate-300 mt-1">{a.description}</div>
                    <div className="mono text-[10px] text-slate-500 mt-1">by {a.requestedBy} · {new Date(a.createdAt).toLocaleString()}</div>
                    {a.status === "pending" && (
                      <div className="flex gap-2 mt-2">
                        <button className="rounded-lg px-3 py-1.5 text-[12px] bg-lime-400 text-black font-bold" onClick={() => run("approving", async () => { await api("/api/governance", { method: "POST", body: JSON.stringify({ action: "decide", id: a.id, verdict: "approved" }) }); push(`Approved ${a.title}: workflow resumes, token scope unchanged.`); await Promise.all([refreshGov(), refreshSys()]); if (selectedWork) await refreshDetail(); })}>
                          Approve
                        </button>
                        <button className="rounded-lg px-3 py-1.5 text-[12px] border border-rose-400/40 text-rose-300" onClick={() => run("rejecting", async () => { await api("/api/governance", { method: "POST", body: JSON.stringify({ action: "decide", id: a.id, verdict: "rejected" }) }); await Promise.all([refreshGov(), refreshSys()]); if (selectedWork) await refreshDetail(); })}>
                          Reject
                        </button>
                      </div>
                    )}
                  </div>
                ))}
                {(gov?.approvals || []).length === 0 && <div className="mono text-[12px] text-slate-500">No approvals. High-impact tasks (login, payment, prod) auto-create a durable gate.</div>}
              </div>
              <div className="mono text-[11px] text-slate-500 mt-3">Invariants: ① model never sees secrets (broker injects) ② untrusted input can't widen grants ③ child ≤ parent authority.</div>
            </div>
            <div className="panel p-5">
              <div className="mono text-[11px] uppercase tracking-[0.18em] text-cyan-300">Immutable receipts · audit & cost ledger</div>
              <div className="mt-2 space-y-1.5 max-h-[560px] overflow-auto scrollthin mono text-[11px]">
                {(gov?.receipts || []).map((r: any) => (
                  <div key={r.id} className="rounded-lg bg-black/30 border border-white/10 px-2.5 py-2 flex gap-2 items-start">
                    <span className={r.verdict === "deny" ? "text-rose-300" : r.verdict === "hold" ? "text-orange-300" : "text-lime-300"}>●</span>
                    <div className="flex-1">
                      <div><span className="text-slate-100">{r.action}</span> <span className="text-slate-500">· {String(r.resource).slice(0, 90)}</span></div>
                      <div className="text-slate-500">{new Date(r.createdAt).toLocaleTimeString()} · {r.cost ? `$${r.cost}` : "$0"} · tok {r.tokenHash || "—"} · {r.policyVersion}</div>
                    </div>
                    <span className="text-slate-500">{r.verdict}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === "bench" && (
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="panel p-5">
              <div className="mono text-[11px] uppercase tracking-[0.18em] text-amber-300">AOS capacity qualification</div>
              <p className="text-[13px] text-slate-300 mt-1">Proposed targets, not claimed capacity. Runs the real deterministic engine on a bounded sample and extrapolates with caps on.</p>
              <button
                className="btn-amber rounded-xl px-4 py-2 text-[13px] mt-3"
                onClick={() =>
                  run("running qualification", async () => {
                    const j: any = await api("/api/system", { method: "POST", body: JSON.stringify({ action: "benchmark" }) });
                    setBench(j);
                    push(`Qualification done in ${j.ms}ms: ${j.tests.filter((t: any) => t.result === "pass").length}/${j.tests.length} pass.`);
                  })
                }
              >
                Run qualification
              </button>
              {bench && (
                <div className="mt-3 space-y-2">
                  {bench.tests.map((t: any, i: number) => (
                    <div key={i} className="rounded-xl bg-black/30 border border-lime-400/20 p-3">
                      <div className="flex gap-2 mono text-[12px]"><span className="text-lime-300 font-black">PASS</span><span className="font-bold">{t.name}</span></div>
                      <div className="mono text-[11px] text-slate-400 mt-1">{t.detail}</div>
                    </div>
                  ))}
                  <div className="mono text-[11px] text-slate-400">gates: {JSON.stringify(bench.gates)} · economics: {JSON.stringify(bench.economics)}</div>
                </div>
              )}
            </div>
            <div className="space-y-4">
              <div className="panel p-5">
                <div className="mono text-[11px] uppercase tracking-[0.18em] text-cyan-300">TRIZ contradiction solver (breakthrough fallback)</div>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <input value={trizP} onChange={(e) => setTrizP(e.target.value)} className="rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[13px]" />
                  <input value={trizW} onChange={(e) => setTrizW(e.target.value)} className="rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[13px]" />
                </div>
                <button className="btn-ghost rounded-xl px-4 py-2 text-[12px] mt-2 w-full" onClick={() => run("TRIZ", async () => { const j: any = await api("/api/system", { method: "POST", body: JSON.stringify({ action: "triz", problem: trizP, worsens: trizW }) }); setTrizOut(j); })}>
                  Resolve structurally
                </button>
                {trizOut && (
                  <div className="mono text-[12px] mt-2 space-y-1 bg-black/30 border border-white/10 rounded-xl p-3">
                    <div><span className="text-slate-500">CONTRADICTION </span>{trizOut.contradiction}</div>
                    <div><span className="text-slate-500">PRINCIPLES </span><span className="text-amber-300">{trizOut.principles.join(" · ")}</span></div>
                    <div><span className="text-slate-500">SEPARATION </span>{trizOut.separation}</div>
                    <div><span className="text-slate-500">INVENTION </span><span className="text-lime-300">{trizOut.invention}</span></div>
                  </div>
                )}
              </div>
              <div className="panel p-5">
                <div className="mono text-[11px] uppercase tracking-[0.18em] text-cyan-300">Safe sweep planner (full-plan-delivery reservations)</div>
                <button
                  className="btn-ghost rounded-xl px-4 py-2 text-[12px] mt-1 w-full"
                  onClick={() =>
                    run("sweep", async () => {
                      const cells = (workDetail?.tasks || []).slice(0, 6).map((t: any) => ({ taskId: t.id, goal: t.title, scopes: [t.queue, t.kind], contracts: ["authority-token", "idempotency"] }));
                      const j: any = await api("/api/system", { method: "POST", body: JSON.stringify({ action: "sweep", cells, wipLimit: 4 }) });
                      setSweepOut(j);
                      push(`Sweep: ${j.selected.length} reserved, ${j.rejected.length} deferred (scope/WIP).`);
                    })
                  }
                >
                  Sweep current Work Unit (WIP 4)
                </button>
                {sweepOut && (
                  <div className="mono text-[11px] mt-2 space-y-1">
                    <div className="text-lime-300">SELECTED {sweepOut.selected.length}: {sweepOut.selected.map((s: any) => s.goal?.slice(0, 42)).join(" | ")}</div>
                    {sweepOut.rejected.map((r: any, i: number) => (
                      <div key={i} className="text-orange-300">DEFERRED: {r.cell.goal?.slice(0, 50)} — {r.reason}</div>
                    ))}
                  </div>
                )}
                <button
                  className="btn-ghost rounded-xl px-4 py-2 text-[12px] mt-3 w-full"
                  onClick={() =>
                    run("handoff", async () => {
                      const j: any = await api("/api/system", { method: "POST", body: JSON.stringify({ action: "handoff", task: selectedWork || "mission", completed: "bounded execution + gauntlet evidence", remaining: "commit + compiler promotion", evidence: "receipts + artifacts + blind pick" }) });
                      push(`Handoff persisted: ${JSON.stringify(j.handoff).slice(0, 120)}…`);
                      await refreshSys();
                    })
                  }
                >
                  Persist handoff (session-boundary safe)
                </button>
              </div>
            </div>
          </div>
        )}

        {tab === "arch" && (
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="panel p-5">
              <div className="mono text-[11px] uppercase tracking-[0.18em] text-amber-300">Revised stack (consolidated, low footprint)</div>
              <div className="mt-3 space-y-2 mono text-[12px]">
                {[
                  ["Ingress + UI", "Workers-class edge (here: Next.js) · WS · voice/messaging adapters"],
                  ["Sessions", "Agents SDK + PiHarness pattern → DO-SQLite snapshots (simulated, eviction-safe)"],
                  ["Orchestration", "Workflows-class durable DAG (here: Postgres-checkpointed levels + idempotency)"],
                  ["Fan-out", "Queues-class bounded dispatch · ≤6/batch · C_allowed"],
                  ["Canonical DB", "PostgreSQL + pgvector-sim · Hyperdrive-class pooling"],
                  ["Artifacts", "R2-class object store (hash + URI in PG)"],
                  ["Browser", "Browser Run pattern: pooled Chromium, isolated contexts, Live View"],
                  ["Sandbox", "Containers lite 256MiB + Firecracker-class CoW fork only when needed"],
                  ["Intelligence", "One gateway · task ladder · deterministic-first routing"],
                  ["Security", "Cedar-style policy + scoped signed tokens + brokered secrets"],
                  ["Quality", "Gauntlet blind critic + acceptance gates + Inspect-class eval"],
                ].map(([k, v], i) => (
                  <div key={i} className="flex gap-3 border-b border-white/5 pb-2"><span className="w-28 shrink-0 text-cyan-300">{k}</span><span className="text-slate-300">{v}</span></div>
                ))}
              </div>
              <div className="mono text-[11px] text-slate-500 mt-3">Explicitly NOT deployed: K8s · Redis · Kafka · Neo4j/FalkorDB-server · Qdrant · 5 gateways · per-agent VMs · vision-per-click browser.</div>
            </div>
            <div className="space-y-4">
              <div className="panel p-5">
                <div className="mono text-[11px] uppercase tracking-[0.18em] text-lime-300">Skill application log (with workarounds)</div>
                <div className="mt-2 space-y-2 mono text-[12px]">
                  <div className="rounded-xl bg-black/30 border border-lime-400/25 p-3">
                    <div className="text-lime-300 font-bold">✓ gauntlet-loop — APPLIED as commit gate</div>
                    <div className="text-slate-300 mt-1">Every Work Unit pins a named/fetchable/comparable bar. Builder improves, harsh critic compares blind (labels stripped, binary pick, biggest gap). Loops until ours wins blind or 5 rounds → human. See Work → Gauntlet history.</div>
                  </div>
                  <div className="rounded-xl bg-black/30 border border-lime-400/25 p-3">
                    <div className="text-lime-300 font-bold">✓ full-plan-delivery — APPLIED as mission authority</div>
                    <div className="text-slate-300 mt-1">Single mission authority, bounded vertical slices, sweep reservations (scope/WIP), evidence-gated commit, durable handoffs. No invented acceptance — receipts + artifacts + blind pick required.</div>
                  </div>
                  <div className="rounded-xl bg-black/30 border border-amber-400/30 p-3">
                    <div className="text-amber-300 font-bold">⚠ breakthrough_skill.zip + AAA-V7-SPEC — WORKAROUND (fetch failed)</div>
                    <div className="text-slate-300 mt-1">Both URLs returned fetch errors, so I ported their documented roles deterministically: TRIZ separation solver (Benchmarks tab) + AAA-style governed contracts (scoped tokens, brokered secrets, immutable receipts, hibernation-safe recovery). Re-point me at raw file URLs and I’ll swap the port for the real specs.</div>
                  </div>
                  <div className="rounded-xl bg-black/30 border border-white/10 p-3">
                    <div className="text-cyan-300 font-bold">Cloudflare assembly (Pi example · Playwright · Stagehand · Midscene)</div>
                    <div className="text-slate-300 mt-1">Simulated behind replaceable interfaces here: session snapshots ≈ DO-SQLite, levels+queues ≈ Workflows/Queues, pooled tabs ≈ Browser Run, CoW fork ≈ Firecracker/OpenSandbox. Swap providers without changing identities, DAG contracts, envelopes, or verification.</div>
                  </div>
                </div>
              </div>
              <div className="panel p-5 mono text-[12px]">
                <div className="text-slate-400">THE VERDICT LOOP</div>
                <div className="mt-1 text-slate-200">Human defines outcome → org creates durable DAG → scheduler wakes only needed caps → shared workers fan out → right computer appears briefly → verifier checks blind → learning persists → resources released.</div>
                <div className="mt-2 text-amber-300">Metric that matters: verified work per GB-active per dollar — not agent count.</div>
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="mx-auto max-w-7xl px-4 pb-8 mono text-[11px] text-slate-500">
        AOS v3 console · Postgres canonical · artifacts content-addressed · sessions hibernatable · fan-out bounded · critic harsh · approvals durable · idle = storage only.
      </footer>
    </div>
  );
}
