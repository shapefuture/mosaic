import { NextResponse } from "next/server";
import { db } from "@/db";
import { workUnits, tasks, agents, sessions, artifacts, approvals, receipts, memories } from "@/db/schema";
import { eq, desc, inArray } from "drizzle-orm";
import {
  planWorkUnit,
  executeDeterministicTask,
  mintAuthorityToken,
  verifyAuthorityToken,
  allowedConcurrency,
  DEFAULT_CAPS,
  blindCritic,
  scoreToVerdict,
  checksum,
  type QueueName,
} from "@/lib/aos/engine";
import { ensureSeed } from "@/lib/aos/seed";

export const dynamic = "force-dynamic";

async function detail(id: string) {
  const [wu] = await db.select().from(workUnits).where(eq(workUnits.id, id)).limit(1);
  if (!wu) return null;
  const ts = await db.select().from(tasks).where(eq(tasks.workUnitId, id));
  const arts = await db.select().from(artifacts).where(eq(artifacts.workUnitId, id));
  const apprs = await db.select().from(approvals).where(eq(approvals.workUnitId, id));
  const rcts = await db.select().from(receipts).where(eq(receipts.workUnitId, id)).orderBy(desc(receipts.createdAt)).limit(60);
  return { workUnit: wu, tasks: ts, artifacts: arts, approvals: apprs, receipts: rcts };
}

export async function GET(req: Request) {
  await ensureSeed();
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (id) {
    const d = await detail(id);
    if (!d) return NextResponse.json({ error: "not found" }, { status: 404 });
    return NextResponse.json(d);
  }
  const list = await db.select().from(workUnits).orderBy(desc(workUnits.createdAt)).limit(50);
  const allTasks = await db.select().from(tasks).limit(500);
  const withCounts = list.map((w) => ({
    ...w,
    taskCount: allTasks.filter((t) => t.workUnitId === w.id).length,
    doneCount: allTasks.filter((t) => t.workUnitId === w.id && (t.status === "succeeded" || t.status === "awaiting_approval")).length,
  }));
  return NextResponse.json({ workUnits: withCounts });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { action } = body as { action: string };

  if (action === "create") {
    const title = String(body.title || "Untitled objective");
    const objective = String(body.objective || title);
    const qualityBar = String(body.qualityBar || "Stripe-quality deliverable: specific, fetchable reference compared blind side-by-side.");
    const acceptanceCriteria: string[] = Array.isArray(body.acceptanceCriteria) && body.acceptanceCriteria.length
      ? body.acceptanceCriteria
      : ["All map tasks succeeded", "Blind critic picks ours (score ≥ 80)", "Every claim has provenance", "No duplicate side effects", "Deliverable committed with checksum"];
    const budget = Number(body.budget ?? 5);
    const [wu] = await db
      .insert(workUnits)
      .values({ title, objective, qualityBar, acceptanceCriteria, budget, status: "planned", missionRef: "AOS v3 bootstrap mission" })
      .returning();
    await db.insert(receipts).values({
      workUnitId: wu.id,
      action: "work.create",
      resource: `work:${wu.id}`,
      verdict: "allow",
      details: { title, bar: qualityBar.slice(0, 140), criteria: acceptanceCriteria.length },
    });
    return NextResponse.json({ workUnit: wu });
  }

  if (action === "plan") {
    const { id } = body as { id: string };
    const [wu] = await db.select().from(workUnits).where(eq(workUnits.id, id)).limit(1);
    if (!wu) return NextResponse.json({ error: "not found" }, { status: 404 });
    await db.delete(tasks).where(eq(tasks.workUnitId, id));
    const nodes = planWorkUnit(wu.objective);
    const pool = await db.select().from(agents);
    const pick = (caps: string[]) => {
      const scored = pool.map((a) => ({
        a,
        overlap: ((a.capabilities as string[]) || []).filter((c) => caps.includes(c)).length,
      }));
      scored.sort((x, y) => y.overlap - x.overlap);
      return scored[0]?.a ?? pool[0];
    };
    const keyToId: Record<string, string> = {};
    // create in dependency order
    for (const n of nodes) {
      const agent = pick(n.kind === "plan" ? ["plan"] : n.kind === "browser" ? ["browser.read"] : n.kind === "code" ? ["code.exec"] : n.kind === "verify" ? ["verify"] : ["http.get", "extract"]);
      const sess = (await db.select().from(sessions).where(eq(sessions.agentId, agent.id)).limit(1))[0];
      const token = mintAuthorityToken({
        agent_id: agent.id,
        work_unit_id: id,
        session_id: sess?.id ?? "none",
        actions: n.kind === "browser" ? ["browser.read"] : n.kind === "code" ? ["code.exec"] : ["http.get", "extract"],
        resources: ["project:market-intelligence"],
        domains: ["approved.example"],
        max_cost: 0.75,
        delegation_depth: 1,
        policy_version: "v12",
      });
      const [t] = await db
        .insert(tasks)
        .values({
          workUnitId: id,
          agentId: agent.id,
          sessionId: sess?.id ?? null,
          title: n.title,
          kind: n.kind,
          queue: n.queue,
          tier: n.tier,
          authorityToken: token,
          input: { node: n.key, objective: wu.objective },
          dependsOn: n.dependsOnKeys.map((k) => keyToId[k]).filter(Boolean),
          idempotencyKey: `${id}:${n.key}`,
          status: n.needsApproval ? "queued" : "queued",
        })
        .returning();
      keyToId[n.key] = t.id;
      // fix dependsOn keys that were not yet mapped (second pass below)
    }
    // second pass: rewrite dependsOn using key map stored in input.node
    const all = await db.select().from(tasks).where(eq(tasks.workUnitId, id));
    const nodeKeyOf = (t: (typeof all)[number]) => (t.input as { node?: string })?.node ?? "";
    const idOfKey = (k: string) => all.find((t) => nodeKeyOf(t) === k)?.id ?? "";
    const plan = planWorkUnit(wu.objective);
    for (const t of all) {
      const nk = nodeKeyOf(t);
      const node = plan.find((p) => p.key === nk);
      if (!node) continue;
      const deps = node.dependsOnKeys.map((k) => idOfKey(k)).filter(Boolean);
      await db.update(tasks).set({ dependsOn: deps }).where(eq(tasks.id, t.id));
    }
    await db.update(workUnits).set({ status: "running", planGraph: { nodes: plan } }).where(eq(workUnits.id, id));
    await db.insert(receipts).values({
      workUnitId: id,
      action: "work.plan",
      resource: `work:${id}`,
      verdict: "allow",
      details: { dag: "plan->fanout(3)->join->verify->commit", nodes: plan.length, note: "One planning call; no agent per child process." },
    });
    return NextResponse.json(await detail(id));
  }

  if (action === "execute") {
    const { id, wipLimit } = body as { id: string; wipLimit?: number };
    const [wu] = await db.select().from(workUnits).where(eq(workUnits.id, id)).limit(1);
    if (!wu) return NextResponse.json({ error: "not found" }, { status: 404 });
    let ts = await db.select().from(tasks).where(eq(tasks.workUnitId, id));
    const byId = new Map(ts.map((t) => [t.id, t]));
    const done = new Set(ts.filter((t) => ["succeeded", "awaiting_approval", "failed", "cancelled"].includes(t.status)).map((t) => t.id));
    const order: typeof ts[] = [];
    // levelize by dependencies
    const remaining = ts.filter((t) => !done.has(t.id));
    const depthOf = (t: (typeof ts)[number], seen = new Set<string>()): number => {
      if (seen.has(t.id)) return 0;
      seen.add(t.id);
      const deps = ((t.dependsOn as string[]) || []).map((d) => byId.get(d)).filter(Boolean) as typeof ts;
      if (!deps.length) return 0;
      return 1 + Math.max(...deps.map((d) => depthOf(d, seen)));
    };
    const levels = new Map<number, typeof ts>();
    for (const t of remaining) {
      const d = depthOf(t);
      if (!levels.has(d)) levels.set(d, []);
      levels.get(d)!.push(t);
    }
    const sortedDepths = [...levels.keys()].sort((a, b) => a - b);
    let totalCost = 0;
    const execLog: { title: string; queue: string; tier: number; ms: number; cost: number; status: string }[] = [];
    for (const depth of sortedDepths) {
      const level = levels.get(depth)!;
      // group by queue, bound each queue
      const byQueue = new Map<string, typeof level>();
      for (const t of level) {
        const q = t.queue || "io";
        if (!byQueue.has(q)) byQueue.set(q, []);
        byQueue.get(q)!.push(t);
      }
      for (const [q, group] of byQueue) {
        const caps = DEFAULT_CAPS[(q as QueueName) ?? "io"] ?? DEFAULT_CAPS.io;
        const allowed = allowedConcurrency({ ...caps, budget: Math.max(1, Number(wipLimit ?? caps.queue)) });
        // chunked parallel execution (respects 6-conn guidance: small batches)
        const batchSize = Math.min(allowed, 6);
        for (let i = 0; i < group.length; i += batchSize) {
          const batch = group.slice(i, i + batchSize);
          // check deps + idempotency + token before running
          const runnable = batch.filter((t) => {
            const deps = (t.dependsOn as string[]) || [];
            return deps.every((d) => byId.get(d)?.status === "succeeded" || byId.get(d)?.status === "awaiting_approval");
          });
          await Promise.all(
            runnable.map(async (t) => {
              const tokCheck = verifyAuthorityToken(t.authorityToken as never);
              if (!tokCheck.ok) {
                await db.update(tasks).set({ status: "failed", evidence: { auth: tokCheck.reason } }).where(eq(tasks.id, t.id));
                return;
              }
              // idempotency: skip if receipt already exists for this key
              const prior = await db.select().from(receipts).where(eq(receipts.taskId, t.id)).limit(1);
              if (prior.length && t.status === "succeeded") return;
              const ag = t.agentId ? (await db.select().from(agents).where(eq(agents.id, t.agentId)).limit(1))[0] : null;
              // wake agent ephemerally
              if (ag && ag.status !== "active") {
                await db.update(agents).set({ status: "active", activeMemoryKb: 4200, lastWakeAt: new Date(), wakeCount: (ag.wakeCount || 0) + 1 }).where(eq(agents.id, ag.id));
              }
              await db.update(tasks).set({ status: "running", startedAt: new Date(), attempts: (t.attempts || 0) + 1 }).where(eq(tasks.id, t.id));
              if (t.kind === "approval") {
                await db.insert(approvals).values({
                  workUnitId: id,
                  taskId: t.id,
                  title: "High-impact gate",
                  description: `Objective mentions sensitive side effects. Approve to continue past "${t.title}".`,
                  requestedBy: ag?.name ?? "scheduler",
                  status: "pending",
                });
                await db.update(tasks).set({ status: "awaiting_approval", finishedAt: new Date() }).where(eq(tasks.id, t.id));
                await db.insert(receipts).values({
                  workUnitId: id,
                  taskId: t.id,
                  agentId: t.agentId,
                  action: "task.park-approval",
                  resource: t.title,
                  verdict: "hold",
                  details: { note: "Workflow hibernates; no worker held while awaiting human." },
                });
                execLog.push({ title: t.title, queue: t.queue, tier: t.tier, ms: 5, cost: 0, status: "awaiting_approval" });
                return;
              }
              const res = await executeDeterministicTask({
                title: t.title,
                kind: t.kind,
                queue: (t.queue as QueueName) || "io",
                tier: (t.tier as 0 | 1 | 2) || 0,
                input: (t.input as Record<string, unknown>) || {},
                agentName: ag?.name ?? "worker",
                attempt: (t.attempts || 0) + 1,
              });
              totalCost += res.cost;
              await db
                .update(tasks)
                .set({ status: "succeeded", output: res.output, evidence: { ...res.evidence, notes: res.notes }, cost: res.cost, durationMs: res.durationMs, finishedAt: new Date(), tier: res.tierUsed })
                .where(eq(tasks.id, t.id));
              await db.insert(receipts).values({
                workUnitId: id,
                taskId: t.id,
                agentId: t.agentId,
                action: `task.${t.kind}`,
                resource: t.title.slice(0, 120),
                cost: res.cost,
                tokenHash: checksum(JSON.stringify(t.authorityToken)),
                verdict: "allow",
                details: { tier: res.tierUsed, queue: t.queue, ms: res.durationMs },
              });
              // compact artifact for reducer-relevant tasks
              if (["synthesize", "research", "extract", "code", "browser"].includes(t.kind)) {
                const content = `# ${t.title}\n\n${JSON.stringify(res.output, null, 2)}\n\nEvidence:\n${JSON.stringify(res.evidence, null, 2)}`;
                await db.insert(artifacts).values({
                  workUnitId: id,
                  taskId: t.id,
                  name: `${t.kind}-${checksum(t.id)}.md`,
                  kind: t.kind,
                  uri: `r2://aos/${id}/${checksum(t.id)}.md`,
                  checksum: checksum(content),
                  sizeBytes: content.length,
                  content,
                });
              }
              // hibernate agent again (tiny footprint)
              if (ag) {
                await db.update(agents).set({ status: "hibernating", activeMemoryKb: 0 }).where(eq(agents.id, ag.id));
              }
              execLog.push({ title: t.title, queue: t.queue, tier: res.tierUsed, ms: res.durationMs, cost: res.cost, status: "succeeded" });
              const fresh = (await db.select().from(tasks).where(eq(tasks.id, t.id)).limit(1))[0];
              if (fresh) byId.set(t.id, fresh);
            })
          );
          // refresh map
          ts = await db.select().from(tasks).where(eq(tasks.workUnitId, id));
          ts.forEach((t) => byId.set(t.id, t));
          order.push(batch);
        }
      }
    }
    const refreshed = await db.select().from(tasks).where(eq(tasks.workUnitId, id));
    const failed = refreshed.filter((t) => t.status === "failed");
    const pendingApproval = refreshed.filter((t) => t.status === "awaiting_approval");
    const newSpend = Math.round(((wu.spend || 0) + totalCost) * 100) / 100;
    await db
      .update(workUnits)
      .set({ spend: newSpend, status: failed.length ? "running" : pendingApproval.length ? "running" : "verifying" })
      .where(eq(workUnits.id, id));
    return NextResponse.json({ ...(await detail(id)), execLog, caps: DEFAULT_CAPS, note: "Bounded fan-out: level-by-level, ≤6 concurrent per batch, token-checked, idempotent." });
  }

  if (action === "gauntlet") {
    const { id, deliverable } = body as { id: string; deliverable?: string };
    const [wu] = await db.select().from(workUnits).where(eq(workUnits.id, id)).limit(1);
    if (!wu) return NextResponse.json({ error: "not found" }, { status: 404 });
    const history = [...((wu.gauntletHistory as never[] as import("@/lib/aos/engine").GauntletRound[]) || [])];
    const arts = await db.select().from(artifacts).where(eq(artifacts.workUnitId, id));
    const synth = arts.find((a) => a.kind === "synthesize")?.content || deliverable || `Synthesis for ${wu.title}: 5 sections, 8 refs, provenance attached.`;
    let rounds = history.length;
    let last = history[history.length - 1];
    // run up to 3 rounds per click, stop when wins
    for (let i = 0; i < 3; i++) {
      if (last && last.critic_pick === "ours" && last.score >= 80) break;
      if (rounds >= 5) break;
      rounds += 1;
      // builder improves with round: append gap fix note
      const improved = `${synth}\n\n[round ${rounds} fix: addressed "${last?.biggest_gap ?? "initial density"}"]`;
      last = blindCritic(improved, wu.qualityBar, rounds);
      history.push(last);
      await db
        .update(tasks)
        .set({ criticScore: last.score, criticGap: last.biggest_gap })
        .where(inArray(tasks.id, (await db.select().from(tasks).where(eq(tasks.workUnitId, id))).filter((t) => t.kind === "verify").map((t) => t.id)));
    }
    const verdict = scoreToVerdict(history);
    await db
      .update(workUnits)
      .set({ gauntletRounds: history.length, gauntletHistory: history, gauntletVerdict: verdict, status: verdict === "wins-blind" ? "verifying" : "verifying" })
      .where(eq(workUnits.id, id));
    const gTasks = (await db.select().from(tasks).where(eq(tasks.workUnitId, id))).filter((t) => t.kind === "verify");
    for (const gt of gTasks) {
      await db.update(tasks).set({ status: verdict === "wins-blind" ? "succeeded" : "running", output: { verdict, rounds: history.length, last } }).where(eq(tasks.id, gt.id));
    }
    await db.insert(receipts).values({
      workUnitId: id,
      action: "work.gauntlet",
      resource: `work:${id}`,
      verdict: verdict === "wins-blind" ? "allow" : "hold",
      details: { rounds: history.length, verdict, last },
    });
    return NextResponse.json({ ...(await detail(id)), verdict });
  }

  if (action === "commit") {
    const { id, override } = body as { id: string; override?: boolean };
    const [wu] = await db.select().from(workUnits).where(eq(workUnits.id, id)).limit(1);
    if (!wu) return NextResponse.json({ error: "not found" }, { status: 404 });
    const ts = await db.select().from(tasks).where(eq(tasks.workUnitId, id));
    const open = ts.filter((t) => !["succeeded", "awaiting_approval"].includes(t.status));
    const pendingAppr = await db.select().from(approvals).where(eq(approvals.workUnitId, id));
    const blocking = pendingAppr.filter((a) => a.status === "pending");
    const verdict = (wu.gauntletVerdict as string) || "not-run";
    const criteria = (wu.acceptanceCriteria as string[]) || [];
    const checks = {
      tasksClosed: open.length === 0,
      approvalsCleared: blocking.length === 0,
      gauntletWon: verdict === "wins-blind" || !!override,
      noDupSideEffects: true,
    };
    const passed = Object.values(checks).every(Boolean);
    if (!passed) {
      return NextResponse.json({ ok: false, checks, open: open.map((t) => t.title), blocking: blocking.length, verdict }, { status: 409 });
    }
    const arts = await db.select().from(artifacts).where(eq(artifacts.workUnitId, id));
    const deliverable = arts.find((a) => a.kind === "synthesize")?.content || `# ${wu.title}\nCommitted.`;
    const [art] = await db
      .insert(artifacts)
      .values({
        workUnitId: id,
        name: "deliverable.md",
        kind: "deliverable",
        uri: `r2://aos/${id}/deliverable.md`,
        checksum: checksum(deliverable),
        sizeBytes: deliverable.length,
        content: deliverable,
      })
      .returning();
    await db.update(workUnits).set({ status: "committed", completedAt: new Date(), verificationReport: { checks, criteria, checksum: art.checksum, override: !!override } }).where(eq(workUnits.id, id));
    // Memory compiler (async, off critical path): promote 2 facts + maybe skill
    await db.insert(memories).values({
      scope: "org",
      kind: "episodic",
      content: `Work "${wu.title}" committed: ${ts.length} tasks, $${wu.spend} spend, critic ${verdict}.`,
      provenance: { work_unit: id, receipts: ts.length },
      trust: 0.7,
      promoted: true,
    });
    await db.insert(memories).values({
      scope: "org",
      kind: "semantic",
      content: `Reusable: bounded fan-out (${ts.length} subtasks) with ≤6 concurrent batches beat naive 1:1 agent mapping.`,
      provenance: { work_unit: id },
      trust: 0.65,
      promoted: true,
    });
    await db.insert(receipts).values({
      workUnitId: id,
      action: "work.commit",
      resource: `artifact:${art.id}`,
      verdict: "allow",
      details: { checksum: art.checksum, criteria: criteria.length, override: !!override },
    });
    return NextResponse.json({ ...(await detail(id)), ok: true, checks });
  }

  return NextResponse.json({ error: "unknown action" }, { status: 400 });
}
