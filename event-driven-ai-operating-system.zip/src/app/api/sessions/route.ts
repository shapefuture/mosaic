import { NextResponse } from "next/server";
import { db } from "@/db";
import { sessions, agents, receipts } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const agentId = url.searchParams.get("agentId");
  const list = agentId
    ? await db.select().from(sessions).where(eq(sessions.agentId, agentId)).orderBy(desc(sessions.updatedAt))
    : await db.select().from(sessions).orderBy(desc(sessions.updatedAt)).limit(100);
  return NextResponse.json({ sessions: list });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { agentId, name } = body as { agentId: string; name?: string };
  const [a] = await db.select().from(agents).where(eq(agents.id, agentId)).limit(1);
  if (!a) return NextResponse.json({ error: "agent not found" }, { status: 404 });
  const [s] = await db
    .insert(sessions)
    .values({ agentId, name: name || `${a.name}-s${Date.now().toString(36)}`, state: "hibernating", transcript: [], inbox: [] })
    .returning();
  await db.insert(receipts).values({
    agentId,
    action: "session.create",
    resource: `session:${s.id}`,
    verdict: "allow",
    details: { note: "One DO per active conversation; same agent may hold many concurrent sessions." },
  });
  return NextResponse.json({ session: s });
}

export async function PATCH(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { id, op, message } = body as { id: string; op: string; message?: string };
  const [s] = await db.select().from(sessions).where(eq(sessions.id, id)).limit(1);
  if (!s) return NextResponse.json({ error: "not found" }, { status: 404 });

  if (op === "wake") {
    const snap = (() => {
      try {
        return JSON.parse(s.sqliteSnapshot || "{}");
      } catch {
        return {};
      }
    })();
    await db
      .update(sessions)
      .set({ state: "active", wakeCount: (s.wakeCount || 0) + 1, updatedAt: new Date() })
      .where(eq(sessions.id, id));
    return NextResponse.json({ ok: true, restored: { transcript: (s.transcript as unknown[]).length, snapKeys: Object.keys(snap) } });
  }
  if (op === "hibernate") {
    const snap = JSON.stringify({
      transcript_len: (s.transcript as unknown[]).length,
      inbox_len: (s.inbox as unknown[]).length,
      saved_at: new Date().toISOString(),
    });
    await db.update(sessions).set({ state: "hibernating", sqliteSnapshot: snap, updatedAt: new Date() }).where(eq(sessions.id, id));
    await db.insert(receipts).values({
      agentId: s.agentId,
      action: "session.hibernate",
      resource: `session:${id}`,
      verdict: "allow",
      details: { snap },
    });
    return NextResponse.json({ ok: true, snapshot: snap });
  }
  if (op === "message") {
    const transcript = [...((s.transcript as { role: string; text: string; at: string }[]) || [])];
    transcript.push({ role: "user", text: String(message || "").slice(0, 2000), at: new Date().toISOString() });
    // Deterministic Pi-harness-style turn: no model call for echoable intents; compact reply
    const lower = String(message || "").toLowerCase();
    let reply = `Resumed with compact context (${transcript.length} turns). `;
    if (lower.includes("browser")) reply += "Browser identity ready: pooled Chromium context, 0 new processes. Say 'open <domain>' to add a tab.";
    else if (lower.includes("plan") || lower.includes("research")) reply += "I can file this as a Work Unit: plan → fan-out → verify → commit. Use Command Deck → New Work Unit.";
    else if (lower.includes("approv") || lower.includes("login") || lower.includes("mfa")) reply += "That needs a human gate. I'll park the workflow (no worker held) and mint a Live View handoff if it's a browser login.";
    else reply += "Inbox noted. Assign me a task from the Work Engine and I'll wake, execute, commit, and hibernate.";
    transcript.push({ role: "agent", text: reply, at: new Date().toISOString() });
    await db
      .update(sessions)
      .set({ transcript: transcript.slice(-40), state: "active", updatedAt: new Date() })
      .where(eq(sessions.id, id));
    await db.insert(receipts).values({
      agentId: s.agentId,
      action: "session.turn",
      resource: `session:${id}`,
      verdict: "allow",
      details: { turns: transcript.length },
    });
    const [updated] = await db.select().from(sessions).where(eq(sessions.id, id)).limit(1);
    return NextResponse.json({ session: updated, reply });
  }
  return NextResponse.json({ error: "unknown op" }, { status: 400 });
}
