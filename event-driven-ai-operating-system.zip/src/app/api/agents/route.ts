import { NextResponse } from "next/server";
import { db } from "@/db";
import { agents, sessions, browserSessions, receipts } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { ensureSeed } from "@/lib/aos/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed();
  const list = await db.select().from(agents).orderBy(desc(agents.createdAt));
  const sess = await db.select().from(sessions);
  const brows = await db.select().from(browserSessions);
  const enriched = list.map((a) => ({
    ...a,
    sessionCount: sess.filter((s) => s.agentId === a.id).length,
    activeSessions: sess.filter((s) => s.agentId === a.id && s.state === "active").length,
    browsers: brows.filter((b) => b.agentId === a.id).length,
  }));
  const activeMemKb = list
    .filter((a) => a.status === "active")
    .reduce((n, a) => n + (a.activeMemoryKb || 0), 0);
  return NextResponse.json({
    agents: enriched,
    footprint: {
      logical: list.length,
      active: list.filter((a) => a.status === "active").length,
      hibernating: list.filter((a) => a.status !== "active").length,
      activeMemKb,
      idleCost: "storage only (~KB in Postgres, 0 workers)",
    },
  });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const name = String(body.name || `agent-${Date.now().toString(36)}`);
  const role = String(body.role || "Specialist");
  const capabilities: string[] = Array.isArray(body.capabilities) ? body.capabilities : ["http.get", "extract"];
  const budget = Number(body.budget ?? 10);
  const [row] = await db
    .insert(agents)
    .values({
      name,
      role,
      capabilities,
      modelPolicy: body.modelPolicy ?? { ladder: "task-routed", gateway: "ai-gateway" },
      skills: body.skills ?? [],
      budget,
      status: "hibernating",
    })
    .returning();
  // every logical agent gets one hibernating session + one hibernating browser identity (no process)
  const [sess] = await db
    .insert(sessions)
    .values({ agentId: row.id, name: `${name}-main`, state: "hibernating", transcript: [], inbox: [] })
    .returning();
  await db.insert(browserSessions).values({
    agentId: row.id,
    sessionId: sess.id,
    status: "hibernating",
    tabs: [],
    domainAllowlist: ["approved.example"],
    memoryMb: 0,
  });
  await db.insert(receipts).values({
    agentId: row.id,
    action: "agent.register",
    resource: `agent:${name}`,
    verdict: "allow",
    details: { role, capabilities, note: "Identity stored; zero workers allocated." },
  });
  return NextResponse.json({ agent: row, session: sess });
}

export async function PATCH(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { id, op } = body as { id: string; op: "wake" | "hibernate" };
  const [a] = await db.select().from(agents).where(eq(agents.id, id)).limit(1);
  if (!a) return NextResponse.json({ error: "not found" }, { status: 404 });
  if (op === "wake") {
    await db
      .update(agents)
      .set({ status: "active", lastWakeAt: new Date(), wakeCount: (a.wakeCount || 0) + 1, activeMemoryKb: 4200 })
      .where(eq(agents.id, id));
    // wake one session (load context package only, not full memory)
    const sess = await db.select().from(sessions).where(eq(sessions.agentId, id)).limit(1);
    if (sess[0]) {
      await db
        .update(sessions)
        .set({ state: "active", wakeCount: (sess[0].wakeCount || 0) + 1, updatedAt: new Date() })
        .where(eq(sessions.id, sess[0].id));
    }
    await db.insert(receipts).values({
      agentId: id,
      action: "agent.wake",
      resource: `agent:${a.name}`,
      verdict: "allow",
      details: { context: "compact package: role + scoped memories + pending inbox", sqlite: "DO SQLite resumed" },
    });
  } else {
    await db.update(agents).set({ status: "hibernating", activeMemoryKb: 0 }).where(eq(agents.id, id));
    await db.insert(receipts).values({
      agentId: id,
      action: "agent.hibernate",
      resource: `agent:${a.name}`,
      verdict: "allow",
      details: { note: "Worker released; identity + SQLite snapshot retained." },
    });
  }
  const [updated] = await db.select().from(agents).where(eq(agents.id, id)).limit(1);
  return NextResponse.json({ agent: updated });
}
