import { NextResponse } from "next/server";
import { db } from "@/db";
import { browserSessions, agents, receipts } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import crypto from "crypto";

export const dynamic = "force-dynamic";

export async function GET() {
  const list = await db.select().from(browserSessions).orderBy(desc(browserSessions.lastUsed)).limit(50);
  const ags = await db.select().from(agents);
  const enriched = list.map((b) => ({
    ...b,
    agentName: ags.find((a) => a.id === b.agentId)?.name ?? "?",
    tabsCount: ((b.tabs as unknown[]) || []).length,
  }));
  return NextResponse.json({
    browsers: enriched,
    pool: {
      processes: Math.max(1, Math.ceil(list.length / 4)),
      note: "Pool processes, isolate contexts: ≤4 contexts per Chromium process; tabs capped; unhealthy browsers recycled.",
    },
  });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { action } = body as { action: string };

  if (action === "open") {
    const { agentId, url } = body as { agentId: string; url: string };
    const [b] = await db.select().from(browserSessions).where(eq(browserSessions.agentId, agentId)).limit(1);
    if (!b) return NextResponse.json({ error: "no browser identity" }, { status: 404 });
    const allow = ((b.domainAllowlist as string[]) || []);
    let host = "";
    try {
      host = new URL(url).hostname;
    } catch {
      host = url;
    }
    const inAllow = allow.length === 0 || allow.some((d) => host.includes(d) || d === "*");
    // auto-extend allowlist for demo but log it (scoped grant)
    const tabs = [...((b.tabs as { url: string; title: string; open: boolean }[]) || [])];
    if (tabs.filter((t) => t.open).length >= 6) {
      return NextResponse.json({ error: "tab cap reached (6); close a tab or recycle browser" }, { status: 409 });
    }
    tabs.push({ url, title: host, open: true });
    await db
      .update(browserSessions)
      .set({ tabs, status: "alive", memoryMb: 180 + tabs.length * 60, lastUsed: new Date(), domainAllowlist: inAllow ? allow : [...allow, host] })
      .where(eq(browserSessions.id, b.id));
    await db.insert(receipts).values({
      agentId,
      action: "browser.open",
      resource: host,
      verdict: inAllow ? "allow" : "allow-scoped-grant",
      details: { url, context: "isolated per-agent context", tier: "pooled Chromium (no new VM)" },
    });
    const [u] = await db.select().from(browserSessions).where(eq(browserSessions.id, b.id)).limit(1);
    return NextResponse.json({ browser: u });
  }

  if (action === "close-tab") {
    const { id, url } = body as { id: string; url: string };
    const [b] = await db.select().from(browserSessions).where(eq(browserSessions.id, id)).limit(1);
    if (!b) return NextResponse.json({ error: "not found" }, { status: 404 });
    const tabs = ((b.tabs as { url: string; title: string; open: boolean }[]) || []).filter((t) => t.url !== url);
    await db.update(browserSessions).set({ tabs, lastUsed: new Date(), memoryMb: Math.max(0, 180 + tabs.length * 60) }).where(eq(browserSessions.id, id));
    return NextResponse.json({ ok: true });
  }

  if (action === "hibernate" || action === "recycle") {
    const { id } = body as { id: string };
    await db.update(browserSessions).set({ status: action === "hibernate" ? "hibernating" : "alive", memoryMb: action === "hibernate" ? 0 : 180, lastUsed: new Date() }).where(eq(browserSessions.id, id));
    await db.insert(receipts).values({
      action: `browser.${action}`,
      resource: id,
      verdict: "allow",
      details: { note: action === "hibernate" ? "Cookies/session persisted; process released." : "Unhealthy process replaced; contexts re-attached." },
    });
    return NextResponse.json({ ok: true });
  }

  if (action === "takeover") {
    const { id } = body as { id: string };
    const token = crypto.randomBytes(18).toString("hex");
    const url = `https://liveview.aos.local/b/${id.slice(0, 8)}?t=${token}`;
    await db
      .update(browserSessions)
      .set({ liveViewUrl: url, liveViewExpires: new Date(Date.now() + 15 * 60 * 1000), status: "alive", lastUsed: new Date() })
      .where(eq(browserSessions.id, id));
    await db.insert(receipts).values({
      action: "browser.liveview",
      resource: id,
      verdict: "allow",
      details: { warning: "Bearer credential: human-only, never to model, 15-min expiry", url_hash: crypto.createHash("sha256").update(url).digest("hex").slice(0, 12) },
    });
    return NextResponse.json({ liveViewUrl: url, expiresIn: "15m", warning: "Bearer credential — authenticated human only. Never paste into model context." });
  }

  return NextResponse.json({ error: "unknown action" }, { status: 400 });
}
