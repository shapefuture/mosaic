import { NextResponse } from "next/server";
import { db } from "@/db";
import { approvals, receipts, tasks } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const appr = await db.select().from(approvals).orderBy(desc(approvals.createdAt)).limit(50);
  const rcts = await db.select().from(receipts).orderBy(desc(receipts.createdAt)).limit(120);
  return NextResponse.json({ approvals: appr, receipts: rcts });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { action } = body as { action: string };
  if (action === "decide") {
    const { id, verdict } = body as { id: string; verdict: "approved" | "rejected" };
    const [a] = await db.select().from(approvals).where(eq(approvals.id, id)).limit(1);
    if (!a) return NextResponse.json({ error: "not found" }, { status: 404 });
    await db.update(approvals).set({ status: verdict, decidedAt: new Date() }).where(eq(approvals.id, id));
    if (a.taskId) {
      await db
        .update(tasks)
        .set({ status: verdict === "approved" ? "succeeded" : "cancelled", finishedAt: new Date(), output: { human: verdict } })
        .where(eq(tasks.id, a.taskId));
    }
    await db.insert(receipts).values({
      workUnitId: a.workUnitId,
      taskId: a.taskId,
      action: `approval.${verdict}`,
      resource: a.title,
      verdict: verdict === "approved" ? "allow" : "deny",
      details: { approver: "human-operator", policy: "v12", invariant: "no child exceeds parent authority" },
    });
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ error: "unknown action" }, { status: 400 });
}
