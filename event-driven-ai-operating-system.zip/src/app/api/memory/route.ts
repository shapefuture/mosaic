import { NextResponse } from "next/server";
import { db } from "@/db";
import { memories, skills, receipts } from "@/db/schema";
import { eq, desc, ilike, or } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const q = url.searchParams.get("q") || "";
  const mems = q
    ? await db
        .select()
        .from(memories)
        .where(or(ilike(memories.content, `%${q}%`), ilike(memories.kind, `%${q}%`)))
        .orderBy(desc(memories.createdAt))
        .limit(100)
    : await db.select().from(memories).orderBy(desc(memories.createdAt)).limit(100);
  const sk = await db.select().from(skills).orderBy(desc(skills.createdAt)).limit(50);
  const byKind = {
    personal: mems.filter((m) => m.kind === "personal").length,
    episodic: mems.filter((m) => m.kind === "episodic").length,
    semantic: mems.filter((m) => m.kind === "semantic").length,
    procedural: mems.filter((m) => m.kind === "procedural").length,
  };
  return NextResponse.json({ memories: mems, skills: sk, byKind, storage: "PostgreSQL + pgvector-sim (lexical) — no separate vector DB" });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { action } = body as { action: string };
  if (action === "add") {
    const [m] = await db
      .insert(memories)
      .values({
        agentId: body.agentId || null,
        scope: body.scope || "org",
        kind: body.kind || "semantic",
        content: String(body.content || "").slice(0, 2000),
        provenance: body.provenance ?? { from: "operator" },
        trust: Number(body.trust ?? 0.5),
        promoted: false,
      })
      .returning();
    return NextResponse.json({ memory: m });
  }
  if (action === "promote" || action === "demote") {
    await db.update(memories).set({ promoted: action === "promote" }).where(eq(memories.id, body.id));
    await db.insert(receipts).values({
      action: `memory.${action}`,
      resource: `memory:${body.id}`,
      verdict: "allow",
      details: { note: "Compiler gate: dedupe→scope→validate→promote; contradictory info validated." },
    });
    return NextResponse.json({ ok: true });
  }
  if (action === "compile") {
    // background compiler demo: extract candidates from unpromoted, promote top-2
    const all = await db.select().from(memories).orderBy(desc(memories.createdAt)).limit(50);
    const candidates = all.filter((m) => !m.promoted).slice(0, 3);
    for (const c of candidates.slice(0, 2)) {
      await db.update(memories).set({ promoted: true, trust: Math.min(0.95, (c.trust || 0.5) + 0.15) }).where(eq(memories.id, c.id));
    }
    let skill = null;
    if (candidates.length >= 2) {
      const [s] = await db
        .insert(skills)
        .values({
          name: `skill-${Date.now().toString(36)}`,
          description: "Auto-forged after repeated successful work; tests required before stable.",
          codePackage: "candidate procedure package",
          testReport: { tests: "pending 4-case suite" },
          status: "candidate",
          version: "v1",
        })
        .returning();
      skill = s;
    }
    await db.insert(receipts).values({
      action: "memory.compile",
      resource: "compiler:background",
      verdict: "allow",
      details: { candidates: candidates.length, promoted: Math.min(2, candidates.length), skill: skill?.name ?? "none", async: true },
    });
    return NextResponse.json({ ok: true, candidates: candidates.length, skill });
  }
  if (action === "skill-status") {
    await db.update(skills).set({ status: body.status }).where(eq(skills.id, body.id));
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ error: "unknown action" }, { status: 400 });
}
