import {
  integer,
  jsonb,
  numeric,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

/**
 * AOS v3 — control plane schema.
 *
 * The core architectural claim: an agent is an identity, not a process.
 * `agents` is authoritative (PostgreSQL). `sessions` is a derived, hibernating
 * cohort whose live state is computed, not stored per tick (no write
 * amplification). `work_units` + `tasks` + `task_edges` are the durable task
 * graph. Everything else is evidence: receipts, events, memory provenance.
 */

export const agents = pgTable("aos_agents", {
  id: varchar("id", { length: 64 }).primaryKey(),
  organization: varchar("organization", { length: 96 }).notNull(),
  role: varchar("role", { length: 96 }).notNull(),
  department: varchar("department", { length: 64 }).notNull(),
  capabilities: jsonb("capabilities").$type<string[]>().notNull().default([]),
  modelPolicy: varchar("model_policy", { length: 64 }).notNull(),
  memoryScope: varchar("memory_scope", { length: 64 }).notNull(),
  authorityPolicy: varchar("authority_policy", { length: 64 }).notNull(),
  skills: jsonb("skills").$type<string[]>().notNull().default([]),
  budgetUsd: numeric("budget_usd", { precision: 10, scale: 2 }).notNull(),
  spentUsd: numeric("spent_usd", { precision: 10, scale: 2 }).notNull().default("0"),
  turnsCompleted: integer("turns_completed").notNull().default(0),
  status: varchar("status", { length: 24 }).notNull().default("idle"),
});

export const sessions = pgTable(
  "aos_sessions",
  {
    id: varchar("id", { length: 16 }).primaryKey(),
    logicalIndex: integer("logical_index").notNull(),
    agentId: varchar("agent_id", { length: 64 }).notNull(),
    /** 0..1 phase offset, drives the derived wake wave */
    phase: real("phase").notNull(),
    turns: integer("turns").notNull().default(0),
    transcriptTokens: integer("transcript_tokens").notNull().default(0),
    lastWakeTick: integer("last_wake_tick").notNull().default(0),
    origin: varchar("origin", { length: 32 }).notNull().default("durable-object"),
  },
  (t) => [uniqueIndex("aos_sessions_idx").on(t.logicalIndex)],
);

export const workUnits = pgTable("aos_work_units", {
  id: varchar("id", { length: 32 }).primaryKey(),
  title: varchar("title", { length: 160 }).notNull(),
  objective: text("objective").notNull(),
  status: varchar("status", { length: 24 }).notNull().default("executing"),
  ownerId: varchar("owner_id", { length: 64 }).notNull(),
  budgetUsd: numeric("budget_usd", { precision: 10, scale: 2 }).notNull(),
  spentUsd: numeric("spent_usd", { precision: 10, scale: 2 }).notNull().default("0"),
  acceptance: jsonb("acceptance").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const tasks = pgTable("aos_tasks", {
  id: varchar("id", { length: 32 }).primaryKey(),
  workUnitId: varchar("work_unit_id", { length: 32 }).notNull(),
  seq: integer("seq").notNull(),
  /** DAG column used for layout: 0 = plan, 1 = fan-out, 2 = reduce, 3 = verify/commit */
  layer: integer("layer").notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  kind: varchar("kind", { length: 24 }).notNull(),
  tier: integer("tier").notNull().default(0),
  queueName: varchar("queue_name", { length: 24 }).notNull(),
  status: varchar("status", { length: 24 }).notNull().default("ready"),
  agentId: varchar("agent_id", { length: 64 }).notNull(),
  estMs: integer("est_ms").notNull().default(1200),
  costUsd: numeric("cost_usd", { precision: 10, scale: 4 }).notNull().default("0"),
  outputSummary: text("output_summary"),
  receipt: jsonb("receipt").$type<{ action: string; target: string; hash: string; idempotent: boolean } | null>(),
  startedAt: timestamp("started_at"),
  finishedAt: timestamp("finished_at"),
});

export const taskEdges = pgTable(
  "aos_task_edges",
  {
    fromId: varchar("from_id", { length: 32 }).notNull(),
    toId: varchar("to_id", { length: 32 }).notNull(),
  },
  (t) => [uniqueIndex("aos_edge_uq").on(t.fromId, t.toId)],
);

export const events = pgTable("aos_events", {
  id: serial("id").primaryKey(),
  tick: integer("tick").notNull(),
  kind: varchar("kind", { length: 32 }).notNull(),
  severity: varchar("severity", { length: 12 }).notNull().default("info"),
  workUnitId: varchar("work_unit_id", { length: 32 }),
  taskId: varchar("task_id", { length: 32 }),
  agentId: varchar("agent_id", { length: 64 }),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const memoryRecords = pgTable("aos_memory_records", {
  id: serial("id").primaryKey(),
  kind: varchar("kind", { length: 16 }).notNull(),
  scope: varchar("scope", { length: 64 }).notNull(),
  content: text("content").notNull(),
  provenance: varchar("provenance", { length: 128 }).notNull(),
  trust: real("trust").notNull().default(0.5),
  promoted: integer("promoted").notNull().default(0),
  sourceTaskId: varchar("source_task_id", { length: 32 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const authorityTokens = pgTable("aos_authority_tokens", {
  id: varchar("id", { length: 32 }).primaryKey(),
  agentId: varchar("agent_id", { length: 64 }).notNull(),
  workUnitId: varchar("work_unit_id", { length: 32 }).notNull(),
  actions: jsonb("actions").$type<string[]>().notNull().default([]),
  resources: jsonb("resources").$type<string[]>().notNull().default([]),
  domains: jsonb("domains").$type<string[]>().notNull().default([]),
  maxCostUsd: real("max_cost_usd").notNull(),
  delegationDepth: integer("delegation_depth").notNull().default(1),
  policyVersion: varchar("policy_version", { length: 16 }).notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  status: varchar("status", { length: 16 }).notNull().default("active"),
});

export const approvals = pgTable("aos_approvals", {
  id: varchar("id", { length: 32 }).primaryKey(),
  workUnitId: varchar("work_unit_id", { length: 32 }).notNull(),
  taskId: varchar("task_id", { length: 32 }),
  title: varchar("title", { length: 160 }).notNull(),
  detail: text("detail").notNull(),
  requester: varchar("requester", { length: 64 }).notNull(),
  risk: varchar("risk", { length: 12 }).notNull(),
  status: varchar("status", { length: 16 }).notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

export const queueStats = pgTable("aos_queue_stats", {
  name: varchar("name", { length: 24 }).primaryKey(),
  label: varchar("label", { length: 64 }).notNull(),
  pending: integer("pending").notNull().default(0),
  running: integer("running").notNull().default(0),
  p95Ms: integer("p95_ms").notNull().default(0),
  allowed: integer("allowed").notNull().default(1),
  ceiling: integer("ceiling").notNull().default(1),
  binding: varchar("binding", { length: 24 }).notNull().default("C_queue"),
  workload: varchar("workload", { length: 96 }).notNull().default(""),
});

export const simTicks = pgTable("aos_sim_ticks", {
  id: serial("id").primaryKey(),
  tick: integer("tick").notNull(),
  awake: integer("awake").notNull(),
  hibernating: integer("hibernating").notNull(),
  residentMb: real("resident_mb").notNull(),
  turns: integer("turns").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
