import { db } from "@/db";
import { sql, eq, desc } from "drizzle-orm";
import {
  agents,
  approvals,
  authorityTokens,
  events,
  memoryRecords,
  queueStats,
  sessions,
  simTicks,
  taskEdges,
  tasks,
  workUnits,
} from "@/db/schema";

export const COHORT = 2048;
export const IDLE_FLOOR_MB = 3.4;
export const MB_PER_AWAKE = 0.199;
export const REGISTERED_IDENTITIES = 1842912;

/** Duty cycle of the wake wave — waves of work sweeping the cohort. */
export function dutyFor(tick: number): number {
  const v = 0.115 + 0.085 * Math.abs(Math.sin(tick * 0.11)) + 0.04 * Math.sin(tick * 0.29);
  return Math.min(0.46, Math.max(0.07, v));
}

/** Derived session state. Computed at read time: a tick costs zero session writes. */
function awakeSql(tick: number) {
  const duty = dutyFor(tick);
  return sql`((((sin(${sessions.logicalIndex} / 47.0 + ${tick} * 0.21) + 1) / 2) * 0.72 + ${sessions.phase} * 0.28) < ${duty})`;
}

export type QueueRow = typeof queueStats.$inferSelect;
export type TaskRow = typeof tasks.$inferSelect;
export type WorkUnitRow = typeof workUnits.$inferSelect;

export interface Snapshot {
  tick: number;
  duty: number;
  fleet: {
    identities: number;
    cohort: number;
    awake: number;
    hibernating: number;
    residentMb: number;
    idleFloorMb: number;
    turns: number;
    writesPerTick: number;
  };
  field: number[];
  queues: QueueRow[];
  tasks: TaskRow[];
  workUnits: WorkUnitRow[];
  edges: { fromId: string; toId: string }[];
  events: (typeof events.$inferSelect)[];
  memory: (typeof memoryRecords.$inferSelect)[];
  approvals: (typeof approvals.$inferSelect)[];
  tokens: (typeof authorityTokens.$inferSelect)[];
  agents: (typeof agents.$inferSelect)[];
  history: { tick: number; awake: number; hibernating: number; residentMb: number }[];
}

export async function latestTick(): Promise<number> {
  const rows = await db
    .select({ tick: simTicks.tick })
    .from(simTicks)
    .orderBy(desc(simTicks.tick))
    .limit(1);
  return rows[0]?.tick ?? 0;
}

export async function buildSnapshot(): Promise<Snapshot> {
  const tick = await latestTick();

  const counts = await db
    .select({
      awake: sql<number>`count(*) filter (where ${awakeSql(tick)})::int`,
      total: sql<number>`count(*)::int`,
    })
    .from(sessions);
  const awake = counts[0]?.awake ?? 0;
  const total = counts[0]?.total ?? COHORT;

  const turnsRow = await db
    .select({ n: sql<number>`coalesce(sum(${sessions.turns}),0)::int` })
    .from(sessions);

  const fieldRows = await db
    .select({ i: sessions.logicalIndex })
    .from(sessions)
    .where(awakeSql(tick))
    .orderBy(sessions.logicalIndex);

  const [queueRows, taskRows, wuRows, edgeRows, eventRows, memRows, apprRows, tokRows, agentRows, histRows] =
    await Promise.all([
      db.select().from(queueStats).orderBy(queueStats.name),
      db.select().from(tasks).orderBy(tasks.id),
      db.select().from(workUnits).orderBy(workUnits.id),
      db.select().from(taskEdges),
      db.select().from(events).orderBy(desc(events.id)).limit(9),
      db.select().from(memoryRecords).orderBy(desc(memoryRecords.id)),
      db.select().from(approvals).orderBy(approvals.id),
      db.select().from(authorityTokens).orderBy(authorityTokens.id),
      db.select().from(agents),
      db
        .select({
          tick: simTicks.tick,
          awake: simTicks.awake,
          hibernating: simTicks.hibernating,
          residentMb: simTicks.residentMb,
        })
        .from(simTicks)
        .orderBy(simTicks.tick),
    ]);

  return {
    tick,
    duty: dutyFor(tick),
    fleet: {
      identities: REGISTERED_IDENTITIES,
      cohort: total,
      awake,
      hibernating: total - awake,
      residentMb: +(IDLE_FLOOR_MB + awake * MB_PER_AWAKE).toFixed(1),
      idleFloorMb: IDLE_FLOOR_MB,
      turns: turnsRow[0]?.n ?? 0,
      writesPerTick: 6,
    },
    field: fieldRows.map((r) => r.i),
    queues: queueRows,
    tasks: taskRows,
    workUnits: wuRows,
    edges: edgeRows.map((e) => ({ fromId: e.fromId, toId: e.toId })),
    events: eventRows,
    memory: memRows,
    approvals: apprRows,
    tokens: tokRows,
    agents: agentRows,
    history: histRows,
  };
}

/* ------------------------------------------------------------------ */
/* Deterministic tick engine: real writes only at meaningful boundaries */
/* ------------------------------------------------------------------ */

const SUMMARY: Record<string, string[]> = {
  research: [
    "6 sources fetched via Tier 0 HTTP. 2 discarded: aggregator mirrors with no primary citation.",
    "Primary pricing page retrieved and archived to R2. Retrieval timestamp bound to receipt.",
    "Announcement sweep complete: 3 packaging changes since April 2026, all from vendor-owned pages.",
  ],
  extract: [
    "42 price cards extracted against schema. 4 needed the model; 38 parsed deterministically.",
    "Batch parsed with zero model calls. Currency normalised to EUR at retrieval-date rate.",
    "Clause set extracted; confidence recorded per document, none below 0.71.",
  ],
  analysis: [
    "Segment comparison complete. Two vendors diverge above 250 seats.",
    "Seat ladder folded into evidence store with per-row provenance.",
  ],
  browser: [
    "Authenticated portal session reused (cookie jar intact). 3 tabs, 1 context. Downloaded 2 files.",
    "Live View takeover completed by human; agent resumed on the same browser session.",
  ],
  reduce: [
    "Evidence store compacted: 118 → 74 records after dedupe. Content hashes recorded in PostgreSQL.",
  ],
  verify: [
    "Contradiction check: 1 claim downgraded to single-source, 2 held for human review.",
    "Verification PASS on 3 of 4 acceptance criteria. The fourth awaits a primary source.",
  ],
  synthesize: [
    "Executive synthesis drafted with claim-to-evidence map. Every number carries a receipt.",
  ],
  plan: ["Task graph re-planned: 4 subtasks merged, 1 dropped as unbounded fan-out."],
  commit: ["Deliverable committed to R2 · sha256 recorded · resources released."],
};

function pick<T>(arr: T[], n: number): T {
  return arr[n % arr.length];
}

export async function runTick(): Promise<Snapshot> {
  const tick = (await latestTick()) + 1;
  const now = new Date();

  // 1. Complete running tasks (deterministic cadence).
  const running = await db.select().from(tasks).where(eq(tasks.status, "running"));
  const completions = running.filter((_, i) => (tick + i) % 3 !== 0);

  for (const t of completions) {
    const started = t.startedAt?.getTime() ?? now.getTime();
    if (now.getTime() - started < 8000 && (tick + t.seq) % 2 === 0) continue;
    const summary = pick(SUMMARY[t.kind] ?? ["Task completed."], tick + t.seq);
    await db
      .update(tasks)
      .set({
        status: "done",
        finishedAt: now,
        outputSummary: summary,
        receipt: {
          action: t.kind === "browser" ? "browser.act" : t.kind === "extract" ? "doc.extract" : "http.get",
          target: `r2://evidence/${t.id.toLowerCase()}.json`,
          hash: Math.abs(hashCode(t.id + tick)).toString(16).padStart(8, "0").slice(0, 8),
          idempotent: true,
        },
      })
      .where(eq(tasks.id, t.id));
    await db.insert(events).values({
      tick,
      kind: "receipt.issued",
      severity: "info",
      workUnitId: t.workUnitId,
      taskId: t.id,
      agentId: t.agentId,
      message: `${t.id} committed · ${summary}`,
    });
    await db
      .update(agents)
      .set({ turnsCompleted: sql`${agents.turnsCompleted} + 1`, spentUsd: sql`${agents.spentUsd} + ${t.costUsd}` })
      .where(eq(agents.id, t.agentId));
  }

  // 2. Unblock dependents whose predecessors are all done.
  const allTasks = await db.select().from(tasks);
  const doneIds = new Set(allTasks.filter((t) => t.status === "done").map((t) => t.id));
  const edges = await db.select().from(taskEdges);
  const preds = new Map<string, string[]>();
  for (const e of edges) preds.set(e.toId, [...(preds.get(e.toId) ?? []), e.fromId]);

  const unlocked: TaskRow[] = [];
  for (const t of allTasks) {
    if (t.status !== "blocked") continue;
    const pre = preds.get(t.id) ?? [];
    if (pre.length === 0 || pre.every((p) => doneIds.has(p))) {
      await db.update(tasks).set({ status: "ready" }).where(eq(tasks.id, t.id));
      unlocked.push(t);
    }
  }
  if (unlocked.length) {
    await db.insert(events).values({
      tick,
      kind: "task.unblocked",
      severity: "info",
      workUnitId: unlocked[0].workUnitId,
      message: `${unlocked.length} dependenc${unlocked.length === 1 ? "y" : "ies"} satisfied · ${unlocked
        .map((t) => t.id)
        .join(", ")} released to the pool`,
    });
  }

  // 3. Dispatch ready work under bounded concurrency per queue.
  const ready = await db.select().from(tasks).where(eq(tasks.status, "ready"));
  const qs = await db.select().from(queueStats);
  const budget = new Map(qs.map((q) => [q.name, Math.max(1, Math.round(q.allowed / 10))]));
  let dispatched = 0;
  for (const t of ready) {
    const cap = budget.get(t.queueName) ?? 1;
    if (cap <= 0) continue;
    budget.set(t.queueName, cap - 1);
    await db
      .update(tasks)
      .set({ status: "running", startedAt: now, agentId: t.agentId })
      .where(eq(tasks.id, t.id));
    dispatched++;
    await db
      .update(agents)
      .set({ status: "executing" })
      .where(eq(agents.id, t.agentId));
    await db.insert(events).values({
      tick,
      kind: "session.wake",
      severity: "info",
      workUnitId: t.workUnitId,
      taskId: t.id,
      agentId: t.agentId,
      message: `${t.agentId} woken for ${t.id} · context package rebuilt from ${2 + (t.seq % 5)} record references · tier ${t.tier}`,
    });
    if (dispatched >= 6) break;
  }

  // 4. Refresh queue gauges from live task state.
  for (const q of qs) {
    const rows = allTasks.filter((t) => t.queueName === q.name);
    const run = rows.filter((t) => t.status === "running").length;
    const pend = rows.filter((t) => t.status === "ready" || t.status === "blocked").length;
    await db
      .update(queueStats)
      .set({
        running: run,
        pending: pend,
        p95Ms: Math.max(400, Math.round(q.p95Ms * 0.86 + (run + 1) * 1400 * 0.14)),
      })
      .where(eq(queueStats.name, q.name));
  }

  // 5. Record the tick. Session state is derived, not stored — 1 row per tick.
  const duty = dutyFor(tick);
  const awake = await db
    .select({ n: sql<number>`count(*) filter (where ${awakeSql(tick)})::int` })
    .from(sessions);
  const n = awake[0]?.n ?? 0;
  await db.insert(simTicks).values({
    tick,
    awake: n,
    hibernating: COHORT - n,
    residentMb: +(IDLE_FLOOR_MB + n * MB_PER_AWAKE).toFixed(1),
    turns: dispatched,
  });

  return buildSnapshot();
}

function hashCode(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h << 5) - h + s.charCodeAt(i);
  return h | 0;
}

/* ---------------------------- actions ----------------------------- */

export async function resolveApproval(id: string, decision: "approved" | "rejected") {
  const row = (await db.select().from(approvals).where(eq(approvals.id, id)))[0];
  if (!row) return { ok: false as const };
  await db
    .update(approvals)
    .set({ status: decision, resolvedAt: new Date() })
    .where(eq(approvals.id, id));

  if (decision === "approved" && row.taskId) {
    await db.update(tasks).set({ status: "ready" }).where(eq(tasks.id, row.taskId));
    await db.insert(events).values({
      tick: await latestTick(),
      kind: "approval.granted",
      severity: "info",
      workUnitId: row.workUnitId,
      taskId: row.taskId,
      message: `${row.id} approved by human operator · ${row.taskId} released with a short-lived capability token (delegation depth 1)`,
    });
  } else {
    await db.insert(events).values({
      tick: await latestTick(),
      kind: "approval.denied",
      severity: "warn",
      workUnitId: row.workUnitId,
      taskId: row.taskId,
      message: `${row.id} denied by human operator · side effect suppressed, task held at the authority boundary`,
    });
  }
  return { ok: true as const };
}

export async function compileMemory() {
  // 1. Extract candidate facts from recently completed work (background workflow).
  const recent = await db
    .select()
    .from(tasks)
    .where(eq(tasks.status, "done"))
    .orderBy(desc(tasks.seq));
  const source = recent.find((t) => t.outputSummary && t.receipt);
  const already = source
    ? await db.select({ id: memoryRecords.id }).from(memoryRecords).where(eq(memoryRecords.sourceTaskId, source.id))
    : [];
  if (source?.outputSummary && already.length === 0) {
    await db.insert(memoryRecords).values({
      kind: "episodic",
      scope: "project:market-intelligence",
      content: `Derived from ${source.id}: ${source.outputSummary}`,
      provenance: `${source.id} · receipt ${source.receipt?.hash ?? "—"} · one run, needs corroboration`,
      trust: 0.64,
      promoted: 0,
      sourceTaskId: source.id,
    });
  }

  // 2. Dedupe against curated memory, score scope and trust, promote what survives.
  const candidates = await db
    .select()
    .from(memoryRecords)
    .where(eq(memoryRecords.promoted, 0));
  const survivors = candidates.filter((c) => c.trust >= 0.6);
  for (const c of survivors) {
    await db.update(memoryRecords).set({ promoted: 1 }).where(eq(memoryRecords.id, c.id));
  }
  await db.insert(events).values({
    tick: await latestTick(),
    kind: "memory.compiled",
    severity: "info",
    agentId: "memory-compiler-01",
    message: `Memory compiler run: ${candidates.length} candidates · ${survivors.length} promoted to curated memory · ${
      candidates.length - survivors.length
    } held below the trust threshold · 0 model calls on the critical path`,
  });
  return { candidates: candidates.length, promoted: survivors.length };
}

const FANOUT_TEMPLATES: { title: string; kind: string; tier: number; queueName: string; agentId: string; estMs: number; cost: string }[] = [
  { title: "Re-check primary pricing sources for changed packaging", kind: "research", tier: 0, queueName: "io", agentId: "research-analyst-01", estMs: 18000, cost: "0.6200" },
  { title: "Extract discount ladders from cached source snapshots", kind: "extract", tier: 0, queueName: "io", agentId: "pricing-extraction-01", estMs: 24000, cost: "0.8800" },
  { title: "Diff this teardown against the previous quarter's register", kind: "analysis", tier: 1, queueName: "compute", agentId: "evidence-curator-01", estMs: 12000, cost: "0.1400" },
];

export async function fanOut(workUnitId: string) {
  const wu = (await db.select().from(workUnits).where(eq(workUnits.id, workUnitId)))[0];
  if (!wu) return { ok: false as const };
  const existing = await db.select().from(tasks).where(eq(tasks.workUnitId, workUnitId));
  const base = existing.length;
  const now = new Date();
  const created = FANOUT_TEMPLATES.map((tpl, i) => ({
    id: `${workUnitId}-F${base + i + 1}`,
    workUnitId,
    seq: base + i + 1,
    layer: 1,
    title: tpl.title,
    kind: tpl.kind,
    tier: tpl.tier,
    queueName: tpl.queueName,
    status: "ready",
    agentId: tpl.agentId,
    estMs: tpl.estMs,
    costUsd: tpl.cost,
    startedAt: now,
  }));
  await db.insert(tasks).values(created);
  const planTask = existing.find((t) => t.kind === "plan");
  if (planTask) {
    await db.insert(taskEdges).values(created.map((c) => ({ fromId: planTask.id, toId: c.id })));
  }
  await db.insert(events).values({
    tick: await latestTick(),
    kind: "task.fanned-out",
    severity: "info",
    workUnitId,
    message: `Bounded fan-out: ${created.length} independent subtasks dispatched · C_allowed = min(C_provider, C_tenant, C_queue, C_sandbox, C_budget) enforced at 4`,
  });
  return { ok: true as const, created: created.length };
}


