import { buildSnapshot } from "@/lib/aos";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await buildSnapshot();
  return Response.json(snapshot);
}
