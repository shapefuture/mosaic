import { buildSnapshot, compileMemory } from "@/lib/aos";

export const dynamic = "force-dynamic";

export async function POST() {
  const result = await compileMemory();
  return Response.json({ ...(await buildSnapshot()), compiler: result });
}
