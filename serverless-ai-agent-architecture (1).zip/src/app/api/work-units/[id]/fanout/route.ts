import { buildSnapshot, fanOut } from "@/lib/aos";

export const dynamic = "force-dynamic";

export async function POST(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const result = await fanOut(id);
  return Response.json({ ...(await buildSnapshot()), fanout: result });
}
