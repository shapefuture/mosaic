import { runTick } from "@/lib/aos";

export const dynamic = "force-dynamic";

export async function POST() {
  const snapshot = await runTick();
  return Response.json(snapshot);
}
