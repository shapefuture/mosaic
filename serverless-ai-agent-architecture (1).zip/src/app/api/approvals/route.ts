import { buildSnapshot, resolveApproval } from "@/lib/aos";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = (await req.json()) as { id?: string; decision?: string };
  if (!body.id || (body.decision !== "approved" && body.decision !== "rejected")) {
    return Response.json({ ok: false, error: "id and decision required" }, { status: 400 });
  }
  await resolveApproval(body.id, body.decision);
  return Response.json(await buildSnapshot());
}
