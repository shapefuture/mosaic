import Console from "@/components/Console";
import { buildSnapshot } from "@/lib/aos";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export default async function Page() {
  const snapshot = await buildSnapshot();
  return <Console initial={snapshot} />;
}
