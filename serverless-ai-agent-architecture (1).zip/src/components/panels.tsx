"use client";

import type { Snapshot } from "@/lib/aos";

const fmt = (n: number) => n.toLocaleString("en-US");

function when(d: string | Date | null | undefined) {
  if (!d) return "—";
  const dt = typeof d === "string" ? new Date(d) : d;
  return dt.toISOString().slice(11, 19) + "Z";
}

/* ---------------------------------------------------------------- */
/* § 02 — adaptive scheduler band                                    */
/* ---------------------------------------------------------------- */

export function TelemetryBand({ snap }: { snap: Snapshot }) {
  const hist = snap.history.slice(-48);
  const maxMb = Math.max(...hist.map((h) => h.residentMb), 60);
  const w = 320;
  const h = 86;
  const path = hist
    .map((p, i) => {
      const x = (i / Math.max(1, hist.length - 1)) * w;
      const y = h - (p.residentMb / maxMb) * h;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <div className="micro text-signal-soft">§ 02 / adaptive scheduler — live</div>
          <p className="mt-3 font-mono text-[clamp(12px,1.6vw,16px)] leading-[1.6] text-panel-ink">
            C<sub>allowed</sub> = min(C<sub>provider</sub>, C<sub>tenant</sub>, C<sub>queue</sub>, C
            <sub>sandbox</sub>, C<sub>budget</sub>)
          </p>
          <p className="mt-2 max-w-[52ch] text-[12.5px] leading-[1.7] text-panel-ink/60">
            Concurrency is calculated from the narrowest active constraint, never from a fixed worker count. A pathological
            browser task cannot spend capacity reserved for interactive conversation.
          </p>
        </div>
        <div className="min-w-[240px]">
          <div className="micro text-panel-ink/50">resident memory · last {hist.length} ticks</div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="display tnum text-[46px] font-semibold leading-none text-panel-ink">
              {snap.fleet.residentMb.toFixed(1)}
            </span>
            <span className="micro text-panel-ink/60">MB</span>
            <span className="micro text-signal-soft">idle floor {snap.fleet.idleFloorMb} MB</span>
          </div>
          <svg viewBox={`0 0 ${w} ${h}`} className="mt-2 h-[86px] w-full" preserveAspectRatio="none" aria-hidden="true">
            <path d={path} fill="none" stroke="#d4521b" strokeWidth={1.6} vectorEffect="non-scaling-stroke" />
            <path d={`${path} L${w},${h} L0,${h} Z`} fill="#d4521b" opacity={0.14} />
          </svg>
        </div>
      </div>

      <div className="mt-8 overflow-x-auto">
        <table className="w-full min-w-[720px] border-collapse text-left">
          <thead>
            <tr className="border-b border-panel-ink/25">
              <th className="micro py-2 pr-4 text-panel-ink/50">queue</th>
              <th className="micro py-2 pr-4 text-panel-ink/50">workload</th>
              <th className="micro py-2 pr-4 text-right text-panel-ink/50">pending</th>
              <th className="micro py-2 pr-4 text-right text-panel-ink/50">running</th>
              <th className="micro py-2 pr-4 text-right text-panel-ink/50">p95</th>
              <th className="micro py-2 pr-4 text-panel-ink/50">permitted concurrency</th>
              <th className="micro py-2 text-panel-ink/50">binding</th>
            </tr>
          </thead>
          <tbody>
            {snap.queues.map((q) => {
              const pct = Math.round((q.allowed / q.ceiling) * 100);
              return (
                <tr key={q.name} className="border-b border-panel-ink/12">
                  <td className="py-3 pr-4 text-[13px] font-medium text-panel-ink">{q.label}</td>
                  <td className="py-3 pr-4 font-mono text-[10.5px] uppercase tracking-[0.08em] text-panel-ink/55">
                    {q.workload}
                  </td>
                  <td className="tnum py-3 pr-4 text-right font-mono text-[12px] text-panel-ink/80">{fmt(q.pending)}</td>
                  <td className="tnum py-3 pr-4 text-right font-mono text-[12px] text-signal-soft">{fmt(q.running)}</td>
                  <td className="tnum py-3 pr-4 text-right font-mono text-[12px] text-panel-ink/80">
                    {(q.p95Ms / 1000).toFixed(1)}s
                  </td>
                  <td className="py-3 pr-4">
                    <div className="flex items-center gap-2">
                      <div className="h-[7px] w-[120px] bg-panel-ink/12">
                        <div className="h-full bg-signal transition-[width] duration-500" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="tnum font-mono text-[11px] text-panel-ink/70">
                        {q.allowed}/{q.ceiling}
                      </span>
                    </div>
                  </td>
                  <td className="py-3">
                    <span className="micro border border-signal/50 px-2 py-[3px] text-signal-soft">{q.binding}</span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* § 03 — work unit DAG                                              */
/* ---------------------------------------------------------------- */

const STATUS_STYLE: Record<string, { fill: string; stroke: string; text: string; dash: string }> = {
  done: { fill: "#e7dfd1", stroke: "#15191e", text: "#15191e", dash: "" },
  running: { fill: "#d4521b22", stroke: "#d4521b", text: "#15191e", dash: "" },
  ready: { fill: "#f2ede3", stroke: "#1c3e5f", text: "#15191e", dash: "5 3" },
  blocked: { fill: "#00000000", stroke: "#15191e44", text: "#55595f", dash: "3 3" },
  "awaiting-approval": { fill: "#d4521b12", stroke: "#d4521b", text: "#d4521b", dash: "4 3" },
};

export function WorkUnitDag({
  snap,
  workUnitId,
  selectedId,
  onSelect,
  onFanout,
  onTick,
  busy,
}: {
  snap: Snapshot;
  workUnitId: string;
  selectedId: string | null;
  onSelect: (id: string) => void;
  onFanout: (id: string) => void;
  onTick: () => void;
  busy: boolean;
}) {
  const wu = snap.workUnits.find((w) => w.id === workUnitId);
  const nodes = snap.tasks.filter((t) => t.workUnitId === workUnitId);
  const byLayer = new Map<number, typeof nodes>();
  for (const n of nodes) {
    const arr = byLayer.get(n.layer) ?? [];
    arr.push(n);
    byLayer.set(n.layer, arr);
  }
  const layers = [...byLayer.keys()].sort((a, b) => a - b);
  const rowH = 64;
  const nodeW = 200;
  const nodeH = 52;
  const colW = 236;
  const maxRows = Math.max(...layers.map((l) => byLayer.get(l)?.length ?? 1));
  const H = maxRows * rowH + 30;
  const W = 24 + layers.length * colW;

  const pos = new Map<string, { x: number; y: number }>();
  layers.forEach((l, li) => {
    const arr = byLayer.get(l) ?? [];
    const total = arr.length * rowH;
    arr.forEach((n, ni) => {
      pos.set(n.id, { x: 24 + li * colW, y: (H - total) / 2 + ni * rowH + rowH / 2 - nodeH / 2 });
    });
  });

  const selected = nodes.find((n) => n.id === selectedId) ?? nodes[0];

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          {snap.workUnits.map((w) => (
            <span
              key={w.id}
              className={`micro border px-2.5 py-[5px] ${
                w.id === workUnitId ? "border-ink bg-ink text-paper" : "border-ink/25 text-ink-soft"
              }`}
            >
              {w.id} · {w.title}
            </span>
          ))}
        </div>
        <div className="flex gap-2">
          <button className="btn btn-signal" onClick={() => onFanout(workUnitId)} disabled={busy}>
            fan out subtasks
          </button>
          <button className="btn" onClick={onTick} disabled={busy}>
            run tick
          </button>
        </div>
      </div>

      {wu ? (
        <div className="mt-5 border border-ink/25 bg-paper-2/50 p-5">
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <h3 className="display text-[22px] font-semibold">{wu.title}</h3>
            <div className="micro text-ink-soft">
              owner {wu.ownerId} · budget ${wu.budgetUsd} · spent ${wu.spentUsd} · status {wu.status}
            </div>
          </div>
          <p className="mt-3 max-w-[76ch] text-[13.5px] leading-[1.75] text-ink-soft">{wu.objective}</p>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            {wu.acceptance.map((a) => (
              <div key={a} className="flex gap-2 font-mono text-[10.5px] leading-[1.7] text-blueprint">
                <span className="text-signal">◇</span>
                <span>{a}</span>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      <div className="mt-5 overflow-x-auto border border-ink/20 bg-paper-2/30 p-3">
        <svg viewBox={`0 0 ${W} ${H}`} style={{ width: W, maxWidth: "100%", height: "auto" }} role="img" aria-label="Work Unit task graph">
          {snap.edges
            .filter((e) => pos.has(e.fromId) && pos.has(e.toId))
            .map((e) => {
              const a = pos.get(e.fromId)!;
              const b = pos.get(e.toId)!;
              const x1 = a.x + nodeW;
              const y1 = a.y + nodeH / 2;
              const x2 = b.x;
              const y2 = b.y + nodeH / 2;
              const mid = (x1 + x2) / 2;
              return (
                <path
                  key={`${e.fromId}-${e.toId}`}
                  d={`M${x1},${y1} C${mid},${y1} ${mid},${y2} ${x2},${y2}`}
                  fill="none"
                  stroke="#15191e"
                  strokeOpacity={0.32}
                  strokeWidth={1.2}
                  className="dash-draw"
                />
              );
            })}
          {nodes.map((n) => {
            const p = pos.get(n.id)!;
            const s = STATUS_STYLE[n.status] ?? STATUS_STYLE.blocked;
            const isSel = selected?.id === n.id;
            return (
              <g
                key={n.id}
                transform={`translate(${p.x},${p.y})`}
                onClick={() => onSelect(n.id)}
                style={{ cursor: "pointer" }}
                tabIndex={0}
                role="button"
                aria-label={n.title}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") onSelect(n.id);
                }}
              >
                <rect
                  width={nodeW}
                  height={nodeH}
                  rx={2}
                  fill={s.fill}
                  stroke={isSel ? "#d4521b" : s.stroke}
                  strokeWidth={isSel ? 2.4 : 1.2}
                  strokeDasharray={s.dash}
                />
                <text x={10} y={19} fontSize={9} fontFamily="IBM Plex Mono, monospace" letterSpacing="1.2" fill="#55595f">
                  {n.id} · T{n.tier} · {n.queueName.toUpperCase()}
                </text>
                <text x={10} y={35} fontSize={11.5} fontFamily="IBM Plex Sans, sans-serif" fill={s.text}>
                  {n.title.length > 30 ? n.title.slice(0, 29) + "…" : n.title}
                </text>
                <text x={10} y={47} fontSize={9} fontFamily="IBM Plex Mono, monospace" letterSpacing="1" fill={s.text} opacity={0.72}>
                  {n.status.toUpperCase()} · ${n.costUsd}
                </text>
                {n.status === "running" ? <circle cx={nodeW - 12} cy={12} r={3.5} fill="#d4521b" className="blink" /> : null}
              </g>
            );
          })}
        </svg>
      </div>

      {selected ? (
        <div className="mt-5 grid gap-6 border-t-2 border-ink pt-5 lg:grid-cols-[minmax(0,1fr)_260px]">
          <div>
            <div className="micro text-signal">
              task {selected.id} · layer {selected.layer} · {selected.kind}
            </div>
            <h4 className="display mt-2 text-[19px] font-semibold">{selected.title}</h4>
            <dl className="mt-4 grid grid-cols-2 gap-x-8 gap-y-2 sm:grid-cols-3">
              {[
                ["status", selected.status],
                ["assigned identity", selected.agentId],
                ["execution tier", `tier ${selected.tier}`],
                ["queue", selected.queueName],
                ["estimate", `${(selected.estMs / 1000).toFixed(1)}s`],
                ["cost", `$${selected.costUsd}`],
                ["started", when(selected.startedAt)],
                ["finished", when(selected.finishedAt)],
                ["idempotent", selected.receipt ? String(selected.receipt.idempotent) : "pending"],
              ].map(([k, v]) => (
                <div key={k}>
                  <dt className="micro text-ink-soft">{k}</dt>
                  <dd className="tnum mt-0.5 font-mono text-[11.5px] text-ink">{v}</dd>
                </div>
              ))}
            </dl>
            {selected.outputSummary ? (
              <p className="mt-4 max-w-[70ch] border-l-2 border-blueprint/40 pl-3 text-[13px] leading-[1.75] text-ink-soft">
                {selected.outputSummary}
              </p>
            ) : (
              <p className="mt-4 font-mono text-[11px] text-ink-soft">
                no output committed yet — the task is still inside its turn; nothing has been written to the authoritative store.
              </p>
            )}
          </div>
          <div className="bg-panel p-4 text-panel-ink">
            <div className="micro text-panel-ink/50">external-action receipt</div>
            {selected.receipt ? (
              <pre className="mt-3 overflow-x-auto font-mono text-[10.5px] leading-[1.85] text-panel-ink/90">
{`{
  "action": "${selected.receipt.action}",
  "target": "${selected.receipt.target}",
  "sha256": "${selected.receipt.hash}",
  "idempotent": ${selected.receipt.idempotent},
  "task": "${selected.id}",
  "tick": ${snap.tick}
}`}
              </pre>
            ) : (
              <p className="mt-3 font-mono text-[10.5px] leading-[1.8] text-panel-ink/55">
                none issued. A receipt is written only at a meaningful boundary: tool action authorized, external side effect
                attempted, result obtained.
              </p>
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* § 05 — memory compiler                                            */
/* ---------------------------------------------------------------- */

export function MemoryCompiler({
  snap,
  onCompile,
  busy,
  result,
}: {
  snap: Snapshot;
  onCompile: () => void;
  busy: boolean;
  result: string | null;
}) {
  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="micro text-ink-soft">
          {snap.memory.length} records · {snap.memory.filter((m) => m.promoted === 0).length} candidates held ·{" "}
          {snap.memory.filter((m) => m.promoted === 1).length} curated
        </div>
        <div className="flex items-center gap-3">
          {result ? <span className="micro text-signal">{result}</span> : null}
          <button className="btn btn-signal" onClick={onCompile} disabled={busy}>
            run memory compiler
          </button>
        </div>
      </div>

      <div className="mt-4 divide-y divide-ink/12 border-y border-ink/25">
        {snap.memory.map((m) => (
          <div key={m.id} className="grid grid-cols-[minmax(0,1fr)_128px] gap-5 py-3.5">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="micro border border-blueprint/40 px-1.5 py-[2px] text-blueprint">{m.kind}</span>
                <span className="micro text-ink-soft">{m.scope}</span>
                {m.promoted === 1 ? (
                  <span className="micro text-signal">◆ curated</span>
                ) : (
                  <span className="micro text-ink-soft">◇ candidate</span>
                )}
              </div>
              <p className="mt-1.5 max-w-[80ch] text-[13px] leading-[1.65]">{m.content}</p>
              <p className="mt-1 font-mono text-[10px] leading-[1.7] text-ink-soft">provenance: {m.provenance}</p>
            </div>
            <div>
              <div className="micro text-ink-soft">trust</div>
              <div className="mt-1 h-[6px] w-full bg-ink/12">
                <div
                  className={`h-full ${m.trust >= 0.6 ? "bg-signal" : "bg-ink/35"}`}
                  style={{ width: `${Math.round(m.trust * 100)}%` }}
                />
              </div>
              <div className="tnum mt-1 font-mono text-[11px]">{m.trust.toFixed(2)}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* § 06 — authority envelope                                         */
/* ---------------------------------------------------------------- */

function JsonBlock({ token }: { token: Snapshot["tokens"][number] }) {
  const raw = JSON.stringify(
    {
      agent_id: token.agentId,
      work_unit_id: token.workUnitId,
      actions: token.actions,
      resources: token.resources,
      domains: token.domains,
      max_cost: token.maxCostUsd,
      delegation_depth: token.delegationDepth,
      policy_version: token.policyVersion,
      token_id: token.id,
    },
    null,
    2,
  );
  return (
    <pre className="overflow-x-auto bg-panel p-5 font-mono text-[11px] leading-[1.9] text-panel-ink/90">
      {raw.split("\n").map((line, i) => {
        const m = line.match(/^(\s*)"([^"]+)":\s?(.*)$/);
        if (!m) return <div key={i}>{line}</div>;
        return (
          <div key={i}>
            <span>{m[1]}</span>
            <span className="text-[#7fa8cf]">&quot;{m[2]}&quot;</span>
            <span className="text-panel-ink/50">: </span>
            <span className="text-signal-soft">{m[3]}</span>
          </div>
        );
      })}
    </pre>
  );
}

export function AuthorityPanel({
  snap,
  onDecide,
  busy,
}: {
  snap: Snapshot;
  onDecide: (id: string, decision: "approved" | "rejected") => void;
  busy: boolean;
}) {
  const token = snap.tokens[0];
  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <div>
        <div className="micro text-ink-soft">
          live capability token · {snap.tokens.length} active · short-lived · signed · never returned to the model
        </div>
        {token ? <JsonBlock token={token} /> : null}
        <div className="mt-4 space-y-1.5">
          {[
            "The model never receives the underlying secret required to authorize an external action.",
            "A webpage, email or other untrusted input cannot change governing permissions.",
            "No child task may carry more authority than its parent.",
          ].map((t, i) => (
            <div key={t} className="flex gap-2.5 font-mono text-[11px] leading-[1.7] text-ink-soft">
              <span className="text-signal">{String(i + 1).padStart(2, "0")}</span>
              <span>{t}</span>
            </div>
          ))}
        </div>
      </div>

      <div>
        <div className="micro text-ink-soft">human approval centre — the agent requests, it does not authorize</div>
        <div className="mt-3 divide-y divide-ink/12 border-y border-ink/25">
          {snap.approvals.map((a) => (
            <div key={a.id} className="py-4">
              <div className="flex flex-wrap items-center gap-2">
                <span className="micro text-signal">{a.id}</span>
                <span
                  className={`micro px-1.5 py-[2px] ${
                    a.status === "pending"
                      ? "border border-signal/60 text-signal"
                      : a.status === "approved"
                        ? "border border-blueprint/50 text-blueprint"
                        : "border border-ink/30 text-ink-soft"
                  }`}
                >
                  {a.status}
                </span>
                <span className="micro text-ink-soft">risk {a.risk}</span>
                <span className="micro text-ink-soft">from {a.requester}</span>
              </div>
              <h4 className="mt-2 text-[13.5px] font-medium leading-[1.5]">{a.title}</h4>
              <p className="mt-1.5 max-w-[62ch] text-[12px] leading-[1.7] text-ink-soft">{a.detail}</p>
              {a.status === "pending" ? (
                <div className="mt-3 flex gap-2">
                  <button className="btn btn-signal" onClick={() => onDecide(a.id, "approved")} disabled={busy}>
                    approve
                  </button>
                  <button className="btn" onClick={() => onDecide(a.id, "rejected")} disabled={busy}>
                    deny
                  </button>
                </div>
              ) : (
                <p className="mt-2 font-mono text-[10px] uppercase tracking-[0.12em] text-ink-soft">
                  resolved {when(a.resolvedAt)} · decision recorded in the immutable action ledger
                </p>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
