"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Snapshot } from "@/lib/aos";
import { AuthorityPanel, MemoryCompiler, TelemetryBand, WorkUnitDag } from "@/components/panels";
import { MeasureSection, Note, Section, StackSection, TiersSection, fmt } from "@/components/static";

const SECTIONS: [string, string, string][] = [
  ["field", "01", "Hibernation field"],
  ["scheduler", "02", "Adaptive scheduler"],
  ["work", "03", "Universal work engine"],
  ["tiers", "04", "Execution tiers"],
  ["memory", "05", "Memory compiler"],
  ["authority", "06", "Authority envelope"],
  ["stack", "07", "Stack ledger"],
  ["measure", "08", "Measurement"],
];

/* ---------------------------------------------------------------- */

function HibernationField({ snap, reduced }: { snap: Snapshot; reduced: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const energy = useRef<Float32Array>(new Float32Array(2048));
  const awake = useRef<Set<number>>(new Set());
  const [hover, setHover] = useState<string | null>(null);

  useEffect(() => {
    awake.current = new Set(snap.field);
    if (reduced) {
      const e = energy.current;
      for (let i = 0; i < 2048; i++) e[i] = awake.current.has(i) ? 1 : 0;
    }
  }, [snap.field, reduced]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let w = 0;
    let h = 0;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = wrap.clientWidth;
      h = wrap.clientHeight;
      canvas.width = Math.max(1, Math.floor(w * dpr));
      canvas.height = Math.max(1, Math.floor(h * dpr));
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    const draw = () => {
      const cols = 64;
      const rows = 32;
      const cell = Math.min(w / cols, h / rows);
      const ox = (w - cell * cols) / 2;
      const oy = (h - cell * rows) / 2;
      const e = energy.current;

      ctx.clearRect(0, 0, w, h);
      for (let i = 0; i < 2048; i++) {
        const target = awake.current.has(i) ? 1 : 0;
        e[i] += (target - e[i]) * (reduced ? 1 : 0.13);
        const c = i % cols;
        const r = Math.floor(i / cols);
        const x = ox + c * cell + cell / 2;
        const y = oy + r * cell + cell / 2;
        const v = e[i];

        if (v < 0.02) {
          ctx.fillStyle = "#c9bda6";
          ctx.fillRect(x - 1, y - 1, 2, 2);
          continue;
        }
        const size = 2 + v * Math.min(cell * 0.62, 7);
        if (v > 0.45) {
          ctx.shadowColor = "rgba(212, 82, 27, 0.55)";
          ctx.shadowBlur = v * 11;
        } else {
          ctx.shadowBlur = 0;
        }
        ctx.fillStyle = `rgba(212, 82, 27, ${0.16 + v * 0.8})`;
        ctx.fillRect(x - size / 2, y - size / 2, size, size);
        ctx.shadowBlur = 0;
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [reduced]);

  return (
    <div>
      <div className="grid grid-cols-2 gap-x-8 gap-y-5 border-y border-ink/25 py-5 sm:grid-cols-3 lg:grid-cols-5">
        {[
          ["registered identities", fmt(snap.fleet.identities), "logical, not processes"],
          ["cohort rendered", fmt(snap.fleet.cohort), "session actors in this view"],
          ["awake now", fmt(snap.fleet.awake), "executing a turn"],
          ["hibernating", fmt(snap.fleet.hibernating), "0 MB working set"],
          ["resident", `${snap.fleet.residentMb.toFixed(1)} MB`, `idle floor ${snap.fleet.idleFloorMb} MB`],
        ].map(([k, v, sub], i) => (
          <div key={k}>
            <div className="micro text-ink-soft">{k}</div>
            <div className={`display tnum mt-1 text-[clamp(22px,3vw,32px)] font-semibold leading-none ${i === 2 ? "text-signal" : ""}`}>
              {v}
            </div>
            <div className="mt-1 font-mono text-[10px] leading-[1.5] text-ink-soft">{sub}</div>
          </div>
        ))}
      </div>

      <div
        ref={wrapRef}
        className="relative mt-6 h-[clamp(220px,34vw,340px)] w-full border border-ink/20 bg-paper-2/40"
        onMouseLeave={() => setHover(null)}
        onMouseMove={(e) => {
          const wrap = wrapRef.current;
          if (!wrap) return;
          const rect = wrap.getBoundingClientRect();
          const cell = Math.min(rect.width / 64, rect.height / 32);
          const ox = (rect.width - cell * 64) / 2;
          const oy = (rect.height - cell * 32) / 2;
          const c = Math.floor((e.clientX - rect.left - ox) / cell);
          const r = Math.floor((e.clientY - rect.top - oy) / cell);
          if (c < 0 || c > 63 || r < 0 || r > 31) {
            setHover(null);
            return;
          }
          const idx = r * 64 + c;
          const isAwake = snap.field.includes(idx);
          setHover(
            `S-${String(idx + 1).padStart(4, "0")} · ${isAwake ? "awake · executing a turn" : "hibernating · 0 MB working set"}`,
          );
        }}
      >
        <canvas ref={canvasRef} className="absolute inset-0" />
        <div className="pointer-events-none absolute left-3 top-3 micro text-ink-soft">
          2,048 logical sessions · one cell each
        </div>
        <div className="pointer-events-none absolute bottom-3 right-3 flex items-center gap-3">
          <span className="flex items-center gap-1.5 micro text-ink-soft">
            <span className="inline-block h-[7px] w-[7px] bg-[#c9bda6]" /> hibernating
          </span>
          <span className="flex items-center gap-1.5 micro text-signal">
            <span className="inline-block h-[7px] w-[7px] bg-signal" /> awake / executing
          </span>
        </div>
        {hover ? (
          <div className="pointer-events-none absolute right-3 top-3 border border-ink/25 bg-paper px-2 py-1 micro">{hover}</div>
        ) : null}
      </div>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
        <p className="max-w-[72ch] font-mono text-[10.5px] leading-[1.8] text-ink-soft">
          hover any cell for its identity. state is derived at read time from a wake wave over each session&apos;s phase — a tick
          writes one row to the ledger and a handful of receipts, never one row per identity.
        </p>
        <span className="micro text-ink-soft">
          duty cycle <span className="tnum text-signal">{(snap.duty * 100).toFixed(1)}%</span> · tick #
          <span className="tnum text-ink">{String(snap.tick).padStart(4, "0")}</span>
        </span>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- */

function TopBar({
  snap,
  running,
  onToggle,
  onTick,
  busy,
}: {
  snap: Snapshot;
  running: boolean;
  onToggle: () => void;
  onTick: () => void;
  busy: boolean;
}) {
  return (
    <div className="sticky top-0 z-50 border-b border-ink/25 bg-paper/95 backdrop-blur-[2px]">
      <div className="mx-auto flex w-full max-w-[1300px] flex-wrap items-center gap-x-5 gap-y-2 px-5 py-2.5 lg:px-8">
        <div className="flex items-baseline gap-2">
          <span className="display text-[17px] font-semibold tracking-[-0.01em]">AOS v3</span>
          <span className="micro text-ink-soft">control plane 0.3.1</span>
        </div>
        <nav className="hidden flex-wrap gap-x-4 md:flex">
          {SECTIONS.map(([id, num]) => (
            <a key={id} href={`#${id}`} className="micro text-ink-soft transition-colors hover:text-signal">
              {num}
            </a>
          ))}
        </nav>
        <div className="ml-auto flex flex-wrap items-center gap-3">
          <span className="micro text-ink-soft">
            tick <span className="tnum text-ink">#{String(snap.tick).padStart(4, "0")}</span>
          </span>
          <span className="micro text-ink-soft">
            awake <span className="tnum text-signal">{fmt(snap.fleet.awake)}</span>
          </span>
          <span className="micro text-ink-soft">
            resident <span className="tnum text-ink">{snap.fleet.residentMb.toFixed(1)} MB</span>
          </span>
          <button className="btn" onClick={onTick} disabled={busy}>
            run tick
          </button>
          <button className={`btn ${running ? "btn-signal" : ""}`} onClick={onToggle}>
            {running ? "pause fleet" : "resume fleet"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- */

export default function Console({ initial }: { initial: Snapshot }) {
  const [snap, setSnap] = useState<Snapshot>(initial);
  const [busy, setBusy] = useState(false);
  const [running, setRunning] = useState(true);
  const [workUnitId, setWorkUnitId] = useState(initial.workUnits[0]?.id ?? "WU-20491");
  const [selectedId, setSelectedId] = useState<string | null>("T-20491-03");
  const [compilerResult, setCompilerResult] = useState<string | null>(null);
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const fn = () => setReduced(mq.matches);
    mq.addEventListener("change", fn);
    return () => mq.removeEventListener("change", fn);
  }, []);

  const tick = useCallback(async () => {
    setBusy(true);
    try {
      const res = await fetch("/api/sim/tick", { method: "POST" });
      const next = (await res.json()) as Snapshot;
      setSnap(next);
    } catch {
      /* keep the last good snapshot rather than blanking the console */
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => {
      void tick();
    }, 4200);
    return () => clearInterval(id);
  }, [running, tick]);

  const act = useCallback(async (url: string, body?: unknown) => {
    setBusy(true);
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: body ? JSON.stringify(body) : undefined,
      });
      const next = (await res.json()) as Snapshot;
      setSnap(next);
    } catch {
      /* ignore transient failure; the console stays readable */
    } finally {
      setBusy(false);
    }
  }, []);

  const runningCount = useMemo(
    () => snap.tasks.filter((t) => t.status === "running").length,
    [snap.tasks],
  );

  return (
    <div className="overflow-x-clip">
      <TopBar snap={snap} running={running} onToggle={() => setRunning((r) => !r)} onTick={tick} busy={busy} />

      {/* masthead */}
      <header className="relative overflow-hidden border-b border-ink/25">
        <img
          src="images/vellum.jpg"
          alt=""
          aria-hidden="true"
          className="absolute inset-0 h-full w-full object-cover object-right"
        />
        <div className="scrim-vellum absolute inset-0" />
        <div className="relative mx-auto w-full max-w-[1300px] px-5 pb-12 pt-14 lg:px-8 lg:pb-16 lg:pt-20">
          <div className="micro text-blueprint">
            revised architectural north star · hibernating, massively parallel · pg + drizzle control plane
          </div>
          <h1 className="display mt-6 max-w-[19ch] text-[clamp(42px,8.2vw,104px)] font-semibold leading-[0.92] tracking-[-0.028em]">
            Millions of identities.{" "}
            <span className="text-blueprint">Thousands of concurrent tasks.</span>{" "}
            <span className="italic text-signal">A tiny always-on footprint.</span>
          </h1>
          <div className="mt-8 grid gap-8 lg:grid-cols-[minmax(0,60ch)_minmax(0,1fr)]">
            <p className="text-[16px] leading-[1.72] text-ink">
              An agent is an identity, a role, a set of capabilities and persistent knowledge. It is not a process. A single
              shared execution pool serves thousands of identities; each one wakes when it has work, loads only the context it
              needs, commits its result and goes back to sleep.
            </p>
            <div className="grid grid-cols-2 gap-x-6 gap-y-4 self-start border-l border-ink/20 pl-6">
              {[
                ["no process per agent", "database identities"],
                ["no computer per agent", "task-specific execution"],
                ["no model per agent", "router picks the ladder"],
                ["no loss of state", "durable receipts + checkpoints"],
              ].map(([k, v]) => (
                <div key={k}>
                  <div className="micro text-signal">{k}</div>
                  <div className="mt-1 font-mono text-[11px] text-ink-soft">{v}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </header>

      <div className="mx-auto flex w-full max-w-[1300px] gap-8 px-5 lg:px-8">
        <aside className="hidden w-[112px] shrink-0 lg:block">
          <div className="sticky top-[72px] pt-16">
            <div className="border-t border-ink/25 pt-3">
              <div className="micro text-ink-soft">fleet state</div>
              <div className="tnum mt-2 font-mono text-[11px] leading-[1.9] text-ink">
                tick #{String(snap.tick).padStart(4, "0")}
                <br />
                awake {fmt(snap.fleet.awake)}
                <br />
                turns served {fmt(snap.fleet.turns)}
                <br />
                <span className="text-signal">{snap.fleet.residentMb.toFixed(1)} MB</span>
              </div>
            </div>
            <nav className="mt-8 space-y-2">
              {SECTIONS.map(([id, num, label]) => (
                <a key={id} href={`#${id}`} className="block group">
                  <div className="micro text-signal">{num}</div>
                  <div className="font-mono text-[10px] leading-[1.4] text-ink-soft transition-colors group-hover:text-ink">
                    {label}
                  </div>
                </a>
              ))}
            </nav>
            <div className="mt-8 border-t border-ink/25 pt-3">
              <div className="micro text-ink-soft">in flight</div>
              <div className="tnum display mt-1 text-[28px] font-semibold leading-none text-signal">{runningCount}</div>
              <div className="font-mono text-[10px] text-ink-soft">tasks executing</div>
            </div>
          </div>
        </aside>

        <main className="min-w-0 flex-1 pb-24">
          <Section
            id="field"
            num="01"
            kicker="Hibernation field"
            title={<>A living identity, not a resident worker.</>}
            lede={
              <>
                Two thousand and forty-eight session actors, sampled from {fmt(snap.fleet.identities)} registered identities.
                Each cell is a Durable Object session: awake and executing, or hibernating with its transcript checkpointed to
                SQLite and no working set at all. Watch the resident number — it is the whole argument.
              </>
            }
            notes={
              <>
                <Note label="why this works">
                  An idle AI identity should consume storage, not a running computer. An agent waiting on an external model
                  response must not occupy a dedicated server process.
                </Note>
                <Note label="write amplification">
                  Session state is derived from a wake wave at read time. A tick writes one ledger row and a handful of receipts
                  — never one row per identity.
                </Note>
                <Note label="experimental dependency">
                  PiHarness is Beta and Pi Durable is experimental. Isolate the harness behind an internal session interface so
                  it can be replaced without redesigning the business architecture.
                </Note>
              </>
            }
          >
            <HibernationField snap={snap} reduced={reduced} />
          </Section>

          {/* full-bleed instrument band */}
          <div className="relative left-1/2 w-screen -translate-x-1/2 overflow-hidden bg-panel">
            <img
              src="images/instrument.jpg"
              alt=""
              aria-hidden="true"
              className="absolute inset-0 h-full w-full object-cover opacity-45"
            />
            <div className="grain-panel absolute inset-0" />
            <div className="relative mx-auto w-full max-w-[1300px] px-5 py-14 lg:px-8 lg:py-16">
              <TelemetryBand snap={snap} />
            </div>
          </div>

          <Section
            id="work"
            num="03"
            kicker="Universal work engine"
            title={<>Plan, fan out, join, verify, commit.</>}
            lede={
              <>
                One strong planning call produces a bounded task graph. Independent subtasks start immediately on shared,
                stateless workers; the reducer receives compact references and summaries rather than whole transcripts; one
                verifier checks the outcomes that matter. Click any node to inspect its tier, its cost and its receipt.
              </>
            }
            notes={
              <>
                <Note label="the mapreduce shape">
                  Split at the smallest unit that can genuinely be performed independently. Five agents independently rewriting
                  the same market report is waste, not parallelism.
                </Note>
                <Note label="bounded fan-out">
                  200 independent research URLs do not become 200 simultaneous browsers. Fetch publicly, batch extraction, and
                  escalate only the difficult sites.
                </Note>
                <Note label="durable boundaries">
                  Postgres holds authoritative business records. A Durable Object holds a conversation&apos;s operational state.
                  A Workflow holds the Work Unit lifecycle. R2 holds the artifacts.
                </Note>
              </>
            }
          >
            <WorkUnitDag
              snap={snap}
              workUnitId={workUnitId}
              selectedId={selectedId}
              onSelect={(id) => {
                setSelectedId(id);
                setWorkUnitId(snap.tasks.find((t) => t.id === id)?.workUnitId ?? workUnitId);
              }}
              onFanout={(id) => {
                setWorkUnitId(id);
                void act(`/api/work-units/${id}/fanout`);
              }}
              onTick={tick}
              busy={busy}
            />
          </Section>

          <Section
            id="tiers"
            num="04"
            kicker="Execution fabric"
            title={<>Three tiers. Not six permanent environments.</>}
            lede={
              <>
                The earlier architecture carried too many execution classes. They remain useful as concepts and unnecessary as
                separate infrastructure. Everything is decided before a process exists.
              </>
            }
            notes={
              <>
                <Note label="browser pool">
                  Keep a small number of warm browser processes, isolate independent authenticated sessions in separate
                  contexts, reuse tabs within a session, close contexts when finished.
                </Note>
                <Note label="hard limit">
                  Tabs in one browser share its process and its memory. Context isolation is not an operating-system security
                  boundary; heavy pages will crash a crowded browser.
                </Note>
                <Note label="automation order">
                  API first, then Playwright and the accessibility tree, then Stagehand for pages that resist selectors, and a
                  vision model only for genuine visual ambiguity.
                </Note>
              </>
            }
          >
            <TiersSection />
          </Section>

          <Section
            id="memory"
            num="05"
            kicker="Memory compiler"
            title={<>A huge knowledge base, a very small working set.</>}
            lede={
              <>
                After a task completes, candidate facts and reusable procedures are extracted in a background workflow,
                deduplicated against what the organization already believes, scored for scope and trust, and promoted only when
                they survive. The agent never rebuilds a memory profile on every turn — it receives a small context package with
                references to the records that matter.
              </>
            }
            notes={
              <>
                <Note label="four classes">
                  Preferences as structured rows. Episodic memory from task and event records. Semantic knowledge with
                  provenance and validity. Procedural memory as versioned skill packages.
                </Note>
                <Note label="no graph, yet">
                  pgvector inside PostgreSQL first. Neo4j, FalkorDB and Qdrant are not earned by the word &quot;memory&quot; in
                  a feature list. Graphiti arrives when relational edges stop being enough.
                </Note>
                <Note label="promotion rule">
                  A skill is generated only after successful testing. Repeated success becomes a procedure; an unverified claim
                  stays a candidate.
                </Note>
              </>
            }
          >
            <MemoryCompiler
              snap={snap}
              busy={busy}
              result={compilerResult}
              onCompile={() => {
                void (async () => {
                  setBusy(true);
                  try {
                    const res = await fetch("/api/memory/compile", { method: "POST" });
                    const next = (await res.json()) as Snapshot & {
                      compiler: { candidates: number; promoted: number };
                    };
                    setSnap(next);
                    setCompilerResult(`${next.compiler.promoted} of ${next.compiler.candidates} promoted`);
                  } finally {
                    setBusy(false);
                  }
                })();
              }}
            />
          </Section>

          <Section
            id="authority"
            num="06"
            kicker="Authority envelope"
            title={<>An agent can request an action. It cannot authorize itself.</>}
            lede={
              <>
                Deterministic authorization at the tool gateway, with a short-lived scoped capability token per execution. The
                credential broker injects the real secret at the moment the approved tool runs — the model never sees it, and no
                child task inherits more authority than its parent.
              </>
            }
            notes={
              <>
                <Note label="live view is a bearer credential">
                  Whoever holds a Live View URL controls the browser and everything logged into it. Expose it to authenticated
                  humans only — never to the model, never as ordinary task data.
                </Note>
                <Note label="egress">
                  Sandboxes default to denied network access. Permitted destinations are enforced outside the model.
                </Note>
                <Note label="policy placement">
                  Cedar evaluates action policy as a library. Resource relationships live in PostgreSQL. OpenFGA and SPIFFE wait
                  for a complexity that has not arrived.
                </Note>
              </>
            }
          >
            <AuthorityPanel
              snap={snap}
              busy={busy}
              onDecide={(id, decision) => void act("/api/approvals", { id, decision })}
            />
          </Section>

          <Section
            id="stack"
            num="07"
            kicker="Stack ledger"
            title={<>One of each. Deliberately.</>}
            notes={
              <>
                <Note label="portable core">
                  Keep adapters for five things: durable workflow, session storage, browser provider, sandbox provider and
                  object storage. Replace the platform without replacing the product.
                </Note>
                <Note label="if not cloudflare">
                  Workflows become DBOS. Sessions become a shared worker pool. Sandboxes become OpenSandbox with Firecracker.
                  The Work Unit contracts and authority model stay identical.
                </Note>
              </>
            }
          >
            <StackSection />
          </Section>

          <Section
            id="measure"
            num="08"
            kicker="Measurement"
            title={<>Verified work per GB of active memory.</>}
            lede={
              <>
                The most valuable metric is not how many agents the platform can create. It is how much verified work it can
                complete, safely, per GB of active memory and per dollar of cloud expenditure.
              </>
            }
          >
            <MeasureSection />
          </Section>

          <footer className="border-t-2 border-ink pt-6">
            <div className="flex flex-wrap items-baseline justify-between gap-4">
              <div className="display text-[19px] font-semibold">
                AOS v3 — persistent agent identity, not persistent agent infrastructure.
              </div>
              <div className="micro text-ink-soft">
                control plane 0.3.1 · postgres + drizzle · deterministic tick engine · tick #
                {String(snap.tick).padStart(4, "0")}
              </div>
            </div>
            <p className="mt-4 max-w-[74ch] font-mono text-[10.5px] leading-[1.9] text-ink-soft">
              the human defines the outcome. the organization creates a durable task graph. the scheduler activates only the
              necessary capabilities. shared workers execute the independent tasks concurrently. the right computer appears only
              when it is needed. the verifier checks the result. the system preserves the learning and releases the resources.
            </p>
          </footer>
        </main>
      </div>
    </div>
  );
}
