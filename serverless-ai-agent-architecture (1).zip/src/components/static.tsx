import type { ReactNode } from "react";

export const fmt = (n: number) => n.toLocaleString("en-US");

export function Section({
  id,
  num,
  kicker,
  title,
  lede,
  notes,
  children,
  tone = "paper",
}: {
  id: string;
  num: string;
  kicker: string;
  title: ReactNode;
  lede?: ReactNode;
  notes?: ReactNode;
  children: ReactNode;
  tone?: "paper" | "dark";
}) {
  const dark = tone === "dark";
  return (
    <section id={id} className={`scroll-mt-20 py-14 lg:py-20 ${dark ? "text-panel-ink" : ""}`}>
      <div className="mb-8">
        <div className={`micro ${dark ? "text-signal-soft" : "text-signal"}`}>
          § {num} / {kicker}
        </div>
        <h2
          className={`display mt-3 text-[clamp(30px,4.4vw,52px)] font-semibold leading-[1.02] ${
            dark ? "text-panel-ink" : "text-ink"
          }`}
        >
          {title}
        </h2>
        {lede ? (
          <p
            className={`mt-4 max-w-[64ch] text-[15px] leading-[1.72] ${
              dark ? "text-panel-ink/75" : "text-ink-soft"
            }`}
          >
            {lede}
          </p>
        ) : null}
      </div>
      <div className="grid gap-x-10 gap-y-8 xl:grid-cols-[minmax(0,1fr)_236px]">
        <div className="min-w-0">{children}</div>
        {notes ? <aside className="space-y-6">{notes}</aside> : null}
      </div>
    </section>
  );
}

export function Note({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="border-l-2 border-signal/60 pl-3">
      <div className="micro text-signal">{label}</div>
      <p className="mt-1.5 font-mono text-[11px] leading-[1.75] text-ink-soft">{children}</p>
    </div>
  );
}

export function Kicker({ children }: { children: ReactNode }) {
  return <div className="micro text-blueprint">{children}</div>;
}

/* ---------------------------------------------------------------- */
/* § 04 — execution tiers                                            */
/* ---------------------------------------------------------------- */

const TIERS = [
  {
    n: "0",
    name: "No computer",
    when: "Default",
    what: "Typed APIs, native integrations, HTTP fetches, database queries, deterministic functions. This handles the majority of ordinary business tasks. Nothing needs to boot.",
    specs: ["Workers · 128 MiB per isolate", "no cold start", "0 model calls where code suffices"],
  },
  {
    n: "1",
    name: "Lightweight execution",
    when: "High frequency",
    what: "Small scripts, document transformations, parsers, data extraction and controlled command execution, run in Workers and small containers that sleep when finished.",
    specs: ["Container lite · 1/16 vCPU · 256 MiB · 2 GB", "basic · 1/4 vCPU · 1 GiB · 4 GB", "scales to zero"],
  },
  {
    n: "2",
    name: "Isolated computers",
    when: "Only when necessary",
    what: "Untrusted code, long coding sessions, native Linux operations, authenticated browsing that needs process isolation, and genuine full-computer interaction.",
    specs: ["Firecracker VMM overhead ≤ 5 MiB", "boot ≤ 125 ms to guest user space", "128 MiB guest (spec configuration)", "copy-on-write snapshots"],
  },
];

export function TiersSection() {
  return (
    <div>
      <ol className="divide-y divide-ink/15 border-y border-ink/25">
        {TIERS.map((t) => (
          <li key={t.n} className="grid grid-cols-[54px_minmax(0,1fr)] gap-5 py-6">
            <div className="display text-[44px] font-semibold leading-[0.85] text-signal">{t.n}</div>
            <div>
              <div className="flex flex-wrap items-baseline gap-x-3">
                <h3 className="display text-[21px] font-semibold">{t.name}</h3>
                <span className="micro text-ink-soft">{t.when}</span>
              </div>
              <p className="mt-2 max-w-[58ch] text-[14px] leading-[1.7] text-ink-soft">{t.what}</p>
              <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1">
                {t.specs.map((s) => (
                  <span key={s} className="font-mono text-[10.5px] uppercase tracking-[0.1em] text-blueprint">
                    ▸ {s}
                  </span>
                ))}
              </div>
            </div>
          </li>
        ))}
      </ol>
      <div className="mt-6 border border-ink/25 bg-paper-2/60 p-5">
        <Kicker>Default execution flow — the decision is made before a process exists</Kicker>
        <ol className="mt-3 space-y-2 font-mono text-[11.5px] leading-[1.8] text-ink-soft">
          <li>
            <span className="text-signal">01</span> Can a direct API or tool perform it? → Tier 0, stop.
          </li>
          <li>
            <span className="text-signal">02</span> Does it need a browser? → pooled remote browser, separate context, reused session.
          </li>
          <li>
            <span className="text-signal">03</span> Does it require stronger isolation? → dedicated instance or microVM, torn down on completion.
          </li>
        </ol>
        <p className="mt-4 max-w-[62ch] text-[13.5px] leading-[1.7] text-ink">
          The biggest performance win is not making a browser agent twice as fast. It is avoiding browser execution for work a
          direct request can finish.
        </p>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* § 07 — stack ledger                                               */
/* ---------------------------------------------------------------- */

const STACK: [string, string, string][] = [
  ["Application and UI", "Cloudflare Workers", "Cloud Run · Fly.io"],
  ["Durable agent session", "Agents SDK + PiHarness", "custom lightweight harness"],
  ["Agent loop", "Pi Durable", "Pydantic AI · Mastra"],
  ["Work Unit orchestration", "Cloudflare Workflows", "DBOS"],
  ["Event fan-out", "Cloudflare Queues", "NATS JetStream"],
  ["Canonical database", "Managed PostgreSQL", "D1 partitioned per tenant"],
  ["Connection pooling", "Hyperdrive", "managed pooler"],
  ["Large artifacts", "R2", "managed S3"],
  ["Semantic retrieval", "pgvector", "Vectorize"],
  ["Model gateway", "Cloudflare AI Gateway", "agentgateway"],
  ["Browser automation", "Browser Run + Playwright", "Browserbase · Stagehand"],
  ["Small code sandbox", "Workers · Containers", "Cloud Run Jobs"],
  ["High-isolation sandbox", "Firecracker · OpenSandbox", "E2B · microsandbox"],
  ["Authorization", "Cedar + scoped SQL permissions", "OpenFGA"],
  ["External workload identity", "Signed capability tokens", "SPIFFE · SPIRE"],
  ["Evaluation", "Inspect AI", "DeepEval · Promptfoo"],
  ["Telemetry", "OpenTelemetry", "Opik"],
  ["Knowledge graph", "PostgreSQL relations first", "Graphiti + FalkorDB"],
];

export function StackSection() {
  return (
    <div>
      <div className="overflow-x-auto">
      <table className="w-full min-w-[560px] border-collapse text-left">
        <thead>
          <tr className="border-y border-ink/30">
            <th className="micro py-2.5 pr-4 text-ink-soft">Function</th>
            <th className="micro py-2.5 pr-4 text-ink-soft">Primary selection</th>
            <th className="micro py-2.5 text-ink-soft">Alternative / experimental</th>
          </tr>
        </thead>
        <tbody>
          {STACK.map(([fn, primary, alt]) => (
            <tr key={fn} className="border-b border-ink/12 align-top">
              <td className="py-2.5 pr-4 text-[13px] leading-[1.5]">{fn}</td>
              <td className="py-2.5 pr-4 font-mono text-[11.5px] leading-[1.6] text-blueprint">{primary}</td>
              <td className="py-2.5 font-mono text-[11.5px] leading-[1.6] text-ink-soft">{alt}</td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>
      <p className="mt-5 max-w-[62ch] text-[13.5px] leading-[1.75] text-ink-soft">
        It is intentionally consolidated. One workflow engine, one model gateway, one canonical database. Running Cloudflare
        Workflows and DBOS as two authorities for the same Work Unit is how a small platform becomes an operations department.
      </p>
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* § 08 — measurement                                                */
/* ---------------------------------------------------------------- */

const METRICS: [string, string][] = [
  ["Memory per active turn", "efficiency of the agent runtime"],
  ["Memory per idle session", "effectiveness of hibernation"],
  ["Workflow starts / sec", "orchestration throughput"],
  ["Tool operations / sec", "actual execution capability"],
  ["p95 task completion time", "user-visible performance"],
  ["Queue waiting time", "whether the scheduler is overloaded"],
  ["Browser memory per tab", "browser density"],
  ["Sandbox startup latency", "cost of strong isolation"],
  ["Database writes per task", "persistence overhead"],
  ["Model tokens per accepted result", "intelligence efficiency"],
  ["External side effects per success", "operational effectiveness"],
  ["Cost per verified deliverable", "overall economics"],
];

const NOT_BUILT = [
  "A permanently running VM for each agent.",
  "A separate Python or Node process for each agent.",
  "Always-on agent orchestration servers.",
  "Multiple workflow engines.",
  "Multiple overlapping model gateways.",
  "Neo4j plus FalkorDB plus Qdrant plus Redis at launch.",
  "A browser agent that runs a vision model on every click.",
  "Agents communicating through endless autonomous chat loops.",
  "A platform that treats every task as a full computer-use task.",
];

export function MeasureSection() {
  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <div>
        <Kicker>Do not select the system on agent count — select it on these</Kicker>
        <table className="mt-4 w-full border-collapse">
          <tbody>
            {METRICS.map(([m, what], i) => (
              <tr key={m} className="border-b border-ink/12">
                <td className="w-7 py-2 align-top font-mono text-[10.5px] text-signal tnum">
                  {String(i + 1).padStart(2, "0")}
                </td>
                <td className="py-2 pr-3 align-top text-[13px] leading-[1.5]">{m}</td>
                <td className="py-2 align-top font-mono text-[10.5px] leading-[1.6] text-ink-soft">{what}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div>
        <Kicker>Hard acceptance conditions</Kicker>
        <ul className="mt-4 space-y-2">
          {[
            "Zero unauthorized high-impact side effects.",
            "No lost durable Work Units.",
            "No duplicate external actions where the external system supports idempotency.",
            "Correct recovery when a process or a browser disappears.",
            "No persistent execution cost for idle agents.",
            "No unbounded task fan-out.",
            "Every deliverable is checked against its actual success criteria.",
          ].map((c) => (
            <li key={c} className="flex gap-2.5 text-[13px] leading-[1.6]">
              <span className="mt-[3px] block h-[9px] w-[9px] shrink-0 border border-signal bg-signal/25" />
              <span>{c}</span>
            </li>
          ))}
        </ul>
        <div className="mt-8 border-t border-ink/25 pt-5">
          <Kicker>What I would emphatically not build</Kicker>
          <ul className="mt-3 space-y-1.5">
            {NOT_BUILT.map((n) => (
              <li key={n} className="font-mono text-[11px] leading-[1.7] text-ink-soft">
                ✕ {n}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
