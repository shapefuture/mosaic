# Top 100 Free & Open-Source Tools for Reviewing AI-Agent-Generated Code

**Compiled:** 15 August 2026 · **Method:** 62 targeted search queries across GitHub, Reddit, Hacker News, X/Twitter, vendor docs and the open web — scoped deliberately to the *specific failure modes of code written by AI agents*, and filtered to tools that are **free, open-source, or have a genuinely usable free tier**.

**Companion file:** `ai-code-review-tools-top100.md` (200 tools, mostly commercial). This document is the free/OSS counterpart and is **not** a subset of it — where a tool appears in both, the entry here explains its free/self-hosted path specifically.

---

## Part 0 — The analysis: which categories actually matter for agent-written code

Reviewing agent output is **not** the same problem as reviewing human output. Human review tooling assumes the author understood the code and made a typo. Agent output inverts that: the syntax is near-perfect, the style is immaculate, and the *intent* is where it breaks.

From the 200 tools in the companion file, these are the categories that transfer to agent code — ranked by how specific they are to this problem:

| # | Failure mode unique to agent code | Why generic review tools miss it | Cluster in this doc |
|---|---|---|---|
| 1 | **Hallucinated dependencies** — the agent imports a package that does not exist; an attacker registers it ("slopsquatting"). ~20% of LLM-suggested packages don't exist; open-weight models hallucinate at 21.7% | Linters and SAST assume imports resolve. Nothing checks the *registry* | **A** |
| 2 | **Hallucinated APIs** — methods, flags and config keys that look right but aren't in the installed version | Only a strict type checker or a real execution catches this | **B, J** |
| 3 | **Tests that assert nothing** — agent writes tests that pass regardless of logic. Coverage looks great | Coverage measures execution, not verification | **C** |
| 4 | **Silent deletion** — agent removes logic, weakens an assertion, or loosens a quality gate to make CI green | Diff review shows it; nobody reads a 4,000-line diff | **D, I** |
| 5 | **Volume** — PRs too large to review; review capacity is now the bottleneck, not code production | The tool isn't the problem; triage and diff structure are | **E** |
| 6 | **Architecture drift** — agent lacks tacit knowledge of layer boundaries and crosses them plausibly | Nothing in a linter encodes your architecture | **F** |
| 7 | **Duplication / AI slop** — agent re-implements what already exists rather than reusing it | Requires cross-file clone detection, not diff review | **G** |
| 8 | **Missing provenance** — LLMs do not track attribution; copied code arrives with licences stripped | No standard tool checks this by default | **H** |
| 9 | **Agent-specific security** — prompt injection in MCP tool descriptions, unguarded tool calls, secrets in agent context | A brand-new attack surface with brand-new tooling | **K, L** |
| 10 | **Independence** — the model that wrote the bug is the worst candidate to find it | Argues for *different* models/methods, not a better prompt | **M** |

**The single most important finding from the research:** the strongest free stack is **not** "one open-source AI reviewer." It is **deterministic tools that give an agent-written diff nowhere to hide** (registry checks, type checkers, mutation testing, clone detection, architecture rules) plus **one independent LLM reviewer** using a different model from the one that wrote the code. Bismuth's SM-100 benchmark found leading agents catch only ~7% of real maintenance bugs with 90%+ false positives — so do not build your defence on an LLM reviewer alone.

---

## Contents

| Cluster | Theme | Count |
|---|---|---|
| A | Hallucinated dependency & slopsquatting defence | 9 |
| B | Type checkers & "does this API exist" verification | 7 |
| C | Test-quality verification (mutation testing & PBT) | 10 |
| D | Diff coverage & anti-regression gates | 6 |
| E | PR comprehension, semantic diff & triage | 7 |
| F | Architecture & boundary enforcement | 7 |
| G | Duplication, dead code & slop detection | 8 |
| H | Provenance, licence & plagiarism | 6 |
| I | Free/OSS AI PR reviewers (self-hosted, BYO-key) | 14 |
| J | Runtime, fuzzing & execution-verified review | 5 |
| K | Agent-specific security (MCP, tool calls, prompt injection) | 8 |
| L | Secrets & supply-chain scanning | 9 |
| M | Deterministic SAST & multi-model independence | 10 |
| — | **Total** | **100** |

Legend: ⭐ = exceptional, often better than the paid equivalent · 💎 = under-the-radar, low stars, high value

---

# CLUSTER A — Hallucinated dependency & slopsquatting defence
*The most agent-specific category in this document. Almost none of the paid AI reviewers in the companion file check whether an imported package actually exists.*

**1. ⭐ AgentGuard** — https://github.com/momenbasel/AgentGuard
MIT. Installs as a **Claude Code `PreToolUse` hook** so every `npm install` / `pip install` / `git clone` / piped script the agent attempts is intercepted *before execution*. Checks blocklist, typosquat edit-distance + homoglyphs, `curl|sh` patterns, registry metadata (age <7 days, no repo link), GitHub repo reputation, OSV.dev MAL- advisories, optional VirusTotal. Exit code 2 blocks the command. `pip install agentguard && agentguard install --global`. **This is the single highest-leverage install in this document if you run agents autonomously.**

**2. ⭐ Aikido Safe Chain** — https://github.com/AikidoSec/safe-chain
Free, no token required. Shell-alias wrapper around npm, npx, yarn, pnpm, pnpx that checks every package against Aikido Intel threat data before download. `npm i -g @aikidosec/safe-chain && safe-chain setup`. Complements #1 — Safe Chain covers the human's terminal, AgentGuard covers the agent's.

**3. 💎 slopcheck** — https://github.com/0xToxSec/slopcheck
MIT. Purpose-built for hallucinated packages across **PyPI, npm, crates.io and Go modules**. Detects non-existent packages (the #1 signal), packages <7 days old, <100 downloads, LLM naming patterns (`{popular-lib}-{ai|gpt|helper|utils}`), typosquats with "did you mean", and missing repo links. Has `--fix` to comment out slop automatically, and distinct exit codes (0 clean / 1 suspicious / 2 slop / 3 registry error) for CI.

**4. 💎 dep-hallucinator** — https://github.com/serhanwbahar/dep-hallucinator
MIT. Same problem, broader registry coverage (PyPI, npm, Maven Central, Crates.io, Go), adds ML detection of AI-generated naming patterns, CRITICAL/HIGH/MEDIUM/LOW risk classification, and **SBOM generation in SPDX + CycloneDX**. Ships a documented pre-commit hook that aborts on CRITICAL.

**5. OSV-Scanner (Google)** — https://github.com/google/osv-scanner
Apache-2.0, 10.6k★. Queries OSV.dev (30+ advisory sources, the largest aggregated DB). 11+ ecosystems, 19+ lockfile types, container images, **guided remediation** ranking minimum upgrades by ROI, offline mode, call-graph analysis to cut false positives. The free baseline SCA everyone should run.

**6. Socket (free tier / OSS repos)** — https://socket.dev · https://github.com/SocketDev
**Behavioural** rather than CVE-based: judges what a package *does* — install scripts phoning home, unexpected filesystem/shell access, native code, typosquatting — and blocks it in the PR *before a CVE exists*. Free for open source. Has an MCP server so agents can pre-check packages themselves.

**7. pnpm `minimum-release-age`** — https://pnpm.io
Free, built in. Set `minimum-release-age=72h` and a package registered by an attacker two hours ago simply cannot install. Zero-cost, zero-dependency structural defence against slopsquatting; the agent hits an error and re-plans.

**8. GuardDog (DataDog)** — https://github.com/DataDog/guarddog
Apache-2.0. Semgrep-rule-based malicious-package detection for PyPI and npm — identifies suspicious install scripts, obfuscation and exfiltration in package source rather than matching known-bad lists.

**9. Trivy (Aqua)** — https://github.com/aquasecurity/trivy
Apache-2.0. One binary for dependencies, container images, IaC, secrets and SBOM. The consolidation choice when you don't want five tools; weaker on remediation than OSV-Scanner.

---

# CLUSTER B — Type checkers & "does this API exist" verification
*The cheapest, fastest, most deterministic way to catch a hallucinated method or wrong argument order. Run in strict mode or don't bother.*

**10. ⭐ Pyright / basedpyright** — https://github.com/microsoft/pyright · https://github.com/DetachHead/basedpyright
Pyright is free (MIT). **basedpyright** is the stricter community fork worth knowing: it adds `reportAny` to fully ban `Any`, exits non-zero on invalid config (Pyright silently ignores a typo'd `mode = "strict"` and reports success), and fixes Pyright's unreachable-code handling that skips type-checking entirely. `typeCheckingMode = "all"`.

**11. mypy --strict** — https://github.com/python/mypy
The reference implementation, with the richest plugin ecosystem (django-stubs, pydantic). Slower than Pyright; catches a different ~10-20%. A codebase passing both strict is genuinely well-typed.

**12. TypeScript `--strict` + `tsc --noEmit`** — https://www.typescriptlang.org
Free. The single highest-value gate for agent-written TS. Add `noUncheckedIndexedAccess` and `exactOptionalPropertyTypes` — agents are careless with both.

**13. ty (Astral)** — https://github.com/astral-sh/ty
Rust-based Python type checker, sub-second on large repos. Ideal as a pre-commit fast path with mypy/Pyright in CI.

**14. Pyre + Pysa (Meta)** — https://github.com/facebook/pyre-check
Free. Pyre for typing, **Pysa for taint analysis** — the only free Python checker doing security taint tracking, which matters when the agent wires user input to a sink.

**15. Beartype** — https://github.com/beartype/beartype
Runtime type checking with near-zero overhead. Catches what static analysis can't when the agent's code meets real data.

**16. Infer (Meta)** — https://github.com/facebook/infer
MIT, 15.5k★. Interprocedural analysis via **separation logic and bi-abduction** — null dereferences, memory/resource leaks, data races (RacerD) across Java, C, C++, Objective-C, Erlang, Hack. Crucially has a **differential mode reporting only issues introduced by a diff**, which is exactly the agent-PR use case. 100,000+ issues fixed internally at Meta.

---

# CLUSTER C — Test-quality verification (mutation testing & property-based testing)
*The definitive answer to "the agent wrote tests and they pass." Thoughtworks Radar explicitly flags mutation testing as the reinforcement layer against "perpetually green" AI-generated tests.*

**17. ⭐ Stryker Mutator** — https://github.com/stryker-mutator/stryker-js
Apache-2.0. JS/TS/C#/Scala. Introduces mutants (`>` → `>=`, swap `&&`/`||`, delete lines) and reports which survive. `thresholds: { break: 60 }` fails CI. **Incremental mode** makes it viable per-PR. The benchmark in the research: 60% coverage but only 44% mutation score on vanilla AI-generated tests — the gap *is* the problem.

**18. PIT / PITest** — https://pitest.org
Java/Kotlin, Apache-2.0. The most mature mutation engine in existence; its author's own account of finding "interaction tests that never check the return value" describes AI-generated tests precisely.

**19. mutmut** — https://github.com/boxed/mutmut · **cosmic-ray** — https://github.com/sixty-north/cosmic-ray
Python mutation testing. mutmut for speed and ergonomics, cosmic-ray for distributed runs.

**20. cargo-mutants** — https://github.com/sourcefrog/cargo-mutants
Rust. Two commands, zero source changes: `cargo install cargo-mutants && cargo mutants`. The easiest on-ramp to mutation testing in any language.

**21. 💎 mutest (Go)** — https://github.com/fchimpan/mutest
MIT, new and small. Deliberately narrow: mutates only comparison/equality operators — the ones that actually catch bugs — compiles once per package and finishes in **milliseconds, not minutes**. Uses Go's `-overlay` so it never touches your source. Has `-diff`, `-threshold`, `-json`. Written explicitly for the AI-generated-code problem.

**22. Stryker.NET** — https://stryker-mutator.io/docs/stryker-net/introduction/ · **go-mutesting** — https://github.com/zimmski/go-mutesting · **mutant (Ruby)** — https://github.com/mbj/mutant
Language coverage for .NET, Go and Ruby respectively.

**23. ⭐ Hypothesis** — https://github.com/HypothesisWorks/hypothesis
Python property-based testing. Instead of "for this input, expect this output," you assert invariants (`encode ↔ decode`, idempotence, sort preserves length and contents) and it hunts counterexamples, then **shrinks to the minimal failing case**. Research cited in the sweep: an agent generating Hypothesis properties across 100 packages produced 984 bug reports, ~56% genuine.

**24. Google FuzzTest** — https://github.com/google/fuzztest
C++, bridges property-based testing and coverage-guided fuzzing in the same file as your unit tests.

**25. Schemathesis** — https://github.com/schemathesis/schemathesis (MIT) · **EvoMaster** — https://github.com/WebFuzzing/EvoMaster (LGPL-3.0)
API-level verification from OpenAPI/GraphQL schemas — catches agent-written endpoints that don't match their own spec.

**26. proptest (Rust)** — https://github.com/proptest-rs/proptest · **jqwik (Java)** — https://jqwik.net · **fast-check (JS/TS)** — https://github.com/dubzzz/fast-check
Property-based testing for the remaining major ecosystems.

---

# CLUSTER D — Diff coverage & anti-regression gates
*Stops the agent from "fixing" CI by weakening it.*

**27. ⭐ diff-cover / diff-quality** — https://github.com/Bachmann1234/diff_cover
Apache-2.0. Enforces coverage **only on the lines the diff touched** — the one coverage metric that is both achievable and meaningful on an agent PR. Consumes Cobertura/Clover/JaCoCo/LCov, so it works for Python, Java, JS, C/C++. `--fail-under=80`. `diff-quality` does the same for linter violations.

**28. cover-diff** — https://github.com/AtakamaLLC/cover-diff · **coverage-diff** — https://github.com/strayge/coverage-diff
Node and Python-native equivalents of #27 for teams that want lighter tooling.

**29. Open Policy Agent + Conftest** — https://www.openpolicyagent.org · https://www.conftest.dev
Apache-2.0. The mechanism for the rule that matters most: **fail the build if the diff deletes test files without a test-owner approval.** Rego makes "no unreviewed test deletions," "mutation score ≥ 0.85," and "diff coverage ≥ 0.9" enforceable policy rather than hope.

**30. Danger** — https://danger.systems
Free. PR-level policy in Ruby/JS/Swift/Kotlin/Python: "every PR needs a changelog entry", "PRs touching /billing need a billing-team reviewer", "PR must be under 500 lines." No AST — pure policy, which is exactly right for agent-volume triage.

**31. ⭐ Reviewdog** — https://github.com/reviewdog/reviewdog
Free glue that turns *any* linter or scanner's output into inline PR comments on GitHub, GitLab, Bitbucket **and Gerrit** — and filters to changed lines only. 40+ formats out of the box. This is how you get the other 99 tools in this document to comment on a PR without paying anyone.

**32. pre-commit** — https://pre-commit.com · **Lefthook** — https://github.com/evilmartians/lefthook
Hook frameworks. Lefthook is the 2026 pick: single Go binary, one YAML file, parallel execution, replaces Husky + lint-staged. Critical detail from the research: **tell your agent never to use `--no-verify`** in CLAUDE.md/AGENTS.md, and consider a Cursor `beforeShellExecution` hook with `failClosed: true` to block it outright.

---

# CLUSTER E — PR comprehension, semantic diff & triage
*When an agent opens a 50-file PR, the bottleneck is human understanding, not defect detection.*

**33. ⭐ Difftastic** — https://github.com/Wilfred/difftastic
MIT. Structural diff over tree-sitter ASTs across 50+ languages. Reformatting stops showing as change; moved blocks register as moves; renames track properly. `GIT_EXTERNAL_DIFF=difft git diff`. Massively reduces the noise in a large agent refactor.

**34. 💎 Diffcore** — https://github.com/jamesaphoenix/diff-core
Explicitly "built for the era of AI agents producing 50+ file PRs." Free structural layer (tree-sitter symbol graph, entrypoint detection, forward-reachability clustering, data-flow tracing) with **optional** paid LLM refinement — the deterministic half costs nothing. Ships CLI, Tauri desktop app and a VS Code extension with `j`/`k` flow navigation.

**35. diffsitter** — https://github.com/afnanenayet/diffsitter · **delta** — https://github.com/dandavison/delta
AST diff and syntax-highlighting pager respectively. `delta` is the low-effort quality-of-life win.

**36. Repomix** — https://github.com/yamadashy/repomix
MIT, ~21k★. Packs a repo into one AI-friendly XML/Markdown/JSON file with **tree-sitter compression achieving ~70% token reduction**, per-file token counts, Secretlint scanning to stop key leakage, MCP server and Agent Skills output. The standard way to give a *second, independent* model full-repo context for review.

**37. GitIngest** — https://github.com/coderamp-labs/gitingest
Swap `github.com` → `gitingest.com` in any URL for an LLM-ready digest. CLI, Python API, self-hostable via Docker. Zero friction.

**38. code2prompt** — https://github.com/mufeedvh/code2prompt · **yek** — https://github.com/bodo-run/yek
Rust-speed context packing with templating (code2prompt) and raw throughput (yek).

**39. 💎 PR Guard** — https://github.com/YM2132/PR_guard
A genuinely original idea. Doesn't review the code — it generates **three questions about the diff and requires the PR author to answer them**, then judges whether the answers demonstrate understanding. Blocks merge until they do. "Use AI as much as you like, but if your name is on the PR you should be able to explain it." Runs on gpt-5-mini for fractions of a cent.

---

# CLUSTER F — Architecture & boundary enforcement
*Agents lack tacit knowledge. An agent that hasn't been told about a layering rule crosses it without hesitation — and an agent responds to a failing build far more reliably than to a paragraph in a docs file.*

**40. ⭐ ArchUnit** — https://github.com/TNG/ArchUnit
Java/Kotlin, Apache-2.0. Architecture as executable tests: `classes().that().resideInPackage("..domain..").should().notDependOnClassesThat().resideInPackage("..infrastructure..")`. The canonical fitness function.

**41. ⭐ dependency-cruiser** — https://github.com/sverweij/dependency-cruiser
MIT. JS/TS import-graph rules that fail CI. The lastminute.com case study in the research pairs it with Danger to surface violations as MR comments and uses a per-module `architecture.rules.js` "flag file" pattern for incremental adoption.

**42. import-linter** — https://github.com/seddonym/import-linter (Python) · **NetArchTest** — https://github.com/BenMorris/NetArchTest (.NET) · **depguard** — https://github.com/OpenPeeDeeP/depguard (Go)
Same discipline for the remaining major ecosystems.

**43. ⭐ Tach** — https://github.com/gauge-sh/tach
Python module-boundary enforcement, Rust-implemented, zero runtime footprint. Declare modules, define allowed dependencies, `tach check`. Also does `tach show`/`report` for visualisation and can enforce strict public interfaces (only what's in `__init__.py` is importable). Used by NVIDIA in bionemo-framework. More powerful than an import linter, less rigid than Bazel.

**44. ast-grep** — https://github.com/ast-grep/ast-grep
MIT. "grep for ASTs" — find *and rewrite* code by structural pattern with meta-variables. Ideal for encoding "never call the DB directly from a controller" as a checkable, fixable rule, plus built-in rule testing with valid/invalid cases.

**45. ESLint `no-restricted-imports` + eslint-plugin-import** — https://eslint.org
Free, already installed. The lowest-effort boundary enforcement available; runs in the IDE so violations surface before the agent's suggestion is even accepted.

**46. 💎 The (anti-)pattern library method** — https://www.robinwieruch.de/ai-agentic-code-review/
Not a product, and free. Document project patterns and anti-patterns as structured files, bundle into one reference doc, have agents review against it both in CI and locally pre-PR. The zero-cost baseline to try before adopting anything else in this cluster.

**47. Ontoly** — https://github.com/0xsarwagya/ontoly
Deterministic software graph for TypeScript exposed as Agent Skills + MCP: architecture summaries, route tracing, impact analysis. Graph-first — query evidence before searching source.

---

# CLUSTER G — Duplication, dead code & slop detection
*Agents re-implement rather than reuse, and leave orphans behind after iterating.*

**48. ⭐ jscpd** — https://github.com/kucherenko/jscpd
MIT, 5.5k★, 1.8M weekly npm downloads. Rabin-Karp clone detection across **223 formats**. v5 is a Rust rewrite, **24–37× faster**. Explicitly repositioned in 2026 for AI-generated codebases: v4.1 added an **`ai` reporter** (token-efficient output for LLM pipelines), an **MCP server**, and **Agent Skills** so Claude/Cursor/Copilot run duplication checks in their own workflow. v4.2 added cross-format detection (a block in `.vue` matches `.ts`). Bundled inside super-linter, MegaLinter and Codacy. Maintained since 2013 by one developer.

**49. 💎 DRYwall** — https://github.com/nikhaldi/drywall
MIT. Claude Code plugin wrapping jscpd: `/drywall:scan` for supervised refactoring, an autonomous `dedup-refactor` subagent, and a `detect_code_duplication` MCP tool. The key insight in its README: because detection is *deterministic*, it is "significantly more effective and cheaper in tokens than just telling an agent to find duplication."

**50. ⭐ Knip** — https://github.com/webpro-nl/knip
The gold standard for JS/TS dead code: unused **files, exports, dependencies, types and enum members**, with module-graph awareness, monorepo support and `--fix`. Agents generate dead code faster than humans due to rapid iteration.

**51. Vulture** — https://github.com/jendrikseipp/vulture
Python dead code via AST with a **confidence score** (60–100%) so you can triage framework-invoked false positives. `vulture src/ --min-confidence 80`.

**52. ts-prune** — https://github.com/nadeesha/ts-prune · **depcheck** — https://github.com/depcheck/depcheck
Narrower, simpler, faster. ts-prune is in maintenance mode — use Knip for new work.

**53. Ruff** — https://github.com/astral-sh/ruff
Rust, 100–155× faster than Flake8, replaces Flake8 + Black + isort + bandit. Catches unused imports/variables per-file on every save. Also available as an Agent Skill so the agent self-corrects.

**54. Biome** — https://github.com/biomejs/biome · **Oxlint** — https://github.com/oxc-project/oxc
Rust JS/TS tooling. Biome = linter + formatter in one (~200 curated rules); Oxlint = fastest linter available (787 rules, 50–100× ESLint, type-aware via tsgo in 2026). Run Oxlint as a pre-check ahead of ESLint on large repos.

**55. MegaLinter** — https://github.com/oxsecurity/megalinter · **super-linter** — https://github.com/super-linter/super-linter
Aggregate 60+ languages and 100+ linters in one CI step, both bundling jscpd. MegaLinter is the more featureful fork (flavors, auto-fix, reports) and is explicitly "compliant with most Coding Agents."

---

# CLUSTER H — Provenance, licence & plagiarism
*"LLMs, by design, do not track provenance." — AboutCode, after an agent ported ScanCode to Rust and stripped every copyright header, extending the violation to dozens of upstream projects.*

**56. ⭐ ScanCode Toolkit** — https://github.com/aboutcode-org/scancode-toolkit
Apache-2.0. The reference licence-detection engine — full red-line comparison against a licence-text database rather than regex or probabilistic matching. Detects licences, copyrights, package manifests and dependencies in source *and* binaries. The AboutCode team's own recommendation after being on the receiving end: **run licence compliance tooling routinely against AI-generated contributions.**

**57. ⭐ Vendetect (Trail of Bits)** — https://github.com/trailofbits/vendetect
AGPL-3.0. Detects copied and vendored code between repositories using **semantic fingerprinting** (winnowing) that survives renamed variables and stripped comments — and, unlike academic plagiarism detectors, **understands git history so it identifies the exact source commit**. That matters twice: attribution, and knowing whether you inherited a pre-disclosure vulnerability. `pip install vendetect`; ran the Cheating-Daddy/Glass case in ~10 seconds.

**58. stf-plagicheck** — https://github.com/Software-Transparency-Foundation/stf-plagicheck
Winnowing fingerprints + snippet matching against the osskb open dataset — checks agent output against the whole known OSS corpus, not just one suspected source.

**59. FOSSology** — https://github.com/fossology/fossology
Linux Foundation. Licence/copyright/export-control scanning with a database, web UI and compliance workflows — the option when you need an auditable process, not just a CLI.

**60. REUSE tool (FSFE)** — https://github.com/fsfe/reuse-tool
Checks and *annotates* source files with SPDX identifiers, making licence and copyright machine-readable — the post-processing step the AboutCode article says is missing from agent pipelines.

**61. LicenseFinder** — https://github.com/pivotal/LicenseFinder · **ORT** — https://github.com/oss-review-toolkit/ort
Policy allowlists and full compliance orchestration respectively.

---

# CLUSTER I — Free & open-source AI PR reviewers (self-hosted, BYO-key)
*Where the LLM layer belongs. Every entry runs on your own key or your own hardware.*

**62. ⭐ PR-Agent** — https://github.com/The-PR-Agent/pr-agent · docs: https://docs.pr-agent.ai
Apache-2.0, ~11k★, 200 contributors. **Donated by Qodo to a community-owned org in April 2026 and relicensed Apache 2.0.** `/describe`, `/review`, `/improve`, `/ask`, each a single LLM call (~30s, low cost), PR-compression for huge diffs, and the broadest forge support anywhere: GitHub, GitLab, Bitbucket, **Gitea, Gerrit**, Azure DevOps, AWS CodeCommit, local. Works with Ollama. The default free choice.

**63. ⭐ Kodus / Kody** — https://github.com/kodustech/kodus-ai
AGPLv3. Hybrid **AST rule engine feeds deterministic context to the LLM** to suppress hallucination — architecturally the right design. Docker Compose self-host, BYO key with **zero markup**, natural-language Kody Rules in `.kody/rules/*.md` with path-glob scoping that **auto-detects existing `.cursorrules`, `CLAUDE.md`, `.windsurfrules` and Copilot instruction files**. GitHub/GitLab/Bitbucket/Azure DevOps.

**64. ⭐ anthropics/claude-code-action** — https://github.com/anthropics/claude-code-action
Free to self-host; you pay only API tokens (pennies per review). Write the review prompt directly in YAML, inline comments via the `mcp__github_inline_comment` MCP server, works on Bedrock/Vertex. Practitioner tip repeated across Reddit and HN: **scope the prompt to one concern per pass** — asking it to catch everything at once destroys signal.

**65. ⭐ Anthropic Code Review plugin** — https://github.com/anthropics/claude-code/tree/main/plugins/code-review
Official, free. `/code-review` launches **4 parallel agents** (two on CLAUDE.md compliance, one on bugs, one on git-blame history), applies **confidence scoring with an 80 threshold** to filter false positives, and auto-skips draft/trivial/already-reviewed PRs. `--comment` posts to the PR.

**66. 💎 anthroos/claude-code-review-skill** — https://github.com/anthroos/claude-code-review-skill
MIT. **280+ checks across 15 categories**, confidence scoring ≥70, **git blame analysis to skip pre-existing issues**, auto-skip logic, language-specific checks (React/TS/Python/Node), severity and focus filters. Runs locally. Explicitly positioned against CodeRabbit's ~50 checks at $15–30/user/mo.

**67. 💎 OpenRabbit** — https://github.com/aryanbrite/openrabbit
Apache-2.0. Runs **entirely in GitHub Actions** — no dashboard, no SaaS layer, code never leaves your runner. Free models via OpenRouter/Groq. Notable features: **DRIFT detection** (flags changes unrelated to the PR's purpose — the classic agent failure), suggestion validation against actual code, "Socratic Scaffold" mentor mode, and a security auditor that ignores the PR description first to avoid bias. The author is refreshingly candid that the tool itself was largely agent-written and tested against 100+ adversarial PRs.

**68. presubmit/ai-reviewer** — https://github.com/presubmit/ai-reviewer
The most-recommended lightweight OSS reviewer in practitioner threads, BYO model, engineered specifically against comment spam.

**69. ⭐ Nikita-Filonov/ai-review** — https://github.com/Nikita-Filonov/ai-review
The widest matrix in this cluster: **GitHub, GitLab, Bitbucket Cloud, Bitbucket Server, Azure DevOps and Gitea** × **OpenAI, Claude, Gemini, Ollama, Bedrock, OpenRouter, Azure OpenAI**. Inline/context/summary review modes, agent mode for iterative repo exploration, customisable prompts. Fully offline with Ollama.

**70. Gito** — https://github.com/Nayjest/Gito
Open-source reviewer via GitHub Actions with parallel processing, Linear/Jira context ingestion, PR-comment-triggered auto-fix, local CLI, and coverage beyond style into **performance, accessibility and security**.

**71. Vercel OpenReview** — https://github.com/vercel-labs/openreview
MIT. Reviews inside a **Vercel Sandbox with full repo access** — it actually runs your linters, formatters and tests, then commits fixes. Durable workflows, extensible `.agents/skills/`.

**72. git-lrc (Hexmos)** — https://github.com/HexmosTech/git-lrc
Free, unlimited, BYO Gemini key (generous free tier). Hooks `git commit` and reviews the staged diff **before it lands** — opening a GitHub-style diff in the browser with inline comments and severity tags. Built explicitly because "AI agents silently remove logic, change behavior, and introduce bugs." Records `review / vouch / skip` state **into git log**, so review becomes part of authorship. Also ships `claude-lrc` for Claude Code.

**73. anthropic-gitea-bot** — https://github.com/tmseidel/anthropic-gitea-bot · **TerraScan** — https://spaceterran.com/posts/terrascan-self-hosted-ai-code-review-gitea/
Gitea AI review — the ecosystem the commercial vendors ignore entirely. Both Docker, both support Ollama for 100% self-hosted operation.

**74. ThinkReview** — https://github.com/Thinkode/thinkreview-browser-extension
AGPL-3.0 browser extension adding AI review into GitHub, GitLab, Azure DevOps and Bitbucket pages **including on-prem instances**, with an **Ollama option so review runs on your own machine**, and IDE deeplinks turning a finding into a ready-to-run Cursor/Claude Code/Copilot prompt. No repo permissions required.

**75. villesau/ai-codereviewer** — https://github.com/villesau/ai-codereviewer · **cirolini/genai-code-review** — https://github.com/cirolini/genai-code-review · **sshnaidm/gpt-code-review-action** — https://github.com/sshnaidm/gpt-code-review-action
The three most-forked minimal GitHub Actions. villesau has the largest community (~1k★, 880 forks) but is unmaintained since 2023 with a deprecated pinned model — fork it rather than depend on it. sshnaidm's is actively maintained with a custom-prompt input.

---

# CLUSTER J — Runtime, fuzzing & execution-verified review
*The only category that proves behaviour rather than inferring it.*

**76. ⭐ Buttercup (Trail of Bits)** — https://github.com/trailofbits/buttercup
Open source. **Won 2nd place ($3M) in DARPA's AI Cyber Challenge**, autonomously finding 28 vulnerabilities across 20 CWEs and deploying 19 patches at **90% accuracy** — using only non-reasoning LLMs. Pairs static analysis with AI-guided fuzzing, **reproduces and proves every bug before reporting it**, then verifies each generated patch closes the bug without breaking the build. Runs from a laptop to a K8s cluster.

**77. ⭐ OpenAnt (Knostic)** — https://github.com/knostic/OpenAnt
Apache-2.0, 704★. Explicitly "Claude Code Security, but free." Three-stage pipeline: decompose the codebase into self-contained units filtered by reachability from external entry points (**cutting analysis surface up to 97%**), then **adversarial verification** where the model simulates a constrained attacker, then **dynamic verification** generating and executing exploits in sandboxed containers. "Stage 1 detects. Stage 2 attacks. What survives is real." Paper: arXiv 2606.19149.

**78. AFL++ / libFuzzer / OSS-Fuzz** — https://github.com/AFLplusplus/AFLplusplus · https://github.com/google/oss-fuzz
The coverage-guided fuzzing baseline. OSS-Fuzz is free continuous fuzzing for qualifying open-source projects.

**79. Atheris** — https://github.com/google/atheris (Python) · **jazzer.js** — https://github.com/CodeIntelligenceTesting/jazzer.js (Node)
Apache-2.0 coverage-guided fuzzing for the interpreted ecosystems agents most often write in.

**80. Playwright** — https://github.com/microsoft/playwright
Free, MIT. Full E2E verification with AI-assisted test generation added in 2026. The free way to check that the agent's feature actually works in a browser rather than merely compiling.

---

# CLUSTER K — Agent-specific security (MCP, tool calls, prompt injection)
*An attack surface that did not exist two years ago. Almost entirely served by free tools.*

**81. ⭐ diplomat-agent** — https://github.com/Diplomat-ai/diplomat-agent
Apache-2.0. Static scanner mapping every function in your agent that can **change the real world** (DB writes, HTTP calls, deletes, payments) and reporting which have zero guards. Their scan of 16 agent repos found **76% of side-effecting tool calls had no protective checks** (Skyvern 76%, Dify 75%, CrewAI 78%, PraisonAI 89%). `pip install diplomat-agent && diplomat-agent .` — 2–3 seconds on 1,000 files, zero config, `--fail-on-unchecked` for CI, commit `toolcalls.yaml` as a baseline so only new findings block.

**82. ⭐ Project CodeGuard (OASIS/CoSAI)** — https://github.com/cosai-oasis/project-codeguard
Model-agnostic security rules and Agent Skills that embed secure-by-default practices into agent workflows, with translators for popular agents and validators to test rule compliance. Vendor-neutral standards body backing.

**83. mcp-scanner** — https://github.com/oabraham1/mcp-scanner
Auto-discovers MCP servers from Claude Desktop, Cursor, Windsurf and VS Code, then scans for prompt injection in tool descriptions, overly broad permissions, missing auth on remote servers, and **suspicious changes to tools over time** (rug-pull detection). `brew install oabraham1/tap/mcp-scanner`.

**84. mcp-security-audit** — https://github.com/LuciferForge/mcp-security-audit
MIT. Classifies every tool SHELL/FILE/DATABASE/NETWORK/SAFE, scans descriptions against **75 injection patterns across 9 categories**, flags sensitive resource URIs, warns when >50% of tools are high-risk, and scores 0–100 with an A–F grade. Runs as a CLI *or* as an MCP server so agents can audit other servers.

**85. mcp-security-scanner** — https://github.com/badchars/mcp-security-scanner
MIT. **55 tools across 6 categories** — runtime inspection, AST-based SAST, config audit, dependency analysis, fuzz testing, OWASP MCP Top 10 compliance scoring. 100% local, zero external API calls.

**86. Proximity (+ NOVA)** — https://github.com/fr0gger/Proximity
Probes remote or local MCP servers to enumerate exposed prompts, tools and resources, and pairs with the NOVA rule engine to detect prompt injection and jailbreak content in tool descriptions **before deployment**.

**87. mcps-audit** — https://github.com/razashariff/mcps-audit
Scans JS/TS/Python MCP server code against **OWASP MCP Top 10 and OWASP Agentic AI Top 10**, generating a PDF audit with severity ratings and compliance matrices. `npm i -g mcps-audit`.

**88. Microsoft Agent Governance Toolkit** — https://github.com/microsoft/agent-governance-toolkit
Policy enforcement, zero-trust identity, execution sandboxing and SRE for autonomous agents, covering 10/10 OWASP Agentic Top 10. `agt red-team scan ./prompts/ --min-grade B`. Python/TS/.NET/Rust/Go SDKs plus a Claude Code plugin.

**89. promptfoo** — https://github.com/promptfoo/promptfoo (MIT, 22k★) · **garak (NVIDIA)** — https://github.com/NVIDIA/garak (Apache-2.0, 8.1k★) · **PyRIT (Microsoft)** — https://github.com/Azure/PyRIT
Red-teaming. garak = 120+ probe modules against model endpoints. promptfoo = 50+ vulnerability types against the **whole application** including RAG and agent tool-use, with OWASP/NIST/MITRE ATLAS mapping and CI regression tests. PyRIT = multi-turn attack chains. Note the Microsoft advisory in the research: apply the **Agents Rule of Two** — never let a workflow simultaneously process untrusted input, hold secrets, and change state.

---

# CLUSTER L — Secrets & supply-chain scanning
*Agents hardcode credentials in the wrong files and leak them into context windows.*

**90. ⭐ TruffleHog** — https://github.com/trufflesecurity/trufflehog
AGPL-3.0. Unique differentiator: **live verification** — it authenticates the found credential against the provider (700+ types) to confirm it's active, collapsing the false-positive triage problem. Scans git history, filesystems, S3, Docker, GitHub orgs, Jira.

**91. Gitleaks** — https://github.com/gitleaks/gitleaks
MIT, 27.7k★. The fastest pre-commit gate. SARIF/JSON/CSV/JUnit output, composite rules, baselines, official GitHub Action.

**92. 💎 Betterleaks** — https://github.com/betterleaks/betterleaks
MIT. By Zach Rice, the original Gitleaks author. Regex + BPE token efficiency + CEL rules, and — the reason it's here — **flag-based output control designed so AI coding agents can run it as a subprocess without burning tokens**. Purpose-built for the agent era.

**93. detect-secrets (Yelp)** — https://github.com/Yelp/detect-secrets
Apache-2.0. **Baseline-first**: snapshot existing secrets so enforcement applies only to *new* ones. The pragmatic path for legacy repos.

**94. Noseyparker** — https://github.com/praetorian-inc/noseyparker · **ripsecrets** — https://github.com/sirwart/ripsecrets
Rust. Noseyparker for terabyte-scale history sweeps; ripsecrets for minimal pre-commit latency.

**95. ggshield** — https://github.com/GitGuardian/ggshield
MIT CLI (free tier up to 25 devs on the platform). Strong pre-commit ergonomics and developer-friendly output.

**96. ⭐ Microsoft Presidio** — https://github.com/microsoft/presidio
MIT, ~10.4k★. Detects, redacts and anonymises PII/PHI in text, images and structured data — increasingly used as the **guard on what goes into an agent's context window** and its logs. Analyzer, Anonymizer, Image Redactor, CLI; regex + NER + checksums + context; extensible with custom recognizers.

**97. Syft + Grype (Anchore)** — https://github.com/anchore/syft · https://github.com/anchore/grype
Apache-2.0, 9.1k★ / 12.4k★. Syft generates SPDX/CycloneDX SBOMs offline; Grype rescans that SBOM as databases update without needing the original image. Signed attestations via in-toto.

**98. Dependency-Track** — https://github.com/DependencyTrack/dependency-track · **pip-audit** — https://github.com/pypa/pip-audit · **cargo-audit** — https://github.com/rustsec/rustsec · **bundler-audit** — https://github.com/rubysec/bundler-audit · **Retire.js** — https://github.com/RetireJS/retire.js
Continuous SBOM monitoring plus ecosystem-native scanners, which produce fewer false positives inside their own language than general-purpose tools.

---

# CLUSTER M — Deterministic SAST & multi-model independence
*"The AI that wrote the code shouldn't be the one reviewing it — it has the same blind spots in both directions."*

**99. ⭐ Semgrep CE / ⭐ Opengrep / CodeQL / SonarQube Community Build**
- **Semgrep CE** — https://github.com/semgrep/semgrep (LGPL-2.1, 30+ languages, ~10s median CI scan, code never uploaded)
- **⭐ Opengrep** — https://github.com/opengrep/opengrep — the **January 2025 community fork** governed by a consortium of 10+ AppSec vendors (Aikido, Endor Labs, Jit, Orca) that **restores cross-function taint analysis, inter-procedural scanning, fingerprinting and Windows support** which Semgrep moved behind its commercial tier. Drop-in rule-compatible. **Strictly more capable than Semgrep CE and permanently free.**
- **CodeQL** — https://codeql.github.com — free for public repos and the CLI is free for OSS; semantic queries over a database of your code, the deepest free dataflow analysis available (95% SQLi detection).
- **SonarQube Community Build** — https://github.com/SonarSource/sonarqube — free self-hosted, 40+ languages. Caveat worth knowing: **no branch analysis or PR decoration** in the free tier, so pair with Reviewdog (#31) or use SonarQube Cloud Free for public repos.

**100. ⭐ Multi-model consensus & independence tooling**
The structural answer to reviewer independence, all free:
- **masoncl/review-prompts** — https://github.com/masoncl/review-prompts — 826★. Chris Mason's (btrfs maintainer) production kernel/systemd/iproute review prompts with subsystem knowledge and bug-pattern files. Cited on HN as the difference between "useless generic agent" and "extremely valuable." The best free prompt library in existence.
- **masoncl/kres** — https://github.com/masoncl/kres — multi-agent REPL for auditing large C codebases with fast/slow/todo/merger agent roles and cumulative deduplicated findings.
- **codeguard-action** — MIT GitHub Action doing **risk-tiered triage** (L0 auto-approve → L4 mandatory human sign-off) running multi-model review proportional to risk, producing a hash-chained cryptographic evidence bundle. Directly addresses "10× code volume, flat reviewer count."
- **AltimateAI/claude-consensus** — https://github.com/AltimateAI/claude-consensus — MIT multi-model consensus review plugin.
- **adversarial-review** — https://github.com/marketplace/actions/adversarial-review — Optimizer vs Skeptic agent pairs behind a cost gate, escalating to dual-model only above a risk score, then verifying its own fixes.
- **trailofbits/skills** — https://github.com/trailofbits/skills — free Claude Code/Codex marketplace with `differential-review`, `c-review`, `rust-review`, `fp-check` (false-positive verification with mandatory gate reviews), `mutation-testing`, `property-based-testing`, `second-opinion` (runs review via *external* LLM CLIs — literal model independence), `supply-chain-risk-auditor`. Written by a top-tier security firm, free.

---

## The recommended free stack

Layered by when it runs. Everything below is free.

**1 — Agent runtime (before code exists)**
`AgentGuard` (#1) hook + `Aikido Safe Chain` (#2) + `pnpm minimum-release-age` (#7). Blocks hallucinated/malicious packages at the moment of install.

**2 — Pre-commit (< 10 seconds)**
`Lefthook` (#32) running `Gitleaks`/`Betterleaks` (#91/#92), `Ruff`/`Biome`/`Oxlint` (#53/#54), and `slopcheck` (#3). Tell the agent in CLAUDE.md never to use `--no-verify`.

**3 — Pre-push (< 2 minutes)**
`tsc --noEmit` / `basedpyright` strict (#10/#12), `Knip`/`Vulture` (#50/#51), `jscpd` (#48), unit tests.

**4 — PR-time deterministic**
`Opengrep` (#99), `OSV-Scanner` (#5), `diff-cover` (#27), `ArchUnit`/`dependency-cruiser`/`Tach` (#40/#41/#43), `Danger` policy (#30) — all surfaced inline via `Reviewdog` (#31).

**5 — PR-time LLM (one, on a different model than wrote the code)**
`PR-Agent` (#62) or `Kodus` (#63) or `claude-code-action` (#64), primed with `masoncl/review-prompts`-style project prompts (#100) and `Repomix` context (#36).

**6 — Merge gate**
`OPA/Conftest` (#29): diff coverage ≥ threshold, **no unreviewed test deletions**, mutation score ≥ threshold, no CRITICAL findings.

**7 — Nightly / weekly**
`Stryker`/`PIT`/`mutmut`/`cargo-mutants` (#17–22) full run, `TruffleHog` verified history sweep (#90), `ScanCode` + `Vendetect` provenance (#56/#57), `OpenAnt` or `Buttercup` deep security pass (#77/#76).

---

## Where free genuinely beats paid

| Need | Free winner | Beats |
|---|---|---|
| Cross-function taint analysis | **Opengrep** (#99) | Semgrep CE — the fork *restores* features Semgrep paywalled |
| Hallucinated-package defence | **AgentGuard** (#1), **slopcheck** (#3) | No major paid AI reviewer checks registry existence |
| Test-quality verification | **Stryker / PIT / cargo-mutants** (#17–20) | No paid AI reviewer runs mutation testing |
| Provenance & attribution | **ScanCode** (#56), **Vendetect** (#57) | Reference implementations; commercial tools license them |
| Clone detection | **jscpd** (#48) | Powers Codacy's duplication engine — use it directly |
| Interprocedural null/leak/race | **Infer** (#16) | Meta-grade analysis, MIT, differential mode built for PRs |
| Prompt library quality | **masoncl/review-prompts** (#100) | Practitioner consensus: better than generic vendor agents |
| MCP security | **#83–#88** | Category is almost entirely open source |
| Proven vulnerability discovery | **Buttercup** (#76), **OpenAnt** (#77) | DARPA-prize-winning; free |

## Honest limitations

- **Free LLM reviewers are not free to run.** You pay API tokens (~pennies per PR) or host a model. The software licence is the free part.
- **Self-hosting costs engineering time.** DX's analysis puts self-hosted AI tooling at $100K–$500K all-in for 50–200 devs once GPU, setup and 0.25–0.5 FTE maintenance are counted. For most teams a BYO-key SaaS-free tool (#62–#64) is the honest optimum, not a local model.
- **SonarQube Community Build has no PR decoration** — a real gap; pair with Reviewdog.
- **Mutation testing is slow.** Run incrementally on changed files per-PR, full suite nightly.
- **No open-source tool matched commercial cross-service architectural reasoning** in Augment's 450K-file monorepo test. Deterministic tools plus one good LLM reviewer close most, not all, of the gap.
- **Benchmarks are unreliable.** SWE-bench Verified is saturated and contaminated (80% there vs 23% on SWE-bench Pro); OpenAI retired it as a frontier eval. SM-100 is the more honest signal for maintenance/review ability.

---

*100 tools · all free, open-source, or with a genuinely usable free tier · every entry with an explicit URL · compiled from 62 search queries across GitHub, Reddit, Hacker News, X and the open web.*
