# Top AI Code Review Tools — 250 Entries, Ranked by Uniqueness, Clustered by Similarity

> **DOCUMENT STATUS — updated 5 November 2026.** Three parts, 250 entries, every one with an explicit URL:
> - **Part I (#1–100)** — compiled 15 Aug 2026 · 64 English queries · clustered A–L.
> - **Part II (#101–200)** — appended Aug 2026 · 68 Chinese + English queries · clustered M–Y.
> - **Part III (#201–250)** — **appended 5 Nov 2026** · **104 new queries** in English, Chinese and Japanese · 14 new clusters (AA–AN) · **plus a full errata sheet (§3.3) for every Part I/II entry that changed, retired or was repriced after 15 Aug 2026**, new benchmark and telemetry numbers (§3.4), the 2026 security delta (§3.5), funding/M&A/pricing (§3.6) and a revised playbook (§3.7).
>
> **If you read only one section, read Part III §3.1 and §3.3** — the thirteen shifts since August, and the errata.

**Originally compiled:** 15 August 2026 · **Method:** 64 English web searches across vendor sites, comparison roundups, benchmarks (Martian Code Review Bench, 118-bug benchmark, SM-100), GitHub/Product Hunt/YC launches, marketplaces and AppSec directories.

**How to read this document**

- **Uniqueness Rank (#1 = most unique):** how structurally different a tool's *approach* is from the median "LLM reads the diff and comments on the PR" product. Rank is **not** quality, accuracy or popularity — CodeRabbit is the most-installed tool on GitHub yet sits mid-table because its architecture is now the industry default.
- **Clusters (A–L):** tools grouped by what they actually *do*, so you can pick one per cluster instead of evaluating 100 lookalikes.
- Every entry lists an explicit URL.

---

## Contents

| Cluster | Theme | Entries |
|---|---|---|
| A | Runtime / execution-verified review | 4 |
| B | Graph, AST & program-analysis-first review | 9 |
| C | Detect → fix → validate closed-loop agents | 11 |
| D | Full-codebase-context PR reviewers | 9 |
| E | AI-native SAST & agentic code security | 15 |
| F | Autonomous security remediation (fix-PR factories) | 5 |
| G | Rules / policy-as-code review engines | 8 |
| H | Open source & self-hosted reviewers | 11 |
| I | Platform-native reviewers (Git host / cloud / IDE vendor) | 10 |
| J | Coding agents & IDE suites with review modes | 9 |
| K | Classic static analysis retrofitted with AI | 7 |
| L | Human-in-the-loop, analytics & adjacent review layers | 7 |
| — | **Total** | **100** |

---

# TIER 1 — MOST UNIQUE (#1–20)

Structurally novel approaches: they review something other than the text of a diff.

## Cluster A — Runtime / execution-verified review
*They run the code before judging it. Rarest architecture in the market.*

**#1 · Ito** — https://www.ito.ai
Spins up an ephemeral single-use container per PR, seeds data, drives the app with a swarm of agents (clicks, API calls, DB verification), and posts video/logs/screenshots as runtime evidence. Catches concurrency, migration and auth failures no static reviewer can see. First 100 reviews free, then ~$40/mo; free forever for OSS. Launched 2026 by an 8-engineer MIT team.

**#2 · Bismuth** — https://www.bismuth.sh
LLM-driven **fuzzing** plus custom code-graph search, and author of the **SM-100** maintenance benchmark that showed most agents find only ~7% of real bugs with 90%+ false positives. Delivers regression-tested PRs, not just comments. https://aiagentsdirectory.com/agent/bismuth

**#3 · Sentry AI Code Review (Prevent AI + Seer)** — https://docs.sentry.io/product/ai-in-sentry/sentry-prevent-ai/
The only reviewer wired to **production telemetry**: pulls your existing Sentry error and performance issues and predicts whether this diff will reproduce them live. Adds flaky-test detection via Test Analytics. `@sentry review` in any PR.

**#4 · Vercel OpenReview** — https://github.com/vercel-labs/openreview
Open-source (MIT), self-hosted bot that reviews inside a **Vercel Sandbox with full repo access** — it can actually run your linters, formatters and tests, then commit fixes back. Built on Vercel Workflow + Claude Sonnet. https://openreview.labs.vercel.dev

## Cluster B — Graph, AST & program-analysis-first review
*The LLM is downstream of a deterministic code model, not the other way round.*

**#5 · Metabob** — https://metabob.com
**Graph Neural Networks** over an extended AST, seeded with BERTopic topic modelling and trained on millions of human bug fixes, with an LLM only for explanation. Targets non-deterministic faults — race conditions, memory leaks, unhandled edge cases. Nothing else on this list uses GNNs.

**#6 · CodeScene** — https://codescene.com
**Behavioural code analysis**: mines version-control history (change frequency, hotspots, author coupling) rather than the code alone. Its **CodeHealth™** score is a validated statistical model tied to defect rates and delivery cost, exposed via an MCP server that forces AI agents into self-correcting refactor loops. https://codescene.com/product/code-health-mcp

**#7 · Macroscope** — https://macroscope.com/ai-code-review
Builds a graph-based reference model of the whole codebase; independent 118-bug benchmark: **48% detection at 98% precision, ~2.55 comments per PR** — the low-noise leader. Pure usage-based pricing ($0.05/KB, ~$0.95/review), no seats. Includes "Fix It For Me" and Check Run Agents. GitHub only.

**#8 · Kodus / Kody** — https://kodus.io · repo: https://github.com/kodustech/kodus-ai
Hybrid **AST rule engine feeds deterministic context into the LLM** to suppress hallucination, wrapped in an AGPLv3 open-source core, Docker-Compose self-hosting, BYO-key with **zero markup on LLM costs**. Rare combination of architecture + licensing + economics.

**#9 · Endor Labs AI SAST** — https://www.endorlabs.com
**Multi-modal**: syntax + dataflow + LLM reasoning, orchestrated as detection / triage / remediation agents over a proprietary Code API, applying the expensive model only where semantic depth is needed. Reports 95% false-positive elimination; 40+ languages. https://www.prnewswire.com/news-releases/endor-labs-debuts-ai-native-multi-modal-sast-marking-a-new-era-in-code-flaw-detection-302619629.html

**#10 · DryRun Security** — https://www.dryrun.security
**Contextual Security Analysis (CSA)** — no pattern rules at all; reasons about authentication, authorization, sensitive codepaths, authorship intent and code brittleness. Detected **88% of seeded vulnerabilities** in the 2025 SAST Accuracy Report, beating five leading SAST tools on logic and authz flaws. Adds a Code Insights MCP server.

## Cluster C — Detect → fix → validate closed-loop agents (opening entries)
*Reviewing is only step one; the loop closes when CI goes green.*

**#11 · Gitar** — https://gitar.ai
The only reviewer that **diagnoses CI failures, applies the fix, and re-validates it against your own pipeline before committing**. Also retries flaky tests and implements reviewer feedback; collapses everything into one updating comment. Free review tier, unlimited repos; **acquired by Sonar** (2026). https://www.producthunt.com/products/gitar

**#12 · Cursor Bugbot** — https://cursor.com/bugbot
8-pass majority voting for noise suppression, **Learned Rules** distilled from developer downvotes and human reviewer comments, MCP server support, autofix VMs, plus `/review-bugbot` locally *before* push that de-duplicates against the remote PR review. ~70–80% of raised issues get resolved. Docs: https://cursor.com/docs/bugbot

**#13 · Claude Code Review** — https://www.anthropic.com/claude-code
Managed multi-agent PR reviewer (launched March 2026): **9 parallel specialised sub-agents**, a cross-verification pass that filters false positives, findings ranked by severity. Lowest missed-bug rate observed; also the most expensive at $15–25 per review, Team/Enterprise only.

**#14 · Tembo** — https://www.tembo.io
Event-driven **automation platform** rather than a bot: natural-language (Notion-style, no YAML) automations trigger on PRs, Sentry errors, Linear issues, schedules or webhooks, coordinate PRs across multiple repos, and are agent-agnostic (Claude Code, Cursor, Codex, Amp). From $60/mo.

**#15 · cubic** — https://www.cubic.dev
"Cursor for code review" (YC 2026). Two-sided: an AI reviewer that navigates the codebase with developer-grade tools in a torn-down sandbox, **plus a Linear/Superhuman-inspired human review client** (web + desktop, keyboard-first) with AI-sorted diffs grouped logically rather than alphabetically. Used by Cal.com, n8n, Linux Foundation.

**#16 · ZeroPath** — https://zeropath.com
Combines LLMs with AST analysis, then **"Zero"** turns plain-English instructions into standing AppSec workflows: bulk-patch the top 5 critical SCA findings across repos, open PRs, file Linear tickets, ping owners in Slack, escalate to the CISO after an hour. 750+ companies, 125k+ scans/month. https://zeropath.com/blog/introducing-zero

**#17 · Greptile** — https://www.greptile.com
Repository-wide indexing into a **knowledge graph** with a swarm of agents per PR; **82% bug catch rate** (highest single-pass detection published) at the cost of ~11 false positives per run. Custom rules in plain English, Mermaid architecture diagrams, learns from PR comments *and emoji reactions*. $30/seat + $1 overage after 50 reviews.

**#18 · Baz** — https://baz.co
**Behaviour-aware, contract-oriented** review: focuses on breaking changes and API/contract violations plus deep change-impact analysis and CI-log-derived insight, rather than line-level nitpicks. Trust centre: https://trust.baz.co

**#19 · Semgrep Assistant** — https://semgrep.dev/products/semgrep-code/assistant/
**Memories**: triage a finding once and the decision permanently suppresses that class of false positive org-wide. Adds AI component tags (payments, auth, infra) for risk-weighted prioritisation. Security researchers agree with its calls 96% of the time; ~20% triage reduction on day one, 8+ hours/week saved per security engineer.

**#20 · Codacy Guardrails** — https://www.codacy.com/quality
Inverts the timeline: deterministic analysis runs **inside the agent's generation loop**, silently auto-repairing violations in AI-written code *before the developer ever sees it*. Ships as an IDE/MCP layer across Copilot, Cursor and Claude. 15,000 orgs, 200,000 developers. IDE extension: https://github.com/codacy/codacy-vscode-extension

---

# TIER 2 — STRONGLY DIFFERENTIATED (#21–45)

## Cluster D — Full-codebase-context PR reviewers

**#21 · Qodo (formerly CodiumAI)** — https://www.qodo.ai
Only major reviewer pairing review with **test generation**, plus **Jira/Linear ticket-compliance scoring** (does this diff actually satisfy the ticket?), 15+ agentic workflows, slash commands, auto-generated rules from PR history, and an Enterprise Context Engine. Self-published 60.1% F1. $30/user/mo Teams; free tier 30 PRs/mo.

**#22 · Augment Code** — https://www.augmentcode.com
**Context Engine** maintains a semantic map of 400,000+ file codebases; the Deep Code Review agent traces cross-repository contracts to flag when a change in one service breaks three others. $20–$200/user/mo.

**#23 · Sourcegraph Amp + Code Review Agent** — https://ampcode.com · GitHub app: https://github.com/sourcegraph/cra-github
Review built on Sourcegraph's enterprise **code graph**, with parallel subagents, Oracle mode and unconstrained token usage. Two deploy modes: GitHub Action or self-hosted webhook service. Free tier without hard token caps.

**#24 · Entelligence AI** — https://www.entelligence.ai
Review plus **self-updating documentation** that refreshes every commit, auto-generated architecture diagrams, and engineering performance analytics. 47.2% F1 on its own bug-detection benchmark; SOC 2 with self-hosted option.

**#25 · Graphite Agent (formerly Diamond)** — https://graphite.com
Review welded to a **stacked-PR + merge-queue** workflow, so the unit of review is a small sequential change rather than a monolith. <5% negative-comment rate; 82% of findings lead to real fixes; free to 100 PRs/month. Product page: https://graphite.dev/features/ai-code-review

**#26 · CodeRabbit** — https://www.coderabbit.ai
The market default and most-installed AI app on GitHub (13M+ PRs, 2M+ repos): PR walkthroughs, inline comments, chat, **40+ integrated linters and scanners**, sandbox testing, VS Code/Cursor/Windsurf extension and a CLI (`curl -fsSL https://cli.coderabbit.ai/install.sh | sh`). Lowest noise in several benchmarks (2 FPs/run) at 44% catch. $24/dev/mo.

**#27 · Optibot (Optimal AI)** — https://getoptimal.ai
Review fused with **delivery analytics**: cycle time, review performance and throughput dashboards, an agent that root-causes failing GitHub Actions and opens a fix PR, plus story-point estimation and predictive-maintenance agents. $15/contributor/mo. Docs: https://docs.getoptimal.ai

**#28 · Korbit AI** — https://www.korbit.ai
Positioned as a **mentor**: explains *how* to fix and why, acting as a training tool for junior developers, with a management dashboard on code quality and developer progress. 22K+ developers; 47% of suggestions get implemented. SOC 2 Type 2.

**#29 · Panto AI** — https://www.getpanto.ai
Pulls **business context from Jira and Confluence** so review checks alignment with product intent, not just code health; reinforcement learning tunes signal-to-noise; 30,000+ security/quality checks, 40+ linters, on-prem option. ~$15–20/dev/mo.

## Cluster C (continued) — Closed-loop agents

**#30 · Ellipsis** — https://www.ellipsis.dev
Dozens of small independently benchmarked agents rather than one big prompt: parallel **comment generators** (custom rules, duplication, etc.), then dedup / confidence / hallucination filters using attached code **Evidence**, mixing GPT and Claude in one review. Tag `@ellipsis-dev` to generate tested code. YC-backed, SOC II. Architecture write-up: https://www.zenml.io/llmops-database/building-and-deploying-production-llm-code-review-agents-architecture-and-best-practices

**#31 · devlo** — https://devlo.ai
Prompt-driven **audit-style** deep reviews run on demand from an editor interface rather than auto-firing on PR events — structured risk/severity/remediation reports instead of inline hygiene. Also resolves tickets and writes unit tests. From $19–39/mo.

**#32 · Recurse ML** — https://www.recurse.ml
Bug- and **breaking-change** specialist with expert third-party library knowledge, usable both as a GitHub PR bot and as a pre-submission check invoked by Claude Code and Cursor. Recurse Rules for team taste. $25/mo. Endorsed by Continue.dev's founder.

**#33 · Aikido Security** — https://www.aikido.dev
AI code review and AppSec in one: **85–95% false-positive reduction**, multi-file taint tracking, AutoFix, dependency reachability with one-click fix PRs, plus VM, host, domain and runtime (Zen firewall) coverage. 50k+ orgs. Flat-rate pricing with a free tier. https://www.aikido.dev/use-cases/secure-your-source-code

**#34 · CodeAnt AI** — https://codeant.ai
Single pass covering AI review + SAST + secrets + IaC **plus an offensive layer of 500+ exploit agents** that re-attack with grey-box knowledge from your codebase. **#3 globally (51.7% F1) on the Martian Code Review Bench** across 300,000 real PRs. DORA dashboards, bulk-fix 200 files. $24/user/mo. Docs: https://docs.codeant.ai/introduction

**#35 · Bito AI Code Review Agent** — https://bito.ai
A **set of specialised engineer personas** (performance, structure, security, optimisation, scalability) whose outputs are merged and filtered; agentic engine cuts false positives 57%. Built on the open Bito Dev Agents framework with a global agent registry. Git + IDE + CLI. $12–15/seat/mo. Docs: https://docs.bito.ai/ai-code-reviews-in-git/overview

## Cluster E — AI-native SAST & agentic code security

**#36 · Cycode** — https://cycode.com/blog/ai-sast/
Runs **three layers simultaneously** — deterministic scanning, LLM-generated deterministic rules, and agentic reasoning from the code itself — routing each finding to the cheapest layer that can handle it. The clearest published taxonomy of AI SAST.

**#37 · Datadog Code Security (Bits AI)** — https://docs.datadoghq.com/security/code_security/static_analysis/ai_enhanced_sast/
AI at four lifecycle stages: **malicious-PR protection** (detecting deliberately hostile diffs from internal or external contributors), LLM taint-analysis detection with a second-LLM verification pass, agentic false-positive filtering, and **Bits Memories** for org-specific sanitiser context. Absorbed Codiga (2023).

**#38 · Snyk Code (DeepCode AI)** — https://snyk.io/product/snyk-code
Hybrid symbolic + ML engine, self-hosted models (no third-party LLM), scans without a build so interpreted languages work natively, ~50x faster than legacy SAST, OWASP Benchmark ~20 points above competitors, 92% detection on AI-generated vulnerability patterns. ~$25/contributing dev.

**#39 · Corgea** — https://corgea.com
AI-native SAST for **business-logic flaws, broken auth and misconfigurations** — the pentest-class bugs pattern matching misses — with a separate, deliberately decoupled **Code Quality Scanner** that excludes security findings entirely to avoid overlap. 11 languages. https://docs.corgea.app/code-quality-scanner

**#40 · Jit** — https://www.jit.io
ASPM built on a **Company Context Graph** mapping repos → cloud → team ownership → business priority, with Core / Pre-Built / Custom agents each running a Plan → Execute → Reflect → Respond loop. Bundles its own SAST, SCA, secrets, IaC, CSPM, DAST and container scanners. https://appsecsanta.com/jit

**#41 · Checkmarx One** — https://checkmarx.com
Enterprise SAST with AI Security Champion remediation and AI-generated-code guardrails; the compliance-mandated default in regulated industries. Very high security depth, no free tier.

**#42 · SonarQube (Sonar)** — https://www.sonarsource.com/products/sonarqube/
750B+ lines analysed daily, 6,500+ rules, 35+ languages, **AI Code Assurance** and AI CodeFix, deterministic quality gates for compliance — and now owner of **Gitar**. Community Build free; Team from ~$32/mo. Cloud: https://www.sonarsource.com/products/sonarcloud/

**#43 · GitHub CodeQL + Code Quality** — https://codeql.github.com
Semantic **query language over a database of your code** — you write queries, not regexes — giving the deepest published dataflow analysis (95% SQLi detection). Now paired with GitHub Code Quality for coverage metrics, one-click Copilot fixes and merge gating.

**#44 · Coverity (Black Duck / formerly Synopsys)** — https://www.blackduck.com/static-analysis-tools-sast/coverity.html
Decades-old interprocedural analysis engine, now with AI-assisted triage and remediation. The safety-critical / regulated-industry incumbent (automotive, aerospace, medical).

**#45 · Veracode Fix** — https://www.veracode.com/fix/
Enterprise SAST/DAST/SCA platform whose AI generates suggested remediations from its own scan findings, geared to compliance evidence and policy gates rather than developer velocity.

---

# TIER 3 — DIFFERENTIATED BY NICHE (#46–70)

## Cluster F — Autonomous security remediation (fix-PR factories)

**#46 · Pixee** — https://www.pixee.ai
Deliberately **generates no alerts** — it consumes other scanners' findings and emits merge-ready fix PRs. Hybrid agentic AI + deterministic **codemods** (open-source `codemodder` framework), 95% FP elimination before a fix is written, SBOM updated in the same commit, ~75–100 fixes in week one. Founded by Contrast Security's co-founder. Two Cyber UXcellence Awards, Black Hat 2025.

**#47 · Mobb** — https://www.mobb.ai
**Patent-pending hybrid**: deterministic semantic analysis constrains the GenAI so fixes are reproducible and free of hallucination/code-ownership concerns. Plugs into Checkmarx, Snyk, Fortify, GitHub findings; one-click PowerUp for recurring vulnerability classes; sub-60-second fixes.

**#48 · Amazon Q Developer** — https://aws.amazon.com/q/developer/
`/q review` in GitHub PRs and `/review` in the IDE, with fixes committable straight to the PR and AWS-best-practice awareness. Successor to the retired Amazon CodeGuru Reviewer. Docs: https://docs.aws.amazon.com/amazonq/latest/qdeveloper-ug/github-code-reviews.html

**#49 · DeepSource** — https://deepsource.com
Five years of deterministic **Autofix™** (≈30% of issues) now extended by **Autofix AI** (nearly all issues, context-aware and idiomatic) plus **Autopilot** agents that open remediation PRs autonomously, and the Narada secrets model at 97% precision. 20+ analyzers, 6,000+ companies incl. NASA. Changelog: https://deepsource.com/changelog/2025-05-27

**#50 · Sourcery** — https://sourcery.ai
Started Python-first refactoring, now 30+ languages with **IDE-first review** (feedback while you type in VS Code, Cursor, Windsurf, JetBrains), bring-your-own-LLM, and a distinctive loop that **investigates Sentry production issues and generates fixes**. 300,000+ developers; from $10–12/seat.

## Cluster G — Rules / policy-as-code review engines

**#51 · wispbit** — https://wispbit.com · skills: https://github.com/wispbit-ai/skills
Publishes its code-quality engine as **versioned, eval-tested Agent Skills** (Claude Code, Cursor) refreshed weekly — rules as a distributable, testable artifact rather than a hidden prompt.

**#52 · Kodus Policy-as-Code** — https://kodus.io/policy-as-code-review/
Rules are **markdown files with YAML frontmatter** in `.kody/rules/`, scoped by path glob with Global → Repo → Directory inheritance, a versioned audit trail (CSV/JSON), auto-generation from 3+ months of PR history, and **auto-detection of existing `.cursorrules`, `CLAUDE.md`, `.windsurfrules` and Copilot instruction files**.

**#53 · Trag** — https://usetrag.com
Self-described "LLM superlinter": every rule is written in plain English, fully language-agnostic, with semantic context-aware analysis (circular references, unused imports), real-time CLI feedback and AI auto-fix PRs.

**#54 · Surmado Code Review** — https://www.surmado.com
**Flat $15/month for 100 PRs** — deliberately rejecting per-seat pricing — with reviews anchored strictly to your written standards rather than generic best practice. GitHub only.

**#55 · CodeReviewr** — https://codereviewr.app
**Active-developer billing**: you pay only for developers who actually opened a PR that month ($8 base + $12 per active dev). A pricing-model innovation more than a technical one.

**#56 · CodeReviewBot** — https://codereviewbot.dev
**Per-repo pricing from $9/mo** (no seats), hard cap of 10 comments per PR to guarantee no spam, force-push deduplication, automatic skipping of lockfiles and generated code, zero config. Also: https://github.com/apps/codereviewbot-ai

**#57 · Callstack.ai Reviewer** — https://callstack.ai/code-reviewer
Modular `.callstack.yml` where each reviewer capability is toggled independently — `bug_hunter`, `code_suggestions`, `code_conventions`, `grammar`, `performance`, `security` — with severity ranking and BYO OpenAI key. Action: https://github.com/marketplace/actions/callstack-ai-reviewer

**#58 · Refacto.ai** — https://refacto.ai
Precision-positioned reviewer explicitly optimised against comment spam, with secrets and vulnerability scanning in every review and a strong published code-review-checklist methodology. Freemium. https://github.com/marketplace/refacto-ai-precise-ai-code-review

## Cluster H — Open source & self-hosted reviewers

**#59 · PR-Agent** — https://github.com/The-PR-Agent/pr-agent · docs: https://docs.pr-agent.ai
The original open-source PR reviewer (~11k stars, 200 contributors). **Donated by Qodo to a community-owned org in April 2026 and reverted to Apache 2.0**, now with its first external maintainer and heading to a foundation. Single-LLM-call tools (`/describe`, `/review`, `/improve`, `/ask`), PR-compression for huge diffs, and the broadest forge support anywhere: GitHub, GitLab, Bitbucket, Gitea, Gerrit, Azure DevOps, AWS CodeCommit, local.

**#60 · presubmit/ai-reviewer** — https://github.com/presubmit/ai-reviewer
The most-recommended lightweight open-source CodeRabbit alternative in practitioner threads; BYO model, explicitly engineered against noisy comment spam.

**#61 · git-lrc** — https://github.com/shrsv/git-lrc
Reviews at the **`git commit` hook**, before code ever reaches a PR: opens a GitHub-style diff in the browser with inline AI comments, severity tags and copy-back-to-your-agent output. Free, unlimited, source-available, 60-second setup.

**#62 · LiveReview (Ollama self-hosted)** — https://livereview.dev
Fully local review via Ollama — no code ever leaves your infrastructure — across GitHub, GitLab and Bitbucket. Guide: https://dev.to/shrsv/secure-self-hosted-ai-code-review-powered-by-ollama-2p55

**#63 · Gito** — https://github.com/Nayjest/Gito
Open-source reviewer that goes beyond style into refactoring opportunities, performance, **accessibility** and security — the accessibility dimension is unusual in a CLI/PR reviewer.

**#64 · QuasarByte LLM Code Review suite** — https://github.com/QuasarByte/llm-code-review-cli
Apache-2.0 **rule-based** LLM review shipped as a Maven plugin, a CLI and an SDK, designed to run fully on-premises against any OpenAI-compatible endpoint. Maven plugin: https://github.com/QuasarByte/llm-code-review-maven-plugin

**#65 · villesau/ai-codereviewer** — https://github.com/villesau/ai-codereviewer
The most-adopted open-source GitHub Action for AI review (~1k stars, 880+ forks) — historically the fastest path to a working reviewer, though unmaintained since 2023 with a now-deprecated pinned model.

**#66 · ai-code-review (Red Hat / Juanje Ojeda)** — https://gitlab.com/redhat/edge/ci-cd/ai-code-review
Modular, well-architected, provider-agnostic reviewer; rated alongside pr-agent as the best open-source option in an independent hands-on comparison. https://www.happyassassin.net/posts/2025/12/16/a-half-assed-assessment-of-open-source-ai-code-review-tools/

**#67 · tmokmss/bedrock-pr-reviewer** — https://github.com/tmokmss/bedrock-pr-reviewer
Amazon Bedrock/Claude fork of the archived CodeRabbit OSS action: **incremental commit-by-commit reviews** with a light summariser model and a heavy review model to control cost.

**#68 · llm-sast-scanner** — https://github.com/SunWeb3Sec/llm-sast-scanner
Distributes SAST capability as an **Agent Skill** for Claude Code and OpenAI Codex: 34 vulnerability classes, structured source→sink taint tracing, and a Judge verification step. Java/Python/JS/TS/PHP/.NET.

**#69 · SAST-AI-Workflow (Red Hat)** — https://github.com/RHEcosystemAppEng/sast-ai-workflow
**LangGraph** agent pipeline (pre_process → filter → investigate → summarize → metrics → write) whose investigate node runs an autonomous ReAct research loop with a reflection/circuit-breaker stage, scored with Ragas metrics. Purpose-built to kill SAST false alarms; proven on RHEL systemd.

**#70 · cirolini/genai-code-review** — https://github.com/cirolini/genai-code-review
Widely-forked (~363 stars) GPT-powered review GitHub Action, a common starting template for in-house reviewers.

---

# TIER 4 — PLATFORM-NATIVE & INCUMBENT (#71–88)

*Highly capable, minimally unique: review is a feature of a larger platform you already pay for.*

## Cluster I — Platform-native reviewers

**#71 · GitHub Copilot Code Review** — https://github.com/features/copilot
Agentic full-repo context gathering, Lite/Balanced effort levels, MCP servers and agent skills read from the **head** branch, delegation of fixes to the Copilot cloud agent, `.github/copilot-instructions.md`, and CLI invocation via `gh pr edit --add-reviewer @copilot`. 54% catch rate, mixed quality. Docs: https://docs.github.com/en/copilot/concepts/agents/code-review

**#72 · GitLab Duo Code Review** — https://docs.gitlab.com/user/project/merge_requests/duo_in_merge_requests/
Assign `@GitLabDuo` as a reviewer; full-file context across all changed files, MR summaries, SAST/DAST vulnerability explanations, suggested reviewers from repo history, and CI/CD pipeline root-cause analysis in one merge widget. Handbook: https://handbook.gitlab.com/handbook/engineering/ai/ai-coding/duo_code_review/

**#73 · Gemini Code Assist for GitHub** — https://developers.google.com/gemini-code-assist/docs/review-github-code
Free-tier-friendly GitHub app: automatic review on PR open with Critical→Low severity labels, plus `/gemini review` and `/gemini summary`. Note the `run-gemini-cli` Action stopped serving on 18 June 2026.

**#74 · Atlassian Rovo Dev** — https://www.atlassian.com/solutions/devops/rovo-dev
Review inside the Atlassian graph — Jira issues, Confluence specs, Bitbucket PRs — for teams whose requirements context lives there. ~$20/mo.

**#75 · JetBrains Qodana** — https://www.jetbrains.com/qodana/
Brings the **JetBrains IDE inspection engine** into CI: 60+ languages, 3,000+ inspections, **baselines** so legacy repos can adopt gates without a big-bang cleanup, quality gates, taint analysis in Ultimate Plus. Free Community edition.

**#76 · OpenAI Codex** — https://openai.com/codex/
Auto-review on every PR plus terminal one-off reviews; GPT-5.6-class models, Terminal-Bench record, cooperative subagents. Review is a side-effect of the agent, not a product.

**#77 · Tabnine Code Review Agent** — https://www.tabnine.com
The only serious **air-gapped** reviewer: zero data retention, SOC 2 Type II + ISO 27001 + GDPR, BYO-LLM, 15+ IDEs, Enterprise Context Engine trained on your own patterns. $39–59/user/mo. Free tier discontinued.

**#78 · Zencoder** — https://zencoder.ai
**Repo Grokking™** codebase indexing across 70+ languages feeding Zen Agents that review GitHub/GitLab PRs; SOC 2 Type II, ISO 27001. From $19/user/mo. Independent review: https://aicodereview.cc/tool/zencoder/

**#79 · Sourcegraph Cody** — https://sourcegraph.com/cody
Cross-**repository** code intelligence (precise go-to-definition and find-references across the whole org graph) applied to review in CI. Enterprise-only at $59/user/mo since the Free/Pro tiers closed in July 2025.

**#80 · Windsurf (formerly Codeium)** — https://windsurf.com
Cascade agent plus a built-in AI code review assistant in an agentic IDE; strongest on large codebases with automatic context retrieval. Gartner Leader.

## Cluster J — Coding agents & IDE suites with review modes

**#81 · Cursor Agent Review** — https://cursor.com/learn/reviewing-testing
Distinct from Bugbot: `@Branch` self-review and Source Control "Agent Review" against main, both local and pre-push.

**#82 · Devin (Cognition)** — https://www.devin.ai
Autonomous engineer with an end-to-end sandboxed environment; reviews and revises its own PRs as part of the task loop.

**#83 · Aider** — https://aider.chat
Open-source terminal pair programmer working directly against git; 72% of its own code is now written by Aider. Review emerges from the edit/commit loop. 46k+ stars.

**#84 · OpenCode** — https://opencode.ai
Fully open-source, offline-capable agent harness supporting 75+ LLM providers — the maximal-sovereignty option for running review with any model.

**#85 · Continue.dev** — https://www.continue.dev
Open-source IDE agent framework for building custom review assistants over your own models and rules.

**#86 · Sweep** — https://sweep.dev
Pivoted from a GitHub issue-to-PR bot to a **JetBrains-first** assistant: next-edit autocomplete, inline agent, AI commit messages and AI code review using JetBrains' internal static analysis. 40k+ installs, 4.9 stars. $10–60/mo. Docs: https://docs.sweep.dev

**#87 · Replit Agent** — https://replit.com/ai
200-minute autonomous runs with self-review inside a hosted environment; strongest for prototyping rather than enterprise review.

**#88 · Capy** — https://capy.ai
Integrated plan → build → review platform where the Review Agent routes findings to the Build agent for an automated fix, then re-reviews the result. Review included in every plan.

---

# TIER 5 — ADJACENT, LEGACY & LOW-DIFFERENTIATION (#89–100)

## Cluster K — Classic static analysis retrofitted with AI

**#89 · Codacy** — https://www.codacy.com
40+ languages, 49-language coverage, quality gates, coverage enforcement, SAST/secrets/dependencies, Gemini-backed AI review. $15–18/dev/mo. (Its Guardrails product is separately ranked at #20.)

**#90 · Qlty** — https://qlty.sh
Built by the **Code Climate founding team** as its spiritual successor: 70+ analysis plugins, 40+ languages, A–F maintainability grading, technical-debt quantification. Qlty CLI free for commercial use; $15/contributor/mo.

**#91 · Code Climate** — https://codeclimate.com
The maintainability-grading pioneer; Quality spun out to Qlty in 2025 and the company pivoted to enterprise SEI/velocity and AI-transformation consulting. Included for migration planning.

**#92 · CodeFactor** — https://www.codefactor.io
Zero-setup automated review on every GitHub/Bitbucket commit and PR, 20+ languages, hotspot ranking by churn × size, autofix limited to specific linters (ESLint, RuboCop, SwiftLint, etc.). Free for OSS.

**#93 · Codiga** — https://www.codiga.io
Custom static analysis rules authored in the browser, IDE + CI + PR review, autofix. **Acquired by Datadog (April 2023)** and folded into Datadog Static Analysis; not accepting standard sign-ups. Historical/migration reference.

**#94 · codebeat** — https://codebeat.co
Automated code review focused on readability and complexity metrics for team collaboration, GitHub/Bitbucket/GitLab. Long-standing, minimal AI.

**#95 · SpotBugs / FindBugs** — https://spotbugs.github.io
Free, open-source Java bytecode bug detector. No AI — included as the deterministic baseline AI reviewers are benchmarked against.

## Cluster L — Human-in-the-loop, analytics & adjacent review layers

**#96 · HackerOne Code (formerly PullRequest)** — https://www.hackerone.com/product/code-security-audit
AI trained on hundreds of millions of lines identifies **Security Hotspots** and the highest-risk changes in real time, then routes them to a network of vetted **human** expert reviewers — with deliberate randomisation for broad spot-checking. Median review 90 minutes, 99% within 24 hours. https://www.pullrequest.com/smart-review-selection/

**#97 · Reviewdog** — https://github.com/reviewdog/reviewdog
Free OSS glue that posts *any* linter's or AI tool's output as PR comments across GitHub, GitLab, Bitbucket and Gerrit. The plumbing layer under many custom AI reviewers.

**#98 · Danger** — https://danger.systems
PR-level policy engine (no AST): enforce "has a changelog entry", "PR is under 500 lines", "tests were touched". The deterministic complement to LLM review.

**#99 · What The Diff** — https://whatthediff.ai
Plain-English PR summaries, changelogs and release notes for non-engineering stakeholders — release *communication* rather than defect detection. ~2,300 tokens per average PR.

**#100 · Pullflow** — https://www.pullflow.com
Review **collaboration** layer connecting GitHub/GitLab, Slack and VS Code, with configurable AI-reviewer notification handling (show all / summarise / hide) — the meta-layer for teams running several of the tools above at once. Entelligence integration: https://www.pullflow.com/blog/entelligenceai/

---

## Notable retirements and moves (do not shortlist)

| Tool | Status | Where to go |
|---|---|---|
| Amazon CodeGuru Reviewer — https://aws.amazon.com/codeguru/ | Closed to new repo associations 7 Nov 2025 | Amazon Q Developer (#48) |
| Codeball / Sturdy — https://github.com/sturdy-dev/codeball-action | Abandoned (Apache-2.0 archive). Scored PRs 0→1 with a model trained on 1M+ PRs to auto-approve safe ones — a genuinely unique idea worth reviving | Macroscope, Graphite |
| CodeRabbit `ai-pr-reviewer` OSS — https://github.com/coderabbitai/ai-pr-reviewer | Archived Nov 2023 | bedrock-pr-reviewer (#67) |
| Codium / CodiumAI | Rebranded late 2024 | Qodo (#21) |
| Codiga | Acquired by Datadog 2023 | Datadog Code Security (#37) |
| Code Climate Quality | Spun out 2025 | Qlty (#90) |
| PullRequest | Acquired by HackerOne | HackerOne Code (#96) |
| Gitar | Acquired by Sonar 2026 | Still shipping standalone (#11) |
| CodeMind | Defunct; domain parked | — |
| `run-gemini-cli` GitHub Action | Stopped serving 18 June 2026 | Gemini Code Assist app (#73) |

---

## Cross-cutting benchmark snapshot

| Tool | Detection | Precision / noise | Source |
|---|---|---|---|
| Greptile | 82% catch | ~11 FP per run | vendor + independent evals |
| Macroscope | 48% (118-bug) | 98% precision, 2.55 comments/PR | 118-bug benchmark |
| CodeRabbit | 44–46% | 2 FP per run — lowest noise among high-volume tools | multiple |
| Cursor BugBot | 42% | ~100% precision, very selective; 70–80% resolution | 118-bug benchmark |
| CodeAnt AI | **#3 globally, 51.7% F1** | — | Martian Code Review Bench (300,000 PRs) |
| Qodo | 60.1% F1 (self-published) | — | vendor |
| GitHub Copilot | 54% | mixed; 31/47 suggestions were ESLint-level | independent |
| Entelligence AI | 47.2% F1 | — | vendor benchmark |
| DryRun Security | 88% of seeded vulns | beat 5 leading SAST tools | 2025 SAST Accuracy Report |
| Graphite Agent | — | <5% negative-comment rate; 82% of findings fixed | vendor |
| Endor Labs AI SAST | 4.5% true positives surfaced | 95% FP elimination | vendor, 5 enterprise pilots |

*Benchmarks are largely vendor-published and mutually inconsistent — treat as directional. The Martian Code Review Bench (300,000 real PRs) and the independent 118-bug benchmark are the two most credible third-party sources currently available.*

---

## Fast selection guide

- **You want proof, not opinion** → Ito (#1), Bismuth (#2), Sentry (#3)
- **Lowest noise** → Macroscope (#7), Cursor Bugbot (#12), Graphite (#25)
- **Highest catch rate, noise tolerated** → Greptile (#17)
- **Fix it, don't just flag it** → Gitar (#11), Pixee (#46), Mobb (#47), DeepSource (#49)
- **Security-first** → DryRun (#10), Endor Labs (#9), Snyk Code (#38), Corgea (#39), Aikido (#33)
- **Air-gapped / sovereign** → Tabnine (#77), Kodus self-hosted (#8), LiveReview+Ollama (#62), QuasarByte (#64)
- **Open source** → PR-Agent (#59), Kodus (#8), OpenReview (#4), presubmit (#60)
- **Escape per-seat pricing** → Macroscope (#7, usage), Surmado (#54, flat), CodeReviewBot (#56, per-repo), CodeReviewr (#55, active-dev)
- **Bitbucket or Azure DevOps** → CodeRabbit (#26), Qodo (#21), CodeAnt (#34), Kodus (#8), Codacy (#89)
- **Human sign-off required by policy** → HackerOne Code (#96)

---
---

# PART II — THE SECOND HUNDRED (#101–200)

**Compiled:** 15 August 2026 · **Method:** a second, independent sweep of **68 search queries in Chinese (简体中文) and English**, deliberately targeting territory Part I did not cover: the Chinese domestic ecosystem (阿里 / 腾讯 / 百度 / 华为 / 字节 / 蚂蚁 / 智谱), Chinese DevSecOps and 信创 compliance vendors, safety-critical and embedded SAST, database/SQL and IaC review, secret and supply-chain scanning, agent skills and MCP servers, browser extensions, and a long tail of open-source PR bots.

**No entry below repeats any of #1–100.** Numbering continues from Part I. Uniqueness ranking restarts within this part (#101 = most structurally distinct of the second hundred) and clustering uses new clusters **M–Y**.

## Contents — Part II

| Cluster | Theme | Entries |
|---|---|---|
| M | Chinese hyperscaler platform reviewers (国内大厂) | 12 |
| N | Chinese DevSecOps & 信创 security vendors | 10 |
| O | Chinese open-source LLM review bots (中文开源) | 9 |
| P | Agent skills, MCP servers & plugin-layer reviewers | 10 |
| Q | Browser-extension & URL-swap reviewers | 4 |
| R | PR comprehension & diff-restructuring tools | 5 |
| S | Autonomous vulnerability hunting | 5 |
| T | Safety-critical & embedded compliance analysis | 9 |
| U | Database, SQL & schema-migration review | 7 |
| V | Infrastructure-as-Code & policy review | 6 |
| W | Secrets & software supply-chain review | 8 |
| X | Long-tail open-source GitHub Actions & CI bots | 10 |
| Y | Adjacent quality, benchmark & meta layers | 5 |
| — | **Total** | **100** |

---

# TIER 1 (Part II) — MOST UNIQUE (#101–125)

## Cluster S — Autonomous vulnerability hunting
*Not "review this diff" — "go find a zero-day nobody knows about."*

**#101 · Vulnhuntr** — https://github.com/protectai/vulnhuntr
The first tool credited with **autonomously discovering real 0-days**: it builds the complete call chain from remote user input to server sink, requesting additional functions/classes from other files each pass until the chain closes, guided by XML-structured chain-of-thought prompts with prefilled response formats. Found RCEs in gpt_academic, ComfyUI, FastChat and Ragflow within hours. Python-only, Jedi AST parsing, Claude recommended. By Protect AI; feeds the huntr.com AI bug bounty.

**#102 · AuditBase** — https://www.auditbase.com
Smart-contract review with a **three-layer engine**: 200+ static patterns in milliseconds, symbolic execution exploring every reachable path, then LLM reasoning for business-logic flaws and intent-vs-implementation gaps. Covers **Solidity, Move, Cairo, Vyper and Rust**, outputs a quantified risk score, severity-ranked findings with PoC exploits, and **MiCA compliance percentages** — decision-grade audit output in hours, not months. From $49/mo, SOC 2.

**#103 · AutoAudit** — https://github.com/ddzipp/AutoAudit
An **LLM fine-tuned specifically for security auditing** (not a wrapper around a general model), trained on a Self-Instruct dataset from GitHub, Kaggle and public vulnerability corpora, with outputs strictly structured as analysis / label / risk / solution. Coupled with ClamAV into a scanning platform; weights on HuggingFace.

**#104 · PentestKit** — https://github.com/lordx64/pentestkit
Autonomous multi-agent framework that **requires proof before reporting** — plans, exploits, verifies, CVSS-scores, then writes a client-ready report. Scored 104/104 (100%) on the XBOW validation benchmarks, powered by Kimi K3. The proof-required design directly attacks the false-positive problem.

**#105 · XBOW** — https://xbow.com
Autonomous offensive-security AI that attacks a running application the way a pentester would and **proves exploitability** rather than flagging patterns; its validation benchmark set has become a reference target for other agents (see #104). The offensive counterpart to every defensive reviewer in this document.

## Cluster M — Chinese hyperscaler platform reviewers (国内大厂)
*Fully localised stacks: domestic models, 等保 2.0 / 信创 compliance, private deployment, Chinese-language review output.*

**#106 · 腾讯云 CodeBuddy（Tencent Cloud CodeBuddy）** — https://www.codebuddy.ai · CN: https://copilot.tencent.com
The only Chinese assistant shipping **three form factors at once — IDE plugin, standalone IDE, and CLI** (`npm i -g @tencent-ai/codebuddy-code`) — with a dedicated **代码评审智能体 (code review agent)** doing line-level comments across 200+ languages, a **安全智能体** wired to TCA scanning, and an architecture agent producing 6 kinds of technical docs. Dual-model: Tencent Hunyuan + DeepSeek. 100% domestic models, full audit logs, private deployment for 等保 2.0 / GDPR. Used by 85%+ of Tencent engineers; WeChat, QQ, 王者荣耀 and China Merchants Bank are cited deployments.

**#107 · 阿里云云效 Codeup AI 评审（Alibaba Cloud Yunxiao Codeup）** — https://help.aliyun.com/zh/yunxiao/user-guide/ai-intelligent-code-review
Review welded into a Chinese-style **推送评审模式 (push-review mode)**: a `git push` auto-creates the CR, no branch/PR ceremony required. Severity gating at BLOCKER/CRITICAL/MAJOR/MINOR, `path_instructions` custom rules, auto title/description generation and an AI chat over the diff. Codeup has run Alibaba's internal code assets (Taobao, Tmall, Aliyun) for years.

**#108 · 通义灵码 Lingma Code Review 智能体（Alibaba Tongyi Lingma）** — https://lingma.aliyun.com
The `/code-review` **built-in agent** inside Lingma IDE reviews a user-specified scope *within the chat session* — you pick the review dimensions (code style, standards, security) in natural language and it walks the folder itself. Paired with **Repo Wiki** auto-documentation and a Spec-driven Quest mode. Changelog: https://help.aliyun.com/zh/lingma/product-overview/changelogs-of-lingma-ide

**#109 · Qoder / Qoder CLI（阿里巴巴）** — https://qoder.com · CLI: https://qoder.com/cli
`/review` in the terminal, **parallel git-worktree tasks** (one Qoder instance per "parallel universe" branch — one writes code, one writes tests, one reviews), Quest Mode for spec-driven autonomous delivery, and a retrieval engine indexing **100,000 files in a single pass**. Claims ~50% reduction in review time. Positioned as China's Claude Code equivalent.

**#110 · 文心快码 Baidu Comate** — https://comate.baidu.com · https://cloud.baidu.com/product/comate-public.html
One-click AI review over a selection, file or diff, enforcing either general standards or **企业自定义编码规范** from a private enterprise knowledge base, with SAST-style compliance detection running *during* generation. Notable for being the **only major assistant with a native Xcode app**, plus IntelliJ/Android Studio/PyCharm/GoLand/WebStorm/VS/Eclipse. SaaS, VPC or fully private deployment. Reported 46% code adoption rate.

**#111 · 华为云 CodeArts Snap（Huawei Cloud）** — https://www.huaweicloud.com/product/codeartside/snap.html
Built on the **盘古 (PanGu) R&D large model**, distilled from 30 years of Huawei ICT engineering data and governed by internal "基本法" standards for corpus quality, data cleaning and evaluation. **代码检查 (code inspection)** is one of eight core capabilities alongside translation, debugging and test generation; the model self-corrects via元能力 fine-tuning (self-correction, reflection, harm judgement). Claims >20% R&D efficiency gain.

**#112 · 字节跳动 Trae / MarsCode（ByteDance）** — https://www.trae.cn · intl: https://trae.ai
Trae is the AI-native IDE (SOLO mode, Doubao-1.5-pro + DeepSeek R1 domestically, GPT/Claude internationally); the **Trae plugin (formerly MarsCode)** carries the code-quality and review side into VS Code and JetBrains across 100+ languages. Commonly wired into `.gitlab-ci.yml` as an MR review rule for things like SQL-injection checks. Trae CN Enterprise edition shipped 2026.

**#113 · CodeGeeX（智谱 AI / Zhipu, Tsinghua KEG）** — https://codegeex.cn · repo: https://github.com/THUDM
Free-tier reviewer with a dedicated **`/review` command** plus right-click and pre-commit entry points, generating a **代码安全审查报告** built on rules and a vulnerability library from a partner security firm — covering security, performance, best practice and compatibility. Auto-expands a partial selection to the nearest complete method/class before reviewing. Uniquely broad IDE reach: VS Code, JetBrains, Visual Studio, **HBuilderX, deepin-IDE, Code Server, Open VSX**, and an Ollama offline mode.

**#114 · 蚂蚁 CodeFuse（Ant Group）** — https://codefuse.ai · models: https://huggingface.co/codefuse-ai
Open-sourced code LLM family whose distinguishing asset is the **MFT (Multi-task Fine-tuning) framework** — code generation, translation, test generation and bug fixing tuned *jointly*, with a novel loss design balancing uneven task convergence, ~8x faster fine-tuning via data-packing and ~2x inference acceleration. Scored 74.4% on HumanEval, above GPT-4's 67% at release. Ships CodeFuse-Eval and the TestAgent testing tool.

**#115 · 腾讯云代码分析 TCA（Tencent Cloud Code Analysis）** — https://tca.tencent.com · repo: https://github.com/Tencent/CodeAnalysis · CNB: https://cnb.cool/tca/code-analysis
Open-source, cloud-native, **distributed-client** analysis platform: clients can be deployed to any geography as ephemeral or permanent nodes, and it orchestrates both self-developed engines and third-party analyzers. Integrates **T-SCA/srcAuditor** for source-level SBOM, license/copyright risk, open-source **poisoning (投毒) detection** and secret leakage — and explicitly never uploads code, only queries the knowledge base. Jenkins integration and quality gates. ~3,500 CNY for 3 years.

**#116 · 极狐 GitLab 驭码 CodeRider（JiHu GitLab）** — https://gitlab.cn
The **Chinese-sovereign GitLab distribution** with its own AI assistant, CodeRider, doing AI code review and DevSecOps CVE detection on infrastructure that satisfies 等保 2.0 and 信创 requirements — the standard answer for Chinese government, finance and energy teams who cannot use gitlab.com. Companion analytics product **极狐星 TowerFox** adds merge-request效能评估 with 10+ review-quality metrics.

**#117 · Gitee Code MCP（码云）** — https://gitee.com · docs: https://help.gitee.com
China's largest domestic code host exposes PR review as an **MCP server**, so Cursor or Claude can list open PRs, review them, post comments and *execute the merge* — review as a tool call rather than a bot. Gitee also brokers third-party scanners (e.g. 奇安信代码卫士) directly into the repo service menu.

## Cluster Q — Browser-extension & URL-swap reviewers
*Review injected into the page you're already on — zero backend, zero repo permissions.*

**#118 · ThinkReview** — https://thinkreview.dev · repo: https://github.com/Thinkode/thinkreview-browser-extension
AGPL-3.0 **browser extension** (Chrome/Firefox, Manifest V3) that adds AI review directly into GitHub, GitLab, Azure DevOps and Bitbucket review pages — including self-hosted/on-prem variants via custom domain — with an **Ollama option so reviews run entirely on the developer's own machine**. Generates **IDE deeplinks** that turn a finding into a ready-to-run Cursor / Claude Code / Copilot prompt on the correct branch. 15+ review languages. Actively courting Gerrit support.

**#119 · Devin Review (Cognition)** — https://devinreview.com · https://cognition.ai
**Onboarding by URL swap** — replace `github` with `devinreview` in any PR link and get an instant review, no signup, public *or* private repos, free. Beyond that: **copy/move detection** (so relocated code stops appearing as a giant delete+insert), logical rather than alphabetical diff grouping, findings ranked by both severity *and* confidence, codebase-aware chat, `npx devin-review {pr-url}` CLI, and honours AGENTS.md / CLAUDE.md / CONTRIBUTING.md.

**#120 · Gitea AI CodeReview (bestK)** — https://github.com/bestK/gitea-ai-codereview
Niche but genuinely unusual: reviews commit diffs and **files the results as Gitea issues** rather than inline comments, with `[skip codereview]` opt-out and configurable webhook fan-out. For self-hosted Gitea shops.

**#121 · codereview.gpt (Sturdy)** — https://github.com/sturdy-dev/codereview.gpt
The original browser-extension reviewer (607 stars, MIT) — reviews Pull/Merge Requests via ChatGPT from inside the browser. Archived but historically important as the pattern #118–119 followed.

## Cluster R — PR comprehension & diff-restructuring tools
*The bottleneck isn't finding bugs — it's that the PR is 4,000 lines of agent output nobody can read.*

**#122 · Alchemize** — https://tryalchemize.com
Attacks the agentic-era problem from the opposite end: it **automatically decomposes one oversized PR into multiple stacked, smaller PRs** and arranges them as a guided narrative revealing the original author's (human *or* agent) intent — showing where changes begin, how data flows, and which decisions actually need human judgement. Two-way GitHub sync with GitHub remaining source of truth. YC 2026.

**#123 · Codenudge** — https://codenudge.com
Focused narrowly on **comprehension rather than criticism**: summarises the PR, adds contextual feedback and surfaces **contributor insights** (who knows this code, who should review) directly inside GitHub. Useful where the blocker is reviewer routing and understanding, not defect detection.

**#124 · Graphify Labs** — https://www.ycombinator.com/companies/graphify-labs
Builds **queryable knowledge graphs from local codebases, docs and Jira** so reviewers and agents can ask structural questions about a change instead of reading it linearly (105K+ GitHub stars across its tooling, ~5M downloads). YC S2026; the context substrate under review rather than a reviewer itself.

**#125 · Robin Wieruch's (anti-)pattern library method** — https://www.robinwieruch.de/ai-agentic-code-review/
Not a product but a widely-adopted **methodology**: document project patterns and anti-patterns as structured files, bundle them into one reference doc, and have agents review against it both in CI and locally pre-PR. The zero-cost baseline any team should try before buying anything in this document.

---

# TIER 2 (Part II) — STRONGLY DIFFERENTIATED (#126–155)

## Cluster N — Chinese DevSecOps & 信创 security vendors

**#126 · 奇安信 代码卫士 AI+（QiAnXin CodeSafe）** — https://www.qianxin.com/product/detail/pid/372
China's first commercially mature SAST product, now fused with the **QAX 安全大模型 + DeepSeek R1**. Four AI capabilities: **AI 缺陷研判** (automated audit verdicts on scanner output), AI reasoning-based defect description, AI-generated fix code, and a code-security Q&A assistant. 32 languages, **3,500+ defect types**, compliance with GB/T 38674-2020, 国军标 GJB 8114-2013 and GJB 5369-2005 — standards no Western tool covers. Deployed at ~1,000 organisations including Bank of Beijing.

**#127 · 悬镜 灵脉 SAST / 灵脉 AI（XMirror Lingmai）** — https://sast.xmirror.cn
**AI multi-mode engine** combining taint analysis, symbolic execution, pointer analysis and LLM reasoning, with published targets of **≤15% false positives, ≤13% false negatives at 1M LOC/hour**. 30+ languages, **9,000+ rules**, fast-scan vs deep-scan modes, and a distinctive **后门查杀 (backdoor hunting)** capability tracing entry function → sink call flow for command-execution, deserialization, reflection and hardcoded-credential backdoors. First batch to pass China's official **AI SAST 工具能力评估** (OSCAR, Oct 2025). Fuses SCA with reachability.

**#128 · 墨菲安全 SCA 4.0（MurphySec）** — https://www.murphysec.com · repo: https://github.com/murphysecurity/murphysec
**AI-native rather than AI-bolted-on**: the product no longer shows a vulnerability list at all — the AI states "you need to care about 3 things; the other 239 components can wait," writes the fix down to file and line, flags which call sites need regression testing, and explains licence risk **in language a lawyer understands** rather than a developer. First SCA to cover **AI Skills supply-chain poisoning**, monitoring clawhub, skills.sh, MCP servers and IDE plugins. Open-source CLI, JetBrains plugin, Jenkins and GitLab scanners.

**#129 · OpenSCA（悬镜开源）** — https://github.com/XmirrorSecurity/OpenSCA-cli
The most widely used **open-source Chinese SCA CLI**, the domestic counterpart to Dependency-Check, with a web UI option and community vulnerability database.

**#130 · 开源网安 SourceCheck（SecZone）** — https://sca.seczone.cn
Scored **highest component-detection rate** among seven free SCA tools in an independent Chinese benchmark, ahead of both Snyk editions, with the most frequently updated domestic vulnerability knowledge base.

**#131 · 安恒 源代码安全审计智能服务（DBAPPSecurity）** — https://www.dbappsecurity.com.cn/product/cloud5292.html
Sold as an **AI 智能体服务 (agent service)** rather than a tool licence: multi-engine fusion with cross-validation, AI 研判 to cut false positives, AI deep audit targeted only at high-risk regions and complex logic, automated fix generation **with self-verification**, and one-click compliance reporting for Chinese regulatory inspection.

**#132 · TscanCode（Tencent, open source）** — https://github.com/Tencent/TscanCode
Tencent's open-source static checker for C/C++/C#/Lua, notable for very fast whole-project scanning and a documented custom-rule development path — the free entry point beneath TCA.

**#133 · Kiuwan（Idera）** — https://www.kiuwan.com
SAST/SCA platform frequently listed alongside Chinese vendors in市场 analyses, with strong multi-standard compliance reporting and cloud/on-prem parity.

**#134 · Embold** — https://embold.io
Anti-pattern-focused analysis producing a code-health rating across design, duplication, metrics and security dimensions — one of the few tools ranking *design* issues above line-level defects.

**#135 · CAST Highlight / Imaging** — https://www.castsoftware.com
Software-intelligence platform that reviews at **architecture and portfolio scale** — cloud-readiness, open-source risk and structural flaws across hundreds of applications — the layer above per-PR review used by large enterprises and cited in static-analysis market surveys.

## Cluster O — Chinese open-source LLM review bots (中文开源)

**#136 · AI-Codereview-Gitlab (sunmh207)** — https://github.com/sunmh207/AI-Codereview-Gitlab
The most popular Chinese open-source reviewer, and the most culturally localised tool in this entire document: DeepSeek/ZhipuAI/OpenAI/Anthropic/通义千问/Ollama support, results pushed to **钉钉 / 企业微信 / 飞书**, **automatic daily developer reports (日报)** generated from commit history, a visual dashboard of all reviews with per-project and per-developer statistics, and **four selectable review personalities — 专业型 / 讽刺型 / 绅士型 / 幽默型** (professional / sarcastic / gentlemanly / humorous). Docker deploy; free OSS core plus a Pro edition.

**#137 · Code-Review-GPT-Gitlab** — https://github.com/mimo-x/Code-Review-GPT-Gitlab
Widely forked Chinese GitLab reviewer built around LLM-assisted MR review with local-model support.

**#138 · ai-code-review-plugin (Vinist123)** — https://github.com/Vinist123/ai-code-review-plugin
IntelliJ IDEA plugin that triggers AI review **at Git commit time inside the IDE**, plus right-click review of any selection, with configurable strictness, ignore rules and custom prompts. Published to the JetBrains marketplace.

**#139 · Code Review Helper (veezean)** — https://github.com/veezean/IntellijIDEA-CodeReview-Plugin
Not AI-first but the dominant IDEA review-管理 plugin in China: Alt+A to attach a review comment, gutter markers, **Excel import/export of review findings**, team-server sync and customisable review fields — the workflow layer Chinese enterprises wrap AI output around.

**#140 · Awesome-AI-Code-Audit** — https://github.com/Tr0e/Awesome-AI-Code-Audit
The best curated Chinese-language index of AI code-audit research and tooling, including detailed teardowns of Vulnhuntr-class systems — the meta-resource for this whole category in Chinese.

**#141 · CodeReviewer (Microsoft / Peking University research model)** — https://github.com/microsoft/CodeBERT/tree/master/CodeReviewer
The **pre-trained model purpose-built for code review** (ESEC/FSE 2022) rather than a general LLM prompted to review — trained on large-scale review data for diff quality estimation, review-comment generation and code refinement. The academic foundation much of this category's tooling implicitly rests on; weights and data public.

**#142 · gitlab-ai-code-reviewer (bokri)** — https://github.com/bokri/gitlab-ai-code-reviewer
Gemini-powered GitLab MR reviewer with **incremental review for updates vs full review for new MRs** and, unusually, **approval-invalidation notifications** — it tells previous approvers when code changed after they approved.

**#143 · llnhnv/ai-code-reviewer** — https://github.com/llnhnv/ai-code-reviewer
GPT-4 GitLab reviewer shipping a **feedback-rating loop** (1–5 score per review logged to Postgres), a Chart.js analytics dashboard with Excel/PDF export, and `ai-reviewed:pass|fail` MR labels — one of the few OSS tools measuring its own review quality.

**#144 · codeReviewBot (sydowma)** — https://github.com/code-reviewer-using-ai/codeReviewBotGitlab
Dual GitLab + GitHub reviewer usable either as a CLI or a FastAPI server, with separately editable `detailed_prompt.txt` and `summary_prompt.txt`.

## Cluster P — Agent skills, MCP servers & plugin-layer reviewers
*Review distributed as a skill/plugin for someone else's agent, not as a SaaS.*

**#145 · TuringMind Code Review** — https://github.com/turingmindai/turingmind-code-review
Claude Code skill installed from the plugin marketplace that runs **six specialised agents in parallel** over *uncommitted local changes* (`/turingmind-code-review:deep-review`, with a lighter `/review`), scoring findings 95–100 for critical. Paired with **tmind** cloud memory offering per-repo / per-branch / per-commit memory with a dashboard. MIT.

**#146 · Microsoft Frontend Design Review skill** — https://mcpmarket.com/tools/skills/frontend-design-review-creator
1,800+ star Claude Code skill reviewing UI PRs against three pillars, with **design-token and Storybook compliance checks, deep Figma verification against spec, and WCAG 2.1 accessibility auditing** — the only entry here reviewing whether the implementation matches the *design*.

**#147 · Gerrit AI Review Agent Provider (GerritForge)** — https://github.com/GerritForge/ai-review-agent-provider
The backend engine for **Gerrit v3.14's native in-change AI chat interface** — a vendor-agnostic adapter to Gemini, OpenAI, Anthropic or self-hosted Ollama. The only serious AI review path for the Gerrit review model (patch sets, not PRs). Requires the secure-config plugin.

**#148 · GitLab Code Review MCP (mehmetakinn)** — https://mcpmarket.com/server/gitlab-code-review
MCP server letting Claude/Cursor fetch full MR details, diffs, commits and comments, analyse specific files, compare branches, then **comment, approve or unapprove** MRs directly.

**#149 · kimi-plugin-cc (linxule)** — https://github.com/linxule/kimi-plugin-cc
Claude Code plugin delegating **read-only review, adversarial review and rescue work to a local Kimi CLI**, including an opt-in **stop-time review gate** — a cost-arbitrage pattern (expensive model plans, cheap model reviews).

**#150 · kimi-code-mcp (howardpen9)** — https://github.com/howardpen9/kimi-code-mcp
MCP server delegating bulk codebase analysis from Claude Code to Kimi K2.5's 256K context, claiming ~90% token-cost reduction with session caching and parallel agents.

**#151 · Kimi Code Review Action** — https://github.com/marketplace/actions/kimi-code-review
Moonshot-powered GitHub Action with `/review`, `/describe`, `/improve`, `/ask` and `/triage`, strictness levels (strict/normal/gentle) and zh-CN/en-US output.

**#152 · Kimi Code CLI (Moonshot)** — https://github.com/MoonshotAI · https://www.kimi.com
Terminal coding agent (9.7K stars, Node.js since v1.49) with shell mode (Ctrl-X), one-off `kimi -p` prompts, VS Code extension, ACP support for Zed/JetBrains, and MCP tools — used widely as a review runner in Chinese teams.

**#153 · agent37-skills-collection local-review** — https://github.com/Agent-3-7/agent37-skills-collection
Claude Code plugin providing `/local-review` over uncommitted local changes — the minimal pre-commit review skill.

**#154 · claude-bootstrap (alinaqi)** — https://github.com/alinaqi/claude-bootstrap
Project bootstrap that installs **code review as a mandatory guardrail in the commit flow** via `/initialize-project` — review as project scaffolding.

**#155 · HyperProbe** — https://www.ycombinator.com/companies/hyperprobe
Targets the gap its founders describe bluntly: agents like Cursor, Claude Code and Codex are "great at writing code, mediocre at debugging it." Sits after review, instrumenting and diagnosing what the agent shipped. YC S2026, 8 employees.

---

# TIER 3 (Part II) — DOMAIN-SPECIALISED (#156–185)

## Cluster T — Safety-critical & embedded compliance analysis
*Where "AI reviewer" must coexist with TÜV certification and an auditor.*

**#156 · Perforce QAC (Helix QAC)** — https://www.perforce.com/products/helix-qac
**100% MISRA coverage** shaped by the people who write the standard, sound abstract interpretation across control flows, C/C++/**Rust** mixed-language analysis, and **AI-assisted remediation that requires developer approval for every suggested fix** — AI constrained by certification requirements. Covers MISRA C 2004→2025, MISRA C++ 2008/2023, AUTOSAR C++14, JSF AV C++, CERT, ISO 26262, DO-178C with a DO-330 qualification pack.

**#157 · Klocwork (Perforce)** — https://www.perforce.com/products/klocwork
2,000+ checkers, 50+ native compiler environments, TÜV SÜD certified for ISO 26262 / IEC 61508 / EN 50128 / IEC 62304, and a **differential analysis engine that scans only changed files per commit** — the feature that makes heavyweight SAST viable in CI. Quote-based, ~$20K–$100K+/yr.

**#158 · IAR C-STAT** — https://www.iar.com/embedded-development-tools/iar-c-stat
Static analysis living **inside IAR Embedded Workbench** with TÜV SÜD-certified functional-safety editions, **SARIF diagnostics output** for structured toolchain integration, and severity *plus confidence* on every finding so teams don't churn working code.

**#159 · LDRA Tool Suite (Testbed / TBvision)** — https://ldra.com
Static **and dynamic** analysis with code coverage and unit testing under one qualification umbrella, plus TBvision's visual metrics and traceability — the avionics/medical/rail certification incumbent (DO-178C, IEC 62304, EN 50128).

**#160 · Parasoft C/C++test** — https://www.parasoft.com/products/parasoft-c-ctest/
AUTOSAR/MISRA compliance combined with **unit-test generation and execution**, now with AI assistance for violation remediation and test creation.

**#161 · MathWorks Polyspace** — https://www.mathworks.com/products/polyspace.html
**Formal methods, not heuristics**: abstract interpretation *proves* the absence of certain runtime error classes rather than sampling for them — the strongest correctness guarantee available and a DO-178C favourite. Increasingly paired with AI triage.

**#162 · Cppcheck (with MISRA addon)** — https://cppcheck.sourceforge.io/misra.php
The free baseline: open-source C/C++ analysis with a MISRA checker driven by a rule-headline file. Cannot itself certify compliance (MISRA text is proprietary) but is the standard pre-check before paying for #156–161.

**#163 · SciTools Understand** — https://scitools.com
Code comprehension and architecture analysis for very large legacy C/C++ — dependency graphs, metrics and structural review, frequently paired with LLMs as the context source.

**#164 · GrammaTech CodeSonar** — https://www.grammatech.com
Deep whole-program analysis including **binary and mixed source/binary** review — relevant when third-party code arrives without source.

**#165 · VectorCAST (Vector)** — https://www.vector.com/int/en/products/products-a-z/software/vectorcast/
Test-focused verification suite for safety-critical embedded software, used alongside the analyzers above to close the certification evidence loop.

## Cluster U — Database, SQL & schema-migration review

**#166 · Bytebase** — https://www.bytebase.com · docs: https://docs.bytebase.com/gitops/state-based-workflow/sql-review-ci
"Database governance" platform whose **SQL Review CI** validates migrations against ~100 built-in rules **plus your team's standards written as natural-language Markdown in `.bytebase/sql-review.md`** (any human language), with policy-matched approval routing, rollbackable changelogs, and an **MCP server so external AI agents inherit the same masking, review and audit controls** instead of connecting to the database directly. 20+ engines.

**#167 · Atlas (Ariga)** — https://atlasgo.io · repo: https://github.com/ariga/atlas
**50+ migration safety analyzers** (`atlas migrate lint`) catching destructive changes, data-dependent modifications, table locks and rewrites *before* deploy, plus schema testing in `.test.hcl` files, drift detection and 16 ORM loaders across 6 languages. Terraform-style declarative plans for schemas.

**#168 · AIM (alecthomas)** — https://github.com/alecthomas/aim
LLM generates the migration, then **every migration is verified against an ephemeral database before it is written to disk** — and each destructive-change rule is evaluated by its own isolated parallel LLM check that only ever sees the UP migration. Verify-before-write is rare in this category.

**#169 · SafeMigrate** — https://dev.to/depapp/safemigrate-never-fear-database-migrations-again-with-ai-agents-2aon
Four specialised agents in parallel — Schema Analyzer, Data Integrity, Performance, **Rollback Validator that auto-generates the undo script** — producing a scored risk report (SAFE → CRITICAL) in ~15 seconds.

**#170 · db-schema-viewer (maxgfr)** — https://github.com/maxgfr/db-schema-viewer
**100% client-side** schema review: upload SQL/Prisma/Drizzle/TypeORM/DBML, get ER diagrams and an AI **"Challenge mode"** scoring the schema 0–100 across 8 categories with history tracking, plus AI-evaluated schema **diff** for migration safety. Nothing leaves the browser. MIT.

**#171 · Liquibase** — https://www.liquibase.com
Changelog-based migration governance with policy checks — the enterprise incumbent now layering AI-assisted change analysis.

**#172 · Flyway (Redgate)** — https://www.red-gate.com/products/flyway/
Versioned migration standard, paired with Redgate's AI-assisted SQL code analysis for change review.

## Cluster V — Infrastructure-as-Code & policy review

**#173 · Checkov (Prisma Cloud / Bridgecrew)** — https://www.checkov.io
The open-source IaC policy baseline — Terraform (AWS/GCP/Azure/OCI), CloudFormation, SAM, ARM, Serverless, Kubernetes, Docker — with zero licensing cost and PR-time gating.

**#174 · Terrateam** — https://terrateam.io
GitOps Terraform review with plan/apply inside the PR and policy enforcement — the workflow layer where IaC review actually happens.

**#175 · Infracost** — https://www.infracost.io
Reviews the **cost** of a diff: posts the monthly dollar delta of an infrastructure change as a PR comment. The only reviewer here whose finding is a currency figure.

**#176 · KICS (Checkmarx)** — https://kics.io
Open-source IaC scanner covering 20+ platforms with a very large query set, embeddable in any CI.

**#177 · Open Policy Agent / Conftest** — https://www.openpolicyagent.org · https://www.conftest.dev
Rego-based **policy-as-code** evaluation of any structured config in a PR — the deterministic policy engine LLM reviewers increasingly call as a tool.

**#178 · Trivy (Aqua)** — https://trivy.dev
Unified scanner for containers, filesystems, repos, IaC and Kubernetes, widely used as the free PR-time gate beneath commercial platforms.

## Cluster W — Secrets & software supply-chain review

**#179 · GitGuardian** — https://www.gitguardian.com
**500+ secret types** with live validity checking (is this credential still active?), real-time monitoring across GitHub/GitLab/Bitbucket **plus Slack, Jira and Confluence**, `ggshield` pre-commit and CI gating, **Non-Human Identity governance**, and uniquely **honeytokens** — decoy credentials that detect both intrusion and public code leakage, with source repo/file attribution. Blog: https://blog.gitguardian.com/secret-scanning-tools/

**#180 · Socket** — https://socket.dev
**Behavioural** supply-chain review rather than CVE matching: analyses what a package actually does — install scripts phoning home, unexpected filesystem or shell access, native code, typosquatting — and **blocks malicious packages in the PR before a CVE exists**. Risk scores across supply chain, quality and maintenance; MCP feature lets AI agents pre-check packages. Free for OSS.

**#181 · TruffleHog** — https://github.com/trufflesecurity/trufflehog
Open-source scanner distinguished by **live credential verification** — it attempts to authenticate found secrets, so you triage real exposure, not entropy noise.

**#182 · Gitleaks** — https://github.com/gitleaks/gitleaks
The fast pre-commit standard for secret blocking, with strong community rule sets. Free, detection-only.

**#183 · Yelp detect-secrets** — https://github.com/Yelp/detect-secrets
**Baseline-first** design: snapshot existing secrets so teams enforce only on *new* ones — the pragmatic path for legacy repos.

**#184 · Mend.io (formerly WhiteSource)** — https://www.mend.io
Long-standing SCA/SAST platform now applying AI to **automated dependency remediation at merge time** and to governing AI-generated code; a fixture in static-analysis market surveys and a common enterprise incumbent teams must displace or integrate with.

**#185 · Veracode SCA (Phylum technology)** — https://www.veracode.com/products/software-composition-analysis/
Veracode acquired Phylum's malicious-package technology (Jan 2025) — the enterprise-policy alternative to Socket for teams already standardised on Veracode.

---

# TIER 4 (Part II) — LONG TAIL & ADJACENT (#186–200)

## Cluster X — Long-tail open-source GitHub Actions & CI bots

**#186 · AI Code Review // VERY POWERFULL (zxcloli666)** — https://github.com/marketplace/actions/ai-code-review-very-powerfull
Unusually deep for a free Action: **AST analysis, linter integration, dependency tracking and call graphs** alongside the LLM, configurable severity threshold, chunk size, and review output in 10+ human languages. GPT-5 / Claude Opus 4 / Gemini 2.5 Pro / custom endpoints.

**#187 · OpenAI GPT Code Review Action (Ostrich-Cyber-Risk)** — https://github.com/marketplace/actions/openai-gpt-code-review-action
Widely used MIT fork of the canonical ai-codereviewer pattern with exclude globs and model selection.

**#188 · gpt-code-review-action (sshnaidm)** — https://github.com/marketplace/actions/openai-code-review-github-action
Minimal, well-maintained Action with a **custom prompt input** ("only suggest performance improvements"), configurable diff cutoff and error-posting behaviour.

**#189 · AI PR Review Action (Azure OpenAI)** — https://github.com/marketplace/actions/ai-pr-review-action
The **Azure OpenAI** variant — the compliance-friendly path for enterprises whose LLM must sit in their own Azure tenant.

**#190 · Gemini AI Code Review Action (petarzarkov)** — https://github.com/marketplace/actions/gemini-ai-code-review-action
Free-tier friendly Gemini Action that **persists conversation summaries between runs** for continuity across review rounds, with automatic model de-ranking on rate limits and draft-PR skipping.

**#191 · code-review-gpt (Matt Carey)** — https://github.com/mattzcarey/code-review-gpt
Multi-provider (GPT-4, Claude Sonnet, Llama 2, Azure) reviewer using **embeddings** for context, deployable to GitHub, GitLab *or* Azure DevOps CI.

**#192 · PR Review Agent (sajeeshkumar)** — https://github.com/sajeeshkumar/pr-review-agent
Ollama/devstral-based reviewer tuned for **SQL anti-patterns**, naming conventions, missing docs and test coverage — fully local models.

**#193 · tracehub code-review-action** — https://www.oschina.net/p/tracehubpm-code-review-action
Inverts the target: uses an LLM to **review the quality of the human code review itself**, scoring thoroughness and suggesting improvements. The only meta-reviewer found.

**#194 · Bitbucket ChatGPT Code Review pipe (Atlassian)** — https://bitbucket.org/atlassian/bitbucket-chatgpt-codereview
Official Atlassian **Bitbucket Pipelines pipe** — the lowest-friction AI review for Bitbucket-native teams, configured entirely in `bitbucket-pipelines.yml`.

**#195 · snarktank/ai-pr-review** — https://github.com/snarktank/ai-pr-review
Minimal GitHub Actions workflow running Amp or Claude Code as the reviewer — the "bring your own agent" template.

## Cluster Y — Adjacent quality, benchmark & meta layers

**#196 · Manus** — https://manus.im
General-purpose autonomous agent used as a **report-style deep security reviewer** for high-risk changes rather than per-PR hygiene — strongest when explicitly framed as a security review (failure mode, impact, remediation). Note: processes data on servers primarily in China; independent security audits not published — assess before use with proprietary code.

**#197 · SWE-bench / SWE-bench Verified** — https://www.swebench.com
The benchmark the whole agent industry quotes — and, per #200, the one that **overstates real-world review and maintenance ability**: agents scoring 60–80% here still fail badly on genuine maintenance bugs. Include it in evaluations only as a generation-capability signal, never as a review-quality proxy.

**#198 · benchmodel.io leaderboard** — https://benchmodel.io/leaderboard
Public, continuously-run comparison of review quality across Claude, GPT, Gemini and DeepSeek — an independent counterweight to vendor-published benchmarks.

**#199 · Martian Code Review Bench** — referenced via https://codeant.ai/blogs/best-ai-code-review-tools
The largest independent benchmark in this space — **300,000 real PRs** — and currently the most credible third-party ranking signal for AI reviewers.

**#200 · SM-100 benchmark (Bismuth)** — https://www.zenml.io/llmops-database/benchmarking-ai-agents-for-software-bug-detection-and-maintenance-tasks
The benchmark that exposed the category's core weakness: leading agents found only ~7% of real maintenance bugs with 90%+ false positives, despite scoring 60–80% on SWE-Bench. Essential context before trusting any vendor detection claim.

---

## Part II — cross-cutting notes

**Why the Chinese ecosystem is structurally different, not just localised**

| Dimension | Western tools | Chinese tools (#106–144) |
|---|---|---|
| Trigger point | Pull request | Often `git push` directly (推送评审模式, #107) |
| Notification | GitHub/Slack | 钉钉 / 企业微信 / 飞书 (#136) |
| Compliance target | SOC 2, GDPR | 等保 2.0, 信创, GB/T 38674, 国军标 GJB (#126) |
| Deployment default | SaaS | Private / VPC / air-gapped as standard (#106, #110) |
| Model | OpenAI/Anthropic | Hunyuan, PanGu, Qwen, Doubao, GLM, DeepSeek |
| Extra outputs | Metrics dashboards | Auto-generated **daily developer reports** (#136) |
| Review persona | Neutral | Selectable tone incl. sarcastic/humorous (#136) |

**Categories that barely existed in Part I**

- **Review-the-reviewer** (#193) — scoring human review quality.
- **Cost review** (#175) — the finding is a dollar amount.
- **Design-spec review** (#146) — does the code match Figma?
- **Verify-before-write migrations** (#168) — generated change proven against an ephemeral DB.
- **Honeytokens** (#179) — planting bait to detect leakage rather than scanning for it.
- **Behavioural package review** (#180) — judging what a dependency *does*, pre-CVE.

**Selection guide — Part II**

- **China-based team, compliance-bound** → CodeBuddy (#106), 云效 Codeup (#107), 极狐 GitLab (#116)
- **Chinese security audit / 等保** → 代码卫士 (#126), 灵脉 SAST (#127)
- **Self-host with Chinese IM push** → AI-Codereview-Gitlab (#136)
- **Safety certification (auto/aero/medical)** → Perforce QAC (#156), LDRA (#159), Polyspace (#161)
- **Database changes** → Bytebase (#166), Atlas (#167)
- **Never send code anywhere** → ThinkReview + Ollama (#118), db-schema-viewer (#170)
- **Zero-signup instant try** → Devin Review URL swap (#119)
- **Giant agent-written PRs** → Alchemize (#122)
- **Supply chain / secrets** → Socket (#180), GitGuardian (#179)
- **Gerrit shops** → GerritForge AI Review Agent (#147)
- **Buy nothing yet** → pattern-library method (#125), Cppcheck (#162), Gitleaks (#182)

---

*End of Part II. Combined total across both parts: **200 distinct AI code review tools**, verified de-duplicated, every entry with an explicit URL.*

**Search coverage:** Part I — 64 English queries. Part II — 68 queries in Chinese and English. **132 queries total.**

---
---

# PART III — THE LATE-2026 DELTA (#201–#250 + status changes to #1–#200)

**Compiled:** 5 November 2026 · **Method:** 104 new search queries (English, Simplified Chinese, Japanese) plus vendor changelogs, GitHub topic indexes, procurement/pricing pages, arXiv + ICSE-SEIP ’26 / FSE ’26 / ASE ’26 papers, benchmark sites, and practitioner threads on X, Reddit (r/codereview, r/ExperiencedDevs, r/vibecoding, r/cybersecurity) and Hacker News.

**Scope rule:** everything here appeared, shipped or materially changed **after this document’s original 15 August 2026 cutoff**. Where an entry in Part I or Part II changed, it is corrected in §3.3 rather than duplicated.

**Companion file:** `free-oss-tools-for-reviewing-ai-generated-code-top100.md` (free/OSS stack — see §3.7 for what changed there too).

---

## 3.1 The thirteen shifts since 15 August 2026

| # | Shift | Hardest evidence |
|---|---|---|
| 1 | **Review became a governance product, not a comment bot.** Vendors stopped selling “AI comments on your PR” and started selling triage, prioritisation, blast-radius explanation and post-merge monitoring. | CodeRabbit’s *Agentic Change Management* + Triage + Change Stack, 12 Aug 2026 · https://sdtimes.com/agentic-ai/coderabbit-introduces-agentic-change-management/ · Qodo’s *Agentic Toolbox* (agent-to-agent review), 9 Sep 2026 · https://finance.yahoo.com/technology/ai/articles/qodo-launches-first-agent-agent-130000467.html |
| 2 | **Review moved *earlier than the PR*.** Plan-level, spec-level and even *prompt*-level review became products: block the bad change before the code exists. | Baz Planner (risk matrix applied to every model suggestion before it is saved) · https://itbrief.news/story/baz-launches-planner-with-usd-9-million-seed-raise · Apiiro Guardian Agent rewrites prompts pre-generation · https://siliconangle.com/2026/01/28/apiiro-introduces-guardian-agent-secure-ai-driven-software-development/ · Cloudflare’s spec reviewer: ~600 designs, 3,200 invocations · https://noise.getoto.net/2026/08/04/how-cloudflare-enforces-engineering-standards-using-ai/ |
| 3 | **Review moved into the Git host itself.** Cursor is building a Git forge whose *Review* module is the default workflow, not an app bolted onto GitHub. | Cursor **Origin**, announced 16 Jun 2026 at Compile, GA “fall 2026” · https://eesel.ai/blog/what-is-cursor-origin · reported launching early on 13 Aug 2026 · https://news.aibase.com/news/30303 |
| 4 | **Multi-agent + independent reproduction became table stakes.** Single-pass review is now the *cheap* tier everywhere; the default claim is “each finding is reproduced before you see it”. | Claude Code `/ultrareview` reproduces every finding in an Anthropic cloud sandbox (22 Apr 2026, v2.1.86) · Snyk Evo: “every result verified independently of the agent that produced it” · https://snyk.io/news/snyk-launches-evo-agentic-appsec/ · Bugbot now *keeps* a rule violation even when the PR text claims it was intentional (12 Oct 2026) · https://cursor.com/docs/release-notes |
| 5 | **Per-seat pricing collapsed into usage credits.** Every major reviewer moved to metered review depth; budgeting a team now requires modelling PR volume, not headcount. | Bugbot usage-billed since May 2026 (~$1.00–1.50/run) · Claude Code Review $15–25/review managed, $5–20 `/ultrareview` · Copilot code review spends AI credits since 1 Jun 2026 ($0.25–5/review) · Greptile Base/Plus/Apex = 1/3/10 credits · GitLab flat $0.25/review |
| 6 | **Benchmarks matured — and got more honest about themselves.** Vendor-run leaderboards now publish methodology and admit per-PR recall hides per-finding weakness; independent work shows synthetic evaluation inflates scores by an order of magnitude. | GitHub **ReviewBench**, 5 Oct 2026 (219 PRs / 187 repos / 19 languages, agent submission via container image) · https://www.helpnetsecurity.com/2026/10/06/github-reviewbench-ai-code-review-benchmark/ · SWRBench (500 change-PRs + 500 clean-PRs) · and: F1 0.847 synthetic vs **0.066** on real PRs, arXiv 2606.15689 · https://arxiv.org/html/2606.15689v1 |
| 7 | **The bottleneck thesis is now measured, not argued.** Review capacity is the constraint, and it is worsening faster than adoption. | GitHub Octoverse 2026 (28 Oct): **>40% of PRs started by an agent** in Sept, ~110M agent-started PRs in one month · Faros “Acceleration Whiplash” (22,000 devs): median review time **+441.5%**, code churn **+861%**, zero-review merges **+31.3%**, bugs/dev **+54%** |
| 8 | **Security review split into three separately sold products:** pre-generation (in-IDE), PR-time, and continuous post-merge monitoring. | Snyk splits Evo ADS (blocks vulnerable code inside the agent) / Evo Code Scanning / Evo Agentic Security Review / Evo Remediation · Claude Security went continuous on 21 Oct 2026 · CodeRabbit Deep Scan added delta scans + **runtime reproduction** on 23 Oct 2026 |
| 9 | **Agent-specific attack surface went mainstream.** Prompt injection through PR *metadata* and poisoned agent *skills* are now documented, paid-bounty attack classes. | “Comment and Control” (Apr 2026) hijacked Claude Code Security Review, Gemini CLI Action and Copilot Agent via PR titles / issue bodies / HTML comments, with credential exfiltration and bug bounties · https://repello.ai/blog/comment-and-control-claude-code-gemini-copilot-prompt-injection · Mini Shai-Hulud `SANDWORM_MODE` (11 May 2026) injected rogue MCP servers into Claude Desktop / Cursor / Continue / Windsurf · https://labs.cloudsecurityalliance.org/research/csa-research-note-mini-shai-hulud-npm-supply-chain-20260516/ |
| 10 | **The open-source contribution supply became hostile.** Maintainers got a kill switch because a quarter of incoming PRs is now machine slop. | GitHub shipped repo-level PR controls (disable PRs, restrict to collaborators, cap concurrent PRs) on **27 Aug 2026** · Linux Foundation Research (30 Oct 2026): **25% of incoming PRs are “AI slop”** (31% at large projects), 59% of maintainers report rising volume · https://openssf.org/press-release/2026/10/30/new-lf-research-survey-shows-generative-ai-cuts-open-source-coding-time-in-half-but-25-of-incoming-pull-requests-are-considered-ai-slop/ |
| 11 | **Consolidation made *independence* a buying criterion.** The same companies now own the code generator and the code reviewer. | SpaceX/Anysphere $60B disclosed 16 Jun 2026 · Cursor/Graphite (~$290M, Dec 2025 → Origin) · Sonar/Gitar (21 May 2026) · OpenAI/Ona (11 Jun 2026) · Snyk/Invariant (MCP-Scan) — hence Tenki’s whole pitch: $0.50/review, source-agnostic, “if Cursor writes the code, Cursor shouldn’t review it” · https://tenki.cloud/blog/graphite-cursor-independent-code-review |
| 12 | **Free tiers moved, shrank or died** — a material change for anyone who built on them. | Gemini Code Assist consumer GitHub app: installs stopped 18 Jun 2026, **all review activity ended 17 Jul 2026**; new Standard/Enterprise subscriptions closed 9 Oct 2026, renewals end 2027 · https://9to5google.com/2026/06/17/gemini-cli-code-assist-shutting-down/ · DeepSource killed its Free plan (23 Feb 2026) · Tabnine went enterprise-only ($39–59/user/mo) · Amazon Q Developer stopped new sign-ups 15 May 2026, replaced by Kiro (IDE plugins EOL 30 Apr 2027) |
| 13 | **Model churn moved review quality more than product releases did.** | CodeRabbit’s security agent now runs on GPT-6.1 Sol (model launched 29 Sep, disclosure 26 Oct) · https://openai.com/index/gpt-6-1-sol-coderabbit-code-security/ · GitLab swapped the review LLM three times in 2026: Sonnet 4.6 → Sonnet 5 → **Sonnet 5.5** (5 Oct 2026) · CodeRabbit reported >10% recall improvement from Opus 4.7 with precision held steady · Entelligence measured GPT-6 Astra at **1.6× the cost per verified bug** vs GPT-5.6 Sol, and a cheaper “Luna-first” pipeline finding *more* bugs at the same cost · https://www.entelligence.ai/code-review |

---

## 3.2 New entries — #201–#250

Ordered by how structurally different the approach is (same rule as Part I: **rank ≠ quality**). Fourteen new clusters, AA–AN. None of these appears in #1–#200.

### Cluster AA — Review as an infrastructure primitive (forge & queue)
*The reviewer is no longer an app on top of GitHub; it is a module of a new Git host.*

**#201 · Cursor Origin** — https://cursor.com/origin · announcement explained: https://eesel.ai/blog/what-is-cursor-origin
Announced 16 June 2026 at Cursor’s Compile conference as “a Git forge for the agentic era” — code storage, Git hosting, review and collaboration, Git-compatible, API- and MCP-extensible, demoed at **22.6 commits/second in a single repo**. Two modules in the Cursor web UI: **Codebase** (sync/manage GitHub repos) and **Review** (an automated PR workflow that clears routine unresolved PRs through system+AI collaboration and only notifies a human when a key decision is needed). Built by the acquired **Graphite** team; internally called “Cursor Review”. Waitlist → fall 2026, reported launching early on 13 Aug 2026. Oct 2026 brought the **Origin App Marketplace** with 20+ integrations explicitly including code review, CI, security and monitoring. Why it matters: if the reviewer owns the merge queue, “review tool” stops being a SaaS add-on.

**#202 · /dev/fast (YC W2026)** — https://www.startuphub.ai/ai-news/claudes-corner/2026/claudes-corner-devfast-yc-w2026
Four-person YC W26 team building an AI-native code forge whose differentiator is a **git-native memory model**: agent knowledge lives in the diff and version-control history rather than in floating chat sessions, so review context never goes stale between PRs. Claims 2× shorter review cycle. Same thesis as Origin from the opposite direction — the review bottleneck is an artefact of review living outside version control.

### Cluster AB — Pre-generation and plan-level review
*Review the intent before the code exists. This cluster did not exist in August.*

**#203 · Baz Planner** — https://baz.co · launch: https://itbrief.news/story/baz-launches-planner-with-usd-9-million-seed-raise
Launched 30 Jun / 1 Jul 2026 alongside a $9M seed extension (total $17M, co-led Battery Ventures + boldstart). Sits **between the developer and the codebase**: evaluates every AI-generated suggestion against a risk matrix, blocks unsafe options and enforces boundaries **before any code is saved**, and checks the proposal against both the current *and* the proposed architecture. Four specialised agents, including a **Spec Reviewer Agent** (product requirements, design, expected behaviour) and an **Advanced Security Agent** (app code + infrastructure + pipelines + auth + network boundaries). Early adopters report >65% less downstream rework. Baz’s PR reviewer ranks **#1 on precision on Code Review Bench (70.4%)**. Israeli company, founded by ex-Palo Alto Networks Cloud AppSec people (Guy Eisenkot, founder of Bridgecrew) — https://www.calcalistech.com/ctechnews/article/cl8og4qtn

**#204 · Apiiro Guardian Agent** — https://apiiro.com · launch: https://siliconangle.com/2026/01/28/apiiro-introduces-guardian-agent-secure-ai-driven-software-development/
The only major product here that reviews **before generation**: a control plane for agentic development that governs Claude, Gemini, Cursor and homegrown agents and prevents vulnerable or non-compliant code from being generated by **rewriting prompts and injecting contextually secure prompts in real time**. Automates threat modelling of feature requests and design documents; powered by its AutoFix agent plus “Secure Prompt”; grounded in Apiiro’s Deep Code Analysis architecture graph from code to runtime. Named a Leader in the 2026 Gartner MQ for Software Supply Chain Security (22 Jun 2026) — https://www.globenewswire.com/news-release/2026/06/22/3315550/0/en/apiiro-named-a-leader-in-the-gartner-magic-quadrant-for-software-supply-chain-security.html. Customers include BlackRock, TIAA, USAA, Bloomberg, SoFi, Shell. Its framing: AI expands the attack surface up to 10×.

**#205 · AWS Kiro (spec-driven review)** — https://kiro.dev · review anatomy: https://www.qodo.ai/glossary/what-is-kiro-code-review/
GA March 2026 and **the replacement for Amazon Q Developer** (new Q sign-ups and subscriptions stopped 15 May 2026; IDE plugins EOL 30 Apr 2027; the Q CLI became Kiro CLI; since 29 May 2026 the newest models, including Opus 4.7, are Kiro-only). Review-relevant design: the agent writes `requirements.md` / `design.md` / `tasks.md` that you can edit **before** it touches code, so the reviewer has a spec to check against. **Agent hooks** can fire a review prompt on file save; **steering files** (`.kiro/steering/`) encode conventions; **Powers** package MCP tools + steering + hooks (AWS Security Agent and Qodo both ship Kiro Powers); the shipped feature-pipeline recipe includes an explicit **independent review** stage. Headless review in CI via `KIRO_API_KEY` and `kiro-cli chat --no-interactive` with read-only tools. Kiro Web (May 2026) added autonomous mode plus `/kiro all` and `/kiro fix` to address reviewer comments; a **Reviews panel** for GitHub PRs arrived 20 Jul 2026 (commenting/approving/merging stay in GitHub). Credit pricing: free 50 → Pro $20/1,000 → Power $200/10,000, enterprise overage $0.04/credit off by default; individual plans train on your content unless unticked; third-party harnesses banned on subscriptions; 2,824 open GitHub issues, with over-engineering (“20 files and 1,500 lines for something that needed 200”) the recurring complaint — https://www.reviewramble.com/tools/kiro

**#206 · AWS Well-Architected Agent** — https://dev.to/aws-builders/security-as-code-terraform-operations-on-aws-in-the-age-of-frontier-agents-10h4
Previewed October 2026: continuously analyses your environment **and reads your Terraform directly** against the Well-Architected Framework across 65+ services, returning concrete code changes. The most review-relevant piece of the AWS agent set, because its output is a proposed diff that must route through the same PR → scan → policy → apply pipeline as human code. Pairs with **AWS DevOps Agent** (incident triage whose proposals come back as PRs) and **AWS Security Agent** (#207).

### Cluster AC — Verification-first review
*Review that requires evidence the change actually behaves as claimed.*

**#207 · AWS Security Agent** — https://aws.amazon.com/blogs/aws/aws-security-agent-adds-threat-modeling-kiro-power-and-claude-code-plugin-and-more/
Now part of **AWS Continuum**. Three lifecycle stages in one agent: design-time (**STRIDE threat modelling** from design docs or source, preview), development-time (**repo-wide code review** plus **PR scanning with remediation** and security-requirement packs, preview), deployment-time (**on-demand penetration testing, GA**). Its distinguishing mechanic is **simulated validation**: the scanner executes each finding in an isolated environment and returns **proof of exploit**. Delivered where the agent already lives — a **Kiro power** (including an agent hook that decides whether to start a diff scan after the Kiro agent’s turn, and a “download findings → start a bugfix spec” flow), a **Claude Code plugin**, and an open **MCP** integration for any AI IDE. Integrations: GitHub, GitLab.com, GitLab Self-Managed, GitHub Enterprise, Bitbucket, Confluence — https://aws.amazon.com/about-aws/whats-new/2026/06/aws-kiro-power-claude-code/

**#208 · Cloudflare Codex + Spec Reviewer Agent** — https://noise.getoto.net/2026/08/04/how-cloudflare-enforces-engineering-standards-using-ai/
Not a product you can buy; the single most instructive published **review architecture** of 2026. A human-authored, human-owned standards corpus (“Cloudflare Codex”) written in RFC 2119 language (`MUST` / `SHOULD`), every clause with a named owner and a lifecycle (`approved` → `enforced`). Three consuming agents with deliberately narrow authority: an **AI code reviewer** (before merge), a **spec reviewer** (designs, before implementation) and a post-mortem reviewer. Results over roughly four months: **~230,000–250,000 violations flagged and ~16,000 merges blocked**, with ~600 specs reviewed across 3,200 invocations (65% major, 29% minor, 6% critical). None of the agents can do anything except flag and block; every block traces to a specific human-authored rule. This is the template to copy.

**#209 · superdiffs (Adee Labs)** — https://www.adeelabs.com/blog/ai-code-review-benchmark-results
A new reviewer notable for **publishing its own benchmark, including every miss**. Latest run 15 Oct 2026, production pipeline as configured (Claude Haiku 5.5 triage → Claude Opus 5.5 find/verify, confidence floor shifted −0.1): **68.0% of 25 seeded bugs found, 65.4% of comments correct, 26 findings, $1.30 of model time**, anchor accuracy 88.2%, 100% of posted findings verified. Prior run (30 Aug, matcher v2) was 80.0% / 66.7%. The page keeps older runs as history and explicitly refuses to publish cross-tool numbers until a comparable run exists, noting that seeded bugs are easier than real ones. In a market of self-scored leaderboards, that refusal is the differentiator.

**#210 · Tenki** — https://tenki.cloud
Sells exactly one thing: **independence**. The engine ingests PRs from GitHub without knowing or caring whether a Cursor agent, Copilot, Claude Code or a human wrote the diff, refuses telemetry cross-pollination, and treats agent-authored PRs as higher-risk by default (bot accounts, `Co-authored-by` trailers, branch-naming and PR-template fingerprints from Cursor/Codex). The business model is deliberately misaligned with rubber-stamping: **$0.50 per review**, charged per review rather than per merge, 10 free, ~2-minute GitHub App setup. Its benchmark innovation is **per-finding scoring** — 84 of 122 findings caught versus 44 for the next two systems — with three independent LLM judges and majority voting, plus the honesty to note its own recall comes with lower precision — https://tenki.cloud/blog/ai-generated-code-review-quality

### Cluster AD — Observability-grounded and insider-threat review
*Review against runtime truth, or against a human adversary rather than a bug.*

**#211 · Datadog BewAIre** — https://www.datadoghq.com/blog/ · engineering post 23 Mar 2026, summary: https://securitysenses.com/organisations/datadog
The only production reviewer in this document built to catch **malicious** source changes rather than defective ones. Datadog’s PR volume reached **~10,000 per week**, which made insider threat and review fatigue a measurable risk; BewAIre is an LLM review system that identifies hostile code introduced by threat actors, reduces approval fatigue for developers and **increases friction for attackers** by routing human judgment to the diff regions that matter. The conceptual move is the important part: the same review surface that buys productivity for honest developers also buys cover for dishonest ones, and automated review has to serve both.

**#212 · Cursor Security Review + Rollouts** — https://cursor.com/docs/release-notes
Launched on Teams/Enterprise **23 Sep 2026**. **Security Review** reports exploitable bugs on every pull request; **Rollouts** watches each change as it deploys and reports per-environment health (healthy / regression / inconclusive) without performing autonomous merges or rollbacks. With Bugbot’s October rule-integrity fix, this is the clearest example of a vendor closing the detect → ship → observe → attribute loop inside one product. Caveat worth stating plainly: Security Review, Bugbot and the agent that wrote the code are all one company — precisely the structural objection #210 monetises.

### Cluster AE — Frontier-lab review products
*Model vendors shipping review as a first-class product rather than a prompt.*

**#213 · Claude Code Review (managed) + `/ultrareview`** — https://claude.com/resources/articles/code-review-is-now-generally-available
Launched 9 March 2026 as a **multi-agent** system (research preview for Teams/Enterprise), GA **15 October 2026**. Deliberately narrow: **logic errors only, not style**, with severity colours (red / yellow / purple-for-preexisting), a written chain of reasoning per finding, and a final aggregator agent that de-duplicates and ranks. It never approves and never blocks. Review depth is selectable (Quick / Standard / Deep); `/code-review` aliases the old `/review`; both a GitHub Action and a CLI exist. `/ultrareview` (22 Apr 2026, v2.1.86) is the expensive tier: a fleet of reviewer agents in an Anthropic-hosted cloud sandbox where **every finding is independently reproduced** before it surfaces. The price of that independence is the story — **$15–25 per managed review**, **$5–20 per `/ultrareview`**, billed as extra usage, with only three trial runs for Pro/Max; Enterprise organisations can claim ≥$10,000 in credit by 15 Jan 2027. Internally, Anthropic reports that after adding “stopping rules”, merged PRs more than doubled, reverts fell >40%, and average review rounds to a pass went **2.08 → 1.32** — https://claude.dev/blog/solving-code-review-at-anthropic/

**#214 · Claude Security** — https://claude.com · analysis: https://explainx.ai/blog/claude-security-continuous-scanning-fix-tracking-api-mcp-2026
A separate product from Code Review, and the more structurally novel of the two. Public beta from April 2026; **on 21 October 2026 it stopped being a scan you run**: connect repositories once, it runs a deep baseline scan and then **re-scans changes continuously**, weighted by risk and complexity. It adds multi-repo *projects* so it can find issues that live between services; findings that **auto-close when the fix lands anywhere and reopen if the problem returns**; an **editable per-project threat model** plus knowledge base that decide what is worth flagging; attack-path explanations; an API, webhooks, an **MCP connector** and RBAC. Enterprise-only (not Pro/Max/Team), billed at direct token cost with **$25,000/month of free credits for two months through 31 Dec 2026**, no zero-data-retention, and OSS repos you do not own are excluded. Model access is the headline: scans run on **Claude Mythos 5** from 21 Aug 2026 without needing separate Cyber Verification access — the same class of model Anthropic described in April as autonomously finding thousands of unknown vulnerabilities across every major OS and browser, held back to a 40-company consortium (Project Glasswing) — https://www.marktechpost.com/2026/08/21/anthropic-brings-claude-mythos-5-to-claude-security/. Anthropic claims >1M vulnerabilities found by thousands of organisations since April; treat that as a findings count, not a fix count.

**#215 · OpenAI Codex Security (formerly Aardvark)** — https://openai.com · coverage: https://awesomeagents.ai/news/openai-codex-security-aardvark-malware-analysis/
Aardvark (private beta October 2025) was quietly rebranded **Codex Security** in February 2026 with a “Formerly Aardvark” badge, and gained a **malware-analysis pipeline** (upload samples, automated analysis, structured reports). The pipeline remains the best-articulated agentic security design of the period: build a repo-specific threat model by reading the whole codebase → scan new commits *and* back-scan history → **reproduce candidate issues in a sandbox to confirm exploitability** → attach a one-click Codex patch for human review. It reported 92% detection of known/synthetic vulnerabilities on golden repos at launch, ten CVE IDs from OSS disclosures, and pro-bono OSS scanning. By late 2026 it is credited on real CVEs (Chrome V8 type confusion, a FreeBSD local-privilege-escalation trio, dnsmasq parser bugs) — a materially stronger evidence class than any benchmark — https://bugflation.com/systems/openai-aardvark/. Note the churn: OpenAI CISO Matt Knight, co-architect of Aardvark, left in January 2026.

**#216 · Codex Security Review (GitHub PRs)** — https://learn.chatgpt.com/docs/security/security-review · coverage: https://aicatchup.com/news/openai-codex-security-review
Research preview **6 August 2026**. A *separate pass* from ordinary Codex review: invoke with `@codex security review`, or enable automatic runs on PR open / every push / alongside Code Review. It analyses the diff **plus repository context plus an optional threat model**, posts findings to the PR and a fuller report in the Codex **Security Report** tab. Automatic runs report High+Critical by default; manual runs report Medium and up, and the thresholds are configurable independently. Requires push/admin rights to enable; available on Enterprise/Business/Edu/Pro (Plus excluded); billed against the Codex allowance or ChatGPT credits. Contrast with ordinary Codex review, which is deliberately band-limited to **P0/P1 only** and reads `AGENTS.md`.

**#217 · OpenAI Daybreak + Patch the Planet** — https://www.ciodive.com/news/OpenAI-Daybreak-cyber-threats/820036/
Launched **11 May 2026**, expanded **22 June 2026**: Codex Security became a plugin inside Codex proper, **GPT-5.5-Cyber** went GA, and a **Cyber Partner Program** opened so security vendors can embed it. Partners named on the Daybreak page: Cloudflare, Cisco, CrowdStrike, Palo Alto Networks, Oracle, Zscaler, Akamai, Fortinet. **Patch the Planet** is the piece that matters for review: an initiative with **Trail of Bits, HackerOne, Calif and independent researchers** to move OSS maintainers from *finding* to *merged fix*, with human review mandatory before any patch merges — https://explainx.ai/blog/openai-daybreak-codex-security-cyber-defense. CodeRabbit joined the Daybreak Defense Network and committed $1M of free security scans on 12 Aug 2026. Counter-coalition: Anthropic’s Project Glasswing (Apple, Microsoft, Google, Amazon).

**#218 · Google Antigravity** — https://antigravity.google · review anatomy: https://www.qodo.ai/glossary/what-is-google-antigravity-code-review/
The product Google replaced Gemini CLI and the consumer Gemini Code Assist app *with*. Antigravity 2.0 launched at I/O **19 May 2026** as a desktop app for parallel agents plus a Go CLI, a Python SDK, managed agents and an enterprise layer, on a VS Code fork; the free tier includes Gemini 3.8/3.7/3.6 Flash, Gemini 3.1 Pro, **Claude Sonnet/Opus 4.6** and gpt-oss-120b, with undocumented, capacity-dependent rate limits that cannot be lifted with your own key. Review surfaces: **Agent Skills** (`SKILL.md` in `.agents/skills/`, committed to the repo, so a team shares one review skill); a **Review Changes** pane in the Agent panel where you comment on any diff in the conversation; **artifact-based review** (plans, walkthroughs and browser screenshots from an isolated Chrome profile); MCP with remote Streamable HTTP and custom headers; and a published codelab for an **SDK-based GitHub Action** that posts findings as PR comments. Also built into the Gemini macOS app since 13 Oct 2026. The structural weakness is stated by its own docs: the reviewer is the same agent family that wrote the code — https://makerstack.co/reviews/google-antigravity-review/

### Cluster AF — Agent-to-agent review
*The reviewer is invoked by the coding agent, mid-task, instead of after the PR.*

**#219 · Qodo Agentic Toolbox** — https://qodo.ai · launch: https://finance.yahoo.com/technology/ai/articles/qodo-launches-first-agent-agent-130000467.html
9 September 2026 — the first product explicitly sold as **agent-to-agent** review and governance. Coding agents (Claude Code, Codex, Kiro) invoke Qodo’s specialised agents and skills **inside the coding session**: understand architecture, dependencies and history before changing anything; run the **full review process on committed and uncommitted changes before a PR exists**; pull structured findings back to fix in-session; receive the organisation’s rules *before* implementation; and let admins manage policies conversationally. Qodo’s 2026 State of AI Code Quality Report (Censuswide, 500 US developers + 300 leaders, September 2026) is the empirical backing: **26% of developers and 26% of leaders rank reviewing/validating AI code as the #1 bottleneck**; 48% call it the biggest quality and governance gap; 36% say review takes the same time but more cognitive effort — the “trust tax” — https://www.globenewswire.com/news-release/2026/09/23/3367496/0/en/qodo-s-2026-state-of-ai-code-quality-report-reveals-growing-verification-challenge-as-agentic-development-scales.html

**#220 · Amp review agent** — https://ampcode.com · design notes: https://hackernoon.com/amps-code-review-agent-tries-to-cut-the-low-signal-noise
Shipped 7 January 2026 — one of the earliest dedicated *review* agents from a coding-agent vendor (Amp spun out of Sourcegraph; Cody went enterprise-only at $59/user/mo and Cody Free/Pro ended July 2025). It replaces the October 2025 one-shot “summarise the diff” panel with a dedicated review agent and toolset: pre-scan the diff, produce a change summary plus a **recommended review order** with per-file churn indicators, then run a full agentic review on request while you keep reading. The write-up is unusually candid about the unsolved parts: how reviews map to agent *threads* when one review spans several concurrent threads, and whether accepted or rejected findings should feed back into `AGENTS.md` memory. That question — review feedback as agent memory — is the one every vendor is currently answering differently.

### Cluster AG — Host-native and IDE-native review
*The Git host or the IDE ships the reviewer, so there is nothing to install.*

**#221 · JetBrains Junie + JetBrains Air** — https://junie.jetbrains.com · review: https://mcp.directory/blog/junie-jetbrains-coding-agent-2026
Junie went **GA in June 2026** and is the strongest “the agent uses the real toolchain” argument in the market: it runs your build and tests, drives the **actual IDE debugger** (breakpoints and runtime state, not log statements), and reviews PRs **with full project context from GitHub Actions, GitLab CI or the CLI**. It ranked #1 on **SWE-Rebench at 61.6% resolved / 72.7% pass@5** (June 2026, independent harness with fresh tasks). **Plan Mode** produces an editable plan you approve before any code is written, which is plan-level review by another name. One engine across IDE chat, tool window and CLI over ACP; BYOK with zero markup, local models, one-click migration from Claude Code/Codex. AI Chat is now an **agent hub** — Junie, Claude Agent, Codex (recommended default since June 2026), GitHub Copilot and any ACP agent — with per-agent `AGENTS.md`/`CLAUDE.md` support and `.aiignore` honoured only by Junie. Mellum, its own completion model that consumes no credits, went open as **Mellum2 12B, Apache-2.0** in June 2026. Pricing: AI Free (3 credits/30 days + unlimited completion), AI Pro $10/mo, AI Ultimate $30/mo, $1 top-ups, pooled credits via JetBrains Central. **22 September 2026: JetBrains Air** — Air, Air Teams and **Air Governance** (formerly JetBrains Central) — the same “review becomes governance” move as CodeRabbit and Cursor — https://javisreview.com/review/jetbrains-ai-assistant-review-2026/

**#222 · GitLab Code Review Flow (Duo Agent Platform)** — https://docs.gitlab.com/user/duo_agent_platform/flows/foundational_flows/code_review/
GitLab re-architected review as an **agentic flow** on the Duo Agent Platform (beta 18.7 → GA 18.8; platform GA 15 Jan 2026) and then did the opposite of its competitors on pricing: a **flat $0.25 per agentic code review**, so cost does not scale with merge-request size. Free-tier access arrived in 18.10 (19 Mar 2026) via group-level GitLab Credits; automatic review became default-on for new Duo trials in 19.1 (18 Jun 2026); review instructions cascade instance → group → project (19.0, 21 May; 19.1, 18 Jun); **follow-up reviews reached GA in 19.5 (15 Oct 2026)** so Duo builds on its own earlier comments and your replies; per-MR exclusion via `.gitlab/duo/mr-review-automated-rules.yaml` (GA 19.3); and **approvals/change-requests by the agent are in beta (19.5)**. 18.10 also GA’d **SAST false-positive scoring** for Ultimate. Open-weight models **GLM 5.3, Kimi K3 and MiniMax M3** (19.4, 17 Sep 2026) claim up to 4× more calls per credit. The review LLM changed three times in 2026: Sonnet 4.6 → Sonnet 5 (6 Aug) → **Sonnet 5.5 on Gemini Enterprise Agent Platform** (5 Oct). Watch the commercial shift: per a reported sales statement, Duo Pro/Enterprise seats are being phased toward the credits model — https://www.infoq.com/news/2026/04/gitlab-flatrate-view-ai-access/

**#223 · Gerrit 3.14 Review Agent** — https://www.gerritcodereview.com · ecosystem: https://github.com/GerritForge/ai-review-agent-provider
**Gerrit 3.14 turned AI Chat into a “Review Agent”** — a panel on the change screen that helps understand, summarise and review a change; on by default when an AI provider plugin is installed, and **disabled for private changes** (May 2026). The plugin API is the interesting part: `ai-review-agent-provider` (Java, generic provider interface), `ai-review-agent-gemini`, and `docker-gerrit-ai`, so an organisation can swap providers without forking. The community `ai-code-review` plugin posts comments after each patch set via ChatGPT or Ollama. This matters because Gerrit is where Android, much of telco and a good deal of automotive still live, and it was the last major forge without a native review agent.

**#224 · Bitbucket Rovo Dev code review** — https://www.atlassian.com/software/bitbucket/features/ai
Atlassian’s native “AI-assisted code review” on **Bitbucket Cloud** (Standard/Premium/Enterprise) — and, critically, **nothing on Bitbucket Data Center**: the self-managed documentation contains no native AI review as of 17 Sep 2026, so Data Center teams must put a third party behind a merge gate — https://dev.to/emilreiter/ai-code-review-on-bitbucket-data-center-whats-native-what-isnt-2b7j. Rovo Dev review supports Bitbucket Cloud **and GitHub**, and draws credits from the **pull-request author’s** Rovo Dev allocation, so if the author is out of credits the review silently does not run. Atlassian’s **Rovo MCP server** has exposed Bitbucket Cloud PR diff, comment and approval tools since 8 Apr 2026, which is how Claude Code and other MCP clients reach Bitbucket at all.

### Cluster AH — Security-agent suites and pre-emption
*AppSec vendors rebuilt around agents; review became one stage of a loop.*

**#225 · Snyk Evo Agentic AppSec** — https://snyk.io/news/snyk-launches-evo-agentic-appsec/
Launched **15 October 2026** as a *team* of agents, each sold as a stage: **Evo ADS** prevents vulnerabilities **inside the coding agent before code is emitted** (GA); **Evo Code Scanning Agent** pairs frontier reasoning with Snyk’s static analysis for broken access control and authentication logic — exactly where AI-generated code is weakest; **Evo Agentic Security Review** delegates a whole-repo security review to an agent that builds an application model *and* a threat model, then judges whether controls are present and sufficient against credible threat scenarios, independent of scanner coverage; **Evo Remediation Agent** runs the whole fix loop including the backlog, and a fix that would break the build is queued for approval rather than merged. Plus **Evo Dependency Firewall**, **Secrets Detection** and **Evo Continuous Offensive Security**. The design principle is stated in the release’s first paragraph: *“every result verified independently of the agent that produced it.”* Distribution already exists — Snyk Studio in 1,600+ customers’ CLIs, deterministic engines trusted by 4,800+. Context: CEO Peter McKay stepped down in February 2026, and Snyk cut ~90 roles and closed its Israeli development centre in June 2026 while re-organising around AI security.

**#226 · Checkmarx Triage Assist + Remediation Assist** — https://checkmarx.com · coverage: https://securitybrief.co.uk/story/checkmarx-revamps-ai-era-app-security-with-new-agents
Checkmarx One was re-architected around agents on **17 March 2026**. **Triage Assist** prioritises findings by **exploitability and contextual risk rather than static severity**; **Remediation Assist** produces review-ready fixes for validated vulnerabilities before merge; **Developer Assist** works preventatively in the IDE. The engine change matters more than the agents: a **hybrid SAST** pipeline of deterministic analysis plus purpose-tuned AI plus a **Finding Analysis Engine** that confirms true positives and suppresses false positives *before findings reach a developer*. Coverage now spans code, dependencies, **AI assets (models, prompts, datasets)** and runtime across 150+ technologies, with ASPM correlating nine scanners (vendor claim: 89% noise reduction, 43% productivity gain) — https://appsecsanta.com/checkmarx

**#227 · Semgrep Guardian** — https://semgrep.dev · independent review: https://www.francisokafor.com/tools/semgrep
The most important free-tier architectural move in security review: Guardian **installs into AI coding agents as an MCP server with hooks and skills** and scans each file the agent touches, using the same Code / Supply Chain / Secrets engines — so the agent is told it broke a taint rule while it is still editing. It complements the renamed AI layer **Multimodal** (19 Mar 2026, formerly Assistant) and **Autofix** (public beta 16 Mar 2026), which opens draft PRs with **line-level breaking-change analysis** for Code and Supply Chain findings. Autotriage reports 95% user agreement across 6M+ findings, −20% findings on day one, up to −40% after a week and ~60% backlog reduction; **Assistant Memories** are auto-suggested from triage behaviour (one Fortune 500 reported 2.8× better false-positive detection with two memories). Honest limits: cross-file taint skips Ruby, PHP, Swift and Rust entirely, and drops to single-file mode above 5 GB of memory.

**#228 · Semgrep Multimodal + Autofix (as a review product)** — https://semgrep.dev/docs · capability data: https://www.augmentcode.com/tools/semgrep-ai-code-review
Worth a separate entry because it is the clearest case of **deterministic engine + LLM judge** being sold as review rather than as “SAST plus chat”: explanations and remediation inside PR comments, fix PRs described as mergeable with minimal review, noise filtering that hides confirmed false positives from developers entirely, and diff-aware PR scanning so only changed code is analysed. The Pro cross-file engine detected 72–75% of vulnerabilities in independent suites versus 44–48% for Community Edition — the largest capability gap between a free and a paid tier in this document.

**#229 · Endor Labs AURI** — https://www.endorlabs.com · launch: https://venturebeat.com/technology/endor-labs-launches-free-tool-auri-after-study-finds-only-10-of-ai-generated
An agentic-security **harness** implementing the Gartner 2026 “Agentic Application Security Testing” pattern (reconnaissance → discovery → validation → prioritisation → remediation), free for individual developers, reaching into the coding tool over **MCP** (Cursor, Claude, Augment). Two facts are worth carrying: its own study found AI code is functionally correct 61% of the time but **functional *and* secure only ~10%** of the time; and in February 2026 AURI found and validated **seven vulnerabilities in OpenClaw** that its maintainers acknowledged — a real disclosure, not a benchmark. Endor also acquired **Autonomous Plane** (Kyle Quest, creator of DockerSlim) on 11 Feb 2026 to extend reachability from source code through container images, filtering up to 90% of scanner false positives — https://www.prnewswire.com/news-releases/endor-labs-acquires-autonomous-plane-expanding-ai-native-application-security-with-full-stack-reachability-from-code-to-container-302684888.html. Named a Representative Vendor in Gartner’s 2026 Innovation Insight for Agentic AST (8 Jun 2026); >$208M raised.

**#230 · Aikido AI Code Audit** — https://www.aikido.dev/code/code-audit
A new class Aikido positions *between* SAST and pentest: reasoning-model static audit that follows references across files to find **IDOR, broken access control, multi-step exploit chains, business-logic flaws, authentication bypass and privilege escalation**, with **no staging URL, no crawl and no traffic replay**, so it works on projects with no live environment. Credit-priced per repo, and it pairs with Aikido **Pentest** when runtime confirmation is needed. Distribution move worth noting: **OWASP gave every individual member 200 free credits for six months from 18 June 2026** — https://owasp.org/blog/2026/06/18/aikido-agentic-code-audit.html. Aikido’s State of AI in Security 2026: **69% of organisations have found vulnerabilities introduced by AI-generated code, and 1 in 5 had a serious incident tied to it** — https://www.aikido.dev/blog/top-greptile-alternatives

### Cluster AI — Agent and skill supply-chain review
*Reviewing the things the agent loads, not just the code it emits.*

**#231 · Snyk Agent Scan (formerly MCP-Scan)** — https://snyk.io · project: https://github.com/invariantlabs-ai/mcp-scan
Invariant Labs’ MCP-Scan was the first dedicated MCP security scanner and remains the most adopted (2k+ stars, Apache-2.0); it became the foundation of Snyk’s enterprise **Agent Scan** after the acquisition and was rebranded (v0.4.13, April 2026). It detects **tool poisoning** (malicious instructions inside tool descriptions), prompt injection through tool output, **tool shadowing**, **cross-origin escalation**, and **rug pulls** — with tool pinning to catch a server that changes after approval. Two modes matter for review: **passive scan** (`mcp-scan scan`, a one-shot audit of your MCP client configuration) and **active proxy** (continuous runtime monitoring with guardrail enforcement). Multi-client: Claude, Cursor, Windsurf, Gemini CLI, VS Code, Amazon Q. It also scans **agent skills**. If your team reviews agent-written code but never reviews the MCP servers the agent can call, this is the gap — https://appsecsanta.com/mcp-scan

**#232 · Socket MCP + AI-skill scanning** — https://socket.dev/blog/socket-mcp-supply-chain-investigation
The best existing answer to “the agent hallucinated a package”: **Socket MCP** exposes seven tools to the assistant itself — `depscore` scoring before a dependency is added, organisation alerts, **threat-feed review** (recent malware, typosquats, obfuscated packages), **artifact and package-file inspection**, grep inside published package contents, and mapping findings back to org exposure — across public and authenticated tiers. Separately, since 17 February 2026 Socket scans **AI agent skills**, starting with **skills.sh and its 60,000+ skills**, analysing *every file a skill references* regardless of language (a Python script invoked by a JS skill is scanned by the PyPI engine) and combining static analysis with LLM reading of a skill’s natural-language intent; validated against 382 known-malicious and 355 benign skills — https://socket.dev/blog/socket-brings-supply-chain-security-to-skills. Coverage spans npm, PyPI, Go, Maven Central, RubyGems, Packagist, NuGet, Scala, Kotlin, Cargo and GitHub Actions.

**#233 · Ship Safe** — https://www.npmjs.com/package/ship-safe · launch thread: https://www.reddit.com/r/cybersecurity/comments/1s17s7h/mcp_servers_are_the_next_big_attack_surface_here/
Open-source local scanner purpose-built for **agentic** security, runnable as `npx ship-safe audit .` with 17 local agents across 80+ attack classes and **no code leaving the machine**. Its MCP agent flags missing authentication and transport security on HTTP MCP servers, stdio transport without sandboxing, missing rate limiting, **typosquatted MCP servers** and broad filesystem access; its agentic agent flags agents running with elevated, admin, root or service-role permissions that a prompt injection could inherit. It produces a 0–100 security score with per-category deductions and a remediation plan; `ci --github-pr` blocks PRs that introduce AI-security issues and `diff --staged` scans only changed files. Cheap to run, worth it as a pre-commit gate.

**#234 · Lucidshark** — https://lucidshark.dev
A single local CLI **quality gate** bundling SAST, SCA, IaC, container scanning, linting, type checks and coverage, designed to run automatically before any PR. Its genuinely novel contribution is **HMAC-based redaction of review artefacts**: when you feed a diff or finding bundle to a model, secrets are replaced with deterministic pseudonyms (`sk-abc123` → `HMAC:7f3a2b`), consistently across the bundle, so the reviewer can still reason that “the same credential appears in three places” without the prompt ever containing the secret. That solves a second-order problem most teams miss: **the review prompt is itself an exfiltration channel**.

### Cluster AJ — Agent-era open-source reviewers
*New OSS built for output *from* agents rather than for human diffs. Star counts are October–November 2026.*

**#235 · zeroshot (`the-open-engine/zeroshot`)** — https://github.com/the-open-engine/zeroshot · 2.1k★
Open-source **meta-harness for coding agents**: you define the workflow, the reviewers and the repair loops, and zeroshot *enforces* the process you configured. Its distinction from every other OSS reviewer here is that it is not a PR bot — it constrains the agent’s process so that code arrives review-shaped. The most interesting project in this cluster for teams that have given up on prompt discipline.

**#236 · openqodex** — https://github.com/openqodex/openqodex · 1.1k★
“Open source AI code review **for coding agents**”: a *separate* reviewer checks every change the agent writes **before you push**, working inside Claude Code, Codex, Cursor and Cline, with **no account or key of its own**. The cleanest free implementation of the independence principle (#210) folded into the inner loop rather than the PR.

**#237 · sno-station (`sno-ai`)** — https://github.com/sno-ai/sno-station · 1.1k★
Puts Codex, Claude Code, Cursor, Hermes Agent and OpenClaw on **one local squad**: when one hits a usage limit another picks the task up from the same memory, and they **review each other’s code**. Open source, runs on your own machine. A different answer to “one model should not grade its own homework”: cross-vendor adversarial review, locally.

**#238 · mira (`miracodeai`)** — https://github.com/miracodeai/mira · 389★, updated 30 Oct 2026
Self-hosted reviewer with **indexed** PR reviews, walkthroughs, vulnerability scanning, dependency graphs, custom rules and a **learning loop** — i.e. the Greptile/Macroscope feature set, self-hosted, under 500 stars. Exactly the “worthwhile but not popular” category: the codebase is small enough to audit, which for a tool that reads all of your code is itself a security property.

### Cluster AK — Review skills (the new distribution unit)
*Prompts packaged as installable, versioned skills — the fastest-moving layer of late 2026.*

**#239 · Claude Code `/simplify` (bundled)** — https://claude.com/claude-code
Built in, no install: after you implement a feature, `/simplify` spawns **three parallel review agents** — code reuse, code quality, efficiency — aggregates their findings and applies the fixes. The significance is distribution rather than sophistication: a review workflow shipping inside the agent binary, invoked with one word, versus $24 per developer per month of SaaS. Multiply by Anthropic’s own statement that ~90% of Claude Code’s code is Claude-written.

**#240 · Matt Pocock `code-review` skill** — https://github.com/mattpocock/skills · ~291k★ / 24.4k forks on the skills repo, updated 13 Oct 2026
Reviews a branch on **two separate axes reported side by side**: the **standards axis** (does it follow repository conventions) and the **spec axis** (does it match what was asked for), run in **parallel sub-agents**. Its design rule is the most-quoted review principle of late 2026: separate *“this is ugly”* from *“this is wrong”* — only the second should block a merge. Companion skills in the same repo: `diagnosing-bugs` (reproduce before guessing) and `grilling` (the cheapest bug fix is the one caught before you build anything) — https://aibestprompts.in/aidevelopmentskills

**#241 · kyy-logs `code-review-skill`** — https://github.com/kyy-logs/code-review-skill · v0.1.0, 31 Oct 2026, 208★
“Auditable code review”: **four independent probes**, evidence-backed findings, and a **JSON-derived merge gate** — the verdict is computed from machine-readable findings rather than narrated by the model, which is what makes it usable as a gate rather than a commenter. Static-first, supporting `worktree` mode (staged, unstaged and untracked changes against HEAD) and `commits` mode (a fixed `base..head` range), with English and Chinese skill variants for Claude Code and Codex. Small, new, and structurally more honest than most paid tools — https://skillsllm.com/skill/code-review-skill

### Cluster AL — Agent governance and oversight
*Who watches the agents, as distinct from who reviews their output.*

**#242 · Zenity (AISPM + Runtime Boundaries)** — https://zenity.io/platform/ai-security-posture-management
Tel Aviv and New York; **$125M Series C** in early August 2026 led by Norwest (with Qumra, SoftBank Vision Fund 2, Hitachi Ventures and LG Technology Ventures joining, plus existing Vertex, Third Point, DTCP and Intel Capital) for ~$185M total — https://enterprisedna.co/resources/news/zenity-125m-series-c-ai-agent-security-governance-2026/. Gartner named it **“Company to Beat” in AI Agent Governance** (17 Apr 2026). **AISPM** evaluates each agent’s configuration, permissions and integrations *before it goes live* and keeps enforcing as they drift; **Runtime Boundaries** (July 2026) is event-driven enforcement **before an agent action executes**, tied to OWASP LLM Top 10 and MITRE ATLAS. It ships an **MCP gateway** and native hooks for coding and personal agents, including detection and prevention of **secret exfiltration and unsafe tool chaining on developer devices** — the control that would have blunted SANDWORM_MODE.

**#243 · CodeIntegrity** — https://codeintegrity.ai
$5M seed (May 2026) for **runtime security of AI agent actions**: agent discovery, policy enforcement and audit trails positioned before the agent touches sensitive systems. Read it as the commercial form of the question every reviewer should now ask — not “is this diff correct” but “was this action authorised at all”.

**#244 · Noma Security** — https://noma.security
Unified AI-security platform for agents and AI applications: discovery, posture, runtime protection and governance across the agent lifecycle. Notable mainly because it is named among the top Israeli AI-security companies for 2026 alongside Zenity — agent oversight has become its own category rather than a feature of code review — https://www.topinisrael.com/israel/best-ai-startups/

**#245 · Datadog AI Guard + Agent Console** — https://www.datadoghq.com/blog/dash-2026-new-feature-roundup-secure/
Two underrated pieces from DASH 2026 (June). **AI Guard for coding agents** (preview, starting with Claude Code) blocks prompt injection and malicious scripts **at runtime**. **Agent Console** meters the coding agents you already run — Claude Code, Cursor, Copilot — reporting their cost and output. Agent Console is quietly the first “review the reviewers’ economics” product: before you can govern agent output you have to see what your agents cost and ship per week — https://www.techtarget.com/it-infrastructure/opinion/DASH-2026-Datadog-goes-from-watching-code-to-writing-it

### Cluster AM — Vibe-code scanners for non-engineers
*A category that barely existed in August: cheap URL or repo scanners for apps built entirely by agents.*

**#246 · Vibe App Scanner** — https://vibeappscanner.com
150+ checks across 8 categories against a **live URL** — Supabase RLS tests, Firebase rules, rate limiting — with a free URL preview, then $29/mo (Go) or $49/mo (Pro). It is honest about its own limits: a URL scan cannot prove every user-role permission works, and “no findings is not proof of security”. That sentence is the most valuable thing in the category — https://justinmckelvey.com/blog/best-security-scanners-for-vibe-coded-apps

**#247 · VibeEval** — https://vibeeval.com
Live-app tests where findings are **confirmed by a security engineer** before you see them — 14-day free trial, Pro $25/mo, lifetime $249. The only entry in this cluster selling human verification rather than a model’s opinion.

**#248 · Launch Ready Code** — https://launchreadycode.com
URL-based, DAST-class readiness scanning that is **AI-platform-aware** (detects 11 AI app builders) and adds reliability and monitoring checks; free scan, $499 full audit. Its dataset is the most useful published vulnerability profile of agent-built software: 700+ AI-built apps scanned, average readiness **44/100**, and the top critical failures were **missing HTTP security headers (83%), no rate limiting on auth endpoints (71%), exposed API keys or secrets (67%), absent database row-level security (58%)**. Note the shape of that list: none of it is a clever bug. All of it is default-omission.

### Cluster AN — Evaluation infrastructure
*The scoring layer matured into something you can actually submit to.*

**#249 · GitHub ReviewBench** — https://github.blog · explained: https://www.devx.com/coding/what-is-reviewbench-ai-code-review-benchmark/
Published **5 October 2026**. 219 real pull requests from **187 open-source repositories across 19 languages**, with language and repository-size distribution mirroring GitHub and PR size deliberately re-weighted toward “the reviewable middle and tail”. Ground truth is a three-stage **golden set**: candidate findings from human reviewers, follow-up code changes, analysis tools *and* models → merge duplicates → score against a shared rubric. It reports **grounded precision, recall and F1** plus an adjustable **Fβ** so you can weight issue detection against false alarms, filterable by severity and category. Anyone can submit a reviewer by providing a **container image, configuration and model key**; agents run a 25-PR subset first, then three rounds on the full 219, all scored by the same AI judge, results private until a maintainer approves and published only on first entry or improvement. Copilot Code Review in Balanced mode currently tops it at **40.1% grounded F1** — a refreshingly low number, consistent with GitHub’s own finding that a **multi-model ensemble** (several independent model runs combined into one review) gained +8% addressed-rate, +13.6% recall and −8% cost versus a single-reviewer control — https://www.helpnetsecurity.com/2026/10/06/github-reviewbench-ai-code-review-benchmark/

**#250 · SWRBench** — https://arxiv.org · summary: https://www.emergentmind.com/topics/swrbench
The benchmark that answers “what about false positives”: **1,000 manually verified GitHub pull requests, deliberately balanced as 500 Change-PRs and 500 Clean-PRs** (4.05 commits / 6.29 files / 1.90 change points versus 3.25 / 6.85 / 0), each with **full project context via a codebase checkpoint**, scored by an LLM judge that checks whether a review *semantically covers* a structured ground truth rather than matching lexically, at ~90% agreement with human judgement. It also supplies the most honest calibration data in the field: human–LLM type-assignment consistency 69.4–94.8%, **inter-human agreement only 67.4–83.6%**, and severity agreement substantially lower still — a large share of “the reviewer got it wrong” is really “two humans disagreed”.

---

## 3.3 Status changes and corrections to #1–#200

Read this as the errata sheet: if you evaluated a tool from Part I or Part II before November 2026, re-check it here first.

| Entry (rank) | What changed | Date | Source |
|---|---|---|---|
| **CodeRabbit** (#12) | **$143M Series C at $1.5B** (co-led Atomico + Smash Capital; BMW i Ventures, Datadog, Hirtle Callaghan). >2M reviews/week, >17,000 customers (Nvidia, BMW, JFrog, Trivago, Adyen, Indeed), revenue ~5× YoY, cumulative ~$231M. Launched **Agentic Change Management** + **Triage** (scores value, urgency, risk, dependencies, readiness, reviewer fit; routes low-risk work to automation) + **Change Stack** (guided view of contracts, domain behaviour, integrations, tests, migrations, plus blast-radius and architecture analysis). Committed $10M/yr to keep OSS free, $1M in free security scans, joined OpenAI’s **Daybreak Defense Network** | 12 Aug 2026 | https://www.businesswire.com/news/home/20260812311754/en/CodeRabbit-Raises-$143-Million-at-$1.5-Billion-Valuation-and-Introduces-Agentic-Change-Management |
| **CodeRabbit** (#12) | **Security shipped properly**: Deep Scan with **Delta Deep Scans** (26 Oct) and delta triggers (28 Oct); **Runtime verification** of Deep Scan findings with a “Reproducer Guide” that Runtime Analysis can execute in a CodeRabbit environment (23 Oct); **security merge blocking** via a published CodeRabbit Security check (5 Oct); Deep Scan API on all plans (1 Oct); linked repositories as context (2 Oct); Claude Code rules in Code Guidelines (15 Oct); CLI 0.9.0 / 0.9.1 with `cr code` cloud tasks; Slack Agent at **$0.40/agent-minute** | Sep–Oct 2026 | https://docs.coderabbit.ai/changelog |
| **CodeRabbit** (#12) | **Repackaged pricing** (1 Sep 2026): Pro → **Essentials** ($24 annual / $30 monthly), Pro+ → **Team** ($48 / $60), new **Advanced $72** bundling continuous security monitoring, per-PR security review, Blast Radius and Architecture Impact (replacing the $40/user Security add-on). Overage **$0.25 per reviewed file**; Team’s included limits trimmed with higher quotas moved to Advanced; **free on public repos unchanged** | 1 Sep 2026 | https://www.usagepricing.com/blueprint/coderabbit |
| **CodeRabbit** (#12) | Security agent now runs on **GPT-6.1 Sol** as its primary model (model released 29 Sep, 1.05M context, 128k output) | 26 Oct 2026 | https://openai.com/index/gpt-6-1-sol-coderabbit-code-security/ |
| **Greptile** (#5-ish) | **$50M Series B at $750M** (Menlo Ventures, Benchmark participating). Pricing rebuilt with **no seat fees**: **Starter free for 1 active developer (50 credits/mo)**, **$1 per review credit**, and review-depth tiers **Base = 1, Plus = 3, Apex = 10 credits** (Plus/Apex added Sep 2026 to buy more parallel subagent time on risky changes). Free for OSI-licensed non-commercial OSS; pre-Series A under $2M revenue get 500 credits/mo for 6 months. Still no Bitbucket/Azure DevOps; self-hosting is Enterprise-only | Sep–Oct 2026 | https://www.llms.blog/posts/greptile-raises-50m-at-a-750m-valuation-what-the-ai-code-reviewer-does-and-what-it-costs |
| **Greptile** (#5-ish) | **Correction to the Part I version note:** v3 (late 2025) introduced agentic review built on the **Claude Agent SDK**; v4 (early 2026) was an accuracy release; “**Agent v4**” was announced **21 Jul 2026** (+74% addressed comments, 43% acceptance from 30%). The 82% catch claim remains **self-designed and self-scored** — independent re-scoring of the same data by DeepSource and Augment put it near **45%** | Jul 2026 | https://bestaiq.com/greptile-review/ |
| **Macroscope** (#7) | Engine now referred to as **v3** with a 98% precision claim (vendor). Pricing quoted as **$0.05 per KB of diff reviewed, $0.50 floor, no seats** — a model change from the old $30/active-developer seat. Internal benchmark: ~5% more bugs caught with **75% fewer comments** than the second-best tool on 100+ real bugs | Feb–Oct 2026 | https://macroscope.com/content/macroscope-vs-greptile-ai-code-review-comparison |
| **GitHub Copilot code review** (#9-ish) | **GA on an agentic architecture** (5 Mar 2026) replacing the single-pass model; runs on GitHub Actions, so runners are now part of setup. **Copilot can submit an approving review** satisfying required-approval rules (public preview 1 Sep; off by default, path-scopable, dismissed on new commits). **Auto-resolution + shell verification** (11 Sep) — it verifies by running builds, tests and scripts. Default effort profile → **Balanced** (28 Sep). **`AGENTS.md` support GA** (18 Jun), 4,000-char instruction cap removed (Jun), content exclusion (12 Jun). Billing: **AI credits since 1 Jun 2026**, $0.25–5/review at default effort, plus Actions minutes on private repos | Mar–Sep 2026 | https://github.blog/changelog/2026-09-01-copilot-code-review-can-now-approve-pull-requests/ |
| **GitHub Copilot** (#9-ish) | **Now reviews Azure Repos PRs** (public preview, sprint 279, 4 Sep 2026) — every Azure DevOps customer, no signup; org/project/repo enablement, Managed DevOps Pools, org/project/repo/path instructions, automatic review via **branch policies** including drafts. Built on the Copilot SDK; **AI processing runs on GitHub infrastructure**, not your pipeline agent | 4 Sep 2026 | https://learn.microsoft.com/en-us/azure/devops/release-notes/2026/sprint-279-update |
| **Cursor Bugbot** (Part I) | **Usage-billed since May 2026**; **~90 s average review** (from ~5 min), 0.62 bugs/run, −22% cost/run, on Composer 2.5; **2M+ PRs/month**, resolution rate 70%+ (52% at launch), 0.7 bugs flagged/run, ~0.5 resolved bugs/PR; `/review`, `/review-bugbot`, `/review-security` pre-push commands (Cursor 3.7+, 5 Jun); incremental “only what changed” reviews; **Autofix** spawns Cloud Agents. Oct 2026 fix: **rule violations are no longer dropped when the PR description claims the change was intentional** | Jun–Oct 2026 | https://cursor.com/changelog/bugbot-updates-june-2026 |
| **Graphite** (Part I) | Acquired by **Cursor** in Dec 2025 (~$290M); integration live **3 Mar 2026** (Cursor Cloud Agents create PRs inside Graphite, Diamond reviews them). Still GitHub-only; AI review requires Team at $40/user/mo. Its team now builds **Origin** (#201) | Mar 2026 | https://tenki.cloud/blog/graphite-cursor-independent-code-review |
| **Gitar** (Part I/II) | **Acquired by Sonar, 21 May 2026** — five weeks after exiting stealth with $9M (Venrock + Sierra Ventures, 15 Apr). Remains standalone, positioned inside Sonar’s verification platform alongside the SonarQube CLI, SonarQube Plugin for Claude Code, SonarQube Remediation Agent, Sonar Context Augmentation and **SonarSweep** (claims −67% vulnerabilities in LLM output) | Apr–May 2026 | https://techcrunch.com/2026/04/15/gitar-a-startup-that-uses-agents-to-secure-code-emerges-from-stealth-with-9-million/ |
| **Devin / Cognition** (Part I/II) | **Devin Review** launched 21 Jan 2026 (“AI to stop slop”) as PR comprehension; **Devin 2.2** (24 Feb) added desktop computer-use and self-review catching ~30% more issues, 3× faster start (~15 s); **Devin 3.0** added dynamic re-planning; **SWE-1.7** own model (8 Jul, Kimi K2.7 base, ~1,000 tok/s via Cerebras); **Devin Security Swarm** (1 Jul) runs “Agentic MapReduce” parallel agents for business-logic flaws and chained attacks with sandbox reproduction and fix PRs; **FedRAMP High** (13 Jul); **TierZero** acquisition (20 Jul); **Series E: >$2B at $48B** (8 Sep); Devin Desktop (Windsurf successor, 2 Jun); Devin Fusion (−60% cost, 29 Jun; up to 39% more efficient in Desktop/CLI on 11 Sep); **FrontierCode 2.0** (27 Oct, graded by OSS maintainers on mergeability); self-serve plans from 14 Apr now charge for Ask Devin and Devin Review | Jan–Oct 2026 | https://cognition.com/blog |
| **Qodo** (Part I) | **2.0** shipped Feb 2026 (multi-agent: bugs, security, quality, test-coverage in parallel, writes missing tests). **Agentic Toolbox** 9 Sep 2026 (#219). **Plugin for Codex** GA Sep 2026 (Reviewer, Review Resolver, Codebase Wisdom). **Relevance** scores each finding High/Medium/Low from how the team handled similar findings in past PRs. Free tier 30 PR reviews + 250 credits/mo; Pro Team $30/mo (≤30 users) at $0.012/credit; air-gapped on GitHub Enterprise, GitLab Self-Managed, Bitbucket Data Center and **Gerrit** with self-hosted models | Feb–Oct 2026 | https://www.qodo.ai/blog/ai-code-review/ |
| **PR-Agent** (Part I/II) | **Donated by Qodo to a community-owned organisation in April 2026 and reverted to Apache-2.0**; now community-maintained (v0.47.0 on 2 Oct 2026) with its first external maintainer and a move toward a foundation. Still the broadest forge support: GitHub, GitLab, Bitbucket, Gitea, Gerrit, Azure DevOps, CodeCommit, local | Apr–Oct 2026 | https://kodus.io/en/open-source-ai-code-review-tools-compared/ |
| **Kodus / Kody** (#8) | `selfhosted-2.2.4` (27 Sep 2026); **AGPLv3** with commercial `ee/`; GitHub, GitLab, Bitbucket, Azure DevOps, **Forgejo/Gitea**, plus GitLab Self-Managed, Bitbucket Data Center and GHES (beta). Kody Rules import `AGENTS.md`, `CLAUDE.md`, Cursor rules and Copilot instructions; Linked Repositories add up to 3 repos; Community free (10 rules, 3 plugins, no SSO), Teams **$8/dev/mo** annual ($10 monthly) plus model costs, Enterprise adds SOC 2, RBAC and audit logs. Internal 38-PR benchmark: **Kodus 30/38 vs Bugbot 22, Copilot 20, CodeRabbit 15** | 2026 | https://kodus.io/en/ai-code-review-tools/ |
| **SonarQube** (Part I) | Beyond the Gitar acquisition: **AI Code Assurance** (flags AI-generated code and applies stricter gates) and **AI CodeFix**; **SonarQube CLI** for agentic coding environments; **SonarQube Plugin for Claude Code**; **Remediation Agent**; **Context Augmentation**; **SonarSweep**. AI CodeFix runs **without outbound internet** on self-hosted models. Sonar also took a Leader placement in the 2026 Gartner MQ for Software Supply Chain Security | 2026 | https://www.sonarsource.com/ |
| **Semgrep** (Part I) | AI layer **renamed Multimodal** (19 Mar 2026); **Autofix** public beta (16 Mar); **Guardian** (#227) installs into coding agents as MCP + hooks + skills. Free ≤10 contributors / 10 repos; Teams $30/contributor/mo; Enterprise adds 50 AI credits/dev/mo, SSO, on-prem and a custom model provider | Mar–Aug 2026 | https://www.francisokafor.com/tools/semgrep |
| **Snyk** (Part I) | Whole platform rebuilt as **Evo Agentic AppSec** (15 Oct 2026, #225); **Snyk Agent Fix** renamed from DeepCode AI Fix (May 2026); acquired **Invariant Labs / MCP-Scan** → **Snyk Agent Scan** (#231). Corporate: CEO Peter McKay departed Feb 2026; ~90 roles cut and the Israeli development centre closed in Jun 2026 | Feb–Oct 2026 | https://snyk.io/news/snyk-launches-evo-agentic-appsec/ |
| **Endor Labs** (Part I) | **AURI** launched free for individual developers, integrating Cursor/Claude/Augment over MCP; **acquired Autonomous Plane** (11 Feb 2026); named a Representative Vendor in Gartner’s **2026 Innovation Insight for Agentic Application Security Testing** (8 Jun 2026) — the report that formally named this category | Feb–Jun 2026 | https://www.endorlabs.com/learn/endor-labs-named-a-representative-vendor-in-the-gartner-r-innovation-insight-for-agentic-application-security-testing |
| **Aikido** (Part I) | Launched **AI Code Audit** between SAST and pentest; **200 free credits for every OWASP individual member** for six months from 18 Jun 2026. Pricing: free 2 users; Basic **$350/mo for 10 users**; pentest ~$4,000. Published State of AI in Security 2026 (69% / 1-in-5 incident stats) | Jun 2026 | https://owasp.org/blog/2026/06/18/aikido-agentic-code-audit.html |
| **Corgea** (Part I) | AI-native **BLAST** engine (LLM + AST) for business logic, IDOR, broken access control and mass assignment; imports Snyk/Semgrep/Checkmarx/Fortify/CodeQL/Coverity findings; false positives <5% claimed vs 20%+ traditional; auto-fix PRs claimed >90% accurate; free tier **2 devs / 10 repos / 10 autofixes per month**; Growth $39/dev/mo, Scale $49/dev/mo; **AI pentesting is a separate paid product** | 2026 | https://toolradar.com/tools/corgea |
| **ZeroPath** (Part II) | Total funding **$12.5M** by Feb 2026 (Crosspoint, HOF, SurgePoint, YC, Paul Graham). Semantic plus tree-reasoning static analysis with exploitability pathways, service-boundary detection across monorepos and microservices, and conversational patch generation; SAST + SCA with reachability + secrets (40+ file types) + IaC + containers; GitHub/GitLab/Bitbucket/Azure DevOps/Jira/Linear/Slack | Feb 2026 | https://guardiansofthemachineage.com/vendors/zeropath/ |
| **Tabnine** (Part I) | **Enterprise-only now** — free and individual plans gone; **$39–59/user/mo**; Gartner **Visionary 2026** for Enterprise AI Coding Agents; SOC 2 Type II, GDPR, ISO 27001; four deployment modes including **air-gapped on-prem via Dell PowerEdge + NVIDIA**; **Tabnine CLI** (Jan 2026); Code Review Agent; Enterprise Context Engine (+82% acceptance claim); trains only on permissive OSS with Code Provenance attribution | 2026 | https://aiunpacking.com/review/tabnine/ |
| **Amazon Q Developer** (Part I) | **Retired as a front door**: no new sign-ups or subscriptions after **15 May 2026**; IDE plugins and paid subscriptions reach end of support **30 Apr 2027**; the Q CLI became **Kiro CLI**; newest models Kiro-only since 29 May 2026. This supersedes the CodeGuru → Q migration path noted in Part I | 2026 | https://www.reviewramble.com/tools/kiro |
| **Gemini Code Assist** (Part I) | **Consumer product gone**: the free-individual tier stopped serving requests **18 Jun 2026**; the consumer GitHub review app stopped installs on 18 Jun and **all review activity ended 17 Jul 2026**. New Standard/Enterprise subscriptions closed **9 Oct 2026** (annual renewals end 31 Jan 2027, monthly 31 Dec 2027) and Google points users to **Antigravity** (#218). The **enterprise GitHub reviewer survives as a separate Google Cloud product** in Preview, free during preview | Jun–Oct 2026 | https://www.qodo.ai/glossary/what-is-gemini-code-assist-code-review/ |
| **Sentry Seer** (#3) | Expanded on **27 January 2026** from production-only to **all three stages**: local development (the Sentry MCP server feeds runtime context to coding agents), **code review** (analyses PRs for defects with high production-impact potential, explicitly skipping style) and production (automatic root-cause analysis, delegated fixes). Repriced to a **flat $40 per active contributor per month, unlimited** | 27 Jan 2026 | https://sentry.io/changelog/seer-now-debugs-in-every-stage-of-development/ |
| **DeepSource** (Part I) | Free plan **deprecated** (23 Feb 2026) in favour of a narrower **Open Source** plan for OSS organisations only; Business → **Team** with **$120/seat/yr bundled AI Review credits**. AI Review now runs alongside static analysis on every PR with AI filtering of static-analysis false positives; new **DeepSource Agents** and Iterative Fix Refinement; “Copy as Markdown” export so findings can be pasted into a coding agent | 23 Feb 2026 | https://deepsource.com/changelog/2026-02-23 |
| **Bito** (Part I) | Agentic review engine claims −57% false positives and +89% faster merges; **AI Architect** local knowledge graph (zero code leakage); Team $12/seat/mo annual ($15 monthly), Professional $20 ($25), 5K LOC/seat/mo then $5 per extra 1K LOC; $8.9M raised; SOC 2 | 2026 | https://aicodereview.io/tools/bito/ |
| **CodeAnt AI** (Part I) | YC-backed, **$2M seed at $20M valuation** (YC, VitalStage, Uncorrelated, DeVC, Transpose, Entrepreneur First); **$10/dev/mo** for basic AI review and **$40/dev/mo** for the full quality + security + compliance suite; 30+ languages; on-prem option; claims >50% review-time reduction | 2026 | https://techeconomy.ng/codeant-ai-raises-2m-to-automate-code-reviews |
| **CodeScene** (#6) | Behavioural analysis unchanged in concept, but now ships **explicit checks on AI-generated code** inside PR quality gates, plus **ACE** AI refactoring (6 languages only). Free for OSS; from €18/author/mo; on-prem or cloud; G2 4.6/5 | 2026 | https://dev.to/rahulxsingh/best-ai-code-review-tools-in-2026-expert-picks-397b |
| **Ito** (#1) | Out of stealth on Product Hunt (#2 of the day) with a **free tier: first 10 PRs plus qualifying OSS**; GitHub only, no GitLab. Mechanics confirmed: test plan from code + PR description + ticket + your input; single-use isolated container with credentials and seed data; mocks what it cannot reach; agent swarm clicks, navigates, calls APIs and verifies the database; returns video, logs and screenshots. **Trade-off: runs can take up to an hour**, and it works best on monorepos | 2026 | https://www.producthunt.com/products/ito-ai-code-review-that-runs-code |
| **Vercel OpenReview** (#4) | **Downgraded. The repository has no licence file** as of August 2026, so despite being described as open source it grants no formal rights; the model is hardcoded to Claude Sonnet 4.6; **no commits since March 2026** (~1.5k stars, not archived). Do not build a review pipeline on it until the licence lands | Aug 2026 | https://aicodereview.io/blog/open-source-ai-code-review-tools/ |
| **Alchemize** (#122) | Idea validated rather than changed: Origin (#201) and /dev/fast (#202) are both commercialising PR decomposition and narrative review. Alchemize’s differentiator — two-way GitHub sync with GitHub remaining source of truth — is now the contested ground | 2026 | https://tryalchemize.com |
| **Martian Code Review Bench** (#199) | Now the reference *independent* leaderboard. 10 Oct 2026 last-month view (15 tools, 17,505 scored PRs): **cubic 64.0, Kody AI 63.4, Greptile 63.2, CodeRabbit 61.8, Claude 60.9, Copilot 60.9** (Copilot #4 online, #5 offline), range 48.7–64.0. Caveat: **Kody AI was scored on only 155 PRs versus 777–2,497 for others** | Oct 2026 | https://www.cubic.dev/best-ai-code-review-tools |
| **SWE-bench and friends** (#197) | Effectively superseded for agent work: **Terminal-Bench 4.0** (66 tasks, released 28 Aug 2026), **FrontierCode 1.1/2.0** (Cognition; mergeability graded by OSS maintainers), **SWE-Atlas-QnA-AA**, **DeepSWE**; Artificial Analysis **Coding Agent Index v2.0** is the equal-weight average of FrontierCode v1.1, Terminal-Bench 4.0 and SWE-Atlas-QnA-AA. SWE-Bench-Pro-Hard-AA was removed from the index | 2026 | https://artificialanalysis.ai/methodology/coding-agents-benchmarking |
| **Entelligence** (Part I) | Published the most-cited 2026 head-to-head (8 reviewers, **67 production bugs**, 5 repos): F1 **Entelligence 47.2%, Codex 45.4, Claude 42.8, Bugbot 39.4, Greptile 36.9, CodeRabbit 33.0, Copilot 22.6, Graphite 13.4**. Also published the most useful cost/performance research of the period: GPT-6 Astra cost **1.6× more per verified bug** than GPT-5.6 Sol, and a cheaper “Luna-first” routing found **12 more bugs at the same cost** | Jan–Sep 2026 | https://www.entelligence.ai/code-review-benchmark-2026 |

---

## 3.4 Numbers that moved

**Production-scale telemetry — the strongest evidence class in this document.**

| Signal | Value | Source |
|---|---|---|
| PRs started by an AI agent on GitHub | **>40%** in Sept 2026 (17% in March) ≈ **110M agent-started PRs in one month** | GitHub Octoverse 2026, 28 Oct · https://aicybr.com/blog/github-octoverse-2026-agent-pull-requests-code-review-governance |
| Commits / pushes / merged PRs (12 months) | 34.3B commits (from 12.9B) · 17.9B pushes · 1.3B merged PRs | same |
| Agent PRs merged within 2 weeks | **90%** vs ~86% without detected agent involvement (agents were *behind*, at 83%, in February) — GitHub measured merges, not correctness | same |
| Median time in code review | **+441.5%** | Faros AI, “The Acceleration Whiplash”, 22,000 devs / 4,000 teams · https://hyrax.dev/blog/review-gap-measurable-faros-ai-telemetry-2026 |
| Code churn (rewritten within two weeks) | **+861%** | same |
| Incident-to-PR ratio / monthly incidents | **+242.7%** / **+57.9%** | same |
| Bugs per developer | **+54%** (versus +9% the prior year) | same |
| PRs merged with **zero** review | **+31.3%** — capacity ran out, not a policy change | same |
| Daily PR contexts per developer | **+67.4%**; work restarts +13.8%; tasks idle ≥7 days +26% | same |
| AI-assisted PR size / time to first reviewer | **2.5× larger**; ~**16 hours** versus 200 minutes | same |
| Delivery stability per +25% AI adoption | **−7.2%** (throughput −1.5%). High-AI teams: +98% merged PRs, PRs +154% larger, review **+91% longer**, bugs/dev +9% | DORA 2026 · https://dora.dev/ai/gen-ai-report/report/ |
| Time to first action on AI-generated / agentic PRs | **4.6×** / **5.3×** longer than human PRs; approval rate **32.7%** for AI-generated vs **84.4%** for human | LinearB 2026 Benchmarks, 8.1M PRs / 4,800 orgs |
| OSS contribution quality | **25% of incoming PRs are “AI slop”** (31% at large projects); 59% of maintainers report rising volume | Linux Foundation Research, 30 Oct · https://openssf.org/press-release/2026/10/30/ |
| Cloudflare’s internal reviewer | ~**230,000–250,000** standards violations flagged; **~16,000 merges blocked**; ~600 specs reviewed across 3,200 invocations | https://noise.getoto.net/2026/08/04/how-cloudflare-enforces-engineering-standards-using-ai/ |
| Datadog PR volume (why BewAIre exists) | ~**10,000 PRs/week** | Datadog engineering, 23 Mar 2026 |
| Anthropic’s own review stack | merged PRs **>2×**, reverts **−40%**, review rounds to pass **2.08 → 1.32** | https://claude.dev/blog/solving-code-review-at-anthropic/ |
| Review as the top delivery bottleneck | **26%** of developers and **26%** of leaders; **48%** call it the biggest quality/governance gap; **36%** report a “trust tax” | Qodo State of AI Code Quality 2026 (Censuswide, n=500+300) |
| Japan, same finding | ~**90%** of 322 reviewers report increased burden; **78.6%** have fixed AI-caused bugs; coding is **0%** of the bottleneck while code review is ~**31%** (2nd) | Kagikake Creation 2026; AI DevEx 2026 · https://tech-blog.tabelog.com/entry/ai-devex-conference-2026-report |

**Code quality and security baselines.**

| Signal | Value | Source |
|---|---|---|
| Duplicated code blocks | **+81%** (40.3 → 73.0 per million changed lines); duplicated blocks linked to 15–50% more defects | GitClear, 623M changes · https://www.gitclear.com/the_ai_code_quality_maintainability_gap |
| Refactoring share of changed lines | **21% (2022) → 3.8% (2026 YTD)**; cross-file connectivity −35%; error-masking +47%; refactoring −70%; edits to code older than a year −74% | same |
| Security pass rate of AI-generated code | **56%**, stalled (55% earlier in 2026); **44%** of tasks introduce ≥1 known vulnerability with no security instruction. Worst classes: log injection **12%**, XSS **15%**; best: crypto **87%**, SQLi **83%** | Veracode 2026 GenAI Code Security Report · https://www.matthewswong.com/en/blog/veracode-2026-genai-code-security-report-pass-rate/ |
| Functional versus secure | AI code functionally correct **61%** of the time, functional **and** secure **~10%** | Endor Labs study, 2026 |
| Developer trust versus verification | **96%** do not fully trust AI code; only **48%** always verify before committing (a 48-point gap); **53–61%** have shipped code that “looked correct but wasn’t reliable” | Sonar State of Code 2026, n=1,149 · https://www.sonarsource.com/state-of-code-developer-survey-report.pdf |
| Test-suite weakness inflating agent scores | **77%** of benchmark instances admitted ≥1 surviving mutant that still passed the existing suite; strengthening suites materially cut agent resolved-rates | PROBE, ASE ’26 |
| LLM reviewer capability, real versus synthetic PRs | F1 **0.847 synthetic vs 0.066 real (92% degradation)**; F1 **0.657** for diffs under 10 lines → **0.043** for diffs over 150 lines; a smaller/cheaper model (Haiku 4.5) beat a larger one (Sonnet 4.6) at 3.2× lower cost | arXiv 2606.15689 · https://arxiv.org/html/2606.15689v1 |
| LLM review reasoning quality | Models systematically **over-correct** on requirement conformance; explanation/fix-oriented prompting raises false rejections; rationales are internally inconsistent and show high symptom-level but weak cause-level fault awareness | arXiv 2603.00539, “Are LLMs Reliable Code Reviewers?” · https://arxiv.org/html/2603.00539v1 |
| Package hallucination, 2026 re-test | **4.62%–6.10%** across five frontier models (down from 5.2–21.7%), but **127 names invented identically by all five** (109 PyPI, 18 npm) and **53 still registrable** | “The Range Shrinks, the Threat Remains”, May 2026 · https://www.matthewswong.com/en/blog/slopsquatting-2026-frontier-models-package-hallucination/ |
| Terraform/IaC from agents | First-attempt deployment success **20.8–30.2%**; policy-compliant only **8.4%** (DPIaC-Eval, FSE 2026). TerraFormer (ICSE-SEIP ’26) tested 17 frontier LLMs and attributes the gap to HCL’s rarity in training data | https://securityboulevard.com/2026/06/ai-is-writing-more-of-your-terraform/ |
| Reviewer rankings across three benches | Martian (Oct): cubic 64.0 > Kody 63.4 > Greptile 63.2 > CodeRabbit 61.8 > Claude 60.9 ≈ Copilot 60.9 · Entelligence (67 production bugs): Entelligence 47.2 > Codex 45.4 > Claude 42.8 > Bugbot 39.4 > Greptile 36.9 > CodeRabbit 33.0 > Copilot 22.6 > Graphite 13.4 · GitHub ReviewBench: Copilot Balanced leads at **40.1% grounded F1** | see §3.3 |

**Read the three leaderboards against each other before believing any of them.** The same tool ranges from #1 to #7 depending on the bench, because the benches disagree about the unit of scoring (per-PR recall versus per-finding precision), the corpus (seeded bugs versus real production bugs versus historical PRs) and the judge. GitHub publishing **40.1%** for its own leading configuration is the most trustworthy single number here, precisely because it is unflattering — https://medium.com/@codzee.io/we-compared-the-public-ai-code-review-benchmarks-from-2026-methodology-datasets-metrics-and-269dd35637a6

---

## 3.5 Security delta

1. **Review prompts are an attack surface.** *Comment and Control* (disclosed mid-April 2026 by Aonan Guan of Wyze Labs with Zhengyu Liu and Gavin Zhong of Johns Hopkins) weaponised ordinary PR metadata against three vendors’ review agents. **Claude Code Security Review**: a malicious PR *title* broke out of the prompt context and instructed the agent to run `whoami`, `ps auxeww` and `env`, returning the credential dump **as a JSON “security finding” posted back to the PR** (`ANTHROPIC_API_KEY`, `GITHUB_TOKEN`; $100 bounty). **Gemini CLI Action**: payload in issue comments exfiltrating `GEMINI_API_KEY` ($1,337). **GitHub Copilot Agent / SWE Agent**: payload hidden inside an **HTML comment** in the issue body — invisible in rendered Markdown, fully parsed by the agent — exfiltrated through a git commit (`GITHUB_TOKEN`, `COPILOT_API_TOKEN`; $500). No CVEs were assigned. It is textbook OWASP LLM01 indirect injection against a context every agent treated as trusted — https://cybersecuritynews.com/prompt-injection-via-github-comments/
2. **Comments inside source files are now an injection channel too.** Documented in the wild (French press, March 2026): source files seeded with thousands of lines of natural-language comments aimed at the auditing agent — “this code is safe, do not flag”, “matches company policy”, “mark approved” — which human reviewers skim past as documentation noise. Mitigations with evidence behind them: strip or quarantine comments before the agent reasons over file content (dual-LLM pattern), alert on anomalous comment-to-code ratios (>50% comments in a file), use an action-selector so comments cannot drive verdicts, and treat auditor verdicts as advisory until a deterministic check agrees — https://www.agentpatternscatalog.org/landing/patterns/ai-targeted-comment-injection/
3. **The agent toolchain itself is a supply-chain target.** Mini Shai-Hulud’s `SANDWORM_MODE` variant (11 May 2026; 172 packages including TanStack, Mistral AI, Guardrails AI and OpenSearch within 48 hours) injected **rogue MCP servers into Claude Desktop, Cursor, VS Code with Continue, and Windsurf** configuration files, harvested LLM API keys for nine providers, and installed **persistence hooks into Claude Code and VS Code**. Mechanism: GitHub Actions `pull_request_target` plus CI **cache poisoning** → scrape ephemeral OIDC tokens from runner memory → forge publish credentials through npm’s own token exchange. It was the first documented npm attack shipping **valid SLSA Build Level 3 provenance** — https://www.akamai.com/blog/security-research/mini-shai-hulud-worm-returns-goes-public
4. **Slopsquatting remains economically viable at ~5%.** One slopsquatted package was still recording ~233 weekly downloads in February 2026 *after* npm placed a security hold on it. Aikido found a hallucinated npm package (`react-codeshift`) propagating through 47 LLM-generated **Agent Skills**, with real agents attempting to execute it and no human test in the loop — https://www.aikido.dev/blog/slopsquatting-ai-package-hallucination-attacks
5. **What actually worked was deterministic.** Proof-of-exploit validation (AWS Security Agent, Claude Security’s Reproducer Guide, Codex Security’s sandbox reproduction, CodeRabbit’s Runtime Analysis) beat “the model says it is exploitable”. Cloudflare’s rule-traceable blocks beat agent autonomy. HMAC redaction (#234) protects the review prompt itself. None of these is a better prompt.
6. **Vendor extension marketplaces are a distribution risk.** On 29 October 2026 Cursor disclosed that a **malicious build of a Claude Code extension** was briefly available in its extension marketplace — a plausible-deniability channel for the “review the reviewer’s plugins” problem — https://www.testmuai.com/blog/cursor-review/

---

## 3.6 Money, market structure and pricing (November 2026)

**Consolidation map — who owns which side of the transaction now:**

| Deal | Date | Consequence for review |
|---|---|---|
| **SpaceX acquires Anysphere/Cursor, $60B all-stock** | disclosed 16 Jun 2026 | Largest venture-backed acquisition on record; brings Colossus compute, Grok and 4M Cursor users under one owner. Cursor’s reviewers (Bugbot, Security Review) now sit inside a model-and-compute owner |
| **Cursor acquires Graphite** (~$290M) | Dec 2025 | Became **Origin** (#201). The reviewer now owns the merge queue |
| **Sonar acquires Gitar** | 21 May 2026 | “Verification platform” bundles AI review with deterministic standards enforcement |
| **OpenAI acquires Ona (ex-Gitpod)** | announced 11 Jun 2026 | Gives Codex **persistent cloud environments** — microVMs plus 10-minute checkpointing, so agent tasks survive closing your laptop |
| **Snyk acquires Invariant Labs (MCP-Scan)** | → **Snyk Agent Scan** | Agent/MCP security folds into AppSec |
| **Endor Labs acquires Autonomous Plane** | 11 Feb 2026 | Reachability from source code through container images |
| **Cognition**: SWE-1.7, Security Swarm, TierZero, FedRAMP High, **$2B at $48B** | Jul–Sep 2026 | The coding agent now ships both its own reviewer and its own vulnerability hunter |
| **Factory**: $150M at $1.5B (Apr) → **$200M at $5B** (Sep) | 2026 | Droids: Writer / **Reviewer** / Tester / Docs / Deployer, plus an “agent-readiness” score for your codebase |
| **CodeRabbit**: $143M at $1.5B | 12 Aug 2026 | The pure-play reviewer is now a $1.5B company |
| **Greptile**: $50M at $750M | 2026 | Menlo Ventures; no seat fees, credit-priced depth |
| Same window, other categories | 2026 | Lovable $400M @ $13.3B · Legora $550M @ $8.8B · Harvey $550M @ $15.5B · Daytona $60M @ $1B (Oct) · Zenity $125M C · Rein Security $25M A · CodeIntegrity $5M seed · Asymptote Labs $5.5M seed · Vesta $30M |

**Structural read:** every major *generation* vendor now ships a *reviewer* — Anthropic, OpenAI, Google, AWS, Cursor, Cognition, JetBrains, Sourcegraph/Amp, ByteDance, Alibaba, Tencent, Huawei — and every independent reviewer’s pitch has shifted from “we find more bugs” to “**we are not the company that wrote your code**”. That is a defensible product claim, and it is why CodeRabbit, Qodo, Baz and Tenki all use the word “independent” in the first paragraph of their positioning.

**Market size:** Gartner (20 May 2026) puts the **enterprise AI coding agent market at $9.8–11.0B annualised as of April 2026**, and predicts that by 2027 **>65% of engineering teams using agentic coding will treat the IDE as optional**; its “next stage” feature list explicitly includes *AI-assisted code review*. Narrower AI-review-plus-security TAM estimates land at **$2–3B in 2026**, growing 30–40% year on year on $1.2B+ of venture funding — https://enterprisedna.co/resources/news/gartner-enterprise-ai-coding-agents-10-billion-market-2026/ · https://aipulse.nayaone.com/landscape/ai-code-review-and-security

**Price sheet, October–November 2026** — what you actually pay to review one PR:

| Tool | Model | Effective cost |
|---|---|---|
| CodeRabbit Essentials / Team / Advanced | per developer who opens PRs | $24 / $48 / $72 per dev/mo annual; overage **$0.25 per reviewed file**; free on public repos |
| CodeRabbit Security | per user | **$40/user/mo** (folded into Advanced) |
| Greptile Starter / Pro | credits, no seat fees | free (1 dev, 50 credits) → **$1/credit**; Base 1, Plus 3, **Apex 10** |
| Qodo | prepaid credits | $30/mo base (≤30 users), **$0.012/credit**; free 30 PRs/mo |
| Cursor Bugbot | usage credits | ~**$1.00–1.50/run**; Teams $40/user/mo includes an allowance |
| Claude Code Review | token usage | **$15–25** managed · **$5–20** `/ultrareview` |
| GitHub Copilot code review | AI credits at $0.01 | **$0.05–1.00** (Lite) → **$0.25–5.00** (Balanced) per review, plus Actions minutes |
| OpenAI Codex review | plan allowance / credits | counted against ChatGPT/Codex usage; GitHub reviews billed separately |
| **GitLab Duo Code Review Flow** | flat | **$0.25 per review** — the predictable outlier |
| Sentry Seer | flat | **$40 per active contributor/mo**, unlimited |
| Tenki | per review | **$0.50** |
| cubic | per developer | $30/mo annual ($40 monthly); free 20 PRs/org/mo; **$20 per extra 10k lines** |
| Kodus / Kody | seat + your own model | **$8–10/dev/mo** plus provider cost, no markup |
| Bito | seat + LOC | $12–25/seat/mo, 5K LOC/seat then **$5 per extra 1K LOC** |
| Macroscope | per diff size | **$0.05 per KB**, $0.50 floor |
| Semgrep / Snyk / Aikido / Checkmarx | platform tiers | free tiers exist, enterprise quoted. Snyk free = 100 code tests/mo; Aikido free = 2 users; Semgrep free = ≤10 contributors; SonarQube Cloud free ≤50k private LOC; CodeQL free on public repos |

**Model-layer prices that set the floor** (10 Oct 2026): gpt-6.1-sol and Claude Sonnet 5.5 both **$2/M input, $10/M output**; gpt-6-luna and Claude Haiku 5.5 **$0.10 / $0.50**. A small model at 20× lower cost is why “Luna-first” pipelines can beat frontier-only ones on cost per verified bug.

---

## 3.7 Revised playbook — what the late-2026 evidence changes

The Part I / Part II recommendation (“deterministic tools plus one independent LLM reviewer”) survives. Five amendments are now evidence-backed:

1. **Add a second, source-agnostic reviewer, and make independence explicit.** With >40% of PRs agent-started and the same vendors owning generation and review, *who reviews* is a control question. Practically: keep the Git host’s native reviewer **and** add one reviewer that cannot see which agent wrote the diff (Tenki #210, Baz, or a self-hosted model on a different provider), and log which model reviewed what, for which repository.
2. **Gate on plan and spec, not just the diff.** The cheapest bug is the one blocked before the code exists. Baz Planner (#203), Kiro specs (#205), Apiiro Guardian (#204) and Cloudflare’s spec reviewer (#208) all remove a class of finding that diff review structurally cannot see. If you cannot buy it, copy it: a `MUST`-style standards file, human-owned, with the reviewer allowed to *block* only what is already in the `enforced` state.
3. **Treat “same time, more cognitive effort” as a capacity problem, not a training problem.** 36% of developers report the trust tax, median review time is +441.5%, and 31.3% more PRs merge with zero review. The only interventions with published numbers behind them: route reviewer attention by risk, cap PR size at the source, and stop counting merges as success.
4. **Gate test *discrimination*, not coverage.** 77% of agent benchmark instances admitted a mutant that passed the existing suite. If one agent writes the code and the tests, coverage proves execution, not verification — so gate on mutation score over changed lines, plus a merge-blocking rule against weakening existing assertions or deleting tests.
5. **Verify findings by execution or do not post them.** Every product that gained credibility in late 2026 did so by *reproducing* the finding: sandbox exploit proofs, runtime reproducer guides, `/ultrareview`’s reproduction requirement, seeded-bug benchmarks that publish their misses. A finding that cannot be reproduced is a comment, and comments are what caused the trust tax.

**What got worse for free/OSS users:** Gemini Code Assist’s consumer reviewer is gone; DeepSource’s free plan is gone; Tabnine has no free tier; Vercel OpenReview has no licence and no commits since March; the Amazon Q plugin line dies in April 2027. **What got better:** GitLab charges **$0.25/review flat**; **cubic gives 20 PRs/org/mo free**; **Greptile’s Starter is a real free seat**; **CodeRabbit stays free on public repos** with $10M/yr committed; **Kodus Community is free with your own key**; **Aikido gave every OWASP member 200 credits**; and the whole agent-era OSS cluster (#235–#238) did not exist in August.

Two operational additions for anyone reviewing agent output specifically:

- **Review the agent’s inputs, not only its outputs.** MCP server configs, `AGENTS.md`/`CLAUDE.md` rule files, installed skills, and the package registry are now part of the review surface — see #231, #232, #233 and the SANDWORM_MODE section. A diff that is clean but calls a poisoned MCP server is a shipped incident.
- **Measure the queue, not the tool.** Track time-to-first-review, PR size distribution, share of PRs merged with no review, and the ratio of AI-authored PRs to reviewer capacity. Those four numbers diagnose the actual bottleneck faster than any tool trial, and all four are available from Faros-style telemetry.

---

## 3.8 Query log (104 queries, 5 November 2026)

**English — product and launch (34):** new AI code review tool launched 2026 · AI code review startup funding 2026 · CodeRabbit news October 2026 · Greptile code review 2026 update · “code review” AI agent release September 2026 · AI code review benchmark October 2026 results · Cursor Bugbot 2026 launch update review agent · cubic.dev AI code review funding 2026 · “Kody” Kodus AI code review 2026 · Devin Review Cognition 2026 launch AI code review · Macroscope AI code review 2026 update funding · Sonar acquires Gitar AI code review 2026 · “vibe coding” security review tool 2026 new startup · Claude Code Security review October 2026 announcement enterprise · OpenAI Codex code review @codex security review 2026 · GitLab Duo code review agent 2026 update · Gemini Code Assist code review 2026 Google agent · Google Antigravity code review agent 2026 · JetBrains AI code review agent 2026 Junie · Sourcegraph Amp code review 2026 · AWS Kiro code review agent 2026 · Snyk AI code review agent 2026 launch · Semgrep AI assistant 2026 code review new feature · Corgea AI security code review 2026 · ZeroPath AI security 2026 funding code review · Aikido Security AI code review 2026 new · Endor Labs AI application security 2026 · Mobb Pixee automated vulnerability fix 2026 · Apiiro AI generated code governance 2026 · GitHub Copilot coding agent 2026 review AGENTS.md · OpenAI Aardvark security researcher agent 2026 · Datadog Code Security 2026 AI code review · Checkmarx 2026 AI agents code review One · Veracode 2026 AI code review agent fix

**English — market, benchmark and research (28):** AI code review market size 2026 Gartner forecast · DORA 2026 report AI adoption delivery stability · METR study 2026 AI coding productivity developer · Claude Skills code review agent skill October 2026 · Cursor 3.9 changelog October 2026 review · Ona Gitpod 2026 AI agent code review · Vercel OpenReview 2026 update self-hosted code review · Cursor “Origin” rebrand 2026 code review product name · Factory Droids 2026 code review enterprise · Augment Code review 2026 codebase context · Bitbucket Pipelines AI code review 2026 Atlassian Rovo · Azure DevOps AI code review agent 2026 · Gerrit AI review 2026 GerritForge agent · air-gapped self-hosted AI code review 2026 sovereign EU · npm supply chain attack 2026 Shai-Hulud AI agent · Socket.dev 2026 AI package security new feature · maintainers overwhelmed AI generated pull requests 2026 open source · LLM code review research paper 2026 evaluation · Terminal-Bench FrontierCode 2026 benchmark agent coding · runtime verification code review 2026 Ito new startup · Israeli AI code review startup 2026 · Baz code review Planner 2026 benchmark precision weighted · GitHub Octoverse 2026 report AI code statistics · AI code review vendor acquisitions consolidation 2026 · Zenity AI agent oversight guardrails 2026 · Ellipsis Korbit Sourcery 2026 AI code review · Tenki code review 2026 independent reviewer · prompt injection in code comments AI reviewer 2026 attack

**English — long tail (18):** CodeRabbit “Agentic Change Management” 2026 what is · SWRBench code review benchmark 2026 dataset · AI code review Terraform infrastructure as code 2026 agent · database migration review AI 2026 schema change safety · mutation testing AI agent 2026 test quality verification · Qlty Code Climate 2026 code quality AI · Faros AI Jellyfish 2026 engineering metrics AI code review data · AWS Security Agent 2026 code review pentest Kiro · TerraFormer ICSE 2026 LLM Terraform security study · Qodo Gartner Visionary 2026 Series B code review · new AI code review startup 2026 stealth YC batch review agent · agent sandbox PR verification 2026 Daytona E2B code review · CodeRabbit vs Qodo vs Greptile October 2026 comparison pricing · Cloudflare “Engineering Standards Enforcement” AI code review blocked merges 2026 · “AI DevEx 2026” report code review bottleneck survey · OpenAI Daybreak cyber defense network 2026 partners · Greptile “Apex” tier 2026 pricing Plus · CodeRabbit “Advanced” plan 2026 new tier security · Claude Mythos model 2026 Anthropic security

**Chinese (12):** 2026 AI代码评审 工具 新发布 · 阿里云 云效 AI 代码评审 2026 更新 · 腾讯 CodeBuddy 2026 代码评审 更新 · Trae 字节 2026 code review 智能评审 · 华为 CodeArts 2026 代码检视 AI · 开源 AI code review 2026 GitHub stars new project · plus the Chinese-language comparison and analysis pages cited in Part II and §3.3 (CodeRabbit 1300万 PR 案例, Qodo 2.0 多 Agent 架构, Macroscope v3 98% 精确率, 通义灵码/云效 GitLab 内网接入, CodeArts 码道公测, 腾讯 TCA, CodeBuddy /cr 与 /security-review)

**Japanese (2):** AIコードレビュー おすすめツール 2026 · 日本 コードレビュー AI 導入事例

**Community and primary surfaces sampled:** X/Twitter (Aikido Security, OpenAI Devs, AISecHub, Cursor, model-leak trackers), Reddit (r/codereview, r/ExperiencedDevs, r/vibecoding, r/cybersecurity, r/ChatGPTCoding), Hacker News (Octoverse, Acceleration Whiplash and “How the Claude Code team does code review” threads), GitHub Topics (`ai-code-review`: 1,007 public repositories as of November 2026), GitHub Changelog, vendor changelogs and pricing pages, arXiv, ICSE-SEIP ’26, FSE ’26, ASE ’26.

**Honest gaps.**
1. Several benchmark and pricing figures are vendor-reported. Where a claim is self-scored it is labelled as such in the entry.
2. Two widely repeated 2026 claims could not be corroborated and are **not asserted anywhere in this document**: a reported OpenAI acquisition of Windsurf for $3B in March 2026 (Cognition acquired Windsurf in July 2025 and shipped Devin Desktop from it in June 2026), and a reported Synopsys acquisition of Apiiro in January 2026 (Apiiro was still operating independently and being named a Gartner MQ Leader in June 2026).
3. Kody AI’s #2 Martian ranking rests on 155 scored PRs versus 777–2,497 for competitors.
4. CodeRabbit and several peers publish review volumes they do not break down by human-accepted versus auto-resolved findings.
5. X.com’s logged-out search endpoint blocks automated retrieval (HTTP 403), so X-sourced items here come via web search results and vendor reposts rather than direct scraping.

---

*End of Part III. Running total across all three parts: **250 distinct AI code review tools, products, modules and evaluation systems**, every entry with an explicit URL. Search coverage: Part I — 64 English queries; Part II — 68 Chinese + English queries; Part III — 104 queries in English, Chinese and Japanese. **236 queries total.***
