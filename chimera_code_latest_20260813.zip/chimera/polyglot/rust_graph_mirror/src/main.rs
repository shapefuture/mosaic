use std::collections::HashMap;
use std::env;
use std::fs;
use std::io;
use std::path::{Path, PathBuf};
use tree_sitter::Node;

fn ignored(path: &Path) -> bool {
    path.components().any(|part| {
        matches!(
            part.as_os_str().to_str(),
            Some(
                ".git"
                    | ".chimera"
                    | "node_modules"
                    | "__pycache__"
                    | ".venv"
                    | "build"
                    | "dist"
                    | "target"
                    | "out"
            )
        )
    })
}

fn files(root: &Path, current: &Path, output: &mut Vec<PathBuf>) -> io::Result<()> {
    let mut entries: Vec<_> = fs::read_dir(current)?.filter_map(Result::ok).collect();
    entries.sort_by_key(|entry| entry.path());
    for entry in entries {
        let path = entry.path();
        if ignored(path.strip_prefix(root).unwrap_or(&path)) {
            continue;
        }
        if path.is_dir() {
            files(root, &path, output)?;
        } else if matches!(
            path.extension().and_then(|x| x.to_str()),
            Some(
                "py" | "ts"
                    | "tsx"
                    | "js"
                    | "jsx"
                    | "go"
                    | "rs"
                    | "java"
                    | "cpp"
                    | "c"
                    | "rb"
                    | "php"
                    | "cs"
                    | "swift"
                    | "kt"
                    | "scala"
                    | "sh"
            )
        ) {
            output.push(path);
        }
    }
    Ok(())
}

fn identifier_after<'a>(line: &'a str, marker: &str) -> Option<&'a str> {
    let offset = line.find(marker)? + marker.len();
    let value = &line[offset..];
    let end = value
        .find(|c: char| !(c.is_ascii_alphanumeric() || c == '_'))
        .unwrap_or(value.len());
    if end == 0 {
        None
    } else {
        Some(&value[..end])
    }
}

fn python_symbols(line: &str) -> Vec<(&'static str, &str)> {
    let text = line.trim_start();
    for marker in ["async def ", "def "] {
        if text.starts_with(marker) {
            return identifier_after(text, marker)
                .map(|name| vec![("Function", name)])
                .unwrap_or_default();
        }
    }
    if text.starts_with("class ") {
        return identifier_after(text, "class ")
            .map(|name| vec![("Class", name)])
            .unwrap_or_default();
    }
    Vec::new()
}

fn generic_symbols(line: &str) -> Vec<(&'static str, &str)> {
    for (marker, kind) in [
        ("function ", "Function"),
        ("def ", "Function"),
        ("fn ", "Function"),
        ("class ", "Class"),
        ("interface ", "Class"),
        ("type ", "Class"),
        ("const ", "Function"),
    ] {
        if let Some(name) = identifier_after(line, marker) {
            return vec![(kind, name)];
        }
    }
    Vec::new()
}

fn text<'a>(node: Node<'a>, source: &'a [u8]) -> &'a str {
    node.utf8_text(source).unwrap_or("")
}

fn qual(scope: &[String], name: &str) -> String {
    if scope.is_empty() {
        name.to_string()
    } else {
        format!("{}.{}", scope.join("."), name)
    }
}

fn walk_symbols(
    node: Node<'_>,
    source: &[u8],
    scope: &mut Vec<String>,
    symbols: &mut HashMap<String, String>,
) {
    match node.kind() {
        "class_definition" => {
            if let Some(name_node) = node.child_by_field_name("name") {
                let name = text(name_node, source).to_string();
                symbols.insert(name.clone(), qual(scope, &name));
                scope.push(name);
                if let Some(body) = node.child_by_field_name("body") {
                    walk_symbols(body, source, scope, symbols);
                }
                scope.pop();
                return;
            }
        }
        "function_definition" => {
            if let Some(name_node) = node.child_by_field_name("name") {
                let name = text(name_node, source).to_string();
                symbols.insert(name.clone(), qual(scope, &name));
                scope.push(name);
                if let Some(body) = node.child_by_field_name("body") {
                    walk_symbols(body, source, scope, symbols);
                }
                scope.pop();
                return;
            }
        }
        _ => {}
    }
    let mut cursor = node.walk();
    for child in node.named_children(&mut cursor) {
        walk_symbols(child, source, scope, symbols);
    }
}

fn call_target(node: Node<'_>, source: &[u8]) -> Option<String> {
    let function = node.child_by_field_name("function")?;
    if function.kind() == "identifier" {
        return Some(text(function, source).to_string());
    }
    if function.kind() == "attribute" {
        if let Some(attribute) = function.child_by_field_name("attribute") {
            return Some(text(attribute, source).to_string());
        }
        let mut cursor = function.walk();
        return function
            .named_children(&mut cursor)
            .last()
            .map(|child| text(child, source).to_string());
    }
    None
}

fn walk_calls(
    node: Node<'_>,
    source: &[u8],
    scope: &mut Vec<String>,
    caller: Option<String>,
    symbols: &HashMap<String, String>,
    calls: &mut Vec<(String, String)>,
) {
    match node.kind() {
        "decorated_definition" => {
            let mut search = node.walk();
            let definition = node.child_by_field_name("definition").or_else(|| {
                node.named_children(&mut search)
                    .find(|child| child.kind() == "function_definition")
            });
            if let Some(function) = definition {
                if function.kind() == "function_definition" {
                    if let Some(name_node) = function.child_by_field_name("name") {
                        let decorated_caller = qual(scope, text(name_node, source));
                        let mut cursor = node.walk();
                        for child in node.named_children(&mut cursor) {
                            walk_calls(
                                child,
                                source,
                                scope,
                                Some(decorated_caller.clone()),
                                symbols,
                                calls,
                            );
                        }
                        return;
                    }
                }
            }
        }
        "class_definition" => {
            if let Some(name_node) = node.child_by_field_name("name") {
                scope.push(text(name_node, source).to_string());
                if let Some(body) = node.child_by_field_name("body") {
                    walk_calls(body, source, scope, caller, symbols, calls);
                }
                scope.pop();
                return;
            }
        }
        "function_definition" => {
            if let Some(name_node) = node.child_by_field_name("name") {
                let name = text(name_node, source).to_string();
                let current = qual(scope, &name);
                scope.push(name);
                let mut cursor = node.walk();
                for child in node.named_children(&mut cursor) {
                    if child != name_node {
                        walk_calls(child, source, scope, Some(current.clone()), symbols, calls);
                    }
                }
                scope.pop();
                return;
            }
        }
        "call" => {
            if let (Some(from), Some(target)) = (caller.clone(), call_target(node, source)) {
                if let Some(to) = symbols.get(&target) {
                    calls.push((from, to.clone()));
                }
            }
        }
        _ => {}
    }
    let mut cursor = node.walk();
    for child in node.named_children(&mut cursor) {
        walk_calls(child, source, scope, caller.clone(), symbols, calls);
    }
}

fn python_calls(source: &[u8]) -> Vec<(String, String)> {
    let mut parser = tree_sitter::Parser::new();
    parser
        .set_language(&tree_sitter_python::LANGUAGE.into())
        .expect("Python grammar");
    let Some(tree) = parser.parse(source, None) else {
        return Vec::new();
    };
    if tree.root_node().has_error() {
        return Vec::new();
    }
    let mut symbols = HashMap::new();
    walk_symbols(tree.root_node(), source, &mut Vec::new(), &mut symbols);
    let mut calls = Vec::new();
    walk_calls(
        tree.root_node(),
        source,
        &mut Vec::new(),
        None,
        &symbols,
        &mut calls,
    );
    calls
}

fn output_rows_for_file(root: &Path, path: &Path) -> Vec<String> {
    let bytes = fs::read(path).unwrap_or_default();
    let source = String::from_utf8_lossy(&bytes);
    let relative = path
        .strip_prefix(root)
        .unwrap()
        .to_string_lossy()
        .replace('\\', "/");
    let python = path.extension().and_then(|x| x.to_str()) == Some("py");
    let mut rows = Vec::new();
    let mut triple: Option<&str> = None;
    for (index, line) in source.lines().enumerate() {
        if python {
            let quote_sanitized = line.replace("\"'''\"", "").replace("'\\\"\\\"\\\"'", "");
            let double_count = quote_sanitized.matches("\"\"\"").count();
            let single_count = quote_sanitized.matches("'''").count();
            let was_inside = triple.is_some();
            if let Some(marker) = triple {
                if quote_sanitized.matches(marker).count() % 2 == 1 {
                    triple = None;
                }
                if was_inside {
                    continue;
                }
            } else if double_count > 0 || single_count > 0 {
                let marker = if double_count > 0 { "\"\"\"" } else { "'''" };
                if quote_sanitized.matches(marker).count() % 2 == 1 {
                    triple = Some(marker);
                }
                continue;
            }
        }
        let found = if python {
            python_symbols(line)
        } else {
            generic_symbols(line)
        };
        for (kind, name) in found {
            rows.push(format!("SYMBOL\t{}\t{}\t{}\t{}", relative, kind, name, index + 1));
        }
    }
    if python {
        for (from, to) in python_calls(&bytes) {
            rows.push(format!("CALL\t{}\t{}\t{}", relative, from, to));
        }
    }
    rows
}

fn print_batch(root: &Path) -> io::Result<()> {
    let mut paths = Vec::new();
    files(root, root, &mut paths)?;
    for path in paths {
        for row in output_rows_for_file(root, &path) {
            println!("{}", row);
        }
    }
    Ok(())
}

fn escape_path(path: &str) -> bool {
    path.starts_with('/') || path.split('/').any(|part| part == ".." || part.is_empty())
}

fn unescape(value: &str) -> String {
    let mut out = String::new();
    let mut chars = value.chars();
    while let Some(ch) = chars.next() {
        if ch == '\\' {
            match chars.next() {
                Some('n') => out.push('\n'),
                Some('t') => out.push('\t'),
                Some('r') => out.push('\r'),
                Some('\\') => out.push('\\'),
                Some(other) => {
                    out.push('\\');
                    out.push(other);
                }
                None => out.push('\\'),
            }
        } else {
            out.push(ch);
        }
    }
    out
}

fn index_existing(root: &Path) -> io::Result<HashMap<String, Vec<String>>> {
    let mut paths = Vec::new();
    files(root, root, &mut paths)?;
    let mut index = HashMap::new();
    for path in paths {
        let relative = path.strip_prefix(root).unwrap().to_string_lossy().replace('\\', "/");
        index.insert(relative, output_rows_for_file(root, &path));
    }
    Ok(index)
}

fn print_index(label: &str, index: &HashMap<String, Vec<String>>) {
    println!("BEGIN\t{}", label);
    let mut keys: Vec<_> = index.keys().cloned().collect();
    keys.sort();
    for key in keys {
        if let Some(rows) = index.get(&key) {
            for row in rows {
                println!("{}", row);
            }
        }
    }
    println!("END\t{}", label);
}

fn run_incremental(root: &Path, ops_path: &Path) -> io::Result<()> {
    let mut index = index_existing(root)?;
    let ops = fs::read_to_string(ops_path)?;
    for (line_number, line) in ops.lines().enumerate() {
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = line.splitn(3, '\t').collect();
        match fields.as_slice() {
            ["SCAN", label] => print_index(label, &index),
            ["WRITE", rel, content] => {
                if escape_path(rel) {
                    return Err(io::Error::new(io::ErrorKind::InvalidInput, format!("unsafe path at line {}", line_number + 1)));
                }
                let path = root.join(rel);
                if let Some(parent) = path.parent() {
                    fs::create_dir_all(parent)?;
                }
                fs::write(&path, unescape(content))?;
                index.insert((*rel).to_string(), output_rows_for_file(root, &path));
            }
            ["DELETE", rel] => {
                if escape_path(rel) {
                    return Err(io::Error::new(io::ErrorKind::InvalidInput, format!("unsafe path at line {}", line_number + 1)));
                }
                let path = root.join(rel);
                let _ = fs::remove_file(path);
                index.remove(*rel);
            }
            ["RENAME", old, new] => {
                if escape_path(old) || escape_path(new) {
                    return Err(io::Error::new(io::ErrorKind::InvalidInput, format!("unsafe path at line {}", line_number + 1)));
                }
                let old_path = root.join(old);
                let new_path = root.join(new);
                if let Some(parent) = new_path.parent() {
                    fs::create_dir_all(parent)?;
                }
                fs::rename(&old_path, &new_path)?;
                index.remove(*old);
                index.insert((*new).to_string(), output_rows_for_file(root, &new_path));
            }
            _ => {
                return Err(io::Error::new(io::ErrorKind::InvalidInput, format!("invalid incremental op at line {}", line_number + 1)));
            }
        }
    }
    Ok(())
}

#[derive(Clone)]
struct SearchNode {
    path: String,
    kind: String,
    name: String,
    line: usize,
    score: f64,
}

fn search_tokens(value: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut current = String::new();
    for ch in value.chars() {
        if ch.is_ascii_alphanumeric() || ch == '_' {
            current.push(ch.to_ascii_lowercase());
        } else if !current.is_empty() {
            tokens.push(current.clone());
            current.clear();
        }
    }
    if !current.is_empty() {
        tokens.push(current);
    }
    tokens
}

fn symbol_nodes(root: &Path) -> io::Result<Vec<SearchNode>> {
    let mut paths = Vec::new();
    files(root, root, &mut paths)?;
    let mut nodes = Vec::new();
    for path in paths {
        for row in output_rows_for_file(root, &path) {
            let fields: Vec<&str> = row.split('\t').collect();
            if fields.len() == 5 && fields[0] == "SYMBOL" {
                nodes.push(SearchNode {
                    path: fields[1].to_string(),
                    kind: fields[2].to_string(),
                    name: fields[3].to_string(),
                    line: fields[4].parse().unwrap_or(0),
                    score: 0.0,
                });
            }
        }
    }
    Ok(nodes)
}

fn run_search(root: &Path, query: &str, limit: usize) -> io::Result<()> {
    rank_search_nodes(symbol_nodes(root)?, query, limit);
    Ok(())
}

fn rows_to_search_nodes(rows: &[String]) -> Vec<SearchNode> {
    let mut nodes = Vec::new();
    for row in rows {
        let fields: Vec<&str> = row.split('\t').collect();
        if fields.len() == 5 && fields[0] == "SYMBOL" {
            nodes.push(SearchNode {
                path: fields[1].to_string(),
                kind: fields[2].to_string(),
                name: fields[3].to_string(),
                line: fields[4].parse().unwrap_or(0),
                score: 0.0,
            });
        }
    }
    nodes
}

fn rank_search_nodes(mut nodes: Vec<SearchNode>, query: &str, limit: usize) {
    let query_lower = query.to_ascii_lowercase();
    let query_tokens = search_tokens(query);
    let mut rows = Vec::new();
    for mut node in nodes.drain(..) {
        let haystack = format!("{} {} {}", node.name, node.path, node.kind).to_ascii_lowercase();
        let hay_tokens = search_tokens(&haystack);
        let mut score = 0.0;
        for token in &query_tokens {
            if hay_tokens.iter().any(|item| item == token) {
                score += 2.0;
            } else if hay_tokens.iter().any(|item| item.starts_with(token) || token.starts_with(item)) {
                score += 0.75;
            }
        }
        if node.name.to_ascii_lowercase().contains(&query_lower) {
            score += 3.0;
        }
        if node.path.to_ascii_lowercase().contains(&query_lower) {
            score += 1.0;
        }
        if score > 0.0 {
            node.score = score;
            rows.push(node);
        }
    }
    rows.sort_by(|left, right| {
        right.score.partial_cmp(&left.score).unwrap_or(std::cmp::Ordering::Equal)
            .then_with(|| left.path.cmp(&right.path))
            .then_with(|| left.kind.cmp(&right.kind))
            .then_with(|| left.name.cmp(&right.name))
    });
    for row in rows.into_iter().take(limit) {
        println!("SEARCH\t{}\t{}\t{}\t{}\t{:.6}", row.path, row.kind, row.name, row.line, row.score);
    }
}

fn collect_batch_rows(root: &Path) -> io::Result<Vec<String>> {
    let mut paths = Vec::new();
    files(root, root, &mut paths)?;
    let mut rows = Vec::new();
    for path in paths {
        rows.extend(output_rows_for_file(root, &path));
    }
    Ok(rows)
}

fn save_index(root: &Path, index_path: &Path, source_digest: &str) -> io::Result<()> {
    let rows = collect_batch_rows(root)?;
    let mut body = String::new();
    body.push_str("CHIMERA_RUST_GRAPH_INDEX_V1\n");
    body.push_str(&format!("SOURCE\t{}\n", source_digest));
    body.push_str("ROWS\n");
    for row in rows {
        body.push_str(&row);
        body.push('\n');
    }
    body.push_str("END\n");
    if let Some(parent) = index_path.parent() {
        fs::create_dir_all(parent)?;
    }
    fs::write(index_path, body)
}

fn load_index_rows(index_path: &Path, expected_digest: &str) -> io::Result<Vec<String>> {
    let content = fs::read_to_string(index_path)?;
    let mut lines = content.lines();
    let version = lines.next().unwrap_or("");
    if version != "CHIMERA_RUST_GRAPH_INDEX_V1" {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "unsupported rust graph index version"));
    }
    let source = lines.next().unwrap_or("");
    let fields: Vec<&str> = source.split('\t').collect();
    if fields.len() != 2 || fields[0] != "SOURCE" {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "missing rust graph source digest"));
    }
    if fields[1] != expected_digest {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "rust graph source digest mismatch"));
    }
    if lines.next().unwrap_or("") != "ROWS" {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "missing rust graph row section"));
    }
    let mut rows = Vec::new();
    for line in lines {
        if line == "END" {
            return Ok(rows);
        }
        let fields: Vec<&str> = line.split('\t').collect();
        let valid = (fields.len() == 5 && fields[0] == "SYMBOL") || (fields.len() == 4 && fields[0] == "CALL");
        if !valid {
            return Err(io::Error::new(io::ErrorKind::InvalidData, "malformed rust graph index row"));
        }
        rows.push(line.to_string());
    }
    Err(io::Error::new(io::ErrorKind::InvalidData, "unterminated rust graph index"))
}

fn load_index(index_path: &Path, expected_digest: &str) -> io::Result<()> {
    for row in load_index_rows(index_path, expected_digest)? {
        println!("{}", row);
    }
    Ok(())
}

fn search_index(index_path: &Path, expected_digest: &str, query: &str, limit: usize) -> io::Result<()> {
    let rows = load_index_rows(index_path, expected_digest)?;
    rank_search_nodes(rows_to_search_nodes(&rows), query, limit);
    Ok(())
}

fn main() -> io::Result<()> {
    let mut args = env::args().skip(1);
    let first = args
        .next()
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "workspace root required"))?;
    if first == "--incremental" {
        let root = args
            .next()
            .map(PathBuf::from)
            .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "workspace root required"))?;
        let ops = args
            .next()
            .map(PathBuf::from)
            .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "ops file required"))?;
        let root = root.canonicalize()?;
        return run_incremental(&root, &ops);
    }
    if first == "--search" {
        let root = args
            .next()
            .map(PathBuf::from)
            .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "workspace root required"))?;
        let query = args
            .next()
            .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "query required"))?;
        let limit = args.next().and_then(|value| value.parse::<usize>().ok()).unwrap_or(10);
        let root = root.canonicalize()?;
        return run_search(&root, &query, limit);
    }
    if first == "--save-index" {
        let root = args.next().map(PathBuf::from).ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "workspace root required"))?;
        let index = args.next().map(PathBuf::from).ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "index path required"))?;
        let digest = args.next().ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "source digest required"))?;
        let root = root.canonicalize()?;
        return save_index(&root, &index, &digest);
    }
    if first == "--load-index" {
        let index = args.next().map(PathBuf::from).ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "index path required"))?;
        let digest = args.next().ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "source digest required"))?;
        return load_index(&index, &digest);
    }
    if first == "--search-index" {
        let index = args.next().map(PathBuf::from).ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "index path required"))?;
        let digest = args.next().ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "source digest required"))?;
        let query = args.next().ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "query required"))?;
        let limit = args.next().and_then(|value| value.parse::<usize>().ok()).unwrap_or(10);
        return search_index(&index, &digest, &query, limit);
    }
    let root = PathBuf::from(first).canonicalize()?;
    print_batch(&root)
}
