# Chimera cloud-runtime doctor profile

`chimera doctor --profile cloud-runtime` is a deployment-readiness gate, not a local certification-bundle gate.

It requires persistent runtime endpoints to be configured in the process environment while still relying on the bounded local certification evidence produced by the `cloud-postgres` and `durable-restate` bundles.

## Required environment variable names

Provide these through a secret manager, CI environment, or runtime injector. Do not store credential-bearing URLs in `chimera.toml` or in the repository.

PostgreSQL cloud state endpoint, one of:

```bash
export CHIMERA_POSTGRES_URL='postgresql+psycopg://USER:REDACTED@HOST:5432/DB?sslmode=require'
# or
export DATABASE_URL='postgresql+psycopg://USER:REDACTED@HOST:5432/DB?sslmode=require'
```

Restate runtime endpoint, one of:

```bash
export CHIMERA_RESTATE_INGRESS='https://RESTATE-INGRESS.example.invalid'
# or
export CHIMERA_RESTATE_ENDPOINT='https://RESTATE-INGRESS.example.invalid'
# or
export RESTATE_ENDPOINT='https://RESTATE-INGRESS.example.invalid'
```

## Expected gates

Local certification bundles:

```bash
chimera doctor --profile local --fail-on-blockers
chimera doctor --profile cloud-postgres --fail-on-blockers
chimera doctor --profile durable-restate --fail-on-blockers
chimera doctor --profile sandbox-linux --fail-on-blockers
```

Persistent runtime endpoint gate:

```bash
chimera doctor --profile cloud-runtime --fail-on-blockers
```

In a local sandbox without endpoint env vars, `cloud-runtime` should fail with blockers:

```text
postgres-runtime-endpoint
restate-runtime-endpoint
```

That failure is intentional and prevents disposable local certification artifacts from being confused with a configured production/cloud deployment.
