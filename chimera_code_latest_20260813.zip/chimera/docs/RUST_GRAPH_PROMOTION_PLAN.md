# Rust graph promotion plan

The current Rust graph implementation is certified as a **mirror**, not an authoritative production replacement.

Current passing evidence covers exact batch conformance for:

```text
symbols
CONTAINS edges
CALLS edges
```

It does not yet cover all behavior needed to replace Python `CodeGraph` in production.

## Promotion invariant

Rust graph may be promoted from mirror-only to production-authoritative only when every Python graph behavior used by routing, retrieval, and certification has a Rust equivalent with a cross-checking conformance campaign.

Until then, doctor/reporting must keep:

```text
mirror_only = true
production_replacement_authorized = false
```

## Current first campaign

Implemented first mirror-only campaign:

```text
evals/deployment/rust_graph_incremental_campaign.py
artifacts/rust_graph_incremental_campaign_2026-08-11.json
```

It mutates a fixture workspace through create/edit/delete/rename/idempotent-rescan steps and proves Rust/Python parity after every step using the Rust binary's stateful `--incremental` command. It reports:

```text
incremental_update_api_present = true
incremental_update_api_certified = true
mirror_only = true
production_replacement_authorized = false
```

This is now a minimal incremental API proof, but it is still not enough for production promotion because watch/search/persisted-index/cross-platform/runtime gates remain open.

## Required promotion gates

### 1. Incremental update conformance

Implemented minimal evidence:

- stateful Rust `--incremental` command;
- create file;
- edit file;
- delete file;
- rename/move file;
- update call edges after edit;
- remove stale symbols/edges;
- repeated rescan idempotency.

Remaining incremental evidence for promotion:

- production runtime integration, not only eval command;
- broader corpus beyond the small campaign fixture;
- cross-platform repeated evidence.

### 2. Watch-mode conformance

Implemented bounded adapter evidence:

```text
evals/deployment/rust_graph_watch_campaign.py
artifacts/rust_graph_watch_campaign_2026-08-11.json
```

This certifies a Python polling/debounce adapter feeding the Rust incremental API for burst create/edit/delete and no mixed-state exposure in a local fixture.

Still missing for promotion:

- native Rust filesystem watcher or production watch service integration;
- platform-specific filesystem event behavior;
- long-running watch service lifecycle/failure recovery;
- fallback to Python or full rebuild without corrupting state under watcher failure.

### 3. Search/retrieval conformance

Implemented bounded lexical recall evidence:

```text
evals/deployment/rust_graph_search_campaign.py
artifacts/rust_graph_search_campaign_2026-08-11.json
```

This certifies top-5 recall for labeled symbol queries on a small fixture using the Rust `--search` command.

Implemented broader corpus evidence:

```text
evals/deployment/rust_graph_broad_retrieval_campaign.py
artifacts/rust_graph_broad_retrieval_campaign_2026-08-11.json
```

This certifies top-10 lexical symbol recall across a larger synthetic multi-domain corpus. It still does not prove exact BM25 ranking parity or semantic retrieval.

Still missing for promotion:

- exact BM25/token ranking parity or formally accepted replacement metrics on a real/hidden broader corpus;
- structural expansion parity;
- call-neighborhood retrieval parity;
- no hidden-test recall regression on semantic/code retrieval corpora.

### 4. Persisted-index conformance

Implemented bounded persisted-index evidence:

```text
evals/deployment/rust_graph_persisted_index_campaign.py
artifacts/rust_graph_persisted_index_campaign_2026-08-11.json
```

Certified behavior:

- save/load exact symbols and calls;
- source snapshot digest binding;
- stale/modified source digest rejection;
- corrupt index rejection;
- version drift rejection;
- unterminated index rejection;
- persisted-index search top-1 parity on a fixture query.

Still missing for promotion:

- production CodeGraph store integration;
- broader corpus/cross-platform persisted-index evidence;
- runtime rebuild/fallback policy under index rejection.

### 5. Cross-platform certification

Required evidence across at least:

```text
Linux x86_64
Linux arm64
macOS arm64 or equivalent developer platform
```

If Windows support is claimed, add Windows explicitly. Otherwise document it unsupported.

### 6. Runtime integration gates

Implemented mirror-only runtime boundary:

```text
chimera/rust_graph_runtime_adapter.py
tests/test_rust_graph_runtime_adapter.py
```

Certified behavior:

- all local Rust graph evidence artifacts are read into a promotion status;
- production replacement remains unauthorized;
- default search path stays Python;
- explicit Rust mirror search falls back to Python when unavailable/uncertified.

Implemented runtime fallback drill:

```text
evals/deployment/rust_graph_runtime_fallback_campaign.py
artifacts/rust_graph_runtime_fallback_campaign_2026-08-11.json
```

This proves the runtime boundary defaults to Python and falls back on missing/failing Rust binaries.

Still missing for promotion:

- application/runtime port integration using Rust as an authoritative backend;
- CLI graph commands using the Rust-backed adapter only after promotion;
- rollback drills after Rust runtime failure under real workload;
- no regression in `chimera doctor` local/cloud certification bundles on broader CI matrices.

## Non-goals for promotion

The following are not sufficient alone:

- Rust toolchain installed;
- one clean build;
- exact batch symbols/edges only;
- faster benchmark without failure-mode evidence;
- model-generated claim of equivalence.

## Proposed campaign files

```text
evals/deployment/rust_graph_incremental_campaign.py
evals/deployment/rust_graph_watch_campaign.py
evals/deployment/rust_graph_search_campaign.py
evals/deployment/rust_graph_persisted_index_campaign.py
```

Each should emit a JSON artifact with:

```text
schema_version
python_snapshot_digest
rust_snapshot_digest
all_passed
mirror_only
production_replacement_authorized
limits
```

`production_replacement_authorized` must remain `false` until all required campaigns pass on the required platforms.
