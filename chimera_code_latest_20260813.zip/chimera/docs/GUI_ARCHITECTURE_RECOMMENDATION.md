# Chimera GUI architecture recommendation

## Recommendation

Use a **web-first GUI adapter over hexagonal ports**, with **Tauri + Svelte/Solid** as the first desktop shell and a normal web deployment for cloud.

Why this fits Chimera:

- Chimera is cloud-priority and multi-tenant; the UI should primarily target a browser-accessible control plane.
- Tauri gives a low-footprint desktop shell without bundling Chromium, using the OS WebView and Rust command boundary.
- A web frontend can consume the same GUI/MCP/HTTP ports as the desktop shell.
- Rust-native toolkits are valuable for debug utilities, but Chimera's main UI needs rich tables, traces, graphs, markdown, auth flows, and multi-tenant admin screens where web UI velocity wins.

## Port boundary implemented

```text
chimera/gui_ports.py
chimera/gui_application.py
```

Primary GUI ports:

```text
GuiReadPort
GuiCommandPort
GuiApplicationPort
```

Data/contracts:

```text
GuiTenantSession
GuiNavigationItem
GuiViewModel
GuiAction
GuiActionResult
```

The GUI adapter must call these ports or MCP/API use cases. It must not import RLM internals, WAL internals, provider clients, or tenant storage directly.

## Framework choice

### First choice: Tauri shell + Svelte/Solid web UI

Best for:

- cloud dashboard + desktop shell from one UI codebase;
- low memory compared to Electron;
- fast frontend iteration;
- rich observability/trace tables;
- graph and timeline visualization;
- controlled Rust backend bridge.

### Alternative: Dioxus

Good if the team wants Rust UI components and a shared web/desktop/mobile direction. Use only if Dioxus maturity/tooling is acceptable for the team.

### Debug/internal utility: egui

Best for low-friction internal dashboards, local debug panels, and telemetry viewers. Do not use as the primary user-facing cloud UI.

### Low-resource embedded: Slint

Best if Chimera ever needs embedded/device-adjacent UI. Not ideal as primary cloud control plane due to licensing/UI ecosystem tradeoffs.

### Native enterprise Linux: GTK/Relm4

Good for Linux-native admin tools. Not the best primary cross-platform/cloud UI.

## Screens to build first

1. Telemetry overview
   - WAL entries by kind
   - latency p50/p95/max by action/provider/tool
   - token usage and cost exposure
   - GCF reduction
   - sandbox/backend use
2. Run/session view
   - branch/session status
   - tool timeline
   - test evidence
   - provider usage
3. Graph explorer
   - Rust/Python graph status
   - GCF graph query output
   - search/retrieval evidence
4. Cloud runtime readiness
   - doctor profiles
   - missing endpoint envs
   - certification bundle state
5. Self-improvement gauntlet
   - generated tasks
   - critic/metacritic status
   - promotion blocked/allowed state

## Security and tenancy

- Every GUI call carries `GuiTenantSession`.
- Tenant/principal identities are hashes or opaque keys.
- No raw provider keys or endpoint URLs in UI telemetry by default.
- Mutating actions go through application use cases and policy gates.
- Long-running cloud execution uses durable session APIs, not browser-local state.

## Online research basis

Recent observability guidance emphasizes OpenTelemetry GenAI semantic conventions for model, token, latency, and trace attributes; per-tool spans; privacy-first prompt handling; and trace context propagation through MCP boundaries. Recent GUI comparisons consistently position Tauri as a low-footprint webview desktop shell, while egui/Slint are lower-level Rust-native choices for debug/embedded use cases.
