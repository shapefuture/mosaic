# Chimera Workbench GUI porting status

The supplied React draft has been ported into a first Tauri + Svelte scaffold:

```text
gui/tauri-svelte/
```

Implemented features in the port:

- premium dark/light shell;
- Workbench / Cinema / Self-improve / Cloud modes;
- agent constellation inspired by the draft;
- smooth animated timeline and wave telemetry;
- responsive mobile layout;
- reduced-motion support;
- telemetry cards for tokens, providers, GCF, latency;
- evidence receipts for cloud runtime, GCF, self-improvement, sandbox;
- API client for `/api/telemetry` and `/api/gui/dashboard`;
- Tauri v2 shell config with CSP;
- GUI HTTP adapter in Python over hexagonal GUI ports.

This is not yet a full production GUI implementation. It is the correct porting foundation: web/cloud-first UI with Tauri desktop shell, backed by `GuiApplicationPort` rather than runtime internals.

Next GUI steps:

1. add real hosted HTTP server route for `GuiHttpAdapter`;
2. wire websocket/SSE stream for live runs;
3. connect run/session actions to `GuiAction` dispatch;
4. add graph visualization with GCF payload decoding;
5. add auth/tenant selector and protected cloud-runtime settings screen.
