# Provider report and canary workflow

Chimera separates provider configuration from provider proof.

A configured API key only means Chimera can attempt a call. It does not prove native tool calling, strict JSON, prompt-cache reuse, streaming behavior, cancellation termination, or billing termination.

## Redacted provider inventory

Run:

```bash
chimera providers --report --model cerebras/gpt-oss-120b
```

The report schema is:

```text
chimera.provider-system-report.v1
```

It includes:

- provider id;
- implemented adapter status;
- protocol;
- configured environment variable names only;
- credential slot count;
- adapter capability manifest;
- artifact-backed proved capabilities;
- QoS and reliability summaries;
- route penalty;
- canary proof counts;
- cancellation canary counts;
- provider billing reservations and unresolved exposure.

It never prints credential values.

## Configure credentials through the environment

Examples using placeholder values only:

```bash
export CEREBRAS_API_KEY='REDACTED'
export GEMINI_API_KEY='REDACTED'
export TOKENROUTER_API_KEY='REDACTED'
export OPENROUTER_API_KEY='REDACTED'
```

Pooled key variables are counted as credential slots but values remain redacted:

```bash
export GEMINI_API_KEYS='REDACTED_1,REDACTED_2'
export OPENROUTER_API_KEYS='REDACTED_1,REDACTED_2'
```

## Run explicit live canaries

Live canaries consume provider quota and must be explicitly authorized:

```bash
chimera provider-canary cerebras/gpt-oss-120b \
  --capability strict_json \
  --capability native_tools \
  --authorize-live-call
```

Other fixed canary capabilities:

```text
streaming
prompt_cache
refusal_shape
sticky_session
response_chain
```

Only these are promotable routing capabilities in the current provider canary path:

```text
native_tools
strict_json
streaming
prompt_cache
```

`sticky_session` and `response_chain` remain non-promotable until a dedicated endpoint adapter proves them. `refusal_shape` is observability only.

## Inspect proved capabilities after canaries

```bash
chimera providers --report --model cerebras/gpt-oss-120b
```

The `proved_capabilities` field is populated only from artifact-backed canary WAL entries. Ordinary successful completions and provider marketing claims do not promote capabilities.

## Cancellation and billing honesty

Local task cancellation does not prove provider-side billing termination. Chimera's provider billing ledger reserves worst-case exposure until an authoritative provider receipt arrives.

The provider report shows:

```text
billing_reservations
unresolved_billing_exposure_microusd
cancellation_canaries
```

A provider route should not claim billing-stop proof until authoritative cancellation and billing receipts exist for that route.
