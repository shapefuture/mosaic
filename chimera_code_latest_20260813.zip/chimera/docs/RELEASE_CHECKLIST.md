# Chimera Release Checklist

Run before cutting a release:

```bash
pytest tests -q
python -m compileall -q chimera tests
python -m chimera health | python -m json.tool >/dev/null
python - <<'PY'
from chimera.performance_gates import PerformanceGateRunner
from pathlib import Path
for result in PerformanceGateRunner(Path('.')).run_all():
    print(result.as_dict())
    assert result.passed
PY
python - <<'PY'
from chimera.orchestrator import ChimeraHarness
res=ChimeraHarness().run('inspect authentication code and report blast radius', model='mock-echo')
assert res['ltl_ok'] and res.get('heldout') and res.get('quality_rubric')
PY
```

Matrix requirements:

- `CHIMERA_SANDBOX_MODE=materialized` fallback suite.
- `CHIMERA_SANDBOX_MODE=bwrap` with `CHIMERA_BWRAP_OVERLAY_CERTIFIED=1` on Linux with bubblewrap installed.
