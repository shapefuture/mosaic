export type TelemetrySnapshot = {
  schema_version: string;
  wal?: { entries: number; kinds: Record<string, number>; recent?: unknown[] };
  providers?: { providers: number; implemented: number; configured: number; with_canary_proofs: number };
  token_usage?: Record<string, number>;
  latency_ms_by_kind?: Record<string, { count: number; p50: number | null; p95: number | null; max: number | null }>;
  wire_codec?: { observations: number; average_reduction: number | null; gcf_campaign?: Record<string, unknown> };
  sandbox?: Record<string, number>;
  cloud_runtime?: Record<string, unknown>;
  self_improvement?: Record<string, unknown>;
  recommendations?: string[];
};


export type GateDashboard = {
  schema_version: string;
  status: string;
  blockers?: string[];
  warnings?: string[];
  latest_supreme_gate?: { status?: string | null; schema_version?: string; path?: string } | null;
  token_error_tax?: { token_error_tax?: number; total_tokens?: number; failed_tokens?: number; retry_tokens?: number; repair_tokens?: number };
  cloud_scale_readiness?: { ready_for_local_mode?: boolean; ready_for_thousands_cloud_agents?: boolean; shard_plan?: Record<string, unknown>; warnings?: string[] };
  gate_history?: { entries?: number; regression_watch?: { regression_count?: number } };
  next_required_actions?: string[];
};

export async function fetchGateDashboard(base = ''): Promise<GateDashboard> {
  const res = await fetch(`${base}/api/gates/dashboard?recent=50`, { headers: { accept: 'application/json' } });
  if (!res.ok) throw new Error(`gate dashboard HTTP ${res.status}`);
  return await res.json();
}

export type GuiViewModel = {
  schema_version: string;
  title: string;
  panels: Record<string, unknown>;
  redactions: string[];
};

export async function fetchTelemetry(base = ''): Promise<TelemetrySnapshot> {
  const res = await fetch(`${base}/api/telemetry?recent=200`, { headers: { accept: 'application/json' } });
  if (!res.ok) throw new Error(`telemetry HTTP ${res.status}`);
  return await res.json();
}

export async function fetchDashboard(base = ''): Promise<GuiViewModel> {
  const res = await fetch(`${base}/api/gui/dashboard`, { headers: { accept: 'application/json' } });
  if (!res.ok) throw new Error(`dashboard HTTP ${res.status}`);
  return await res.json();
}

export async function dispatchGuiAction(base: string, kind: string, payload: Record<string, unknown>) {
  const res = await fetch(`${base}/api/gui/action`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json' },
    body: JSON.stringify({ id: kind, kind, payload }),
  });
  if (!res.ok) throw new Error(`action HTTP ${res.status}`);
  return await res.json();
}

export async function decodeGcf(base: string, text: string) {
  const res = await fetch(`${base}/api/wire/decode`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json' },
    body: JSON.stringify({ text }),
  });
  if (!res.ok) throw new Error(`wire decode HTTP ${res.status}`);
  return await res.json();
}

export function openRunEventSocket(base: string, onMessage: (value: unknown) => void): WebSocket {
  const url = new URL(base || location.origin);
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
  url.pathname = '/api/ws';
  const socket = new WebSocket(url);
  socket.onmessage = (event) => {
    try { onMessage(JSON.parse(event.data)); } catch { onMessage(event.data); }
  };
  return socket;
}

export async function issueTenantGrant(base: string, tenant_id: string, principal: string, scopes = ['cli', 'mcp', 'rpc', 'artifact']) {
  const res = await fetch(`${base}/api/tenant/issue`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json' },
    body: JSON.stringify({ tenant_id, principal, scopes }),
  });
  if (!res.ok) throw new Error(`tenant issue HTTP ${res.status}`);
  return await res.json();
}

export const demoTelemetry: TelemetrySnapshot = {
  schema_version: 'chimera.telemetry-snapshot.v1',
  wal: { entries: 640, kinds: { provider_qos: 21, sandbox_exec: 44, wire_codec_graph: 18, self_improvement: 3 } },
  providers: { providers: 24, implemented: 17, configured: 1, with_canary_proofs: 1 },
  token_usage: { input_tokens: 184200, output_tokens: 48200, cache_read_tokens: 91000 },
  latency_ms_by_kind: {
    'provider_qos.latency_ms': { count: 21, p50: 812, p95: 4711, max: 4890 },
    'sandbox_exec.duration_ms': { count: 44, p50: 920, p95: 31000, max: 55000 },
  },
  wire_codec: { observations: 18, average_reduction: 0.61, gcf_campaign: { all_passed: true, graph_reduction: 0.6703 } },
  sandbox: { executions: 44, bubblewrap: 36, timeouts: 0 },
  cloud_runtime: { all_passed: true, doctor_certified: true, endpoint_values_recorded: false },
  self_improvement: { all_passed: true, schema_version: 'chimera.self-improvement-gauntlet-receipt.v1' },
  recommendations: ['Cloud runtime smoke passed with endpoint env wiring.', 'TokenRouter strict JSON canary proved.'],
};

export const demoGateDashboard: GateDashboard = {
  schema_version: 'chimera.gate-dashboard.v1',
  status: 'green',
  blockers: [],
  warnings: [],
  latest_supreme_gate: { status: 'pass', schema_version: 'chimera.supreme-gate.v1', path: 'artifacts/supreme_gate_2026-08-13.json' },
  token_error_tax: { token_error_tax: 0, total_tokens: 0, failed_tokens: 0, retry_tokens: 0, repair_tokens: 0 },
  cloud_scale_readiness: { ready_for_local_mode: true, ready_for_thousands_cloud_agents: true, shard_plan: { suggested_shards: 8 } },
  gate_history: { entries: 1, regression_watch: { regression_count: 0 } },
  next_required_actions: ['Run candidate-promotion-gate with evaluator-owned hidden tests for each candidate patch.'],
};

export function fmt(n: number | undefined | null): string {
  if (n == null || Number.isNaN(n)) return '—';
  if (Math.abs(n) >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (Math.abs(n) >= 1_000) return `${(n / 1_000).toFixed(1)}k`;
  return Math.round(n).toLocaleString();
}
