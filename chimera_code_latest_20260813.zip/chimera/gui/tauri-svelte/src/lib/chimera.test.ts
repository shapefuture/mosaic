import { describe, expect, it } from 'vitest';
import { demoTelemetry, fmt } from './chimera';

describe('Chimera GUI client helpers', () => {
  it('ships redacted demo telemetry with core panels', () => {
    expect(demoTelemetry.schema_version).toBe('chimera.telemetry-snapshot.v1');
    expect(demoTelemetry.providers?.implemented).toBeGreaterThan(0);
    expect(JSON.stringify(demoTelemetry)).not.toContain('sk-');
  });

  it('formats telemetry numbers compactly', () => {
    expect(fmt(1200)).toBe('1.2k');
    expect(fmt(null)).toBe('—');
  });
});
