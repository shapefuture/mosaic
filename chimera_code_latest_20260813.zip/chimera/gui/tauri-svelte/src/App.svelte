<script lang="ts">
  import { onMount } from 'svelte';
  import { demoGateDashboard, demoTelemetry, fetchGateDashboard, fetchTelemetry, fmt, type GateDashboard, type TelemetrySnapshot } from './lib/chimera';

  let telemetry: TelemetrySnapshot = demoTelemetry;
  let mode: 'workbench' | 'cinema' | 'self-improve' | 'cloud' | 'gates' = 'workbench';
  let theme: 'dark' | 'light' = 'dark';
  let live = false;
  let progress = 0;
  let apiBase = localStorage.getItem('chimera.apiBase') || '';
  let status = 'demo telemetry loaded';
  let gates: GateDashboard = demoGateDashboard;

  const phases = ['perceive', 'plan', 'synthesize', 'sandbox', 'verify', 'seal'];
  const agents = [
    ['chimera', 'primary orchestration', 'application'],
    ['planner', 'DAG + task hierarchy', 'planner'],
    ['semantic', 'graph / TIA / GCF', 'codeintel'],
    ['coder', 'GSA focused coder', 'transaction'],
    ['sandbox', 'bubblewrap + pytest', 'sandbox'],
    ['critic', 'hidden tests + metacritic', 'evidence'],
  ];

  $: tokens = (telemetry.token_usage?.input_tokens || 0) + (telemetry.token_usage?.output_tokens || 0) + (telemetry.token_usage?.tokens || 0);
  $: providerCount = telemetry.providers?.configured || 0;
  $: gcfReduction = telemetry.wire_codec?.average_reduction ?? (telemetry.wire_codec?.gcf_campaign?.graph_reduction as number | undefined) ?? null;
  $: cloudOk = telemetry.cloud_runtime?.all_passed || telemetry.cloud_runtime?.doctor_certified;
  $: selfImproveOk = telemetry.self_improvement?.all_passed;
  $: latency = telemetry.latency_ms_by_kind?.['provider_qos.latency_ms'] || telemetry.latency_ms_by_kind?.['sandbox_exec.duration_ms'];

  async function refresh() {
    try {
      telemetry = await fetchTelemetry(apiBase);
      gates = await fetchGateDashboard(apiBase);
      status = 'live telemetry refreshed';
      live = true;
      localStorage.setItem('chimera.apiBase', apiBase);
    } catch (err) {
      status = `demo mode · ${(err as Error).message}`;
      live = false;
      telemetry = demoTelemetry;
      gates = demoGateDashboard;
    }
  }

  onMount(() => {
    refresh();
    const id = setInterval(() => {
      progress = (progress + 0.008) % 1;
      if (live) refresh();
    }, 1600);
    return () => clearInterval(id);
  });
</script>

<svelte:head>
  <title>Chimera Workbench</title>
</svelte:head>

<div class:light={theme === 'light'} class="shell">
  <div class="aurora"></div>
  <header class="topbar">
    <div class="brand"><span class="mark">◌</span><strong>Chimera</strong><em>2</em></div>
    <nav>
      {#each ['workbench','cinema','self-improve','cloud','gates'] as item}
        <button class:active={mode === item} on:click={() => (mode = item as typeof mode)}>{item}</button>
      {/each}
    </nav>
    <div class="spacer"></div>
    <span class:ok={live} class="pill">{live ? '● live' : '○ demo'}</span>
    <button class="icon" on:click={() => (theme = theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? '☀' : '☾'}</button>
  </header>

  <main>
    <aside class="chat glass">
      <div class="section-title">Workbench</div>
      <textarea placeholder="Ask Chimera to build, verify, or self-improve…">Add a cloud-runtime telemetry dashboard and run the self-improvement gauntlet.</textarea>
      <div class="chips">
        <button>Run task</button><button>Open session</button><button>Verify branch</button>
      </div>
      <div class="feed">
        <p><b>chimera</b><span>RunContext bound · tenant/principal redacted</span></p>
        <p><b>planner</b><span>System-2 compute plan · GSA for coding</span></p>
        <p><b>coder</b><span>code-execution verdict policy injected</span></p>
        <p><b>critic</b><span>hidden tests remain evaluator-owned</span></p>
      </div>
      <label>API base<input bind:value={apiBase} placeholder="https://chimera.example" /></label>
      <label>Tenant selector<input placeholder="tenant key / signed session (redacted)" /></label>
      <button class="primary" on:click={refresh}>Refresh telemetry</button>
      <small>{status}</small>
    </aside>

    <section class="stage glass">
      {#if mode === 'workbench'}
        <div class="hero-grid">
          <div class="orbital">
            {#each agents as agent, i}
              <div class="node" style={`--i:${i}; --n:${agents.length}`}>
                <strong>{agent[0]}</strong><small>{agent[2]}</small>
              </div>
            {/each}
            <div class="core"><strong>Chimera</strong><small>hexagonal cloud runtime</small></div>
          </div>
          <div class="timeline">
            {#each phases as phase, i}
              <div class:lit={progress * phases.length >= i} style={`--delay:${i * 80}ms`}><span>{phase}</span></div>
            {/each}
          </div>
        </div>
      {:else if mode === 'cinema'}
        <div class="cinema">
          <h1>Execution cinema</h1>
          <p>Replay every model call, tool call, sandbox run, GCF compression, token burn, and evidence receipt as a single trace.</p>
          <div class="wave">{#each Array(64) as _, i}<i style={`height:${20 + Math.abs(Math.sin(i * .37 + progress * 9)) * 90}px`}></i>{/each}</div>
        </div>
      {:else if mode === 'self-improve'}
        <div class="cards big">
          <article><span>generator</span><strong>adversarial tasks</strong><p>duration, inventory, prompt-injection sanitizer</p></article>
          <article><span>copies</span><strong>multi-Chimera swarm</strong><p>independent workspaces, hidden tests, metacritic</p></article>
          <article><span>promotion</span><strong>{selfImproveOk ? 'blocked until evidence' : 'not run'}</strong><p>no self-certification; critic rows only</p></article>
        </div>
      {:else if mode === 'gates'}
        <div class="cloud-panel">
          <h1>Gate dashboard</h1>
          <p>Promotion remains blocked until candidate-specific hidden tests, exploit scan, rollback, and deployment receipts pass.</p>
          <div class="cards">
            <article><span>status</span><strong>{gates.status}</strong></article>
            <article><span>supreme</span><strong>{gates.latest_supreme_gate?.status || '—'}</strong></article>
            <article><span>history</span><strong>{fmt(gates.gate_history?.entries)}</strong></article>
          </div>
          <div class="panel"><h3>Token error tax</h3><div class="metric"><span>waste</span><b>{fmt((gates.token_error_tax?.token_error_tax || 0) * 100)}%</b></div><div class="metric"><span>tokens</span><b>{fmt(gates.token_error_tax?.total_tokens)}</b></div></div>
          <div class="panel"><h3>Blockers / warnings</h3><ul>{#each [...(gates.blockers || []), ...(gates.warnings || [])] as item}<li>{item}</li>{/each}</ul></div>
          <div class="panel"><h3>Next actions</h3>{#each gates.next_required_actions || [] as item}<p class="rec">{item}</p>{/each}</div>
        </div>
      {:else}
        <div class="cloud-panel">
          <h1>Cloud runtime</h1>
          <p>Self-hosted cloud first, local preserved. Endpoint envs stay outside telemetry.</p>
          <div class="cards">
            <article><span>Postgres/RLS</span><strong>{cloudOk ? 'wired' : 'pending'}</strong></article>
            <article><span>Restate</span><strong>{cloudOk ? 'wired' : 'pending'}</strong></article>
            <article><span>Local option</span><strong>preserved</strong></article>
          </div>
          <div class="panel cloud-settings">
            <h3>Cloud-runtime settings</h3>
            <p>Provide endpoint secrets outside the UI process: CHIMERA_POSTGRES_URL and CHIMERA_RESTATE_INGRESS. Values stay redacted; only env names are shown.</p>
            <div class="chips"><button>Check doctor</button><button>Open tenant selector</button><button>Decode GCF graph</button></div>
          </div>
        </div>
      {/if}
    </section>

    <aside class="drawer glass">
      <h2 class="drawer-title">Telemetry deck</h2>
      <div class="score-grid">
        <article><span>tokens</span><strong>{fmt(tokens)}</strong><small>input/output/cache</small></article>
        <article><span>providers</span><strong>{providerCount}</strong><small>configured</small></article>
        <article><span>GCF</span><strong>{gcfReduction == null ? '—' : `${Math.round(gcfReduction * 100)}%`}</strong><small>avg reduction</small></article>
        <article><span>p95</span><strong>{fmt(latency?.p95)}ms</strong><small>latency</small></article>
      </div>
      <div class="panel">
        <h3>Evidence receipts</h3>
        <ul>
          <li class:pass={cloudOk}>cloud-runtime smoke</li>
          <li class:pass={telemetry.wire_codec?.gcf_campaign?.all_passed}>GCF wire campaign</li>
          <li class:pass={selfImproveOk}>self-improvement gauntlet</li>
          <li class:pass={telemetry.sandbox?.bubblewrap}>bubblewrap sandbox</li>
        </ul>
      </div>
      <div class="panel">
        <h3>Latency by span</h3>
        {#each Object.entries(telemetry.latency_ms_by_kind || {}).slice(0, 7) as [k, v]}
          <div class="metric"><span>{k}</span><b>{fmt(v.p95)}ms</b></div>
        {/each}
      </div>
      <div class="panel">
        <h3>Recommendations</h3>
        {#each telemetry.recommendations || [] as item}<p class="rec">{item}</p>{/each}
      </div>
    </aside>
  </main>
</div>
