#!/usr/bin/env python3
"""Crash-contained live held-out evaluator for Chimera's OpenAI-compatible port.

No credentials, prompts, model responses, test output, or temporary workspaces
are persisted.  Each condition runs in a child process with a hard parent-side
timeout, and its sanitised row is atomically checkpointed before the next
condition starts.  This is intentionally an evaluation tool, not a runtime
provider adapter or a benchmark publisher.

Example (only with explicit user/provider authorization and a host-inherited,
one-shot credential descriptor; never place a credential in this command):
  CHIMERA_TESTING_ENVIRONMENT=1 \
  CHIMERA_TEST_ROUTE=tokenrouter-kimi-cancellation-v1 \
  CHIMERA_TEST_CREDENTIAL_FD=<inherited-fd> \
  python evals/coding/heldout_v1/run_tokenrouter.py \
    --profiles micro_transaction --repetitions 2 --condition-timeout 150 \
    --request-timeout 90 --max-output-tokens 1200
"""
from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing as mp
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from chimera.testing_environment import TestingEnvironment, TransientEnvironmentError


MANIFEST_PATH = pathlib.Path(__file__).with_name("manifest.json")
MODEL = "moonshotai/kimi-k3-free"


def _atomic_jsonl_append(path: pathlib.Path, value: dict[str, Any]) -> None:
    """Append a small sanitised row and fsync before the next condition starts."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def _load_completed(path: pathlib.Path) -> set[tuple[str, int, str]]:
    if not path.exists():
        return set()
    completed: set[tuple[str, int, str]] = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            value = json.loads(line)
            completed.add((str(value["case"]), int(value["repetition"]), str(value["condition"])))
        except (KeyError, TypeError, ValueError, json.JSONDecodeError):
            continue
    return completed


def _sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _seed(root: pathlib.Path, case: dict[str, Any]) -> None:
    (root / "chimera").mkdir()
    (root / "chimera" / "__init__.py").write_text("")
    for rel, content in case.get("files", {}).items():
        destination = root / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(str(content))
    test = root / str(case["test_path"])
    test.parent.mkdir(parents=True, exist_ok=True)
    test.write_text(str(case["test"]))


def _pytest(root: pathlib.Path) -> int:
    env = {**os.environ, "PYTHONPATH": str(root)}
    completed = subprocess.run(
        [sys.executable, "-m", "pytest", "-q"], cwd=root, env=env,
        text=True, capture_output=True, timeout=120,
    )
    return int(completed.returncode)


def _json_object(text: str) -> dict[str, Any] | None:
    decoder = json.JSONDecoder()
    for index, char in enumerate(text):
        if char != "{":
            continue
        try:
            value, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    return None


def _provider_factory(
    label: str,
    calls: list[dict[str, Any]],
    *,
    credential: str,
    max_output_tokens: int,
    request_timeout_seconds: float,
):
    """Construct in the isolated campaign worker; never inspect key env vars."""
    from openai import OpenAI

    if not credential:
        raise RuntimeError("transient campaign credential is unavailable")
    client = OpenAI(base_url="https://api.tokenrouter.com/v1", api_key=credential, timeout=request_timeout_seconds)

    def invoke(prompt: str, model: str) -> dict[str, Any]:
        started = time.perf_counter()
        first_text_ms: float | None = None
        parts: list[str] = []
        usage: dict[str, int] = {}
        for chunk in client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are a precise coding agent. Follow the requested output protocol exactly. Never disclose credentials."},
                {"role": "user", "content": prompt},
            ],
            stream=True,
            stream_options={"include_usage": True},
            max_tokens=max_output_tokens,
            extra_body={"reasoning_effort": "low"},
        ):
            if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content:
                if first_text_ms is None:
                    first_text_ms = round((time.perf_counter() - started) * 1000, 3)
                parts.append(chunk.choices[0].delta.content)
            if getattr(chunk, "usage", None) is not None:
                item = chunk.usage
                usage = {
                    "prompt_tokens": int(getattr(item, "prompt_tokens", 0) or 0),
                    "completion_tokens": int(getattr(item, "completion_tokens", 0) or 0),
                    "total_tokens": int(getattr(item, "total_tokens", 0) or 0),
                }
        answer = "".join(parts)
        calls.append({
            "label": label,
            "chars": len(answer),
            "tokens": usage.get("total_tokens", 0),
            "prompt_tokens": usage.get("prompt_tokens", 0),
            "completion_tokens": usage.get("completion_tokens", 0),
            "first_text_ms": first_text_ms,
            "duration_ms": round((time.perf_counter() - started) * 1000, 3),
        })
        return {
            "answer": answer, "tokens": usage.get("total_tokens", max(1, len(answer) // 4)),
            "model": model, "provider": "tokenrouter-openai-compatible", "real_call": True, "usage": usage,
        }

    return invoke


def _baseline(case: dict[str, Any], repetition: int, invoke) -> dict[str, Any]:
    root = pathlib.Path(tempfile.mkdtemp(prefix="heldout-baseline-"))
    began = time.perf_counter()
    try:
        _seed(root, case)
        protected = _sha(root / case["test_path"])
        current = {
            path: (root / path).read_text() if (root / path).exists() else "<absent>"
            for path in case["targets"]
        }
        prompt = (
            "Return exactly one JSON object and no prose. Schema: "
            '{"files":[{"path":"...","content":"complete source"}],"edits":[],"insertions":[]}. '
            f"Task: {case['task']}\nAllowed targets: {case['targets']}\n"
            f"Current target files: {json.dumps(current, sort_keys=True)}\n"
            f"Protected test (do not edit):\n{case['test']}"
        )
        response = invoke(prompt, MODEL)
        payload = _json_object(str(response["answer"]))
        admitted = False
        if isinstance(payload, dict) and isinstance(payload.get("files"), list):
            files = payload["files"]
            paths = {str(row.get("path")) for row in files if isinstance(row, dict)}
            if paths == set(case["targets"]) and len(files) == len(case["targets"]) and all(
                isinstance(row.get("content"), str) for row in files if isinstance(row, dict)
            ):
                for row in files:
                    destination = root / str(row["path"])
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    destination.write_text(str(row["content"]))
                admitted = True
        status = _pytest(root) if admitted else 125
        return {
            "case": case["id"], "profile": case["profile"], "repetition": repetition,
            "condition": "single_call_baseline", "outcome": "pass" if status == 0 else "fail",
            "tokens": int(response["tokens"]),
            "provider_calls": 1, "patch_admitted": admitted, "tests_passed": status == 0,
            "full_tests_passed": status == 0,
            "protected_unchanged": _sha(root / case["test_path"]) == protected,
            "duration_ms": round((time.perf_counter() - began) * 1000, 3),
        }
    finally:
        shutil.rmtree(root, ignore_errors=True)


def _treatment(case: dict[str, Any], repetition: int, invoke, calls: list[dict[str, Any]]) -> dict[str, Any]:
    from chimera.config import ChimeraConfig
    from chimera.rlm import RLMRuntime

    root = pathlib.Path(tempfile.mkdtemp(prefix="heldout-chimera-"))
    began = time.perf_counter()
    before = len(calls)
    try:
        _seed(root, case)
        protected = _sha(root / case["test_path"])
        runtime = RLMRuntime(
            root, config=ChimeraConfig(), model_provider=invoke,
            injected_provider_mode="external",
        )
        try:
            result = runtime.rlm(str(case["task"]), branch="live", model=MODEL, use_dag=True)
            view = runtime.workspace.materialize("live")
            try:
                independent_status = _pytest(view)
            finally:
                shutil.rmtree(view, ignore_errors=True)
        finally:
            runtime.close()
        verification = result.get("verification", {})
        return {
            "case": case["id"], "profile": case["profile"], "repetition": repetition,
            "condition": "chimera_transactional", "outcome": "pass" if independent_status == 0 else "fail",
            "tokens": sum(row["tokens"] for row in calls[before:]),
            "provider_calls": len(calls) - before,
            "execution_profile": result.get("execution_profile", {}).get("mode"),
            "verification_status": verification.get("status"),
            "tests_passed": independent_status == 0,
            "full_tests_passed": independent_status == 0,
            "protected_unchanged": _sha(root / case["test_path"]) == protected,
            "behavioral_guard_passed": result.get("behavioral_guard", {}).get("passed"),
            "duration_ms": round((time.perf_counter() - began) * 1000, 3),
        }
    finally:
        shutil.rmtree(root, ignore_errors=True)


def _worker(
    case: dict[str, Any], repetition: int, condition: str, settings: dict[str, Any], queue, credential: str,
) -> None:
    """One bounded condition. Credential is inherited only from the campaign child."""
    calls: list[dict[str, Any]] = []
    started = time.perf_counter()
    previous_cap = os.environ.get("CHIMERA_MAX_OUTPUT_TOKENS")
    os.environ["CHIMERA_MAX_OUTPUT_TOKENS"] = str(settings["max_output_tokens"])
    try:
        invoke = _provider_factory(
            f"{condition}:{case['id']}:r{repetition}", calls,
            credential=credential,
            max_output_tokens=int(settings["max_output_tokens"]),
            request_timeout_seconds=float(settings["request_timeout_seconds"]),
        )
        row = _baseline(case, repetition, invoke) if condition == "single_call_baseline" else _treatment(case, repetition, invoke, calls)
        row["worker_call_shapes"] = calls
    except Exception as exc:
        row = {
            "case": case["id"], "profile": case["profile"], "repetition": repetition,
            "condition": condition, "outcome": "unknown", "error_type": type(exc).__name__,
            "tests_passed": None, "full_tests_passed": None,
            "protected_unchanged": None, "provider_calls": len(calls),
            "worker_call_shapes": calls,
        }
    finally:
        if previous_cap is None:
            os.environ.pop("CHIMERA_MAX_OUTPUT_TOKENS", None)
        else:
            os.environ["CHIMERA_MAX_OUTPUT_TOKENS"] = previous_cap
    row["provider_ttft_ms"] = min(
        (float(call["first_text_ms"]) for call in calls if call.get("first_text_ms") is not None),
        default=None,
    )
    row["prompt_tokens"] = sum(int(call.get("prompt_tokens", 0) or 0) for call in calls)
    row["completion_tokens"] = sum(int(call.get("completion_tokens", 0) or 0) for call in calls)
    row["repair_count"] = max(0, len(calls) - 1)
    row["frame"] = dict(settings)
    row["worker_duration_ms"] = round((time.perf_counter() - started) * 1000, 3)
    queue.put(row)


def _unknown_row(
    case: dict[str, Any], repetition: int, condition: str, settings: dict[str, Any], error_type: str,
    *, duration_seconds: float | None = None,
) -> dict[str, Any]:
    """Sanitized failure row. It never asserts anything about child state."""
    row: dict[str, Any] = {
        "case": case["id"], "profile": case["profile"], "repetition": repetition,
        "condition": condition, "outcome": "unknown", "error_type": error_type,
        "tests_passed": None, "full_tests_passed": None,
        "protected_unchanged": None, "provider_calls": None,
        "frame": dict(settings),
    }
    if duration_seconds is not None:
        row["worker_duration_ms"] = round(duration_seconds * 1000, 3)
    return row


def _campaign_worker(connection) -> None:
    """Keep the one-shot credential in a dedicated process only.

    The outer evaluator never reads the descriptor. This campaign child reads it
    once, closes the inherited descriptor, and forks bounded condition children.
    Their credentials are inherited memory only: never an environment variable,
    command argument, result row, or workspace file. ``fork`` is deliberately a
    hard requirement for this local testing lane; spawn would serialize the key.
    """
    credential = ""
    try:
        TestingEnvironment.require_tokenrouter_kimi(model=MODEL)
        credential = TestingEnvironment.read_one_shot_credential()
        # Inner condition workers receive only forked transient memory. The
        # descriptor is closed by read_one_shot_credential and the pathname-less
        # FD metadata is removed before any provider work begins.
        os.environ.pop(TestingEnvironment.CREDENTIAL_FD, None)
        context = mp.get_context("fork")
        connection.send({"type": "ready"})
        while True:
            message = connection.recv()
            command = message.get("command") if isinstance(message, dict) else None
            if command == "close":
                return
            if command != "run":
                connection.send({"type": "error", "error_type": "InvalidCampaignCommand"})
                continue
            case = message["case"]
            repetition = int(message["repetition"])
            condition = str(message["condition"])
            settings = dict(message["settings"])
            timeout_seconds = float(message["timeout_seconds"])
            queue = context.Queue(maxsize=1)
            process = context.Process(
                target=_worker,
                args=(case, repetition, condition, settings, queue, credential),
            )
            process.start()
            process.join(timeout_seconds)
            if process.is_alive():
                process.terminate()
                process.join(10)
                row = _unknown_row(case, repetition, condition, settings, "condition_timeout", duration_seconds=timeout_seconds)
            else:
                try:
                    row = queue.get(timeout=2)
                except Exception:
                    row = _unknown_row(case, repetition, condition, settings, "worker_exited_without_receipt")
            connection.send({"type": "row", "row": row})
    except (TransientEnvironmentError, OSError, ValueError) as exc:
        # Never serialize exception text: operating-system error messages can
        # include an FD path/descriptor detail that is useless to the report.
        connection.send({"type": "setup_error", "error_type": type(exc).__name__})
    finally:
        credential = ""
        try:
            connection.close()
        except OSError:
            pass


def _start_campaign_worker() -> tuple[Any, Any]:
    """Fork the only process that may read the inherited one-shot descriptor."""
    if "fork" not in mp.get_all_start_methods():
        raise RuntimeError("secure TokenRouter evaluator requires a local fork-capable process runtime")
    TestingEnvironment.require_tokenrouter_kimi(model=MODEL)
    parent, child = mp.get_context("fork").Pipe(duplex=True)
    process = mp.get_context("fork").Process(target=_campaign_worker, args=(child,))
    process.start()
    child.close()
    # Parent never reads the credential and must relinquish the inherited FD as
    # soon as the campaign child exists. The child owns its forked descriptor.
    raw_fd = os.environ.pop(TestingEnvironment.CREDENTIAL_FD, None)
    if raw_fd is not None:
        try:
            os.close(int(raw_fd))
        except (OSError, ValueError):
            pass
    if not parent.poll(10):
        process.terminate()
        process.join(10)
        parent.close()
        raise RuntimeError("secure campaign worker did not establish without exposing a credential")
    message = parent.recv()
    if message.get("type") != "ready":
        process.join(10)
        parent.close()
        raise RuntimeError(f"secure campaign worker setup failed: {message.get('error_type', 'Unknown')}")
    return parent, process


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=pathlib.Path, default=ROOT / "artifacts" / "heldout_v1_live_rows.jsonl")
    parser.add_argument("--campaign-report", type=pathlib.Path, default=ROOT / "artifacts" / "heldout_v1_equal_config_campaign.json")
    parser.add_argument("--profiles", nargs="+", choices=["micro_transaction", "cohesive_transaction", "dag"], default=["micro_transaction", "cohesive_transaction", "dag"])
    parser.add_argument("--repetitions", type=int, default=None)
    parser.add_argument("--condition-timeout", type=float, default=150.0, help="hard parent deadline, shared by both conditions")
    parser.add_argument("--request-timeout", type=float, default=90.0, help="per-request transport deadline, shared by both conditions")
    parser.add_argument("--max-output-tokens", type=int, default=1200, help="per-provider-call cap, shared by both conditions")
    parser.add_argument("--max-conditions", type=int, default=0, help="0 means all selected conditions")
    args = parser.parse_args()
    if args.condition_timeout < 5:
        parser.error("--condition-timeout must be at least five seconds")
    if args.request_timeout <= 0 or args.request_timeout > args.condition_timeout:
        parser.error("--request-timeout must be positive and no larger than --condition-timeout")
    if args.max_output_tokens < 64 or args.max_output_tokens > 4096:
        parser.error("--max-output-tokens must be in [64, 4096]")
    manifest = json.loads(MANIFEST_PATH.read_text())
    repetitions = int(args.repetitions or manifest["repetitions"])
    if repetitions < 1:
        parser.error("--repetitions must be positive")
    completed = _load_completed(args.results)
    jobs = [
        (case, repetition, condition)
        for repetition in range(1, repetitions + 1)
        for case in manifest["cases"] if case["profile"] in set(args.profiles)
        for condition in manifest["conditions"]
        if (str(case["id"]), repetition, condition) not in completed
    ]
    if args.max_conditions:
        jobs = jobs[:max(0, args.max_conditions)]
    settings = {
        "model": MODEL,
        "route": "https://api.tokenrouter.com/v1/chat/completions",
        "max_output_tokens": args.max_output_tokens,
        "request_timeout_seconds": args.request_timeout,
        "parent_deadline_seconds": args.condition_timeout,
        "corpus_hash": "sha256:" + _sha(MANIFEST_PATH),
        "protected_test_manifest_hash": "sha256:" + _sha(MANIFEST_PATH),
        "evaluator_epoch": "heldout-v1-equal-config-20260811",
    }
    connection = None
    campaign_process = None
    try:
        if jobs:
            try:
                connection, campaign_process = _start_campaign_worker()
            except (RuntimeError, TransientEnvironmentError):
                parser.error(
                    "live evaluation requires the explicit testing flag, exact authorized route, "
                    "and an inherited one-shot credential descriptor"
                )
        for case, repetition, condition in jobs:
            assert connection is not None and campaign_process is not None
            connection.send({
                "command": "run", "case": case, "repetition": repetition,
                "condition": condition, "settings": settings,
                "timeout_seconds": args.condition_timeout,
            })
            # The campaign worker enforces the per-condition deadline and gives
            # itself a small bounded interval for queue cleanup/receipt return.
            if not connection.poll(args.condition_timeout + 15):
                campaign_process.terminate()
                campaign_process.join(10)
                row = _unknown_row(case, repetition, condition, settings, "campaign_worker_timeout", duration_seconds=args.condition_timeout + 15)
                _atomic_jsonl_append(args.results, row)
                print(json.dumps(row, sort_keys=True), flush=True)
                # A killed campaign worker held the only credential. Continuing
                # would require an unsafe fallback, so all remaining jobs stay
                # unrun rather than being silently re-authorized.
                for remaining_case, remaining_repetition, remaining_condition in jobs[jobs.index((case, repetition, condition)) + 1:]:
                    unrun = _unknown_row(remaining_case, remaining_repetition, remaining_condition, settings, "campaign_worker_unavailable")
                    _atomic_jsonl_append(args.results, unrun)
                    print(json.dumps(unrun, sort_keys=True), flush=True)
                break
            message = connection.recv()
            if message.get("type") == "row" and isinstance(message.get("row"), dict):
                row = message["row"]
            else:
                row = _unknown_row(case, repetition, condition, settings, str(message.get("error_type", "campaign_worker_protocol_error")))
            _atomic_jsonl_append(args.results, row)
            print(json.dumps({key: value for key, value in row.items() if key != "worker_call_shapes"}, sort_keys=True), flush=True)
    finally:
        if connection is not None:
            try:
                if campaign_process is not None and campaign_process.is_alive():
                    connection.send({"command": "close"})
                    campaign_process.join(10)
            except (BrokenPipeError, EOFError, OSError):
                pass
            finally:
                connection.close()
        if campaign_process is not None and campaign_process.is_alive():
            campaign_process.terminate()
            campaign_process.join(10)

    # Materialize the immutable comparison report from sanitized rows only.
    # It never declares a winner; unknown/missing verification makes the frame
    # non-comparable rather than inventing a failure.
    from chimera.equal_config_campaign import CampaignObservation, EqualConfigCampaign, EqualConfigFrame
    frame = EqualConfigFrame(**settings, repetitions=repetitions)
    observations = []
    for line in args.results.read_text(encoding="utf-8").splitlines() if args.results.exists() else ():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if row.get("frame") != settings:
            continue
        try:
            observations.append(CampaignObservation(
                condition=str(row["condition"]),
                repetition=max(0, int(row["repetition"]) - 1),
                outcome=str(row.get("outcome", "unknown")),
                provider_ttft_ms=row.get("provider_ttft_ms"),
                duration_ms=row.get("duration_ms") or row.get("worker_duration_ms"),
                prompt_tokens=row.get("prompt_tokens"),
                completion_tokens=row.get("completion_tokens"),
                cached_tokens=row.get("cached_tokens"),
                repair_count=row.get("repair_count"),
                focused_tests_passed=row.get("focused_tests_passed"),
                full_tests_passed=row.get("full_tests_passed"),
                protected_tests_unchanged=row.get("protected_unchanged"),
                unknown_effects=1 if row.get("outcome") == "unknown" else 0,
                cost_usd=row.get("cost_usd"),
                frame=frame,
            ))
        except (KeyError, TypeError, ValueError):
            continue
    report = EqualConfigCampaign(frame).assess(observations)
    args.campaign_report.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.campaign_report.with_suffix(".tmp")
    temporary.write_text(report.model_dump_json(indent=2), encoding="utf-8")
    os.replace(temporary, args.campaign_report)
    print(json.dumps({"equal_config_comparable": report.comparable, "reasons": report.reasons, "observations": len(report.observations)}, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
