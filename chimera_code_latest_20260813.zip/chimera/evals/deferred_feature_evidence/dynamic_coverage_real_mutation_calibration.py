#!/usr/bin/env python3
"""Calibrate dynamic coverage Test Impact Analysis against real Chimera mutants.

A full coverage collection is run once in a disposable baseline copy. Each
curated source mutation then runs in an independent copy of that baseline:

1. select tests using the persisted Coverage.py dynamic-context map;
2. run the selected tests and the full suite independently;
3. record timing, selection, and detection facts.

This is an evidence harness, not a policy switch. It never changes Chimera's
default full-suite verification or enables focused-only promotion.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time
from statistics import median
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parents[2]
CORPUS = pathlib.Path(__file__).with_name("chimera_dynamic_coverage_real_mutation_corpus_v1.json")
IGNORE = shutil.ignore_patterns(
    ".chimera", ".pytest_cache", ".testmondata", "__pycache__", "node_modules", "build", "dist", "coverage", ".git",
)
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from chimera.dynamic_impact import DynamicCoverageCollector, DynamicImpactSelector


def _hash(path: pathlib.Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _copy_project(destination: pathlib.Path) -> None:
    """Copy the complete checked project fixture, excluding runtime/cache state.

    Some regression tests intentionally verify versioned root-level release and
    CI materials. Copying only Python packages would turn a calibration failure
    into a false claim about dynamic test selection.
    """
    shutil.copytree(ROOT, destination, dirs_exist_ok=True, ignore=IGNORE)


def _run(root: pathlib.Path, argv: list[str], *, timeout: int = 240) -> tuple[int, float, str]:
    started = time.perf_counter()
    completed = subprocess.run(
        argv, cwd=root, text=True, capture_output=True, timeout=timeout,
        env={**os.environ, "PYTHONPATH": str(root) + os.pathsep + os.environ.get("PYTHONPATH", "")},
    )
    return completed.returncode, round((time.perf_counter() - started) * 1000, 3), (completed.stdout + completed.stderr)[-4000:]


def _failed_path_seen(output: str, expected: str) -> bool:
    normalized = expected.replace("\\", "/")
    return normalized in output.replace("\\", "/")


def _baseline(root: pathlib.Path, *, evidence_ref: str) -> dict[str, Any]:
    command = [sys.executable, "-m", "pytest", "-q", "--cov=chimera", "--cov-context=test", "--cov-report="]
    status, duration_ms, output = _run(root, command, timeout=360)
    if status != 0:
        raise RuntimeError("coverage baseline failed: " + output[-500:])
    coverage_file = root / ".coverage"
    if not coverage_file.exists():
        raise RuntimeError("coverage baseline did not produce .coverage")
    receipt = DynamicCoverageCollector(root).collect(coverage_file, evidence_ref=evidence_ref)
    return {
        "baseline_status": status,
        "baseline_duration_ms": duration_ms,
        "coverage_file_hash": _hash(coverage_file),
        "coverage_map_tests": len(receipt.test_to_paths),
        "coverage_map_paths": sum(len(value) for value in receipt.test_to_paths.values()),
        "map_hash": "sha256:" + hashlib.sha256(receipt.model_dump_json().encode()).hexdigest(),
    }


def _case(baseline: pathlib.Path, case: dict[str, Any]) -> dict[str, Any]:
    workspace = pathlib.Path(tempfile.mkdtemp(prefix="chimera-dynamic-tia-case-"))
    try:
        shutil.copytree(baseline, workspace, dirs_exist_ok=True, ignore=IGNORE)
        # The map is evidence from the unmutated baseline, so copy it explicitly
        # after ignore rules have excluded unrelated branch state.
        source_map = baseline / ".chimera" / "dynamic-impact-map.json"
        map_path = workspace / ".chimera" / "dynamic-impact-map.json"
        map_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_map, map_path)
        target = workspace / str(case["path"])
        original = target.read_text(encoding="utf-8")
        needle = str(case["find"])
        if original.count(needle) != 1:
            return {
                "id": case["id"], "status": "invalid-anchor", "path": case["path"],
                "anchor_occurrences": original.count(needle), "expected_test": case["expected_test"],
            }
        target.write_text(original.replace(needle, str(case["replace"]), 1), encoding="utf-8")
        selection = DynamicImpactSelector(workspace).select([str(case["path"])])
        if selection.mode == "focused-dynamic":
            focused_command = [sys.executable, "-m", "pytest", "-q", *selection.selected_tests]
        else:
            focused_command = [sys.executable, "-m", "pytest", "-q"]
        focused_status, focused_ms, focused_output = _run(workspace, focused_command)
        full_status, full_ms, full_output = _run(workspace, [sys.executable, "-m", "pytest", "-q"])
        expected = str(case["expected_test"])
        return {
            "id": case["id"], "status": "completed", "path": case["path"], "expected_test": expected,
            "selection_mode": selection.mode, "selection_reason": selection.reason,
            "selected_tests": list(selection.selected_tests), "selected_test_count": len(selection.selected_tests),
            "expected_test_selected": expected in selection.selected_tests,
            "focused_status": focused_status, "full_status": full_status,
            "focused_detected": focused_status != 0,
            "full_detected": full_status != 0,
            "focused_expected_path_seen": _failed_path_seen(focused_output, expected),
            "full_expected_path_seen": _failed_path_seen(full_output, expected),
            "focused_duration_ms": focused_ms, "full_duration_ms": full_ms,
            "focused_to_full_ratio": round(focused_ms / full_ms, 6) if full_ms else None,
        }
    except subprocess.TimeoutExpired:
        return {"id": case["id"], "status": "timeout", "path": case["path"], "expected_test": case["expected_test"]}
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


def run(corpus_path: pathlib.Path, *, max_cases: int = 0) -> dict[str, Any]:
    corpus = json.loads(corpus_path.read_text(encoding="utf-8"))
    cases = list(corpus["cases"])
    if max_cases:
        cases = cases[:max_cases]
    baseline = pathlib.Path(tempfile.mkdtemp(prefix="chimera-dynamic-tia-baseline-"))
    try:
        _copy_project(baseline)
        evidence_ref = "artifact:sha256:" + hashlib.sha256(corpus_path.read_bytes()).hexdigest()
        baseline_receipt = _baseline(baseline, evidence_ref=evidence_ref)
        rows = [_case(baseline, case) for case in cases]
    finally:
        shutil.rmtree(baseline, ignore_errors=True)
    completed = [row for row in rows if row.get("status") == "completed"]
    valid_mutants = [row for row in completed if row.get("full_detected")]
    focused_hits = [row for row in valid_mutants if row.get("focused_detected")]
    ratios = [float(row["focused_to_full_ratio"]) for row in focused_hits if row.get("focused_to_full_ratio") is not None]
    selection_recall = (
        sum(bool(row.get("expected_test_selected")) for row in valid_mutants) / len(valid_mutants)
        if valid_mutants else None
    )
    report = {
        "schema_version": "chimera.dynamic-coverage-real-mutation-calibration.v1",
        "corpus_hash": _hash(corpus_path),
        "baseline": baseline_receipt,
        "cases_requested": len(cases),
        "completed_cases": len(completed),
        "valid_full_detected_mutants": len(valid_mutants),
        "dynamic_detection_recall": len(focused_hits) / len(valid_mutants) if valid_mutants else None,
        "expected_test_selection_recall": selection_recall,
        "median_focused_to_full_duration_ratio": median(ratios) if ratios else None,
        "rows": rows,
        "automatic_enablement": False,
        "manual_promotion_required": True,
        "policy_promotion": False,
        "reasons": [
            "Dynamic coverage selection is an explicit offline calibration lane.",
            "A single repository/host/environment and curated mutation corpus cannot certify a default focused-only policy.",
            "Full/protected verification remains mandatory for promotion decisions.",
        ],
    }
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=pathlib.Path, default=CORPUS)
    parser.add_argument("--max-cases", type=int, default=0, help="0 executes every corpus case")
    parser.add_argument("--results", type=pathlib.Path, default=ROOT / "artifacts" / "dynamic_coverage_real_mutation_calibration.json")
    args = parser.parse_args()
    report = run(args.corpus, max_cases=args.max_cases)
    args.results.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.results.with_suffix(args.results.suffix + ".tmp")
    temporary.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, args.results)
    print(json.dumps({
        key: report[key] for key in (
            "cases_requested", "completed_cases", "valid_full_detected_mutants", "dynamic_detection_recall",
            "expected_test_selection_recall", "median_focused_to_full_duration_ratio", "policy_promotion",
        )
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
