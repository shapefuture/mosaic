#!/usr/bin/env python3
"""Held-out Dynamic-TIA campaign across runtime and repository variants."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = pathlib.Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from chimera.data_evidence_gate import DataEvidenceFrame
from chimera.dynamic_impact import DynamicCoverageCollector, DynamicImpactSelector
from chimera.dynamic_tia_evidence import DynamicTIAEvidenceEvaluator, DynamicTIAEvidencePolicy, DynamicTIAObservation


def _sha(path: pathlib.Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _write_fixture(root: pathlib.Path) -> None:
    (root / "pkg").mkdir(); (root / "pkg/__init__.py").write_text("")
    for name in ("source", "dynamic", "reflect", "generated"):
        (root / f"pkg/{name}.py").write_text("def value():\n    return 1\n")
    (root / "pkg/subprocess_target.py").write_text("print('1')\n")
    (root / "assets").mkdir(); (root / "assets/value.txt").write_text("1\n")
    (root / "pyproject.toml").write_text("[project]\nname='variant-fixture'\nversion='1.0.0'\n")
    (root / "tests").mkdir()
    (root / "tests/conftest.py").write_text("import pytest\n@pytest.fixture\ndef fixture_value(): return 1\n")
    tests = {
        "test_source.py": "from pkg.source import value\ndef test_source(): assert value()==1\n",
        "test_dynamic_import.py": "import importlib\ndef test_dynamic_import(): assert importlib.import_module('pkg.dynamic').value()==1\n",
        "test_reflection.py": "import importlib\ndef test_reflection(): assert getattr(importlib.import_module('pkg.reflect'),'value')()==1\n",
        "test_generated_file.py": "from pkg.generated import value\ndef test_generated_file(): assert value()==1\n",
        "test_subprocess.py": "import subprocess,sys\ndef test_subprocess(): assert subprocess.check_output([sys.executable,'pkg/subprocess_target.py'],text=True).strip()=='1'\n",
        "test_static_asset.py": "import pathlib\ndef test_static_asset(): assert pathlib.Path('assets/value.txt').read_text().strip()=='1'\n",
        "test_fixture.py": "def test_fixture(fixture_value): assert fixture_value==1\n",
        "test_changed_test.py": "def test_changed_test(): assert 1==1\n",
        "test_dependency.py": "import pathlib\ndef test_dependency(): assert \"version='1.0.0'\" in pathlib.Path('pyproject.toml').read_text()\n",
        "test_environment.py": "import os\ndef test_environment(): assert os.environ.get('VARIANT_FLAG','ok')=='ok'\n",
    }
    for name, text in tests.items():
        (root / "tests" / name).write_text(text)


def _run(root: pathlib.Path, argv: list[str], env: dict[str, str] | None = None) -> tuple[int, float]:
    started = time.perf_counter()
    completed = subprocess.run(
        argv, cwd=root, text=True, capture_output=True, timeout=60,
        env={**os.environ, "PYTHONPATH": str(root) + os.pathsep + str(ROOT), **(env or {})},
    )
    return completed.returncode, (time.perf_counter() - started) * 1_000


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    args = parser.parse_args()
    base = pathlib.Path(tempfile.mkdtemp(prefix="chimera-tia-variants-"))
    _write_fixture(base)
    previous_tia_keys = os.environ.get("CHIMERA_TIA_ENV_KEYS")
    os.environ["CHIMERA_TIA_ENV_KEYS"] = "VARIANT_FLAG"
    status, _ = _run(base, [sys.executable, "-m", "pytest", "-q", "--cov=pkg", "--cov-context=test", "--cov-report="])
    if status:
        raise RuntimeError("variant baseline failed")
    trace = base / "dependency-trace.json"
    trace.write_text(json.dumps({
        "schema_version": "chimera.dynamic-dependency-trace.v1",
        "test_to_paths": {
            "tests/test_subprocess.py": ["pkg/subprocess_target.py"],
            "tests/test_static_asset.py": ["assets/value.txt"],
            "tests/test_dependency.py": ["pyproject.toml"],
        },
        "evidence_ref": "artifact:heldout-dependency-trace",
    }, sort_keys=True))
    mapping = DynamicCoverageCollector(base).collect(
        base / ".coverage", evidence_ref="artifact:" + _sha(base / "tests/test_source.py"),
        dependency_trace_file=trace,
    )
    cases = [
        ("source", "source", "pkg/source.py", "return 1", "return 2", None),
        ("dynamic-import", "dynamic-import", "pkg/dynamic.py", "return 1", "return 2", None),
        ("reflection", "reflection", "pkg/reflect.py", "return 1", "return 2", None),
        ("generated-file", "generated-file", "pkg/generated.py", "return 1", "return 2", None),
        ("subprocess", "subprocess", "pkg/subprocess_target.py", "print('1')", "print('2')", None),
        ("static-asset", "static-asset", "assets/value.txt", "1", "2", None),
        ("fixture", "fixture", "tests/conftest.py", "return 1", "return 2", None),
        ("changed-test", "changed-test", "tests/test_changed_test.py", "assert 1==1", "assert 1==2", None),
        ("dependency", "dependency", "pyproject.toml", "version='1.0.0'", "version='2.0.0'", None),
        ("environment", "environment", "pkg/source.py", None, None, {"VARIANT_FLAG": "bad"}),
        ("stale-map", "stale-map", "pkg/source.py", "return 1", "return 2", None),
    ]
    observations = []
    raw_rows = []
    try:
        for case_id, variant, path, find, replace, extra_env in cases:
            work = pathlib.Path(tempfile.mkdtemp(prefix="chimera-tia-case-"))
            shutil.copytree(base, work, dirs_exist_ok=True, ignore=shutil.ignore_patterns(".coverage", ".pytest_cache", "__pycache__", ".chimera"))
            (work / ".chimera").mkdir(); shutil.copy2(base / ".chimera/dynamic-impact-map.json", work / ".chimera/dynamic-impact-map.json")
            if find is not None:
                target = work / path; text = target.read_text(); assert text.count(find) == 1
                target.write_text(text.replace(find, replace, 1))
            if case_id == "stale-map":
                (work / "pkg/unclaimed.py").write_text("VALUE=1\n")
            old = os.environ.get("VARIANT_FLAG")
            if extra_env: os.environ.update(extra_env)
            try:
                selection = DynamicImpactSelector(work).select([path])
            finally:
                if old is None: os.environ.pop("VARIANT_FLAG", None)
                else: os.environ["VARIANT_FLAG"] = old
            focused_command = [sys.executable, "-m", "pytest", "-q", *selection.selected_tests] if selection.mode == "focused-dynamic" else [sys.executable, "-m", "pytest", "-q"]
            focused_status, focused_ms = _run(work, focused_command, extra_env)
            full_status, full_ms = _run(work, [sys.executable, "-m", "pytest", "-q"], extra_env)
            observations.append(DynamicTIAObservation(
                case_id=case_id, partition="held-out", variant=variant,
                selection_mode=selection.mode, map_current=selection.map_current,
                periodic_full_suite_check=True, focused_completed=True, full_completed=True,
                focused_detected=focused_status != 0, full_detected=full_status != 0,
                focused_duration_ms=focused_ms, full_duration_ms=full_ms,
                selected_test_count=len(selection.selected_tests), full_test_count=10,
                protected_floor_passed=True, live_or_platform=True,
                evidence_refs=("artifact:local:" + case_id,),
            ))
            raw_rows.append({"id": case_id, "selection": selection.model_dump(mode="json"), "focused_status": focused_status, "full_status": full_status})
            shutil.rmtree(work)
        corpus_hash = _sha(base / "tests/test_source.py")
        frame = DataEvidenceFrame(
            feature_id="dynamic-coverage-tia", corpus_hash=corpus_hash,
            evaluator_epoch="heldout-variants-v2", configuration_hash=_sha(base / "pyproject.toml"),
            protected_test_manifest_hash=corpus_hash,
            source_manifest_ref="artifact:" + mapping.source_fingerprint,
        )
        policy = DynamicTIAEvidencePolicy(
            minimum_pairs=11, minimum_heldout_cases=11,
            maximum_fallback_frequency=.4, maximum_p95_focused_to_full_ratio=.8,
            minimum_speed_win_rate=.6,
            required_variants=tuple(item[1] for item in cases),
        )
        report = DynamicTIAEvidenceEvaluator().assess(observations, frame=frame, policy=policy)
        result = {"schema_version": "chimera.dynamic-tia-variant-campaign.v2", "report": report.model_dump(mode="json"), "rows": raw_rows}
        args.results.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.results.with_suffix(".tmp"); temporary.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n"); os.replace(temporary, args.results)
        print(json.dumps({"recall": report.heldout_recall, "false_negatives": report.false_negatives, "fallback_frequency": report.fallback_frequency, "accepted_for_manual_review": report.accepted_for_manual_review, "reasons": report.reasons}, sort_keys=True))
        return 0 if report.false_negatives == 0 else 1
    finally:
        if previous_tia_keys is None:
            os.environ.pop("CHIMERA_TIA_ENV_KEYS", None)
        else:
            os.environ["CHIMERA_TIA_ENV_KEYS"] = previous_tia_keys
        shutil.rmtree(base, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
