#!/usr/bin/env python3
"""Run a curated real-source mutation corpus in disposable Chimera copies.

This is intentionally offline/local. It measures whether ImpactAnalyzer's
focused command selects the specified regression test and compares its timing
with the full local suite. It neither changes impact policy nor persists copied
workspaces or test output.
"""
from __future__ import annotations

import argparse
import json
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = pathlib.Path(__file__).resolve().parents[2]
CORPUS = pathlib.Path(__file__).with_name("chimera_real_mutation_corpus.json")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from chimera.impact import ImpactAnalyzer
from chimera.test_impact_calibration import ImpactCalibrationCase, TestImpactCalibrator


IGNORE = shutil.ignore_patterns(
    ".chimera", ".pytest_cache", "__pycache__", "node_modules", "build", "dist", "coverage", ".git",
)


def _run(root: pathlib.Path, argv: list[str]) -> tuple[int, float]:
    started = time.perf_counter()
    result = subprocess.run(argv, cwd=root, text=True, capture_output=True, timeout=180)
    return int(result.returncode), round((time.perf_counter() - started) * 1000, 3)


def _copy_workspace(destination: pathlib.Path) -> None:
    for name in ("chimera", "tests", "evals", "pyproject.toml", "chimera_agent_harness.egg-info"):
        source = ROOT / name
        target = destination / name
        if source.is_dir():
            shutil.copytree(source, target, ignore=IGNORE)
        elif source.is_file():
            shutil.copy2(source, target)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=pathlib.Path, default=CORPUS)
    parser.add_argument("--max-cases", type=int, default=0, help="0 means all corpus cases")
    args = parser.parse_args()
    corpus = json.loads(args.corpus.read_text(encoding="utf-8"))
    cases = list(corpus["cases"])
    if args.max_cases:
        cases = cases[:args.max_cases]
    calibration = []
    rows = []
    for case in cases:
        root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-real-mutation-"))
        try:
            _copy_workspace(root)
            source = root / case["path"]
            text = source.read_text(encoding="utf-8")
            if text.count(case["find"]) != 1:
                raise RuntimeError(f"mutation anchor is not unique for {case['id']}")
            source.write_text(text.replace(case["find"], case["replace"], 1), encoding="utf-8")
            scope = ImpactAnalyzer(root).analyze([case["path"]])
            focused_status, focused_ms = _run(root, scope.command.split())
            full_status, full_ms = _run(root, [sys.executable, "-m", "pytest", "-q"])
            expected = str(case["expected_failure"])
            calibration.append(ImpactCalibrationCase(
                case_id=str(case["id"]),
                scope=scope,
                injected_failure_tests=(expected,),
                focused_duration_ms=focused_ms,
                full_duration_ms=full_ms,
                focused_completed=True,
                full_completed=True,
                full_failing_tests=(expected,) if full_status != 0 else (),
            ))
            rows.append({
                "id": case["id"], "focused_status": focused_status, "full_status": full_status,
                "focused_ms": focused_ms, "full_ms": full_ms,
                "focused_mode": scope.mode, "selected_tests": list(scope.affected_tests),
                "expected_failure": expected,
            })
        finally:
            shutil.rmtree(root, ignore_errors=True)
    report = TestImpactCalibrator().assess(calibration)
    print(json.dumps({
        "cases": rows,
        "mutation_recall": report.mutation_recall,
        "focused_to_full_time_ratio": report.focused_to_full_time_ratio,
        "mandatory_floor_covered": report.mandatory_floor_covered,
        "policy_promotion": False,
        "reasons": list(report.reasons),
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
