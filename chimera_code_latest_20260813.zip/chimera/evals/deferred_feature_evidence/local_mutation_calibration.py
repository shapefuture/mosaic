#!/usr/bin/env python3
"""Transient local mutation calibration for ImpactAnalyzer.

Creates a disposable Python fixture, injects deterministic defects, executes the
selected focused command and full suite, and emits only aggregate rows.  It does
not change Chimera's focused-test policy.
"""
from __future__ import annotations

import json
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = pathlib.Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from chimera.impact import ImpactAnalyzer
from chimera.test_impact_calibration import ImpactCalibrationCase, TestImpactCalibrator


def _run(root: pathlib.Path, command: str) -> tuple[int, float]:
    started = time.perf_counter()
    completed = subprocess.run(command.split(), cwd=root, text=True, capture_output=True, timeout=60)
    return int(completed.returncode), round((time.perf_counter() - started) * 1000, 3)


def _seed(root: pathlib.Path) -> None:
    (root / "pkg").mkdir(exist_ok=True)
    (root / "pkg" / "__init__.py").write_text("")
    (root / "pkg" / "maths.py").write_text(
        "def add(left: int, right: int) -> int:\n    return left + right\n\n"
        "def sub(left: int, right: int) -> int:\n    return left - right\n"
    )
    (root / "tests").mkdir(exist_ok=True)
    (root / "tests" / "test_maths.py").write_text(
        "from pkg.maths import add, sub\n\n"
        "def test_add(): assert add(2, 3) == 5\n"
        "def test_sub(): assert sub(5, 3) == 2\n"
    )


def main() -> int:
    temp = pathlib.Path(tempfile.mkdtemp(prefix="chimera-impact-calibration-"))
    try:
        _seed(temp)
        cases = []
        for case_id, mutation, failing in (
            ("add-off-by-one", "return left + right + 1", "tests/test_maths.py::test_add"),
            ("sub-off-by-one", "return left - right - 1", "tests/test_maths.py::test_sub"),
        ):
            _seed(temp) if not (temp / "pkg" / "maths.py").exists() else None
            source = (temp / "pkg" / "maths.py").read_text()
            if case_id.startswith("add"):
                source = source.replace("return left + right", mutation)
            else:
                source = source.replace("return left - right", mutation)
            (temp / "pkg" / "maths.py").write_text(source)
            scope = ImpactAnalyzer(temp).analyze(["pkg/maths.py"])
            focused_status, focused_ms = _run(temp, scope.command)
            full_status, full_ms = _run(temp, "pytest -q")
            cases.append(ImpactCalibrationCase(
                case_id=case_id,
                scope=scope,
                injected_failure_tests=(failing,),
                focused_duration_ms=focused_ms,
                full_duration_ms=full_ms,
                focused_completed=True,
                full_completed=True,
                full_failing_tests=(failing,) if full_status != 0 else (),
            ))
            _seed(temp)
        report = TestImpactCalibrator().assess(cases)
        print(json.dumps({
            "cases": len(cases),
            "mutation_recall": report.mutation_recall,
            "focused_to_full_time_ratio": report.focused_to_full_time_ratio,
            "mandatory_floor_covered": report.mandatory_floor_covered,
            "accepted_for_manual_policy_review": False,
            "reasons": list(report.reasons),
        }, sort_keys=True))
        return 0
    finally:
        shutil.rmtree(temp, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
