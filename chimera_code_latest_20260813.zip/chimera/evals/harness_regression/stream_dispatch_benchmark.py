#!/usr/bin/env python3
"""Synthetic stream-time dispatch benchmark.

Measures the theoretical latency benefit when a complete read-only tool call
appears before the model finishes streaming. No provider credentials needed.
"""
from __future__ import annotations
import json, time
from chimera.stream_tools import StreamToolExtractor

def simulate(*, tail_tokens: int = 20, tail_delay: float = 0.02, tool_delay: float = 0.25):
    chunks = ['prefix ', '<tool_call>{"name":"read_file","arguments":{"path":"a.py"}}</tool_call>', *([' tail'] * tail_tokens)]
    # Previous design: wait for full stream, then tool.
    t0=time.perf_counter()
    for c in chunks:
        time.sleep(tail_delay)
    time.sleep(tool_delay)
    previous=time.perf_counter()-t0
    # Stream-time: start tool as soon as block appears; here model tail continues while tool runs.
    t0=time.perf_counter(); extractor=StreamToolExtractor(); tool_done_at=None; now=0.0
    for i,c in enumerate(chunks):
        time.sleep(tail_delay); now=time.perf_counter()-t0
        events=extractor.feed(c)
        if events and tool_done_at is None:
            tool_done_at=now+tool_delay
    stream_end=time.perf_counter()-t0
    stream_time=max(stream_end, tool_done_at or stream_end)
    return {
        'previous_seconds': round(previous, 4),
        'stream_time_seconds': round(stream_time, 4),
        'saved_seconds': round(previous-stream_time, 4),
        'tool_wall_hidden_ratio': round(max(0.0, previous-stream_time)/tool_delay, 3),
        'tail_tokens': tail_tokens,
        'tail_delay': tail_delay,
        'tool_delay': tool_delay,
    }

if __name__ == '__main__':
    print(json.dumps(simulate(), indent=2))
