#!/usr/bin/env python3
"""Live hardened-vs-scaffold-flag comparison on a non-registry task shape."""
from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any

ROOT=pathlib.Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
MODEL="moonshotai/kimi-k3-free"

TASK=("Implement `chimera/sequence_tools.py` with typed `bucket_runs(values: list[int]) -> list[dict[str, int]]`. "
      "Return one dictionary for each consecutive run, in order, with exactly keys `value` and `length`. "
      "Do not modify supplied tests.")


def seed(root:pathlib.Path)->None:
    (root/'chimera').mkdir();(root/'chimera'/'__init__.py').write_text('');(root/'chimera'/'sequence_tools.py').write_text('')
    (root/'tests').mkdir();(root/'tests'/'test_sequence_tools.py').write_text(
        "from chimera.sequence_tools import bucket_runs\n\n"
        "def test_bucket_runs_empty_and_singleton():\n"
        "    assert bucket_runs([]) == []\n"
        "    assert bucket_runs([7]) == [{'value': 7, 'length': 1}]\n\n"
        "def test_bucket_runs_preserves_consecutive_boundaries():\n"
        "    assert bucket_runs([1,1,2,2,2,1,3,3]) == [\n"
        "        {'value': 1, 'length': 2}, {'value': 2, 'length': 3},\n"
        "        {'value': 1, 'length': 1}, {'value': 3, 'length': 2}\n"
        "    ]\n"
    )


def test_status(root:pathlib.Path)->tuple[int,float]:
    started=time.perf_counter()
    row=subprocess.run([sys.executable,'-m','pytest','-q'],cwd=root,env={**os.environ,'PYTHONPATH':str(root)},text=True,capture_output=True,timeout=120)
    return int(row.returncode),round((time.perf_counter()-started)*1000,3)


def provider(calls:list[dict[str,Any]]):
    from openai import OpenAI
    key=os.environ.get('TOKENROUTER_API_KEY')
    if not key: raise RuntimeError('missing TOKENROUTER_API_KEY')
    client=OpenAI(base_url='https://api.tokenrouter.com/v1',api_key=key,timeout=60.0)
    def invoke(prompt:str,model:str)->dict[str,Any]:
        started=time.perf_counter();parts=[];usage={}
        for chunk in client.chat.completions.create(model=model,messages=[
            {'role':'system','content':'You are a precise coding agent. Return only the requested JSON patch. Never disclose credentials.'},
            {'role':'user','content':prompt},
        ],stream=True,stream_options={'include_usage':True},max_tokens=1200,extra_body={}):
            if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content: parts.append(chunk.choices[0].delta.content)
            if getattr(chunk,'usage',None) is not None:
                row=chunk.usage; usage={'prompt':int(getattr(row,'prompt_tokens',0) or 0),'completion':int(getattr(row,'completion_tokens',0) or 0),'total':int(getattr(row,'total_tokens',0) or 0)}
        answer=''.join(parts);calls.append({'model':model,'tokens':usage.get('total',0),'duration_ms':round((time.perf_counter()-started)*1000,3),'chars':len(answer)})
        return {'answer':answer,'tokens':usage.get('total',max(1,len(answer)//4)),'model':model,'provider':'tokenrouter-openai-compatible','real_call':True,'usage':usage}
    return invoke


def worker(condition:str, queue)->None:
    from chimera.config import ChimeraConfig
    from chimera.quality import TaskContract
    from chimera.rlm import RLMRuntime
    from chimera.scaffolds import ScaffoldRegistry
    root=pathlib.Path(tempfile.mkdtemp(prefix='chimera-nonscaffold-')); calls=[]; started=time.perf_counter(); prior=os.environ.get('CHIMERA_ENABLE_DETERMINISTIC_SCAFFOLDS')
    try:
        if condition=='scaffold_opt_in': os.environ['CHIMERA_ENABLE_DETERMINISTIC_SCAFFOLDS']='1'
        else: os.environ.pop('CHIMERA_ENABLE_DETERMINISTIC_SCAFFOLDS',None)
        seed(root); protected=(root/'tests/test_sequence_tools.py').read_text(); contract=TaskContract.compile(root,TASK)
        registry_match=ScaffoldRegistry(root).match(contract,contract.targets[0])
        runtime=RLMRuntime(root,config=ChimeraConfig(),model_provider=provider(calls),injected_provider_mode='external')
        try:
            result=runtime.rlm(TASK,branch='live',model=MODEL,use_dag=True)
            view=runtime.workspace.materialize('live')
            try: status,test_ms=test_status(view)
            finally: shutil.rmtree(view,ignore_errors=True)
        finally: runtime.close()
        queue.put({'condition':condition,'outcome':'known','registry_match':registry_match is not None,'tests_passed':status==0,'protected_unchanged':(root/'tests/test_sequence_tools.py').read_text()==protected,'execution_profile':result.get('execution_profile',{}).get('mode'),'verification_status':result.get('verification',{}).get('status'),'provider_calls':len(calls),'provider_tokens':sum(row['tokens'] for row in calls),'provider_latency_ms':sum(row['duration_ms'] for row in calls),'provider_trace':calls,'test_ms':test_ms,'duration_ms':round((time.perf_counter()-started)*1000,3)})
    except Exception as exc:
        queue.put({'condition':condition,'outcome':'unknown','error_type':type(exc).__name__})
    finally:
        if prior is None: os.environ.pop('CHIMERA_ENABLE_DETERMINISTIC_SCAFFOLDS',None)
        else: os.environ['CHIMERA_ENABLE_DETERMINISTIC_SCAFFOLDS']=prior
        shutil.rmtree(root,ignore_errors=True)


def run_one(condition:str, timeout:float)->dict[str,Any]:
    ctx=mp.get_context('spawn');queue=ctx.Queue(maxsize=1);process=ctx.Process(target=worker,args=(condition,queue));process.start();process.join(timeout)
    if process.is_alive():
        process.terminate();process.join(10)
        return {'condition':condition,'outcome':'unknown','error_type':'condition_timeout','timeout_seconds':timeout}
    try:return queue.get(timeout=2)
    except Exception:return {'condition':condition,'outcome':'unknown','error_type':'worker_exited_without_receipt'}


def main()->None:
    parser=argparse.ArgumentParser();parser.add_argument('--timeout',type=float,default=240.0);parser.add_argument('--results',type=pathlib.Path,default=ROOT/'artifacts'/'non_scaffold_compare.json');args=parser.parse_args()
    if not os.environ.get('TOKENROUTER_API_KEY'):
        print(json.dumps({'outcome':'skipped','reason':'missing TOKENROUTER_API_KEY'}));return
    rows=[run_one('hardened',args.timeout),run_one('scaffold_opt_in',args.timeout)]
    result={'schema_version':'chimera.non-scaffold-compare/v1','model_requested':MODEL,'task_shape':'non_registry_sequence_runs','rows':rows}
    args.results.parent.mkdir(parents=True,exist_ok=True);args.results.write_text(json.dumps(result,sort_keys=True,indent=2,default=str));print(json.dumps(result,sort_keys=True,default=str))

if __name__=='__main__':main()
