#!/usr/bin/env python3
"""Strict hidden-test harness regression comparison.

Runs direct baselines (no protected tests) against Chimera full-repo execution.
No credentials are stored here. Set CEREBRAS_API_KEY to run live; otherwise exits
with a skip row.
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any

import httpx

ROOT = pathlib.Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

MODEL = "cerebras/gpt-oss-120b"
DIRECT_MODEL = "gpt-oss-120b"


def pytest_status(root: pathlib.Path) -> tuple[int, str]:
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "-q"], cwd=root,
        env={**os.environ, "PYTHONPATH": str(root)}, capture_output=True, text=True, timeout=60,
    )
    return result.returncode, (result.stdout + result.stderr)[-1000:]


def extract_json(text: str) -> dict[str, Any] | None:
    decoder = json.JSONDecoder()
    for index, char in enumerate(text or ""):
        if char != "{":
            continue
        try:
            value, _ = decoder.raw_decode(text[index:])
            if isinstance(value, dict):
                return value
        except json.JSONDecodeError:
            pass
    return None


def apply_payload(root: pathlib.Path, payload: dict[str, Any] | None, allowed: set[str]) -> tuple[list[str], list[str]]:
    touched: list[str] = []
    rejected: list[str] = []
    if not isinstance(payload, dict):
        return touched, ["no json object"]
    rows: list[dict[str, Any]] = []
    if isinstance(payload.get("f"), dict):
        rows.extend({"path": path, "content": content} for path, content in payload["f"].items())
    rows.extend(payload.get("files", []) or [])
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("path"), str) or not isinstance(row.get("content"), str):
            continue
        if row["path"] in allowed:
            destination = root / row["path"]
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(row["content"])
            touched.append(row["path"])
        else:
            rejected.append(row["path"])
    return list(dict.fromkeys(touched)), rejected


def call_direct(prompt: str) -> tuple[float, str | None, dict[str, Any]]:
    key = os.environ.get("CEREBRAS_API_KEY")
    if not key:
        return 0.0, None, {"skip": "missing CEREBRAS_API_KEY"}
    started = time.monotonic()
    response = httpx.post(
        "https://api.cerebras.ai/v1/chat/completions",
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        json={"model": DIRECT_MODEL, "messages": [{"role": "user", "content": prompt}], "max_tokens": 900, "temperature": 0, "reasoning_effort": "low"},
        timeout=60,
    )
    wall = round(time.monotonic() - started, 3)
    if response.status_code != 200:
        return wall, None, {"http_status": response.status_code, "error": response.text[:300]}
    data = response.json()
    return wall, data["choices"][0]["message"].get("content") or "", {"http_status": 200, "tokens": data.get("usage", {}).get("total_tokens")}


def seed_inventory(root: pathlib.Path) -> dict[str, Any]:
    (root / "chimera").mkdir(); (root / "chimera/__init__.py").write_text(""); (root / "chimera/inventory.py").write_text("")
    (root / "tests").mkdir(); (root / "tests/test_inventory.py").write_text('''from chimera.inventory import reconcile\n\ndef test_reconcile_merges_casefolded_skus_and_sorts():\n    rows=[{"sku":" a-1 ","qty":"02"},{"sku":"A-1","qty":3},{"sku":"b","qty":"0"},{"sku":"","qty":9}]\n    assert reconcile(rows)==[{"sku":"a-1","qty":5},{"sku":"b","qty":0}]\n\ndef test_bad_quantities_are_ignored_not_crashing():\n    assert reconcile([{"sku":"x","qty":"bad"},{"sku":"x","qty":4}])==[{"sku":"x","qty":4}]\n''')
    return {
        "id": "inventory_reconcile_hidden_edges",
        "allowed": ["chimera/inventory.py"], "protected": ["tests/test_inventory.py"],
        "direct_task": "Implement chimera/inventory.py reconcile(rows) to aggregate inventory quantities by sku and return normalized rows.",
        "chimera_task": "Implement `chimera/inventory.py` with a typed `reconcile(rows: list[dict]) -> list[dict]` function matching supplied tests. Do not modify supplied tests.",
    }


def direct_condition(case: dict[str, Any], visible: bool) -> dict[str, Any]:
    with tempfile.TemporaryDirectory() as td:
        root = pathlib.Path(td); seed_inventory(root); before = {path: (root / path).read_text() for path in case["protected"]}
        prompt = "Return ONLY JSON patch with files/edits/insertions. Do not modify tests. Allowed targets: " + ",".join(case["allowed"]) + "\nTask:\n" + case["direct_task"]
        if visible:
            prompt += "\nCurrent target files:\n" + json.dumps({path: (root / path).read_text() for path in case["allowed"]})
        wall, text, meta = call_direct(prompt)
        touched, rejected = apply_payload(root, extract_json(text or ""), set(case["allowed"]))
        status, log = pytest_status(root) if touched else (125, "no patch")
        return {"ok": status == 0 and not rejected and all((root / path).read_text() == value for path, value in before.items()), "wall": wall, "status": status, "touched": touched, "rejected": rejected, "tokens": meta.get("tokens"), "skip": meta.get("skip"), "log": log[:500]}


def chimera_condition(case: dict[str, Any]) -> dict[str, Any]:
    from chimera.config import ChimeraConfig
    from chimera.rlm import RLMRuntime
    with tempfile.TemporaryDirectory() as td:
        root = pathlib.Path(td); seed_inventory(root); before = {path: (root / path).read_text() for path in case["protected"]}
        runtime = RLMRuntime(root, config=ChimeraConfig())
        started = time.monotonic()
        try:
            result = runtime.rlm(case["chimera_task"], branch="live", model=MODEL, use_dag=True)
            view = runtime.workspace.materialize("live")
            try:
                status, log = pytest_status(view)
            finally:
                shutil.rmtree(view, ignore_errors=True)
            return {"ok": status == 0 and all((root / path).read_text() == value for path, value in before.items()), "wall": round(time.monotonic() - started, 3), "status": status, "verification": result.get("verification"), "heldout": result.get("heldout"), "quality": result.get("quality_rubric"), "tokens": result.get("usage", {}).get("tokens"), "log": log[:500]}
        finally:
            runtime.close()


def main() -> None:
    os.environ.setdefault("CHIMERA_REASONING_EFFORT", "low")
    if not os.environ.get("CEREBRAS_API_KEY"):
        print(json.dumps({"status": "skip", "reason": "missing CEREBRAS_API_KEY"}, indent=2))
        return
    with tempfile.TemporaryDirectory() as td:
        root = pathlib.Path(td); case = seed_inventory(root)
    result = {"case": case["id"], "direct_raw": direct_condition(case, False), "direct_visible": direct_condition(case, True), "chimera": chimera_condition(case)}
    include_scaffold_free = os.environ.get("CHIMERA_STRICT_STRESS_INCLUDE_SCAFFOLD_FREE") == "1"
    if include_scaffold_free:
        previous = os.environ.get("CHIMERA_DISABLE_DOMAIN_SCAFFOLDS")
        os.environ["CHIMERA_DISABLE_DOMAIN_SCAFFOLDS"] = "1"
        try:
            result["chimera_scaffold_free"] = chimera_condition(case)
        finally:
            if previous is None:
                os.environ.pop("CHIMERA_DISABLE_DOMAIN_SCAFFOLDS", None)
            else:
                os.environ["CHIMERA_DISABLE_DOMAIN_SCAFFOLDS"] = previous
    result["chimera_superior"] = bool(result["chimera"].get("ok")) and (not result["direct_raw"].get("ok") or not result["direct_visible"].get("ok"))
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
