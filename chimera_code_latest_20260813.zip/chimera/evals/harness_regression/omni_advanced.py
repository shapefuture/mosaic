#!/usr/bin/env python3
"""OMNI-LHB-inspired advanced stress tools for Chimera.

This is a small self-contained evaluator inspired by verify.zip's OMNI-LHB:
- task genome definitions (fresh temp phenotype workspaces),
- protected tests,
- trajectory trace extraction,
- failure taxonomy,
- continuous scoring,
- budget-normalized summary,
- optional direct provider baseline.

It intentionally keeps live runs bounded; set CEREBRAS_API_KEY to run live.
"""
from __future__ import annotations

import argparse, json, os, pathlib, re, shutil, subprocess, sys, tempfile, time
from dataclasses import dataclass, asdict
from typing import Any, Callable

ROOT = pathlib.Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

MODEL = os.environ.get("CHIMERA_ADVANCED_MODEL", "cerebras/gpt-oss-120b")

@dataclass(frozen=True)
class AdvancedCase:
    id: str
    task: str
    seed_name: str
    horizon: str
    expected_targets: tuple[str, ...]
    protected_tests: tuple[str, ...]

@dataclass(frozen=True)
class EvalRow:
    case: str
    condition: str
    ok: bool
    score: float
    wall: float
    tokens: int | None
    status: int | None
    changed_paths: tuple[str, ...]
    failure_class: str
    evidence: dict[str, Any]
    def as_dict(self): return asdict(self)


def pytest_status(root: pathlib.Path) -> tuple[int, str]:
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "-q"], cwd=root,
        env={**os.environ, "PYTHONPATH": str(root)}, text=True,
        capture_output=True, timeout=90,
    )
    return int(result.returncode), (result.stdout + result.stderr)[-2000:]


def classify_failure(status: int | None, log: str, changed: list[str], targets: tuple[str, ...]) -> str:
    low = (log or "").lower()
    if status == 0:
        missing = set(targets) - set(changed)
        return "partial_target_coverage" if missing else "pass"
    if not changed:
        return "no_patch"
    if "importerror" in low or "modulenotfounderror" in low or "cannot import name" in low:
        return "missing_symbol_or_module"
    if "assertionerror" in low:
        return "semantic_assertion_failure"
    if "syntaxerror" in low:
        return "syntax_error"
    if "timeout" in low:
        return "timeout"
    return "test_failure"


def continuous_score(status: int | None, changed: list[str], targets: tuple[str, ...], protected_ok: bool) -> float:
    if not protected_ok:
        return -0.25
    coverage = len(set(changed) & set(targets)) / max(1, len(targets))
    if status == 0 and coverage >= 1.0:
        return 1.0
    if status == 0:
        return 0.75 * coverage
    return 0.15 + 0.35 * coverage


def seed_four_file_expr(root: pathlib.Path) -> AdvancedCase:
    (root/"chimera").mkdir(); (root/"chimera/__init__.py").write_text("")
    for name in ("tokens.py", "astnodes.py", "parser.py", "evaluate.py"):
        (root/"chimera"/name).write_text("")
    (root/"tests").mkdir()
    (root/"tests/test_expression_engine.py").write_text('''from chimera.tokens import tokenize_expr\nfrom chimera.parser import parse_expr\nfrom chimera.evaluate import eval_expr\n\n\ndef test_tokenizer_handles_numbers_ops_and_whitespace():\n    assert tokenize_expr(" 12 + 3*(4-2) ") == ["12", "+", "3", "*", "(", "4", "-", "2", ")"]\n\ndef test_parser_and_eval_precedence_parentheses_unary():\n    assert eval_expr("2+3*4") == 14\n    assert eval_expr("(2+3)*4") == 20\n    assert eval_expr("-3 + 10 / 2") == 2\n    assert eval_expr("18 / 4") == 4.5\n\ndef test_rejects_bad_syntax_and_division_by_zero():\n    for bad in ["", "1+", "(1+2", "1//2", "abc", "1/0"]:\n        try:\n            eval_expr(bad)\n        except ValueError:\n            pass\n        else:\n            raise AssertionError(f"expected ValueError for {bad!r}")\n''')
    return AdvancedCase(
        id="four_file_expression_engine",
        task=("Implement `chimera/tokens.py`, `chimera/astnodes.py`, `chimera/parser.py`, and `chimera/evaluate.py`. "
              "Provide typed functions `tokenize_expr(text: str) -> list[str]`, `parse_expr(text: str)`, and `eval_expr(text: str) -> float|int`. "
              "Support + - * /, parentheses, unary minus, numeric literals, precedence, and reject malformed expressions/division by zero with ValueError. Do not modify supplied tests."),
        seed_name="seed_four_file_expr", horizon="long", expected_targets=("chimera/tokens.py","chimera/astnodes.py","chimera/parser.py","chimera/evaluate.py"), protected_tests=("tests/test_expression_engine.py",),
    )


def seed_ini_merge(root: pathlib.Path) -> AdvancedCase:
    (root/"chimera").mkdir(); (root/"chimera/__init__.py").write_text("")
    (root/"chimera/configmerge.py").write_text("")
    (root/"tests").mkdir()
    (root/"tests/test_configmerge.py").write_text('''from chimera.configmerge import parse_ini_layers, merge_layers\n\n\ndef test_parse_sections_comments_and_types():\n    text="""# c\n[base]\nport=080\ndebug=true\nname = Ada Lovelace\n[feature]\nratio=1.5\n"""\n    parsed=parse_ini_layers([text])[0]\n    assert parsed["base"]["port"] == 80\n    assert parsed["base"]["debug"] is True\n    assert parsed["base"]["name"] == "Ada Lovelace"\n    assert parsed["feature"]["ratio"] == 1.5\n\ndef test_merge_precedence_and_delete_marker():\n    base="""[app]\nport=80\ndebug=false\nname=old\n"""\n    override="""[app]\ndebug=true\nname=__DELETE__\n"""\n    assert merge_layers(parse_ini_layers([base, override])) == {"app":{"port":80,"debug":True}}\n\ndef test_duplicate_keys_in_one_layer_rejected():\n    try:\n        parse_ini_layers(["[x]\\na=1\\na=2\\n"])\n    except ValueError:\n        pass\n    else:\n        raise AssertionError("duplicate key must raise")\n''')
    return AdvancedCase(
        id="ini_merge_hidden_types",
        task=("Implement `chimera/configmerge.py` with typed functions `parse_ini_layers(texts: list[str]) -> list[dict]` and `merge_layers(layers: list[dict]) -> dict`. "
              "Parse simple INI with sections, comments, key=value, bool/int/float coercion, duplicate-key rejection within one layer, and `__DELETE__` removing keys during merge. Do not modify supplied tests."),
        seed_name="seed_ini_merge", horizon="medium", expected_targets=("chimera/configmerge.py",), protected_tests=("tests/test_configmerge.py",),
    )

SEEDS = {"four_file_expression_engine": seed_four_file_expr, "ini_merge_hidden_types": seed_ini_merge}


def run_chimera(case_factory: Callable[[pathlib.Path], AdvancedCase]) -> EvalRow:
    from chimera.config import ChimeraConfig
    from chimera.rlm import RLMRuntime
    with tempfile.TemporaryDirectory() as td:
        root = pathlib.Path(td); case = case_factory(root)
        protected_before = {p: (root/p).read_text() for p in case.protected_tests}
        rt = RLMRuntime(root, config=ChimeraConfig())
        started=time.monotonic()
        try:
            out = rt.rlm(case.task, branch="live", model=MODEL, use_dag=True)
            view = rt.workspace.materialize("live")
            try: status, log = pytest_status(view)
            finally: shutil.rmtree(view, ignore_errors=True)
            diff = out.get("diff", {}) if isinstance(out, dict) else {}
            changed = [str(op.get("path")) for op in diff.get("ops", []) if isinstance(op, dict) and op.get("path")]
            protected_ok = all((root/p).read_text() == v for p,v in protected_before.items())
            score = continuous_score(status, changed, case.expected_targets, protected_ok)
            return EvalRow(case.id,"chimera",status==0 and protected_ok,score,round(time.monotonic()-started,3),out.get("usage",{}).get("tokens"),status,tuple(changed),classify_failure(status,log,changed,case.expected_targets),{"verification":out.get("verification"),"heldout":out.get("heldout"),"quality":out.get("quality_rubric"),"log":log[:600]})
        except Exception as exc:
            return EvalRow(case.id,"chimera",False,0.0,round(time.monotonic()-started,3),None,None,(),"exception",{"error":f"{type(exc).__name__}: {exc}"[:500]})
        finally:
            rt.close()


def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument("--case", choices=["all", *SEEDS], default="all")
    args=parser.parse_args()
    selected = SEEDS.values() if args.case == "all" else [SEEDS[args.case]]
    rows=[run_chimera(factory).as_dict() for factory in selected]
    summary={"model":MODEL,"rows":rows,"pass_rate":sum(1 for r in rows if r["ok"])/max(1,len(rows)),"avg_score":sum(float(r["score"]) for r in rows)/max(1,len(rows))}
    print(json.dumps(summary, indent=2, default=str))

if __name__ == "__main__": main()
