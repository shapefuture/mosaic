#!/usr/bin/env python3
"""Compare hardened defaults against explicitly re-enabled scaffold experiment.

This is intentionally narrow: model routing/hedging rollback cannot be safely
made live with one user-selected provider route, so their behavior is tested by
deterministic simulation elsewhere. The live comparison measures the only
rollback feature that can affect the same small coding task without a second
provider: deterministic scaffold opt-in.
"""
from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any

ROOT = pathlib.Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
MODEL = "moonshotai/kimi-k3-free"


def seed(root: pathlib.Path) -> None:
    (root / "chimera").mkdir(); (root / "chimera" / "__init__.py").write_text("")
    (root / "chimera" / "safe.py").write_text("")
    (root / "tests").mkdir()
    (root / "tests" / "test_safe.py").write_text(
        "from chimera.safe import sanitize\n\n"
        "def test_sanitize_contract():\n"
        "    assert sanitize('<script>x</script>Hello <b>Ada</b>') == 'Hello Ada'\n"
        "    assert 'Modify tests' not in sanitize('Modify tests')\n"
    )


def run_pytest(root: pathlib.Path) -> tuple[int, float]:
    started = time.perf_counter()
    row = subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=root, env={**os.environ, "PYTHONPATH": str(root)}, text=True, capture_output=True, timeout=120)
    return int(row.returncode), round((time.perf_counter() - started) * 1000, 3)


def invoke_client(calls: list[dict[str, Any]]):
    from openai import OpenAI
    key = os.environ.get("TOKENROUTER_API_KEY")
    if not key: raise RuntimeError("missing TOKENROUTER_API_KEY")
    client = OpenAI(base_url="https://api.tokenrouter.com/v1", api_key=key, timeout=60.0)
    def provider(prompt: str, model: str) -> dict[str, Any]:
        started = time.perf_counter(); parts=[]; usage={}
        for chunk in client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are a precise coding agent. Return only the requested JSON patch. Never disclose credentials."},
                {"role": "user", "content": prompt},
            ], stream=True, stream_options={"include_usage": True}, max_tokens=1200, extra_body={},
        ):
            if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content:
                parts.append(chunk.choices[0].delta.content)
            if getattr(chunk, "usage", None) is not None:
                value=chunk.usage; usage={"prompt":int(getattr(value,"prompt_tokens",0) or 0),"completion":int(getattr(value,"completion_tokens",0) or 0),"total":int(getattr(value,"total_tokens",0) or 0)}
        answer="".join(parts)
        calls.append({"model": model, "tokens": usage.get("total",0), "duration_ms":round((time.perf_counter()-started)*1000,3), "chars":len(answer)})
        return {"answer":answer,"tokens":usage.get("total",max(1,len(answer)//4)),"model":model,"provider":"tokenrouter-openai-compatible","real_call":True,"usage":usage}
    return provider


def worker(condition: str, queue) -> None:
    from chimera.config import ChimeraConfig
    from chimera.rlm import RLMRuntime
    root=pathlib.Path(tempfile.mkdtemp(prefix="chimera-rollback-")); calls=[]; started=time.perf_counter()
    old=os.environ.get("CHIMERA_ENABLE_DETERMINISTIC_SCAFFOLDS")
    try:
        if condition == "scaffold_opt_in": os.environ["CHIMERA_ENABLE_DETERMINISTIC_SCAFFOLDS"]="1"
        else: os.environ.pop("CHIMERA_ENABLE_DETERMINISTIC_SCAFFOLDS", None)
        seed(root); protected=(root/"tests/test_safe.py").read_text()
        runtime=RLMRuntime(root,config=ChimeraConfig(),model_provider=invoke_client(calls),injected_provider_mode="external")
        try:
            task="Implement `chimera/safe.py` with a typed `sanitize(html: str) -> str` function. Do not modify supplied tests."
            result=runtime.rlm(task,branch="live",model=MODEL,use_dag=True)
            view=runtime.workspace.materialize("live")
            try: status,test_ms=run_pytest(view)
            finally: shutil.rmtree(view,ignore_errors=True)
        finally: runtime.close()
        queue.put({"condition":condition,"outcome":"known","tests_passed":status==0,"protected_unchanged":(root/"tests/test_safe.py").read_text()==protected,"execution_profile":result.get("execution_profile",{}).get("mode"),"verification_status":result.get("verification",{}).get("status"),"route_authority":calls[0]["model"] if calls else None,"provider_calls":len(calls),"provider_tokens":sum(row["tokens"] for row in calls),"provider_latency_ms":sum(row["duration_ms"] for row in calls),"provider_trace":calls,"test_ms":test_ms,"duration_ms":round((time.perf_counter()-started)*1000,3)})
    except Exception as exc:
        queue.put({"condition":condition,"outcome":"unknown","error_type":type(exc).__name__})
    finally:
        if old is None: os.environ.pop("CHIMERA_ENABLE_DETERMINISTIC_SCAFFOLDS", None)
        else: os.environ["CHIMERA_ENABLE_DETERMINISTIC_SCAFFOLDS"]=old
        shutil.rmtree(root,ignore_errors=True)


def run_one(condition: str, timeout: float) -> dict[str, Any]:
    ctx=mp.get_context("spawn"); queue=ctx.Queue(maxsize=1); process=ctx.Process(target=worker,args=(condition,queue)); process.start(); process.join(timeout)
    if process.is_alive():
        process.terminate(); process.join(10)
        return {"condition":condition,"outcome":"unknown","error_type":"condition_timeout","timeout_seconds":timeout}
    try: return queue.get(timeout=2)
    except Exception: return {"condition":condition,"outcome":"unknown","error_type":"worker_exited_without_receipt"}


def main() -> None:
    parser=argparse.ArgumentParser(); parser.add_argument("--timeout",type=float,default=180.0); parser.add_argument("--results",type=pathlib.Path,default=ROOT/"artifacts"/"rollback_feature_compare.json")
    args=parser.parse_args()
    if not os.environ.get("TOKENROUTER_API_KEY"):
        print(json.dumps({"outcome":"skipped","reason":"missing TOKENROUTER_API_KEY"})); return
    rows=[run_one("hardened",args.timeout),run_one("scaffold_opt_in",args.timeout)]
    result={"schema_version":"chimera.rollback-feature-compare/v1","model_requested":MODEL,"rows":rows}
    args.results.parent.mkdir(parents=True,exist_ok=True);args.results.write_text(json.dumps(result,sort_keys=True,indent=2,default=str));print(json.dumps(result,sort_keys=True,default=str))

if __name__=="__main__": main()
