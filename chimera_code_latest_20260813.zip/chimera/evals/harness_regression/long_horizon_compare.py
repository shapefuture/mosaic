#!/usr/bin/env python3
"""Crash-contained chained coding comparison inspired by verify_benchmark OMNI-LHB.

Each condition receives the same four sequential tasks, but only the next phase
and tests are revealed at each checkpoint.  The direct condition gets one raw
patch request per phase; Chimera gets its normal transactional coding runtime
per phase on the same branch.  Results are JSONL telemetry only: no credential,
raw prompt, model output, test output or temporary workspace is retained.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing as mp
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any

ROOT = pathlib.Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
MODEL = "moonshotai/kimi-k3-free"
# A fair direct-vs-harness comparison needs the same terminal output ceiling.
# Without one, an injected streaming provider can consume the entire condition
# budget in model prose before either patch gate runs.
MAX_OUTPUT_TOKENS = 1200

PHASES = (
    {
        "id": "normalize",
        "target": "chimera/normalise.py",
        "task": "Implement `chimera/normalise.py` with typed `normalize_code(value: str) -> str`. Trim surrounding whitespace, lowercase, replace every run of internal whitespace with one hyphen, and preserve punctuation. Do not modify supplied tests.",
        "test_path": "tests/test_normalise.py",
        "test": "from chimera.normalise import normalize_code\n\ndef test_normalize_code():\n    assert normalize_code('  Ada  Lovelace! ') == 'ada-lovelace!'\n    assert normalize_code('x\\t y') == 'x-y'\n",
    },
    {
        "id": "ledger",
        "target": "chimera/ledger.py",
        "task": "Implement `chimera/ledger.py` with typed `accumulate(rows: list[dict]) -> dict[str, int]`. Use `normalize_code` from `chimera.normalise`, ignore rows with missing/invalid integer qty, and sum quantities by normalized code. Do not modify supplied tests.",
        "test_path": "tests/test_ledger.py",
        "test": "from chimera.ledger import accumulate\n\ndef test_accumulate_uses_normalization_and_ignores_bad_rows():\n    rows=[{'code':' A ', 'qty':2},{'code':'a','qty':3},{'code':'b c','qty':'bad'},{'code':'b c','qty':1}]\n    assert accumulate(rows) == {'a':5, 'b-c':1}\n",
    },
    {
        "id": "report",
        "target": "chimera/report.py",
        "task": "Implement `chimera/report.py` with typed `summarize(rows: list[dict]) -> list[dict]`. Use `accumulate` from `chimera.ledger` and return dictionaries `{'code': code, 'qty': qty}` sorted by descending quantity then ascending code. Do not modify supplied tests.",
        "test_path": "tests/test_report.py",
        "test": "from chimera.report import summarize\n\ndef test_summarize_chain():\n    assert summarize([{'code':'B','qty':2},{'code':' a ','qty':2},{'code':'a','qty':1}]) == [{'code':'a','qty':3},{'code':'b','qty':2}]\n",
    },
    {
        "id": "service",
        "target": "chimera/service.py",
        "task": "Implement `chimera/service.py` with typed `build_payload(rows: list[dict]) -> dict`. Use `summarize` from `chimera.report` and return `{'count': number_of_items, 'items': summarized_items}`. Do not modify supplied tests.",
        "test_path": "tests/test_service.py",
        "test": "from chimera.service import build_payload\n\ndef test_build_payload_end_to_end():\n    assert build_payload([{'code':'A','qty':1},{'code':' a ','qty':2},{'code':'z','qty':0}]) == {'count':2,'items':[{'code':'a','qty':3},{'code':'z','qty':0}]}\n",
    },
)


def atomic_append(path: pathlib.Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
        handle.flush(); os.fsync(handle.fileno())


def sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_pytest(root: pathlib.Path) -> tuple[int, float]:
    started = time.perf_counter()
    result = subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=root, env={**os.environ, "PYTHONPATH": str(root)}, text=True, capture_output=True, timeout=120)
    return int(result.returncode), round((time.perf_counter() - started) * 1000, 3)


def parse_patch(text: str) -> dict[str, Any] | None:
    decoder = json.JSONDecoder()
    for index, char in enumerate(text):
        if char != "{": continue
        try:
            row, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict): return row
    return None


def seed(root: pathlib.Path) -> None:
    (root / "chimera").mkdir(); (root / "chimera" / "__init__.py").write_text("")
    (root / "tests").mkdir()


def add_phase_test(root: pathlib.Path, phase: dict[str, str]) -> None:
    path = root / phase["test_path"]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(phase["test"])


def direct_client(calls: list[dict[str, Any]]):
    from openai import OpenAI
    key = os.environ.get("TOKENROUTER_API_KEY")
    if not key: raise RuntimeError("missing TOKENROUTER_API_KEY")
    client = OpenAI(base_url="https://api.tokenrouter.com/v1", api_key=key, timeout=60.0)
    def invoke(prompt: str) -> tuple[str, int]:
        started = time.perf_counter(); parts=[]; usage={}
        for chunk in client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role":"system","content":"You are a precise coding agent. Return only a JSON patch; never disclose credentials."},
                {"role":"user","content":prompt},
            ], stream=True, stream_options={"include_usage":True}, max_tokens=MAX_OUTPUT_TOKENS, extra_body={},
        ):
            if chunk.choices and chunk.choices[0].finish_reason:
                usage["finish_reason"] = str(chunk.choices[0].finish_reason)
            if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content:
                parts.append(chunk.choices[0].delta.content)
            if getattr(chunk, "usage", None) is not None:
                value=chunk.usage; usage={"prompt":int(getattr(value,"prompt_tokens",0) or 0),"completion":int(getattr(value,"completion_tokens",0) or 0),"total":int(getattr(value,"total_tokens",0) or 0)}
        text="".join(parts); calls.append({"tokens":usage.get("total",0),"duration_ms":round((time.perf_counter()-started)*1000,3),"chars":len(text),"finish_reason":usage.get("finish_reason")})
        return text, usage.get("total", max(1,len(text)//4))
    return invoke


def direct_condition() -> dict[str, Any]:
    root=pathlib.Path(tempfile.mkdtemp(prefix="chimera-long-direct-")); calls=[]; phase_rows=[]
    started=time.perf_counter()
    try:
        seed(root)
        for phase in PHASES:
            add_phase_test(root, phase)
            protected={path:sha(path) for path in (root/"tests").glob("test_*.py")}
            sources={str(path.relative_to(root)):path.read_text() for path in sorted((root/"chimera").glob("*.py"))}
            tests={str(path.relative_to(root)):path.read_text() for path in sorted((root/"tests").glob("test_*.py"))}
            prompt=(
                "Return exactly one JSON object, no prose: {\"f\":{target_path:\"complete source\"}}. "
                f"Only write {phase['target']}; do not modify tests.\nTASK:\n{phase['task']}\n"
                f"CURRENT CODE:\n{json.dumps(sources,sort_keys=True)}\nCURRENT TESTS:\n{json.dumps(tests,sort_keys=True)}"
            )
            text, tokens=direct_client(calls)(prompt)
            patch=parse_patch(text); applied=False
            if isinstance(patch, dict) and isinstance(patch.get("f"), dict) and set(patch["f"]) == {phase["target"]} and isinstance(patch["f"].get(phase["target"]),str):
                target=root/phase["target"]; target.parent.mkdir(parents=True,exist_ok=True); target.write_text(patch["f"][phase["target"]]); applied=True
            status, test_ms = run_pytest(root) if applied else (125, 0.0)
            protected_ok=all(sha(path)==digest for path,digest in protected.items())
            phase_rows.append({"phase":phase["id"],"target":phase["target"],"applied":applied,"status":status,"protected_unchanged":protected_ok,"tokens":tokens,"test_ms":test_ms,"finish_reason":calls[-1].get("finish_reason") if calls else None})
            if status != 0 or not protected_ok: break
        return {"condition":"direct","outcome":"known","phases":phase_rows,"provider_calls":len(calls),"provider_tokens":sum(row["tokens"] for row in calls),"provider_latency_ms":sum(row["duration_ms"] for row in calls),"provider_trace":calls,"duration_ms":round((time.perf_counter()-started)*1000,3),"completed":len(phase_rows)==len(PHASES) and all(row["status"]==0 and row["protected_unchanged"] for row in phase_rows)}
    finally: shutil.rmtree(root,ignore_errors=True)


def chimera_condition() -> dict[str, Any]:
    from chimera.config import ChimeraConfig
    from chimera.rlm import RLMRuntime
    root=pathlib.Path(tempfile.mkdtemp(prefix="chimera-long-runtime-")); calls=[]; phase_rows=[]
    started=time.perf_counter()
    try:
        seed(root)
        def provider(prompt: str, model: str) -> dict[str, Any]:
            text,tokens=direct_client(calls)(prompt)
            return {"answer":text,"tokens":tokens,"model":model,"provider":"tokenrouter-openai-compatible","real_call":True,"usage":{"total_tokens":tokens}}
        runtime=RLMRuntime(root,config=ChimeraConfig(),model_provider=provider,injected_provider_mode="external")
        try:
            for phase in PHASES:
                add_phase_test(root, phase)
                protected={path:sha(path) for path in (root/"tests").glob("test_*.py")}
                before=len(calls)
                result=runtime.rlm(phase["task"],branch="long",model=MODEL,use_dag=True)
                view=runtime.workspace.materialize("long")
                try: status,test_ms=run_pytest(view)
                finally: shutil.rmtree(view,ignore_errors=True)
                protected_ok=all(sha(path)==digest for path,digest in protected.items())
                trace_rows = result.get("traces", []) if isinstance(result.get("traces"), list) else []
                trace_counts: dict[str, int] = {}
                for item in trace_rows:
                    if isinstance(item, dict):
                        kind = str(item.get("kind", "unknown"))
                        trace_counts[kind] = trace_counts.get(kind, 0) + 1
                phase_rows.append({"phase":phase["id"],"target":phase["target"],"status":status,"protected_unchanged":protected_ok,"execution_profile":result.get("execution_profile",{}).get("mode"),"verification_status":result.get("verification",{}).get("status"),"provider_calls":len(calls)-before,"tokens":sum(row["tokens"] for row in calls[before:]),"test_ms":test_ms,"dependency_barrier":result.get("verification",{}).get("hierarchical_gate"),"changed_paths":[str(op.get("path")) for op in result.get("diff",{}).get("ops",[]) if isinstance(op,dict) and op.get("path")],"trace_event_counts":trace_counts})
                if status != 0 or not protected_ok: break
        finally: runtime.close()
        return {"condition":"chimera","outcome":"known","phases":phase_rows,"provider_calls":len(calls),"provider_tokens":sum(row["tokens"] for row in calls),"provider_latency_ms":sum(row["duration_ms"] for row in calls),"provider_trace":calls,"duration_ms":round((time.perf_counter()-started)*1000,3),"completed":len(phase_rows)==len(PHASES) and all(row["status"]==0 and row["protected_unchanged"] for row in phase_rows)}
    finally: shutil.rmtree(root,ignore_errors=True)


def worker(condition: str, queue) -> None:
    try:
        row = direct_condition() if condition == "direct" else chimera_condition()
    except Exception as exc:
        row={"condition":condition,"outcome":"unknown","error_type":type(exc).__name__,"completed":False}
    queue.put(row)


def run_one(condition: str, timeout_seconds: float) -> dict[str, Any]:
    context=mp.get_context("spawn"); queue=context.Queue(maxsize=1); process=context.Process(target=worker,args=(condition,queue)); process.start(); process.join(timeout_seconds)
    if process.is_alive():
        process.terminate(); process.join(10)
        return {"condition":condition,"outcome":"unknown","error_type":"condition_timeout","completed":False,"timeout_seconds":timeout_seconds}
    try: return queue.get(timeout=2)
    except Exception: return {"condition":condition,"outcome":"unknown","error_type":"worker_exited_without_receipt","completed":False}


def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument("--timeout",type=float,default=360.0)
    parser.add_argument("--condition",choices=["both","direct","chimera"],default="both")
    parser.add_argument("--results",type=pathlib.Path,default=ROOT/"artifacts"/"long_horizon_compare.json")
    args=parser.parse_args()
    if not os.environ.get("TOKENROUTER_API_KEY"):
        print(json.dumps({"outcome":"skipped","reason":"missing TOKENROUTER_API_KEY"})); return
    conditions=["direct","chimera"] if args.condition=="both" else [args.condition]
    rows=[run_one(condition,args.timeout) for condition in conditions]
    result={"schema_version":"chimera.long-horizon-compare/v1","model_requested":MODEL,"phase_count":len(PHASES),"requested_condition":args.condition,"rows":rows}
    args.results.parent.mkdir(parents=True,exist_ok=True); args.results.write_text(json.dumps(result,sort_keys=True,indent=2,default=str))
    print(json.dumps(result,sort_keys=True,default=str))

if __name__=="__main__": main()
