#!/usr/bin/env python3
"""Pinned single-node Restate service, serializer, and restart campaign."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
import uuid
from dataclasses import asdict

from chimera.restate_durable_workflow import (
    RestateAdapterConfig,
    RestateDurableWorkflowPort,
)


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1_048_576), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def wait_port(port: int, process: subprocess.Popen, timeout: float = 30.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(f"process exited before port {port} became ready")
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                return
        except OSError:
            time.sleep(0.1)
    raise TimeoutError(f"port {port} did not become ready")


def request_json(url: str, value: dict | None = None) -> dict:
    body = None if value is None else json.dumps(value).encode()
    request = urllib.request.Request(
        url,
        data=body,
        headers={"content-type": "application/json"} if body is not None else {},
        method="POST" if body is not None else "GET",
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        parsed = json.load(response)
    if not isinstance(parsed, dict):
        raise TypeError("Restate admin API returned a non-object")
    return parsed


def stop(process: subprocess.Popen | None) -> None:
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=20)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--server-binary", type=pathlib.Path, required=True)
    parser.add_argument("--results", type=pathlib.Path, required=True)
    args = parser.parse_args()
    binary = args.server_binary.resolve()
    if not binary.is_file():
        raise FileNotFoundError(binary)
    version = subprocess.check_output([str(binary), "--version"], text=True).strip()
    if version != "restate-server 1.7.3":
        raise RuntimeError(f"expected pinned Restate 1.7.3, observed {version}")

    root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-restate-local-"))
    data = root / "server"
    service_log = (root / "service.log").open("wb")
    server_log = (root / "server.log").open("ab")
    service: subprocess.Popen | None = None
    server: subprocess.Popen | None = None
    try:
        service = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "evals.deployment.restate_fixture_service:app",
                "--host",
                "127.0.0.1",
                "--port",
                "9080",
            ],
            cwd=pathlib.Path(__file__).resolve().parents[2],
            stdout=service_log,
            stderr=subprocess.STDOUT,
        )
        wait_port(9080, service)

        def start_server() -> subprocess.Popen:
            data.mkdir(exist_ok=True)
            process = subprocess.Popen(
                [
                    str(binary),
                    "--no-logo",
                    "--listen-mode",
                    "tcp",
                    "--bind-ip",
                    "127.0.0.1",
                ],
                cwd=data,
                stdout=server_log,
                stderr=subprocess.STDOUT,
            )
            wait_port(9070, process, timeout=60)
            wait_port(8080, process, timeout=60)
            return process

        server = start_server()
        registration = request_json(
            "http://127.0.0.1:9070/deployments",
            {"uri": "http://127.0.0.1:9080", "use_http_11": True},
        )
        services = {row["name"]: row for row in registration.get("services", [])}
        registry = services.get("ChimeraDurableRegistry", {})
        registry_handlers = {row["name"]: row for row in registry.get("handlers", [])}
        known = registry_handlers.get("known_workflows", {})
        list_serializer_declared = (
            known.get("ty") == "Shared"
            and known.get("output_json_schema", {}).get("type") == "array"
            and known.get("output_json_schema", {}).get("items", {}).get("type")
            == "string"
        )

        ingress = "http://127.0.0.1:8080"
        environment = {**os.environ, "CHIMERA_RESTATE_INGRESS": ingress}
        tests = subprocess.run(
            [
                sys.executable,
                "-m",
                "pytest",
                "-q",
                "tests/test_restate_durable_adapter.py",
            ],
            cwd=pathlib.Path(__file__).resolve().parents[2],
            env=environment,
            capture_output=True,
            text=True,
            timeout=180,
            check=False,
        )
        if tests.returncode != 0:
            raise RuntimeError(
                "Restate adapter tests failed: " + tests.stdout + tests.stderr
            )

        tenant = "tenant:" + "d" * 64
        identifier = "workflow:restart:" + uuid.uuid4().hex
        adapter_root = root / "adapter"
        adapter = RestateDurableWorkflowPort(
            adapter_root,
            RestateAdapterConfig(ingress_url=ingress),
        )
        workflow = adapter.start(
            workflow_type="restart-campaign",
            input_identity="sha256:input-v1",
            workflow_id=identifier,
            tenant_key=tenant,
        )
        checkpoint = adapter.checkpoint(
            workflow,
            {"phase": "before-restart"},
            idempotency_key="campaign-checkpoint-v1",
            tenant_key=tenant,
        )
        stop(server)
        server = start_server()
        recovered = adapter.recover(identifier, tenant_key=tenant)
        if recovered is None:
            raise RuntimeError("workflow was unavailable after Restate restart")
        terminal = adapter.finish(
            recovered,
            state="completed",
            idempotency_key="campaign-finish-v1",
            tenant_key=tenant,
        )
        incomplete = adapter.recover_incomplete(tenant_key=tenant)
        evidence = {
            "schema_version": "chimera.restate-local-campaign.v1",
            "server_version": version,
            "server_binary_digest": sha256(binary),
            "sdk_version": "1.0.3",
            "service": "ChimeraDurableObject",
            "observed": {
                "deployment_registered": set(services)
                == {"ChimeraDurableObject", "ChimeraDurableRegistry"},
                "shared_handler_registered": known.get("ty") == "Shared",
                "list_serializer_registered": list_serializer_declared,
                "adapter_law_tests_passed": "2 passed" in tests.stdout,
                "checkpoint_created": bool(checkpoint.checkpoint_ref),
                "server_restart_preserved_checkpoint": recovered.checkpoint_ref
                == checkpoint.checkpoint_ref,
                "terminal_continuation_after_restart": terminal.state == "completed",
                "known_workflows_list_serializer_invoked": incomplete == (),
            },
            "automatic_enablement": False,
            "manual_promotion_required": True,
            "limits": [
                "Disposable single-node Restate server and local ASGI service.",
                "No clustered Restate failover or physical multi-host behavior was exercised.",
                "No external provider or irreversible effect was invoked.",
            ],
            "restart_receipt": {
                "before": asdict(checkpoint),
                "after": asdict(recovered),
                "terminal": asdict(terminal),
            },
        }
        evidence["all_passed"] = all(evidence["observed"].values())
        args.results.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.results.with_suffix(".tmp")
        temporary.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n")
        os.replace(temporary, args.results)
        print(json.dumps(evidence, sort_keys=True))
        return 0 if evidence["all_passed"] else 1
    finally:
        stop(server)
        stop(service)
        service_log.close()
        server_log.close()
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
