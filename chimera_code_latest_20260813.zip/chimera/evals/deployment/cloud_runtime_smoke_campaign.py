#!/usr/bin/env python3
"""Transient cloud-runtime smoke campaign.

Starts disposable local PostgreSQL and pinned Restate endpoints, sets the same
environment variables that a self-hosted cloud deployment would provide, and
verifies Chimera's cloud-runtime doctor gate plus minimal cloud-state I/O.
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import socket
import subprocess
import tempfile

from chimera.cloud_state import PostgresCloudStateAdapter
from evals.deployment.restate_test_harness import RestateTestHarness


def postgres_bin() -> pathlib.Path:
    for path in sorted(pathlib.Path("/usr/lib/postgresql").glob("*/bin"), reverse=True):
        if (path / "postgres").exists():
            return path
    raise RuntimeError("PostgreSQL server binaries are unavailable")


def free_port() -> int:
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        return int(listener.getsockname()[1])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    args = parser.parse_args()
    repo = pathlib.Path(__file__).resolve().parents[2]
    root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-cloud-runtime-smoke-"))
    data = root / "pgdata"
    sockets = root / "sock"
    sockets.mkdir()
    port = free_port()
    pg = postgres_bin()
    restate: RestateTestHarness | None = None
    adapter: PostgresCloudStateAdapter | None = None
    started = False
    try:
        subprocess.run([
            str(pg / "initdb"), "-D", str(data), "--no-locale", "--encoding=UTF8", "--auth=trust",
        ], check=True, stdout=subprocess.DEVNULL, timeout=60)
        subprocess.run([
            str(pg / "pg_ctl"), "-D", str(data), "-l", str(root / "postgres.log"),
            "-o", f"-h 127.0.0.1 -k {sockets} -p {port} -F", "-w", "start",
        ], check=True, stdout=subprocess.DEVNULL, timeout=60)
        started = True
        postgres_url = f"postgresql+psycopg://user@127.0.0.1:{port}/postgres"
        adapter = PostgresCloudStateAdapter(postgres_url, enable_rls=True)
        tenant = "7" * 64
        event_id = adapter.append_event(tenant_key=tenant, kind="cloud-runtime-smoke", data={"ok": True})
        replay = adapter.replay_events(tenant_key=tenant)
        outbox_id = adapter.enqueue_outbox(tenant_key=tenant, kind="smoke", payload={"event_id": event_id})
        claimed = adapter.claim_outbox(tenant_key=tenant)
        adapter.finish_outbox(outbox_id, tenant_key=tenant)

        restate = RestateTestHarness()
        restate_ingress = restate.start()
        env = {
            **os.environ,
            "PYTHONPATH": str(repo),
            "CHIMERA_POSTGRES_URL": postgres_url,
            "CHIMERA_RESTATE_INGRESS": restate_ingress,
        }
        doctor = subprocess.run(
            ["python", "-m", "chimera.cli", "doctor", "--profile", "cloud-runtime", "--fail-on-blockers", "--json"],
            cwd=repo,
            env=env,
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )
        doctor_json = json.loads(doctor.stdout) if doctor.stdout.strip() else {}
        evidence = {
            "schema_version": "chimera.cloud-runtime-smoke-campaign.v1",
            "postgres_version": subprocess.check_output([str(pg / "postgres"), "--version"], text=True, timeout=10).strip(),
            "restate_ingress_configured": restate_ingress.startswith("http://127.0.0.1:"),
            "doctor_exit_code": doctor.returncode,
            "doctor_certified": bool(doctor_json.get("certified")),
            "doctor_blockers": doctor_json.get("blockers", []),
            "postgres_event_replayed": bool(replay and replay[-1].get("data") == {"ok": True}),
            "postgres_outbox_claimed": bool(claimed and claimed[0].id == outbox_id),
            "endpoint_values_recorded": False,
            "cloud_runtime_env_names": ["CHIMERA_POSTGRES_URL", "CHIMERA_RESTATE_INGRESS"],
            "local_option_preserved": True,
            "limits": [
                "Disposable local PostgreSQL and single-node Restate endpoints, not managed-cloud multi-host evidence.",
                "This proves cloud-runtime wiring and doctor gating with endpoint env vars, not production SLOs.",
                "Endpoint values are intentionally not recorded in the artifact.",
            ],
        }
        required = [
            "restate_ingress_configured",
            "doctor_certified",
            "postgres_event_replayed",
            "postgres_outbox_claimed",
            "local_option_preserved",
        ]
        evidence["all_passed"] = all(bool(evidence[key]) for key in required) and doctor.returncode == 0
        args.results.parent.mkdir(parents=True, exist_ok=True)
        tmp = args.results.with_suffix(".tmp")
        tmp.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, args.results)
        print(json.dumps(evidence, sort_keys=True))
        return 0 if evidence["all_passed"] else 1
    finally:
        if adapter is not None:
            adapter.close()
        if restate is not None:
            restate.close()
        if started:
            subprocess.run([str(pg / "pg_ctl"), "-D", str(data), "-m", "immediate", "stop"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False, timeout=30)
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
