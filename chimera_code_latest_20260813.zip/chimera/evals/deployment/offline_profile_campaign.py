#!/usr/bin/env python3
"""Run the offline profile in a loopback-only Linux network namespace."""

from __future__ import annotations

import argparse
import json
import os
import pathlib
import subprocess
import sys
import uuid

ROOT = pathlib.Path(__file__).resolve().parents[2]
WORKER = ROOT / "evals/deployment/offline_profile_worker.py"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    args = parser.parse_args()
    namespace = "chimera-offline-" + uuid.uuid4().hex[:8]
    try:
        subprocess.run(
            ["sudo", "-n", "ip", "netns", "add", namespace],
            check=True,
            timeout=10,
        )
        subprocess.run(
            [
                "sudo",
                "-n",
                "ip",
                "netns",
                "exec",
                namespace,
                "ip",
                "link",
                "set",
                "lo",
                "up",
            ],
            check=True,
            timeout=10,
        )
        result = subprocess.run(
            [
                "sudo",
                "-n",
                "ip",
                "netns",
                "exec",
                namespace,
                "env",
                f"PYTHONPATH={ROOT}",
                sys.executable,
                str(WORKER),
            ],
            text=True,
            capture_output=True,
            timeout=60,
            check=False,
        )
        if result.returncode:
            raise RuntimeError(
                f"offline worker failed: stdout={result.stdout[-2000:]} stderr={result.stderr[-4000:]}"
            )
        evidence = json.loads(result.stdout.splitlines()[-1])
        evidence.update(
            {
                "network_namespace": namespace,
                "same_physical_kernel": True,
                "physical_hosts": 1,
                "limits": [
                    "Loopback-only Linux network namespace on one physical host/kernel.",
                    "Local inference endpoint is a protocol fixture, not a model-quality benchmark.",
                ],
            }
        )
        args.results.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.results.with_suffix(".tmp")
        temporary.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n")
        os.replace(temporary, args.results)
        print(json.dumps(evidence, sort_keys=True))
        return 0
    finally:
        subprocess.run(
            ["sudo", "-n", "ip", "netns", "del", namespace],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10,
            check=False,
        )


if __name__ == "__main__":
    raise SystemExit(main())
