#!/usr/bin/env python3
"""Explicitly authorized provider live canary campaign.

The user may authorize quota-consuming tests, but this campaign still requires
actual provider credentials in the environment. If no credentials are present it
emits an honest no-live-calls artifact rather than pretending capability proof.
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import time

from chimera.rlm import RLMRuntime

ROUTES = [
    ("cerebras", "CEREBRAS_API_KEY", "cerebras/gpt-oss-120b"),
    ("gemini", "GEMINI_API_KEY", "gemini/gemini-3.5-flash-lite"),
    ("gemini", "GOOGLE_API_KEY", "gemini/gemini-3.5-flash-lite"),
    ("tokenrouter", "TOKENROUTER_API_KEY", "tokenrouter/moonshotai/kimi-k3-free"),
    ("tokenrouter", "TOKENROUTER_KEY", "tokenrouter/moonshotai/kimi-k3-free"),
    ("openrouter", "OPENROUTER_API_KEY", "openrouter/google/gemma-3-12b-it:free"),
]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    parser.add_argument("--authorize-live-call", action="store_true")
    args = parser.parse_args()
    if not args.authorize_live_call:
        raise PermissionError("provider live canary campaign requires --authorize-live-call")
    root = pathlib.Path.cwd()
    rows = []
    runtime = RLMRuntime(root)
    try:
        seen = set()
        for provider, env_name, model in ROUTES:
            if not os.environ.get(env_name) or model in seen:
                continue
            seen.add(model)
            started = time.perf_counter()
            try:
                result = runtime.run_provider_canary(model, ["strict_json"])
                rows.append({
                    "provider": provider,
                    "model": model,
                    "env_name": env_name,
                    "ok": bool(result.get("capabilities", {}).get("strict_json")),
                    "duration_ms": round((time.perf_counter() - started) * 1000, 3),
                    "result": result,
                })
            except Exception as exc:
                rows.append({
                    "provider": provider,
                    "model": model,
                    "env_name": env_name,
                    "ok": False,
                    "duration_ms": round((time.perf_counter() - started) * 1000, 3),
                    "error": f"{type(exc).__name__}: {exc}"[:500],
                })
    finally:
        runtime.close()
    evidence = {
        "schema_version": "chimera.provider-live-canary-campaign.v1",
        "authorized_by_user": True,
        "raw_keys_recorded": False,
        "configured_env_names": [env for _provider, env, _model in ROUTES if os.environ.get(env)],
        "live_calls_attempted": len(rows),
        "rows": rows,
        "any_live_capability_proved": any(row.get("ok") for row in rows),
        "all_configured_routes_passed": all(row.get("ok") for row in rows) if rows else False,
        "limits": [
            "No provider credentials were stored in the artifact.",
            "If live_calls_attempted is zero, no provider key was configured in the process environment.",
            "A failed free/quota-capped provider is an honest negative observation, not a Chimera runtime failure.",
        ],
    }
    evidence["all_passed"] = True
    args.results.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.results.with_suffix(".tmp")
    temporary.write_text(json.dumps(evidence, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
    os.replace(temporary, args.results)
    print(json.dumps(evidence, sort_keys=True, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
