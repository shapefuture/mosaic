#!/usr/bin/env python3
"""Inside-netns worker proving local inference while external egress is absent."""

from __future__ import annotations

import json
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from chimera.bootstrap import ProfileEgressPolicy, profile_policy
from chimera.config import DeploymentProfile
from chimera.provider_adapters import (
    EnvironmentSecretPort,
    OpenAICompatibleAdapter,
)
from chimera.runtime_ports import CompletionOutcome, CompletionRequest


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers.get("content-length", "0"))
        self.rfile.read(length)
        body = json.dumps(
            {
                "choices": [{"message": {"content": "offline-local-ok"}}],
                "usage": {
                    "prompt_tokens": 2,
                    "completion_tokens": 2,
                    "total_tokens": 4,
                },
            }
        ).encode()
        self.send_response(200)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_):
        return


def main() -> int:
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    port = server.server_address[1]
    policy = ProfileEgressPolicy(
        profile_policy(DeploymentProfile.LOCAL_OFFLINE),
        offline_loopback_ports={port},
    )
    adapter = OpenAICompatibleAdapter(
        adapter_id="offline-local-fixture",
        local=True,
        base_url=f"http://127.0.0.1:{port}/v1",
        egress=policy,
        secrets=EnvironmentSecretPort(),
        secret_name=None,
    )
    try:
        result = adapter.complete(
            CompletionRequest(
                "offline",
                "local/fixture",
                request_id="request:offline",
                deadline_unix_ms=9_999_999_999_999,
            )
        )
        external_denied = False
        try:
            socket.create_connection(("1.1.1.1", 53), timeout=0.5)
        except OSError:
            external_denied = True
        output = {
            "schema_version": "chimera.offline-profile-netns.v1",
            "local_inference": result.outcome is CompletionOutcome.SUCCEEDED,
            "local_answer": result.answer,
            "external_socket_denied": external_denied,
            "profile_policy_offline": policy.policy.offline,
            "automatic_enablement": False,
        }
        output["all_passed"] = all(
            (
                output["local_inference"],
                output["external_socket_denied"],
                output["profile_policy_offline"],
            )
        )
        print(json.dumps(output, sort_keys=True))
        return 0 if output["all_passed"] else 1
    finally:
        adapter.close()
        server.shutdown()
        server.server_close()


if __name__ == "__main__":
    raise SystemExit(main())
