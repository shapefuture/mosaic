#!/usr/bin/env python3
"""Bounded durability/deployment compatibility matrix for Chimera.

The matrix uses only disposable local state: temporary directories, an ephemeral
PostgreSQL cluster, DBOS, and local fake receivers. It makes no provider,
Restate, cloud, or tenant-transport calls. A fake receiver is used solely to
show why a stable idempotency key is necessary across a crash; it does *not*
prove a real provider's effect or billing semantics.

Rows are evidence records, not deployment certification. In particular, a
passing row never enables DBOS, queues, retry, external delivery, or model
routing by default.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import contextlib
import json
import os
import pathlib
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
from typing import Any, Iterator


ROOT = pathlib.Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _row(
    identifier: str,
    *,
    status: str,
    capability_proven: bool,
    scope: str,
    acceptance: str,
    kill_criterion: str,
    observed: dict[str, Any],
    limits: str,
) -> dict[str, Any]:
    return {
        "id": identifier,
        "status": status,
        "capability_proven": capability_proven,
        "scope": scope,
        "acceptance": acceptance,
        "kill_criterion": kill_criterion,
        "observed": observed,
        "limits": limits,
    }


def _pg_bin() -> pathlib.Path:
    configured = os.environ.get("CHIMERA_POSTGRES_BIN")
    candidates = [pathlib.Path(configured)] if configured else []
    candidates.extend(sorted(pathlib.Path("/usr/lib/postgresql").glob("*/bin"), reverse=True))
    for candidate in candidates:
        if (candidate / "initdb").is_file() and (candidate / "pg_ctl").is_file():
            return candidate
    raise RuntimeError("PostgreSQL initdb/pg_ctl binaries are unavailable")


def _free_port() -> int:
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        listener.bind(("127.0.0.1", 0))
        return int(listener.getsockname()[1])
    finally:
        listener.close()


@contextlib.contextmanager
def _ephemeral_postgres() -> Iterator[str]:
    """Start a current-user-owned transient Postgres cluster and erase it."""
    pg_bin = _pg_bin()
    root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-compat-pg-"))
    data = root / "data"
    sock = root / "sock"
    sock.mkdir()
    port = _free_port()
    started = False
    try:
        subprocess.run(
            [str(pg_bin / "initdb"), "-D", str(data), "--no-locale", "--encoding=UTF8", "--auth=trust"],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        subprocess.run(
            [str(pg_bin / "pg_ctl"), "-D", str(data), "-o", f"-k {sock} -p {port} -F", "-w", "start"],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        started = True
        yield f"postgresql+psycopg://user@/postgres?host={sock}&port={port}"
    finally:
        if started:
            subprocess.run(
                [str(pg_bin / "pg_ctl"), "-D", str(data), "-m", "immediate", "stop"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        shutil.rmtree(root, ignore_errors=True)


def _parse_last_json(text: str) -> dict[str, Any] | None:
    value: dict[str, Any] | None = None
    for line in text.splitlines():
        try:
            decoded = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(decoded, dict):
            value = decoded
    return value


def _append_attempt(path: pathlib.Path, label: str) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(label + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def _idempotent_fake_receiver(path: pathlib.Path, *, key: str, kind: str) -> dict[str, Any]:
    """A local receiver with an explicit endpoint-owned idempotency register."""
    if path.exists():
        state = json.loads(path.read_text(encoding="utf-8"))
    else:
        state = {"keys": [], "physical_effects": 0}
    keys = set(str(item) for item in state.get("keys", []))
    duplicate = key in keys
    if not duplicate:
        keys.add(key)
        state["keys"] = sorted(keys)
        state["physical_effects"] = int(state.get("physical_effects", 0)) + 1
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(state, sort_keys=True), encoding="utf-8")
        os.replace(temporary, path)
    return {
        "receiver": "local-idempotent-fake",
        "kind": kind,
        "idempotency_key_seen": key,
        "duplicate": duplicate,
        "physical_effects": int(state.get("physical_effects", 0)),
    }


def _dbos_recovery_worker(database_url: str, marker: pathlib.Path, receiver: pathlib.Path, kind: str) -> int:
    """Worker intentionally killed after a boundary step to force DBOS recovery."""
    from dbos import DBOS, SetWorkflowID

    attempt_path = receiver.with_suffix(".attempts")
    workflow_id = f"chimera-compat-{kind}-recovery-v1"
    DBOS(config={
        "name": "chimera_compat_recovery",
        "application_version": "chimera-compat-recovery-v1",
        "system_database_url": database_url,
    })

    @DBOS.step(retries_allowed=False)
    def checkpoint(value: int) -> int:
        _append_attempt(attempt_path, "checkpoint")
        return value + 1

    @DBOS.step(retries_allowed=False)
    def boundary() -> int:
        _append_attempt(attempt_path, "boundary")
        if kind in {"external-effect", "provider-call"}:
            _idempotent_fake_receiver(
                receiver,
                key=f"chimera-compat-{kind}-idempotency-v1",
                kind=kind,
            )
        # The receiver has accepted the effect but DBOS has not recorded a
        # completed step. This is the ambiguity a real effect adapter must
        # reconcile using its own idempotency contract.
        if marker.exists():
            os._exit(87)
        return 1

    @DBOS.workflow()
    def workflow(value: int) -> int:
        return checkpoint(value) + boundary()

    try:
        DBOS.launch()
        with SetWorkflowID(workflow_id):
            result = workflow(4)
        attempts = attempt_path.read_text(encoding="utf-8").splitlines() if attempt_path.exists() else []
        receiver_state = json.loads(receiver.read_text(encoding="utf-8")) if receiver.exists() else None
        print(json.dumps({"result": result, "attempts": attempts, "receiver": receiver_state}, sort_keys=True), flush=True)
        return 0
    finally:
        # This does not run in the deliberate os._exit process, which is the
        # point of the probe. The recovery process shuts down cleanly.
        DBOS.destroy(destroy_registry=True)


def _run_dbos_recovery(database_url: str, kind: str) -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix=f"chimera-{kind}-recovery-") as raw:
        root = pathlib.Path(raw)
        marker = root / "crash-after-boundary"
        receiver = root / "receiver.json"
        marker.write_text("crash", encoding="utf-8")
        command = [
            sys.executable, str(pathlib.Path(__file__).resolve()), "--dbos-recovery-worker",
            "--database-url", database_url, "--marker", str(marker), "--receiver", str(receiver), "--kind", kind,
        ]
        env = {**os.environ, "PYTHONPATH": str(ROOT) + os.pathsep + os.environ.get("PYTHONPATH", "")}
        first = subprocess.run(command, cwd=ROOT, env=env, text=True, capture_output=True, timeout=60)
        marker.unlink()
        second = subprocess.run(command, cwd=ROOT, env=env, text=True, capture_output=True, timeout=60)
        payload = _parse_last_json(second.stdout) or {}
        attempts = payload.get("attempts") if isinstance(payload.get("attempts"), list) else []
        receiver_state = payload.get("receiver") if isinstance(payload.get("receiver"), dict) else {}
        accepted = (
            first.returncode == 87
            and second.returncode == 0
            and payload.get("result") == 6
            and attempts.count("checkpoint") == 1
            and attempts.count("boundary") == 2
        )
        return {
            "accepted": accepted,
            "first_exit_code": first.returncode,
            "recovery_exit_code": second.returncode,
            "checkpoint_attempts": attempts.count("checkpoint"),
            "boundary_attempts": attempts.count("boundary"),
            "receiver_physical_effects": receiver_state.get("physical_effects"),
            "receiver_idempotency_keys": len(receiver_state.get("keys", [])) if isinstance(receiver_state.get("keys"), list) else 0,
            "recovery_error_type": None if second.returncode == 0 else "DBOSRecoveryWorkerFailed",
        }


def _local_crash_recovery() -> dict[str, Any]:
    from chimera.durable_workflow import LocalDurableWorkflowPort

    with tempfile.TemporaryDirectory(prefix="chimera-local-recovery-") as raw:
        root = pathlib.Path(raw)
        child = (
            "import os, pathlib; "
            "from chimera.durable_workflow import LocalDurableWorkflowPort; "
            f"port=LocalDurableWorkflowPort(pathlib.Path({str(root)!r})); "
            "workflow=port.start(workflow_type='compatibility', input_identity='local-crash-v1'); "
            "port.checkpoint(workflow, {'phase':'durably-checkpointed'}); os._exit(73)"
        )
        env = {**os.environ, "PYTHONPATH": str(ROOT) + os.pathsep + os.environ.get("PYTHONPATH", "")}
        process = subprocess.run([sys.executable, "-c", child], cwd=ROOT, env=env, timeout=30)
        recovered = LocalDurableWorkflowPort(root).recover_incomplete()
        accepted = process.returncode == 73 and len(recovered) == 1 and recovered[0].checkpoint_ref is not None
        observed = {
            "abrupt_child_exit_code": process.returncode,
            "recovered_incomplete_workflows": len(recovered),
            "checkpoint_reference_verified": bool(recovered and recovered[0].checkpoint_ref),
        }
    return _row(
        "local-crash-recovery",
        status="passed" if accepted else "failed",
        capability_proven=accepted,
        scope="Local WAL/CAS only: process exit after a checkpoint and explicit read-only recovery reconstruction.",
        acceptance="A hard-exited child leaves exactly one verified running workflow with a verified CAS checkpoint.",
        kill_criterion="Missing/corrupt WAL or CAS data, more than one recovered record, or automatic replay during recovery.",
        observed=observed,
        limits="No external effect, queue worker, or automatic continuation is exercised or enabled.",
    )


def _local_idempotency_probe(*, effect_kind: str) -> dict[str, Any]:
    from chimera.effect_outbox import EffectDispatchController, EffectOutcome, OutboxInboxLedger

    with tempfile.TemporaryDirectory(prefix="chimera-idempotency-") as raw:
        root = pathlib.Path(raw)
        ledger = OutboxInboxLedger(root)
        controller = EffectDispatchController(ledger)
        receiver = root / "receiver.json"
        attempts = 0

        def ambiguous_send(key: str) -> dict[str, Any]:
            nonlocal attempts
            attempts += 1
            _idempotent_fake_receiver(receiver, key=key, kind=effect_kind)
            if attempts == 1:
                raise ConnectionError("local transport loss after receiver acceptance")
            return _idempotent_fake_receiver(receiver, key=key, kind=effect_kind)

        key = f"chimera-{effect_kind}-idempotency-v1"
        first = controller.dispatch(
            effect_kind=effect_kind,
            payload={"operation": "compatibility"},
            idempotent=True,
            idempotency_key=key,
            send=ambiguous_send,
        )
        # This is an explicit evaluator-controlled reconciliation attempt, not
        # an automatic dispatcher retry.
        second = controller.dispatch(
            effect_kind=effect_kind,
            payload={"operation": "compatibility"},
            idempotent=True,
            idempotency_key=key,
            send=ambiguous_send,
        )
        receiver_state = json.loads(receiver.read_text(encoding="utf-8"))
        non_idempotent = ledger.enqueue(effect_kind=effect_kind, payload={"operation": "unsafe"}, idempotent=False)
        accepted = (
            first.outcome is EffectOutcome.UNKNOWN
            and first.reconciliation_required
            and second.outcome is EffectOutcome.SUCCEEDED
            and int(receiver_state["physical_effects"]) == 1
            and not ledger.retry_allowed(non_idempotent, EffectOutcome.UNKNOWN)
        )
        observed = {
            "first_local_outcome": first.outcome.value,
            "first_reconciliation_required": first.reconciliation_required,
            "manual_second_outcome": second.outcome.value,
            "fake_receiver_physical_effects": int(receiver_state["physical_effects"]),
            "same_idempotency_key": first.intent.idempotency_key == second.intent.idempotency_key == key,
            "non_idempotent_unknown_retry_allowed": ledger.retry_allowed(non_idempotent, EffectOutcome.UNKNOWN),
        }
    return _row(
        "local-external-effect-idempotency" if effect_kind == "external.effect" else "provider-call-recovery-policy",
        status="passed-local-simulation" if accepted else "failed",
        capability_proven=False,
        scope=(
            "Local outbox/inbox plus a local idempotent fake external receiver."
            if effect_kind == "external.effect" else
            "Local outbox policy plus a fake provider receiver; no provider endpoint was contacted."
        ),
        acceptance="Ambiguous first send remains unknown; only an explicit same-key reconciliation reaches a fake receiver with one physical effect.",
        kill_criterion="Unknown is treated as success, a non-idempotent unknown is retryable, or a same-key receiver records more than one physical effect.",
        observed=observed,
        limits=(
            "The receiver is a test double. This does not prove a third party honours idempotency keys or provides exactly-once delivery."
            if effect_kind == "external.effect" else
            "No secure provider credential/FD, TokenRouter request, provider acknowledgement, billing receipt, or provider-side recovery was available."
        ),
    )


def _tenant_isolation() -> dict[str, Any]:
    from chimera.tenancy import TenantContext, TenantQuota, TenantQuotaLedger, TenantWorkspaceResolver

    with tempfile.TemporaryDirectory(prefix="chimera-tenant-isolation-") as raw:
        root = pathlib.Path(raw)
        source = root / "source"
        (source / "pkg").mkdir(parents=True)
        (source / "pkg" / "state.py").write_text("VALUE = 'baseline'\n", encoding="utf-8")
        resolver = TenantWorkspaceResolver(root)
        left = TenantContext.from_id("matrix-tenant-left@example.invalid")
        right = TenantContext.from_id("matrix-tenant-right@example.invalid")
        left_ws = resolver.provision(left, source_root=source)
        right_ws = resolver.provision(right, source_root=source)
        left_state = pathlib.Path(left_ws.workspace_root) / "pkg" / "state.py"
        right_state = pathlib.Path(right_ws.workspace_root) / "pkg" / "state.py"
        left_state.write_text("VALUE = 'left-only'\n", encoding="utf-8")
        left_quota = TenantQuotaLedger(left_ws)
        right_quota = TenantQuotaLedger(right_ws)
        left_first, left_run = left_quota.admit(TenantQuota(max_active_runs=1))
        left_second, _ = left_quota.admit(TenantQuota(max_active_runs=1))
        right_first, right_run = right_quota.admit(TenantQuota(max_active_runs=1))
        persisted = "\n".join(
            item.read_text(encoding="utf-8", errors="ignore")
            for item in (root / ".chimera" / "tenants").rglob("*") if item.is_file()
        )
        accepted = (
            "baseline" in right_state.read_text(encoding="utf-8")
            and left_ws.workspace_root != right_ws.workspace_root
            and left.tenant_id not in left_ws.workspace_root
            and right.tenant_id not in right_ws.workspace_root
            and left_first.allowed and left_run is not None and not left_second.allowed
            and right_first.allowed and right_run is not None
            and left.tenant_id not in persisted and right.tenant_id not in persisted
        )
        observed = {
            "workspace_roots_distinct": left_ws.workspace_root != right_ws.workspace_root,
            "left_write_visible_in_right": "left-only" in right_state.read_text(encoding="utf-8"),
            "raw_tenant_ids_persisted": left.tenant_id in persisted or right.tenant_id in persisted,
            "left_first_admitted": left_first.allowed,
            "left_second_admitted": left_second.allowed,
            "right_first_admitted": right_first.allowed,
        }
    return _row(
        "tenant-workspace-isolation",
        status="passed" if accepted else "failed",
        capability_proven=accepted,
        scope="Local copied tenant workspaces, opaque hashed roots, and separate local active-run ledgers.",
        acceptance="A write and exhausted quota in the left tenant do not alter the right tenant workspace or right tenant admission.",
        kill_criterion="Cross-workspace mutation, raw tenant ID persistence, shared quota state, or a default tenant fallback.",
        observed=observed,
        limits="This is not end-to-end RPC/MCP/scheduler identity propagation, authentication, OS user isolation, or cloud multi-tenancy.",
    )


def _restate_preflight() -> dict[str, Any]:
    import importlib.util

    sdk_present = importlib.util.find_spec("restate") is not None
    server = shutil.which("restate") or shutil.which("restate-server")
    docker = shutil.which("docker") or shutil.which("podman")
    return _row(
        "restate-equivalence",
        status="blocked-no-restate-runtime",
        capability_proven=False,
        scope="Equivalence requires the same crash/effect/queue fixture against a running pinned Restate server.",
        acceptance="A disposable Restate server runs the identical fixture and returns comparable crash, idempotency, queue, pool, and cancellation receipts.",
        kill_criterion="SDK import is treated as a server execution, or semantic differences/unknown effect outcomes are hidden.",
        observed={"restate_sdk_importable": sdk_present, "restate_server_binary": bool(server), "container_runtime": bool(docker)},
        limits="The installed SDK is not a Restate runtime. No Restate workflow/equivalence result exists in this matrix.",
    )


def _dbos_queue_and_pool(database_url: str) -> tuple[dict[str, Any], dict[str, Any]]:
    """Exercise DBOS's real temporary Postgres queue and its configured pool."""
    from dbos import DBOS
    from dbos._dbos import _get_dbos_instance

    active = {"value": 0, "maximum": 0, "calls": 0}
    lock = threading.Lock()
    DBOS(config={
        "name": "chimera_compat_queue",
        "application_version": "chimera-compat-queue-v1",
        "system_database_url": database_url,
        "sys_db_pool_size": 2,
        "db_engine_kwargs": {"max_overflow": 0, "pool_timeout": 5},
    })

    @DBOS.step(retries_allowed=False)
    def bounded_step(value: int) -> int:
        with lock:
            active["value"] += 1
            active["maximum"] = max(active["maximum"], active["value"])
            active["calls"] += 1
        try:
            time.sleep(0.08)
        finally:
            with lock:
                active["value"] -= 1
        return value

    @DBOS.workflow()
    def queued_workflow(value: int) -> int:
        return bounded_step(value)

    try:
        DBOS.launch()
        DBOS.register_queue(
            "chimera_compat_saturation_q",
            concurrency=1,
            worker_concurrency=1,
            polling_interval_sec=0.02,
        )
        handles = [DBOS.enqueue_workflow("chimera_compat_saturation_q", queued_workflow, value) for value in range(6)]
        results = [handle.get_result() for handle in handles]
        statuses = [str(DBOS.get_workflow_status(handle.workflow_id).status) for handle in handles]
        queue_accepted = results == list(range(6)) and active["maximum"] == 1 and active["calls"] == 6 and statuses == ["SUCCESS"] * 6

        # DBOS exposes this engine as an implementation detail. The probe is
        # intentionally version-scoped evidence for DBOS 2.29.0, not a stable
        # Chimera adapter contract.
        engine = _get_dbos_instance()._sys_db.engine
        pool = engine.pool

        def hold_one_connection(_: int) -> int:
            with engine.connect() as connection:
                return int(connection.exec_driver_sql("SELECT pg_backend_pid(), pg_sleep(0.08)").first()[0])

        with concurrent.futures.ThreadPoolExecutor(max_workers=8, thread_name_prefix="chimera-pool-probe") as executor:
            backend_pids = list(executor.map(hold_one_connection, range(8)))
        pool_size = int(pool.size())
        max_overflow = int(getattr(pool, "_max_overflow", -1))
        pool_accepted = pool_size == 2 and max_overflow == 0 and len(set(backend_pids)) <= 2 and len(backend_pids) == 8
        queue_row = _row(
            "dbos-queue-saturation",
            status="passed" if queue_accepted else "failed",
            capability_proven=queue_accepted,
            scope="DBOS 2.29.0 database-backed queue on a disposable PostgreSQL 17 cluster, six workflows, global and worker concurrency of one.",
            acceptance="All six workflows complete while the instrumented step never has more than one active execution.",
            kill_criterion="More than one active execution, lost/duplicated workflow result, or an unexpected terminal state.",
            observed={"enqueued": 6, "completed": len(results), "step_calls": active["calls"], "max_active": active["maximum"], "terminal_statuses": statuses},
            limits="This is one local executor and six short workflows, not a multi-node saturation, fairness, retention, cancellation, or outage benchmark.",
        )
        pool_row = _row(
            "dbos-connection-pooling",
            status="passed-version-scoped" if pool_accepted else "failed",
            capability_proven=pool_accepted,
            scope="DBOS 2.29.0 system-database SQLAlchemy QueuePool configured with size 2 and max_overflow 0; eight concurrent held local queries.",
            acceptance="The actual DBOS system engine services eight held queries through no more than two observed PostgreSQL backend PIDs.",
            kill_criterion="Pool settings differ, more than two distinct DB backends service the held queries, or a query is lost.",
            observed={"configured_pool_size": pool_size, "configured_max_overflow": max_overflow, "held_queries": len(backend_pids), "distinct_postgres_backend_pids": len(set(backend_pids))},
            limits="This does not test PgBouncer, LISTEN/NOTIFY pooling compatibility, application DB pools, mixed DBOS/queue workloads, or production sizing.",
        )
        return queue_row, pool_row
    finally:
        DBOS.destroy(destroy_registry=True)


def _dbos_rows() -> list[dict[str, Any]]:
    try:
        import dbos  # noqa: F401
        import psycopg  # noqa: F401
    except ImportError as exc:
        return [_row(
            "dbos-matrix",
            status="blocked-missing-dependency",
            capability_proven=False,
            scope="DBOS/PostgreSQL compatibility matrix.",
            acceptance="dbos and psycopg import and a disposable local PostgreSQL cluster starts.",
            kill_criterion="Dependency absence is reported as a pass.",
            observed={"missing": type(exc).__name__},
            limits="No DBOS row ran.",
        )]
    try:
        with _ephemeral_postgres() as database_url:
            crash = _run_dbos_recovery(database_url, "crash")
            effect = _run_dbos_recovery(database_url, "external-effect")
            provider = _run_dbos_recovery(database_url, "provider-call")
            queue_row, pool_row = _dbos_queue_and_pool(database_url)
    except Exception as exc:
        return [_row(
            "dbos-matrix",
            status="failed-infrastructure",
            capability_proven=False,
            scope="Disposable DBOS/PostgreSQL matrix startup.",
            acceptance="All bounded local DBOS probes finish.",
            kill_criterion="A startup, child, queue, or pool error is hidden as a pass.",
            observed={"error_type": type(exc).__name__},
            limits="Other DBOS rows were not trusted after infrastructure failure.",
        )]
    crash_ok = bool(crash["accepted"])
    effect_ok = bool(effect["accepted"] and effect["receiver_physical_effects"] == 1 and effect["receiver_idempotency_keys"] == 1)
    provider_ok = bool(provider["accepted"] and provider["receiver_physical_effects"] == 1 and provider["receiver_idempotency_keys"] == 1)
    return [
        _row(
            "dbos-crash-recovery",
            status="passed" if crash_ok else "failed",
            capability_proven=crash_ok,
            scope="DBOS 2.29.0 plus a disposable PostgreSQL 17 cluster; process exits after a completed checkpoint and before the next step completion.",
            acceptance="Recovery returns 6, preserves one checkpoint execution, and re-enters the interrupted boundary exactly once.",
            kill_criterion="Checkpoint executes more than once, recovery does not complete, or a missing outcome is accepted.",
            observed=crash,
            limits="The boundary was a local process kill. This does not establish real external-effect exactly-once semantics.",
        ),
        _row(
            "dbos-external-effect-idempotency",
            status="passed-local-simulation" if effect_ok else "failed",
            capability_proven=False,
            scope="The DBOS crash fixture invokes a local fake external receiver before process death; the receiver persists one supplied idempotency key.",
            acceptance="The DBOS boundary runs twice after recovery while the endpoint-owned fake receiver records exactly one physical effect.",
            kill_criterion="The DBOS step is called once despite a crash, a receiver duplicates the physical effect, or a local fake is represented as a real endpoint proof.",
            observed=effect,
            limits="DBOS retried the boundary. De-duplication came from the receiver's explicit key semantics, not DBOS exactly-once delivery.",
        ),
        _row(
            "dbos-provider-call-recovery-simulation",
            status="passed-local-simulation" if provider_ok else "failed",
            capability_proven=False,
            scope="Same DBOS crash fixture with a local fake provider receiver and a stable supplied idempotency key.",
            acceptance="The checkpoint executes once, the call boundary is retried once, and the fake provider records one physical request.",
            kill_criterion="A local fake response is called a TokenRouter/provider receipt, or duplicate/unknown outcomes are silently treated as success.",
            observed=provider,
            limits="No live provider credential, request, cancellation acknowledgement, billing receipt, or provider idempotency contract was tested.",
        ),
        queue_row,
        pool_row,
    ]


def run_matrix() -> dict[str, Any]:
    rows = [
        _local_crash_recovery(),
        _local_idempotency_probe(effect_kind="external.effect"),
        _local_idempotency_probe(effect_kind="provider.call"),
        _tenant_isolation(),
    ]
    rows.extend(_dbos_rows())
    rows.append(_restate_preflight())
    return {
        "schema_version": "chimera.deployment-compatibility-matrix.v1",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "rows": rows,
        "automatic_enablement": False,
        "manual_promotion_required": True,
        "summary": {
            "passed_rows": sum(1 for row in rows if str(row["status"]).startswith("passed")),
            "blocked_rows": sum(1 for row in rows if str(row["status"]).startswith("blocked")),
            "failed_rows": sum(1 for row in rows if str(row["status"]).startswith("failed")),
            "statement": "Bounded local evidence only; no DBOS, queue, Restate, provider, or cloud adapter is promoted by this matrix.",
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, default=ROOT / "artifacts" / "deployment_compatibility_matrix.json")
    parser.add_argument("--dbos-recovery-worker", action="store_true")
    parser.add_argument("--database-url")
    parser.add_argument("--marker", type=pathlib.Path)
    parser.add_argument("--receiver", type=pathlib.Path)
    parser.add_argument("--kind", choices=("crash", "external-effect", "provider-call"))
    args = parser.parse_args()
    if args.dbos_recovery_worker:
        if not args.database_url or args.marker is None or args.receiver is None or args.kind is None:
            raise SystemExit("DBOS recovery worker requires database URL, marker, receiver, and kind")
        return _dbos_recovery_worker(args.database_url, args.marker, args.receiver, args.kind)
    result = run_matrix()
    args.results.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.results.with_suffix(args.results.suffix + ".tmp")
    temporary.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, args.results)
    print(json.dumps(result, sort_keys=True))
    return 0 if result["summary"]["failed_rows"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
