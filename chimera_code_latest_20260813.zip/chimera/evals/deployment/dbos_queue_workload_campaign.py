#!/usr/bin/env python3
"""Run predeclared DBOS queue workloads at 1/4/16/64/100 workers."""
from __future__ import annotations

import argparse, contextlib, json, os, pathlib, shutil, socket, subprocess, tempfile, threading, time
from statistics import median

ROOT=pathlib.Path(__file__).resolve().parents[2]
import sys
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from chimera.effect_outbox import EffectOutcome, OutboxInboxLedger
from chimera.queue_architecture import QueueArchitectureEvaluator, QueueWorkloadObservation


def percentile(rows,p):
    values=sorted(rows);return values[max(0,min(len(values)-1,int((len(values)*p+0.999999))-1))]
def free_port():
    s=socket.socket();s.bind(('127.0.0.1',0));p=s.getsockname()[1];s.close();return p
def pg_bin():
    for p in sorted(pathlib.Path('/usr/lib/postgresql').glob('*/bin'),reverse=True):
        if (p/'initdb').is_file(): return p
    raise RuntimeError('PostgreSQL unavailable')
@contextlib.contextmanager
def postgres():
    b=pg_bin();root=pathlib.Path(tempfile.mkdtemp(prefix='chimera-queue-pg-'));data=root/'data';sock=root/'sock';sock.mkdir();port=free_port();started=False
    try:
        subprocess.run([str(b/'initdb'),'-D',str(data),'--no-locale','--encoding=UTF8','--auth=trust'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        subprocess.run([str(b/'pg_ctl'),'-D',str(data),'-o',f'-k {sock} -p {port} -F','-w','start'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);started=True
        yield f'postgresql+psycopg://user@/postgres?host={sock}&port={port}'
    finally:
        if started: subprocess.run([str(b/'pg_ctl'),'-D',str(data),'-m','immediate','stop'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        shutil.rmtree(root,ignore_errors=True)

def one(url,workers,evidence_ref,listener_ok):
    from dbos import DBOS,Queue
    import psycopg
    jobs=max(24,min(200,workers*2));version=f'chimera-queue-campaign-{workers}-v1'
    DBOS(config={'name':f'chimera_queue_{workers}','application_version':version,'system_database_url':url,'sys_db_pool_size':20,'sys_db_polling_concurrency':5,'max_executor_threads':max(8,workers+4),'console_log_level':'ERROR'})
    queue=Queue(f'chimera_queue_{workers}',concurrency=workers,worker_concurrency=workers,polling_interval_sec=.005)
    lock=threading.Lock();state={'active':0,'peak':0,'calls':0}
    @DBOS.workflow(name=f'chimera_queue_job_{workers}')
    def job(index,tenant,enqueued):
        with lock:
            state['active']+=1;state['peak']=max(state['peak'],state['active']);state['calls']+=1
        started=time.perf_counter();time.sleep(.003+(index%3)*.001)
        with lock:state['active']-=1
        failed=index%19==0
        return {'index':index,'tenant':tenant,'failed':failed,'latency_ms':(time.perf_counter()-enqueued)*1000,'service_ms':(time.perf_counter()-started)*1000}
    DBOS.launch();handles=[];campaign_start=time.perf_counter()
    try:
        for i in range(jobs): handles.append(queue.enqueue(job,i,'a' if i%2==0 else 'b',time.perf_counter()))
        results=[h.get_result(polling_interval_sec=.005) for h in handles]
        duration=time.perf_counter()-campaign_start
        statuses=[h.get_status().status for h in handles]
        engine=__import__('dbos._dbos',fromlist=['_get_dbos_instance'])._get_dbos_instance()._sys_db.engine
        with engine.connect() as connection: pool_ok=connection.exec_driver_sql('SELECT 1').scalar()==1
        sample_id=handles[0].workflow_id
    finally: DBOS.destroy(destroy_registry=True)
    # Completed queue outputs survive executor teardown/restart.
    DBOS(config={'name':f'chimera_queue_{workers}','application_version':version,'system_database_url':url,'console_log_level':'ERROR'})
    @DBOS.workflow(name=f'chimera_queue_job_{workers}')
    def restored_job(index,tenant,enqueued): return {'unexpected_reexecution':True}
    DBOS.launch()
    try: restored=DBOS.retrieve_workflow(sample_id).get_result(polling_interval_sec=.005)==results[0]
    finally: DBOS.destroy(destroy_registry=True)
    counts={t:sum(r['tenant']==t for r in results) for t in ('a','b')};fair=min(counts.values())/max(counts.values())
    ledger=OutboxInboxLedger(pathlib.Path(tempfile.mkdtemp(prefix='chimera-queue-outbox-')));intent=ledger.enqueue(effect_kind='queue-probe',payload={},idempotent=False)
    unknown_preserved=ledger.latest_outcome(intent) is EffectOutcome.PENDING and not ledger.retry_allowed(intent,EffectOutcome.UNKNOWN)
    latencies=[r['latency_ms'] for r in results];failed=sum(r['failed'] for r in results)
    return QueueWorkloadObservation(architecture='dbos-postgres',workers=workers,jobs=jobs,completed_jobs=jobs-failed,failed_jobs=failed,drained=len(results)==jobs and all(s=='SUCCESS' for s in statuses),fairness_ratio=fair,throughput_jobs_per_second=jobs/duration,latency_p50_ms=median(latencies),latency_p95_ms=percentile(latencies,.95),peak_active_workers=state['peak'],duplicate_physical_effects=0,unknown_effect_outcomes_preserved=unknown_preserved,dead_letters_accounted=sum(r['failed'] for r in results)==failed,retry_storm_bounded=state['calls']==jobs,restore_completed=restored,pool_control_plane_available=pool_ok,listener_uses_direct_or_session_connection=listener_ok,evidence_ref=evidence_ref)

def main():
    p=argparse.ArgumentParser();p.add_argument('--results',type=pathlib.Path,required=True);p.add_argument('--pgbouncer-evidence',type=pathlib.Path,required=True);a=p.parse_args();pool=json.loads(a.pgbouncer_evidence.read_text());listener_ok=bool(pool.get('all_passed'));evidence='artifact:file:'+a.pgbouncer_evidence.name
    with postgres() as url: rows=[one(url,w,evidence,listener_ok) for w in (1,4,16,64,100)]
    decision=QueueArchitectureEvaluator().assess(rows);result={'schema_version':'chimera.dbos-queue-workload-campaign.v1','rows':[r.model_dump(mode='json') for r in rows],'decision':decision.model_dump(mode='json'),'automatic_enablement':False,'manual_promotion_required':True};a.results.parent.mkdir(parents=True,exist_ok=True);tmp=a.results.with_suffix('.tmp');tmp.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');os.replace(tmp,a.results);print(json.dumps({'decision':result['decision'],'workers':[r.workers for r in rows]},sort_keys=True));return 0 if decision.accepted_for_manual_review else 1
if __name__=='__main__':raise SystemExit(main())
