#!/usr/bin/env python3
"""Least-privilege PostgreSQL RLS campaign using separate owner/runtime roles."""

from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import socket
import subprocess
import tempfile
import time

from sqlalchemy import create_engine
from sqlalchemy.exc import DBAPIError

from chimera.cloud_state import PostgresCloudStateAdapter


def postgres_bin() -> pathlib.Path:
    for path in sorted(pathlib.Path("/usr/lib/postgresql").glob("*/bin"), reverse=True):
        if (path / "postgres").exists():
            return path
    raise RuntimeError("PostgreSQL server binaries are unavailable")


def free_port() -> int:
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        return int(listener.getsockname()[1])


def denied(connection, statement: str) -> bool:
    transaction = connection.begin_nested()
    try:
        connection.exec_driver_sql(statement)
    except DBAPIError:
        transaction.rollback()
        return True
    transaction.rollback()
    return False


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    args = parser.parse_args()
    root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-cloud-rls-"))
    data = root / "data"
    sockets = root / "sock"
    sockets.mkdir()
    port = free_port()
    pg = postgres_bin()
    started = False
    owner = None
    runtime = None
    try:
        subprocess.run(
            [
                str(pg / "initdb"),
                "-D",
                str(data),
                "--no-locale",
                "--encoding=UTF8",
                "--auth=trust",
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            timeout=60,
        )
        subprocess.run(
            [
                str(pg / "pg_ctl"),
                "-D",
                str(data),
                "-l",
                str(root / "postgres.log"),
                "-o",
                f"-h 127.0.0.1 -k {sockets} -p {port} -F",
                "-w",
                "start",
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            timeout=60,
        )
        started = True
        owner_url = f"postgresql+psycopg://user@127.0.0.1:{port}/postgres"
        runtime_url = f"postgresql+psycopg://chimera_runtime@127.0.0.1:{port}/postgres"
        tenant_a = "a" * 64
        tenant_b = "b" * 64
        owner = PostgresCloudStateAdapter(owner_url, enable_rls=True)
        owner.append_event(tenant_key=tenant_a, kind="seed", data={"tenant": "a"})
        owner.append_event(tenant_key=tenant_b, kind="seed", data={"tenant": "b"})
        with owner.engine.begin() as connection:
            connection.exec_driver_sql(
                "CREATE ROLE chimera_runtime LOGIN NOSUPERUSER NOCREATEDB "
                "NOCREATEROLE NOINHERIT NOBYPASSRLS"
            )
            connection.exec_driver_sql(
                "GRANT CONNECT ON DATABASE postgres TO chimera_runtime"
            )
            connection.exec_driver_sql(
                "GRANT USAGE ON SCHEMA public TO chimera_runtime"
            )
            connection.exec_driver_sql(
                "GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public "
                "TO chimera_runtime"
            )
            connection.exec_driver_sql(
                "GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO chimera_runtime"
            )
        runtime = PostgresCloudStateAdapter(runtime_url, initialize_schema=False)
        events_a = runtime.replay_events(tenant_key=tenant_a)
        events_b = runtime.replay_events(tenant_key=tenant_b)
        runtime.append_event(tenant_key=tenant_a, kind="runtime", data={"ok": True})
        outbox_id = runtime.enqueue_outbox(
            tenant_key=tenant_a,
            kind="telemetry",
            payload={"latency_ms": 1},
        )
        claims = runtime.claim_outbox(tenant_key=tenant_a)
        runtime.finish_outbox(outbox_id, tenant_key=tenant_a)

        direct = create_engine(runtime_url)
        with direct.connect() as connection:
            role = connection.exec_driver_sql(
                "SELECT rolsuper, rolcreatedb, rolcreaterole, rolbypassrls "
                "FROM pg_roles WHERE rolname=current_user"
            ).one()
            no_scope_count = connection.exec_driver_sql(
                "SELECT count(*) FROM public.chimera_cloud_events"
            ).scalar_one()
        with direct.begin() as connection:
            connection.exec_driver_sql(
                "SELECT set_config('chimera.tenant_key', %s, true)", (tenant_a,)
            )
            visible_tenants = {
                str(row[0])
                for row in connection.exec_driver_sql(
                    "SELECT DISTINCT tenant_key FROM public.chimera_cloud_events"
                ).fetchall()
            }
            forged_insert_denied = denied(
                connection,
                "INSERT INTO public.chimera_cloud_events "
                f"(tenant_key,kind,data_json,created_at) VALUES ('{tenant_b}','forged','{{}}',{time.time()})",
            )
            ddl_denied = denied(
                connection,
                "CREATE TABLE public.chimera_runtime_escape(id integer)",
            )
            policy_mutation_denied = denied(
                connection,
                "ALTER TABLE public.chimera_cloud_events DISABLE ROW LEVEL SECURITY",
            )
        direct.dispose()
        evidence = {
            "schema_version": "chimera.cloud-state-postgres-rls-campaign.v1",
            "postgres_version": subprocess.check_output(
                [str(pg / "postgres"), "--version"], text=True, timeout=10
            ).strip(),
            "separate_owner_and_runtime_roles": True,
            "runtime_role_attributes_least_privilege": tuple(role)
            == (False, False, False, False),
            "runtime_role_cannot_initialize_schema": ddl_denied,
            "runtime_role_cannot_modify_rls_policy": policy_mutation_denied,
            "unscoped_reads_empty": int(no_scope_count) == 0,
            "tenant_a_visibility": len(events_a) == 1
            and events_a[0]["data"] == {"tenant": "a"},
            "tenant_b_visibility": len(events_b) == 1
            and events_b[0]["data"] == {"tenant": "b"},
            "direct_cross_tenant_visibility_denied": visible_tenants == {tenant_a},
            "cross_tenant_write_denied": forged_insert_denied,
            "tenant_scoped_outbox": bool(claims and claims[0].id == outbox_id),
            "automatic_enablement": False,
            "manual_cloud_promotion_required": True,
            "limits": [
                "Disposable single-host PostgreSQL, not managed-cloud or physical multi-host evidence.",
                "The runtime role can choose the custom tenant GUC; production must bind authenticated tenant identity in a trusted gateway, per-tenant role, or security-definer mapping.",
                "The owner/migration role must never be available to the runtime process.",
            ],
        }
        required = {
            "separate_owner_and_runtime_roles",
            "runtime_role_attributes_least_privilege",
            "runtime_role_cannot_initialize_schema",
            "runtime_role_cannot_modify_rls_policy",
            "unscoped_reads_empty",
            "tenant_a_visibility",
            "tenant_b_visibility",
            "direct_cross_tenant_visibility_denied",
            "cross_tenant_write_denied",
            "tenant_scoped_outbox",
        }
        evidence["all_passed"] = all(evidence[key] for key in required)
        args.results.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.results.with_suffix(".tmp")
        temporary.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n")
        os.replace(temporary, args.results)
        print(json.dumps(evidence, sort_keys=True))
        return 0 if evidence["all_passed"] else 1
    finally:
        if runtime is not None:
            runtime.close()
        if owner is not None:
            owner.close()
        if started:
            subprocess.run(
                [str(pg / "pg_ctl"), "-D", str(data), "-m", "immediate", "stop"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=30,
                check=False,
            )
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
