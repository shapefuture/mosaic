#!/usr/bin/env python3
"""Transient DBOS/Postgres idempotency spike.

Starts a disposable local PostgreSQL instance as the current non-root user,
runs one deterministic DBOS workflow twice under the same workflow ID, emits a
sanitized receipt, and deletes the cluster. This is not a crash/effect/queue
certification or a production DBOS adapter.
"""
from __future__ import annotations

import json
import os
import pathlib
import shutil
import subprocess
import tempfile


def _pg_bin() -> pathlib.Path:
    configured = os.environ.get("CHIMERA_POSTGRES_BIN")
    candidates = [pathlib.Path(configured)] if configured else []
    candidates += sorted(pathlib.Path("/usr/lib/postgresql").glob("*/bin"), reverse=True)
    for candidate in candidates:
        if (candidate / "initdb").is_file() and (candidate / "pg_ctl").is_file():
            return candidate
    raise RuntimeError("PostgreSQL initdb/pg_ctl binaries are unavailable")


def main() -> int:
    from dbos import DBOS, SetWorkflowID

    pg_bin = _pg_bin()
    root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-dbos-spike-"))
    data, sock = root / "data", root / "sock"
    sock.mkdir()
    port = 55435
    try:
        subprocess.run([str(pg_bin / "initdb"), "-D", str(data), "--no-locale", "--encoding=UTF8", "--auth=trust"], check=True, stdout=subprocess.DEVNULL)
        subprocess.run([str(pg_bin / "pg_ctl"), "-D", str(data), "-o", f"-k '{sock}' -p {port} -F", "-w", "start"], check=True, stdout=subprocess.DEVNULL)
        DBOS(config={
            "name": "chimera_dbos_spike",
            "application_version": "chimera-dbos-spike-v1",
            "system_database_url": f"postgresql+psycopg://user@/postgres?host={sock}&port={port}",
        })
        calls = {"step": 0}

        @DBOS.step(retries_allowed=False)
        def deterministic_step(value: int) -> int:
            calls["step"] += 1
            return value + 1

        @DBOS.workflow()
        def workflow(value: int) -> int:
            return deterministic_step(value)

        DBOS.launch()
        with SetWorkflowID("chimera-dbos-spike-workflow"):
            first = workflow(4)
        with SetWorkflowID("chimera-dbos-spike-workflow"):
            second = workflow(4)
        receipt = {
            "postgres_ephemeral": True,
            "workflow_id_reused": True,
            "first_result": first,
            "second_result": second,
            "step_calls": calls["step"],
            "idempotent_checkpoint_observed": first == second == 5 and calls["step"] == 1,
            "certification": "spike-only; no crash, external-effect, queue, or concurrency certification",
        }
        print(json.dumps(receipt, sort_keys=True))
        DBOS.destroy(destroy_registry=True)
        return 0
    finally:
        subprocess.run([str(pg_bin / "pg_ctl"), "-D", str(data), "-m", "immediate", "stop"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
