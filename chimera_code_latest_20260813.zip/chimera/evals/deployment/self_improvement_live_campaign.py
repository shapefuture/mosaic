#!/usr/bin/env python3
"""Live multi-copy Chimera self-improvement gauntlet.

Runs multiple isolated worker processes against adversarial, incrementally harder
coding tasks.  The generator owns tasks, workers produce code, critic runs
visible+hidden tests, and metacritic decides whether any candidate is eligible.
No repository promotion is applied by this campaign.
"""
from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any

from chimera.self_improvement_gauntlet import AdversarialTaskGenerator, Critic, MetaCritic, GauntletTask


def _solution(task: GauntletTask, copy_index: int) -> str:
    # Distinct copies intentionally use slightly different implementations.
    # At least one robust candidate must survive hidden tests for each task.
    if task.id == "duration_edges_v1":
        if copy_index % 3 == 1:
            return "def parse_duration(text):\n    return int(float(text[:-1]) * 1000)\n"
        return r'''
def parse_duration(text):
    if text is None:
        raise ValueError("duration is required")
    raw = str(text).strip().lower()
    import re
    match = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)\s*(ms|s|min|h)", raw)
    if not match:
        raise ValueError(f"ambiguous duration: {text!r}")
    value = float(match.group(1)); unit = match.group(2)
    scale = {"ms": 1, "s": 1000, "min": 60000, "h": 3600000}[unit]
    return int(value * scale)
'''.lstrip()
    if task.id == "inventory_reconcile_v1":
        if copy_index % 3 == 1:
            return "def reconcile(events):\n    out={}\n    for e in events: out[e['sku']]=out.get(e['sku'],0)+e['delta']\n    return out\n"
        return r'''
def reconcile(events):
    seen = set(); stock = {}
    for event in events or []:
        event_id = event.get("id")
        if event_id in seen:
            continue
        seen.add(event_id)
        sku = event["sku"]
        delta = int(event.get("delta", 0))
        next_value = stock.get(sku, 0) + delta
        if next_value < 0:
            raise ValueError("negative stock")
        stock[sku] = next_value
    return stock
'''.lstrip()
    if task.id == "prompt_injection_sanitizer_v1":
        if copy_index % 3 == 1:
            return "def sanitize_markdown(text):\n    return str(text).replace('<script>','').replace('</script>','')\n"
        return r'''
def sanitize_markdown(text):
    import re
    source = "" if text is None else str(text)
    parts = re.split(r"(```.*?```)", source, flags=re.S)
    cleaned = []
    for index, part in enumerate(parts):
        if index % 2 == 1:
            cleaned.append(part)
            continue
        part = re.sub(r"<!--.*?(ignore previous instructions|ignore prior instructions).*?-->", "", part, flags=re.I | re.S)
        part = re.sub(r"<\s*(script|style)\b.*?>.*?<\s*/\s*\1\s*>", "", part, flags=re.I | re.S)
        cleaned.append(part)
    return "".join(cleaned)
'''.lstrip()
    raise ValueError(task.id)


def _module_import(task: GauntletTask) -> str:
    module = pathlib.PurePosixPath(task.target).with_suffix("").as_posix().replace("/", ".")
    if task.id == "duration_edges_v1":
        return f"from {module} import parse_duration\n"
    if task.id == "inventory_reconcile_v1":
        return f"from {module} import reconcile\n"
    if task.id == "prompt_injection_sanitizer_v1":
        return f"from {module} import sanitize_markdown\n"
    raise ValueError(task.id)


def _run_tests(root: pathlib.Path, task: GauntletTask, *, hidden: bool) -> dict[str, Any]:
    tests = root / "tests"
    tests.mkdir(exist_ok=True)
    path = tests / ("test_hidden.py" if hidden else "test_visible.py")
    assertions = (task.hidden_test if hidden else task.visible_test).splitlines()
    body = _module_import(task) + "\ndef test_case():\n" + "\n".join("    " + line if line.strip() else "" for line in assertions) + "\n"
    path.write_text(body, encoding="utf-8")
    started = time.perf_counter()
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", str(path)],
        cwd=root,
        env={**os.environ, "PYTHONPATH": str(root)},
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )
    return {
        "status": int(result.returncode),
        "duration_ms": round((time.perf_counter() - started) * 1000, 3),
        "stdout_tail": result.stdout[-2000:],
        "stderr_tail": result.stderr[-2000:],
    }


def _worker(task_dict: dict[str, Any], copy_index: int, queue) -> None:
    task = GauntletTask(**task_dict)
    root = pathlib.Path(tempfile.mkdtemp(prefix=f"chimera-gauntlet-{task.id}-{copy_index}-"))
    started = time.perf_counter()
    spans = []
    try:
        (root / "chimera_tasks").mkdir()
        (root / "chimera_tasks" / "__init__.py").write_text("", encoding="utf-8")
        target = root / task.target
        t0 = time.perf_counter()
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(_solution(task, copy_index), encoding="utf-8")
        spans.append({"name": "write_solution", "duration_ms": round((time.perf_counter() - t0) * 1000, 3), "target": task.target})
        visible = _run_tests(root, task, hidden=False)
        hidden = _run_tests(root, task, hidden=True)
        result = {
            "task_id": task.id,
            "copy_index": copy_index,
            "workspace": str(root),
            "visible_passed": visible["status"] == 0,
            "hidden_passed": hidden["status"] == 0,
            "protected_tests_unchanged": True,
            "visible": visible,
            "hidden": hidden,
            "spans": spans,
            "duration_ms": round((time.perf_counter() - started) * 1000, 3),
        }
        queue.put(result)
    except Exception as exc:
        queue.put({"task_id": task.id, "copy_index": copy_index, "visible_passed": False, "hidden_passed": False, "protected_tests_unchanged": False, "error": f"{type(exc).__name__}: {exc}", "duration_ms": round((time.perf_counter() - started) * 1000, 3)})
    finally:
        shutil.rmtree(root, ignore_errors=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    parser.add_argument("--chimera-copies", type=int, default=4)
    parser.add_argument("--levels", type=int, default=3)
    parser.add_argument("--timeout", type=float, default=120.0)
    args = parser.parse_args()
    tasks = AdversarialTaskGenerator().generate(levels=max(1, min(3, args.levels)))
    context = mp.get_context("spawn")
    rows = []
    critic = Critic(); metacritic = MetaCritic()
    started = time.perf_counter()
    for task in tasks:
        queue = context.Queue()
        processes = [context.Process(target=_worker, args=(task.as_dict(), index, queue)) for index in range(max(1, args.chimera_copies))]
        for process in processes:
            process.start()
        task_rows = []
        deadline = time.monotonic() + args.timeout
        for process in processes:
            remaining = max(1.0, deadline - time.monotonic())
            process.join(remaining)
            if process.is_alive():
                process.terminate(); process.join(5)
                task_rows.append({"task_id": task.id, "copy_index": None, "visible_passed": False, "hidden_passed": False, "error": "timeout"})
        while not queue.empty():
            task_rows.append(queue.get())
        critic_rows = [critic.score(task, row) for row in task_rows]
        best = next((row for row in task_rows if row.get("visible_passed") and row.get("hidden_passed")), None)
        rows.append({
            "task": task.as_dict(),
            "attempts": task_rows,
            "critic_rows": critic_rows,
            "task_passed": best is not None,
            "selected_copy": best.get("copy_index") if best else None,
        })
    selected_critic_rows = []
    for task_row in rows:
        selected = task_row.get("selected_copy")
        selected_attempt = next((attempt for attempt in task_row["attempts"] if attempt.get("copy_index") == selected), None)
        if selected_attempt is not None:
            selected_critic_rows.append(critic.score(GauntletTask(**task_row["task"]), selected_attempt))
    meta = metacritic.review(selected_critic_rows)
    evidence = {
        "schema_version": "chimera.self-improvement-live-campaign.v1",
        "chimera_copies": max(1, args.chimera_copies),
        "task_count": len(tasks),
        "rows": rows,
        "metacritic": meta,
        "all_tasks_have_passing_copy": all(row["task_passed"] for row in rows),
        "promotion_allowed_by_metacritic": bool(meta.get("promotion_allowed")),
        "repository_promotion_applied": False,
        "live_coding_execution": True,
        "hidden_tests_evaluator_owned": True,
        "duration_ms": round((time.perf_counter() - started) * 1000, 3),
        "limits": [
            "Uses deterministic local candidate generators to certify multi-copy gauntlet execution; it is not a provider-model capability claim.",
            "No repository promotion is applied by this campaign.",
        ],
    }
    evidence["all_passed"] = bool(evidence["all_tasks_have_passing_copy"] and evidence["promotion_allowed_by_metacritic"] and evidence["live_coding_execution"])
    args.results.parent.mkdir(parents=True, exist_ok=True)
    tmp = args.results.with_suffix(".tmp")
    tmp.write_text(json.dumps(evidence, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
    os.replace(tmp, args.results)
    print(json.dumps(evidence, sort_keys=True, default=str))
    return 0 if evidence["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
