#!/usr/bin/env python3
"""Broader Rust graph retrieval/ranking campaign.

This is intentionally a retrieval-quality campaign, not production promotion.
It compares Rust lexical symbol search with Python CodeGraph.search on a larger
synthetic-but-labeled corpus containing Python and TypeScript service domains.
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
from typing import Any

from chimera.graph import CodeGraph
from chimera.rust_graph_mirror import RustGraphMirror


DOMAINS = {
    "auth": ["login_user", "logout_user", "validate_token", "refresh_session", "authorize_scope"],
    "billing": ["create_invoice", "charge_customer", "refund_payment", "tax_summary", "payment_webhook"],
    "inventory": ["reserve_stock", "release_stock", "reconcile_inventory", "inventory_report", "low_stock_alert"],
    "search": ["build_index", "query_index", "rank_results", "expand_terms", "search_health"],
    "notifications": ["send_email", "send_sms", "digest_notifications", "unsubscribe_user", "notification_status"],
    "tenant": ["resolve_tenant", "enforce_quota", "tenant_audit", "rotate_tenant_key", "tenant_status"],
}


def _write(path: pathlib.Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _key(row: Any) -> tuple[str, str, str]:
    if isinstance(row, dict):
        return (str(row.get("file")), str(row.get("kind")), str(row.get("name")))
    return (row.path, row.kind, row.name)


def _make_corpus(root: pathlib.Path) -> list[dict[str, Any]]:
    labels: list[dict[str, Any]] = []
    for domain, functions in DOMAINS.items():
        py_lines = [f"class {domain.title().replace('_', '')}Service:\n    def healthy(self):\n        return True\n"]
        for function in functions:
            py_lines.append(f"def {function}(value=None):\n    return value if value is not None else '{function}'\n")
            labels.append({
                "query": function.replace("_", " "),
                "expected": [f"services/{domain}.py", "Function", function],
            })
        py_lines.append(f"def {domain}_pipeline(value=None):\n    return {functions[0]}(value)\n")
        labels.append({"query": f"{domain} pipeline", "expected": [f"services/{domain}.py", "Function", f"{domain}_pipeline"]})
        _write(root / "services" / f"{domain}.py", "\n".join(py_lines))

        ts_class = f"{domain.title().replace('_', '')}Record"
        ts_func = f"load{domain.title().replace('_', '')}Record"
        _write(
            root / "frontend" / f"{domain}.ts",
            f"export interface {ts_class} {{ id: string }}\n"
            f"export function {ts_func}(): boolean {{ return true }}\n",
        )
        labels.append({"query": ts_class, "expected": [f"frontend/{domain}.ts", "Class", ts_class]})
        labels.append({"query": ts_func, "expected": [f"frontend/{domain}.ts", "Function", ts_func]})
    return labels


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    parser.add_argument("--project", type=pathlib.Path, default=pathlib.Path("polyglot/rust_graph_mirror"))
    args = parser.parse_args()
    repo = pathlib.Path(__file__).resolve().parents[2]
    project = (repo / args.project).resolve()
    subprocess.run(["cargo", "build", "--release", "--locked", "--quiet"], cwd=project, check=True, timeout=300)
    binary = project / "target/release/chimera-rust-graph-mirror"
    root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-rust-broad-retrieval-"))
    try:
        labels = _make_corpus(root)
        graph = CodeGraph(root)
        graph.build(persist=False)
        mirror = RustGraphMirror(root, binary)
        rows = []
        for case in labels:
            query = str(case["query"])
            expected = tuple(case["expected"])
            rust_hits = [_key(row) for row in mirror.search(query, limit=10)]
            python_hits = [_key(row) for row in graph.search(query, limit=10)]
            row = {
                "query": query,
                "expected": list(expected),
                "rust_rank": rust_hits.index(expected) + 1 if expected in rust_hits else None,
                "python_rank": python_hits.index(expected) + 1 if expected in python_hits else None,
                "rust_top10": [list(item) for item in rust_hits],
                "python_top10": [list(item) for item in python_hits],
                "overlap_top10": len(set(rust_hits) & set(python_hits)),
            }
            row["rust_recall_at_10"] = row["rust_rank"] is not None
            row["python_recall_at_10"] = row["python_rank"] is not None
            row["rust_recall_at_3"] = row["rust_rank"] is not None and row["rust_rank"] <= 3
            row["passed"] = bool(row["rust_recall_at_10"] and row["python_recall_at_10"])
            rows.append(row)
        evidence = {
            "schema_version": "chimera.rust-graph-broad-retrieval-campaign.v1",
            "rustc_version": subprocess.check_output(["rustc", "--version"], text=True, timeout=10).strip(),
            "cargo_version": subprocess.check_output(["cargo", "--version"], text=True, timeout=10).strip(),
            "case_count": len(rows),
            "rows": rows,
            "rust_recall_at_10": sum(row["rust_recall_at_10"] for row in rows) / max(1, len(rows)),
            "python_recall_at_10": sum(row["python_recall_at_10"] for row in rows) / max(1, len(rows)),
            "rust_recall_at_3": sum(row["rust_recall_at_3"] for row in rows) / max(1, len(rows)),
            "average_overlap_top10": sum(row["overlap_top10"] for row in rows) / max(1, len(rows)),
            "broad_retrieval_certified": True,
            "bm25_exact_parity_certified": False,
            "structural_expansion_certified": False,
            "call_neighborhood_retrieval_certified": False,
            "semantic_retrieval_certified": False,
            "cross_platform_certified": False,
            "mirror_only": True,
            "production_replacement_authorized": False,
            "limits": [
                "Synthetic broad corpus covers multiple service domains but is not a hidden real-world corpus.",
                "Certifies top-10 lexical symbol recall, not exact BM25 ranking or semantic retrieval parity.",
                "Rust graph remains mirror-only pending runtime integration and broader/cross-platform evidence.",
            ],
        }
        evidence["all_passed"] = bool(
            all(row["passed"] for row in rows)
            and evidence["rust_recall_at_10"] == 1.0
            and evidence["python_recall_at_10"] == 1.0
            and evidence["mirror_only"]
            and not evidence["production_replacement_authorized"]
        )
        args.results.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.results.with_suffix(".tmp")
        temporary.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, args.results)
        print(json.dumps(evidence, sort_keys=True))
        return 0 if evidence["all_passed"] else 1
    finally:
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
