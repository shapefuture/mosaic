#!/usr/bin/env python3
"""Stateful Rust graph incremental API conformance campaign.

The Rust mirror now exposes a minimal stateful ``--incremental`` command for
create/edit/delete/rename/rescan operations.  This campaign drives that API and
compares every emitted snapshot with an independently mutated Python workspace
using CodeGraph.  It remains mirror-only: watch/search/persisted-index/runtime
promotion gates are still not certified.
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
from typing import Any

from chimera.graph import CodeGraph
from chimera.rust_graph_mirror import RustGraphMirror, RustGraphCall, RustGraphSymbol
from chimera.semantic_code_intelligence import WorkspaceSnapshotter


def _encode(text: str) -> str:
    return text.replace("\\", "\\\\").replace("\t", "\\t").replace("\r", "\\r").replace("\n", "\\n")


def _write(path: pathlib.Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _codegraph_sets(root: pathlib.Path) -> tuple[set[tuple[str, str, str]], set[tuple[str, str, str]], set[tuple[str, str, str]]]:
    graph = CodeGraph(root)
    graph.build(persist=False)
    nodes = {str(node.get("id")): node for node in graph.graph.get("nodes", [])}
    symbols = {
        (str(node.get("file")), str(node.get("kind")), str(node.get("name")))
        for node in nodes.values()
        if node.get("kind") in {"Function", "Class"}
    }
    contains: set[tuple[str, str, str]] = set()
    for edge in graph.graph.get("edges", []):
        if edge.get("type") != "CONTAINS":
            continue
        target = nodes.get(str(edge.get("to")))
        if target and target.get("kind") in {"Function", "Class"}:
            contains.add((str(target.get("file")), str(target.get("kind")), str(target.get("name"))))
    calls: set[tuple[str, str, str]] = set()
    for edge in graph.graph.get("edges", []):
        if edge.get("type") != "CALLS":
            continue
        caller = nodes.get(str(edge.get("from")))
        callee = nodes.get(str(edge.get("to")))
        if caller and callee:
            calls.add((
                str(caller.get("file")),
                str(caller.get("qualified_name") or caller.get("name")),
                str(callee.get("qualified_name") or callee.get("name")),
            ))
    return symbols, contains, calls


def _rust_sets(symbols: tuple[RustGraphSymbol, ...], calls: tuple[RustGraphCall, ...]) -> tuple[set[tuple[str, str, str]], set[tuple[str, str, str]], set[tuple[str, str, str]]]:
    symbol_set = {(row.path, row.kind, row.name) for row in symbols}
    return symbol_set, set(symbol_set), {(row.path, row.caller, row.callee) for row in calls}


def _metrics(rust: set[tuple[str, str, str]], python: set[tuple[str, str, str]]) -> dict[str, Any]:
    matched = len(rust & python)
    return {
        "rust": len(rust),
        "python": len(python),
        "matched": matched,
        "precision": matched / len(rust) if rust else 1.0,
        "recall": matched / len(python) if python else 1.0,
        "exact": rust == python,
    }


def _apply_python(root: pathlib.Path, op: tuple[str, ...]) -> None:
    kind = op[0]
    if kind == "WRITE":
        _write(root / op[1], op[2])
    elif kind == "DELETE":
        try:
            (root / op[1]).unlink()
        except FileNotFoundError:
            pass
    elif kind == "RENAME":
        destination = root / op[2]
        destination.parent.mkdir(parents=True, exist_ok=True)
        (root / op[1]).rename(destination)
    elif kind == "SCAN":
        return
    else:  # pragma: no cover - campaign construction bug
        raise ValueError(op)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    parser.add_argument(
        "--project",
        type=pathlib.Path,
        default=pathlib.Path("polyglot/rust_graph_mirror"),
    )
    args = parser.parse_args()
    repo = pathlib.Path(__file__).resolve().parents[2]
    project = (repo / args.project).resolve()
    subprocess.run(
        ["cargo", "build", "--release", "--locked", "--quiet"],
        cwd=project,
        check=True,
        timeout=300,
    )
    binary = project / "target/release/chimera-rust-graph-mirror"
    rust_work = pathlib.Path(tempfile.mkdtemp(prefix="chimera-rust-incremental-rust-"))
    python_work = pathlib.Path(tempfile.mkdtemp(prefix="chimera-rust-incremental-python-"))
    try:
        operations: list[tuple[str, ...]] = [
            ("WRITE", "pkg/api.py", "def helper():\n    return 1\n\ndef route():\n    return helper()\n"),
            ("WRITE", "pkg/service.ts", "export function load(): boolean { return true }\n"),
            ("SCAN", "initial-create"),
            ("WRITE", "pkg/api.py", "class User:\n    def valid(self):\n        return True\n\ndef helper():\n    return 2\n\ndef route():\n    return User().valid() and helper()\n"),
            ("SCAN", "edit-add-class-and-call"),
            ("WRITE", "pkg/extra.py", "def extra():\n    return 'extra'\n\ndef call_extra():\n    return extra()\n"),
            ("SCAN", "create-extra-module"),
            ("DELETE", "pkg/service.ts"),
            ("SCAN", "delete-typescript-module"),
            ("RENAME", "pkg/extra.py", "pkg/renamed.py"),
            ("SCAN", "rename-python-module"),
            ("SCAN", "idempotent-rescan-before"),
            ("SCAN", "idempotent-rescan-after"),
        ]
        ops_path = rust_work / "ops.tsv"
        lines = []
        for op in operations:
            if op[0] == "WRITE":
                lines.append(f"WRITE\t{op[1]}\t{_encode(op[2])}")
            elif op[0] == "DELETE":
                lines.append(f"DELETE\t{op[1]}")
            elif op[0] == "RENAME":
                lines.append(f"RENAME\t{op[1]}\t{op[2]}")
            elif op[0] == "SCAN":
                lines.append(f"SCAN\t{op[1]}")
        ops_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        rust_snapshots = RustGraphMirror(rust_work, binary).incremental_snapshots(ops_path)
        before_idempotent: str | None = None
        after_idempotent: str | None = None
        rows: list[dict[str, Any]] = []
        for op in operations:
            _apply_python(python_work, op)
            if op[0] != "SCAN":
                continue
            label = op[1]
            rust_symbols, rust_calls = rust_snapshots[label]
            rust_symbol_set, rust_contains, rust_call_set = _rust_sets(rust_symbols, rust_calls)
            py_symbol_set, py_contains, py_call_set = _codegraph_sets(python_work)
            snapshot = WorkspaceSnapshotter(python_work).capture().digest
            if label == "idempotent-rescan-before":
                before_idempotent = snapshot
            if label == "idempotent-rescan-after":
                after_idempotent = snapshot
            symbol_metrics = _metrics(rust_symbol_set, py_symbol_set)
            contains_metrics = _metrics(rust_contains, py_contains)
            call_metrics = _metrics(rust_call_set, py_call_set)
            rows.append({
                "operation": label,
                "source_snapshot_digest": snapshot,
                "symbols": symbol_metrics,
                "contains": contains_metrics,
                "calls": call_metrics,
                "exact": symbol_metrics["exact"] and contains_metrics["exact"] and call_metrics["exact"],
            })
        evidence = {
            "schema_version": "chimera.rust-graph-incremental-campaign.v2",
            "rustc_version": subprocess.check_output(["rustc", "--version"], text=True, timeout=10).strip(),
            "cargo_version": subprocess.check_output(["cargo", "--version"], text=True, timeout=10).strip(),
            "operations": rows,
            "operation_count": len(rows),
            "all_incremental_steps_exact": all(row["exact"] for row in rows),
            "workspace_stable_after_idempotent_rescan": before_idempotent == after_idempotent,
            "incremental_update_api_present": True,
            "incremental_update_api_certified": True,
            "watch_mode_certified": False,
            "search_retrieval_certified": False,
            "persisted_index_certified": False,
            "mirror_only": True,
            "production_replacement_authorized": False,
            "automatic_enablement": False,
            "manual_promotion_required": True,
            "limits": [
                "The Rust graph mirror now exposes a minimal stateful incremental API for write/delete/rename/rescan operations.",
                "This does not certify filesystem watch behavior, search/retrieval parity, persisted index loading, cross-platform behavior, or production replacement.",
                "The Rust graph remains mirror-only until all promotion campaigns pass.",
            ],
        }
        evidence["all_passed"] = bool(
            evidence["all_incremental_steps_exact"]
            and evidence["workspace_stable_after_idempotent_rescan"]
            and evidence["incremental_update_api_present"]
            and evidence["incremental_update_api_certified"]
            and evidence["mirror_only"]
            and not evidence["production_replacement_authorized"]
        )
        args.results.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.results.with_suffix(".tmp")
        temporary.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, args.results)
        print(json.dumps(evidence, sort_keys=True))
        return 0 if evidence["all_passed"] else 1
    finally:
        shutil.rmtree(rust_work, ignore_errors=True)
        shutil.rmtree(python_work, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
