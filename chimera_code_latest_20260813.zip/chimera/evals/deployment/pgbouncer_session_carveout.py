#!/usr/bin/env python3
"""Disposable PgBouncer transaction/session carve-out evidence."""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import socket
import subprocess
import tempfile
import time


def _free_port() -> int:
    value = socket.socket()
    try:
        value.bind(("127.0.0.1", 0)); return int(value.getsockname()[1])
    finally: value.close()


def _pg_bin() -> pathlib.Path:
    for path in sorted(pathlib.Path("/usr/lib/postgresql").glob("*/bin"), reverse=True):
        if (path / "initdb").is_file(): return path
    raise RuntimeError("PostgreSQL binaries unavailable")


def run() -> dict:
    import psycopg
    pg_bin = _pg_bin()
    pgbouncer = pathlib.Path(shutil.which("pgbouncer") or "/usr/sbin/pgbouncer")
    if not pgbouncer.is_file(): raise RuntimeError("PgBouncer unavailable")
    root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-pgbouncer-"))
    data, sock = root / "data", root / "sock"; sock.mkdir()
    pg_port, pool_port = _free_port(), _free_port()
    pg_started = pool_started = False
    try:
        subprocess.run([str(pg_bin / "initdb"), "-D", str(data), "--no-locale", "--encoding=UTF8", "--auth=trust"], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run([str(pg_bin / "pg_ctl"), "-D", str(data), "-o", f"-k {sock} -h 127.0.0.1 -p {pg_port} -F", "-w", "start"], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        pg_started = True
        (root / "users.txt").write_text('"user" ""\n')
        config = root / "pgbouncer.ini"
        config.write_text(f"""[databases]
transaction = host=127.0.0.1 port={pg_port} dbname=postgres pool_mode=transaction
session = host=127.0.0.1 port={pg_port} dbname=postgres pool_mode=session
[pgbouncer]
listen_addr=127.0.0.1
listen_port={pool_port}
auth_type=trust
auth_file={root / 'users.txt'}
pidfile={root / 'pgbouncer.pid'}
logfile={root / 'pgbouncer.log'}
unix_socket_dir={sock}
admin_users=user
max_client_conn=100
default_pool_size=4
""")
        process = subprocess.Popen([str(pgbouncer), str(config)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        pool_started = True
        deadline = time.time() + 10
        while time.time() < deadline:
            try:
                with socket.create_connection(("127.0.0.1", pool_port), timeout=.2): break
            except OSError: time.sleep(.05)
        else: raise RuntimeError("PgBouncer did not start")
        session_dsn = f"postgresql://user@127.0.0.1:{pool_port}/session"
        transaction_dsn = f"postgresql://user@127.0.0.1:{pool_port}/transaction"
        with psycopg.connect(session_dsn, autocommit=True) as listener, psycopg.connect(session_dsn, autocommit=True) as sender:
            listener.execute("LISTEN chimera_probe")
            listener.execute("SET application_name='chimera-session-probe'")
            listener.execute("CREATE TEMP TABLE chimera_temp(value int)")
            listener.execute("INSERT INTO chimera_temp VALUES (1)")
            lock = listener.execute("SELECT pg_try_advisory_lock(919191)").fetchone()[0]
            sender.execute("NOTIFY chimera_probe, 'ok'")
            notification = next(listener.notifies(timeout=3), None)
            app_name = listener.execute("SHOW application_name").fetchone()[0]
            temp_count = listener.execute("SELECT count(*) FROM chimera_temp").fetchone()[0]
            lock_still_held = not sender.execute("SELECT pg_try_advisory_lock(919191)").fetchone()[0]
            listener.execute("SELECT pg_advisory_unlock(919191)")
        with psycopg.connect(transaction_dsn, autocommit=True) as transaction:
            query_ok = transaction.execute("SELECT 1").fetchone()[0] == 1
        result = {
            "schema_version": "chimera.pgbouncer-carveout.v1",
            "postgres_version": subprocess.check_output([str(pg_bin / "postgres"), "--version"], text=True).strip(),
            "pgbouncer_version": subprocess.check_output([str(pgbouncer), "--version"], text=True).splitlines()[0],
            "transaction_query_ok": query_ok,
            "session_listen_notify_ok": bool(notification and notification.payload == "ok"),
            "session_persistent_set_ok": app_name == "chimera-session-probe",
            "session_temp_table_ok": temp_count == 1,
            "session_advisory_lock_ok": bool(lock and lock_still_held),
            "selected_architecture": "PgBouncer transaction pool for stateless queries plus session/direct carve-out for session-bound features",
            "automatic_enablement": False,
            "manual_promotion_required": True,
        }
        result["all_passed"] = all(value for key, value in result.items() if key.endswith("_ok"))
        return result
    finally:
        if pool_started:
            try: process.terminate(); process.wait(timeout=5)
            except Exception: process.kill()
        if pg_started:
            subprocess.run([str(pg_bin / "pg_ctl"), "-D", str(data), "-m", "immediate", "stop"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        shutil.rmtree(root, ignore_errors=True)


def main() -> int:
    parser=argparse.ArgumentParser();parser.add_argument("--results",type=pathlib.Path,required=True);args=parser.parse_args()
    result=run();args.results.parent.mkdir(parents=True,exist_ok=True);tmp=args.results.with_suffix('.tmp');tmp.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');os.replace(tmp,args.results);print(json.dumps(result,sort_keys=True));return 0 if result['all_passed'] else 1

if __name__ == '__main__': raise SystemExit(main())
