#!/usr/bin/env python3
"""GCF wire-use certification campaign."""
from __future__ import annotations

import argparse
import json
import os
import pathlib

from chimera.wire import GCF_AVAILABLE, WireCodec


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    args = parser.parse_args()
    codec = WireCodec(default="auto")
    graph_hits = [
        {"id": f"func:pkg/service.py:handler_{i}", "kind": "Function", "file": "pkg/service.py", "name": f"handler_{i}", "label": f"handler_{i}", "description": "handles request and calls shared validator"}
        for i in range(40)
    ]
    generic = {
        "rows": [
            {"path": "pkg/service.py", "symbol": f"handler_{i}", "kind": "Function", "line": i + 1, "evidence": "same repeated evidence payload"}
            for i in range(60)
        ]
    }
    graph = codec.encode_graph(graph_hits, session_key="gcf-campaign", mode="gcf")
    generic_envelope = codec.encode_generic(generic, mode="gcf")
    decoded_graph = codec.decode(graph.model_text())
    decoded_generic = codec.decode(generic_envelope.model_text())
    evidence = {
        "schema_version": "chimera.gcf-wire-campaign.v1",
        "gcf_available": GCF_AVAILABLE,
        "graph_format": graph.format,
        "generic_format": generic_envelope.format,
        "graph_source_bytes": graph.source_bytes,
        "graph_wire_bytes": graph.wire_bytes,
        "graph_reduction": graph.reduction,
        "generic_source_bytes": generic_envelope.source_bytes,
        "generic_wire_bytes": generic_envelope.wire_bytes,
        "generic_reduction": generic_envelope.reduction,
        "graph_decode_nonempty": bool(decoded_graph),
        "generic_decode_nonempty": bool(decoded_generic),
        "model_boundary_only": True,
        "durable_evidence_stays_json": True,
        "relevant_surfaces": [
            "WireCodec.encode_graph",
            "WireCodec.encode_generic",
            "rlm_loop_transcript.materialize_tool_transcript",
            "mcp_proxy.GCFMCPProxy",
            "mcp_server wire_format=json|gcf|auto",
            "cli wire encode/decode/stats",
        ],
        "limits": [
            "GCF is used at model/tool boundaries; durable receipts remain JSON.",
            "Savings depend on payload shape; codec falls back to JSON when GCF is unavailable or not smaller.",
        ],
    }
    evidence["all_passed"] = bool(
        evidence["gcf_available"]
        and evidence["graph_format"] in {"gcf", "json"}
        and evidence["generic_format"] in {"gcf", "json"}
        and evidence["graph_decode_nonempty"]
        and evidence["generic_decode_nonempty"]
        and evidence["model_boundary_only"]
        and evidence["durable_evidence_stays_json"]
    )
    args.results.parent.mkdir(parents=True, exist_ok=True)
    tmp = args.results.with_suffix(".tmp")
    tmp.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n")
    os.replace(tmp, args.results)
    print(json.dumps(evidence, sort_keys=True))
    return 0 if evidence["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
