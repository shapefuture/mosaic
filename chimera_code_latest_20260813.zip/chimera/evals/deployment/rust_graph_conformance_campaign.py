#!/usr/bin/env python3
"""Build the pinned Rust mirror and compare it with Python CodeGraph."""

from __future__ import annotations

import argparse
import json
import os
import pathlib
import subprocess

from chimera.rust_graph_mirror import RustGraphMirror


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    parser.add_argument(
        "--project",
        type=pathlib.Path,
        default=pathlib.Path("polyglot/rust_graph_mirror"),
    )
    args = parser.parse_args()
    root = pathlib.Path(__file__).resolve().parents[2]
    project = (root / args.project).resolve()
    subprocess.run(
        ["cargo", "build", "--release", "--locked", "--quiet"],
        cwd=project,
        check=True,
        timeout=300,
    )
    binary = project / "target/release/chimera-rust-graph-mirror"
    receipt = RustGraphMirror(root, binary).conformance()
    evidence = {
        "schema_version": "chimera.rust-graph-conformance-campaign.v1",
        "rustc_version": subprocess.check_output(
            ["rustc", "--version"], text=True, timeout=10
        ).strip(),
        "cargo_version": subprocess.check_output(
            ["cargo", "--version"], text=True, timeout=10
        ).strip(),
        "receipt": receipt.model_dump(mode="json"),
        "exact_symbol_conformance": receipt.precision == receipt.recall == 1.0,
        "exact_contains_conformance": (
            receipt.contains_precision == receipt.contains_recall == 1.0
        ),
        "exact_calls_conformance": (
            receipt.calls_precision == receipt.calls_recall == 1.0
            and receipt.calls_edges_mirrored
        ),
        "automatic_enablement": False,
        "manual_promotion_required": True,
        "limits": [
            "Rust remains a mirror and is not an authoritative production replacement.",
            "Incremental updates, watch behavior, BM25 search, and persisted-index behavior are not mirrored.",
            "This campaign runs on one Linux x86_64 host and is not cross-platform evidence.",
        ],
    }
    evidence["all_passed"] = all(
        evidence[key]
        for key in (
            "exact_symbol_conformance",
            "exact_contains_conformance",
            "exact_calls_conformance",
        )
    )
    args.results.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.results.with_suffix(".tmp")
    temporary.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n")
    os.replace(temporary, args.results)
    print(json.dumps(evidence, sort_keys=True))
    return 0 if evidence["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
