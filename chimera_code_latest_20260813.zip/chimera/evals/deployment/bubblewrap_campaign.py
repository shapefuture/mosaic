#!/usr/bin/env python3
"""Host-local Bubblewrap filesystem, network, and process isolation campaign."""

from __future__ import annotations

import argparse
import json
import os
import pathlib
import platform
import shutil
import subprocess
import tempfile

from chimera.sandbox_certification import (
    MaterializedBubblewrapCertifier,
    OverlayBubblewrapCertifier,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    args = parser.parse_args()
    binary = shutil.which("bwrap")
    if binary is None:
        raise RuntimeError("Bubblewrap is unavailable")
    root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-bwrap-campaign-"))
    try:
        materialized = MaterializedBubblewrapCertifier(root).run()
        overlay = OverlayBubblewrapCertifier(root).run()
        evidence = {
            "schema_version": "chimera.bubblewrap-campaign.v1",
            "bubblewrap_version": subprocess.check_output(
                [binary, "--version"], text=True, timeout=10
            ).strip(),
            "host": {
                "system": platform.system(),
                "machine": platform.machine(),
                "kernel": platform.release(),
            },
            "materialized": materialized.model_dump(mode="json"),
            "overlay": overlay.model_dump(mode="json"),
            "automatic_enablement": False,
            "manual_promotion_required": True,
            "limits": [
                "Host-local Linux namespace evidence on one kernel, not VM or physical-host isolation.",
                "This does not certify Kata Containers, Firecracker, or rootless gVisor.",
            ],
        }
        evidence["all_passed"] = bool(materialized.certified and overlay.certified)
        args.results.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.results.with_suffix(".tmp")
        temporary.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n")
        os.replace(temporary, args.results)
        print(json.dumps(evidence, sort_keys=True))
        return 0 if evidence["all_passed"] else 1
    finally:
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
