#!/usr/bin/env python3
"""Rust graph lexical search/retrieval parity campaign.

This certifies a bounded Rust symbol-search command against Python CodeGraph on a
small labeled corpus.  It is not full production retrieval parity: structural
expansion, call-neighborhood retrieval, persistent search index, and large-corpus
semantic retrieval remain separate gates.
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
from typing import Any

from chimera.graph import CodeGraph
from chimera.rust_graph_mirror import RustGraphMirror


def _write(path: pathlib.Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _key(row: Any) -> tuple[str, str, str]:
    if isinstance(row, dict):
        return (str(row.get("file")), str(row.get("kind")), str(row.get("name")))
    return (row.path, row.kind, row.name)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    parser.add_argument("--project", type=pathlib.Path, default=pathlib.Path("polyglot/rust_graph_mirror"))
    args = parser.parse_args()
    repo = pathlib.Path(__file__).resolve().parents[2]
    project = (repo / args.project).resolve()
    subprocess.run(["cargo", "build", "--release", "--locked", "--quiet"], cwd=project, check=True, timeout=300)
    binary = project / "target/release/chimera-rust-graph-mirror"
    root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-rust-search-"))
    try:
        _write(root / "pkg" / "api.py", """
class User:
    def valid(self):
        return True

def authenticate_user(user):
    return user.valid()

def route_request(user):
    return authenticate_user(user)
""".lstrip())
        _write(root / "pkg" / "inventory.py", """
def reconcile_inventory(items):
    return sum(items)

def inventory_report(items):
    return reconcile_inventory(items)
""".lstrip())
        _write(root / "web" / "service.ts", """
export interface Record { id: string }
export function loadRecord(): boolean { return true }
export function renderRecord(): boolean { return loadRecord() }
""".lstrip())
        graph = CodeGraph(root)
        graph.build(persist=False)
        mirror = RustGraphMirror(root, binary)
        cases = [
            {"query": "authenticate user", "expected": ("pkg/api.py", "Function", "authenticate_user")},
            {"query": "route request", "expected": ("pkg/api.py", "Function", "route_request")},
            {"query": "User", "expected": ("pkg/api.py", "Class", "User")},
            {"query": "inventory report", "expected": ("pkg/inventory.py", "Function", "inventory_report")},
            {"query": "reconcile inventory", "expected": ("pkg/inventory.py", "Function", "reconcile_inventory")},
            {"query": "loadRecord", "expected": ("web/service.ts", "Function", "loadRecord")},
            {"query": "Record", "expected": ("web/service.ts", "Class", "Record")},
        ]
        rows = []
        for case in cases:
            query = str(case["query"])
            expected = tuple(case["expected"])
            rust_hits = [_key(row) for row in mirror.search(query, limit=5)]
            python_hits = [_key(row) for row in graph.search(query, limit=5)]
            row = {
                "query": query,
                "expected": list(expected),
                "rust_hits": [list(item) for item in rust_hits],
                "python_hits": [list(item) for item in python_hits],
                "rust_expected_top5": expected in rust_hits,
                "python_expected_top5": expected in python_hits,
                "top1_equal": bool(rust_hits and python_hits and rust_hits[0] == python_hits[0]),
                "overlap_top5": len(set(rust_hits) & set(python_hits)),
            }
            row["passed"] = row["rust_expected_top5"] and row["python_expected_top5"] and row["overlap_top5"] >= 1
            rows.append(row)
        evidence = {
            "schema_version": "chimera.rust-graph-search-campaign.v1",
            "rustc_version": subprocess.check_output(["rustc", "--version"], text=True, timeout=10).strip(),
            "cargo_version": subprocess.check_output(["cargo", "--version"], text=True, timeout=10).strip(),
            "cases": rows,
            "case_count": len(rows),
            "expected_recall_top5": sum(row["rust_expected_top5"] for row in rows) / max(1, len(rows)),
            "python_expected_recall_top5": sum(row["python_expected_top5"] for row in rows) / max(1, len(rows)),
            "top1_exact_rate": sum(row["top1_equal"] for row in rows) / max(1, len(rows)),
            "search_retrieval_certified": True,
            "bm25_exact_parity_certified": False,
            "structural_expansion_certified": False,
            "call_neighborhood_retrieval_certified": False,
            "semantic_retrieval_certified": False,
            "persisted_index_certified": False,
            "mirror_only": True,
            "production_replacement_authorized": False,
            "automatic_enablement": False,
            "manual_promotion_required": True,
            "limits": [
                "This certifies bounded lexical symbol-search recall on a labeled fixture, not exact BM25 ranking parity.",
                "Structural expansion, call-neighborhood retrieval, persisted-index search, and semantic retrieval remain uncertified.",
                "The Rust graph remains mirror-only until all promotion gates pass.",
            ],
        }
        evidence["all_passed"] = bool(
            all(row["passed"] for row in rows)
            and evidence["expected_recall_top5"] == 1.0
            and evidence["python_expected_recall_top5"] == 1.0
            and evidence["mirror_only"]
            and not evidence["production_replacement_authorized"]
        )
        args.results.parent.mkdir(parents=True, exist_ok=True)
        tmp = args.results.with_suffix(".tmp")
        tmp.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, args.results)
        print(json.dumps(evidence, sort_keys=True))
        return 0 if evidence["all_passed"] else 1
    finally:
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
