#!/usr/bin/env python3
"""Rust graph persisted-index certification campaign."""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
from typing import Any

from chimera.rust_graph_mirror import RustGraphMirror, RustGraphCall, RustGraphSymbol
from chimera.semantic_code_intelligence import WorkspaceSnapshotter


def _write(path: pathlib.Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _symbol_set(rows: tuple[RustGraphSymbol, ...]) -> set[tuple[str, str, str]]:
    return {(row.path, row.kind, row.name) for row in rows}


def _call_set(rows: tuple[RustGraphCall, ...]) -> set[tuple[str, str, str]]:
    return {(row.path, row.caller, row.callee) for row in rows}


def _fails(command: list[str]) -> bool:
    result = subprocess.run(command, capture_output=True, text=True, timeout=60, check=False)
    return result.returncode != 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    parser.add_argument("--project", type=pathlib.Path, default=pathlib.Path("polyglot/rust_graph_mirror"))
    args = parser.parse_args()
    repo = pathlib.Path(__file__).resolve().parents[2]
    project = (repo / args.project).resolve()
    subprocess.run(["cargo", "build", "--release", "--locked", "--quiet"], cwd=project, check=True, timeout=300)
    binary = project / "target/release/chimera-rust-graph-mirror"
    root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-rust-index-"))
    try:
        _write(root / "pkg" / "api.py", """
class User:
    def valid(self):
        return True

def authenticate_user(user):
    return user.valid()

def route_request(user):
    return authenticate_user(user)
""".lstrip())
        _write(root / "web" / "service.ts", """
export interface Record { id: string }
export function loadRecord(): boolean { return true }
""".lstrip())
        mirror = RustGraphMirror(root, binary)
        digest = WorkspaceSnapshotter(root).capture().digest
        index_path = root / ".chimera" / "rust-graph.index"
        live_symbols, live_calls = mirror._scan_all()
        mirror.save_index(index_path, digest)
        loaded_symbols, loaded_calls = mirror.load_index(index_path, digest)
        live_search = [hit.model_dump(mode="json") for hit in mirror.search("authenticate user", limit=5)]
        loaded_search = [hit.model_dump(mode="json") for hit in mirror.search_index(index_path, digest, "authenticate user", limit=5)]
        stale_digest = "sha256:" + "0" * 64
        stale_rejected = _fails([str(binary), "--load-index", str(index_path), stale_digest])
        search_stale_rejected = _fails([str(binary), "--search-index", str(index_path), stale_digest, "User", "5"])
        corrupt_path = root / ".chimera" / "corrupt.index"
        corrupt_path.write_text("CHIMERA_RUST_GRAPH_INDEX_V1\nSOURCE\t" + digest + "\nROWS\nBAD\tROW\nEND\n")
        corrupt_rejected = _fails([str(binary), "--load-index", str(corrupt_path), digest])
        version_path = root / ".chimera" / "version.index"
        version_path.write_text(index_path.read_text().replace("CHIMERA_RUST_GRAPH_INDEX_V1", "CHIMERA_RUST_GRAPH_INDEX_V0", 1))
        version_rejected = _fails([str(binary), "--load-index", str(version_path), digest])
        unterminated_path = root / ".chimera" / "unterminated.index"
        unterminated_path.write_text("CHIMERA_RUST_GRAPH_INDEX_V1\nSOURCE\t" + digest + "\nROWS\n")
        unterminated_rejected = _fails([str(binary), "--load-index", str(unterminated_path), digest])
        _write(root / "pkg" / "new_file.py", "def newly_added():\n    return 3\n")
        new_digest = WorkspaceSnapshotter(root).capture().digest
        modified_source_rejected = _fails([str(binary), "--load-index", str(index_path), new_digest])
        evidence: dict[str, Any] = {
            "schema_version": "chimera.rust-graph-persisted-index-campaign.v1",
            "rustc_version": subprocess.check_output(["rustc", "--version"], text=True, timeout=10).strip(),
            "cargo_version": subprocess.check_output(["cargo", "--version"], text=True, timeout=10).strip(),
            "source_snapshot_digest": digest,
            "index_size": index_path.stat().st_size,
            "save_load_symbols_exact": _symbol_set(live_symbols) == _symbol_set(loaded_symbols),
            "save_load_calls_exact": _call_set(live_calls) == _call_set(loaded_calls),
            "search_index_matches_live_top1": bool(live_search and loaded_search and live_search[0]["path"] == loaded_search[0]["path"] and live_search[0]["name"] == loaded_search[0]["name"]),
            "stale_digest_rejected": stale_rejected,
            "search_stale_digest_rejected": search_stale_rejected,
            "modified_source_digest_rejected": modified_source_rejected,
            "corrupt_index_rejected": corrupt_rejected,
            "version_drift_rejected": version_rejected,
            "unterminated_index_rejected": unterminated_rejected,
            "persisted_index_certified": True,
            "mirror_only": True,
            "production_replacement_authorized": False,
            "automatic_enablement": False,
            "manual_promotion_required": True,
            "limits": [
                "The index is a minimal line-oriented Rust mirror format, not yet the production CodeGraph store.",
                "This certifies save/load/search fail-closed behavior for one local fixture and digest supplied by the caller.",
                "Runtime adapter integration, broader corpus, and cross-platform behavior remain separate gates.",
            ],
        }
        required = [
            "save_load_symbols_exact",
            "save_load_calls_exact",
            "search_index_matches_live_top1",
            "stale_digest_rejected",
            "search_stale_digest_rejected",
            "modified_source_digest_rejected",
            "corrupt_index_rejected",
            "version_drift_rejected",
            "unterminated_index_rejected",
        ]
        evidence["all_passed"] = all(bool(evidence[key]) for key in required) and evidence["mirror_only"] and not evidence["production_replacement_authorized"]
        args.results.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.results.with_suffix(".tmp")
        temporary.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, args.results)
        print(json.dumps(evidence, sort_keys=True))
        return 0 if evidence["all_passed"] else 1
    finally:
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
