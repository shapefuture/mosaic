#!/usr/bin/env python3
"""Disposable PostgreSQL campaign for shared cloud event/lease/quota/session/outbox laws."""

from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import socket
import subprocess
import tempfile
import time

from chimera.cloud_state import PostgresCloudStateAdapter


def postgres_bin() -> pathlib.Path:
    for path in sorted(pathlib.Path("/usr/lib/postgresql").glob("*/bin"), reverse=True):
        if (path / "postgres").exists():
            return path
    raise RuntimeError("PostgreSQL server binaries are unavailable")


def free_port() -> int:
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        return int(listener.getsockname()[1])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    args = parser.parse_args()
    root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-cloud-state-"))
    data = root / "data"
    sockets = root / "sock"
    sockets.mkdir()
    port = free_port()
    pg = postgres_bin()
    started = False
    try:
        subprocess.run(
            [
                str(pg / "initdb"),
                "-D",
                str(data),
                "--no-locale",
                "--encoding=UTF8",
                "--auth=trust",
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            timeout=60,
        )
        subprocess.run(
            [
                str(pg / "pg_ctl"),
                "-D",
                str(data),
                "-l",
                str(root / "postgres.log"),
                "-o",
                f"-h 127.0.0.1 -k {sockets} -p {port} -F",
                "-w",
                "start",
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            timeout=60,
        )
        started = True
        adapter = PostgresCloudStateAdapter(
            f"postgresql+psycopg://user@127.0.0.1:{port}/postgres"
        )
        tenant = "a" * 64
        other_tenant = "b" * 64
        seq = adapter.append_event(tenant_key=tenant, kind="test", data={"ok": True})
        tenant_events = adapter.replay_events(tenant_key=tenant)
        isolated_events = adapter.replay_events(tenant_key=other_tenant)
        lease = adapter.acquire_lease("workspace", "worker-a", 10, tenant_key=tenant)
        blocked_lease = adapter.acquire_lease(
            "workspace", "worker-b", 10, tenant_key=tenant
        )
        lease_released = bool(
            lease
            and adapter.release_lease(
                "workspace", "worker-a", lease.fencing_token, tenant_key=tenant
            )
        )
        admitted = adapter.admit(
            tenant_key=tenant,
            run_id="run:a",
            max_active_runs=1,
            expires_at=time.time() + 60,
        )
        quota_blocked = adapter.admit(
            tenant_key=tenant,
            run_id="run:b",
            max_active_runs=1,
            expires_at=time.time() + 60,
        )
        adapter.release(tenant_key=tenant, run_id="run:a")
        first_version = adapter.put_session(
            tenant_key=tenant,
            session_id="session:a",
            payload={"state": "open"},
            expected_version=None,
        )
        second_version = adapter.put_session(
            tenant_key=tenant,
            session_id="session:a",
            payload={"state": "done"},
            expected_version=first_version,
        )
        session = adapter.get_session(tenant_key=tenant, session_id="session:a")
        wait_version = adapter.register_wait(
            tenant_key=tenant,
            wait_id="wait:a",
            run_id="run:a",
            deadline=time.time() + 60,
            payload={"kind": "approval"},
        )
        pending_waits = adapter.pending_waits(tenant_key=tenant, run_id="run:a")
        wait_terminal_version = adapter.transition_wait(
            tenant_key=tenant,
            wait_id="wait:a",
            expected_version=wait_version,
            state="resolved",
            payload={"evidence_ref": "artifact:approval"},
        )
        outbox_id = adapter.enqueue_outbox(
            tenant_key=tenant, kind="telemetry", payload={"latency_ms": 1}
        )
        claims = adapter.claim_outbox()
        adapter.finish_outbox(outbox_id)
        adapter.close()
        evidence = {
            "schema_version": "chimera.cloud-state-postgres-campaign.v1",
            "postgres_version": subprocess.check_output(
                [str(pg / "postgres"), "--version"], text=True, timeout=10
            ).strip(),
            "event_append_replay": (
                len(tenant_events) == 1
                and tenant_events[0]["seq"] == seq
                and tenant_events[0]["data"] == {"ok": True}
            ),
            "tenant_event_isolation": isolated_events == [],
            "lease_fencing": bool(lease and lease.fencing_token == 1),
            "lease_exclusion": blocked_lease is None,
            "lease_release": lease_released,
            "atomic_quota": admitted.allowed and not quota_blocked.allowed,
            "session_compare_and_swap": second_version == 2
            and session == (2, {"state": "done"}),
            "wait_compare_and_swap": (
                wait_terminal_version == 2
                and len(pending_waits) == 1
                and pending_waits[0]["version"] == 1
            ),
            "outbox_skip_locked_claim": bool(claims and claims[0].id == outbox_id),
            "automatic_enablement": False,
            "manual_cloud_promotion_required": True,
            "limits": [
                "Disposable single-host PostgreSQL; not a managed-cloud or physical multi-host drill.",
                "RLS DDL is implemented but requires a separate least-privilege deployment-role campaign.",
            ],
        }
        evidence["all_passed"] = all(
            value
            for key, value in evidence.items()
            if key
            in {
                "event_append_replay",
                "tenant_event_isolation",
                "lease_fencing",
                "lease_exclusion",
                "lease_release",
                "atomic_quota",
                "session_compare_and_swap",
                "wait_compare_and_swap",
                "outbox_skip_locked_claim",
            }
        )
        args.results.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.results.with_suffix(".tmp")
        temporary.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n")
        os.replace(temporary, args.results)
        print(json.dumps(evidence, sort_keys=True))
        return 0 if evidence["all_passed"] else 1
    finally:
        if started:
            subprocess.run(
                [str(pg / "pg_ctl"), "-D", str(data), "-m", "immediate", "stop"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=30,
                check=False,
            )
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
