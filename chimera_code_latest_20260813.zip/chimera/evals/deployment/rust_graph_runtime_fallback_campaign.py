#!/usr/bin/env python3
"""Rust graph runtime fallback drills."""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import subprocess
import tempfile

from chimera.rust_graph_runtime_adapter import RustGraphRuntimeAdapter


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    parser.add_argument("--project", type=pathlib.Path, default=pathlib.Path("polyglot/rust_graph_mirror"))
    args = parser.parse_args()
    repo = pathlib.Path(__file__).resolve().parents[2]
    project = (repo / args.project).resolve()
    subprocess.run(["cargo", "build", "--release", "--locked", "--quiet"], cwd=project, check=True, timeout=300)
    binary = project / "target/release/chimera-rust-graph-mirror"
    root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-rust-runtime-fallback-"))
    try:
        (root / "api.py").write_text("def route_request():\n    return 1\n", encoding="utf-8")
        default_result = RustGraphRuntimeAdapter(root, binary=binary).search("route request")
        missing_binary_result = RustGraphRuntimeAdapter(root, binary=pathlib.Path("/missing/rust-graph")).search("route request", use_mirror=True)
        failing = root / "failing-rust-graph"
        failing.write_text("#!/bin/sh\necho broken >&2\nexit 42\n", encoding="utf-8")
        failing.chmod(0o755)
        failing_result = RustGraphRuntimeAdapter(root, binary=failing).search("route request", use_mirror=True)
        mirror_result = RustGraphRuntimeAdapter(repo, binary=binary).search("RustGraphRuntimeAdapter", use_mirror=True)
        evidence = {
            "schema_version": "chimera.rust-graph-runtime-fallback-campaign.v1",
            "default_backend_python": default_result["backend"] == "python",
            "missing_binary_fallback": missing_binary_result["backend"] == "python-fallback",
            "failing_binary_fallback": failing_result["backend"] == "python-fallback",
            "fallback_preserves_hits": any(hit.get("name") == "route_request" for hit in default_result["hits"]),
            "mirror_explicit_backend_allowed": mirror_result["backend"] in {"rust-mirror", "python-fallback"},
            "mirror_explicit_not_production_authorized": mirror_result.get("production_replacement_authorized") is False or mirror_result["backend"] == "python-fallback",
            "mirror_only": True,
            "production_replacement_authorized": False,
            "limits": [
                "Runtime adapter defaults to Python and uses Rust only when explicitly requested as a mirror.",
                "Fallback was exercised for missing and failing Rust binaries.",
                "This is not an authoritative Rust backend promotion drill.",
            ],
        }
        required = [
            "default_backend_python",
            "missing_binary_fallback",
            "failing_binary_fallback",
            "fallback_preserves_hits",
            "mirror_explicit_backend_allowed",
            "mirror_explicit_not_production_authorized",
        ]
        evidence["all_passed"] = all(evidence[key] for key in required) and evidence["mirror_only"] and not evidence["production_replacement_authorized"]
        args.results.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.results.with_suffix(".tmp")
        temporary.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, args.results)
        print(json.dumps(evidence, sort_keys=True))
        return 0 if evidence["all_passed"] else 1
    finally:
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
