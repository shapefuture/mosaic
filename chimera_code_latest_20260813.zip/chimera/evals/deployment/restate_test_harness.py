"""Best-effort pinned Restate test harness for optional integration tests.

This module is intentionally test/eval support. It starts the same pinned local
Restate server and packaged Chimera fixture service used by the campaign when a
caller has not provided CHIMERA_RESTATE_INGRESS.
"""
from __future__ import annotations

import atexit
import json
import os
import pathlib
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

_RESTATE: "RestateTestHarness | None" = None


class RestateTestHarness:
    def __init__(self, *, binary: pathlib.Path | None = None) -> None:
        self.root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-restate-pytest-"))
        self.binary = binary or self._default_binary()
        self.service: subprocess.Popen | None = None
        self.server: subprocess.Popen | None = None
        self.service_log = (self.root / "service.log").open("wb")
        self.server_log = (self.root / "server.log").open("ab")
        self.repo_root = pathlib.Path(__file__).resolve().parents[2]
        self.ingress = "http://127.0.0.1:8080"

    @staticmethod
    def _default_binary() -> pathlib.Path:
        candidates = [
            pathlib.Path(os.environ.get("CHIMERA_RESTATE_SERVER_BINARY", "")),
            pathlib.Path("/tmp/restate-1.7.3/restate-server-x86_64-unknown-linux-musl/restate-server"),
            pathlib.Path("/tmp/restate-server-x86_64-unknown-linux-musl/restate-server"),
        ]
        for candidate in candidates:
            if str(candidate) and candidate.is_file():
                return candidate
        raise FileNotFoundError("pinned Restate 1.7.3 server binary is unavailable")

    @staticmethod
    def _wait_port(port: int, process: subprocess.Popen, timeout: float = 45.0) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeError(f"process exited before port {port} became ready")
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                    return
            except OSError:
                time.sleep(0.1)
        raise TimeoutError(f"port {port} did not become ready")

    @staticmethod
    def _request_json(url: str, value: dict | None = None) -> dict:
        body = None if value is None else json.dumps(value).encode()
        request = urllib.request.Request(
            url,
            data=body,
            headers={"content-type": "application/json"} if body is not None else {},
            method="POST" if body is not None else "GET",
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            parsed = json.load(response)
        if not isinstance(parsed, dict):
            raise TypeError("Restate admin API returned a non-object")
        return parsed

    def start(self) -> str:
        version = subprocess.check_output([str(self.binary), "--version"], text=True, timeout=10).strip()
        if version != "restate-server 1.7.3":
            raise RuntimeError(f"expected Restate 1.7.3, observed {version}")
        env = {**os.environ, "PYTHONPATH": str(self.repo_root)}
        self.service = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "evals.deployment.restate_fixture_service:app",
                "--host",
                "127.0.0.1",
                "--port",
                "9080",
            ],
            cwd=self.repo_root,
            env=env,
            stdout=self.service_log,
            stderr=subprocess.STDOUT,
        )
        self._wait_port(9080, self.service)
        data = self.root / "server"
        data.mkdir(exist_ok=True)
        self.server = subprocess.Popen(
            [
                str(self.binary),
                "--no-logo",
                "--listen-mode",
                "tcp",
                "--bind-ip",
                "127.0.0.1",
            ],
            cwd=data,
            stdout=self.server_log,
            stderr=subprocess.STDOUT,
        )
        self._wait_port(9070, self.server, timeout=60)
        self._wait_port(8080, self.server, timeout=60)
        self._request_json(
            "http://127.0.0.1:9070/deployments",
            {"uri": "http://127.0.0.1:9080", "use_http_11": True},
        )
        return self.ingress

    def close(self) -> None:
        for process in (self.server, self.service):
            if process is not None and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)
        self.server_log.close()
        self.service_log.close()


def get_or_start_restate_ingress() -> str:
    """Return configured ingress or start the pinned local harness if possible."""
    configured = os.environ.get("CHIMERA_RESTATE_INGRESS")
    if configured:
        return configured
    global _RESTATE
    if _RESTATE is None:
        _RESTATE = RestateTestHarness()
        atexit.register(_RESTATE.close)
        os.environ["CHIMERA_RESTATE_INGRESS"] = _RESTATE.start()
    return _RESTATE.ingress
