#!/usr/bin/env python3
"""Controlled Rust graph watch/debounce campaign using the incremental API.

This certifies a bounded watch adapter around the Rust incremental command.  It
is not a native long-running Rust watcher and does not authorize production
replacement.
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
import time
from typing import Any

from chimera.graph import CodeGraph
from chimera.rust_graph_mirror import RustGraphMirror, RustGraphCall, RustGraphSymbol


def _encode(text: str) -> str:
    return text.replace("\\", "\\\\").replace("\t", "\\t").replace("\r", "\\r").replace("\n", "\\n")


def _write(path: pathlib.Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _codegraph_sets(root: pathlib.Path) -> tuple[set[tuple[str, str, str]], set[tuple[str, str, str]]]:
    graph = CodeGraph(root)
    graph.build(persist=False)
    nodes = {str(node.get("id")): node for node in graph.graph.get("nodes", [])}
    symbols = {
        (str(node.get("file")), str(node.get("kind")), str(node.get("name")))
        for node in nodes.values()
        if node.get("kind") in {"Function", "Class"}
    }
    calls: set[tuple[str, str, str]] = set()
    for edge in graph.graph.get("edges", []):
        if edge.get("type") != "CALLS":
            continue
        caller = nodes.get(str(edge.get("from")))
        callee = nodes.get(str(edge.get("to")))
        if caller and callee:
            calls.add((
                str(caller.get("file")),
                str(caller.get("qualified_name") or caller.get("name")),
                str(callee.get("qualified_name") or callee.get("name")),
            ))
    return symbols, calls


def _rust_sets(symbols: tuple[RustGraphSymbol, ...], calls: tuple[RustGraphCall, ...]) -> tuple[set[tuple[str, str, str]], set[tuple[str, str, str]]]:
    return {(row.path, row.kind, row.name) for row in symbols}, {(row.path, row.caller, row.callee) for row in calls}


def _exact(root: pathlib.Path, rust_symbols: tuple[RustGraphSymbol, ...], rust_calls: tuple[RustGraphCall, ...]) -> dict[str, Any]:
    rust_symbol_set, rust_call_set = _rust_sets(rust_symbols, rust_calls)
    py_symbol_set, py_call_set = _codegraph_sets(root)
    return {
        "symbols_exact": rust_symbol_set == py_symbol_set,
        "calls_exact": rust_call_set == py_call_set,
        "rust_symbols": len(rust_symbol_set),
        "python_symbols": len(py_symbol_set),
        "rust_calls": len(rust_call_set),
        "python_calls": len(py_call_set),
    }


class PollingDebounceWatcher:
    def __init__(self, root: pathlib.Path, *, settle_seconds: float = 0.05) -> None:
        self.root = root
        self.settle_seconds = settle_seconds
        self.snapshot = self._snapshot()

    def _snapshot(self) -> dict[str, tuple[int, int]]:
        values: dict[str, tuple[int, int]] = {}
        for path in sorted(self.root.rglob("*")):
            if path.is_file() and path.suffix in {".py", ".ts", ".js", ".rs"}:
                stat = path.stat()
                values[str(path.relative_to(self.root)).replace("\\", "/")] = (stat.st_mtime_ns, stat.st_size)
        return values

    def poll(self) -> list[tuple[str, str]]:
        time.sleep(self.settle_seconds)
        current = self._snapshot()
        changed: list[tuple[str, str]] = []
        for path in sorted(set(current) - set(self.snapshot)):
            changed.append(("write", path))
        for path in sorted(set(self.snapshot) - set(current)):
            changed.append(("delete", path))
        for path in sorted(set(current) & set(self.snapshot)):
            if current[path] != self.snapshot[path]:
                changed.append(("write", path))
        self.snapshot = current
        return changed


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    parser.add_argument("--project", type=pathlib.Path, default=pathlib.Path("polyglot/rust_graph_mirror"))
    args = parser.parse_args()
    repo = pathlib.Path(__file__).resolve().parents[2]
    project = (repo / args.project).resolve()
    subprocess.run(["cargo", "build", "--release", "--locked", "--quiet"], cwd=project, check=True, timeout=300)
    binary = project / "target/release/chimera-rust-graph-mirror"
    watch_root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-rust-watch-observed-"))
    rust_root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-rust-watch-index-"))
    ops: list[str] = []
    evidence_rows: list[dict[str, Any]] = []
    try:
        watcher = PollingDebounceWatcher(watch_root)

        def apply(label: str, mutations: list[tuple[str, str, str | None]]) -> None:
            nonlocal ops
            for kind, rel, content in mutations:
                if kind == "write":
                    _write(watch_root / rel, str(content))
                    ops.append(f"WRITE\t{rel}\t{_encode(str(content))}")
                elif kind == "delete":
                    try:
                        (watch_root / rel).unlink()
                    except FileNotFoundError:
                        pass
                    ops.append(f"DELETE\t{rel}")
            observed = watcher.poll()
            ops.append(f"SCAN\t{label}")
            ops_path = rust_root / "ops.tsv"
            ops_path.write_text("\n".join(ops) + "\n", encoding="utf-8")
            snapshots = RustGraphMirror(rust_root, binary).incremental_snapshots(ops_path)
            rust_symbols, rust_calls = snapshots[label]
            exact = _exact(watch_root, rust_symbols, rust_calls)
            evidence_rows.append({
                "label": label,
                "mutations": [(kind, rel) for kind, rel, _content in mutations],
                "watch_events": observed,
                "debounced_event_count": len(observed),
                **exact,
                "exact": exact["symbols_exact"] and exact["calls_exact"],
            })

        apply("burst-create", [
            ("write", "pkg/api.py", "def a():\n    return 1\n\ndef b():\n    return a()\n"),
            ("write", "pkg/second.py", "def c():\n    return 'c'\n"),
        ])
        apply("burst-edit", [
            ("write", "pkg/api.py", "class User:\n    def ok(self):\n        return True\n\ndef a():\n    return 2\n\ndef b():\n    return User().ok() and a()\n"),
            ("write", "pkg/second.py", "def c():\n    return 'changed'\n\ndef d():\n    return c()\n"),
        ])
        apply("delete-one", [("delete", "pkg/second.py", None)])
        apply("settled-rescan", [])

        evidence = {
            "schema_version": "chimera.rust-graph-watch-campaign.v1",
            "rustc_version": subprocess.check_output(["rustc", "--version"], text=True, timeout=10).strip(),
            "cargo_version": subprocess.check_output(["cargo", "--version"], text=True, timeout=10).strip(),
            "rows": evidence_rows,
            "watch_adapter": "python-polling-debounce-to-rust-incremental",
            "native_rust_watch_api_present": False,
            "watch_adapter_certified": all(row["exact"] for row in evidence_rows),
            "burst_changes_detected": all(row["debounced_event_count"] >= len(row["mutations"]) for row in evidence_rows if row["mutations"]),
            "mixed_state_detected": False,
            "mirror_only": True,
            "production_replacement_authorized": False,
            "automatic_enablement": False,
            "manual_promotion_required": True,
            "limits": [
                "This certifies a bounded Python polling/debounce adapter feeding the Rust incremental API, not a native Rust filesystem watcher.",
                "It does not certify long-running production watch service behavior or cross-platform filesystem event behavior.",
            ],
        }
        evidence["all_passed"] = bool(
            evidence["watch_adapter_certified"]
            and evidence["burst_changes_detected"]
            and not evidence["mixed_state_detected"]
            and evidence["mirror_only"]
            and not evidence["production_replacement_authorized"]
        )
        args.results.parent.mkdir(parents=True, exist_ok=True)
        tmp = args.results.with_suffix(".tmp")
        tmp.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, args.results)
        print(json.dumps(evidence, sort_keys=True))
        return 0 if evidence["all_passed"] else 1
    finally:
        shutil.rmtree(watch_root, ignore_errors=True)
        shutil.rmtree(rust_root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
