#!/usr/bin/env python3
"""Separate-process worker for DBOS shared PostgreSQL CAS evidence."""
from __future__ import annotations
import argparse,json,pathlib
from chimera.dbos_durable_workflow import DBOSAdapterConfig,DBOSDurableWorkflowPort
from chimera.shared_artifacts import PostgresContentAddressedArtifactStore

def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=('start','recover'),required=True);p.add_argument('--database-url',required=True);p.add_argument('--root',type=pathlib.Path,required=True);p.add_argument('--tenant',required=True);a=p.parse_args()
 store=PostgresContentAddressedArtifactStore(a.database_url);config=DBOSAdapterConfig(system_database_url=a.database_url,application_name='shared_cas_process_test',application_version='shared-cas-process-v1',system_pool_size=6,polling_concurrency=2)
 with DBOSDurableWorkflowPort(a.root,config,artifact_store=store) as port:
  if a.mode=='start':
   w=port.start(workflow_type='shared-process',input_identity='input',workflow_id='workflow:shared-cas-process',tenant_key=a.tenant);r=port.checkpoint(w,{'node':'process-a'},tenant_key=a.tenant)
  else:
   r=port.recover('workflow:shared-cas-process',tenant_key=a.tenant);assert r and r.checkpoint_ref;r=port.finish(r,state='completed',tenant_key=a.tenant)
 print(json.dumps({'id':r.id,'state':r.state,'checkpoint_ref':r.checkpoint_ref},sort_keys=True));store.close();return 0
if __name__=='__main__':raise SystemExit(main())
