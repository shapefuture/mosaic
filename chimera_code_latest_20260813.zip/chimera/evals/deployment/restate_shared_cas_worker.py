#!/usr/bin/env python3
"""Separate-process Restate adapter worker using PostgreSQL checkpoint CAS."""
from __future__ import annotations
import argparse,json,pathlib
from chimera.restate_durable_workflow import RestateAdapterConfig,RestateDurableWorkflowPort
from chimera.shared_artifacts import PostgresContentAddressedArtifactStore

def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=('start','recover'),required=True);p.add_argument('--database-url',required=True);p.add_argument('--ingress',required=True);p.add_argument('--root',type=pathlib.Path,required=True);p.add_argument('--tenant',required=True);p.add_argument('--workflow-id',required=True);a=p.parse_args()
 store=PostgresContentAddressedArtifactStore(a.database_url);port=RestateDurableWorkflowPort(a.root,RestateAdapterConfig(ingress_url=a.ingress),artifact_store=store)
 if a.mode=='start':
  w=port.start(workflow_type='shared-process',input_identity='input',workflow_id=a.workflow_id,tenant_key=a.tenant);r=port.checkpoint(w,{'node':'process-a'},idempotency_key='shared-cas-cp',tenant_key=a.tenant)
 else:
  r=port.recover(a.workflow_id,tenant_key=a.tenant);assert r and r.checkpoint_ref;r=port.finish(r,state='completed',idempotency_key='shared-cas-finish',tenant_key=a.tenant)
 print(json.dumps({'id':r.id,'state':r.state,'checkpoint_ref':r.checkpoint_ref},sort_keys=True));store.close();return 0
if __name__=='__main__':raise SystemExit(main())
