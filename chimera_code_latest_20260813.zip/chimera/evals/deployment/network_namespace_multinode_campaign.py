#!/usr/bin/env python3
"""Continue one DBOS/PostgreSQL workflow across two Linux network namespaces."""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import socket
import subprocess
import sys
import tempfile
import uuid
from collections.abc import Sequence


ROOT = pathlib.Path(__file__).resolve().parents[2]
WORKER = ROOT / "evals/deployment/dbos_shared_cas_worker.py"


def run(argv: Sequence[str], **kwargs) -> subprocess.CompletedProcess[str]:
    kwargs.setdefault("timeout", 60)
    result = subprocess.run(argv, text=True, capture_output=True, **kwargs)
    if result.returncode:
        raise RuntimeError(
            f"command failed {argv}: "
            f"stdout={result.stdout[-2_000:]} stderr={result.stderr[-4_000:]}"
        )
    return result


def pg_bin() -> pathlib.Path:
    for candidate in sorted(
        pathlib.Path("/usr/lib/postgresql").glob("*/bin"), reverse=True
    ):
        if (candidate / "initdb").is_file():
            return candidate
    raise RuntimeError("PostgreSQL is unavailable")


def free_port() -> int:
    with socket.socket() as listener:
        listener.bind(("0.0.0.0", 0))
        return int(listener.getsockname()[1])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=pathlib.Path, required=True)
    args = parser.parse_args()

    suffix = uuid.uuid4().hex[:6]
    namespace_a = "chimera-a-" + suffix
    namespace_b = "chimera-b-" + suffix
    host_link_a = "cha" + suffix
    host_link_b = "chb" + suffix
    namespace_link_a = "cna" + suffix
    namespace_link_b = "cnb" + suffix
    root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-netns-multinode-"))
    data = root / "data"
    socket_directory = root / "sock"
    socket_directory.mkdir()
    port = free_port()
    postgres = pg_bin()
    postgres_started = False

    try:
        run(
            [
                str(postgres / "initdb"),
                "-D",
                str(data),
                "--no-locale",
                "--encoding=UTF8",
                "--auth=trust",
            ]
        )
        with (data / "pg_hba.conf").open("a", encoding="utf-8") as handle:
            handle.write("\nhost all all 10.244.0.0/16 trust\n")
        subprocess.run(
            [
                str(postgres / "pg_ctl"),
                "-D",
                str(data),
                "-o",
                f"-k {socket_directory} -h 0.0.0.0 -p {port} -F",
                "-w",
                "start",
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=60,
        )
        postgres_started = True

        for namespace in (namespace_a, namespace_b):
            run(["sudo", "-n", "ip", "netns", "add", namespace])

        run(
            [
                "sudo", "-n", "ip", "link", "add", host_link_a,
                "type", "veth", "peer", "name", namespace_link_a,
            ]
        )
        run(
            [
                "sudo", "-n", "ip", "link", "set", namespace_link_a,
                "netns", namespace_a,
            ]
        )
        run(
            [
                "sudo", "-n", "ip", "addr", "add", "10.244.1.1/30",
                "dev", host_link_a,
            ]
        )
        run(["sudo", "-n", "ip", "link", "set", host_link_a, "up"])
        run(
            [
                "sudo", "-n", "ip", "netns", "exec", namespace_a,
                "ip", "addr", "add", "10.244.1.2/30", "dev",
                namespace_link_a,
            ]
        )
        run(
            [
                "sudo", "-n", "ip", "netns", "exec", namespace_a,
                "ip", "link", "set", namespace_link_a, "up",
            ]
        )
        run(
            [
                "sudo", "-n", "ip", "netns", "exec", namespace_a,
                "ip", "link", "set", "lo", "up",
            ]
        )

        run(
            [
                "sudo", "-n", "ip", "link", "add", host_link_b,
                "type", "veth", "peer", "name", namespace_link_b,
            ]
        )
        run(
            [
                "sudo", "-n", "ip", "link", "set", namespace_link_b,
                "netns", namespace_b,
            ]
        )
        run(
            [
                "sudo", "-n", "ip", "addr", "add", "10.244.2.1/30",
                "dev", host_link_b,
            ]
        )
        run(["sudo", "-n", "ip", "link", "set", host_link_b, "up"])
        run(
            [
                "sudo", "-n", "ip", "netns", "exec", namespace_b,
                "ip", "addr", "add", "10.244.2.2/30", "dev",
                namespace_link_b,
            ]
        )
        run(
            [
                "sudo", "-n", "ip", "netns", "exec", namespace_b,
                "ip", "link", "set", namespace_link_b, "up",
            ]
        )
        run(
            [
                "sudo", "-n", "ip", "netns", "exec", namespace_b,
                "ip", "link", "set", "lo", "up",
            ]
        )

        tenant = "tenant:" + "7" * 64
        base = ["sudo", "-n", "ip", "netns", "exec"]
        environment = ["env", f"PYTHONPATH={ROOT}"]
        url_a = f"postgresql+psycopg://user@10.244.1.1:{port}/postgres"
        url_b = f"postgresql+psycopg://user@10.244.2.1:{port}/postgres"
        common = ["--tenant", tenant]
        print("network namespaces ready", flush=True)
        first = run(
            [
                *base,
                namespace_a,
                *environment,
                sys.executable,
                str(WORKER),
                "--mode",
                "start",
                "--database-url",
                url_a,
                "--root",
                str(root / "node-a"),
                *common,
            ]
        )
        print("node A complete", flush=True)
        second = run(
            [
                *base,
                namespace_b,
                *environment,
                sys.executable,
                str(WORKER),
                "--mode",
                "recover",
                "--database-url",
                url_b,
                "--root",
                str(root / "node-b"),
                *common,
            ]
        )
        print("node B complete", flush=True)

        left = json.loads(first.stdout.splitlines()[-1])
        right = json.loads(second.stdout.splitlines()[-1])
        result = {
            "schema_version": "chimera.network-namespace-multinode.v1",
            "network_namespaces": 2,
            "separate_network_stacks": True,
            "separate_os_processes": True,
            "shared_postgres_cas": left["checkpoint_ref"] == right["checkpoint_ref"],
            "continued_to_terminal": right["state"] == "completed",
            "node_a_address": "10.244.1.2",
            "node_b_address": "10.244.2.2",
            "same_physical_kernel": True,
            "physical_hosts": 1,
            "physical_multihost_proven": False,
            "automatic_enablement": False,
            "manual_promotion_required": True,
            "limits": ["Same physical kernel/host; not two physical machines."],
        }
        result["all_passed"] = all(
            result[key]
            for key in (
                "separate_network_stacks",
                "separate_os_processes",
                "shared_postgres_cas",
                "continued_to_terminal",
            )
        )
        args.results.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.results.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(result, sort_keys=True, indent=2) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, args.results)
        print(json.dumps(result, sort_keys=True))
        return 0 if result["all_passed"] else 1
    finally:
        for namespace in (namespace_a, namespace_b):
            subprocess.run(
                ["sudo", "-n", "ip", "netns", "del", namespace],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=10,
                check=False,
            )
        for link in (host_link_a, host_link_b):
            subprocess.run(
                ["sudo", "-n", "ip", "link", "del", link],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=10,
                check=False,
            )
        if postgres_started:
            subprocess.run(
                [
                    str(postgres / "pg_ctl"),
                    "-D",
                    str(data),
                    "-m",
                    "immediate",
                    "stop",
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=30,
                check=False,
            )
        shutil.rmtree(root, ignore_errors=True)
        if root.exists():
            subprocess.run(
                ["sudo", "-n", "rm", "-rf", "--", str(root)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=10,
                check=False,
            )


if __name__ == "__main__":
    raise SystemExit(main())
