#!/usr/bin/env python3
"""Extended, fixture-based structural retrieval benchmark.

This complements the real-Chimera ten-symbol pilot with sealed cross-language,
malformed-source, import, and query-heavy synthetic fixtures.  It documents
capability gaps instead of mapping AST syntax matches to semantic-reference
claims.  ast-grep remains evaluation-only and is run only through the pinned
Bubblewrap path from ``structural_candidate_benchmark.py``.
"""
from __future__ import annotations

import argparse
import json
import pathlib
import runpy
import shutil
import statistics
import sys
import tempfile
import time
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parents[2]
BASE = pathlib.Path(__file__).with_name("structural_candidate_benchmark.py")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _write_fixture(root: pathlib.Path, *, generated_pairs: int = 160) -> list[dict[str, str]]:
    # The current Python graph is imported inside the same isolated fixture.
    # Copying only its source package gives the benchmark a runnable baseline
    # without granting the candidate access to the original workspace.
    shutil.copytree(ROOT / "chimera", root / "chimera", ignore=shutil.ignore_patterns("__pycache__"))
    (root / "py").mkdir(parents=True)
    (root / "ts").mkdir(parents=True)
    (root / "py" / "models.py").write_text("class User:\n    pass\n", encoding="utf-8")
    (root / "py" / "policy.py").write_text(
        "from py.models import User\n\n"
        "class PolicyEngine:\n"
        "    def authorize(self, user: User) -> bool:\n"
        "        return bool(user)\n\n"
        "def validate_token(value: str) -> bool:\n"
        "    return bool(value)\n\n"
        "def route(value: str) -> bool:\n"
        "    return validate_token(value)\n",
        encoding="utf-8",
    )
    (root / "py" / "malformed.py").write_text(
        "def stable_after_damage() -> int:\n    return 7\n\n"
        "def broken(:\n",
        encoding="utf-8",
    )
    (root / "ts" / "repository.ts").write_text(
        "export class UserRepository {\n"
        "  findById(id: string): string { return id }\n"
        "}\n"
        "export function makeUser(id: string) { return new UserRepository().findById(id) }\n",
        encoding="utf-8",
    )
    (root / "ts" / "malformed.ts").write_text(
        "export function stableAfterDamage(): number { return 7 }\n"
        "export function broken( {\n",
        encoding="utf-8",
    )
    for index in range(generated_pairs):
        (root / "py" / f"generated_{index}.py").write_text(
            f"class GeneratedPython{index}:\n"
            f"    def locate_{index}(self) -> int:\n        return {index}\n",
            encoding="utf-8",
        )
        (root / "ts" / f"generated_{index}.ts").write_text(
            f"export class GeneratedTypeScript{index} {{\n"
            f"  locate{index}(): number {{ return {index} }}\n"
            "}\n",
            encoding="utf-8",
        )
    return [
        {"id": "python-member", "query": "PolicyEngine authorize", "file": "py/policy.py", "class": "PolicyEngine", "member": "authorize"},
        {"id": "python-function", "query": "validate_token", "file": "py/policy.py", "class": "", "member": "validate_token"},
        {"id": "python-malformed", "query": "stable_after_damage", "file": "py/malformed.py", "class": "", "member": "stable_after_damage"},
        {"id": "typescript-member", "query": "UserRepository findById", "file": "ts/repository.ts", "class": "UserRepository", "member": "findById"},
        {"id": "typescript-function", "query": "makeUser", "file": "ts/repository.ts", "class": "", "member": "makeUser"},
        {"id": "typescript-malformed", "query": "stableAfterDamage", "file": "ts/malformed.ts", "class": "", "member": "stableAfterDamage"},
        {"id": "large-python-member", "query": f"GeneratedPython{generated_pairs - 1} locate_{generated_pairs - 1}", "file": f"py/generated_{generated_pairs - 1}.py", "class": f"GeneratedPython{generated_pairs - 1}", "member": f"locate_{generated_pairs - 1}"},
        {"id": "large-typescript-member", "query": f"GeneratedTypeScript{generated_pairs - 1} locate{generated_pairs - 1}", "file": f"ts/generated_{generated_pairs - 1}.ts", "class": f"GeneratedTypeScript{generated_pairs - 1}", "member": f"locate{generated_pairs - 1}"},
    ]


def _graph_query(api: dict[str, Any], workspace: pathlib.Path, candidate_dir: pathlib.Path, query: str) -> dict[str, Any]:
    code = (
        "import json,sys; from chimera.graph import CodeGraph; "
        "g=CodeGraph('.');g.load();print(json.dumps(g.search(sys.argv[1],limit=10),sort_keys=True))"
    )
    result = api["_run"](api["_bwrap_command"](
        workspace=workspace, candidate_dir=candidate_dir, writable_workspace=False,
        inner=[sys.executable, "-c", code, query],
    ))
    try:
        matches = json.loads(result["stdout"]) if result["status"] == 0 else []
    except json.JSONDecodeError:
        matches = []
    return {**{key: value for key, value in result.items() if key not in {"stdout", "stderr"}}, "matches": matches}


def _outline(api: dict[str, Any], workspace: pathlib.Path, candidate_dir: pathlib.Path) -> dict[str, Any]:
    result = api["_run"](api["_bwrap_command"](
        workspace=workspace, candidate_dir=candidate_dir, writable_workspace=False,
        inner=["/candidate/ast-grep", "outline", "--items", "all", "--view", "expanded", "--json=compact", "/workspace"],
    ), timeout=120)
    try:
        documents = json.loads(result["stdout"]) if result["status"] == 0 else []
    except json.JSONDecodeError:
        documents = []
    return {**{key: value for key, value in result.items() if key not in {"stdout", "stderr"}}, "documents": documents}


def _rel(raw: str) -> str:
    return str(raw).replace("\\", "/").removeprefix("/workspace/")


def _candidate_matches(documents: list[dict[str, Any]], case: dict[str, str]) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for document in documents:
        path = _rel(str(document.get("path", "")))
        for item in document.get("items", []):
            if case["class"]:
                if item.get("name") != case["class"]:
                    continue
                for member in item.get("members", []):
                    if member.get("name") == case["member"]:
                        output.append({"file": path, "line": int(member["range"]["start"]["line"]) + 1, "text": member.get("signature", "")})
            elif item.get("name") == case["member"]:
                output.append({"file": path, "line": int(item["range"]["start"]["line"]) + 1, "text": item.get("signature", "")})
    return output


def _snippet(root: pathlib.Path, path: str, line: int) -> str:
    values = (root / path).read_text(encoding="utf-8", errors="replace").splitlines()
    return "\n".join(values[max(0, line - 1):max(0, line - 1) + 12])


def _hit_graph(matches: list[dict[str, Any]], case: dict[str, str]) -> bool:
    if case["class"]:
        expected = f"{case['class']}.{case['member']}"
        return any(row.get("file") == case["file"] and row.get("qualified_name") == expected for row in matches)
    return any(row.get("file") == case["file"] and row.get("name") == case["member"] for row in matches)


def _measure_query_heavy(api: dict[str, Any], workspace: pathlib.Path, candidate_dir: pathlib.Path, cases: list[dict[str, str]], repetitions: int) -> dict[str, float]:
    queries = [case["query"] for case in cases] * repetitions
    graph_code = (
        "import json,sys;from chimera.graph import CodeGraph;"
        "g=CodeGraph('.');g.load();qs=json.loads(sys.argv[1]);"
        "[g.search(q,limit=10) for q in qs];print('ok')"
    )
    graph = api["_run"](api["_bwrap_command"](
        workspace=workspace, candidate_dir=candidate_dir, writable_workspace=False,
        inner=[sys.executable, "-c", graph_code, json.dumps(queries)],
    ), timeout=240)
    started = time.perf_counter()
    candidate_runs = [_outline(api, workspace, candidate_dir) for _ in queries]
    candidate_ms = round((time.perf_counter() - started) * 1000, 3)
    return {
        "queries": len(queries),
        "python_graph_single_process_duration_ms": graph["duration_ms"],
        "python_graph_rss_kb": graph["rss_kb"] or 0,
        "ast_grep_one_shot_total_duration_ms": candidate_ms,
        "ast_grep_max_rss_kb": max(run["rss_kb"] or 0 for run in candidate_runs),
        "ast_grep_all_clean_exit": all(run["status"] == 0 for run in candidate_runs),
    }


def run(*, candidate: pathlib.Path, repetitions: int = 5) -> dict[str, Any]:
    api = runpy.run_path(str(BASE), run_name="extended_structural_candidate_api")
    lock = json.loads(api["LOCK_PATH"].read_text(encoding="utf-8"))
    binary = pathlib.Path(candidate).resolve()
    if api["_sha"](binary) != lock["executable_sha256"]:
        raise ValueError("candidate does not match pinned executable digest")
    if not shutil.which("bwrap"):
        raise RuntimeError("Bubblewrap is required")
    with tempfile.TemporaryDirectory(prefix="chimera-structural-extended-") as raw:
        workspace = pathlib.Path(raw) / "fixture"
        cases = _write_fixture(workspace)
        before = api["_tree_digest"](workspace)
        graph_build = api["_graph_build"](workspace, binary.parent)
        rows: list[dict[str, Any]] = []
        for case in cases:
            graph_runs = [_graph_query(api, workspace, binary.parent, case["query"]) for _ in range(repetitions)]
            candidate_runs = [_outline(api, workspace, binary.parent) for _ in range(repetitions)]
            graph_first = graph_runs[0]
            candidate_first_matches = _candidate_matches(candidate_runs[0]["documents"], case)
            graph_context = "\n\n".join(_snippet(workspace, row["file"], int(row.get("line", 1))) for row in graph_first["matches"] if (workspace / str(row.get("file", ""))).exists())
            candidate_context = "\n\n".join(_snippet(workspace, row["file"], row["line"]) for row in candidate_first_matches)
            rows.append({
                "id": case["id"], "expected": {key: case[key] for key in ("file", "class", "member")},
                "python_graph": {
                    "hit": _hit_graph(graph_first["matches"], case), "match_count": len(graph_first["matches"]),
                    "median_query_ms": statistics.median(run["duration_ms"] for run in graph_runs),
                    "max_rss_kb": max(run["rss_kb"] or 0 for run in graph_runs),
                    "estimated_context_tokens": (len(graph_context) + 3) // 4,
                },
                "ast_grep_outline": {
                    "hit": any(row["file"] == case["file"] for row in candidate_first_matches), "match_count": len(candidate_first_matches),
                    "median_query_ms": statistics.median(run["duration_ms"] for run in candidate_runs),
                    "max_rss_kb": max(run["rss_kb"] or 0 for run in candidate_runs),
                    "estimated_context_tokens": (len(candidate_context) + 3) // 4,
                },
            })
        heavy = _measure_query_heavy(api, workspace, binary.parent, cases, repetitions=10)
        after = api["_tree_digest"](workspace)
        fixture_file_count = sum(1 for item in workspace.rglob("*") if item.is_file())
    return {
        "schema_version": "chimera.structural-candidate-extended-benchmark.v1",
        "candidate_lock": lock,
        "fixture": {"generated_pairs_per_language": 160, "files": fixture_file_count, "cross_language": ["Python", "TypeScript"], "includes_malformed_source": True},
        "repetitions": repetitions,
        "python_graph_build": graph_build,
        "rows": rows,
        "query_heavy_session": heavy,
        "isolation": {"backend": "bubblewrap", "network_namespace": True, "workspace_candidate_bind": "read-only", "workspace_unchanged_by_candidate": before == after},
        "semantic_reference_limit": "Neither evaluated adapter establishes cross-file semantic reference equivalence in this fixture. ast-grep outline is structural, and current CodeGraph only resolves same-file Python CALLS edges.",
        "summary": {
            "cases": len(rows),
            "python_graph_recall": sum(row["python_graph"]["hit"] for row in rows) / len(rows),
            "ast_grep_recall": sum(row["ast_grep_outline"]["hit"] for row in rows) / len(rows),
            "python_graph_median_query_ms": statistics.median(row["python_graph"]["median_query_ms"] for row in rows),
            "ast_grep_median_query_ms": statistics.median(row["ast_grep_outline"]["median_query_ms"] for row in rows),
            "python_graph_median_context_tokens": statistics.median(row["python_graph"]["estimated_context_tokens"] for row in rows),
            "ast_grep_median_context_tokens": statistics.median(row["ast_grep_outline"]["estimated_context_tokens"] for row in rows),
        },
        "automatic_enablement": False,
        "manual_promotion_required": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=pathlib.Path, required=True)
    parser.add_argument("--repetitions", type=int, default=5)
    parser.add_argument("--results", type=pathlib.Path, default=ROOT / "artifacts" / "structural_candidate_extended_benchmark.json")
    args = parser.parse_args()
    if not 1 <= args.repetitions <= 10:
        parser.error("--repetitions must be in [1, 10]")
    report = run(candidate=args.candidate, repetitions=args.repetitions)
    args.results.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.results.with_suffix(args.results.suffix + ".tmp")
    temporary.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(args.results)
    print(json.dumps(report["summary"], sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
