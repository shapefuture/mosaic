#!/usr/bin/env python3
"""Sealed read-only comparison: current Python CodeGraph vs pinned ast-grep.

The benchmark intentionally measures a narrow symbol-retrieval workload. It
compares exact-file/member recall, returned context size, cold build/query wall
time, peak child RSS, stale-index behavior, workspace write containment, and
network/process containment for the third-party candidate.

It does *not* install, promote, or invoke ast-grep as a Chimera runtime adapter.
The candidate must be supplied explicitly and match the checked-in lock file.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import time
from statistics import median
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parents[2]
LOCK_PATH = pathlib.Path(__file__).with_name("ast_grep_candidate_lock.json")
CORPUS_PATH = pathlib.Path(__file__).with_name("structural_candidate_corpus_v1.json")
IGNORE = shutil.ignore_patterns(".chimera", ".git", ".pytest_cache", ".testmondata", "__pycache__", "node_modules", "build", "dist", "coverage")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _tree_digest(root: pathlib.Path) -> str:
    h = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if any(part in {".chimera", ".git", "__pycache__", ".pytest_cache", ".testmondata"} for part in rel.parts):
            continue
        h.update(rel.as_posix().encode()); h.update(b"\0"); h.update(path.read_bytes()); h.update(b"\0")
    return "sha256:" + h.hexdigest()


def _parse_rss(stderr: str) -> int | None:
    marker = re.search(r"__CHIMERA_RSS_KB__=(\d+)", stderr)
    return int(marker.group(1)) if marker else None


def _bwrap_command(*, workspace: pathlib.Path, candidate_dir: pathlib.Path, writable_workspace: bool, inner: list[str], rule_file: pathlib.Path | None = None) -> list[str]:
    bwrap = shutil.which("bwrap")
    if not bwrap:
        raise RuntimeError("Bubblewrap is required for the candidate benchmark")
    argv = [bwrap, "--die-with-parent", "--new-session", "--unshare-net", "--proc", "/proc", "--dev", "/dev"]
    for runtime in ("/usr", "/usr/local", "/bin", "/lib", "/lib64"):
        if pathlib.Path(runtime).exists():
            argv += ["--ro-bind", runtime, runtime]
    argv += (["--bind", str(workspace), "/workspace"] if writable_workspace else ["--ro-bind", str(workspace), "/workspace"])
    argv += ["--ro-bind", str(candidate_dir), "/candidate"]
    if rule_file is not None:
        argv += ["--ro-bind", str(rule_file), "/rule.yml"]
    argv += ["--tmpfs", "/tmp", "--chdir", "/workspace", "--setenv", "PYTHONPATH", "/workspace", "/usr/bin/time", "-f", "__CHIMERA_RSS_KB__=%M"]
    return [*argv, *inner]


def _run(argv: list[str], *, timeout: int = 60) -> dict[str, Any]:
    started = time.perf_counter()
    completed = subprocess.run(argv, text=True, capture_output=True, timeout=timeout)
    return {
        "status": int(completed.returncode),
        "duration_ms": round((time.perf_counter() - started) * 1000, 3),
        "stdout": completed.stdout,
        "stderr": completed.stderr,
        "rss_kb": _parse_rss(completed.stderr),
    }


def _graph_build(workspace: pathlib.Path, candidate_dir: pathlib.Path) -> dict[str, Any]:
    code = (
        "import json; from chimera.graph import CodeGraph; "
        "print(json.dumps(CodeGraph('.').build().get('meta', {}), sort_keys=True))"
    )
    result = _run(_bwrap_command(workspace=workspace, candidate_dir=candidate_dir, writable_workspace=True, inner=[sys.executable, "-c", code]), timeout=120)
    if result["status"] != 0:
        raise RuntimeError("CodeGraph build failed: " + result["stderr"][-500:])
    return {key: value for key, value in result.items() if key not in {"stdout", "stderr"}} | {"meta": json.loads(result["stdout"])}


def _graph_query(workspace: pathlib.Path, candidate_dir: pathlib.Path, query: str) -> dict[str, Any]:
    code = (
        "import json,sys; from chimera.graph import CodeGraph; "
        "g=CodeGraph('.'); g.load(); print(json.dumps(g.search(sys.argv[1], limit=10, kind='Function'), sort_keys=True))"
    )
    result = _run(_bwrap_command(workspace=workspace, candidate_dir=candidate_dir, writable_workspace=False, inner=[sys.executable, "-c", code, query]))
    try:
        matches = json.loads(result["stdout"]) if result["status"] == 0 else []
    except json.JSONDecodeError:
        matches = []
    return {key: value for key, value in result.items() if key not in {"stdout", "stderr"}} | {"matches": matches}


def _rule(method: str) -> str:
    # A Tree-sitter AST rule: only a function-definition node with a literal
    # identifier matches. It does not execute candidate rewrites.
    return "\n".join((
        "id: chimera-member-lookup",
        "language: Python",
        "rule:",
        "  all:",
        "    - kind: function_definition",
        "    - has:",
        "        field: name",
        f"        pattern: {method}",
        "",
    ))


def _candidate_query(
    workspace: pathlib.Path, candidate_dir: pathlib.Path, method: str, *, search_root: str = "chimera",
) -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="chimera-ast-rule-") as raw:
        rule_path = pathlib.Path(raw) / "rule.yml"
        rule_path.write_text(_rule(method), encoding="utf-8")
        result = _run(_bwrap_command(
            workspace=workspace, candidate_dir=candidate_dir, writable_workspace=False, rule_file=rule_path,
            inner=["/candidate/ast-grep", "scan", "--rule", "/rule.yml", "--json=compact", f"/workspace/{search_root}"],
        ), timeout=120)
    try:
        matches = json.loads(result["stdout"]) if result["status"] == 0 else []
    except json.JSONDecodeError:
        matches = []
    return {key: value for key, value in result.items() if key not in {"stdout", "stderr"}} | {"matches": matches}


def _relative_match_path(raw: str, workspace: pathlib.Path) -> str | None:
    path = pathlib.Path(raw)
    try:
        return path.resolve().relative_to(workspace.resolve()).as_posix()
    except ValueError:
        return str(raw).replace("\\", "/").removeprefix("/workspace/")


def _snippet(root: pathlib.Path, relative: str, line: int, *, width: int = 12) -> str:
    try:
        lines = (root / relative).read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return ""
    start = max(0, int(line) - 1)
    return "\n".join(lines[start:start + width])


def _graph_context(workspace: pathlib.Path, matches: list[dict[str, Any]]) -> tuple[int, int]:
    text = "\n\n".join(_snippet(workspace, str(row.get("file", "")), int(row.get("line", 1))) for row in matches)
    return len(text), math.ceil(len(text) / 4)


def _candidate_context(workspace: pathlib.Path, matches: list[dict[str, Any]]) -> tuple[int, int]:
    snippets: list[str] = []
    for row in matches:
        relative = _relative_match_path(str(row.get("file", "")), workspace)
        start = row.get("range", {}).get("start", {}).get("line", 0) if isinstance(row.get("range"), dict) else 0
        if relative:
            snippets.append(_snippet(workspace, relative, int(start) + 1))
    text = "\n\n".join(snippets)
    return len(text), math.ceil(len(text) / 4)


def _graph_hit(matches: list[dict[str, Any]], case: dict[str, str]) -> bool:
    expected = f"{case['class']}.{case['member']}"
    return any(str(row.get("file")) == case["file"] and str(row.get("qualified_name", "")) == expected for row in matches)


def _candidate_hit(matches: list[dict[str, Any]], case: dict[str, str], workspace: pathlib.Path) -> bool:
    return any(_relative_match_path(str(row.get("file", "")), workspace) == case["file"] for row in matches)


def _stale_probe(workspace: pathlib.Path, candidate_dir: pathlib.Path) -> dict[str, Any]:
    probe = workspace / "stale_probe"
    probe.mkdir()
    source = probe / "sample.py"
    source.write_text("def old_symbol() -> int:\n    return 1\n", encoding="utf-8")
    from chimera.graph import CodeGraph
    graph = CodeGraph(probe)
    graph.build()
    source.write_text("def new_symbol() -> int:\n    return 1\n", encoding="utf-8")
    stale_before = any(row.get("name") == "old_symbol" for row in graph.search("old_symbol", limit=10, kind="Function"))
    graph.update({"ops": [{"op": "write", "path": "sample.py"}]})
    fresh_after = any(row.get("name") == "new_symbol" for row in graph.search("new_symbol", limit=10, kind="Function"))
    old_after_update = any(row.get("name") == "old_symbol" for row in graph.search("old_symbol", limit=10, kind="Function"))
    candidate_old = _candidate_query(probe, candidate_dir, "old_symbol", search_root=".")
    candidate_new = _candidate_query(probe, candidate_dir, "new_symbol", search_root=".")
    return {
        "python_graph_stale_before_explicit_update": stale_before,
        "python_graph_fresh_after_explicit_update": fresh_after,
        "python_graph_old_symbol_after_update": old_after_update,
        "candidate_old_symbol_after_file_change": len(candidate_old["matches"]),
        "candidate_new_symbol_after_file_change": len(candidate_new["matches"]),
        "candidate_live_filesystem_fresh": len(candidate_old["matches"]) == 0 and len(candidate_new["matches"]) == 1,
    }


def run(*, candidate: pathlib.Path, repetitions: int = 3) -> dict[str, Any]:
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    binary = pathlib.Path(candidate).resolve()
    if binary.name != lock["executable_name"]:
        raise ValueError(f"candidate executable must be named {lock['executable_name']}")
    if _sha(binary) != lock["executable_sha256"]:
        raise ValueError("candidate executable digest does not match the checked-in lock")
    if not shutil.which("bwrap"):
        raise RuntimeError("Bubblewrap is unavailable; candidate will not run unsandboxed")
    candidate_dir = binary.parent
    with tempfile.TemporaryDirectory(prefix="chimera-structural-benchmark-") as raw:
        workspace = pathlib.Path(raw) / "workspace"
        shutil.copytree(ROOT, workspace, ignore=IGNORE)
        before_candidate_digest = _tree_digest(workspace)
        version = _run(_bwrap_command(workspace=workspace, candidate_dir=candidate_dir, writable_workspace=False, inner=["/candidate/ast-grep", "--version"]))
        if version["status"] != 0:
            raise RuntimeError("candidate version probe failed")
        graph_build = _graph_build(workspace, candidate_dir)
        corpus = json.loads(CORPUS_PATH.read_text(encoding="utf-8"))
        rows: list[dict[str, Any]] = []
        for case in corpus["cases"]:
            graph_runs = [_graph_query(workspace, candidate_dir, str(case["query"])) for _ in range(repetitions)]
            candidate_runs = [_candidate_query(workspace, candidate_dir, str(case["member"])) for _ in range(repetitions)]
            graph_first, candidate_first = graph_runs[0], candidate_runs[0]
            graph_chars, graph_tokens = _graph_context(workspace, graph_first["matches"])
            candidate_chars, candidate_tokens = _candidate_context(workspace, candidate_first["matches"])
            rows.append({
                "id": case["id"], "expected": {key: case[key] for key in ("file", "class", "member")},
                "python_graph": {
                    "hit": _graph_hit(graph_first["matches"], case),
                    "match_count": len(graph_first["matches"]),
                    "median_query_ms": median(item["duration_ms"] for item in graph_runs),
                    "max_rss_kb": max(item["rss_kb"] or 0 for item in graph_runs),
                    "context_chars": graph_chars, "estimated_context_tokens": graph_tokens,
                },
                "ast_grep": {
                    "hit": _candidate_hit(candidate_first["matches"], case, workspace),
                    "match_count": len(candidate_first["matches"]),
                    "median_query_ms": median(item["duration_ms"] for item in candidate_runs),
                    "max_rss_kb": max(item["rss_kb"] or 0 for item in candidate_runs),
                    "context_chars": candidate_chars, "estimated_context_tokens": candidate_tokens,
                },
            })
        after_candidate_digest = _tree_digest(workspace)
        stale = _stale_probe(workspace, candidate_dir)
    def recall(key: str) -> float:
        return sum(bool(row[key]["hit"]) for row in rows) / len(rows) if rows else 0.0
    report = {
        "schema_version": "chimera.structural-candidate-benchmark.v1",
        "candidate_lock": lock,
        "candidate_version_stdout": version["stdout"].strip(),
        "isolation": {
            "backend": "bubblewrap", "network_namespace": True, "workspace_candidate_bind": "read-only",
            "candidate_clean_exit": version["status"] == 0,
            "workspace_digest_before_candidate": before_candidate_digest,
            "workspace_digest_after_candidate": after_candidate_digest,
            "workspace_unchanged_by_candidate": before_candidate_digest == after_candidate_digest,
            "process_lifecycle": "per-invocation bwrap --die-with-parent --new-session; every measured candidate process returned before the next repetition",
        },
        "python_graph_build": graph_build,
        "corpus_hash": "sha256:" + hashlib.sha256(CORPUS_PATH.read_bytes()).hexdigest(),
        "repetitions": repetitions,
        "rows": rows,
        "summary": {
            "cases": len(rows),
            "python_graph_recall": recall("python_graph"),
            "ast_grep_recall": recall("ast_grep"),
            "python_graph_median_query_ms": median(row["python_graph"]["median_query_ms"] for row in rows),
            "ast_grep_median_query_ms": median(row["ast_grep"]["median_query_ms"] for row in rows),
            "python_graph_median_estimated_context_tokens": median(row["python_graph"]["estimated_context_tokens"] for row in rows),
            "ast_grep_median_estimated_context_tokens": median(row["ast_grep"]["estimated_context_tokens"] for row in rows),
        },
        "stale_index_probe": stale,
        "automatic_enablement": False,
        "manual_promotion_required": True,
        "limits": [
            "This is a narrow, sealed Python symbol-retrieval corpus, not an end-to-end coding-agent outcome evaluation.",
            "The Python graph is measured after an explicit build; ast-grep is measured as a read-only one-shot structural scan.",
            "Estimated context tokens use chars/4 only and are not provider tokenizer measurements.",
            "No candidate binary is integrated into Chimera or granted workspace write, provider, MCP, or promotion authority.",
        ],
    }
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=pathlib.Path, required=True, help="pinned ast-grep executable")
    parser.add_argument("--repetitions", type=int, default=3)
    parser.add_argument("--results", type=pathlib.Path, default=ROOT / "artifacts" / "structural_candidate_benchmark.json")
    args = parser.parse_args()
    if args.repetitions < 1 or args.repetitions > 20:
        parser.error("--repetitions must be in [1, 20]")
    report = run(candidate=args.candidate, repetitions=args.repetitions)
    args.results.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.results.with_suffix(args.results.suffix + ".tmp")
    temporary.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, args.results)
    print(json.dumps(report["summary"], sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
