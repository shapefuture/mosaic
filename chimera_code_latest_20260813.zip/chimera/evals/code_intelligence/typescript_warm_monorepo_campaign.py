#!/usr/bin/env python3
"""Pinned TypeScript LSP warm-session campaign on a 100-file monorepo fixture."""
from __future__ import annotations

import argparse
import json
import math
import os
import pathlib
import shutil
import statistics
import tempfile

from chimera.semantic_code_intelligence import (
    CodeGraphSemanticAdapter,
    SemanticCodeIntelligenceRouter,
    SemanticPosition,
    SemanticQueryRequest,
    WorkspaceSnapshotter,
)
from chimera.semantic_lsp import LSPLaunchSpec
from chimera.semantic_lsp_warm import WarmLSPSubprocessSemanticSession
from chimera.tokenizer import TokenizerMeasurer


def position(text: str, needle: str, occurrence: int = 0) -> SemanticPosition:
    start=0;offset=-1
    for _ in range(occurrence+1):offset=text.index(needle,start);start=offset+len(needle)
    return SemanticPosition(line=text.count('\n',0,offset),character=offset-(text.rfind('\n',0,offset)+1)+1)

def write_project(root: pathlib.Path) -> dict[str,str]:
    core="export interface User { id: string }\nexport function validate(user: User): boolean { return user.id.length > 0 }\nexport function route(user: User): boolean { return validate(user) }\n"
    (root/'core.ts').write_text(core)
    for i in range(98):
        (root/f'module{i}.ts').write_text(f"import {{ User, route }} from './core'\nexport function use{i}(user: User): boolean {{ return route(user) }}\n")
    index="import { User } from './core'\nimport { use97 } from './module97'\nexport function main(user: User): boolean { return use97(user) }\n"
    (root/'index.ts').write_text(index);(root/'malformed.ts').write_text("export function broken(: boolean { return false }\n")
    (root/'tsconfig.json').write_text(json.dumps({'compilerOptions':{'target':'ES2022','module':'commonjs','strict':True,'declaration':True,'sourceMap':True},'include':['*.ts']}))
    return {'core':core,'module97':(root/'module97.ts').read_text(),'index':index}

def main()->int:
    parser=argparse.ArgumentParser();parser.add_argument('--toolchain',type=pathlib.Path,default=pathlib.Path('/tmp/typescript-lsp-5.3.0'));parser.add_argument('--results',type=pathlib.Path,required=True);args=parser.parse_args()
    root=pathlib.Path(tempfile.mkdtemp(prefix='chimera-ts-warm-'));texts=write_project(root)
    entry=args.toolchain/'node_modules/typescript-language-server/lib/cli.mjs'
    if not entry.is_file():raise SystemExit('pinned TypeScript LSP toolchain unavailable')
    spec=LSPLaunchSpec(adapter_id='typescript-language-server-5.3.0-warm',argv=('/usr/bin/node',str(entry),'--stdio'),isolation='bubblewrap',readonly_bind_paths=(str(args.toolchain),),max_message_bytes=16*1024*1024)
    snapshotter=WorkspaceSnapshotter(root);snapshot=snapshotter.capture();tokenizer=TokenizerMeasurer();primary=WarmLSPSubprocessSemanticSession(root,spec,snapshotter=snapshotter,tokenizer=tokenizer);fallback=CodeGraphSemanticAdapter(root,snapshotter=snapshotter,tokenizer=tokenizer);router=SemanticCodeIntelligenceRouter(root,primary=primary,fallback=fallback,snapshotter=snapshotter)
    requests=[
      ('definition-import-alias',SemanticQueryRequest(request_id='ts:def',snapshot_digest=snapshot.digest,operation='definition',path='module97.ts',position=position(texts['module97'],'route',0),tokenizer_model='gpt-4o',max_results=200),lambda r:any(x.path=='module97.ts' and x.symbol=='route' for x in r.results)),
      ('references-user',SemanticQueryRequest(request_id='ts:refs',snapshot_digest=snapshot.digest,operation='references',path='core.ts',position=position(texts['core'],'User'),tokenizer_model='gpt-4o',max_results=200,max_context_tokens=2000),lambda r:len({x.path for x in r.results})>=20),
      ('document-symbols',SemanticQueryRequest(request_id='ts:doc',snapshot_digest=snapshot.digest,operation='document_symbols',path='core.ts',query='validate route',tokenizer_model='gpt-4o',max_results=200),lambda r:{'validate','route'}.issubset({x.symbol for x in r.results})),
      ('outgoing-calls',SemanticQueryRequest(request_id='ts:calls',snapshot_digest=snapshot.digest,operation='outgoing_calls',path='core.ts',position=position(texts['core'],'route'),tokenizer_model='gpt-4o',max_results=200),lambda r:any(x.symbol=='validate' for x in r.results)),
      ('workspace-symbol',SemanticQueryRequest(request_id='ts:workspace',snapshot_digest=snapshot.digest,operation='workspace_symbols',query='use97',tokenizer_model='gpt-4o',max_results=200),lambda r:any(x.path=='module97.ts' for x in r.results)),
      ('malformed-neighbor',SemanticQueryRequest(request_id='ts:malformed',snapshot_digest=snapshot.digest,operation='definition',path='index.ts',position=position(texts['index'],'use97',1),tokenizer_model='gpt-4o',max_results=200),lambda r:any(x.path=='module97.ts' for x in r.results)),
    ]
    rows=[]
    try:
      for case,request,accept in requests:
        receipt=router.query(request);rows.append({'case':case,'status':receipt.status,'passed':receipt.status=='completed' and accept(receipt),'latency_ms':receipt.latency_ms,'result_count':len(receipt.results),'paths':sorted({x.path for x in receipt.results}),'symbols':sorted({x.symbol for x in receipt.results if x.symbol}),'token_status':receipt.token_measurement.status if receipt.token_measurement else 'missing','tokens':receipt.token_measurement.tokens if receipt.token_measurement else None,'fallback_reason':receipt.fallback_reason})
      (root/'core.ts').write_text(texts['core'].replace('return validate(user)','return false'))
      stale=router.query(requests[0][1]);stale_ok=stale.status=='rejected' and stale.stale_state_rejected
    finally:primary.close();shutil.rmtree(root,ignore_errors=True)
    lat=[row['latency_ms'] for row in rows];warm=lat[1:];result={'schema_version':'chimera.typescript-warm-monorepo-campaign.v1','server_version':'5.3.0','typescript_version':'5.9.3','files':101,'cases':len(rows),'rows':rows,'case_recall':sum(row['passed'] for row in rows)/len(rows),'cold_start_query_ms':lat[0],'warm_p50_ms':statistics.median(warm),'warm_p95_ms':sorted(warm)[math.ceil(.95*len(warm))-1],'exact_token_measurement_complete':all(row['token_status']=='measured' for row in rows),'stale_state_rejected':stale_ok,'accepted_for_manual_review':all(row['passed'] for row in rows) and stale_ok and all(row['token_status']=='measured' for row in rows),'automatic_enablement':False,'manual_promotion_required':True,'limits':['Disposable representative TypeScript monorepo because Chimera has no production TypeScript source tree.','No write/provider/MCP authority.']}
    args.results.parent.mkdir(parents=True,exist_ok=True);tmp=args.results.with_suffix('.tmp');tmp.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');os.replace(tmp,args.results);print(json.dumps({k:result[k] for k in ('case_recall','cold_start_query_ms','warm_p50_ms','warm_p95_ms','stale_state_rejected','accepted_for_manual_review')},sort_keys=True));return 0 if result['case_recall']==1 else 1
if __name__=='__main__':raise SystemExit(main())
