#!/usr/bin/env python3
"""Sealed semantic navigation benchmark: CodeGraph vs pinned Pyright LSP.

The benchmark exercises actual LSP requests over stdio: definition, references,
import resolution, call hierarchy, document symbols, config exclusion, and a
live didChange stale-state drill. Pyright is a Python-only semantic candidate;
a TypeScript generated-source fixture is intentionally retained as a negative
control rather than being mislabelled as cross-language support.

No language server is integrated into Chimera. The server runs once per campaign
inside an unshared-network Bubblewrap process with a read-only workspace.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parents[2]
LOCK_PATH = pathlib.Path(__file__).with_name("pyright_semantic_candidate_lock.json")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _tree_digest(root: pathlib.Path) -> str:
    h = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if path.is_file():
            rel = path.relative_to(root).as_posix()
            h.update(rel.encode()); h.update(b"\0"); h.update(path.read_bytes()); h.update(b"\0")
    return "sha256:" + h.hexdigest()


def _write_fixture(root: pathlib.Path) -> dict[str, str]:
    (root / "models.py").write_text("class User:\n    pass\n", encoding="utf-8")
    service = (
        "from models import User\n\n"
        "def validate_token(value: str) -> bool:\n"
        "    return bool(value)\n\n"
        "def route(value: str) -> bool:\n"
        "    return validate_token(value)\n\n"
        "def use_user(user: User) -> User:\n"
        "    return user\n"
    )
    (root / "service.py").write_text(service, encoding="utf-8")
    (root / "excluded.py").write_text("def excluded_only() -> int:\n    return 1\n", encoding="utf-8")
    (root / "schema.ts").write_text("export interface TypeScriptOnlyUserRecord { id: string }\n", encoding="utf-8")
    (root / "generated_from_schema.py").write_text("class GeneratedUserRecord:\n    pass\n", encoding="utf-8")
    (root / "pyrightconfig.json").write_text(json.dumps({"exclude": ["excluded.py"]}), encoding="utf-8")
    return {"service": service, "models": (root / "models.py").read_text(encoding="utf-8")}


def _bwrap_argv(workspace: pathlib.Path, candidate_dir: pathlib.Path) -> list[str]:
    bwrap = shutil.which("bwrap")
    if not bwrap:
        raise RuntimeError("Bubblewrap is required; semantic candidate will not run unsandboxed")
    argv = [bwrap, "--die-with-parent", "--new-session", "--unshare-net", "--proc", "/proc", "--dev", "/dev"]
    for runtime in ("/usr", "/usr/local", "/bin", "/lib", "/lib64"):
        if pathlib.Path(runtime).exists():
            argv += ["--ro-bind", runtime, runtime]
    return [
        *argv,
        "--ro-bind", str(workspace), "/workspace",
        "--ro-bind", str(candidate_dir), "/candidate",
        "--tmpfs", "/tmp", "--setenv", "HOME", "/tmp", "--chdir", "/workspace",
        "/usr/bin/node", "/candidate/langserver.index.js", "--stdio",
    ]


class LSPClient:
    def __init__(self, argv: list[str]) -> None:
        self.process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        assert self.process.stdin is not None and self.process.stdout is not None
        self.stdin = self.process.stdin
        self.stdout = self.process.stdout
        self.next_id = 1
        self.notifications: list[dict[str, Any]] = []
        self._peak_rss_kb = 0
        self._sampling = True
        self._sampler = threading.Thread(target=self._sample_rss, daemon=True)
        self._sampler.start()

    def _sample_rss(self) -> None:
        """Track the Bubblewrap process tree, not only its tiny launcher."""
        while self._sampling:
            try:
                parent_by_pid: dict[int, int] = {}
                for entry in pathlib.Path("/proc").iterdir():
                    if not entry.name.isdigit():
                        continue
                    try:
                        # /proc/<pid>/stat uses field four as parent PID.
                        fields = (entry / "stat").read_text().split()
                        parent_by_pid[int(entry.name)] = int(fields[3])
                    except (OSError, ValueError, IndexError):
                        continue
                descendants = {self.process.pid}
                changed = True
                while changed:
                    changed = False
                    for pid, parent in parent_by_pid.items():
                        if parent in descendants and pid not in descendants:
                            descendants.add(pid)
                            changed = True
                current = 0
                for pid in descendants:
                    try:
                        match = re.search(r"^VmRSS:\s+(\d+)\s+kB", pathlib.Path(f"/proc/{pid}/status").read_text(), re.MULTILINE)
                        if match:
                            current += int(match.group(1))
                    except OSError:
                        pass
                self._peak_rss_kb = max(self._peak_rss_kb, current)
            except OSError:
                pass
            time.sleep(0.01)

    @property
    def peak_rss_kb(self) -> int:
        return self._peak_rss_kb

    def _send(self, message: dict[str, Any]) -> None:
        raw = json.dumps(message, separators=(",", ":")).encode("utf-8")
        self.stdin.write(f"Content-Length: {len(raw)}\r\n\r\n".encode("ascii") + raw)
        self.stdin.flush()

    def _read(self, timeout_seconds: float = 20.0) -> dict[str, Any]:
        # Language-server requests in this controlled fixture finish well below
        # the deadline. stdout is protocol-only; stderr is never parsed as data.
        deadline = time.monotonic() + timeout_seconds
        headers: dict[str, str] = {}
        while time.monotonic() < deadline:
            line = self.stdout.readline()
            if not line:
                if self.process.poll() is not None:
                    raise RuntimeError("language server exited before producing a protocol message")
                continue
            if line in {b"\r\n", b"\n"}:
                break
            key, value = line.decode("ascii").split(":", 1)
            headers[key.lower()] = value.strip()
        if "content-length" not in headers:
            raise RuntimeError("LSP message had no content length")
        length = int(headers["content-length"])
        return json.loads(self.stdout.read(length))

    def notify(self, method: str, params: dict[str, Any]) -> None:
        self._send({"jsonrpc": "2.0", "method": method, "params": params})

    def request(self, method: str, params: dict[str, Any], *, timeout_seconds: float = 20.0) -> tuple[Any, float]:
        request_id = self.next_id
        self.next_id += 1
        started = time.perf_counter()
        self._send({"jsonrpc": "2.0", "id": request_id, "method": method, "params": params})
        while True:
            message = self._read(timeout_seconds)
            if message.get("id") == request_id:
                return message.get("result"), round((time.perf_counter() - started) * 1000, 3)
            self.notifications.append(message)

    def close(self) -> tuple[int, str]:
        try:
            self.request("shutdown", {}, timeout_seconds=10)
            self.notify("exit", {})
        finally:
            self._sampling = False
            self._sampler.join(timeout=1)
        self.process.wait(timeout=10)
        assert self.process.stderr is not None
        return int(self.process.returncode or 0), self.process.stderr.read().decode("utf-8", errors="replace")[-1000:]


def _uri(path: str) -> str:
    return "file:///workspace/" + path


def _position(text: str, needle: str, *, occurrence: int = 0) -> dict[str, int]:
    offset = -1
    start = 0
    for _ in range(occurrence + 1):
        offset = text.index(needle, start)
        start = offset + len(needle)
    line = text[:offset].count("\n")
    column = offset - (text.rfind("\n", 0, offset) + 1)
    return {"line": line, "character": column + min(1, max(0, len(needle) - 1))}


def _locations_have(result: Any, relative_path: str, line: int | None = None) -> bool:
    rows = result if isinstance(result, list) else [result]
    for row in rows:
        if not isinstance(row, dict):
            continue
        uri = str(row.get("uri") or row.get("targetUri") or "")
        if not uri.endswith("/" + relative_path):
            continue
        candidate_line = (row.get("range") or row.get("targetRange") or {}).get("start", {}).get("line")
        if line is None or candidate_line == line:
            return True
    return False


def _current_graph_probe(root: pathlib.Path) -> dict[str, Any]:
    from chimera.graph import CodeGraph
    graph = CodeGraph(root)
    graph.build()
    definition = any(item.get("file") == "service.py" and item.get("name") == "validate_token" for item in graph.search("validate_token", limit=10, kind="Function"))
    imports = any(item.get("file") == "service.py" and item.get("kind") == "Import" and "models" in str(item.get("name")) for item in graph.graph["nodes"])
    route_id = next(item["id"] for item in graph.graph["nodes"] if item.get("file") == "service.py" and item.get("name") == "route")
    target_id = next(item["id"] for item in graph.graph["nodes"] if item.get("file") == "service.py" and item.get("name") == "validate_token")
    calls = any(edge.get("from") == route_id and edge.get("to") == target_id and edge.get("type") == "CALLS" for edge in graph.graph["edges"])
    service = root / "service.py"
    before = service.read_text(encoding="utf-8")
    service.write_text(before.replace("validate_token", "validate_token_v2"), encoding="utf-8")
    stale_before_update = any(item.get("name") == "validate_token" for item in graph.search("validate_token", limit=10, kind="Function"))
    graph.update({"ops": [{"op": "write", "path": "service.py"}]})
    fresh_after_update = any(item.get("name") == "validate_token_v2" for item in graph.search("validate_token_v2", limit=10, kind="Function"))
    service.write_text(before, encoding="utf-8")
    return {
        "definition_lookup": definition,
        "import_node": imports,
        "same_file_call_edge": calls,
        "references": False,
        "build_config_exclusion": False,
        "cross_language_generated_navigation": False,
        "stale_before_explicit_update": stale_before_update,
        "fresh_after_explicit_update": fresh_after_update,
    }


def run(*, candidate_dir: pathlib.Path) -> dict[str, Any]:
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    entrypoint = pathlib.Path(candidate_dir) / str(lock["entrypoint"])
    if _sha(entrypoint) != lock["entrypoint_sha256"]:
        raise ValueError("Pyright language-server entrypoint does not match the pinned lock")
    with tempfile.TemporaryDirectory(prefix="chimera-semantic-lsp-") as raw:
        workspace = pathlib.Path(raw) / "workspace"
        workspace.mkdir()
        texts = _write_fixture(workspace)
        initial_digest = _tree_digest(workspace)
        graph = _current_graph_probe(workspace)
        # Restore source after the independent stale graph probe before feeding
        # the semantic server its sealed original fixture. CodeGraph's private
        # .chimera index is intentionally present before the candidate digest;
        # it must not be attributed to a read-only candidate process.
        (workspace / "service.py").write_text(texts["service"], encoding="utf-8")
        candidate_before = _tree_digest(workspace)
        client = LSPClient(_bwrap_argv(workspace, pathlib.Path(candidate_dir)))
        init, init_ms = client.request("initialize", {
            "processId": None,
            "rootUri": "file:///workspace",
            "workspaceFolders": [{"uri": "file:///workspace", "name": "workspace"}],
            "capabilities": {
                "textDocument": {"definition": {}, "references": {}, "documentSymbol": {}, "callHierarchy": {}},
                "workspace": {"symbol": {}},
            },
        })
        client.notify("initialized", {})
        for path, language, text in (("models.py", "python", texts["models"]), ("service.py", "python", texts["service"])):
            client.notify("textDocument/didOpen", {"textDocument": {"uri": _uri(path), "languageId": language, "version": 1, "text": text}})
        # Definition at the call in route; references at the declaration.
        definition, definition_ms = client.request("textDocument/definition", {
            "textDocument": {"uri": _uri("service.py")}, "position": _position(texts["service"], "validate_token", occurrence=1),
        })
        references, references_ms = client.request("textDocument/references", {
            "textDocument": {"uri": _uri("service.py")}, "position": _position(texts["service"], "validate_token"), "context": {"includeDeclaration": True},
        })
        import_definition, import_ms = client.request("textDocument/definition", {
            "textDocument": {"uri": _uri("service.py")}, "position": _position(texts["service"], "User"),
        })
        call_items, call_prepare_ms = client.request("textDocument/prepareCallHierarchy", {
            "textDocument": {"uri": _uri("service.py")}, "position": _position(texts["service"], "route"),
        })
        outgoing: Any = []
        outgoing_ms = None
        if isinstance(call_items, list) and call_items:
            outgoing, outgoing_ms = client.request("callHierarchy/outgoingCalls", {"item": call_items[0]})
        symbols, symbols_ms = client.request("textDocument/documentSymbol", {"textDocument": {"uri": _uri("service.py")}})
        excluded, excluded_ms = client.request("workspace/symbol", {"query": "excluded_only"})
        typescript, typescript_ms = client.request("workspace/symbol", {"query": "TypeScriptOnlyUserRecord"})
        # Live didChange check: the old identifier must no longer resolve, and
        # the new one must resolve after the in-memory update.
        changed = texts["service"].replace("validate_token", "validate_token_v2")
        client.notify("textDocument/didChange", {"textDocument": {"uri": _uri("service.py"), "version": 2}, "contentChanges": [{"text": changed}]})
        stale_new, stale_ms = client.request("textDocument/definition", {
            "textDocument": {"uri": _uri("service.py")}, "position": _position(changed, "validate_token_v2", occurrence=1),
        })
        exit_code, stderr = client.close()
        candidate_after = _tree_digest(workspace)
    capabilities = init.get("capabilities", {}) if isinstance(init, dict) else {}
    outgoing_names = [row.get("to", {}).get("name") for row in outgoing if isinstance(row, dict)] if isinstance(outgoing, list) else []
    return {
        "schema_version": "chimera.semantic-lsp-candidate-benchmark.v1",
        "candidate_lock": lock,
        "fixture": {"languages": ["Python", "TypeScript negative control"], "pyright_config_excludes": "excluded.py", "generated_cross_language_fixture": True},
        "isolation": {
            "backend": "bubblewrap", "network_namespace": True, "workspace_candidate_bind": "read-only",
            "initial_workspace_digest": initial_digest,
            "workspace_digest_before_candidate": candidate_before,
            "workspace_digest_after_candidate": candidate_after,
            "workspace_unchanged_by_candidate": candidate_before == candidate_after,
            "server_exit_code": exit_code, "server_stderr_tail": stderr,
            "peak_process_tree_rss_kb": client.peak_rss_kb,
        },
        "pyright_server_capabilities": {
            "definition": bool(capabilities.get("definitionProvider")),
            "references": bool(capabilities.get("referencesProvider")),
            "document_symbols": bool(capabilities.get("documentSymbolProvider")),
            "call_hierarchy": bool(capabilities.get("callHierarchyProvider")),
        },
        "operations": {
            "definition": {"passed": _locations_have(definition, "service.py", line=2), "duration_ms": definition_ms},
            "references": {"passed": _locations_have(references, "service.py", line=2) and _locations_have(references, "service.py", line=6), "count": len(references or []), "duration_ms": references_ms},
            "import_definition": {"passed": _locations_have(import_definition, "models.py", line=0), "duration_ms": import_ms},
            "outgoing_call_hierarchy": {"passed": "validate_token" in outgoing_names, "duration_ms": outgoing_ms},
            "document_symbols": {"passed": any(isinstance(item, dict) and item.get("name") == "route" for item in (symbols or [])), "duration_ms": symbols_ms},
            "build_config_exclusion": {"passed": not bool(excluded), "duration_ms": excluded_ms},
            "cross_language_generated_navigation": {"passed": False, "observed_results": len(typescript or []), "duration_ms": typescript_ms, "reason": "Pyright is Python-only; TypeScript generated-source navigation is deliberately a negative control"},
            "live_did_change_freshness": {"passed": _locations_have(stale_new, "service.py", line=2), "duration_ms": stale_ms},
        },
        "current_python_graph": graph,
        "automatic_enablement": False,
        "manual_promotion_required": True,
        "limits": [
            "This is a small semantic Python fixture, not a complete Chimera repository index or a coding-task outcome evaluation.",
            "Pyright has no TypeScript/cross-language generated-code capability in this evaluation.",
            "The current CodeGraph has no general semantic references or build-config model; it is not a language-server implementation.",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-dir", type=pathlib.Path, required=True, help="extracted pinned pyright package directory")
    parser.add_argument("--results", type=pathlib.Path, default=ROOT / "artifacts" / "semantic_lsp_candidate_benchmark.json")
    args = parser.parse_args()
    report = run(candidate_dir=args.candidate_dir)
    args.results.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.results.with_suffix(args.results.suffix + ".tmp")
    temporary.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, args.results)
    print(json.dumps({"operations": report["operations"], "isolation": report["isolation"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
