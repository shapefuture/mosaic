#!/usr/bin/env python3
"""Sealed TypeScript semantic LSP benchmark.

A pinned TypeScript compiler builds declaration/source maps in a disposable
fixture. A separately pinned TypeScript language server is then driven over
LSP stdio inside a read-only, unshared-network Bubblewrap process. The campaign
measures definitions, references, imports, call hierarchy, build exclusion,
declaration/source map navigation, live updates, stale graph behavior, and a
Python-to-TypeScript generated-code negative control.

Neither tool is integrated into Chimera after this evaluation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parents[2]
LOCK_PATH = pathlib.Path(__file__).with_name("typescript_semantic_candidate_lock.json")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _tree_digest(root: pathlib.Path) -> str:
    h = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if any(part == ".chimera" for part in rel.parts):
            continue
        h.update(rel.as_posix().encode()); h.update(b"\0"); h.update(path.read_bytes()); h.update(b"\0")
    return "sha256:" + h.hexdigest()


def _write_fixture(root: pathlib.Path) -> dict[str, str]:
    (root / "src").mkdir(parents=True)
    (root / "tsconfig.json").write_text(json.dumps({
        "compilerOptions": {"strict": True, "declaration": True, "declarationMap": True, "sourceMap": True, "outDir": "dist"},
        "include": ["src/**/*.ts"], "exclude": ["src/ignored.ts"],
    }), encoding="utf-8")
    schema = "export interface SourceContract { id: string }\nexport function normalize(value: string): string { return value.trim() }\n"
    generated = "// generated from schema.ts\nimport { SourceContract, normalize } from \"./schema\"\nexport type GeneratedContract = SourceContract\nexport function generatedNormalize(value: string): string { return normalize(value) }\n"
    consumer = "import { GeneratedContract, generatedNormalize } from \"./generated\"\nexport function route(value: string): GeneratedContract {\n  return { id: generatedNormalize(value) }\n}\n"
    (root / "src" / "schema.ts").write_text(schema, encoding="utf-8")
    (root / "src" / "generated.ts").write_text(generated, encoding="utf-8")
    (root / "src" / "consumer.ts").write_text(consumer, encoding="utf-8")
    (root / "src" / "ignored.ts").write_text("export function ignoredOnly(): number { return 1 }\n", encoding="utf-8")
    # Deliberate cross-language/generated relation that TypeScript alone cannot
    # prove. It must remain unavailable rather than become a fabricated edge.
    (root / "source_schema.py").write_text("class PythonSchemaContract:\n    pass\n", encoding="utf-8")
    (root / "src" / "generated_from_python.ts").write_text("// generated from source_schema.py:PythonSchemaContract\nexport interface GeneratedFromPython { id: string }\n", encoding="utf-8")
    return {"schema": schema, "generated": generated, "consumer": consumer}


def _bwrap_prefix(workspace: pathlib.Path, candidate_dir: pathlib.Path, *, writable_workspace: bool) -> list[str]:
    bwrap = shutil.which("bwrap")
    if not bwrap:
        raise RuntimeError("Bubblewrap is required; candidate will not run unsandboxed")
    argv = [bwrap, "--die-with-parent", "--new-session", "--unshare-net", "--proc", "/proc", "--dev", "/dev"]
    for runtime in ("/usr", "/usr/local", "/bin", "/lib", "/lib64"):
        if pathlib.Path(runtime).exists():
            argv += ["--ro-bind", runtime, runtime]
    argv += (["--bind", str(workspace), "/workspace"] if writable_workspace else ["--ro-bind", str(workspace), "/workspace"])
    return [*argv, "--ro-bind", str(candidate_dir), "/candidate", "--tmpfs", "/tmp", "--setenv", "HOME", "/tmp", "--chdir", "/workspace"]


def _run(argv: list[str], *, timeout: int = 120) -> dict[str, Any]:
    started = time.perf_counter()
    result = subprocess.run(argv, text=True, capture_output=True, timeout=timeout)
    rss = re.search(r"__CHIMERA_RSS_KB__=(\d+)", result.stderr)
    return {"status": result.returncode, "duration_ms": round((time.perf_counter() - started) * 1000, 3), "rss_kb": int(rss.group(1)) if rss else None, "stdout": result.stdout, "stderr": result.stderr}


class LSPClient:
    def __init__(self, argv: list[str]) -> None:
        self.process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        assert self.process.stdin is not None and self.process.stdout is not None
        self.stdin, self.stdout = self.process.stdin, self.process.stdout
        self.next_id = 1
        self.notifications: list[dict[str, Any]] = []
        self._sampling = True
        self._peak_rss_kb = 0
        self._thread = threading.Thread(target=self._sample_tree_rss, daemon=True)
        self._thread.start()

    def _sample_tree_rss(self) -> None:
        while self._sampling:
            try:
                parents: dict[int, int] = {}
                for item in pathlib.Path("/proc").iterdir():
                    if item.name.isdigit():
                        try:
                            parents[int(item.name)] = int((item / "stat").read_text().split()[3])
                        except (OSError, ValueError, IndexError):
                            pass
                pids = {self.process.pid}
                changed = True
                while changed:
                    changed = False
                    for pid, parent in parents.items():
                        if parent in pids and pid not in pids:
                            pids.add(pid); changed = True
                value = 0
                for pid in pids:
                    try:
                        match = re.search(r"^VmRSS:\s+(\d+)\s+kB", pathlib.Path(f"/proc/{pid}/status").read_text(), re.MULTILINE)
                        if match:
                            value += int(match.group(1))
                    except OSError:
                        pass
                self._peak_rss_kb = max(self._peak_rss_kb, value)
            except OSError:
                pass
            time.sleep(0.01)

    @property
    def peak_rss_kb(self) -> int:
        return self._peak_rss_kb

    def _send(self, message: dict[str, Any]) -> None:
        raw = json.dumps(message, separators=(",", ":")).encode()
        self.stdin.write(f"Content-Length: {len(raw)}\r\n\r\n".encode() + raw)
        self.stdin.flush()

    def _read(self) -> dict[str, Any]:
        headers: dict[str, str] = {}
        while True:
            line = self.stdout.readline()
            if line == b"":
                if self.process.poll() is not None:
                    raise RuntimeError("TypeScript LSP process ended before a response")
                continue
            if line in {b"\r\n", b"\n"}:
                break
            key, value = line.decode("ascii").split(":", 1)
            headers[key.lower()] = value.strip()
        return json.loads(self.stdout.read(int(headers["content-length"])))

    def notify(self, method: str, params: dict[str, Any]) -> None:
        self._send({"jsonrpc": "2.0", "method": method, "params": params})

    def request(self, method: str, params: dict[str, Any]) -> tuple[Any, float]:
        request_id = self.next_id; self.next_id += 1
        started = time.perf_counter()
        self._send({"jsonrpc": "2.0", "id": request_id, "method": method, "params": params})
        while True:
            message = self._read()
            if message.get("id") == request_id:
                return message.get("result"), round((time.perf_counter() - started) * 1000, 3)
            self.notifications.append(message)

    def close(self) -> tuple[int, str]:
        try:
            self.request("shutdown", {})
            self.notify("exit", {})
        finally:
            self._sampling = False
            self._thread.join(timeout=1)
        self.process.wait(timeout=10)
        assert self.process.stderr is not None
        return int(self.process.returncode or 0), self.process.stderr.read().decode(errors="replace")[-1000:]


def _uri(path: str) -> str:
    return "file:///workspace/" + path


def _position(text: str, needle: str, occurrence: int = 0) -> dict[str, int]:
    start = 0; offset = -1
    for _ in range(occurrence + 1):
        offset = text.index(needle, start); start = offset + len(needle)
    return {"line": text[:offset].count("\n"), "character": offset - (text.rfind("\n", 0, offset) + 1) + 1}


def _has_location(result: Any, path: str, line: int | None = None) -> bool:
    for item in result if isinstance(result, list) else [result]:
        if not isinstance(item, dict):
            continue
        if not str(item.get("uri") or item.get("targetUri") or "").endswith("/" + path):
            continue
        start = (item.get("range") or item.get("targetRange") or {}).get("start", {}).get("line")
        if line is None or start == line:
            return True
    return False


def _current_graph_probe(root: pathlib.Path) -> dict[str, Any]:
    from chimera.graph import CodeGraph
    graph = CodeGraph(root); graph.build()
    definition = any(node.get("file") == "src/generated.ts" and node.get("name") == "generatedNormalize" for node in graph.search("generatedNormalize", limit=10))
    imports = any(node.get("file") == "src/consumer.ts" and node.get("kind") == "Import" and "generated" in str(node.get("name")) for node in graph.graph["nodes"])
    references = False  # Current graph has no semantic occurrence database.
    call_hierarchy = False  # Generic TS extraction intentionally emits no CALLS edges.
    config = False
    generated_map = False
    consumer = root / "src" / "consumer.ts"
    original = consumer.read_text(encoding="utf-8")
    consumer.write_text(original.replace("generatedNormalize", "generatedNormalizeV2"), encoding="utf-8")
    stale_before = any(node.get("name") == "generatedNormalize" for node in graph.search("generatedNormalize", limit=10))
    graph.update({"ops": [{"op": "write", "path": "src/consumer.ts"}]})
    fresh_after = any(node.get("name") == "generatedNormalizeV2" for node in graph.search("generatedNormalizeV2", limit=10))
    consumer.write_text(original, encoding="utf-8")
    return {"definition_lookup": definition, "import_node": imports, "references": references, "call_hierarchy": call_hierarchy, "build_config_exclusion": config, "declaration_source_map": generated_map, "cross_language_mapping": False, "stale_before_explicit_update": stale_before, "fresh_after_explicit_update": fresh_after}


def run(*, candidate_dir: pathlib.Path) -> dict[str, Any]:
    lock = json.loads(LOCK_PATH.read_text())
    candidate_dir = pathlib.Path(candidate_dir).resolve()
    server = candidate_dir / lock["server_entrypoint"]
    tsserver = candidate_dir / lock["typescript_tsserver"]
    if _sha(server) != lock["server_entrypoint_sha256"] or _sha(tsserver) != lock["typescript_tsserver_sha256"]:
        raise ValueError("TypeScript semantic candidate entrypoint hash mismatch")
    with tempfile.TemporaryDirectory(prefix="chimera-ts-semantic-") as raw:
        workspace = pathlib.Path(raw) / "workspace"; workspace.mkdir()
        texts = _write_fixture(workspace)
        # Build generated declarations and source maps using the pinned compiler
        # in an isolated, disposable writeable build view.
        build = _run([*_bwrap_prefix(workspace, candidate_dir, writable_workspace=True), "/usr/bin/time", "-f", "__CHIMERA_RSS_KB__=%M", "/usr/bin/node", "/candidate/node_modules/typescript/lib/tsc.js", "-p", "/workspace"], timeout=120)
        if build["status"] != 0:
            raise RuntimeError("pinned TypeScript build failed: " + build["stderr"][-500:])
        declaration_map = (workspace / "dist" / "generated.d.ts.map").exists()
        source_map = (workspace / "dist" / "consumer.js.map").exists()
        initial = _tree_digest(workspace)
        graph = _current_graph_probe(workspace)
        (workspace / "src" / "consumer.ts").write_text(texts["consumer"], encoding="utf-8")
        candidate_before = _tree_digest(workspace)
        client = LSPClient([*_bwrap_prefix(workspace, candidate_dir, writable_workspace=False), "/usr/bin/node", "/candidate/node_modules/typescript-language-server/lib/cli.mjs", "--stdio"])
        initialized, initialized_ms = client.request("initialize", {"processId": None, "rootUri": "file:///workspace", "workspaceFolders": [{"uri": "file:///workspace", "name": "workspace"}], "capabilities": {"textDocument": {"definition": {}, "references": {}, "documentSymbol": {}, "callHierarchy": {}}, "workspace": {"symbol": {}}}})
        client.notify("initialized", {})
        open_files = [("src/schema.ts", "typescript", texts["schema"]), ("src/generated.ts", "typescript", texts["generated"]), ("src/consumer.ts", "typescript", texts["consumer"]), ("dist/generated.d.ts", "typescript", (workspace / "dist" / "generated.d.ts").read_text()), ("dist/consumer.js", "javascript", (workspace / "dist" / "consumer.js").read_text())]
        for path, language, text in open_files:
            client.notify("textDocument/didOpen", {"textDocument": {"uri": _uri(path), "languageId": language, "version": 1, "text": text}})
        import_def, import_ms = client.request("textDocument/definition", {"textDocument": {"uri": _uri("src/consumer.ts")}, "position": _position(texts["consumer"], "GeneratedContract")})
        source_def, source_ms = client.request("textDocument/definition", {"textDocument": {"uri": _uri("src/generated.ts")}, "position": _position(texts["generated"], "SourceContract")})
        references, references_ms = client.request("textDocument/references", {"textDocument": {"uri": _uri("src/schema.ts")}, "position": _position(texts["schema"], "normalize"), "context": {"includeDeclaration": True}})
        hierarchy_item, hierarchy_prepare_ms = client.request("textDocument/prepareCallHierarchy", {"textDocument": {"uri": _uri("src/consumer.ts")}, "position": _position(texts["consumer"], "route")})
        outgoing: Any = []; outgoing_ms = None
        if hierarchy_item:
            outgoing, outgoing_ms = client.request("callHierarchy/outgoingCalls", {"item": hierarchy_item[0]})
        symbols, symbols_ms = client.request("textDocument/documentSymbol", {"textDocument": {"uri": _uri("src/consumer.ts")}})
        excluded, excluded_ms = client.request("workspace/symbol", {"query": "ignoredOnly"})
        dts_def, dts_ms = client.request("textDocument/definition", {"textDocument": {"uri": _uri("dist/generated.d.ts")}, "position": _position((workspace / "dist" / "generated.d.ts").read_text(), "GeneratedContract")})
        js_def, js_ms = client.request("textDocument/definition", {"textDocument": {"uri": _uri("dist/consumer.js")}, "position": _position((workspace / "dist" / "consumer.js").read_text(), "generatedNormalize")})
        cross_lang, cross_lang_ms = client.request("workspace/symbol", {"query": "PythonSchemaContract"})
        changed_generated = texts["generated"].replace("generatedNormalize", "generatedNormalizeV2")
        changed_consumer = texts["consumer"].replace("generatedNormalize", "generatedNormalizeV2")
        client.notify("textDocument/didChange", {"textDocument": {"uri": _uri("src/generated.ts"), "version": 2}, "contentChanges": [{"text": changed_generated}]})
        client.notify("textDocument/didChange", {"textDocument": {"uri": _uri("src/consumer.ts"), "version": 2}, "contentChanges": [{"text": changed_consumer}]})
        changed_def, changed_ms = client.request("textDocument/definition", {"textDocument": {"uri": _uri("src/consumer.ts")}, "position": _position(changed_consumer, "generatedNormalizeV2")})
        exit_code, stderr = client.close()
        candidate_after = _tree_digest(workspace)
    caps = initialized.get("capabilities", {}) if isinstance(initialized, dict) else {}
    outgoing_names = [row.get("to", {}).get("name") for row in outgoing if isinstance(row, dict)] if isinstance(outgoing, list) else []
    return {
        "schema_version": "chimera.typescript-semantic-lsp-candidate-benchmark.v1",
        "candidate_lock": lock,
        "build": {"status": build["status"], "duration_ms": build["duration_ms"], "rss_kb": build["rss_kb"], "declaration_map_emitted": declaration_map, "source_map_emitted": source_map},
        "isolation": {"backend": "bubblewrap", "network_namespace": True, "workspace_candidate_bind": "read-only", "initial_workspace_digest": initial, "workspace_digest_before_candidate": candidate_before, "workspace_digest_after_candidate": candidate_after, "workspace_unchanged_by_candidate": candidate_before == candidate_after, "server_exit_code": exit_code, "server_stderr_tail": stderr, "peak_process_tree_rss_kb": client.peak_rss_kb},
        "server_capabilities": {"definition": bool(caps.get("definitionProvider")), "references": bool(caps.get("referencesProvider")), "document_symbols": bool(caps.get("documentSymbolProvider")), "call_hierarchy": bool(caps.get("callHierarchyProvider"))},
        "operations": {
            "import_definition": {"passed": _has_location(import_def, "src/generated.ts", 2), "duration_ms": import_ms},
            "generated_to_source_definition": {"passed": _has_location(source_def, "src/schema.ts", 0), "duration_ms": source_ms},
            "references": {"passed": _has_location(references, "src/schema.ts", 1) and _has_location(references, "src/generated.ts", 1), "count": len(references or []), "duration_ms": references_ms},
            "outgoing_call_hierarchy": {"passed": "generatedNormalize" in outgoing_names, "duration_ms": outgoing_ms},
            "document_symbols": {"passed": any(isinstance(row, dict) and row.get("name") == "route" for row in (symbols or [])), "duration_ms": symbols_ms},
            "build_config_exclusion": {"passed": not bool(excluded), "duration_ms": excluded_ms},
            "declaration_map_navigation": {"passed": _has_location(dts_def, "src/generated.ts", 2), "duration_ms": dts_ms},
            "source_map_navigation": {"passed": _has_location(js_def, "src/generated.ts", 3), "duration_ms": js_ms},
            "cross_language_python_to_typescript_mapping": {"passed": False, "observed_results": len(cross_lang or []), "duration_ms": cross_lang_ms, "reason": "TypeScript LSP does not establish Python-to-TypeScript generator provenance from a comment"},
            "live_did_change_freshness": {"passed": _has_location(changed_def, "src/generated.ts", 3), "duration_ms": changed_ms},
        },
        "current_python_graph": graph,
        "automatic_enablement": False,
        "manual_promotion_required": True,
        "limits": ["This is a sealed TypeScript fixture, not a full Chimera or monorepo evaluation.", "Declaration/source maps are TypeScript build artifacts, not cross-language generator provenance.", "No SCIP index was produced; this is a pinned semantic LSP comparison."],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-dir", type=pathlib.Path, required=True)
    parser.add_argument("--results", type=pathlib.Path, default=ROOT / "artifacts" / "typescript_semantic_lsp_candidate_benchmark.json")
    args = parser.parse_args()
    report = run(candidate_dir=args.candidate_dir)
    args.results.parent.mkdir(parents=True, exist_ok=True)
    temp = args.results.with_suffix(args.results.suffix + ".tmp")
    temp.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, args.results)
    print(json.dumps({"operations": report["operations"], "build": report["build"], "isolation": report["isolation"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
