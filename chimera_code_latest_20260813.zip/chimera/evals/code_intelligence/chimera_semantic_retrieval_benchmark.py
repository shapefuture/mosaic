#!/usr/bin/env python3
"""Evaluate the snapshot-bound semantic port on held-out actual-Chimera queries.

By default this measures the deterministic read-only CodeGraph adapter.  A
contained LSP primary may be supplied through a typed launch-spec JSON file.  An
exact tokenizer command is optional for mechanics, but absent measurements make
this receipt ineligible for promotion.  No result enables an adapter.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import shutil
import statistics
import sys
import tempfile
from typing import Any

ROOT = pathlib.Path(__file__).resolve().parents[2]
CORPUS = pathlib.Path(__file__).with_name("chimera_semantic_retrieval_corpus_v1.json")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from chimera.semantic_code_intelligence import (
    CodeGraphSemanticAdapter,
    SemanticCodeIntelligenceRouter,
    SemanticPosition,
    SemanticQueryRequest,
    WorkspaceSnapshotter,
)
from chimera.semantic_lsp import LSPLaunchSpec, LSPSubprocessSemanticAdapter
from chimera.semantic_lsp_warm import WarmLSPSubprocessSemanticSession
from chimera.tokenizer import TokenizerMeasurer


def _sha(path: pathlib.Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _position(root: pathlib.Path, case: dict[str, Any]) -> SemanticPosition | None:
    if not case.get("needle"):
        return None
    text = (root / case["path"]).read_text(encoding="utf-8")
    needle = str(case["needle"])
    occurrence = int(case.get("occurrence", 0))
    cursor = 0
    offset = -1
    for _ in range(occurrence + 1):
        offset = text.index(needle, cursor)
        cursor = offset + len(needle)
    line = text.count("\n", 0, offset)
    character = offset - (text.rfind("\n", 0, offset) + 1)
    return SemanticPosition(line=line, character=character + min(1, len(needle) - 1))


def _stale_drill(tokenizer: TokenizerMeasurer) -> bool:
    with tempfile.TemporaryDirectory(prefix="chimera-semantic-stale-") as raw:
        root = pathlib.Path(raw)
        source = root / "sample.py"
        source.write_text("def value():\n    return 1\n")
        snapshotter = WorkspaceSnapshotter(root)
        snapshot = snapshotter.capture()
        source.write_text("def value():\n    return 2\n")
        router = SemanticCodeIntelligenceRouter(
            root,
            fallback=CodeGraphSemanticAdapter(root, snapshotter=snapshotter, tokenizer=tokenizer),
            snapshotter=snapshotter,
        )
        receipt = router.query(SemanticQueryRequest(
            request_id="semantic:stale-drill",
            snapshot_digest=snapshot.digest,
            operation="workspace_symbols",
            query="value",
        ))
        return receipt.status == "rejected" and receipt.stale_state_rejected and not receipt.results


def run(
    *,
    root: pathlib.Path,
    corpus_path: pathlib.Path,
    tokenizer: TokenizerMeasurer,
    lsp_spec: LSPLaunchSpec | None,
    context_budget: int,
    warm_session: bool = False,
) -> dict[str, Any]:
    corpus = json.loads(corpus_path.read_text(encoding="utf-8"))
    snapshotter = WorkspaceSnapshotter(root)
    snapshot = snapshotter.capture()
    fallback = CodeGraphSemanticAdapter(root, snapshotter=snapshotter, tokenizer=tokenizer)
    primary = None
    if lsp_spec is not None:
        primary_type = WarmLSPSubprocessSemanticSession if warm_session else LSPSubprocessSemanticAdapter
        primary = primary_type(root, lsp_spec, snapshotter=snapshotter, tokenizer=tokenizer)
    router = SemanticCodeIntelligenceRouter(
        root,
        primary=primary,
        fallback=fallback,
        snapshotter=snapshotter,
    )
    rows = []
    for case in corpus["cases"]:
        request = SemanticQueryRequest(
            request_id="semantic:" + str(case["id"]),
            snapshot_digest=snapshot.digest,
            operation=case["operation"],
            path=case.get("path"),
            position=_position(root, case),
            query=case.get("query"),
            timeout_seconds=20,
            max_results=200,
            max_context_tokens=context_budget,
            tokenizer_model="semantic-benchmark",
        )
        receipt = router.query(request)
        paths = {item.path for item in receipt.results}
        symbols = {item.symbol for item in receipt.results if item.symbol}
        expected_paths = set(case["expected_paths"])
        expected_symbols = set(case.get("expected_symbols", ()))
        path_recall = len(paths & expected_paths) / len(expected_paths) if expected_paths else 1.0
        symbol_recall = len(symbols & expected_symbols) / len(expected_symbols) if expected_symbols else 1.0
        context_precision = (
            sum(item.path in expected_paths for item in receipt.results) / len(receipt.results)
            if receipt.results else 0.0
        )
        rows.append({
            "id": case["id"],
            "intent": case["intent"],
            "status": receipt.status,
            "adapter_id": receipt.adapter_id,
            "fallback_reason": receipt.fallback_reason,
            "path_recall": path_recall,
            "symbol_recall": symbol_recall,
            "context_precision": context_precision,
            "result_count": len(receipt.results),
            "context_tokens": receipt.token_measurement.tokens if receipt.token_measurement else None,
            "token_status": receipt.token_measurement.status if receipt.token_measurement else "missing",
            "context_budget_satisfied": receipt.context_budget_satisfied,
            "latency_ms": receipt.latency_ms,
            "expected_paths": sorted(expected_paths),
            "returned_paths": sorted(paths),
            "expected_symbols": sorted(expected_symbols),
            "returned_symbols": sorted(symbols),
            "passed": receipt.status in {"completed", "fallback"} and path_recall == 1.0 and symbol_recall == 1.0,
        })
    if primary is not None and hasattr(primary, "close"):
        primary.close()
    latencies = [float(row["latency_ms"]) for row in rows]
    exact_tokens = all(row["token_status"] == "measured" for row in rows)
    all_passed = all(row["passed"] for row in rows)
    stale_rejected = _stale_drill(tokenizer)
    return {
        "schema_version": "chimera.semantic-retrieval-benchmark.v1",
        "partition": corpus.get("partition"),
        "evaluator_epoch": corpus.get("evaluator_epoch"),
        "corpus_hash": _sha(corpus_path),
        "source_snapshot_digest": snapshot.digest,
        "cases": len(rows),
        "case_recall": sum(row["passed"] for row in rows) / len(rows) if rows else None,
        "mean_context_precision": statistics.fmean(row["context_precision"] for row in rows) if rows else None,
        "median_latency_ms": statistics.median(latencies) if latencies else None,
        "exact_token_measurement_complete": exact_tokens,
        "stale_state_rejected": stale_rejected,
        "primary_adapter_configured": primary is not None,
        "warm_session": bool(primary is not None and warm_session),
        "fallback_count": sum(row["status"] == "fallback" for row in rows),
        "rows": rows,
        "accepted_for_manual_review": all_passed and exact_tokens and stale_rejected and primary is not None,
        "automatic_enablement": False,
        "manual_promotion_required": True,
        "limits": [
            "A checked-in held-out partition is a reproducible regression corpus, not secrecy from future development.",
            "A primary adapter must still run inside Bubblewrap or an explicitly equivalent outer sandbox.",
            "No retrieval receipt grants write, provider, MCP, branch, or promotion authority.",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=pathlib.Path, default=ROOT)
    parser.add_argument("--corpus", type=pathlib.Path, default=CORPUS)
    parser.add_argument("--tokenizer-command", default=None)
    parser.add_argument("--tokenizer-json", type=pathlib.Path, default=None)
    parser.add_argument("--lsp-spec", type=pathlib.Path, default=None)
    parser.add_argument("--context-budget", type=int, default=2_000)
    parser.add_argument("--warm-session", action="store_true")
    parser.add_argument("--results", type=pathlib.Path, default=ROOT / "artifacts" / "chimera_semantic_retrieval_benchmark.json")
    args = parser.parse_args()
    if not 0 <= args.context_budget <= 100_000:
        parser.error("--context-budget must be in [0, 100000]")
    tokenizer = TokenizerMeasurer(command=args.tokenizer_command, tokenizer_json=args.tokenizer_json)
    spec = LSPLaunchSpec.model_validate_json(args.lsp_spec.read_text()) if args.lsp_spec else None
    result = run(
        root=args.root.resolve(),
        corpus_path=args.corpus.resolve(),
        tokenizer=tokenizer,
        lsp_spec=spec,
        context_budget=args.context_budget,
        warm_session=args.warm_session,
    )
    args.results.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.results.with_suffix(args.results.suffix + ".tmp")
    temporary.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, args.results)
    print(json.dumps({
        key: result[key] for key in (
            "cases", "case_recall", "mean_context_precision", "exact_token_measurement_complete",
            "stale_state_rejected", "primary_adapter_configured", "fallback_count", "accepted_for_manual_review",
        )
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
