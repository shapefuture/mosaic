#!/usr/bin/env python3
"""Exercise an explicit source-to-generated mapping producer and consumer.

The fixture generator deliberately supports one tiny contract shape: a Python
class declaration becomes a TypeScript interface declaration. Its value is not
as a general transpiler. It proves that source/generated navigation can require
an exact, attested, byte-bound mapping contract rather than comments, text
search, or ordinary TypeScript source maps.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import pathlib
import sys
import tempfile
from statistics import median


ROOT = pathlib.Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from chimera.artifacts import ContentAddressedArtifactStore
from chimera.generated_code_mapping import (
    GeneratedMappingIndex,
    GeneratedMappingVerifier,
    GeneratorIdentity,
    GeneratorMappingContract,
    SourceGeneratedEdge,
    SourceRange,
)


def _sha(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _file_sha(path: pathlib.Path) -> str:
    return _sha(path.read_bytes())


def _range_for(text: str, token: str) -> tuple[int, int, int, int]:
    offset = text.index(token)
    start_line = text[:offset].count("\n")
    start_char = offset - (text.rfind("\n", 0, offset) + 1)
    return start_line, start_char, start_line, start_char + len(token)


def _generate(root: pathlib.Path) -> tuple[GeneratorMappingContract, ContentAddressedArtifactStore]:
    schema = root / "schema.py"
    generated = root / "generated.ts"
    text = schema.read_text(encoding="utf-8")
    parsed = ast.parse(text, filename=str(schema))
    classes = [node for node in parsed.body if isinstance(node, ast.ClassDef)]
    if len(classes) != 1:
        raise ValueError("fixture generator requires exactly one top-level Python class")
    name = classes[0].name
    generated_text = f"export interface Generated{name} {{\n  id: string\n}}\n"
    generated.write_text(generated_text, encoding="utf-8")
    store = ContentAddressedArtifactStore(root)
    manifest = {"input": "schema.py", "input_digest": _file_sha(schema), "output": "generated.ts", "generator": "chimera-fixture-python-class-to-ts-interface-v1"}
    producer = store.put(json.dumps(manifest, sort_keys=True), media_type="application/vnd.chimera.generator-receipt+json")
    sl, sc, el, ec = _range_for(text, name)
    gl, gc, gel, gec = _range_for(generated_text, "Generated" + name)
    command_digest = _sha(b"chimera-fixture-python-class-to-ts-interface-v1")
    contract = GeneratorMappingContract(
        generator=GeneratorIdentity(
            generator_id="chimera-fixture-python-class-to-ts-interface",
            generator_version="1",
            generator_command_digest=command_digest,
            input_manifest_digest=_sha(json.dumps(manifest, sort_keys=True).encode()),
            producer_evidence_ref="artifact:" + producer.digest,
        ),
        edges=(SourceGeneratedEdge(
            id="python-class-to-typescript-interface",
            source=SourceRange(path="schema.py", start_line=sl, start_character=sc, end_line=el, end_character=ec, file_digest=_file_sha(schema)),
            generated=SourceRange(path="generated.ts", start_line=gl, start_character=gc, end_line=gel, end_character=gec, file_digest=_file_sha(generated)),
        ),),
    )
    (root / "generated.mapping.json").write_text(contract.model_dump_json(indent=2), encoding="utf-8")
    return contract, store


def _one() -> dict:
    with tempfile.TemporaryDirectory(prefix="chimera-explicit-generator-") as raw:
        root = pathlib.Path(raw)
        (root / "schema.py").write_text("class PythonSchemaContract:\n    pass\n", encoding="utf-8")
        contract, store = _generate(root)
        verifier = GeneratedMappingVerifier(root, evidence_resolver=lambda ref: store.has(ref.removeprefix("artifact:")))
        receipt = verifier.verify(contract)
        index = GeneratedMappingIndex(contract, receipt)
        generated_to_source = index.generated_to_source(path="generated.ts", line=0, character=20)
        source_to_generated = index.source_to_generated(path="schema.py", line=0, character=10)
        # Drift must invalidate the old contract before an old edge is reused.
        (root / "schema.py").write_text("class DriftedSchema:\n    pass\n", encoding="utf-8")
        source_drift = verifier.verify(contract)
        (root / "schema.py").write_text("class PythonSchemaContract:\n    pass\n", encoding="utf-8")
        (root / "generated.ts").write_text("export interface DriftedGenerated {}\n", encoding="utf-8")
        generated_drift = verifier.verify(contract)
        untrusted = GeneratedMappingVerifier(root, evidence_resolver=lambda _ref: False).verify(contract)
        return {
            "verified": receipt.status == "verified",
            "producer_evidence_resolved": receipt.evidence_resolved,
            "generated_to_source": [item.model_dump(mode="json") for item in generated_to_source],
            "source_to_generated": [item.model_dump(mode="json") for item in source_to_generated],
            "source_drift_rejected": source_drift.status == "rejected" and any("source file digest drifted" in item for item in source_drift.errors),
            "generated_drift_rejected": generated_drift.status == "rejected" and any("generated file digest drifted" in item for item in generated_drift.errors),
            "unresolved_evidence_rejected": untrusted.status == "rejected" and not untrusted.evidence_resolved,
            "contract_digest": contract.digest,
            "producer_evidence_ref": contract.generator.producer_evidence_ref,
        }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repetitions", type=int, default=5)
    parser.add_argument("--results", type=pathlib.Path, default=ROOT / "artifacts" / "explicit_generator_mapping_campaign.json")
    args = parser.parse_args()
    if not 1 <= args.repetitions <= 50:
        parser.error("--repetitions must be in [1, 50]")
    rows = [_one() for _ in range(args.repetitions)]
    required = ("verified", "producer_evidence_resolved", "source_drift_rejected", "generated_drift_rejected", "unresolved_evidence_rejected")
    result = {
        "schema_version": "chimera.explicit-generator-mapping-campaign.v1",
        "runs": len(rows),
        "all_required_facts_passed": all(all(row[key] for key in required) and bool(row["generated_to_source"]) and bool(row["source_to_generated"]) for row in rows),
        "facts": {key: sum(bool(row[key]) for row in rows) for key in required},
        "contract_digests": sorted({row["contract_digest"] for row in rows}),
        "rows": rows,
        "automatic_enablement": False,
        "manual_promotion_required": True,
        "limits": [
            "The fixture generator covers one explicit Python-class to TypeScript-interface mapping shape only.",
            "The mapping is exact provenance/navigation metadata, not a proof of semantic equivalence across languages.",
            "No LSP, SCIP, codegraph, MCP, branch, provider, or promotion path consumes the mapping automatically.",
        ],
    }
    args.results.parent.mkdir(parents=True, exist_ok=True)
    temp = args.results.with_suffix(args.results.suffix + ".tmp")
    temp.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, args.results)
    print(json.dumps({"runs": result["runs"], "all_required_facts_passed": result["all_required_facts_passed"], "facts": result["facts"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
