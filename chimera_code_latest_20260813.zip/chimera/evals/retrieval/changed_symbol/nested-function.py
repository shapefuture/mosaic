def outer():
    def inner():
        return 2
    return inner()


def untouched():
    return 3
