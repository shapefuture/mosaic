class Widget:
    def render(self):
        return "new"


def helper():
    return None
