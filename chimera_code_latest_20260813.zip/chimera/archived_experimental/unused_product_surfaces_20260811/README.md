# Archived unused product surfaces — 2026-08-11

These modules had no production/test importers and zero executed coverage. They
were removed from the installable `chimera` package so prototype names cannot be
mistaken for supported capabilities.

- `agentscope.py`: descriptive provider claims, no adapter.
- `godel.py`: explicitly simulated Datalog stub; CodeGraph retains its separately
  tested bounded query surface.
- `silent_transform.py`: unused prototype ledger.
- `stop_reasons.py`: unused vocabulary not wired to run results.

Promotion requires an owner, a real port/adapter, behavior tests, and a truthful
capability receipt.
