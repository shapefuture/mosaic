"""Closed vocabulary for agent stop/escalation reasons."""
from __future__ import annotations
from enum import StrEnum
from dataclasses import dataclass, asdict

class StopReason(StrEnum):
    COMPLETE_VERIFIED="complete_verified"
    PARTIAL_KNOWN_RISKS="partial_known_risks"
    PREFLIGHT_FAILED="preflight_failed"
    RETRY_CAP_REACHED="retry_cap_reached"
    PROVIDER_UNAVAILABLE="provider_unavailable"
    HUMAN_APPROVAL_REQUIRED="human_approval_required"
    INTEGRITY_VIOLATION="integrity_violation"
    TOOL_PROTOCOL_FAILED="tool_protocol_failed"
    UNKNOWN_FAILURE="unknown_failure"

@dataclass(frozen=True)
class StopDecision:
    reason: StopReason
    detail: str
    retryable: bool=False
    def as_dict(self):
        row=asdict(self); row['reason']=self.reason.value; return row
