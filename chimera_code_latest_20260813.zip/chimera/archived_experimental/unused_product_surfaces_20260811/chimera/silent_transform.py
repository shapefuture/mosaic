"""Confession protocol for truncation/fallback/transformation events."""
from __future__ import annotations

from dataclasses import dataclass, asdict
import pathlib, re
from .wal import WAL, wal_write

@dataclass(frozen=True)
class SilentTransform:
    kind: str
    scope: str
    reason: str
    def as_dict(self): return asdict(self)

class SilentTransformLedger:
    def __init__(self, root: pathlib.Path): self.wal=WAL(pathlib.Path(root))
    def confess(self, kind:str, scope:str, reason:str)->SilentTransform:
        row=SilentTransform(kind, scope, reason); wal_write(self.wal, "silent_transform", row.as_dict()); return row

FALLBACK_WORDS=("fallback", "truncat", "omitted", "pruned", "compact", "unavailable")

def lint_source_for_unconfessed_transforms(path: pathlib.Path)->list[str]:
    text=path.read_text(errors='ignore')
    findings=[]
    for lineno,line in enumerate(text.splitlines(),1):
        low=line.lower()
        if any(word in low for word in FALLBACK_WORDS) and "silent_transform" not in low and "confess(" not in low:
            # Comments/docstrings only are not executable obligations.
            stripped=line.strip()
            if stripped.startswith('#') or stripped.startswith('"') or stripped.startswith("'"):
                continue
            findings.append(f"{path}:{lineno}: transform/fallback lacks nearby confession")
    return findings
