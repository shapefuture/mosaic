
"""
Gödel / CodeFuse-Query — Datalog for code (COREF facts -> Soufflé)

Per PRD §7.2/11: Gödel declarative, monotonic, terminating.
Code -> COREF facts -> Soufflé -> query results.

For Python harness: simulates Gödel via Python fact generation + in-memory Datalog.

Example Gödel:
  fact Function(id, name, file)
  fact Calls(caller, callee)
  query blastRadius(auth) :- Calls(_, func) where func.name contains "auth"
  code -> COREF facts via CodeGraph nodes/edges -> evaluate

Provides:
- generate_facts(graph) -> COREF facts
- souffle_eval(facts, query) -> results (monotonic, terminating)
"""
from __future__ import annotations
import pathlib, json, re
from typing import Dict, List, Any

def generate_coref_facts(graph: Dict) -> Dict[str, List[Dict]]:
    facts={"Function": [], "Class": [], "File": [], "Calls": [], "Contains": [], "Import": []}
    for n in graph.get("nodes", []):
        kind=n.get("kind")
        if kind=="Function": facts["Function"].append({"id": n["id"], "name": n["name"], "file": n["file"]})
        elif kind=="Class": facts["Class"].append({"id": n["id"], "name": n["name"], "file": n["file"]})
        elif kind=="File": facts["File"].append({"id": n["id"], "file": n["file"]})
        elif kind=="Import": facts["Import"].append({"id": n["id"], "name": n["name"], "file": n["file"]})
    for e in graph.get("edges", []):
        if e.get("type")=="CONTAINS": facts["Contains"].append({"from": e["from"], "to": e["to"]})
        elif e.get("type")=="CALLS": facts["Calls"].append({"caller": e["from"], "callee": e["to"]})
        else: facts["Contains"].append({"from": e.get("from"), "to": e.get("to")})
    return facts

def souffle_eval(facts: Dict[str, List[Dict]], query: str) -> List[Dict]:
    """
    Monotonic Datalog evaluation stub (terminating).
    Supports:
    - `blastRadius(x) :- Function(f), Calls(c, f), f.name contains "auth"`
    - `select Function where name = "auth"`
    """
    q=query.lower()
    # Extract target kind
    m=re.search(r"select\s+(\w+)\s+where\s+(\w+)\s*=\s*\"([^\"]+)\"", query, re.IGNORECASE)
    if m:
        kind, field, val=m.group(1), m.group(2), m.group(3)
        # Map kind to facts
        candidates=facts.get(kind, facts.get(kind.capitalize(), []))
        return [f for f in candidates if val.lower() in str(f.get(field,"")).lower()][:20]
    # blastRadius
    if "blastradius" in q or "auth" in q:
        funcs=facts.get("Function", [])
        filtered=[f for f in funcs if "auth" in f.get("name","").lower() or "auth" in f.get("file","").lower()]
        # Expand via Calls monotonic: if func calls auth, include caller
        calls=facts.get("Calls", [])
        callers=set(c["caller"] for c in calls for f in filtered if f["id"]==c["callee"])
        # Also include callers' functions
        callers_funcs=[f for f in funcs if f["id"] in callers]
        return (filtered+callers_funcs)[:20]
    # Generic contains
    m2=re.search(r"(\w+)\.name\s+contains\s+\"([^\"]+)\"", query, re.IGNORECASE)
    if m2:
        val=m2.group(2)
        funcs=facts.get("Function", [])
        return [f for f in funcs if val.lower() in f.get("name","").lower()][:20]
    return facts.get("Function", [])[:5]

def godel_query(graph: Dict, query: str) -> List[Dict]:
    facts=generate_coref_facts(graph)
    return souffle_eval(facts, query)
