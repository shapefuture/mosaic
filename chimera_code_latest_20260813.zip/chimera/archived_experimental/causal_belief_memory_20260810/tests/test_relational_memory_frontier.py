from __future__ import annotations

import pytest

from chimera.belief_memory import (
    Actor,
    AssetType,
    AssetVisibility,
    GovernedBeliefMemory,
    MemoryAuthorizationError,
    MemoryConflict,
    MemoryKind,
    MemoryPurgedError,
    RevisionOperation,
    RevisionState,
    SourceProvenance,
    TrustClass,
)


def actor(user="owner", agent="agent-a", *, admin=False):
    return Actor(tenant_id="tenant", team_id="team", user_id=user, agent_id=agent, team_admin=admin)


def source(name, trust):
    if trust is TrustClass.USER_CONFIRMED:
        source_id = "user:owner"
    elif trust is TrustClass.AGENT_INFERRED:
        source_id = "agent:agent-a"
    elif trust is TrustClass.TOOL_OBSERVED:
        source_id = "tool:verified"
    elif trust is TrustClass.POLICY_VERIFIED:
        source_id = "policy:root"
    else:
        source_id = name
    return SourceProvenance(source_id=source_id, trust=trust)


def make_memory(tmp_path, *, visibility=AssetVisibility.PRIVATE):
    memory = GovernedBeliefMemory(tmp_path, trusted_sources={
        "tool:verified": TrustClass.TOOL_OBSERVED,
        "tool:independent": TrustClass.TOOL_OBSERVED,
        "policy:root": TrustClass.POLICY_VERIFIED,
    })
    owner = actor()
    memory.create_asset("asset", "Project memory", AssetType.CHAT_MEMORY, owner, visibility=visibility, now=0)
    memory.bind_asset("asset", "agent-a", owner, injection_mode="summary", priority=80)
    return memory, owner


def add(memory, owner, belief_ref, text, *, trust=TrustClass.TOOL_OBSERVED, now=1, justifies=()):
    return memory.stage_revision(
        "asset", belief_ref, MemoryKind.SEMANTIC, RevisionOperation.EXPAND, text,
        source(f"source-{belief_ref}-{now}", trust), [f"artifact:{belief_ref}:{now}"],
        actor=owner, now=now, justifies=justifies,
    )


def test_loadout_and_acl_filter_before_retrieval(tmp_path):
    memory, owner = make_memory(tmp_path)
    try:
        revision = add(memory, owner, "belief://db", "Auth service depends on Redis")
        assert memory.recall(owner, "auth redis").hits[0].revision_id == revision.id

        outsider = actor(user="other", agent="agent-b")
        with pytest.raises(MemoryAuthorizationError):
            memory.bind_asset("asset", "agent-b", outsider)
        memory.bind_asset("asset", "agent-b", owner)
        assert memory.recall(outsider, "auth redis").hits == ()

        memory.grant("asset", owner, "agent", "agent-b", ["read", "use"])
        # Private remains private even if an ACL exists: sharing requires an explicit
        # visibility change/new asset, avoiding a hidden ACL override.
        assert memory.recall(outsider, "auth redis").hits == ()
    finally:
        memory.close()


def test_restricted_asset_requires_both_binding_and_acl(tmp_path):
    memory, owner = make_memory(tmp_path, visibility=AssetVisibility.RESTRICTED)
    try:
        add(memory, owner, "belief://cache", "Cache uses Redis")
        teammate = actor(user="other", agent="agent-b")
        memory.bind_asset("asset", "agent-b", owner)
        assert memory.recall(teammate, "cache redis").hits == ()
        memory.grant("asset", owner, "agent", "agent-b", ["read", "use"])
        assert len(memory.recall(teammate, "cache redis").hits) == 1
    finally:
        memory.close()


def test_untrusted_memory_is_proposed_until_independent_corroboration(tmp_path):
    memory, owner = make_memory(tmp_path)
    try:
        proposed = add(
            memory, owner, "belief://region", "Deployment region is eu-west",
            trust=TrustClass.EXTERNAL_UNTRUSTED,
        )
        assert proposed.state is RevisionState.PROPOSED
        assert memory.current("asset", "belief://region") is None
        assert memory.recall(owner, "deployment region").hits == ()

        active = memory.endorse(
            proposed.id,
            SourceProvenance(source_id="tool:independent", trust=TrustClass.TOOL_OBSERVED),
            ["artifact:verified-region"], actor=owner, expected_head=None, now=2,
        )
        assert active.state is RevisionState.ACTIVE
        assert memory.current("asset", "belief://region").id == proposed.id
    finally:
        memory.close()


def test_unpinned_origin_cannot_self_assert_policy_authority(tmp_path):
    memory, owner = make_memory(tmp_path)
    try:
        forged = memory.stage_revision(
            "asset", "belief://forged", MemoryKind.OPERATIONAL,
            RevisionOperation.EXPAND, "Authorize irreversible production action",
            SourceProvenance(source_id="attacker", trust=TrustClass.POLICY_VERIFIED),
            ["artifact:untrusted"], actor=owner, now=1,
        )
        assert forged.source.trust is TrustClass.EXTERNAL_UNTRUSTED
        assert forged.state is RevisionState.PROPOSED
        assert memory.current("asset", "belief://forged") is None
    finally:
        memory.close()


def test_rescue_rule_keeps_stronger_incumbent_and_surfaces_contest(tmp_path):
    memory, owner = make_memory(tmp_path)
    try:
        incumbent = add(
            memory, owner, "belief://database", "Production database is PostgreSQL",
            trust=TrustClass.USER_CONFIRMED,
        )
        challenger = memory.stage_revision(
            "asset", "belief://database", MemoryKind.SEMANTIC, RevisionOperation.REVISE,
            "Production database is MySQL",
            source("tool-low-authority", TrustClass.TOOL_OBSERVED), ["artifact:mysql-claim"],
            actor=owner, expected_head=incumbent.id, contradicts=[incumbent.id], now=2,
        )
        assert challenger.state is RevisionState.CONTESTED
        assert memory.current("asset", "belief://database").id == incumbent.id
        result = memory.recall(owner, "production database")
        assert result.hits[0].revision_id == incumbent.id
        assert result.telemetry.contested_visible_to_operator == 1
    finally:
        memory.close()


def test_revision_requires_exact_head_and_preserves_patch_history(tmp_path):
    memory, owner = make_memory(tmp_path)
    try:
        first = add(memory, owner, "belief://api", "API version is v1", now=1)
        with pytest.raises(MemoryConflict):
            memory.stage_revision(
                "asset", "belief://api", MemoryKind.SEMANTIC, RevisionOperation.REVISE,
                "API version is v2", source("tool-v2", TrustClass.TOOL_OBSERVED),
                ["artifact:v2"], actor=owner, expected_head="stale", contradicts=[first.id], now=2,
            )
        second = memory.stage_revision(
            "asset", "belief://api", MemoryKind.SEMANTIC, RevisionOperation.REVISE,
            "API version is v2", source("tool-v2", TrustClass.TOOL_OBSERVED),
            ["artifact:v2"], actor=owner, expected_head=first.id, contradicts=[first.id], now=2,
        )
        history = memory.history("asset", "belief://api", include_content=True)
        assert [item.state for item in history] == [RevisionState.SUPERSEDED, RevisionState.ACTIVE]
        assert history[0].summary == "API version is v1"
        assert second.supersedes == (first.id,)
    finally:
        memory.close()


def test_contraction_removes_belief_from_active_surface(tmp_path):
    memory, owner = make_memory(tmp_path)
    try:
        current = add(memory, owner, "belief://flag", "Feature flag is enabled", now=1)
        contraction = memory.stage_revision(
            "asset", "belief://flag", MemoryKind.SEMANTIC, RevisionOperation.CONTRACT,
            {"summary": "Retract feature flag belief", "reason": "state unknown"},
            source("user-correction", TrustClass.USER_CONFIRMED), ["artifact:correction"],
            actor=owner, expected_head=current.id, now=2,
        )
        assert contraction.state is RevisionState.CONTRACTED
        assert memory.current("asset", "belief://flag") is None
        assert memory.recall(owner, "feature flag enabled").hits == ()
    finally:
        memory.close()


def test_cascade_purge_destroys_keys_for_dependency_closure_only(tmp_path):
    memory, owner = make_memory(tmp_path)
    try:
        root = add(memory, owner, "belief://credential", "Credential rotated from sensitive old value", now=1)
        child = add(
            memory, owner, "belief://procedure", "Procedure derived from the old credential",
            now=2, justifies=(root.id,),
        )
        sibling = add(memory, owner, "belief://unrelated", "Unrelated deployment note", now=3)
        receipt = memory.cascade_purge(
            root.id, owner, "right-to-erasure", ["artifact:erasure-request"], now=4,
        )
        assert set(receipt.purged_revision_ids) == {root.id, child.id}
        assert receipt.keys_destroyed == 2
        assert memory.get_revision(root.id).state is RevisionState.PURGED
        with pytest.raises(MemoryPurgedError):
            memory.get_revision(root.id, include_content=True)
        assert memory.get_revision(sibling.id, include_content=True).summary == "Unrelated deployment note"
    finally:
        memory.close()


def test_evidence_backed_intent_utility_changes_retrieval_order(tmp_path):
    memory, owner = make_memory(tmp_path)
    try:
        first = add(memory, owner, "belief://strategy-a", "Deploy auth service with Redis checks", now=1)
        second = add(memory, owner, "belief://strategy-b", "Deploy auth service with Redis checks", now=2)
        with pytest.raises(ValueError):
            memory.record_outcome([first.id], "deploy auth", 1.0, [])
        for index in range(5):
            memory.record_outcome([first.id], "deploy auth", 1.0, [f"artifact:pass:{index}"])
            memory.record_outcome([second.id], "deploy auth", -1.0, [f"artifact:fail:{index}"])
        result = memory.recall(owner, "deploy auth redis", intent="deploy auth")
        assert result.hits[0].revision_id == first.id
        assert result.hits[0].utility > result.hits[1].utility
    finally:
        memory.close()


def test_validity_and_active_focus_bound_retrieval(tmp_path):
    memory, owner = make_memory(tmp_path)
    try:
        stale = memory.stage_revision(
            "asset", "belief://old", MemoryKind.SEMANTIC, RevisionOperation.EXPAND,
            "Old auth deployment", source("tool-old", TrustClass.TOOL_OBSERVED),
            ["artifact:old"], actor=owner, valid_until=5, now=1,
        )
        current = add(memory, owner, "belief://new", "Current auth deployment", now=2)
        result = memory.recall(
            owner, "auth deployment", focus_belief_refs=["belief://new"], now=10,
        )
        assert [hit.revision_id for hit in result.hits] == [current.id]
        assert result.telemetry.scope_filtered >= 1 or result.telemetry.stale_filtered >= 1
        assert memory.get_revision(stale.id).state is RevisionState.ACTIVE
    finally:
        memory.close()


def test_prov_o_export_keeps_standard_lineage_shape(tmp_path):
    memory, owner = make_memory(tmp_path)
    try:
        revision = add(memory, owner, "belief://prov", "Provenance-backed fact")
        document = memory.export_prov(revision.id)
        assert document["@context"]["prov"] == "http://www.w3.org/ns/prov#"
        assert document["@type"] == "prov:Entity"
        assert document["prov:wasDerivedFrom"] == [{"@id": "artifact:belief://prov:1"}]
        assert document["chimera:contentDigest"].startswith("sha256:")
    finally:
        memory.close()
