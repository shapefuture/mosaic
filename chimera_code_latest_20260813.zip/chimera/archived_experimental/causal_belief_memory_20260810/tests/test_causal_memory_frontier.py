from __future__ import annotations

import pytest
from pydantic import ValidationError

from chimera.causal_memory import (
    ActionSchema,
    AssignmentKind,
    CausalInvariantError,
    CausalMemory,
    DiscoveryMethod,
    FactorKind,
    GroundingClaim,
    IdentificationMethod,
    InterventionState,
)
from chimera.context_evidence import ContextSigner


def setup_memory(tmp_path):
    signer = ContextSigner.generate_ephemeral()
    memory = CausalMemory(tmp_path, trusted_evaluators={"eval": signer.public_key})
    memory.register_action_schema(ActionSchema(
        action_name="retry_tool",
        treatment_var="action.retry_tool",
        outcome_var="post.last_error",
        candidate_confounders=("last_error", "user_goal_tag"),
    ))
    actions = []
    for index in range(2):
        text = f"Retry {index} cleared the build error and restored service."
        episode = memory.record_episode(
            "agent-a", text, authz="team", evidence_refs=[f"artifact:episode:{index}"], ts=index + 1,
        )
        span = memory.add_span(episode.id, 0, len(text))
        action = memory.record_action(
            episode.id,
            "retry_tool",
            {"attempt": index + 1},
            InterventionState(last_error="build failed", user_goal_tag="restore"),
            InterventionState(last_error=None, user_goal_tag="restore"),
            policy_ref="sha256:fixture-policy-v1",
            assignment=AssignmentKind.RANDOMIZED_INTERVENTION,
            assignment_probability=0.5,
            assignment_evidence_refs=[f"artifact:assignment:{index}"],
            evidence_refs=[f"artifact:action:{index}"],
            ts=index + 1,
        )
        actions.append((episode, span, action))
    return memory, signer, actions


def qualify_factor(memory, signer, factor, action_ids, *, cf_gain=0.1, r2=0.2):
    receipt = memory.sign_factor_validation(
        factor.id,
        cf_gain=cf_gain,
        recoverability_r2=r2,
        split_effects=(0.12, 0.09),
        heldout_action_ids=action_ids,
        evidence_refs=[f"artifact:factor-eval:{factor.id}"],
        evaluator_id="eval",
        signer=signer,
    )
    return memory.validate_factor(receipt)


def identify(memory, signer, edge, action_ids):
    receipt = memory.sign_identification(
        edge.id,
        method=IdentificationMethod.RANDOMIZED,
        effect_size=0.4,
        ci_low=0.2,
        ci_high=0.6,
        split_effects=(0.35, 0.44),
        adjustment_set=(),
        sample_size=20,
        overlap_min=1.0,
        action_ids=action_ids,
        evidence_refs=[f"artifact:edge-eval:{edge.id}"],
        evaluator_id="eval",
        signer=signer,
    )
    return memory.identify_edge(receipt)


def signed_gates(memory, signer):
    return (
        memory.sign_gate_result(
            "write-hallucination-nonregression", True, ["artifact:halumem"],
            evaluator_id="eval", signer=signer,
        ),
        memory.sign_gate_result(
            "causal-suite-nonregression", True, ["artifact:causal-suite"],
            evaluator_id="eval", signer=signer,
        ),
    )


def build_committed_graph(memory, signer, action_ids):
    branch = memory.create_branch("night-one", now=10)
    cause = memory.propose_factor(
        branch, "retry action", FactorKind.ACTION, (1.0, 0.0), ["artifact:cause"], now=11,
    )
    effect = memory.propose_factor(
        branch, "service restored", FactorKind.STATE, (0.0, 1.0), ["artifact:effect"], now=12,
    )
    qualify_factor(memory, signer, cause, action_ids)
    qualify_factor(memory, signer, effect, action_ids)
    edge = memory.propose_edge(
        branch, cause.id, effect.id, DiscoveryMethod.CONTROLLED_REPLAY,
        ["artifact:proposal"], now=13,
    )
    identify(memory, signer, edge, action_ids)
    gates = signed_gates(memory, signer)
    receipt = memory.merge_branch(
        branch, gates,
        required_gate_names=("write-hallucination-nonregression", "causal-suite-nonregression"),
        now=14,
    )
    return cause, effect, edge, receipt


def test_exact_episode_spans_and_crypto_erasure(tmp_path):
    memory, signer, rows = setup_memory(tmp_path)
    try:
        episode, span, _ = rows[0]
        replayed = memory.get_span(span.id)
        assert replayed.text == "Retry 0 cleared the build error and restored service."
        assert memory.store.get(episode.raw_blob_ref) != replayed.text.encode()
        memory.crypto_erase_episode(
            episode.id, reason="right-to-erasure", evidence_refs=["artifact:erase"],
        )
        with pytest.raises(FileNotFoundError):
            memory.get_span(span.id)
    finally:
        memory.close()


def test_action_logs_are_not_interventions_by_default(tmp_path):
    memory, signer, rows = setup_memory(tmp_path)
    try:
        episode = memory.record_episode(
            "agent-a", "ordinary action", authz="team", evidence_refs=["artifact:ordinary"], ts=9,
        )
        observed = memory.record_action(
            episode.id, "retry_tool", {"attempt": 1},
            InterventionState(last_error="x", user_goal_tag="restore"),
            InterventionState(last_error=None, user_goal_tag="restore"),
            policy_ref="sha256:fixture-policy-v1",
            evidence_refs=["artifact:observed"], ts=9,
        )
        assert not observed.causal_eligible
        with pytest.raises(ValidationError):
            InterventionState(user_goal_tag="x", unknown_state="unsafe")
        with pytest.raises(ValueError, match="assignment probability"):
            memory.record_action(
                episode.id, "retry_tool", {"attempt": 2},
                InterventionState(last_error="x", user_goal_tag="restore"),
                InterventionState(last_error=None, user_goal_tag="restore"),
                policy_ref="sha256:fixture-policy-v1",
                assignment=AssignmentKind.RANDOMIZED_INTERVENTION,
                assignment_evidence_refs=["artifact:randomized"],
                evidence_refs=["artifact:missing-probability"], ts=10,
            )

        branch = memory.create_branch("observed-only")
        factor = memory.propose_factor(
            branch, "candidate", FactorKind.LATENT, (0.2, 0.8), ["artifact:candidate"],
        )
        receipt = memory.sign_factor_validation(
            factor.id, cf_gain=0.2, recoverability_r2=0.1,
            split_effects=(0.2, 0.2),
            heldout_action_ids=[rows[0][2].id, observed.id],
            evidence_refs=["artifact:evaluation"], evaluator_id="eval", signer=signer,
        )
        with pytest.raises(ValueError, match="randomized or controlled-replay"):
            memory.validate_factor(receipt)
    finally:
        memory.close()


def test_signed_factor_and_edge_receipts_commit_all_or_nothing(tmp_path):
    memory, signer, rows = setup_memory(tmp_path)
    try:
        action_ids = [item[2].id for item in rows]
        cause, effect, edge, receipt = build_committed_graph(memory, signer, action_ids)
        assert set(receipt.committed_factor_ids) == {cause.id, effect.id}
        assert receipt.committed_edge_ids == (edge.id,)
        assert memory.get_factor(cause.id).status == "committed"
        assert memory.get_edge(edge.id).identified
    finally:
        memory.close()


def test_tampered_or_unpinned_evaluator_receipts_fail(tmp_path):
    memory, signer, rows = setup_memory(tmp_path)
    try:
        branch = memory.create_branch("tamper")
        factor = memory.propose_factor(
            branch, "factor", FactorKind.STATE, (0.3, 0.7), ["artifact:factor"],
        )
        receipt = memory.sign_factor_validation(
            factor.id, cf_gain=0.2, recoverability_r2=0.1,
            split_effects=(0.2, 0.2), heldout_action_ids=[item[2].id for item in rows],
            evidence_refs=["artifact:eval"], evaluator_id="eval", signer=signer,
        )
        with pytest.raises(PermissionError):
            memory.validate_factor(receipt.model_copy(update={"signature": "bad"}))
    finally:
        memory.close()


def test_cycle_precheck_rejects_reverse_edge_before_identification(tmp_path):
    memory, signer, rows = setup_memory(tmp_path)
    try:
        action_ids = [item[2].id for item in rows]
        cause, effect, _, _ = build_committed_graph(memory, signer, action_ids)
        branch = memory.create_branch("cycle")
        with pytest.raises(CausalInvariantError) as error:
            memory.propose_edge(
                branch, effect.id, cause.id, DiscoveryMethod.SERENDIPITY,
                ["artifact:reverse"],
            )
        assert error.value.violations[0].kind == "CycleViolation"
    finally:
        memory.close()


def test_duplicate_factor_blocks_branch_and_drop_preserves_decision(tmp_path):
    memory, signer, rows = setup_memory(tmp_path)
    try:
        action_ids = [item[2].id for item in rows]
        cause, _, _, _ = build_committed_graph(memory, signer, action_ids)
        branch = memory.create_branch("duplicate")
        duplicate = memory.propose_factor(
            branch, "duplicate retry", FactorKind.ACTION, (1.0, 0.0),
            ["artifact:duplicate"],
        )
        qualify_factor(memory, signer, duplicate, action_ids)
        violations = memory.validate_branch(branch, signed_gates(memory, signer))
        assert any(item.kind == "DuplicateFactor" for item in violations)
        with pytest.raises(CausalInvariantError):
            memory.merge_branch(
                branch, signed_gates(memory, signer),
                required_gate_names=("write-hallucination-nonregression",),
            )
        assert memory.get_factor(cause.id).status == "committed"
        memory.drop_branch(branch, "duplicate rejected", ["artifact:drop"])
        decisions = memory.db.execute(
            "SELECT decision FROM causal_factor_decisions WHERE factor_id=? ORDER BY seq",
            (duplicate.id,),
        ).fetchall()
        assert decisions[-1][0] == "rejected"
        with pytest.raises(KeyError):
            memory.get_factor(duplicate.id)
    finally:
        memory.close()


def test_grounding_requires_trace_entailment_and_identified_causal_edge(tmp_path):
    memory, signer, rows = setup_memory(tmp_path)
    try:
        action_ids = [item[2].id for item in rows]
        cause, effect, _, _ = build_committed_graph(memory, signer, action_ids)
        claim = GroundingClaim(
            id="claim-1",
            text="Retrying the tool caused service recovery.",
            cited_span_ids=(rows[0][1].id,),
            factor_ids=(cause.id, effect.id),
            cause_factor=cause.id,
            effect_factor=effect.id,
            entailment_score=0.91,
            entailment_evidence_ref="artifact:nli",
        )
        accepted = memory.evaluate_claim(
            claim,
            retrieval_path_answers={"lexical": "retry", "causal": "retry", "dense": "retry"},
        )
        assert accepted.accepted and accepted.wording == "causes"

        disagreement = memory.evaluate_claim(
            claim,
            retrieval_path_answers={"lexical": "retry", "causal": "restart"},
        )
        assert not disagreement.accepted and disagreement.abstain

        unsupported = claim.model_copy(update={"effect_factor": cause.id})
        downgraded = memory.evaluate_claim(unsupported)
        assert not downgraded.accepted and downgraded.wording == "associated_with"
    finally:
        memory.close()


def test_benchmark_gate_requires_pinned_signature(tmp_path):
    memory, signer, rows = setup_memory(tmp_path)
    try:
        branch = memory.create_branch("empty-gate")
        gate = memory.sign_gate_result(
            "causal-suite-nonregression", True, ["artifact:gate"],
            evaluator_id="eval", signer=signer,
        )
        bad = gate.model_copy(update={"signature": "bad"})
        with pytest.raises(CausalInvariantError) as error:
            memory.merge_branch(
                branch, [bad], required_gate_names=("causal-suite-nonregression",),
            )
        assert any(item.kind == "BenchmarkGateFailure" for item in error.value.violations)
    finally:
        memory.close()
