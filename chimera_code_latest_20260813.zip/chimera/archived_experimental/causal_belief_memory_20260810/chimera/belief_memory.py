"""Governed, versioned belief memory for Project Chimera.

The module keeps three concerns separate:

* immutable revision objects and encrypted content artifacts;
* mutable control-plane state (heads, lifecycle, ACLs, loadouts, utility);
* retrieval, which is always scope-filtered before relevance ranking.

It intentionally does not ask an LLM to decide authority.  Callers may propose
revisions, but only provenance/corroboration rules can make one current.  The
WAL records hashes and identifiers rather than memory plaintext.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import pathlib
import re
import sqlite3
import threading
import time
from enum import StrEnum
from typing import Any, Iterable, Literal, Mapping, Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from pydantic import BaseModel, ConfigDict, Field, field_validator

from .artifacts import ContentAddressedArtifactStore
from .wal import WAL


class FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class MemoryConflict(RuntimeError):
    """The expected belief head no longer matches durable state."""


class MemoryAuthorizationError(PermissionError):
    """An actor is not authorized for the requested memory operation."""


class MemoryPurgedError(FileNotFoundError):
    """Revision content was cryptographically purged from the active store."""


class TrustClass(StrEnum):
    EXTERNAL_UNTRUSTED = "external_untrusted"
    AGENT_INFERRED = "agent_inferred"
    TOOL_OBSERVED = "tool_observed"
    USER_CONFIRMED = "user_confirmed"
    POLICY_VERIFIED = "policy_verified"


_TRUST_RANK = {
    TrustClass.EXTERNAL_UNTRUSTED: 0,
    TrustClass.AGENT_INFERRED: 1,
    TrustClass.TOOL_OBSERVED: 2,
    TrustClass.USER_CONFIRMED: 3,
    TrustClass.POLICY_VERIFIED: 4,
}


class RevisionOperation(StrEnum):
    EXPAND = "expand"
    REVISE = "revise"
    CONTRACT = "contract"


class RevisionState(StrEnum):
    PROPOSED = "proposed"
    ACTIVE = "active"
    CONTESTED = "contested"
    SUPERSEDED = "superseded"
    CONTRACTED = "contracted"
    PURGED = "purged"


class AssetType(StrEnum):
    CHAT_MEMORY = "chat_memory"
    SKILL = "skill"
    WIKI = "wiki"
    CODE_GRAPH = "code_graph"


class AssetVisibility(StrEnum):
    PRIVATE = "private"
    TEAM = "team"
    RESTRICTED = "restricted"
    AGENT = "agent"


class MemoryKind(StrEnum):
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"
    OPERATIONAL = "operational"


class Actor(FrozenModel):
    tenant_id: str
    team_id: str
    user_id: str
    agent_id: Optional[str] = None
    team_admin: bool = False


class SourceProvenance(FrozenModel):
    source_id: str
    trust: TrustClass
    author_agent: Optional[str] = None
    source_uri: Optional[str] = None
    observed_at: float = Field(default_factory=time.time)


class MemoryAsset(FrozenModel):
    id: str
    tenant_id: str
    team_id: str
    owner_user_id: str
    name: str
    asset_type: AssetType
    visibility: AssetVisibility
    status: Literal["active", "deprecated"] = "active"
    created_at: float


class BeliefRevision(FrozenModel):
    id: str
    asset_id: str
    belief_ref: str
    kind: MemoryKind
    operation: RevisionOperation
    state: RevisionState
    created_at: float
    valid_from: Optional[float] = None
    valid_until: Optional[float] = None
    content_ref: str
    content_hash: str
    source: SourceProvenance
    evidence_refs: tuple[str, ...]
    justifies: tuple[str, ...] = ()
    contradicts: tuple[str, ...] = ()
    supersedes: tuple[str, ...] = ()
    expected_head: Optional[str] = None
    summary: Optional[str] = None

    @field_validator("valid_until")
    @classmethod
    def _validity_order(cls, value: Optional[float], info):
        start = info.data.get("valid_from")
        if value is not None and start is not None and value < start:
            raise ValueError("valid_until must be >= valid_from")
        return value


class RecallHit(FrozenModel):
    revision_id: str
    asset_id: str
    belief_ref: str
    kind: MemoryKind
    summary: str
    score: float
    lexical_score: float
    utility: float
    trust: TrustClass
    evidence_refs: tuple[str, ...]
    injection_mode: Literal["direct", "summary", "tool", "reference"]


class RecallTelemetry(FrozenModel):
    focus: float
    stability: float
    entropy: float
    candidate_count: int
    selected_count: int
    scope_filtered: int
    stale_filtered: int
    unreadable_filtered: int
    contested_visible_to_operator: int


class RecallResult(FrozenModel):
    hits: tuple[RecallHit, ...]
    telemetry: RecallTelemetry
    intent_bucket: str


class PurgeReceipt(FrozenModel):
    root_revision_id: str
    purged_revision_ids: tuple[str, ...]
    keys_destroyed: int
    reason_hash: str
    evidence_root: str
    created_at: float


_SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
PRAGMA secure_delete=ON;
CREATE TABLE IF NOT EXISTS memory_assets(
  id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, team_id TEXT NOT NULL,
  owner_user_id TEXT NOT NULL, payload TEXT NOT NULL, created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS memory_acl(
  asset_id TEXT NOT NULL, subject_type TEXT NOT NULL, subject_id TEXT NOT NULL,
  permission TEXT NOT NULL,
  PRIMARY KEY(asset_id,subject_type,subject_id,permission),
  FOREIGN KEY(asset_id) REFERENCES memory_assets(id)
);
CREATE TABLE IF NOT EXISTS memory_loadouts(
  agent_id TEXT NOT NULL, asset_id TEXT NOT NULL, injection_mode TEXT NOT NULL,
  priority INTEGER NOT NULL,
  PRIMARY KEY(agent_id,asset_id), FOREIGN KEY(asset_id) REFERENCES memory_assets(id)
);
CREATE TABLE IF NOT EXISTS belief_revisions(
  id TEXT PRIMARY KEY, asset_id TEXT NOT NULL, belief_ref TEXT NOT NULL,
  payload TEXT NOT NULL, created_at REAL NOT NULL,
  FOREIGN KEY(asset_id) REFERENCES memory_assets(id)
);
CREATE INDEX IF NOT EXISTS idx_belief_revisions_ref ON belief_revisions(asset_id,belief_ref,created_at);
CREATE TABLE IF NOT EXISTS belief_revision_state(
  revision_id TEXT PRIMARY KEY, state TEXT NOT NULL, updated_at REAL NOT NULL,
  FOREIGN KEY(revision_id) REFERENCES belief_revisions(id)
);
CREATE TABLE IF NOT EXISTS belief_heads(
  asset_id TEXT NOT NULL, belief_ref TEXT NOT NULL, revision_id TEXT NOT NULL,
  PRIMARY KEY(asset_id,belief_ref), FOREIGN KEY(revision_id) REFERENCES belief_revisions(id)
);
CREATE TABLE IF NOT EXISTS belief_dependencies(
  parent_revision_id TEXT NOT NULL, child_revision_id TEXT NOT NULL,
  PRIMARY KEY(parent_revision_id,child_revision_id)
);
CREATE TABLE IF NOT EXISTS belief_endorsements(
  revision_id TEXT NOT NULL, source_id TEXT NOT NULL, trust TEXT NOT NULL,
  evidence_refs TEXT NOT NULL, created_at REAL NOT NULL,
  PRIMARY KEY(revision_id,source_id), FOREIGN KEY(revision_id) REFERENCES belief_revisions(id)
);
CREATE TABLE IF NOT EXISTS belief_keys(
  revision_id TEXT PRIMARY KEY, key BLOB NOT NULL,
  FOREIGN KEY(revision_id) REFERENCES belief_revisions(id)
);
CREATE TABLE IF NOT EXISTS belief_utility(
  revision_id TEXT NOT NULL, intent_bucket TEXT NOT NULL, q REAL NOT NULL,
  visits INTEGER NOT NULL, updated_at REAL NOT NULL,
  PRIMARY KEY(revision_id,intent_bucket), FOREIGN KEY(revision_id) REFERENCES belief_revisions(id)
);
CREATE TABLE IF NOT EXISTS belief_associations(
  left_revision_id TEXT NOT NULL, right_revision_id TEXT NOT NULL,
  weight REAL NOT NULL, updates INTEGER NOT NULL, updated_at REAL NOT NULL,
  PRIMARY KEY(left_revision_id,right_revision_id)
);
"""


class GovernedBeliefMemory:
    """SQLite/CAS/WAL belief memory with exact scope and revision contracts."""

    def __init__(
        self,
        root: pathlib.Path,
        *,
        trusted_sources: Optional[Mapping[str, TrustClass]] = None,
    ):
        self.root = pathlib.Path(root).resolve()
        # Exact origin pins are host policy, not memory-writer assertions. A
        # caller may claim a trust class, but it is capped by this map (or by
        # its authenticated user/agent identity below).
        self.trusted_sources = {
            str(source_id): TrustClass(trust)
            for source_id, trust in dict(trusted_sources or {}).items()
        }
        path = self.root / ".chimera" / "belief_memory.sqlite"
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.executescript(_SCHEMA)
        self.store = ContentAddressedArtifactStore(self.root)
        self.wal = WAL(self.root)
        self.lock = threading.RLock()

    def close(self) -> None:
        self.db.close()

    @staticmethod
    def _canonical(value: Any) -> bytes:
        return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()

    @staticmethod
    def _digest(value: bytes) -> str:
        return "sha256:" + hashlib.sha256(value).hexdigest()

    @staticmethod
    def _refs(values: Iterable[str], *, label: str = "evidence") -> tuple[str, ...]:
        refs = tuple(dict.fromkeys(str(value).strip() for value in values if str(value).strip()))
        if not refs:
            raise ValueError(f"{label} refs are required")
        return refs

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return set(re.findall(r"[a-z0-9_./:-]{2,}", text.lower()))

    @staticmethod
    def _intent_bucket(intent: str) -> str:
        tokens = sorted(GovernedBeliefMemory._tokens(intent))[:16]
        return "intent:" + hashlib.sha256("\n".join(tokens).encode()).hexdigest()[:20]

    @staticmethod
    def _minimum_trust(kind: MemoryKind) -> int:
        if kind in {MemoryKind.PROCEDURAL, MemoryKind.OPERATIONAL}:
            return _TRUST_RANK[TrustClass.USER_CONFIRMED]
        return _TRUST_RANK[TrustClass.TOOL_OBSERVED]

    def _cap_source(self, source: SourceProvenance, actor: Actor) -> SourceProvenance:
        """Bind claimed authority to an authenticated origin policy.

        Unknown origins are external-untrusted regardless of the label supplied
        by a writer. Authenticated users/agents may speak for themselves up to
        their respective ceilings; tool/policy identities require exact host pins.
        """
        maximum = TrustClass.EXTERNAL_UNTRUSTED
        if source.source_id == f"user:{actor.user_id}":
            maximum = TrustClass.USER_CONFIRMED
        elif actor.agent_id and source.source_id == f"agent:{actor.agent_id}":
            maximum = TrustClass.AGENT_INFERRED
        elif source.source_id in self.trusted_sources:
            maximum = self.trusted_sources[source.source_id]
        effective_rank = min(_TRUST_RANK[source.trust], _TRUST_RANK[maximum])
        effective = next(value for value, rank in _TRUST_RANK.items() if rank == effective_rank)
        return source.model_copy(update={
            "trust": effective,
            "author_agent": source.author_agent or actor.agent_id,
        })

    def create_asset(
        self,
        asset_id: str,
        name: str,
        asset_type: AssetType,
        actor: Actor,
        *,
        visibility: AssetVisibility = AssetVisibility.PRIVATE,
        now: Optional[float] = None,
    ) -> MemoryAsset:
        if not asset_id.strip() or not name.strip():
            raise ValueError("asset id and name are required")
        asset = MemoryAsset(
            id=asset_id,
            tenant_id=actor.tenant_id,
            team_id=actor.team_id,
            owner_user_id=actor.user_id,
            name=name,
            asset_type=asset_type,
            visibility=visibility,
            created_at=time.time() if now is None else float(now),
        )
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO memory_assets VALUES(?,?,?,?,?,?)",
                (asset.id, asset.tenant_id, asset.team_id, asset.owner_user_id,
                 asset.model_dump_json(), asset.created_at),
            )
            self.wal.append("memory_asset_created", {
                "asset_id": asset.id, "tenant_id": asset.tenant_id,
                "team_id": asset.team_id, "owner_user_id": asset.owner_user_id,
                "asset_type": asset.asset_type, "visibility": asset.visibility,
            })
        return asset

    def _asset(self, asset_id: str) -> MemoryAsset:
        row = self.db.execute("SELECT payload FROM memory_assets WHERE id=?", (asset_id,)).fetchone()
        if row is None:
            raise KeyError(asset_id)
        return MemoryAsset.model_validate_json(row[0])

    def _acl_allows(self, asset_id: str, actor: Actor, permission: str) -> bool:
        subjects = [("user", actor.user_id), ("team", actor.team_id)]
        if actor.agent_id:
            subjects.append(("agent", actor.agent_id))
        return any(self.db.execute(
            "SELECT 1 FROM memory_acl WHERE asset_id=? AND subject_type=? AND subject_id=? AND permission=?",
            (asset_id, kind, identifier, permission),
        ).fetchone() for kind, identifier in subjects)

    def _can_read(self, asset: MemoryAsset, actor: Actor) -> bool:
        if asset.tenant_id != actor.tenant_id or asset.team_id != actor.team_id:
            return False
        if actor.team_admin or asset.owner_user_id == actor.user_id:
            return True
        if asset.visibility is AssetVisibility.TEAM:
            return True
        if asset.visibility is AssetVisibility.RESTRICTED:
            return self._acl_allows(asset.id, actor, "read") or self._acl_allows(asset.id, actor, "use")
        if asset.visibility is AssetVisibility.AGENT and actor.agent_id:
            return self.db.execute(
                "SELECT 1 FROM memory_loadouts WHERE agent_id=? AND asset_id=?",
                (actor.agent_id, asset.id),
            ).fetchone() is not None
        return False

    def grant(
        self,
        asset_id: str,
        actor: Actor,
        subject_type: Literal["user", "team", "agent"],
        subject_id: str,
        permissions: Iterable[Literal["read", "write", "assign", "use", "purge"]],
    ) -> None:
        asset = self._asset(asset_id)
        if not (actor.team_admin or actor.user_id == asset.owner_user_id):
            raise MemoryAuthorizationError("only asset owner or team admin may grant access")
        values = tuple(dict.fromkeys(permissions))
        allowed = {"read", "write", "assign", "use", "purge"}
        if not values or any(value not in allowed for value in values):
            raise ValueError("invalid or empty permission set")
        with self.lock, self.db:
            self.db.executemany(
                "INSERT OR IGNORE INTO memory_acl VALUES(?,?,?,?)",
                ((asset_id, subject_type, subject_id, value) for value in values),
            )
            self.wal.append("memory_acl_granted", {
                "asset_id": asset_id, "subject_type": subject_type,
                "subject_id": subject_id, "permissions": sorted(values),
            })

    def bind_asset(
        self,
        asset_id: str,
        target_agent_id: str,
        actor: Actor,
        *,
        injection_mode: Literal["direct", "summary", "tool", "reference"] = "reference",
        priority: int = 50,
    ) -> None:
        asset = self._asset(asset_id)
        if not (actor.team_admin or actor.user_id == asset.owner_user_id or
                self._acl_allows(asset_id, actor, "assign")):
            raise MemoryAuthorizationError("actor cannot assign this asset")
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO memory_loadouts VALUES(?,?,?,?) "
                "ON CONFLICT(agent_id,asset_id) DO UPDATE SET injection_mode=excluded.injection_mode,priority=excluded.priority",
                (target_agent_id, asset_id, injection_mode, max(0, min(100, int(priority)))),
            )
            self.wal.append("memory_asset_bound", {
                "asset_id": asset_id, "agent_id": target_agent_id,
                "injection_mode": injection_mode, "priority": max(0, min(100, int(priority))),
            })

    def _head(self, asset_id: str, belief_ref: str) -> Optional[str]:
        row = self.db.execute(
            "SELECT revision_id FROM belief_heads WHERE asset_id=? AND belief_ref=?",
            (asset_id, belief_ref),
        ).fetchone()
        return None if row is None else str(row[0])

    def _raw_revision(self, revision_id: str) -> tuple[dict[str, Any], RevisionState]:
        row = self.db.execute(
            "SELECT r.payload,s.state FROM belief_revisions r JOIN belief_revision_state s ON s.revision_id=r.id WHERE r.id=?",
            (revision_id,),
        ).fetchone()
        if row is None:
            raise KeyError(revision_id)
        return json.loads(row[0]), RevisionState(row[1])

    def _effective_trust(self, revision_id: str, source: SourceProvenance) -> TrustClass:
        ranks = [(_TRUST_RANK[source.trust], source.trust)]
        for (value,) in self.db.execute(
            "SELECT trust FROM belief_endorsements WHERE revision_id=?", (revision_id,)
        ).fetchall():
            trust = TrustClass(value)
            ranks.append((_TRUST_RANK[trust], trust))
        return max(ranks, key=lambda item: item[0])[1]

    def _decode_content(self, revision_id: str, content_ref: str) -> dict[str, Any]:
        row = self.db.execute("SELECT key FROM belief_keys WHERE revision_id=?", (revision_id,)).fetchone()
        if row is None:
            raise MemoryPurgedError(revision_id)
        encrypted = self.store.get(content_ref)
        if len(encrypted) < 13:
            raise ValueError("encrypted memory artifact is truncated")
        raw = AESGCM(bytes(row[0])).decrypt(encrypted[:12], encrypted[12:], revision_id.encode())
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise ValueError("memory content must decode to an object")
        return value

    def get_revision(self, revision_id: str, *, include_content: bool = False) -> BeliefRevision:
        payload, state = self._raw_revision(revision_id)
        summary = None
        if include_content:
            if state is RevisionState.PURGED:
                raise MemoryPurgedError(revision_id)
            summary = str(self._decode_content(revision_id, payload["content_ref"]).get("summary", ""))
        return BeliefRevision(**payload, state=state, summary=summary)

    def stage_revision(
        self,
        asset_id: str,
        belief_ref: str,
        kind: MemoryKind,
        operation: RevisionOperation,
        content: str | Mapping[str, Any],
        source: SourceProvenance,
        evidence_refs: Iterable[str],
        *,
        actor: Actor,
        expected_head: Optional[str] = None,
        justifies: Iterable[str] = (),
        contradicts: Iterable[str] = (),
        valid_from: Optional[float] = None,
        valid_until: Optional[float] = None,
        now: Optional[float] = None,
    ) -> BeliefRevision:
        asset = self._asset(asset_id)
        if not self._can_read(asset, actor) or not (
            actor.team_admin or actor.user_id == asset.owner_user_id or self._acl_allows(asset_id, actor, "write")
        ):
            raise MemoryAuthorizationError("actor cannot write this asset")
        refs = self._refs(evidence_refs)
        source = self._cap_source(source, actor)
        dependencies = tuple(dict.fromkeys(justifies))
        conflicts = tuple(dict.fromkeys(contradicts))
        current = self._head(asset_id, belief_ref)
        if operation is RevisionOperation.EXPAND and current is not None:
            raise MemoryConflict("expand requires an absent belief head; use revise")
        if operation in {RevisionOperation.REVISE, RevisionOperation.CONTRACT}:
            if current is None or expected_head is None or current != expected_head:
                raise MemoryConflict(f"expected head {expected_head!r}, current head is {current!r}")
            if current not in conflicts and operation is RevisionOperation.REVISE:
                raise ValueError("revise must explicitly contradict the current head")
            dependencies = tuple(dict.fromkeys((*dependencies, current)))
        if valid_from is not None and valid_until is not None and valid_until < valid_from:
            raise ValueError("valid_until must be >= valid_from")

        if isinstance(content, str):
            content_value = {"summary": content, "body": content}
        else:
            content_value = dict(content)
            if not str(content_value.get("summary", "")).strip():
                raise ValueError("structured memory content requires a non-empty summary")
        plaintext = self._canonical(content_value)
        content_hash = self._digest(plaintext)
        created = time.time() if now is None else float(now)
        identity = {
            "asset_id": asset_id, "belief_ref": belief_ref, "kind": kind,
            "operation": operation, "content_hash": content_hash, "source_id": source.source_id,
            "created_at": created, "expected_head": expected_head,
        }
        revision_id = "rev-" + hashlib.sha256(self._canonical(identity)).hexdigest()[:24]
        key = AESGCM.generate_key(bit_length=256)
        nonce = os.urandom(12)
        encrypted = nonce + AESGCM(key).encrypt(nonce, plaintext, revision_id.encode())
        artifact = self.store.put(
            encrypted,
            media_type="application/vnd.chimera.encrypted-memory+json",
            provenance={"kind": "belief_revision", "revision_id": revision_id},
        )
        immutable = {
            "id": revision_id, "asset_id": asset_id, "belief_ref": belief_ref,
            "kind": kind, "operation": operation, "created_at": created,
            "valid_from": valid_from, "valid_until": valid_until,
            "content_ref": artifact.digest, "content_hash": content_hash,
            "source": source.model_dump(mode="json"), "evidence_refs": refs,
            "justifies": dependencies, "contradicts": conflicts,
            "supersedes": (current,) if current and operation is RevisionOperation.REVISE else (),
            "expected_head": expected_head,
        }

        required = self._minimum_trust(kind)
        source_rank = _TRUST_RANK[source.trust]
        state = RevisionState.PROPOSED if source_rank < required else RevisionState.ACTIVE
        if operation is RevisionOperation.CONTRACT and source_rank >= required:
            state = RevisionState.CONTRACTED
        if current and source_rank >= required:
            current_revision = self.get_revision(current)
            current_trust = self._effective_trust(current, current_revision.source)
            if source_rank < _TRUST_RANK[current_trust]:
                state = RevisionState.CONTESTED

        with self.lock, self.db:
            for dependency in dependencies:
                self._raw_revision(dependency)
            self.db.execute(
                "INSERT INTO belief_revisions VALUES(?,?,?,?,?)",
                (revision_id, asset_id, belief_ref, json.dumps(immutable, sort_keys=True, default=str), created),
            )
            self.db.execute("INSERT INTO belief_revision_state VALUES(?,?,?)", (revision_id, state, created))
            self.db.execute("INSERT INTO belief_keys VALUES(?,?)", (revision_id, key))
            self.db.executemany(
                "INSERT OR IGNORE INTO belief_dependencies VALUES(?,?)",
                ((dependency, revision_id) for dependency in dependencies),
            )
            if state is RevisionState.ACTIVE:
                if current:
                    self.db.execute(
                        "UPDATE belief_revision_state SET state=?,updated_at=? WHERE revision_id=?",
                        (RevisionState.SUPERSEDED, created, current),
                    )
                self.db.execute(
                    "INSERT INTO belief_heads VALUES(?,?,?) "
                    "ON CONFLICT(asset_id,belief_ref) DO UPDATE SET revision_id=excluded.revision_id",
                    (asset_id, belief_ref, revision_id),
                )
            elif state is RevisionState.CONTRACTED:
                self.db.execute(
                    "UPDATE belief_revision_state SET state=?,updated_at=? WHERE revision_id=?",
                    (RevisionState.CONTRACTED, created, current),
                )
                self.db.execute("DELETE FROM belief_heads WHERE asset_id=? AND belief_ref=?", (asset_id, belief_ref))
            self.wal.append("belief_revision_staged", {
                "revision_id": revision_id, "asset_id": asset_id,
                "belief_ref_hash": self._digest(belief_ref.encode()),
                "operation": operation, "state": state, "content_ref": artifact.digest,
                "content_hash": content_hash,
                "evidence_root": self._digest(self._canonical(sorted(refs))),
                "source_id_hash": self._digest(source.source_id.encode()),
                "trust": source.trust,
            })
        return self.get_revision(revision_id, include_content=True)

    def endorse(
        self,
        revision_id: str,
        source: SourceProvenance,
        evidence_refs: Iterable[str],
        *,
        actor: Actor,
        expected_head: Optional[str] = None,
        now: Optional[float] = None,
    ) -> BeliefRevision:
        refs = self._refs(evidence_refs)
        revision = self.get_revision(revision_id)
        asset = self._asset(revision.asset_id)
        if not self._can_read(asset, actor) or not (
            actor.team_admin or actor.user_id == asset.owner_user_id or
            self._acl_allows(asset.id, actor, "write")
        ):
            raise MemoryAuthorizationError("actor cannot endorse this asset")
        source = self._cap_source(source, actor)
        if revision.state not in {RevisionState.PROPOSED, RevisionState.CONTESTED}:
            raise ValueError("only proposed or contested revisions can be endorsed")
        if source.source_id == revision.source.source_id:
            raise ValueError("endorsement must come from an independent source")
        created = time.time() if now is None else float(now)
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO belief_endorsements VALUES(?,?,?,?,?)",
                (revision_id, source.source_id, source.trust, json.dumps(refs), created),
            )
            effective = self._effective_trust(revision_id, revision.source)
            required = self._minimum_trust(revision.kind)
            new_state = revision.state
            if _TRUST_RANK[effective] >= required:
                current = self._head(revision.asset_id, revision.belief_ref)
                if current != expected_head:
                    raise MemoryConflict(f"expected head {expected_head!r}, current head is {current!r}")
                if revision.operation in {RevisionOperation.REVISE, RevisionOperation.CONTRACT} and current != revision.expected_head:
                    raise MemoryConflict("proposed revision was based on a stale head")
                if current:
                    current_revision = self.get_revision(current)
                    incumbent = self._effective_trust(current, current_revision.source)
                    if _TRUST_RANK[effective] < _TRUST_RANK[incumbent]:
                        new_state = RevisionState.CONTESTED
                    elif revision.operation is RevisionOperation.CONTRACT:
                        new_state = RevisionState.CONTRACTED
                        self.db.execute(
                            "UPDATE belief_revision_state SET state=?,updated_at=? WHERE revision_id=?",
                            (RevisionState.CONTRACTED, created, current),
                        )
                        self.db.execute(
                            "DELETE FROM belief_heads WHERE asset_id=? AND belief_ref=?",
                            (revision.asset_id, revision.belief_ref),
                        )
                    else:
                        new_state = RevisionState.ACTIVE
                        self.db.execute(
                            "UPDATE belief_revision_state SET state=?,updated_at=? WHERE revision_id=?",
                            (RevisionState.SUPERSEDED, created, current),
                        )
                        self.db.execute(
                            "INSERT INTO belief_heads VALUES(?,?,?) "
                            "ON CONFLICT(asset_id,belief_ref) DO UPDATE SET revision_id=excluded.revision_id",
                            (revision.asset_id, revision.belief_ref, revision_id),
                        )
                elif revision.operation is RevisionOperation.EXPAND:
                    new_state = RevisionState.ACTIVE
                    self.db.execute(
                        "INSERT INTO belief_heads VALUES(?,?,?)",
                        (revision.asset_id, revision.belief_ref, revision_id),
                    )
            self.db.execute(
                "UPDATE belief_revision_state SET state=?,updated_at=? WHERE revision_id=?",
                (new_state, created, revision_id),
            )
            self.wal.append("belief_revision_endorsed", {
                "revision_id": revision_id,
                "source_id_hash": self._digest(source.source_id.encode()),
                "trust": source.trust, "effective_trust": effective,
                "resulting_state": new_state,
                "evidence_root": self._digest(self._canonical(sorted(refs))),
            })
        return self.get_revision(revision_id, include_content=True)

    def history(self, asset_id: str, belief_ref: str, *, include_content: bool = False) -> tuple[BeliefRevision, ...]:
        ids = [row[0] for row in self.db.execute(
            "SELECT id FROM belief_revisions WHERE asset_id=? AND belief_ref=? ORDER BY created_at,id",
            (asset_id, belief_ref),
        ).fetchall()]
        return tuple(self.get_revision(item, include_content=include_content) for item in ids)

    def current(self, asset_id: str, belief_ref: str, *, include_content: bool = True) -> Optional[BeliefRevision]:
        head = self._head(asset_id, belief_ref)
        return None if head is None else self.get_revision(head, include_content=include_content)

    def _loadout_assets(self, actor: Actor) -> list[tuple[MemoryAsset, str, int]]:
        if not actor.agent_id:
            return []
        output = []
        for payload, mode, priority in self.db.execute(
            "SELECT a.payload,l.injection_mode,l.priority FROM memory_loadouts l "
            "JOIN memory_assets a ON a.id=l.asset_id WHERE l.agent_id=?",
            (actor.agent_id,),
        ).fetchall():
            asset = MemoryAsset.model_validate_json(payload)
            if asset.status == "active" and self._can_read(asset, actor):
                output.append((asset, str(mode), int(priority)))
        return output

    @staticmethod
    def _rrf(ranked_lists: list[list[str]], k: int = 60) -> dict[str, float]:
        scores: dict[str, float] = {}
        for ranked in ranked_lists:
            for rank, item in enumerate(ranked, start=1):
                scores[item] = scores.get(item, 0.0) + 1.0 / (k + rank)
        return scores

    @staticmethod
    def _telemetry(scores: list[float]) -> tuple[float, float, float]:
        positive = [max(0.0, value) for value in scores]
        total = sum(positive)
        if len(positive) <= 1:
            return (1.0 if positive else 0.0), (1.0 if positive else 0.0), 0.0
        if total <= 0:
            return 0.0, 0.0, 0.0
        probabilities = [value / total for value in positive if value > 0]
        entropy = -sum(value * math.log(value) for value in probabilities)
        focus = max(0.0, 1.0 - entropy / math.log(len(positive)))
        ordered = sorted(positive, reverse=True)
        stability = max(0.0, min(1.0, (ordered[0] - ordered[1]) / max(ordered[0], 1e-12)))
        return focus, stability, entropy

    def recall(
        self,
        actor: Actor,
        query: str,
        *,
        intent: Optional[str] = None,
        limit: int = 8,
        focus_asset_ids: Iterable[str] = (),
        focus_belief_refs: Iterable[str] = (),
        now: Optional[float] = None,
        mmr_lambda: float = 0.75,
    ) -> RecallResult:
        current_time = time.time() if now is None else float(now)
        focus_assets = set(focus_asset_ids)
        focus_refs = set(focus_belief_refs)
        query_tokens = self._tokens(query)
        bucket = self._intent_bucket(intent or query)
        loadout = self._loadout_assets(actor)
        scope_filtered = 0
        stale_filtered = 0
        unreadable = 0
        contested = int(self.db.execute(
            "SELECT COUNT(*) FROM belief_revision_state WHERE state=?", (RevisionState.CONTESTED,)
        ).fetchone()[0])
        candidates: list[dict[str, Any]] = []
        for asset, mode, priority in loadout:
            if focus_assets and asset.id not in focus_assets:
                scope_filtered += 1
                continue
            rows = self.db.execute(
                "SELECT r.id,r.payload,s.state FROM belief_heads h "
                "JOIN belief_revisions r ON r.id=h.revision_id "
                "JOIN belief_revision_state s ON s.revision_id=r.id WHERE h.asset_id=?",
                (asset.id,),
            ).fetchall()
            for revision_id, raw_payload, raw_state in rows:
                if RevisionState(raw_state) is not RevisionState.ACTIVE:
                    continue
                payload = json.loads(raw_payload)
                if focus_refs and payload["belief_ref"] not in focus_refs:
                    scope_filtered += 1
                    continue
                if payload.get("valid_from") is not None and current_time < float(payload["valid_from"]):
                    stale_filtered += 1
                    continue
                if payload.get("valid_until") is not None and current_time >= float(payload["valid_until"]):
                    stale_filtered += 1
                    continue
                try:
                    content = self._decode_content(revision_id, payload["content_ref"])
                except (MemoryPurgedError, FileNotFoundError, ValueError):
                    unreadable += 1
                    continue
                summary = str(content.get("summary", "")).strip()
                tokens = self._tokens(summary + " " + str(content.get("body", "")))
                overlap = query_tokens & tokens
                lexical = len(overlap) / max(1.0, math.sqrt(len(query_tokens) * max(1, len(tokens))))
                if payload["belief_ref"] in focus_refs:
                    lexical = max(lexical, 1.0)
                if lexical <= 0:
                    continue
                q_row = self.db.execute(
                    "SELECT q FROM belief_utility WHERE revision_id=? AND intent_bucket=?",
                    (revision_id, bucket),
                ).fetchone()
                utility = 0.0 if q_row is None else float(q_row[0])
                source = SourceProvenance.model_validate(payload["source"])
                trust = self._effective_trust(revision_id, source)
                candidates.append({
                    "id": revision_id, "payload": payload, "summary": summary,
                    "tokens": tokens, "lexical": lexical, "utility": utility,
                    "trust": trust, "mode": mode, "priority": priority,
                })

        lexical_rank = [item["id"] for item in sorted(candidates, key=lambda x: (-x["lexical"], x["id"]))]
        utility_rank = [item["id"] for item in sorted(
            candidates,
            key=lambda x: (-x["utility"], -_TRUST_RANK[x["trust"]], -x["priority"], x["id"]),
        )]
        fused = self._rrf([lexical_rank, utility_rank])
        selected: list[dict[str, Any]] = []
        pool = list(candidates)
        while pool and len(selected) < max(1, int(limit)):
            best = None
            best_score = -float("inf")
            for candidate in pool:
                redundancy = 0.0
                for prior in selected:
                    union = candidate["tokens"] | prior["tokens"]
                    similarity = len(candidate["tokens"] & prior["tokens"]) / max(1, len(union))
                    redundancy = max(redundancy, similarity)
                # RRF makes heterogeneous ranks comparable; the bounded utility
                # term breaks equal-rank ties using evidence-backed outcomes.
                base = fused.get(candidate["id"], 0.0) + 0.01 * max(
                    -1.0, min(1.0, candidate["utility"])
                )
                score = mmr_lambda * base - (1.0 - mmr_lambda) * redundancy
                if score > best_score or (score == best_score and candidate["id"] < (best or candidate)["id"]):
                    best, best_score = candidate, score
            assert best is not None
            best = dict(best)
            best["score"] = best_score
            selected.append(best)
            pool.remove(next(item for item in pool if item["id"] == best["id"]))

        hits = tuple(RecallHit(
            revision_id=item["id"], asset_id=item["payload"]["asset_id"],
            belief_ref=item["payload"]["belief_ref"], kind=MemoryKind(item["payload"]["kind"]),
            summary=item["summary"], score=round(float(item["score"]), 12),
            lexical_score=round(float(item["lexical"]), 12), utility=float(item["utility"]),
            trust=item["trust"], evidence_refs=tuple(item["payload"]["evidence_refs"]),
            injection_mode=item["mode"],
        ) for item in selected)
        focus, stability, entropy = self._telemetry([item.score for item in hits])
        return RecallResult(
            hits=hits,
            telemetry=RecallTelemetry(
                focus=round(focus, 8), stability=round(stability, 8), entropy=round(entropy, 8),
                candidate_count=len(candidates), selected_count=len(hits), scope_filtered=scope_filtered,
                stale_filtered=stale_filtered, unreadable_filtered=unreadable,
                contested_visible_to_operator=contested,
            ),
            intent_bucket=bucket,
        )

    def record_outcome(
        self,
        revision_ids: Iterable[str],
        intent: str,
        reward: float,
        evidence_refs: Iterable[str],
        *,
        alpha: float = 0.1,
        now: Optional[float] = None,
    ) -> dict[str, float]:
        ids = tuple(dict.fromkeys(revision_ids))
        refs = self._refs(evidence_refs)
        if not ids:
            raise ValueError("at least one used revision is required")
        if not -1.0 <= float(reward) <= 1.0:
            raise ValueError("reward must be between -1 and 1")
        rate = max(0.001, min(1.0, float(alpha)))
        bucket = self._intent_bucket(intent)
        created = time.time() if now is None else float(now)
        output: dict[str, float] = {}
        with self.lock, self.db:
            for revision_id in ids:
                revision = self.get_revision(revision_id)
                if revision.state is not RevisionState.ACTIVE:
                    raise ValueError("utility can update only active revisions")
                row = self.db.execute(
                    "SELECT q,visits FROM belief_utility WHERE revision_id=? AND intent_bucket=?",
                    (revision_id, bucket),
                ).fetchone()
                old_q, visits = (0.0, 0) if row is None else (float(row[0]), int(row[1]))
                new_q = old_q + rate * (float(reward) - old_q)
                self.db.execute(
                    "INSERT INTO belief_utility VALUES(?,?,?,?,?) "
                    "ON CONFLICT(revision_id,intent_bucket) DO UPDATE SET q=excluded.q,visits=excluded.visits,updated_at=excluded.updated_at",
                    (revision_id, bucket, new_q, visits + 1, created),
                )
                output[revision_id] = new_q
            for index, left in enumerate(sorted(ids)):
                for right in sorted(ids)[index + 1:]:
                    row = self.db.execute(
                        "SELECT weight,updates FROM belief_associations WHERE left_revision_id=? AND right_revision_id=?",
                        (left, right),
                    ).fetchone()
                    weight, updates = (0.0, 0) if row is None else (float(row[0]), int(row[1]))
                    new_weight = max(-1.0, min(1.0, weight + rate * (float(reward) - weight)))
                    self.db.execute(
                        "INSERT INTO belief_associations VALUES(?,?,?,?,?) "
                        "ON CONFLICT(left_revision_id,right_revision_id) DO UPDATE SET weight=excluded.weight,updates=excluded.updates,updated_at=excluded.updated_at",
                        (left, right, new_weight, updates + 1, created),
                    )
            self.wal.append("belief_memory_outcome", {
                "revision_ids": sorted(ids), "intent_bucket": bucket,
                "reward": float(reward), "alpha": rate,
                "evidence_root": self._digest(self._canonical(sorted(refs))),
            })
        return output

    def cascade_purge(
        self,
        revision_id: str,
        actor: Actor,
        reason: str,
        evidence_refs: Iterable[str],
        *,
        now: Optional[float] = None,
    ) -> PurgeReceipt:
        refs = self._refs(evidence_refs)
        root = self.get_revision(revision_id)
        asset = self._asset(root.asset_id)
        if not (actor.team_admin or actor.user_id == asset.owner_user_id or
                self._acl_allows(asset.id, actor, "purge")):
            raise MemoryAuthorizationError("actor cannot purge this memory")
        rows = self.db.execute(
            "WITH RECURSIVE closure(id) AS (SELECT ? UNION SELECT d.child_revision_id "
            "FROM belief_dependencies d JOIN closure c ON d.parent_revision_id=c.id) "
            "SELECT DISTINCT id FROM closure ORDER BY id",
            (revision_id,),
        ).fetchall()
        ids = tuple(str(row[0]) for row in rows)
        created = time.time() if now is None else float(now)
        reason_hash = self._digest(reason.encode())
        evidence_root = self._digest(self._canonical(sorted(refs)))
        with self.lock, self.db:
            placeholders = ",".join("?" for _ in ids)
            key_count = int(self.db.execute(
                f"SELECT COUNT(*) FROM belief_keys WHERE revision_id IN ({placeholders})", ids
            ).fetchone()[0])
            self.db.execute(
                f"UPDATE belief_revision_state SET state=?,updated_at=? WHERE revision_id IN ({placeholders})",
                (RevisionState.PURGED, created, *ids),
            )
            self.db.execute(f"DELETE FROM belief_heads WHERE revision_id IN ({placeholders})", ids)
            self.db.execute(f"DELETE FROM belief_keys WHERE revision_id IN ({placeholders})", ids)
            self.wal.append("belief_memory_cascade_purged", {
                "root_revision_id": revision_id, "purged_revision_ids": list(ids),
                "keys_destroyed": key_count, "reason_hash": reason_hash,
                "evidence_root": evidence_root,
            })
        # Best-effort local cleanup. This is not an HSM/KMS or physical-media erasure claim.
        self.db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        return PurgeReceipt(
            root_revision_id=revision_id, purged_revision_ids=ids,
            keys_destroyed=key_count, reason_hash=reason_hash,
            evidence_root=evidence_root, created_at=created,
        )

    def export_prov(self, revision_id: str) -> dict[str, Any]:
        revision = self.get_revision(revision_id)
        return {
            "@context": {
                "prov": "http://www.w3.org/ns/prov#",
                "chimera": "https://arena.ai/chimera/memory#",
            },
            "@id": f"urn:chimera:revision:{revision.id}",
            "@type": "prov:Entity",
            "chimera:beliefRef": revision.belief_ref,
            "chimera:asset": {"@id": f"urn:chimera:asset:{revision.asset_id}"},
            "chimera:operation": revision.operation,
            "chimera:state": revision.state,
            "prov:generatedAtTime": revision.created_at,
            "prov:wasAttributedTo": {"@id": f"urn:chimera:source:{revision.source.source_id}"},
            "prov:wasDerivedFrom": [{"@id": value} for value in revision.evidence_refs],
            "chimera:justifies": [
                {"@id": f"urn:chimera:revision:{value}"} for value in revision.justifies
            ],
            "chimera:contradicts": [
                {"@id": f"urn:chimera:revision:{value}"} for value in revision.contradicts
            ],
            "chimera:contentDigest": revision.content_hash,
        }
