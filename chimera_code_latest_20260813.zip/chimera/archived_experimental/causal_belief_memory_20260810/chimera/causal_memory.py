"""Evidence-gated causal memory primitives for Project Chimera.

This module does not perform causal discovery or pretend that an ordinary tool
call is a randomized intervention.  It supplies the missing control plane:
exact trajectory escrow, typed action assignments, signed identification and
held-out validation receipts, durable consolidation branches, DAG invariants,
and a claim-level grounding gate.

External estimators (DoWhy/EconML/RxInfer, a simulator, or a deterministic
replay harness) may produce receipts.  Chimera records and verifies them but
never silently substitutes a mock estimator.
"""
from __future__ import annotations

import base64
import hashlib
import json
import math
import os
import pathlib
import sqlite3
import threading
import time
from enum import StrEnum
from typing import Any, Iterable, Literal, Mapping, Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from pydantic import BaseModel, ConfigDict, Field, field_validator

from .artifacts import ContentAddressedArtifactStore
from .context_evidence import ContextSigner
from .wal import WAL


class FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class CausalInvariantError(RuntimeError):
    def __init__(self, violations: Iterable["InvariantViolation"]):
        self.violations = tuple(violations)
        super().__init__("; ".join(f"{item.kind}:{item.message}" for item in self.violations))


class FactorKind(StrEnum):
    STATE = "state"
    ACTION = "action"
    LATENT = "latent"


class DiscoveryMethod(StrEnum):
    DOMAIN_SCHEMA = "domain_schema"
    PC_FCI = "pc_fci"
    COOCCURRENCE = "cooccurrence"
    SERENDIPITY = "serendipity"
    CONTROLLED_REPLAY = "controlled_replay"


class AssignmentKind(StrEnum):
    OBSERVED_POLICY_ACTION = "observed_policy_action"
    RANDOMIZED_INTERVENTION = "randomized_intervention"
    CONTROLLED_REPLAY = "controlled_replay"


class IdentificationMethod(StrEnum):
    BACKDOOR = "backdoor"
    FRONTDOOR = "frontdoor"
    RANDOMIZED = "randomized"
    CONTROLLED_REPLAY = "controlled_replay"


class InterventionState(FrozenModel):
    open_files: tuple[str, ...] = ()
    last_error: Optional[str] = None
    entities_in_scope: tuple[str, ...] = ()
    user_goal_tag: str


class ActionSchema(FrozenModel):
    action_name: str
    treatment_var: str
    outcome_var: str
    candidate_confounders: tuple[Literal[
        "open_files", "last_error", "entities_in_scope", "user_goal_tag"
    ], ...] = ()


class Episode(FrozenModel):
    id: str
    ts: float
    actor: str
    raw_blob_ref: str
    content_hash: str
    authz: str
    evidence_refs: tuple[str, ...]


class EvidenceSpan(FrozenModel):
    id: str
    episode_id: str
    char_start: int
    char_end: int
    text_hash: str
    text: Optional[str] = None


class ActionRecord(FrozenModel):
    id: str
    episode_id: str
    action_name: str
    action_args_ref: str
    pre_state_ref: str
    post_state_ref: str
    policy_ref: str
    assignment: AssignmentKind
    assignment_probability: Optional[float] = Field(default=None, gt=0.0, le=1.0)
    causal_eligible: bool
    ts: float
    evidence_refs: tuple[str, ...]


class CausalPolicy(FrozenModel):
    min_cf_gain: float = 0.02
    max_recoverability_r2: float = 0.8
    duplicate_cosine: float = 0.9
    min_samples: int = 20
    min_overlap: float = 0.05
    entailment_threshold: float = 0.85


class CausalFactor(FrozenModel):
    id: str
    branch_id: str
    name: str
    kind: FactorKind
    vector: tuple[float, ...]
    status: Literal["candidate", "ready", "committed", "pruned"]
    created_at: float


class CausalEdge(FrozenModel):
    id: str
    branch_id: str
    cause_factor: str
    effect_factor: str
    status: Literal["candidate", "ready", "committed", "rejected"]
    identified: bool
    method: Optional[IdentificationMethod]
    effect_size: Optional[float]
    ci_low: Optional[float]
    ci_high: Optional[float]
    adjustment_set: tuple[str, ...]
    discovered_by: DiscoveryMethod
    created_at: float


class FactorValidationReceipt(FrozenModel):
    factor_id: str
    cf_gain: float
    recoverability_r2: float
    split_effects: tuple[float, float]
    heldout_action_ids: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    evaluator_id: str
    key_id: str
    public_key: str
    signature: str

    def unsigned(self) -> dict[str, Any]:
        return self.model_dump(mode="json", exclude={"signature"})

    def verify(self) -> bool:
        return _verify_signature(self.public_key, self.key_id, self.signature, self.unsigned())


class IdentificationReceipt(FrozenModel):
    edge_id: str
    method: IdentificationMethod
    effect_size: float
    ci_low: float
    ci_high: float
    split_effects: tuple[float, float]
    adjustment_set: tuple[str, ...]
    sample_size: int = Field(ge=1)
    overlap_min: float = Field(ge=0.0, le=1.0)
    action_ids: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    evaluator_id: str
    key_id: str
    public_key: str
    signature: str

    @field_validator("ci_high")
    @classmethod
    def _ci_order(cls, value: float, info):
        low = info.data.get("ci_low")
        if low is not None and value < low:
            raise ValueError("ci_high must be >= ci_low")
        return value

    def unsigned(self) -> dict[str, Any]:
        return self.model_dump(mode="json", exclude={"signature"})

    def verify(self) -> bool:
        return _verify_signature(self.public_key, self.key_id, self.signature, self.unsigned())


class GateResult(FrozenModel):
    name: str
    passed: bool
    evidence_refs: tuple[str, ...]
    evaluator_id: str
    key_id: str
    public_key: str
    signature: str

    def unsigned(self) -> dict[str, Any]:
        return self.model_dump(mode="json", exclude={"signature"})

    def verify(self) -> bool:
        return _verify_signature(self.public_key, self.key_id, self.signature, self.unsigned())


class InvariantViolation(FrozenModel):
    kind: Literal[
        "CycleViolation", "OrphanEdge", "IdentifiabilityRegression",
        "DuplicateFactor", "BenchmarkGateFailure", "UnvalidatedCandidate",
    ]
    object_id: Optional[str] = None
    message: str


class MergeReceipt(FrozenModel):
    branch_id: str
    committed_factor_ids: tuple[str, ...]
    committed_edge_ids: tuple[str, ...]
    gate_evidence_root: str
    main_state_hash: str
    created_at: float


class GroundingClaim(FrozenModel):
    id: str
    text: str
    cited_span_ids: tuple[str, ...]
    factor_ids: tuple[str, ...] = ()
    cause_factor: Optional[str] = None
    effect_factor: Optional[str] = None
    entailment_score: float = Field(ge=0.0, le=1.0)
    entailment_evidence_ref: str

    @field_validator("effect_factor")
    @classmethod
    def _pair(cls, value: Optional[str], info):
        if (value is None) != (info.data.get("cause_factor") is None):
            raise ValueError("cause_factor and effect_factor must be supplied together")
        return value


class GroundingDecision(FrozenModel):
    claim_id: str
    accepted: bool
    abstain: bool
    trace_ok: bool
    entailment_ok: bool
    contradiction_free: bool
    causal_ok: bool
    support_count: int
    wording: Literal["causes", "associated_with", "non_causal"]
    reasons: tuple[str, ...]


_SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS causal_episodes(
 id TEXT PRIMARY KEY, ts REAL NOT NULL, actor TEXT NOT NULL, raw_blob_ref TEXT NOT NULL,
 content_hash TEXT NOT NULL, authz TEXT NOT NULL, evidence_refs TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS causal_episode_keys(
 episode_id TEXT PRIMARY KEY, key BLOB NOT NULL,
 FOREIGN KEY(episode_id) REFERENCES causal_episodes(id)
);
CREATE TABLE IF NOT EXISTS causal_spans(
 id TEXT PRIMARY KEY, episode_id TEXT NOT NULL, char_start INTEGER NOT NULL,
 char_end INTEGER NOT NULL, text_hash TEXT NOT NULL,
 FOREIGN KEY(episode_id) REFERENCES causal_episodes(id)
);
CREATE TABLE IF NOT EXISTS causal_action_schemas(
 action_name TEXT PRIMARY KEY, payload TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS causal_actions(
 id TEXT PRIMARY KEY, episode_id TEXT NOT NULL, action_name TEXT NOT NULL,
 payload TEXT NOT NULL, ts REAL NOT NULL,
 FOREIGN KEY(episode_id) REFERENCES causal_episodes(id),
 FOREIGN KEY(action_name) REFERENCES causal_action_schemas(action_name)
);
CREATE TABLE IF NOT EXISTS causal_branches(
 id TEXT PRIMARY KEY, status TEXT NOT NULL, base_hash TEXT NOT NULL,
 created_at REAL NOT NULL, updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS causal_factors(
 id TEXT PRIMARY KEY, branch_id TEXT NOT NULL, payload TEXT NOT NULL,
 status TEXT NOT NULL, created_at REAL NOT NULL,
 FOREIGN KEY(branch_id) REFERENCES causal_branches(id)
);
CREATE TABLE IF NOT EXISTS causal_edges(
 id TEXT PRIMARY KEY, branch_id TEXT NOT NULL, payload TEXT NOT NULL,
 status TEXT NOT NULL, created_at REAL NOT NULL,
 FOREIGN KEY(branch_id) REFERENCES causal_branches(id)
);
CREATE TABLE IF NOT EXISTS causal_factor_decisions(
 seq INTEGER PRIMARY KEY AUTOINCREMENT, factor_id TEXT NOT NULL, branch_id TEXT NOT NULL,
 decision TEXT NOT NULL, metrics TEXT NOT NULL, reason TEXT NOT NULL, decided_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS causal_edge_decisions(
 seq INTEGER PRIMARY KEY AUTOINCREMENT, edge_id TEXT NOT NULL, branch_id TEXT NOT NULL,
 decision TEXT NOT NULL, metrics TEXT NOT NULL, reason TEXT NOT NULL, decided_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS causal_epistemic_edges(
 src_factor TEXT NOT NULL, dst_factor TEXT NOT NULL, rel TEXT NOT NULL,
 score REAL NOT NULL, evidence_ref TEXT NOT NULL, computed_at REAL NOT NULL,
 PRIMARY KEY(src_factor,dst_factor,rel)
);
"""


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()


def _digest(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def _refs(values: Iterable[str], label: str = "evidence") -> tuple[str, ...]:
    refs = tuple(dict.fromkeys(str(value).strip() for value in values if str(value).strip()))
    if not refs:
        raise ValueError(f"{label} refs are required")
    return refs


def _verify_signature(public_key: str, key_id: str, signature: str, payload: Mapping[str, Any]) -> bool:
    try:
        public = base64.b64decode(public_key, validate=True)
        if "ed25519:" + hashlib.sha256(public).hexdigest() != key_id:
            return False
        Ed25519PublicKey.from_public_bytes(public).verify(
            base64.b64decode(signature, validate=True), _canonical(payload)
        )
        return True
    except (ValueError, InvalidSignature):
        return False


def _same_nonzero_sign(values: tuple[float, float]) -> bool:
    return values[0] != 0 and values[1] != 0 and (values[0] > 0) == (values[1] > 0)


def _cosine(left: tuple[float, ...], right: tuple[float, ...]) -> float:
    if len(left) != len(right) or not left:
        return 0.0
    numerator = sum(a * b for a, b in zip(left, right))
    lnorm = math.sqrt(sum(value * value for value in left))
    rnorm = math.sqrt(sum(value * value for value in right))
    return numerator / (lnorm * rnorm) if lnorm and rnorm else 0.0


class CausalMemory:
    """Local causal-memory control plane with signed evaluator receipts."""

    def __init__(
        self,
        root: pathlib.Path,
        *,
        trusted_evaluators: Mapping[str, str],
        policy: Optional[CausalPolicy] = None,
    ):
        self.root = pathlib.Path(root).resolve()
        path = self.root / ".chimera" / "causal_memory.sqlite"
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.executescript(_SCHEMA)
        self.store = ContentAddressedArtifactStore(self.root)
        self.wal = WAL(self.root)
        self.policy = policy or CausalPolicy()
        self.trusted_evaluators = dict(trusted_evaluators)
        self.lock = threading.RLock()
        with self.db:
            self.db.execute(
                "INSERT OR IGNORE INTO causal_branches VALUES('main','merged',?,?,?)",
                (self._main_hash(), 0.0, 0.0),
            )

    def close(self) -> None:
        self.db.close()

    def _episode_key(self, episode_id: str) -> bytes:
        row = self.db.execute(
            "SELECT key FROM causal_episode_keys WHERE episode_id=?", (episode_id,)
        ).fetchone()
        if row is None:
            raise FileNotFoundError(f"episode key was erased: {episode_id}")
        return bytes(row[0])

    def _put_episode_artifact(
        self,
        episode_id: str,
        key: bytes,
        raw: bytes,
        *,
        kind: str,
    ) -> str:
        nonce = os.urandom(12)
        ciphertext = nonce + AESGCM(key).encrypt(nonce, raw, f"{episode_id}:{kind}".encode())
        return self.store.put(
            ciphertext,
            media_type="application/vnd.chimera.encrypted-causal-memory",
            provenance={"kind": kind, "episode_id": episode_id},
        ).digest

    def _get_episode_artifact(self, episode_id: str, ref: str, *, kind: str) -> bytes:
        encrypted = self.store.get(ref)
        if len(encrypted) < 13:
            raise ValueError("encrypted causal-memory artifact is truncated")
        return AESGCM(self._episode_key(episode_id)).decrypt(
            encrypted[:12], encrypted[12:], f"{episode_id}:{kind}".encode()
        )

    def _main_hash(self) -> str:
        try:
            factors = self.db.execute(
                "SELECT id,payload FROM causal_factors WHERE status='committed' ORDER BY id"
            ).fetchall()
            edges = self.db.execute(
                "SELECT id,payload FROM causal_edges WHERE status='committed' ORDER BY id"
            ).fetchall()
        except sqlite3.OperationalError:
            factors, edges = [], []
        return _digest(_canonical({"factors": factors, "edges": edges}))

    def register_action_schema(self, schema: ActionSchema) -> None:
        with self.lock, self.db:
            existing = self.db.execute(
                "SELECT payload FROM causal_action_schemas WHERE action_name=?", (schema.action_name,)
            ).fetchone()
            payload = schema.model_dump_json()
            if existing and existing[0] != payload:
                raise ValueError("action schema is immutable once registered")
            self.db.execute("INSERT OR IGNORE INTO causal_action_schemas VALUES(?,?)", (schema.action_name, payload))
            self.wal.append("causal_action_schema_registered", {
                "action_name": schema.action_name,
                "schema_hash": _digest(payload.encode()),
            })

    def record_episode(
        self,
        actor: str,
        raw_text: str,
        *,
        authz: str,
        evidence_refs: Iterable[str],
        ts: Optional[float] = None,
    ) -> Episode:
        refs = _refs(evidence_refs)
        raw = raw_text.encode()
        content_hash = _digest(raw)
        created = time.time() if ts is None else float(ts)
        identity = {"actor": actor, "content_hash": content_hash, "ts": created, "authz": authz}
        episode_id = "episode-" + hashlib.sha256(_canonical(identity)).hexdigest()[:24]
        key = AESGCM.generate_key(bit_length=256)
        raw_blob_ref = self._put_episode_artifact(
            episode_id, key, raw, kind="causal_episode"
        )
        episode = Episode(
            id=episode_id, ts=created, actor=actor, raw_blob_ref=raw_blob_ref,
            content_hash=content_hash, authz=authz, evidence_refs=refs,
        )
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO causal_episodes VALUES(?,?,?,?,?,?,?)",
                (episode.id, episode.ts, episode.actor, episode.raw_blob_ref,
                 episode.content_hash, episode.authz, json.dumps(refs)),
            )
            self.db.execute("INSERT INTO causal_episode_keys VALUES(?,?)", (episode.id, key))
            self.wal.append("causal_episode_recorded", {
                "episode_id": episode.id, "content_hash": content_hash,
                "raw_blob_ref": raw_blob_ref, "actor": actor, "authz": authz,
                "evidence_root": _digest(_canonical(sorted(refs))),
            })
        return episode

    def add_span(self, episode_id: str, char_start: int, char_end: int) -> EvidenceSpan:
        row = self.db.execute(
            "SELECT raw_blob_ref,content_hash FROM causal_episodes WHERE id=?", (episode_id,)
        ).fetchone()
        if row is None:
            raise KeyError(episode_id)
        raw = self._get_episode_artifact(episode_id, row[0], kind="causal_episode")
        if _digest(raw) != row[1]:
            raise ValueError("episode content no longer matches escrow hash")
        text = raw.decode("utf-8")
        if char_start < 0 or char_end <= char_start or char_end > len(text):
            raise ValueError("span offsets are outside the exact episode text")
        value = text[char_start:char_end]
        text_hash = _digest(value.encode())
        span_id = "span-" + hashlib.sha256(
            _canonical({"episode": episode_id, "start": char_start, "end": char_end, "hash": text_hash})
        ).hexdigest()[:24]
        with self.lock, self.db:
            self.db.execute(
                "INSERT OR IGNORE INTO causal_spans VALUES(?,?,?,?,?)",
                (span_id, episode_id, char_start, char_end, text_hash),
            )
            self.wal.append("causal_span_recorded", {
                "span_id": span_id, "episode_id": episode_id,
                "char_start": char_start, "char_end": char_end, "text_hash": text_hash,
            })
        return EvidenceSpan(
            id=span_id, episode_id=episode_id, char_start=char_start,
            char_end=char_end, text_hash=text_hash, text=value,
        )

    def get_span(self, span_id: str) -> EvidenceSpan:
        row = self.db.execute(
            "SELECT episode_id,char_start,char_end,text_hash FROM causal_spans WHERE id=?", (span_id,)
        ).fetchone()
        if row is None:
            raise KeyError(span_id)
        episode = self.db.execute(
            "SELECT raw_blob_ref FROM causal_episodes WHERE id=?", (row[0],)
        ).fetchone()
        text = self._get_episode_artifact(
            row[0], episode[0], kind="causal_episode"
        ).decode("utf-8")[int(row[1]):int(row[2])]
        if _digest(text.encode()) != row[3]:
            raise ValueError("span replay is not byte-identical")
        return EvidenceSpan(
            id=span_id, episode_id=row[0], char_start=row[1], char_end=row[2],
            text_hash=row[3], text=text,
        )

    def crypto_erase_episode(
        self,
        episode_id: str,
        *,
        reason: str,
        evidence_refs: Iterable[str],
    ) -> None:
        refs = _refs(evidence_refs)
        if self.db.execute("SELECT 1 FROM causal_episodes WHERE id=?", (episode_id,)).fetchone() is None:
            raise KeyError(episode_id)
        with self.lock, self.db:
            removed = self.db.execute(
                "DELETE FROM causal_episode_keys WHERE episode_id=?", (episode_id,)
            ).rowcount
            self.wal.append("causal_episode_crypto_erased", {
                "episode_id": episode_id, "key_destroyed": bool(removed),
                "reason_hash": _digest(reason.encode()),
                "evidence_root": _digest(_canonical(sorted(refs))),
            })
        self.db.execute("PRAGMA wal_checkpoint(TRUNCATE)")

    def record_action(
        self,
        episode_id: str,
        action_name: str,
        action_args: Mapping[str, Any],
        pre_state: InterventionState,
        post_state: InterventionState,
        *,
        policy_ref: str,
        assignment: AssignmentKind = AssignmentKind.OBSERVED_POLICY_ACTION,
        assignment_probability: Optional[float] = None,
        evidence_refs: Iterable[str],
        assignment_evidence_refs: Iterable[str] = (),
        ts: Optional[float] = None,
    ) -> ActionRecord:
        if self.db.execute("SELECT 1 FROM causal_episodes WHERE id=?", (episode_id,)).fetchone() is None:
            raise KeyError(episode_id)
        schema_row = self.db.execute(
            "SELECT payload FROM causal_action_schemas WHERE action_name=?", (action_name,)
        ).fetchone()
        if schema_row is None:
            raise KeyError(f"unregistered action schema: {action_name}")
        refs = _refs(evidence_refs)
        assignment_refs = tuple(assignment_evidence_refs)
        if not policy_ref.strip():
            raise ValueError("an exact policy_ref is required for replay/identification")
        if assignment is not AssignmentKind.OBSERVED_POLICY_ACTION:
            assignment_refs = _refs(assignment_refs, "assignment evidence")
        if assignment is AssignmentKind.RANDOMIZED_INTERVENTION:
            if assignment_probability is None or not 0 < float(assignment_probability) <= 1:
                raise ValueError("randomized interventions require their logged assignment probability")
        elif assignment_probability is not None:
            raise ValueError("assignment_probability is only valid for randomized interventions")
        key = self._episode_key(episode_id)
        args_ref = self._put_episode_artifact(
            episode_id, key, _canonical(dict(action_args)), kind="causal_action_args"
        )
        pre_ref = self._put_episode_artifact(
            episode_id, key, pre_state.model_dump_json().encode(), kind="causal_pre_state"
        )
        post_ref = self._put_episode_artifact(
            episode_id, key, post_state.model_dump_json().encode(), kind="causal_post_state"
        )
        created = time.time() if ts is None else float(ts)
        identity = {
            "episode": episode_id, "action": action_name, "args": args_ref,
            "pre": pre_ref, "post": post_ref, "policy_ref": policy_ref,
            "assignment": assignment, "assignment_probability": assignment_probability,
            "ts": created,
        }
        action_id = "action-" + hashlib.sha256(_canonical(identity)).hexdigest()[:24]
        record = ActionRecord(
            id=action_id, episode_id=episode_id, action_name=action_name,
            action_args_ref=args_ref, pre_state_ref=pre_ref, post_state_ref=post_ref,
            policy_ref=policy_ref, assignment=assignment,
            assignment_probability=assignment_probability,
            causal_eligible=assignment is not AssignmentKind.OBSERVED_POLICY_ACTION,
            ts=created, evidence_refs=tuple(dict.fromkeys((*refs, *assignment_refs))),
        )
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO causal_actions VALUES(?,?,?,?,?)",
                (record.id, episode_id, action_name, record.model_dump_json(), created),
            )
            self.wal.append("causal_action_recorded", {
                "action_id": action_id, "episode_id": episode_id,
                "action_name": action_name, "policy_ref": policy_ref,
                "assignment": assignment,
                "assignment_probability": assignment_probability,
                "causal_eligible": record.causal_eligible,
                "pre_state_ref": pre_ref, "post_state_ref": post_ref,
                "evidence_root": _digest(_canonical(sorted(record.evidence_refs))),
            })
        return record

    def create_branch(self, name: str, *, now: Optional[float] = None) -> str:
        if not name or any(value in name for value in ("/", "\\", "\x00")):
            raise ValueError("invalid causal branch name")
        branch_id = "cons-" + re_safe(name)
        created = time.time() if now is None else float(now)
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO causal_branches VALUES(?,?,?,?,?)",
                (branch_id, "open", self._main_hash(), created, created),
            )
            self.wal.append("causal_branch_created", {
                "branch_id": branch_id, "base_hash": self._main_hash(),
            })
        return branch_id

    def _branch_open(self, branch_id: str) -> None:
        row = self.db.execute("SELECT status FROM causal_branches WHERE id=?", (branch_id,)).fetchone()
        if row is None:
            raise KeyError(branch_id)
        if row[0] != "open":
            raise ValueError(f"causal branch is not open: {row[0]}")

    def propose_factor(
        self,
        branch_id: str,
        name: str,
        kind: FactorKind,
        vector: Iterable[float],
        evidence_refs: Iterable[str],
        *,
        now: Optional[float] = None,
    ) -> CausalFactor:
        self._branch_open(branch_id)
        values = tuple(float(value) for value in vector)
        if not values or any(not math.isfinite(value) for value in values):
            raise ValueError("factor vector must contain finite values")
        refs = _refs(evidence_refs)
        created = time.time() if now is None else float(now)
        factor_id = "factor-" + hashlib.sha256(_canonical({
            "branch": branch_id, "name": name, "kind": kind,
            "vector": values, "created": created,
        })).hexdigest()[:24]
        factor = CausalFactor(
            id=factor_id, branch_id=branch_id, name=name, kind=kind,
            vector=values, status="candidate", created_at=created,
        )
        payload = {**factor.model_dump(mode="json"), "evidence_refs": refs}
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO causal_factors VALUES(?,?,?,?,?)",
                (factor.id, branch_id, json.dumps(payload, sort_keys=True), factor.status, created),
            )
            self.wal.append("causal_factor_proposed", {
                "factor_id": factor.id, "branch_id": branch_id,
                "factor_hash": _digest(_canonical(payload)),
                "evidence_root": _digest(_canonical(sorted(refs))),
            })
        return factor

    @staticmethod
    def sign_factor_validation(
        factor_id: str,
        *,
        cf_gain: float,
        recoverability_r2: float,
        split_effects: tuple[float, float],
        heldout_action_ids: Iterable[str],
        evidence_refs: Iterable[str],
        evaluator_id: str,
        signer: ContextSigner,
    ) -> FactorValidationReceipt:
        unsigned = {
            "factor_id": factor_id, "cf_gain": float(cf_gain),
            "recoverability_r2": float(recoverability_r2),
            "split_effects": split_effects,
            "heldout_action_ids": tuple(heldout_action_ids),
            "evidence_refs": _refs(evidence_refs), "evaluator_id": evaluator_id,
            "key_id": signer.key_id, "public_key": signer.public_key,
        }
        return FactorValidationReceipt(**unsigned, signature=signer.sign(_canonical(unsigned)))

    @staticmethod
    def sign_gate_result(
        name: str,
        passed: bool,
        evidence_refs: Iterable[str],
        *,
        evaluator_id: str,
        signer: ContextSigner,
    ) -> GateResult:
        unsigned = {
            "name": name, "passed": bool(passed),
            "evidence_refs": _refs(evidence_refs),
            "evaluator_id": evaluator_id, "key_id": signer.key_id,
            "public_key": signer.public_key,
        }
        return GateResult(**unsigned, signature=signer.sign(_canonical(unsigned)))

    @staticmethod
    def sign_identification(
        edge_id: str,
        *,
        method: IdentificationMethod,
        effect_size: float,
        ci_low: float,
        ci_high: float,
        split_effects: tuple[float, float],
        adjustment_set: Iterable[str],
        sample_size: int,
        overlap_min: float,
        action_ids: Iterable[str],
        evidence_refs: Iterable[str],
        evaluator_id: str,
        signer: ContextSigner,
    ) -> IdentificationReceipt:
        unsigned = {
            "edge_id": edge_id, "method": method, "effect_size": float(effect_size),
            "ci_low": float(ci_low), "ci_high": float(ci_high),
            "split_effects": split_effects, "adjustment_set": tuple(adjustment_set),
            "sample_size": int(sample_size), "overlap_min": float(overlap_min),
            "action_ids": tuple(action_ids), "evidence_refs": _refs(evidence_refs),
            "evaluator_id": evaluator_id, "key_id": signer.key_id,
            "public_key": signer.public_key,
        }
        return IdentificationReceipt(**unsigned, signature=signer.sign(_canonical(unsigned)))

    def _trusted(self, evaluator_id: str, public_key: str) -> bool:
        return self.trusted_evaluators.get(evaluator_id) == public_key

    def validate_factor(self, receipt: FactorValidationReceipt, *, now: Optional[float] = None) -> CausalFactor:
        row = self.db.execute(
            "SELECT branch_id,payload,status,created_at FROM causal_factors WHERE id=?", (receipt.factor_id,)
        ).fetchone()
        if row is None:
            raise KeyError(receipt.factor_id)
        self._branch_open(row[0])
        if row[2] != "candidate":
            raise ValueError("factor is not awaiting validation")
        if not self._trusted(receipt.evaluator_id, receipt.public_key) or not receipt.verify():
            raise PermissionError("factor validation receipt is not signed by a pinned evaluator")
        for action_id in receipt.heldout_action_ids:
            action = self.db.execute(
                "SELECT payload FROM causal_actions WHERE id=?", (action_id,)
            ).fetchone()
            if action is None:
                raise KeyError(f"held-out action is missing: {action_id}")
            if not ActionRecord.model_validate_json(action[0]).causal_eligible:
                raise ValueError("held-out validation requires randomized or controlled-replay actions")
        qualified = (
            receipt.cf_gain > self.policy.min_cf_gain
            and receipt.recoverability_r2 < self.policy.max_recoverability_r2
            and _same_nonzero_sign(receipt.split_effects)
            and len(receipt.heldout_action_ids) >= 2
        )
        decided = time.time() if now is None else float(now)
        decision = "qualified" if qualified else "rejected"
        new_state = "ready" if qualified else "pruned"
        metrics = receipt.model_dump(mode="json", exclude={"signature", "public_key"})
        with self.lock, self.db:
            payload = json.loads(row[1]); payload["status"] = new_state
            self.db.execute(
                "UPDATE causal_factors SET payload=?,status=? WHERE id=?",
                (json.dumps(payload, sort_keys=True), new_state, receipt.factor_id),
            )
            self.db.execute(
                "INSERT INTO causal_factor_decisions(factor_id,branch_id,decision,metrics,reason,decided_at) VALUES(?,?,?,?,?,?)",
                (receipt.factor_id, row[0], decision, json.dumps(metrics, sort_keys=True),
                 "held-out intervention validation", decided),
            )
            self.wal.append("causal_factor_validated", {
                "factor_id": receipt.factor_id, "branch_id": row[0],
                "decision": decision, "receipt_hash": _digest(_canonical(receipt.model_dump(mode="json"))),
            })
        return self.get_factor(receipt.factor_id)

    def get_factor(self, factor_id: str) -> CausalFactor:
        row = self.db.execute("SELECT payload,status FROM causal_factors WHERE id=?", (factor_id,)).fetchone()
        if row is None:
            raise KeyError(factor_id)
        payload = json.loads(row[0]); payload["status"] = row[1]; payload.pop("evidence_refs", None)
        return CausalFactor.model_validate(payload)

    def _factor_exists_for_branch(self, factor_id: str, branch_id: str) -> bool:
        row = self.db.execute(
            "SELECT branch_id,status FROM causal_factors WHERE id=?", (factor_id,)
        ).fetchone()
        return bool(row and (row[1] == "committed" or row[0] == branch_id))

    def propose_edge(
        self,
        branch_id: str,
        cause_factor: str,
        effect_factor: str,
        discovered_by: DiscoveryMethod,
        evidence_refs: Iterable[str],
        *,
        now: Optional[float] = None,
    ) -> CausalEdge:
        self._branch_open(branch_id)
        if cause_factor == effect_factor:
            raise ValueError("causal self-edges are forbidden")
        if not self._factor_exists_for_branch(cause_factor, branch_id) or not self._factor_exists_for_branch(effect_factor, branch_id):
            raise ValueError("causal edge endpoints must exist in main or the same branch")
        refs = _refs(evidence_refs)
        created = time.time() if now is None else float(now)
        edge_id = "edge-" + hashlib.sha256(_canonical({
            "branch": branch_id, "cause": cause_factor, "effect": effect_factor,
            "discovered_by": discovered_by, "created": created,
        })).hexdigest()[:24]
        existing_pairs = self._effective_edge_pairs(branch_id, include_candidates=True)
        if self._has_cycle((*existing_pairs, (cause_factor, effect_factor))):
            raise CausalInvariantError((InvariantViolation(
                kind="CycleViolation", object_id=edge_id,
                message="proposed edge would close a directed cycle",
            ),))
        edge = CausalEdge(
            id=edge_id, branch_id=branch_id, cause_factor=cause_factor,
            effect_factor=effect_factor, status="candidate", identified=False,
            method=None, effect_size=None, ci_low=None, ci_high=None,
            adjustment_set=(), discovered_by=discovered_by, created_at=created,
        )
        payload = {**edge.model_dump(mode="json"), "evidence_refs": refs}
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO causal_edges VALUES(?,?,?,?,?)",
                (edge.id, branch_id, json.dumps(payload, sort_keys=True), edge.status, created),
            )
            self.wal.append("causal_edge_proposed", {
                "edge_id": edge.id, "branch_id": branch_id,
                "cause_factor": cause_factor, "effect_factor": effect_factor,
                "discovered_by": discovered_by,
                "evidence_root": _digest(_canonical(sorted(refs))),
            })
        return edge

    def identify_edge(self, receipt: IdentificationReceipt, *, now: Optional[float] = None) -> CausalEdge:
        row = self.db.execute(
            "SELECT branch_id,payload,status FROM causal_edges WHERE id=?", (receipt.edge_id,)
        ).fetchone()
        if row is None:
            raise KeyError(receipt.edge_id)
        self._branch_open(row[0])
        if row[2] != "candidate":
            raise ValueError("edge is not awaiting identification")
        if not self._trusted(receipt.evaluator_id, receipt.public_key) or not receipt.verify():
            raise PermissionError("identification receipt is not signed by a pinned evaluator")
        actions = []
        for action_id in receipt.action_ids:
            action_row = self.db.execute("SELECT payload FROM causal_actions WHERE id=?", (action_id,)).fetchone()
            if action_row is None:
                raise KeyError(f"identification action is missing: {action_id}")
            actions.append(ActionRecord.model_validate_json(action_row[0]))
        method_actions_ok = True
        if receipt.method in {IdentificationMethod.RANDOMIZED, IdentificationMethod.CONTROLLED_REPLAY}:
            method_actions_ok = bool(actions) and all(item.causal_eligible for item in actions)
        ci_excludes_zero = receipt.ci_low > 0 or receipt.ci_high < 0
        observational_ok = (
            receipt.method in {IdentificationMethod.BACKDOOR, IdentificationMethod.FRONTDOOR}
            and bool(receipt.adjustment_set)
            and receipt.overlap_min >= self.policy.min_overlap
        )
        experimental_ok = receipt.method in {
            IdentificationMethod.RANDOMIZED, IdentificationMethod.CONTROLLED_REPLAY
        } and method_actions_ok
        qualified = (
            receipt.sample_size >= self.policy.min_samples
            and ci_excludes_zero
            and _same_nonzero_sign(receipt.split_effects)
            and len(receipt.action_ids) >= 2
            and (observational_ok or experimental_ok)
        )
        decided = time.time() if now is None else float(now)
        new_state = "ready" if qualified else "rejected"
        payload = json.loads(row[1])
        payload.update({
            "status": new_state, "identified": bool(qualified), "method": receipt.method,
            "effect_size": receipt.effect_size, "ci_low": receipt.ci_low,
            "ci_high": receipt.ci_high, "adjustment_set": receipt.adjustment_set,
        })
        metrics = receipt.model_dump(mode="json", exclude={"signature", "public_key"})
        with self.lock, self.db:
            self.db.execute(
                "UPDATE causal_edges SET payload=?,status=? WHERE id=?",
                (json.dumps(payload, sort_keys=True), new_state, receipt.edge_id),
            )
            self.db.execute(
                "INSERT INTO causal_edge_decisions(edge_id,branch_id,decision,metrics,reason,decided_at) VALUES(?,?,?,?,?,?)",
                (receipt.edge_id, row[0], "identified" if qualified else "rejected",
                 json.dumps(metrics, sort_keys=True), "signed identification gate", decided),
            )
            self.wal.append("causal_edge_identified", {
                "edge_id": receipt.edge_id, "branch_id": row[0],
                "identified": bool(qualified),
                "receipt_hash": _digest(_canonical(receipt.model_dump(mode="json"))),
            })
        return self.get_edge(receipt.edge_id)

    def get_edge(self, edge_id: str) -> CausalEdge:
        row = self.db.execute("SELECT payload,status FROM causal_edges WHERE id=?", (edge_id,)).fetchone()
        if row is None:
            raise KeyError(edge_id)
        payload = json.loads(row[0]); payload["status"] = row[1]; payload.pop("evidence_refs", None)
        return CausalEdge.model_validate(payload)

    def _effective_edge_pairs(self, branch_id: str, *, include_candidates: bool = False) -> tuple[tuple[str, str], ...]:
        states = ["committed", "ready"] + (["candidate"] if include_candidates else [])
        placeholders = ",".join("?" for _ in states)
        rows = self.db.execute(
            f"SELECT branch_id,payload,status FROM causal_edges WHERE status IN ({placeholders})",
            states,
        ).fetchall()
        pairs = []
        for edge_branch, payload, status in rows:
            if status == "committed" or edge_branch == branch_id:
                value = json.loads(payload)
                pairs.append((value["cause_factor"], value["effect_factor"]))
        return tuple(pairs)

    @staticmethod
    def _has_cycle(pairs: Iterable[tuple[str, str]]) -> bool:
        graph: dict[str, set[str]] = {}
        indegree: dict[str, int] = {}
        for left, right in pairs:
            graph.setdefault(left, set())
            graph.setdefault(right, set())
            indegree.setdefault(left, 0)
            indegree.setdefault(right, 0)
            if right not in graph[left]:
                graph[left].add(right); indegree[right] += 1
        queue = sorted(node for node, degree in indegree.items() if degree == 0)
        visited = 0
        while queue:
            node = queue.pop(0); visited += 1
            for target in sorted(graph[node]):
                indegree[target] -= 1
                if indegree[target] == 0:
                    queue.append(target); queue.sort()
        return visited != len(indegree)

    def validate_branch(self, branch_id: str, gates: Iterable[GateResult]) -> tuple[InvariantViolation, ...]:
        self._branch_open(branch_id)
        violations: list[InvariantViolation] = []
        ready_factors = [self.get_factor(row[0]) for row in self.db.execute(
            "SELECT id FROM causal_factors WHERE branch_id=? AND status='ready'", (branch_id,)
        ).fetchall()]
        candidate_factors = self.db.execute(
            "SELECT id FROM causal_factors WHERE branch_id=? AND status='candidate'", (branch_id,)
        ).fetchall()
        ready_edges = [self.get_edge(row[0]) for row in self.db.execute(
            "SELECT id FROM causal_edges WHERE branch_id=? AND status='ready'", (branch_id,)
        ).fetchall()]
        candidate_edges = self.db.execute(
            "SELECT id FROM causal_edges WHERE branch_id=? AND status='candidate'", (branch_id,)
        ).fetchall()
        for (item,) in (*candidate_factors, *candidate_edges):
            violations.append(InvariantViolation(
                kind="UnvalidatedCandidate", object_id=item,
                message="candidate has no final signed validation decision",
            ))
        committed_factors = [self.get_factor(row[0]) for row in self.db.execute(
            "SELECT id FROM causal_factors WHERE status='committed'"
        ).fetchall()]
        factor_ids = {item.id for item in (*committed_factors, *ready_factors)}
        for edge in ready_edges:
            if edge.cause_factor not in factor_ids or edge.effect_factor not in factor_ids:
                violations.append(InvariantViolation(
                    kind="OrphanEdge", object_id=edge.id,
                    message="edge references a missing, rejected, or pruned factor",
                ))
        pairs = self._effective_edge_pairs(branch_id)
        if self._has_cycle(pairs):
            violations.append(InvariantViolation(
                kind="CycleViolation", message="effective committed graph is cyclic",
            ))
        for candidate in ready_edges:
            prior = self.db.execute(
                "SELECT payload FROM causal_edges WHERE status='committed'"
            ).fetchall()
            for (payload,) in prior:
                old = json.loads(payload)
                if (old["cause_factor"], old["effect_factor"]) == (candidate.cause_factor, candidate.effect_factor):
                    if old.get("identified") and not candidate.identified:
                        violations.append(InvariantViolation(
                            kind="IdentifiabilityRegression", object_id=candidate.id,
                            message="identified edge would become unidentified",
                        ))
        all_factors = [*committed_factors, *ready_factors]
        for index, left in enumerate(all_factors):
            for right in all_factors[index + 1:]:
                if left.id != right.id and _cosine(left.vector, right.vector) > self.policy.duplicate_cosine:
                    if left in ready_factors or right in ready_factors:
                        violations.append(InvariantViolation(
                            kind="DuplicateFactor", object_id=right.id,
                            message=f"factor duplicates {left.id} above cosine threshold",
                        ))
        gate_values = tuple(gates)
        if not gate_values:
            violations.append(InvariantViolation(
                kind="BenchmarkGateFailure", message="at least one external benchmark gate is required",
            ))
        for gate in gate_values:
            trusted = self._trusted(gate.evaluator_id, gate.public_key) and gate.verify()
            if not gate.passed or not gate.evidence_refs or not trusted:
                violations.append(InvariantViolation(
                    kind="BenchmarkGateFailure", object_id=gate.name,
                    message="benchmark gate failed, lacks evidence, or has an untrusted signature",
                ))
        return tuple(violations)

    def merge_branch(
        self,
        branch_id: str,
        gates: Iterable[GateResult],
        *,
        required_gate_names: Iterable[str],
        now: Optional[float] = None,
    ) -> MergeReceipt:
        gate_values = tuple(gates)
        required = tuple(required_gate_names)
        with self.lock:
            return self._merge_branch_locked(branch_id, gate_values, required, now)

    def _merge_branch_locked(
        self,
        branch_id: str,
        gate_values: tuple[GateResult, ...],
        required_gate_names: tuple[str, ...],
        now: Optional[float],
    ) -> MergeReceipt:
        names = {item.name for item in gate_values if item.passed}
        missing = set(required_gate_names) - names
        violations = list(self.validate_branch(branch_id, gate_values))
        for name in sorted(missing):
            violations.append(InvariantViolation(
                kind="BenchmarkGateFailure", object_id=name,
                message="required frozen-baseline gate result is missing",
            ))
        row = self.db.execute("SELECT base_hash FROM causal_branches WHERE id=?", (branch_id,)).fetchone()
        if row and row[0] != self._main_hash():
            violations.append(InvariantViolation(
                kind="IdentifiabilityRegression", object_id=branch_id,
                message="main causal state changed since branch creation; rebase required",
            ))
        if violations:
            raise CausalInvariantError(violations)
        factor_ids = tuple(row[0] for row in self.db.execute(
            "SELECT id FROM causal_factors WHERE branch_id=? AND status='ready' ORDER BY id", (branch_id,)
        ).fetchall())
        edge_ids = tuple(row[0] for row in self.db.execute(
            "SELECT id FROM causal_edges WHERE branch_id=? AND status='ready' ORDER BY id", (branch_id,)
        ).fetchall())
        created = time.time() if now is None else float(now)
        all_refs = tuple(ref for gate in gate_values for ref in gate.evidence_refs)
        gate_root = _digest(_canonical(sorted(all_refs)))
        with self.lock, self.db:
            # Acquire SQLite's write lock, then repeat the base-hash CAS check.
            # This closes the cross-process gap between validation and publish.
            self.db.execute("UPDATE causal_branches SET updated_at=updated_at WHERE id='main'")
            if row[0] != self._main_hash():
                raise CausalInvariantError((InvariantViolation(
                    kind="IdentifiabilityRegression", object_id=branch_id,
                    message="main causal state changed before atomic publish",
                ),))
            self.db.execute("UPDATE causal_factors SET status='committed' WHERE branch_id=? AND status='ready'", (branch_id,))
            self.db.execute("UPDATE causal_edges SET status='committed' WHERE branch_id=? AND status='ready'", (branch_id,))
            for factor_id in factor_ids:
                payload = json.loads(self.db.execute("SELECT payload FROM causal_factors WHERE id=?", (factor_id,)).fetchone()[0])
                payload["status"] = "committed"
                self.db.execute("UPDATE causal_factors SET payload=? WHERE id=?", (json.dumps(payload, sort_keys=True), factor_id))
                self.db.execute(
                    "INSERT INTO causal_factor_decisions(factor_id,branch_id,decision,metrics,reason,decided_at) VALUES(?,?,?,?,?,?)",
                    (factor_id, branch_id, "committed", "{}", "branch gates passed", created),
                )
            for edge_id in edge_ids:
                payload = json.loads(self.db.execute("SELECT payload FROM causal_edges WHERE id=?", (edge_id,)).fetchone()[0])
                payload["status"] = "committed"
                self.db.execute("UPDATE causal_edges SET payload=? WHERE id=?", (json.dumps(payload, sort_keys=True), edge_id))
            main_hash = self._main_hash()
            self.db.execute(
                "UPDATE causal_branches SET status='merged',updated_at=? WHERE id=?", (created, branch_id)
            )
            self.db.execute(
                "UPDATE causal_branches SET base_hash=?,updated_at=? WHERE id='main'", (main_hash, created)
            )
            self.wal.append("causal_branch_merged", {
                "branch_id": branch_id, "factor_ids": list(factor_ids),
                "edge_ids": list(edge_ids), "gate_evidence_root": gate_root,
                "main_state_hash": main_hash,
            })
        return MergeReceipt(
            branch_id=branch_id, committed_factor_ids=factor_ids,
            committed_edge_ids=edge_ids, gate_evidence_root=gate_root,
            main_state_hash=main_hash, created_at=created,
        )

    def drop_branch(self, branch_id: str, reason: str, evidence_refs: Iterable[str], *, now: Optional[float] = None) -> None:
        self._branch_open(branch_id)
        refs = _refs(evidence_refs)
        created = time.time() if now is None else float(now)
        factors = [row[0] for row in self.db.execute(
            "SELECT id FROM causal_factors WHERE branch_id=?", (branch_id,)
        ).fetchall()]
        edges = [row[0] for row in self.db.execute(
            "SELECT id FROM causal_edges WHERE branch_id=?", (branch_id,)
        ).fetchall()]
        with self.lock, self.db:
            for factor_id in factors:
                self.db.execute(
                    "INSERT INTO causal_factor_decisions(factor_id,branch_id,decision,metrics,reason,decided_at) VALUES(?,?,?,?,?,?)",
                    (factor_id, branch_id, "rejected", "{}", reason, created),
                )
            for edge_id in edges:
                self.db.execute(
                    "INSERT INTO causal_edge_decisions(edge_id,branch_id,decision,metrics,reason,decided_at) VALUES(?,?,?,?,?,?)",
                    (edge_id, branch_id, "rejected", "{}", reason, created),
                )
            self.db.execute("DELETE FROM causal_edges WHERE branch_id=?", (branch_id,))
            self.db.execute("DELETE FROM causal_factors WHERE branch_id=?", (branch_id,))
            self.db.execute("UPDATE causal_branches SET status='dropped',updated_at=? WHERE id=?", (created, branch_id))
            self.wal.append("causal_branch_dropped", {
                "branch_id": branch_id, "reason_hash": _digest(reason.encode()),
                "factor_decisions": len(factors), "edge_decisions": len(edges),
                "evidence_root": _digest(_canonical(sorted(refs))),
            })

    def record_epistemic_relation(
        self,
        src_factor: str,
        dst_factor: str,
        rel: Literal["supports", "contradicts", "supersedes"],
        score: float,
        evidence_ref: str,
        *,
        now: Optional[float] = None,
    ) -> None:
        for factor_id in (src_factor, dst_factor):
            factor = self.get_factor(factor_id)
            if factor.status != "committed":
                raise ValueError("epistemic relations require committed factors")
        if not 0 <= score <= 1 or not evidence_ref:
            raise ValueError("relation score/evidence is invalid")
        created = time.time() if now is None else float(now)
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO causal_epistemic_edges VALUES(?,?,?,?,?,?) "
                "ON CONFLICT(src_factor,dst_factor,rel) DO UPDATE SET score=excluded.score,evidence_ref=excluded.evidence_ref,computed_at=excluded.computed_at",
                (src_factor, dst_factor, rel, score, evidence_ref, created),
            )
            self.wal.append("causal_epistemic_relation", {
                "src_factor": src_factor, "dst_factor": dst_factor,
                "rel": rel, "score": score, "evidence_ref": evidence_ref,
            })

    def evaluate_claim(
        self,
        claim: GroundingClaim,
        *,
        active_context_factor_ids: Iterable[str] = (),
        retrieval_path_answers: Mapping[str, str] = {},
    ) -> GroundingDecision:
        reasons: list[str] = []
        trace_ok = bool(claim.cited_span_ids)
        if trace_ok:
            try:
                for span_id in claim.cited_span_ids:
                    self.get_span(span_id)
            except (KeyError, ValueError, FileNotFoundError):
                trace_ok = False
        if not trace_ok:
            reasons.append("missing or invalid claim-level source span")
        entailment_ok = (
            claim.entailment_score > self.policy.entailment_threshold
            and bool(claim.entailment_evidence_ref)
        )
        if not entailment_ok:
            reasons.append("external entailment receipt did not clear threshold")
        active = set(active_context_factor_ids)
        contradiction_free = True
        support_count = 0
        if claim.factor_ids and active:
            placeholders_left = ",".join("?" for _ in claim.factor_ids)
            placeholders_right = ",".join("?" for _ in active)
            rows = self.db.execute(
                f"SELECT rel FROM causal_epistemic_edges WHERE src_factor IN ({placeholders_left}) "
                f"AND dst_factor IN ({placeholders_right})",
                (*claim.factor_ids, *active),
            ).fetchall()
            contradiction_free = not any(row[0] == "contradicts" for row in rows)
            support_count = sum(row[0] == "supports" for row in rows)
        if not contradiction_free:
            reasons.append("committed contradiction cache contains an active conflict")
        causal_ok = True
        wording: Literal["causes", "associated_with", "non_causal"] = "non_causal"
        if claim.cause_factor is not None:
            row = self.db.execute(
                "SELECT payload,status FROM causal_edges WHERE status='committed'"
            ).fetchall()
            causal_ok = False
            associated = False
            for payload, status in row:
                edge = json.loads(payload)
                if (edge["cause_factor"], edge["effect_factor"]) == (claim.cause_factor, claim.effect_factor):
                    associated = True
                    if edge.get("identified") is True:
                        causal_ok = True
                        break
            wording = "causes" if causal_ok else "associated_with"
            if not causal_ok:
                reasons.append("causal wording lacks a committed identified edge")
        normalized_answers = {value.strip().casefold() for value in retrieval_path_answers.values() if value.strip()}
        abstain = len(normalized_answers) > 1
        if abstain:
            reasons.append("retrieval paths disagree; disagreement can trigger abstention only")
        accepted = trace_ok and entailment_ok and contradiction_free and causal_ok and not abstain
        return GroundingDecision(
            claim_id=claim.id, accepted=accepted, abstain=abstain,
            trace_ok=trace_ok, entailment_ok=entailment_ok,
            contradiction_free=contradiction_free, causal_ok=causal_ok,
            support_count=support_count, wording=wording, reasons=tuple(reasons),
        )


def re_safe(value: str) -> str:
    cleaned = "".join(char.lower() if char.isalnum() else "-" for char in value).strip("-")
    while "--" in cleaned:
        cleaned = cleaned.replace("--", "-")
    if not cleaned:
        raise ValueError("branch name has no safe characters")
    return cleaned[:48]
