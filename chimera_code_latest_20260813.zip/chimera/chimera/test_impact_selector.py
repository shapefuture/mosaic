"""Confidence-scored test command selection for changed paths."""
from __future__ import annotations
from dataclasses import dataclass
__test__ = False
import pathlib

@dataclass(frozen=True)
class TestImpactSelection:
    command:str; confidence:float; selected:tuple[str,...]; reason:str; final_requires_full:bool

class TestImpactSelector:
    def __init__(self, root:pathlib.Path): self.root=pathlib.Path(root)
    def select(self, changed_paths:list[str])->TestImpactSelection:
        tests=[]
        for path in changed_paths:
            rel=path.replace('\\','/')
            stem=pathlib.PurePosixPath(rel).stem
            candidates=[self.root/'tests'/f'test_{stem}.py', self.root/'tests'/rel.replace('src/','test_')]
            for c in candidates:
                if c.exists() and c.is_file(): tests.append(c.relative_to(self.root).as_posix())
        tests=tuple(sorted(dict.fromkeys(tests)))
        if tests:
            return TestImpactSelection('pytest -q '+' '.join(tests),0.85,tests,'direct lexical test matches',True)
        return TestImpactSelection('pytest -q',0.5,(), 'no confident focused test; full suite fallback', False)

TestImpactSelector.__test__ = False
