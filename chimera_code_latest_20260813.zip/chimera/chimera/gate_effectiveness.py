"""Evidence-backed review queue for verification-gate effectiveness.

A gate is not retired because an LLM calls it bureaucratic, and it is not kept
because a design document calls it safety.  This ledger records independently
labelled gate outcomes and only *proposes* human review once there is enough
artifact-backed data.  It never removes or weakens a gate automatically.
"""
from __future__ import annotations

from dataclasses import dataclass
import pathlib
from typing import Iterable

from .artifacts import ContentAddressedArtifactStore
from .wal import WAL


@dataclass(frozen=True)
class GateEffectiveness:
    gate: str
    observations: int
    catches: int
    false_positive_blocks: int
    cost_seconds: float
    net_value: float | None
    value_per_hour: float | None
    status: str
    human_review_recommended: bool
    reason: str


class GateEffectivenessLedger:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.wal = WAL(self.root)
        self.artifacts = ContentAddressedArtifactStore(self.root)

    def _exists(self, ref: str) -> bool:
        return isinstance(ref, str) and ref.startswith("artifact:sha256:") and self.artifacts.has(ref.removeprefix("artifact:"))

    def record(
        self, gate: str, *, caught: bool, false_positive_block: bool, cost_seconds: float, evidence_ref: str,
    ) -> None:
        if not gate.strip():
            raise ValueError("gate name is required")
        if caught and false_positive_block:
            raise ValueError("a gate observation cannot be both a catch and a false-positive block")
        if cost_seconds < 0:
            raise ValueError("gate cost cannot be negative")
        if not self._exists(evidence_ref):
            raise ValueError("gate effectiveness requires a resolvable evidence artifact")
        self.wal.append("gate_effectiveness", {
            "gate": gate.strip(), "caught": bool(caught), "false_positive_block": bool(false_positive_block),
            "cost_seconds": float(cost_seconds), "evidence_ref": evidence_ref,
        })

    def record_dual_pass(self, branch: str, *, grader_pass: bool, held_out_pass: bool | None, evidence_ref: str = "") -> None:
        """Track grader-pass and held-out-pass as separate series for Goodhart detection."""
        self.wal.append("gate_dual_pass", {
            "branch": branch,
            "grader_pass": bool(grader_pass),
            "held_out_pass": held_out_pass if held_out_pass is None else bool(held_out_pass),
            "evidence_ref": evidence_ref,
        })

    def divergence_alert(self, window: int = 50) -> dict | None:
        """Alert when grader pass-rate materially exceeds held-out pass-rate."""
        entries = [entry["data"] for entry in self.wal.replay(kind="gate_dual_pass")][-window:]
        scored = [entry for entry in entries if entry.get("held_out_pass") is not None]
        if len(scored) < 10:
            return None
        grader_rate = sum(1 for entry in scored if entry.get("grader_pass")) / len(scored)
        held_out_rate = sum(1 for entry in scored if entry.get("held_out_pass")) / len(scored)
        gap = grader_rate - held_out_rate
        if gap > 0.15:
            return {
                "alert": "grader_reality_divergence",
                "grader_pass_rate": grader_rate,
                "held_out_pass_rate": held_out_rate,
                "gap": gap,
                "window": len(scored),
            }
        return None

    def report(
        self, *, minimum_observations: int = 20, false_positive_weight: float = 1.0,
    ) -> tuple[GateEffectiveness, ...]:
        grouped: dict[str, list[dict]] = {}
        for entry in self.wal.replay(kind="gate_effectiveness"):
            row = entry["data"]
            if self._exists(str(row.get("evidence_ref", ""))):
                grouped.setdefault(str(row.get("gate", "")), []).append(row)
        output: list[GateEffectiveness] = []
        for gate, rows in sorted(grouped.items()):
            n = len(rows)
            catches = sum(bool(row.get("caught")) for row in rows)
            false_positives = sum(bool(row.get("false_positive_block")) for row in rows)
            cost = sum(max(0.0, float(row.get("cost_seconds", 0))) for row in rows)
            if n < max(1, minimum_observations):
                output.append(GateEffectiveness(
                    gate, n, catches, false_positives, cost, None, None, "insufficient-data", False,
                    f"need at least {minimum_observations} artifact-backed observations; no removal decision",
                ))
                continue
            value = catches - float(false_positive_weight) * false_positives
            per_hour = value / (cost / 3600) if cost else None
            candidate = value <= 0 and cost > 0
            output.append(GateEffectiveness(
                gate, n, catches, false_positives, cost, value, per_hour, "measured", candidate,
                "review with a human; never auto-remove" if candidate else "positive measured net value",
            ))
        return tuple(output)
