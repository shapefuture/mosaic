"""Process-group scoped cancellation receipts for local managed work.

A receipt proves only what the local OS process boundary can prove: the process
we started exited and its original process group was absent when checked.  It
cannot prove cancellation of a remote API call, provider billing, or a child
that deliberately escaped the group; such work must remain an unknown outcome.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import errno
import os
import signal
import subprocess
import time
from typing import Any


@dataclass(frozen=True)
class ProcessGroupCancellationReceipt:
    pid: int
    pgid: int | None
    reason: str
    requested_at: float
    sent_sigterm: bool
    sent_sigkill: bool
    returncode: int | None
    leader_exited: bool
    process_group_absent: bool | None
    terminal: bool
    scope: str = "local-process-group"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def process_group_absent(pgid: int | None) -> bool | None:
    """Return group absence on POSIX, otherwise explicitly report unknown."""
    if pgid is None or os.name != "posix":
        return None
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return True
    except PermissionError:
        return False
    return False


def terminate_process_group(
    process: subprocess.Popen[Any],
    *,
    reason: str,
    grace_seconds: float = 2.0,
) -> ProcessGroupCancellationReceipt:
    """Terminate a start-new-session subprocess and verify the local boundary.

    Callers must launch the process with ``start_new_session=True``.  On POSIX
    this gives it a dedicated process group identified by its leader PID.  The
    helper first requests SIGTERM, then SIGKILL after the bounded grace period.
    """
    if grace_seconds < 0:
        raise ValueError("grace_seconds must be non-negative")
    requested_at = time.time()
    pid = int(process.pid)
    pgid = pid if os.name == "posix" else None
    sent_term = False
    sent_kill = False
    if process.poll() is None:
        try:
            if pgid is not None:
                os.killpg(pgid, signal.SIGTERM)
            else:  # pragma: no cover - platform fallback
                process.terminate()
            sent_term = True
        except ProcessLookupError:
            pass
        except PermissionError:
            # Do not claim a terminal cancellation if the OS denied it.
            pass
        deadline = time.monotonic() + float(grace_seconds)
        while process.poll() is None and time.monotonic() < deadline:
            time.sleep(min(0.02, max(0.0, deadline - time.monotonic())))
        if process.poll() is None:
            try:
                if pgid is not None:
                    os.killpg(pgid, signal.SIGKILL)
                else:  # pragma: no cover - platform fallback
                    process.kill()
                sent_kill = True
            except ProcessLookupError:
                pass
            except PermissionError:
                pass
    try:
        process.wait(timeout=max(0.1, float(grace_seconds) + 1.0))
    except subprocess.TimeoutExpired:
        pass
    leader_exited = process.poll() is not None
    group_absent = process_group_absent(pgid)
    # A killed descendant can remain visible briefly while the kernel reaps it.
    # Wait a bounded post-kill interval before classifying the cancellation as
    # unknown; do not turn an instantaneous observation race into a retry.
    if leader_exited and pgid is not None and group_absent is False:
        group_deadline = time.monotonic() + max(0.1, min(1.0, float(grace_seconds) + 0.1))
        while group_absent is False and time.monotonic() < group_deadline:
            time.sleep(0.01)
            group_absent = process_group_absent(pgid)
    # On a non-POSIX fallback we can only prove the leader process exited; label
    # that explicitly rather than claiming a process-group proof.
    terminal = leader_exited and (group_absent is True if pgid is not None else False)
    return ProcessGroupCancellationReceipt(
        pid=pid,
        pgid=pgid,
        reason=str(reason)[:300],
        requested_at=requested_at,
        sent_sigterm=sent_term,
        sent_sigkill=sent_kill,
        returncode=process.poll(),
        leader_exited=leader_exited,
        process_group_absent=group_absent,
        terminal=terminal,
    )
