"""Evaluator-owned short task bank with sealed hidden tests."""
from __future__ import annotations

import hashlib
import json
import pathlib
import tempfile
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class EvaluatorTask:
    id: str
    prompt: str
    target: str
    visible_test: str
    hidden_test: str
    adversarial_property: str

    @property
    def hidden_sha256(self) -> str:
        return "sha256:" + hashlib.sha256(self.hidden_test.encode("utf-8")).hexdigest()

    def public_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "prompt": self.prompt,
            "target": self.target,
            "visible_test": self.visible_test,
            "hidden_test_sha256": self.hidden_sha256,
            "hidden_test_redacted": True,
            "adversarial_property": self.adversarial_property,
        }


class EvaluatorOwnedTaskBank:
    def __init__(self) -> None:
        self.tasks = self._builtin_tasks()

    def public_catalog(self, *, levels: int = 3) -> dict[str, Any]:
        selected_count = len(self.tasks) if int(levels) >= 3 else max(1, min(len(self.tasks), int(levels)))
        selected = self.tasks[:selected_count]
        return {
            "schema_version": "chimera.evaluator-owned-task-bank.v1",
            "task_count": len(selected),
            "hidden_tests_evaluator_owned": True,
            "tasks": [task.public_dict() for task in selected],
            "oracle_policy": "hidden_test bodies are never included in candidate prompts or public catalogs",
            "promotion_allowed": False,
        }

    def materialize_hidden(self, task_id: str, directory: pathlib.Path) -> dict[str, Any]:
        task = self._get(task_id)
        directory = pathlib.Path(directory).resolve()
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"test_hidden_{task.id}.py"
        path.write_text(task.hidden_test, encoding="utf-8")
        digest = "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()
        return {
            "schema_version": "chimera.evaluator-owned-hidden-materialization.v1",
            "task_id": task.id,
            "path": str(path),
            "sha256": digest,
            "matches_seal": digest == task.hidden_sha256,
            "hidden_body_returned": False,
        }

    def smoke(self) -> dict[str, Any]:
        catalog = self.public_catalog(levels=len(self.tasks))
        leaked = any(task.hidden_test in json.dumps(catalog) for task in self.tasks)
        materialized = []
        with tempfile.TemporaryDirectory(prefix="chimera-hidden-bank-") as td:
            for task in self.tasks:
                materialized.append(self.materialize_hidden(task.id, pathlib.Path(td)))
        return {
            "schema_version": "chimera.evaluator-owned-task-bank-smoke.v1",
            "public_catalog": catalog,
            "hidden_content_leaked": leaked,
            "materialized": materialized,
            "all_seals_match": all(row["matches_seal"] for row in materialized),
            "promotion_allowed": False,
        }

    def _get(self, task_id: str) -> EvaluatorTask:
        for task in self.tasks:
            if task.id == task_id:
                return task
        raise KeyError(task_id)

    @staticmethod
    def _builtin_tasks() -> tuple[EvaluatorTask, ...]:
        return (
            EvaluatorTask(
                id="parse_flags_recursive_v1",
                prompt="Implement parse_flags(text) returning dict flags; support --key=value, repeated keys as list, and booleans.",
                target="chimera_tasks/flags.py",
                visible_test="""from chimera_tasks.flags import parse_flags

def test_visible():
    assert parse_flags('--debug --n=2') == {'debug': True, 'n': '2'}
""",
                hidden_test="""from chimera_tasks.flags import parse_flags

def test_hidden_repeated_and_spacing():
    assert parse_flags('  --tag=a --tag=b --dry-run ') == {'tag': ['a','b'], 'dry-run': True}
""",
                adversarial_property="repeated keys and whitespace boundary",
            ),
            EvaluatorTask(
                id="safe_join_escape_v1",
                prompt="Implement safe_join(root, user_path) returning a path under root or raising ValueError on escape/symlink-like traversal.",
                target="chimera_tasks/paths.py",
                visible_test="""from chimera_tasks.paths import safe_join

def test_visible(tmp_path):
    assert str(safe_join(tmp_path, 'a/b')).startswith(str(tmp_path))
""",
                hidden_test="""import pytest
from chimera_tasks.paths import safe_join

def test_hidden_escape(tmp_path):
    with pytest.raises(ValueError): safe_join(tmp_path, '../escape')
    with pytest.raises(ValueError): safe_join(tmp_path, '/etc/passwd')
""",
                adversarial_property="path traversal and absolute-path escape",
            ),
            EvaluatorTask(
                id="agui_delta_projection_v1",
                prompt="Implement project_state_delta(data) returning a JSON Patch list suitable for AG-UI STATE_DELTA.",
                target="chimera_tasks/agui.py",
                visible_test="""from chimera_tasks.agui import project_state_delta

def test_visible():
    assert project_state_delta({'x': 1}) == [{'op':'add','path':'/state/x','value':1}]
""",
                hidden_test="""from chimera_tasks.agui import project_state_delta

def test_hidden_nested_and_empty():
    assert project_state_delta({}) == []
    assert project_state_delta({'a': {'b': 2}}) == [{'op':'add','path':'/state/a','value': {'b': 2}}]
""",
                adversarial_property="AG-UI JSON Patch shape and empty delta handling",
            ),
            EvaluatorTask(
                id="traceparent_validate_v1",
                prompt="Implement valid_traceparent(text) for W3C traceparent shape validation.",
                target="chimera_tasks/trace.py",
                visible_test="""from chimera_tasks.trace import valid_traceparent

def test_visible():
    assert valid_traceparent('00-0af7651916cd43dd8448eb211c80319c-00f067aa0ba902b7-01')
""",
                hidden_test="""from chimera_tasks.trace import valid_traceparent

def test_hidden_invalids():
    assert not valid_traceparent('00-xyz-00f067aa0ba902b7-01')
    assert not valid_traceparent('00-0af7651916cd43dd8448eb211c80319c-00f067aa0ba902b7')
""",
                adversarial_property="strict trace-context syntax without accepting malformed IDs",
            ),
            EvaluatorTask(
                id="waiver_hash_stability_v1",
                prompt="Implement finding_hash(finding) stable over unrelated keys but sensitive to path/kind/evidence.",
                target="chimera_tasks/waiver.py",
                visible_test="""from chimera_tasks.waiver import finding_hash

def test_visible():
    assert finding_hash({'path':'a','kind':'k','evidence':'x'}).startswith('sha256:')
""",
                hidden_test="""from chimera_tasks.waiver import finding_hash

def test_hidden_stability():
    a={'path':'a','kind':'k','evidence':'x','extra':'ignored'}
    b={'path':'a','kind':'k','evidence':'x'}
    c={'path':'a','kind':'k','evidence':'y'}
    assert finding_hash(a) == finding_hash(b)
    assert finding_hash(a) != finding_hash(c)
""",
                adversarial_property="waiver hash must not be broad or unstable",
            ),
            EvaluatorTask(
                id="mcp_trace_meta_v1",
                prompt="Implement inject_trace_meta(params, traceparent) returning params with params['_meta']['traceparent'] set only when valid and preserving existing meta keys.",
                target="chimera_tasks/mcp_trace.py",
                visible_test="""from chimera_tasks.mcp_trace import inject_trace_meta

def test_visible():
    out = inject_trace_meta({'name':'tool'}, '00-0af7651916cd43dd8448eb211c80319c-00f067aa0ba902b7-01')
    assert out['_meta']['traceparent'].startswith('00-')
""",
                hidden_test="""from chimera_tasks.mcp_trace import inject_trace_meta

def test_hidden_preserve_and_reject_invalid():
    out = inject_trace_meta({'_meta': {'x': 1}}, 'bad')
    assert out['_meta'] == {'x': 1}
    assert inject_trace_meta({'_meta': {'x': 1}}, '00-0af7651916cd43dd8448eb211c80319c-00f067aa0ba902b7-01')['_meta']['x'] == 1
""",
                adversarial_property="MCP trace context injection must preserve metadata and reject malformed traceparent",
            ),
            EvaluatorTask(
                id="gateway_stream_usage_v1",
                prompt="Implement parse_sse_usage(lines) returning concatenated content and usage_seen for OpenAI-compatible streaming SSE lines.",
                target="chimera_tasks/gateway_stream.py",
                visible_test="""from chimera_tasks.gateway_stream import parse_sse_usage

def test_visible():
    out = parse_sse_usage(['data: {"choices":[{"delta":{"content":"ok"}}]}', 'data: [DONE]'])
    assert out['content'] == 'ok'
""",
                hidden_test="""from chimera_tasks.gateway_stream import parse_sse_usage

def test_hidden_usage_chunk():
    lines=[': keepalive','data: {"choices":[],"usage":{"total_tokens":2}}','', 'data: [DONE]']
    assert parse_sse_usage(lines)['usage_seen'] is True
""",
                adversarial_property="gateway fidelity must preserve usage chunks and ignore keepalives",
            ),
            EvaluatorTask(
                id="sandbox_relpath_v1",
                prompt="Implement safe_relpath(path) rejecting absolute paths, '..' traversal, and empty path, returning normalized POSIX path.",
                target="chimera_tasks/sandbox_path.py",
                visible_test="""from chimera_tasks.sandbox_path import safe_relpath

def test_visible():
    assert safe_relpath('a/./b') == 'a/b'
""",
                hidden_test="""import pytest
from chimera_tasks.sandbox_path import safe_relpath

def test_hidden_escape_cases():
    for value in ['', '/etc/passwd', '../x', 'a/../../x']:
        with pytest.raises(ValueError): safe_relpath(value)
""",
                adversarial_property="sandbox path normalization must reject traversal before execution",
            ),
            EvaluatorTask(
                id="team_worktree_binding_v1",
                prompt="Implement validate_bindings(members) rejecting duplicate focus/task/worktree identities and worktree paths outside worktrees/.",
                target="chimera_tasks/team_bindings.py",
                visible_test="""from chimera_tasks.team_bindings import validate_bindings

def test_visible():
    assert validate_bindings([{'name':'a','focus':'api','worktree':'worktrees/api'}, {'name':'b','focus':'tests','worktree':'worktrees/tests'}])['ok']
""",
                hidden_test="""from chimera_tasks.team_bindings import validate_bindings

def test_hidden_duplicates_and_escape():
    out = validate_bindings([{'name':'a','focus':'api','worktree':'../escape'}, {'name':'b','focus':'api','worktree':'worktrees/api'}])
    assert not out['ok']
    assert len(out['findings']) >= 2
""",
                adversarial_property="parallel agents must not share identity or escape worktree root",
            ),
            EvaluatorTask(
                id="png_hotspot_summary_v1",
                prompt="Implement hotspot_summary(ref, actual) for two equal-sized flat RGBA byte arrays returning diffPixels and similarityScore.",
                target="chimera_tasks/pngdiff.py",
                visible_test="""from chimera_tasks.pngdiff import hotspot_summary

def test_visible():
    assert hotspot_summary(bytes([0,0,0,255]), bytes([255,0,0,255]))['diffPixels'] == 1
""",
                hidden_test="""from chimera_tasks.pngdiff import hotspot_summary

def test_hidden_identity_and_mismatch():
    assert hotspot_summary(bytes([1,2,3,255]), bytes([1,2,3,255]))['similarityScore'] == 100
    assert hotspot_summary(b'', b'')['similarityScore'] == 100
""",
                adversarial_property="visual diff receipt should be compact and handle empty/equal inputs",
            ),
            EvaluatorTask(
                id="cost_tax_summary_v1",
                prompt="Implement summarize_tax(rows) computing token_error_tax from successful/failed/retry token rows.",
                target="chimera_tasks/tax.py",
                visible_test="""from chimera_tasks.tax import summarize_tax

def test_visible():
    assert summarize_tax([{'tokens':10,'failed':False}])['token_error_tax'] == 0
""",
                hidden_test="""from chimera_tasks.tax import summarize_tax

def test_hidden_retry_failure():
    out=summarize_tax([{'tokens':10,'failed':False},{'tokens':5,'failed':True},{'tokens':5,'retry':True}])
    assert out['total_tokens']==20
    assert out['wasted_tokens']==10
    assert out['token_error_tax']==0.5
""",
                adversarial_property="double-counting failure/retry waste",
            ),
        )
