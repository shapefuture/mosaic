"""DAG solver and integration repair methods for RLMRuntime."""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import re
import time
from collections.abc import Callable
from typing import Any, Dict, List, Mapping, Optional

from .quality import TaskContract, ChangeTarget


class RLMDAGSolverMixin:
    def _hybrid_observation_needed(self, contract: TaskContract, model: str) -> bool:
        mode = self.config.planner.hybrid_observation
        if mode == "off" or not self._uses_production_provider or "mock" in model.lower():
            return False
        readable_targets = [target.path for target in contract.targets if (self.root / target.path).is_file()]
        readable_tests = [path for path in contract.tests if (self.root / path).is_file()]
        if mode == "always":
            return bool(readable_targets or readable_tests)
        # In auto mode, do not spend an extra provider turn for a simple one-file
        # task with one test. Multi-file objectives or broad evidence bundles
        # amortize the observation call and have shown higher patch quality.
        return len(contract.targets) >= 2 or len(readable_targets) + len(readable_tests) >= 4

    def _run_hybrid_observation(self, task: str, branch: str, model: str, contract: TaskContract) -> Dict[str, Any]:
        if not self._hybrid_observation_needed(contract, model):
            return {"enabled": False, "reason": "auto policy did not select shared observation"}
        seed_paths = list(dict.fromkeys([
            *[target.path for target in contract.targets if (self.root / target.path).is_file()],
            *[path for path in contract.tests if (self.root / path).is_file()],
        ]))
        paths = list(self.impact_analyzer.dependency_slice(seed_paths, self.config.planner.hybrid_max_paths))
        if not paths:
            return {"enabled": False, "reason": "no readable target/test paths"}
        requirements = {"list_files": True, "read_paths": tuple(paths), "graph_query": True}
        prompt = (
            "You are the shared discovery stage of a transactional coding harness. "
            "Do not write code or return a patch. Use the selected tool surface to list Python files, read every "
            f"required path, and query the code graph for the task. Required reads: {', '.join(paths)}.\n\n"
            f"TASK:\n{task}"
        )
        _, evidence, tokens = self._model_tool_loop(
            prompt, branch, model, allow_write=False, max_turns=2,
            tool_requirements=requirements, native_schema_profile="compact",
            native_final_patch=False, stop_after_tool_requirements=True,
        )
        remaining = self._tool_requirement_missing(evidence, requirements)
        receipt_rows = []
        for path in paths:
            try:
                content = self.workspace.read(branch, path)
            except Exception:
                continue
            receipt_rows.append(f"{path}: sha256:{hashlib.sha256(content).hexdigest()[:16]}")
        receipt = "Shared discovery receipt:\n" + "\n".join(receipt_rows)
        ref = self.artifacts.put(receipt, media_type="text/plain", provenance={"kind": "hybrid-observation", "branch": branch})
        row = {
            "enabled": True, "paths": paths, "tokens": tokens,
            "complete": not remaining, "missing": remaining,
            "receipt": receipt, "artifact": ref.digest,
        }
        self._hybrid_observations[branch] = row
        return row

    def _integration_repair_contract(self, failure: Dict[str, Any], branch: str) -> Optional[TaskContract]:
        root_contract = self._task_contract
        if root_contract is None:
            return None
        text = (str(failure.get("stdout", "")) + "\n" + str(failure.get("stderr", ""))).lower()
        selected: List[ChangeTarget] = []
        def effective_mode(path: str) -> str:
            try:
                self.workspace.read(branch, path)
                return "edit"
            except (FileNotFoundError, ValueError):
                return "create"
        for path, symbols in root_contract.required_symbols.items():
            if any(symbol.lower() in text for symbol in symbols):
                selected.append(ChangeTarget(
                    path, effective_mode(path),
                    "integration failure references required symbol",
                ))
        for target in root_contract.targets:
            name = pathlib.PurePosixPath(target.path).stem.lower().replace("_", "-")
            if target.path.endswith("cli.py") and ("no such command" in text or name in text or "cli" in text):
                selected.append(target)
        if not selected:
            selected = [target for target in root_contract.targets if target.path.startswith("chimera/")][:2]
        deduped = list({target.path: target for target in selected}.values())
        if not deduped:
            return None
        return TaskContract(
            task=root_contract.task + "\nRepair the integration failures shown by the harness.",
            tests=root_contract.tests, targets=deduped,
            protected_paths=root_contract.protected_paths,
            required_literals=root_contract.required_literals,
            required_symbols=root_contract.required_symbols,
            required_calls=root_contract.required_calls,
            required_mapping_keys=root_contract.required_mapping_keys,
            required_prefixes=root_contract.required_prefixes, required_call_arity=root_contract.required_call_arity,
        )

    def _contract_for_atom(self, atom_spec: Dict[str, Any], goal: str) -> TaskContract:
        local = TaskContract.compile(self.root, goal)
        targets = [
            ChangeTarget(
                path=str(path),
                mode="edit" if (self.root / str(path)).exists() else "create",
                reason=f"hierarchical atom {atom_spec.get('id', '')}",
            )
            for path in atom_spec.get("targets", []) if path
        ] or local.targets
        root_contract = self._task_contract
        protected = list(dict.fromkeys([
            *local.protected_paths,
            *(atom_spec.get("protected_paths", []) or []),
            *((root_contract.protected_paths if root_contract else [])),
        ]))
        required_symbols = dict(local.required_symbols)
        required_calls = dict(local.required_calls)
        required_mapping_keys = dict(local.required_mapping_keys)
        required_prefixes = {path: dict(values) for path, values in local.required_prefixes.items()}
        required_call_arity = {path: dict(values) for path, values in local.required_call_arity.items()}
        required_literals = list(local.required_literals)
        if root_contract:
            for path in [target.path for target in targets]:
                if path in root_contract.required_symbols:
                    required_symbols[path] = root_contract.required_symbols[path]
                if path in root_contract.required_calls:
                    required_calls[path] = root_contract.required_calls[path]
                if path in root_contract.required_mapping_keys:
                    required_mapping_keys[path] = root_contract.required_mapping_keys[path]
                if path in root_contract.required_prefixes:
                    required_prefixes[path] = root_contract.required_prefixes[path]
                if path in root_contract.required_call_arity:
                    required_call_arity[path] = root_contract.required_call_arity[path]
            required_literals = list(dict.fromkeys([*required_literals, *root_contract.required_literals]))
        scoped_task = goal + (f"\nRoot objective: {root_contract.task}" if root_contract else "")
        return TaskContract(
            task=scoped_task, tests=local.tests or (root_contract.tests if root_contract else {}),
            targets=targets, protected_paths=protected, required_literals=required_literals,
            required_symbols=required_symbols, required_calls=required_calls,
            required_mapping_keys=required_mapping_keys,
            required_prefixes=required_prefixes,
            required_call_arity=required_call_arity,
        )

    def _solver_for_node(self, branch: str, model: str = "mock-echo") -> Callable:
        def solver(node):
            self._thread_local.agent_role = node.agent_type
            variable_context = ""
            for name, variable in self.blackboard.variables.items():
                variable_context += f"\nVariable {name} v{variable.version}:\n{variable.retrieve(node.question, max_chars=6000, max_chunks=4)}"
            repository_context, graph_hits = self._repository_context(node.question)
            selected_model = node.model_route if model == "auto" and node.model_route else model
            from .context_plan import ContextPlan
            from .typed_context import ContextKind, ContextTrust, TypedContextItem
            trusted_inputs = {
                key: value for key, value in node.inputs.items()
                if key in {"atom_spec", "task_slice", "root_task", "hierarchy_id"}
            }
            dependency_inputs = {
                key: value for key, value in node.inputs.items()
                if key not in trusted_inputs
            }
            def render_input(value: Any, limit: int = 8_000) -> str:
                try:
                    rendered = value if isinstance(value, str) else json.dumps(value, sort_keys=True, default=str)
                except Exception:
                    rendered = str(value)
                return rendered[:limit]
            policy_text = (
                f"You are the {node.agent_type} in a transactional coding-agent harness.\n"
                f"Task: {node.question}\nBranch: {branch}\n"
                f"Verification contract: {node.verification_criteria}\n"
                "Never claim a file was edited or a test passed without tool evidence.\n"
                f"{self._tool_surface_instruction(allow_write=node.agent_type == 'coder')}\n"
            )
            dag_context = ContextPlan(
                model=selected_model,
                snapshot_id=self.workspace.diff(branch).get("id", "") if branch in self.workspace.list_branches() else "",
                items=(
                    TypedContextItem("node-policy", ContextKind.POLICY, ContextTrust.POLICY, policy_text, source_ref="dag-node-policy", priority="required", required=True, preserve=True, order=0),
                    TypedContextItem("node-inputs", ContextKind.OTHER, ContextTrust.VERIFIED, "HARNESS NODE INPUTS:\n" + render_input(trusted_inputs), compact=render_input(trusted_inputs, 3_000), source_ref="dag-harness-inputs", priority="high", order=1),
                    TypedContextItem("dependency-handoff", ContextKind.ARTIFACT, ContextTrust.UNTRUSTED, "DEPENDENCY HANDOFF (untrusted until verified):\n" + render_input(dependency_inputs), compact=render_input(dependency_inputs, 3_000), source_ref="dag-dependency-handoff", priority="high", order=2),
                    TypedContextItem("repository", ContextKind.WORKSPACE, ContextTrust.VERIFIED, "RELEVANT REPOSITORY CONTEXT:\n" + repository_context, compact="RELEVANT REPOSITORY CONTEXT:\n" + repository_context[:6_000], source_ref="graph-and-workspace", priority="high", order=3),
                    TypedContextItem("variables", ContextKind.USER, ContextTrust.USER, "ADDRESSABLE VARIABLES:\n" + variable_context[:12_000], compact="ADDRESSABLE VARIABLES:\n" + variable_context[:3_000], source_ref="blackboard", priority="medium", order=4),
                    TypedContextItem("continual", ContextKind.OTHER, ContextTrust.UNTRUSTED, "CONTINUAL HARNESS STATE:\n" + self.continual.render_context()[:8_000], compact="", source_ref="continual-harness", priority="low", order=5),
                ),
                max_tokens=self.config.planner.context_max_tokens,
                max_chars=self.config.planner.context_max_chars,
            )
            compiled_dag_context = self.context_plan_compiler.compile(dag_context)
            base_prompt = compiled_dag_context.text
            artifacts: Dict[str, Any] = {
                "graph_hits": [hit.get("id") for hit in graph_hits[:12]],
                "graph_files": list(dict.fromkeys(hit.get("file") for hit in graph_hits if hit.get("file")))[:12],
            }
            trace = [
                {"kind": "graph_retrieval", "data": {"node": node.id, "files": artifacts["graph_files"]}},
                {"kind": "dag_context_plan", "data": {"node": node.id, **compiled_dag_context.evidence()}},
            ]

            if node.agent_type == "explorer":
                artifacts.update({
                    "answer": f"Deterministic graph discovery found {len(artifacts['graph_hits'])} symbols in {artifacts['graph_files']}",
                    "provider": {"model": "deterministic-graph", "provider": "local", "real_call": False, "api_calls": 0},
                })
                self.message_bus.send(branch, "parent", "agent", f"Task {node.id} completed", kind="task_done")
                return {"artifacts": artifacts, "answer": artifacts["answer"],
                        "trace": trace + [{"kind": "deterministic_stage", "data": {"node": node.id, "stage": "graph"}}],
                        "tokens": 0}

            from .intent_policy import IntentGate
            if node.agent_type == "coder" and not IntentGate().decide(self._active_task or node.question).allow_write:
                artifacts.update({
                    "answer": "Assessment-only request: no workspace mutation was authorized; report evidence and a proposed next action.",
                    "test_status": None,
                    "provider": {"model": "intent-gate", "provider": "local", "real_call": False, "api_calls": 0},
                })
                trace.append({"kind": "intent_gate", "data": {"allow_write": False, "reason": "assessment is not mutation authorization"}})
                tokens = 0
            elif node.agent_type == "coder" and self._uses_production_provider:
                atom_spec = node.inputs.get("atom_spec") if isinstance(node.inputs.get("atom_spec"), dict) else None
                atom_branch = branch
                if atom_spec:
                    focused_contract = self._contract_for_atom(atom_spec, node.question)
                    focused_task = node.question
                    test_command = str(atom_spec.get("test_command") or "pytest -q")
                    atom_branch = str(atom_spec.get("branch") or f"{branch}--{node.id[-8:]}")
                    with self._workspace_lock:
                        if atom_branch not in self.workspace.list_branches():
                            self.workspace.fork(atom_branch, from_branch=branch)
                else:
                    focused_contract = self._task_contract
                    focused_task = self._active_task or node.question
                    test_command = "pytest -q"
                hybrid = self._hybrid_observations.get(branch, {})
                shared_context = str(hybrid.get("receipt", "")) if hybrid.get("complete") else ""
                focused = self._focused_coder(
                    atom_branch, selected_model, focused_task,
                    contract_override=focused_contract, test_command=test_command,
                    shared_context=shared_context,
                )
                focused_artifacts = focused.setdefault("artifacts", {})
                if atom_spec:
                    focused_artifacts["atom_branch"] = atom_branch
                    focused_artifacts["integration_branch"] = branch
                    if focused_artifacts.get("test_status") == 0:
                        with self._workspace_lock:
                            merge = self.workspace.merge_into(atom_branch, branch)
                        focused_artifacts["merge"] = merge
                        focused_artifacts["atom_diff"] = focused_artifacts.get("diff")
                        focused_artifacts["diff"] = merge["target_diff"]
                        focused_artifacts["ops"] = merge["target_diff"].get("ops", [])
                        focused.setdefault("trace", []).append({
                            "kind": "atom_merge", "data": {
                                "atom_branch": atom_branch, "integration_branch": branch,
                                "delta": merge["delta"]["id"], "ops": len(merge["delta"].get("ops", [])),
                            },
                        })
                focused_artifacts.setdefault("graph_hits", artifacts["graph_hits"])
                focused_artifacts.setdefault("graph_files", artifacts["graph_files"])
                focused["trace"] = trace + focused.get("trace", [])
                provider_evidence = focused_artifacts.get("provider", {})
                focused["trace"].append({
                    "kind": "model_call",
                    "data": {"node": node.id, "model": provider_evidence.get("model", selected_model),
                             "real": bool(provider_evidence.get("real_call")), "quality_mode": "focused-per-file"},
                })
                self.message_bus.send(branch, "parent", "agent", f"Task {node.id} completed", kind="task_done")
                return focused

            elif node.agent_type == "coder":
                prompt = base_prompt + """
Return a JSON object (optionally fenced as json) with this shape:
{"summary": "what and why", "files": [{"path": "new/or/replaced/file", "content": "complete file content"}], "edits": [{"path": "existing/file", "find": "exact unique old block", "replace": "new block"}]}
Use files for new/small files and exact surgical edits for large existing files. Never use ellipses. Keep the patch minimal.
"""
                response, tool_evidence, tokens = self._model_tool_loop(
                    prompt, branch, selected_model, allow_write=True, max_turns=8
                )
                payload = self._json_from_model(response.get("answer", ""))
                def is_schema_echo(value):
                    return bool(value) and any(
                        isinstance(item, dict) and item.get("path") in {"new/or/replaced/file", "existing/file", "workspace/relative/path"}
                        for key in ("files", "edits")
                        for item in (value.get(key, []) if isinstance(value.get(key, []), list) else [])
                    )
                def is_actionable(value):
                    return bool(value) and any(
                        isinstance(value.get(key), list) and len(value.get(key)) > 0
                        for key in ("files", "edits")
                    )
                if is_schema_echo(payload) or not is_actionable(payload):
                    payload = None
                tool_applied = [
                    item.get("path") for item in tool_evidence
                    if item.get("ok") and item.get("tool") in {"write", "write_file", "fs.write", "edit", "edit_file", "fs.edit"}
                ]
                compile_failure = None
                if not payload and not tool_applied:
                    # Many coding models first emit a detailed prose/code draft.
                    # Use a bounded, no-tool compilation pass rather than
                    # discarding that work or treating prose as a patch.
                    prior_calls = int(response.get("_harness_call_count", 0) or 0)
                    draft = response.get("answer", "") or ""
                    test_contract = ""
                    tests_dir = self.root / "tests"
                    if tests_dir.exists():
                        for test_path in sorted(tests_dir.glob("*audit*.py")):
                            test_contract += f"\n--- {test_path.name} ---\n{test_path.read_text()[:8000]}"
                    cli_path = self.root / "chimera" / "cli.py"
                    cli_tail = cli_path.read_text()[-8000:] if cli_path.exists() else ""
                    compile_prompt = (
                        "RETURN ONLY ONE VALID JSON OBJECT. NO PROSE, MARKDOWN, TOOL CALLS, OR ELLIPSES.\n"
                        "Compile the draft below into this schema: "
                        '{"summary":"...","files":[{"path":"...","content":"complete content"}],'
                        '"edits":[{"path":"...","find":"exact unique old block","replace":"new block"}]}.\n'
                        "Use files for new files and exact edits for existing files. Do not modify tests.\n"
                        f"SUPPLIED TEST CONTRACT:\n{test_contract[-12_000:]}\n"
                        f"CURRENT CLI TAIL FOR AN EXACT EDIT:\n{cli_tail}\n"
                        f"DRAFT TO COMPILE:\n{draft[-30_000:]}\n"
                        "FINAL OUTPUT MUST BE JSON ONLY."
                    )
                    compiled = self.model_provider(compile_prompt, model=selected_model)
                    tokens += int(compiled.get("tokens", 0) or 0)
                    compiled["_harness_call_count"] = prior_calls + 1
                    compiled_payload = self._json_from_model(compiled.get("answer", ""))
                    if is_actionable(compiled_payload) and not is_schema_echo(compiled_payload):
                        payload = compiled_payload
                        response = compiled
                    else:
                        compile_failure = {
                            "chars": len(compiled.get("answer", "") or ""),
                            "prefix": (compiled.get("answer", "") or "")[:240],
                            "key_slot": compiled.get("key_slot"),
                        }
                patch_result = self.action_executor.apply_patch_payload(branch, payload or {}) if payload else {"applied": [], "rejected": []}
                if compile_failure:
                    patch_result["rejected"].append(f"strict JSON compilation failed: {compile_failure}")
                patch_result["applied"] = list(dict.fromkeys([*tool_applied, *patch_result.get("applied", [])]))
                if not patch_result["applied"] and not payload:
                    patch_result["rejected"].append("no valid JSON patch or successful write tool")
                diff = self.workspace.diff(branch)
                artifacts.update({
                    "answer": (payload or {}).get("summary", response.get("answer", "")),
                    "patch": patch_result, "diff": diff, "ops": diff.get("ops", []),
                    "tool_evidence": tool_evidence,
                    "provider": {**{k: response.get(k) for k in ("model", "provider", "real_call", "fallback", "key_slot", "key_pool_size")}, "api_calls": response.get("_harness_call_count", 1)},
                })
                # Run focused/full tests only when a real patch was staged.
                test = self.action_executor.run_branch_tests(branch) if patch_result["applied"] else {"status": 125, "stdout": "", "stderr": "no patch applied", "evidence": {}}
                artifacts["test_status"] = test["status"]
                artifacts["test_evidence"] = test
                trace.extend([
                    {"kind": "tool_calls", "data": tool_evidence},
                    {"kind": "patch_applied", "data": patch_result},
                    {"kind": "test_result", "data": {"status": test["status"], "duration_ms": test.get("duration_ms")}},
                ])
            elif node.agent_type == "verifier":
                # Integration verification is deliberately unscoped. Impact
                # analysis accelerates intermediate atoms; it never replaces
                # the final whole-system gate.
                test = self.action_executor.run_branch_tests(branch, impact_scope=False)
                diff = self.workspace.diff(branch)
                integration_repair = None
                atom_spec = node.inputs.get("atom_spec") if isinstance(node.inputs.get("atom_spec"), dict) else None
                if (
                    test.get("status") != 0
                    and atom_spec and atom_spec.get("kind") == "integration"
                    and self._uses_production_provider
                ):
                    repair_contract = self._integration_repair_contract(test, branch)
                    if repair_contract:
                        integration_repair = self._focused_coder(
                            branch, selected_model,
                            "Repair integration failures for the root objective",
                            contract_override=repair_contract,
                            test_command="pytest -q",
                        )
                        repair_artifacts = integration_repair.get("artifacts", {})
                        # A focused repair result is not integration evidence.
                        # Re-run the full suite after the candidate repair.
                        test = self.action_executor.run_branch_tests(branch, impact_scope=False)
                        diff = self.workspace.diff(branch)
                        trace.extend(integration_repair.get("trace", []))
                        trace.append({
                            "kind": "integration_repair",
                            "data": {
                                "status": test.get("status"),
                                "targets": [target.path for target in repair_contract.targets],
                                "applied": repair_artifacts.get("patch", {}).get("applied", []),
                            },
                        })
                prompt = base_prompt + f"\nIndependent evidence: diff={json.dumps(diff)[:6000]} test_status={test['status']} stderr={test['stderr'][:2000]}\nReport only what this evidence supports."
                # The verifier is deliberately not the actor model.  It reports
                # deterministic sandbox and diff evidence, avoiding correlated
                # self-judging and reward hacking.
                response = {
                    "answer": f"Deterministic verification: tests status={test['status']}; diff ops={len(diff.get('ops', []))}; LTL=G(!writeOutsideAllow).",
                    "model": "deterministic-verifier", "provider": "local", "real_call": False,
                }
                tool_evidence = []
                tokens = int((integration_repair or {}).get("tokens", 0) or 0)
                artifacts.update({
                    "answer": response["answer"], "diff": diff, "ops": diff.get("ops", []),
                    "test_status": test["status"], "test_evidence": test,
                    "tool_evidence": tool_evidence,
                    "integration_repair": (integration_repair or {}).get("artifacts"),
                    "ltl_formula": "G(!writeOutsideAllow)",
                    "provider": {**{k: response.get(k) for k in ("model", "provider", "real_call", "fallback", "key_slot", "key_pool_size")}, "api_calls": response.get("_harness_call_count", 1)},
                })
                trace.append({"kind": "test_result", "data": {"status": test["status"], "duration_ms": test.get("duration_ms")}})
            elif node.agent_type == "synthesizer":
                diff = self.workspace.diff(branch)
                status = node.inputs.get("test_status", "unknown")
                try:
                    status = int(status)
                except (TypeError, ValueError):
                    pass
                artifacts.update({
                    "answer": f"Evidence synthesis: branch={branch}; test_status={status}; diff={diff.get('id')}; files={[op.get('path') for op in diff.get('ops', [])]}",
                    "diff": diff, "ops": diff.get("ops", []), "test_status": status,
                    "tool_evidence": [],
                    "provider": {"model": "deterministic-synthesizer", "provider": "local", "real_call": False},
                })
                response = {"model": "deterministic-synthesizer"}
                tokens = 0
            else:
                response, tool_evidence, tokens = self._model_tool_loop(
                    base_prompt, branch, selected_model, allow_write=False,
                    max_turns=3 if node.agent_type == "explorer" else 2,
                )
                artifacts.update({
                    "answer": response.get("answer", ""), "tool_evidence": tool_evidence,
                    "provider": {**{k: response.get(k) for k in ("model", "provider", "real_call", "fallback", "key_slot", "key_pool_size")}, "api_calls": response.get("_harness_call_count", 1)},
                })
                if node.agent_type == "synthesizer":
                    diff = self.workspace.diff(branch)
                    artifacts.update({"diff": diff, "ops": diff.get("ops", [])})
                    if "test_status" in node.inputs:
                        try:
                            artifacts["test_status"] = int(node.inputs["test_status"])
                        except (TypeError, ValueError):
                            artifacts["test_status"] = node.inputs["test_status"]

            self.message_bus.send(branch, "parent", "agent", f"Task {node.id} completed", kind="task_done")
            provider_evidence = artifacts.get("provider", {})
            trace.append({
                "kind": "model_call" if provider_evidence.get("real_call") else "deterministic_stage",
                "data": {"node": node.id, "model": provider_evidence.get("model", selected_model), "real": bool(provider_evidence.get("real_call")), "api_calls": provider_evidence.get("api_calls", 0)},
            })
            return {"artifacts": artifacts, "answer": artifacts.get("answer", ""), "trace": trace, "tokens": tokens}
        return solver

    def _finalize_run_evidence(self, task: str, branch: str, result: Dict[str, Any]) -> Dict[str, Any]:
        """Attach outcome-independent behavioral and after-action receipts.

        The receipt contains branch/test facts, not a model's explanation of
        itself.  It is useful for replay and regression accounting but does not
        upgrade a failed test or replace the existing commit gates.
        """
        from .behavior_traps import BehaviorTrapEvaluator

        traces = result.get("traces") if isinstance(result.get("traces"), list) else []
        diff_for_gate = result.get("diff") if isinstance(result.get("diff"), Mapping) else {}
        audit = BehaviorTrapEvaluator().audit(
            task=task,
            diff=diff_for_gate,
            traces=traces,
            answer=str(result.get("answer", "")),
        )
        guard = audit.as_dict()
        try:
            from .completion_gate import CompletionGate
            completion_gate = CompletionGate().check(
                answer=str(result.get("answer", "")), diff=diff_for_gate,
                traces=traces, verification=result.get("verification") if isinstance(result.get("verification"), Mapping) else {},
            )
            result["completion_gate"] = completion_gate.as_dict()
        except Exception as exc:
            result["completion_gate"] = {"allowed": None, "error": f"{type(exc).__name__}: {exc}"[:200]}
        test_rows = [
            item.get("data", {}) for item in result.get("traces", [])
            if isinstance(item, Mapping) and item.get("kind") == "test_result"
        ]
        actual = {
            "branch": branch,
            "diff_id": (result.get("diff") or {}).get("id") if isinstance(result.get("diff"), Mapping) else None,
            "changed_paths": [
                op.get("path") for op in (result.get("diff") or {}).get("ops", [])
                if isinstance(op, Mapping) and op.get("path")
            ] if isinstance(result.get("diff"), Mapping) else [],
            "test_results": test_rows,
            "verification_status": (result.get("verification") or {}).get("status") if isinstance(result.get("verification"), Mapping) else None,
            "behavioral_guard_passed": audit.passed,
        }
        receipt = self.artifacts.put(
            json.dumps(actual, sort_keys=True, separators=(",", ":"), default=str),
            media_type="application/vnd.chimera.run-outcome+json",
            provenance={"branch": branch, "kind": "post-run-observed-facts"},
        )
        evidence_ref = f"artifact:{receipt.digest}"
        audited_state = getattr(self._thread_local, "audited_task_state", None)
        if audited_state is not None and self._task_contract is not None:
            try:
                protected = None
                quality = result.get("quality") if isinstance(result.get("quality"), Mapping) else {}
                if isinstance(quality, Mapping) and "protected_tests_unchanged" in quality:
                    protected = bool(quality.get("protected_tests_unchanged"))
                if protected is None:
                    for trace_row in traces:
                        if not isinstance(trace_row, Mapping) or trace_row.get("kind") != "quality_stages":
                            continue
                        stages = trace_row.get("data", [])
                        if not isinstance(stages, list):
                            continue
                        for stage in stages:
                            if isinstance(stage, Mapping) and stage.get("stage") == "protected-test-integrity":
                                protected = bool(stage.get("ok"))
                audited_state = self.audited_task_states.record(
                    audited_state,
                    contract=self._task_contract,
                    diff=diff_for_gate,
                    verification=result.get("verification") if isinstance(result.get("verification"), Mapping) else {},
                    protected_tests_unchanged=protected,
                    evidence_ref=evidence_ref,
                )
                self._thread_local.audited_task_state = audited_state
                result["audited_task_state"] = audited_state.as_dict()
            except Exception as exc:
                from .degradation_ledger import confess_degradation
                confess_degradation(self.root, "audited_task_state", "finalization", type(exc).__name__, severity="info")
        try:
            from .double_confirm import DoubleConfirm
            forced_confirm = os.environ.get("CHIMERA_DOUBLE_CONFIRM") == "1"
            confirmation_model = os.environ.get("CHIMERA_DOUBLE_CONFIRM_MODEL") or getattr(self, "_active_model", "mock-echo")
            confirmer = DoubleConfirm().run(
                task=task, answer=str(result.get("answer", "")),
                verification=result.get("verification") if isinstance(result.get("verification"), Mapping) else {},
                completion_gate=result.get("completion_gate") if isinstance(result.get("completion_gate"), Mapping) else {},
                forced=forced_confirm,
                provider=lambda prompt: self.model_provider(prompt, model=confirmation_model),
            )
            result["double_confirm"] = confirmer.as_dict()
        except Exception as exc:
            result["double_confirm"] = {"enabled": None, "error": f"{type(exc).__name__}: {exc}"[:200]}

        try:
            from .heldout_verifier import HeldOutVerifier
            from .quality_rubric import PatchReviewRubric
            heldout = HeldOutVerifier(self.root).evaluate(
                task=task, diff=result.get("diff") if isinstance(result.get("diff"), Mapping) else {},
                traces=result.get("traces") if isinstance(result.get("traces"), list) else [],
                answer=str(result.get("answer", "")),
            )
            rubric = PatchReviewRubric().score(
                task=task, diff=result.get("diff") if isinstance(result.get("diff"), Mapping) else {},
                answer=str(result.get("answer", "")),
            )
            result["heldout"] = heldout.as_dict()
            result["quality_rubric"] = rubric.as_dict()
        except Exception as exc:
            result["heldout"] = {"passed": None, "error": f"{type(exc).__name__}: {exc}"[:200]}
            result["quality_rubric"] = {"passed": None, "error": f"{type(exc).__name__}: {exc}"[:200]}
        review = self.after_action_reviews.record(
            task,
            actual,
            "retain deterministic transactional and test evidence gates",
            "remove nothing automatically; compare outcome receipts before changing policy",
            [evidence_ref],
        )
        portfolio_events = list(result.get("traces", [])) if isinstance(result.get("traces"), list) else []
        portfolio_events.append({
            "kind": "run_outcome", "ok": bool(audit.passed),
            "data": {"verification_status": actual["verification_status"], "changed_paths": actual["changed_paths"]},
        })
        portfolio = self.evidence_portfolio.capture(
            run_id=f"{branch}:{actual['diff_id'] or 'no-diff'}", events=portfolio_events,
        )
        result["behavioral_guard"] = guard
        result["after_action"] = {"evidence_ref": evidence_ref, "review": review}
        result["evidence_portfolio"] = portfolio.as_dict()
        try:
            from .event_sink import EventSink
            EventSink(self.root).emit("run_finalized", {"branch": branch, "verification_status": actual["verification_status"], "changed_paths": actual["changed_paths"], "evidence_ref": evidence_ref})
        except Exception as exc:
            from .degradation_ledger import confess_degradation
            confess_degradation(self.root, "run_finalized_event", "finalization", type(exc).__name__, severity="info")
        return result
