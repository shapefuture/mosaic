"""Advisory engineering requirements/interface readiness from explicit facts.

This does not rewrite a task or invent missing requirements.  It makes the
absence of measurable acceptance, interface conventions, ownership, units, or
solution constraints visible before expensive coding work begins.
"""
from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel, ConfigDict

from .quality import TaskContract


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class EngineeringReadinessFinding(_FrozenModel):
    topic: Literal[
        "acceptance", "targets", "interface", "units", "acceptance_authority",
        "solution_constraint", "irreversibility",
    ]
    status: Literal["observed", "missing", "ambiguous"]
    evidence: tuple[str, ...] = ()
    detail: str


class EngineeringReadinessReceipt(_FrozenModel):
    schema_version: str = "chimera.engineering-readiness.v1"
    advisory_only: bool = True
    findings: tuple[EngineeringReadinessFinding, ...]

    @property
    def missing_topics(self) -> tuple[str, ...]:
        return tuple(row.topic for row in self.findings if row.status == "missing")

    @property
    def ambiguous_topics(self) -> tuple[str, ...]:
        return tuple(row.topic for row in self.findings if row.status == "ambiguous")

    def as_preflight_evidence(self) -> dict:
        return {
            "advisory_only": True,
            "findings": [row.model_dump(mode="json") for row in self.findings],
            "missing_topics": list(self.missing_topics),
            "ambiguous_topics": list(self.ambiguous_topics),
        }


class EngineeringReadinessAuditor:
    """Extract only literal task/contract evidence; unknown stays unknown."""

    _UNIT_RE = re.compile(
        r"\b(?:ms|msec|milliseconds?|seconds?|minutes?|hours?|bytes?|kb|kib|mb|mib|gb|gib|"
        r"utc|iso[- ]?8601|hz|khz|mhz|percent|%|http|json|yaml|toml|schema|api|cli|version)\b",
        re.IGNORECASE,
    )
    _OWNER_RE = re.compile(
        r"\b(?:accepted|approved|signed[ -]?off|owned|reviewed)\s+by\s+([A-Za-z0-9_.@/-]{2,80})",
        re.IGNORECASE,
    )
    _LOCKIN_RE = re.compile(
        r"\b(?:must\s+use|only\s+use|use\s+only|do\s+not\s+use|without\s+using|required\s+to\s+use)\b",
        re.IGNORECASE,
    )
    _IRREVERSIBLE_RE = re.compile(
        r"\b(?:deploy|production|payment|purchase|delete|email|external\s+api|migrate\s+database)\b",
        re.IGNORECASE,
    )

    def audit(self, task: str, contract: TaskContract) -> EngineeringReadinessReceipt:
        task_text = str(task)
        tests = tuple(sorted(contract.tests))
        targets = tuple(f"{row.mode}:{row.path}" for row in contract.targets)
        interface = tuple(sorted(
            [f"symbol:{path}:{symbol}" for path, values in contract.required_symbols.items() for symbol in values]
            + [f"call:{path}:{call}" for path, values in contract.required_calls.items() for call in values]
            + [f"mapping:{path}:{key}" for path, values in contract.required_mapping_keys.items() for key in values]
        ))
        units = tuple(dict.fromkeys(match.group(0).lower() for match in self._UNIT_RE.finditer(task_text)))
        owners = tuple(dict.fromkeys(match.group(1) for match in self._OWNER_RE.finditer(task_text)))
        lockins = tuple(match.group(0).lower() for match in self._LOCKIN_RE.finditer(task_text))
        irreversible = tuple(dict.fromkeys(match.group(0).lower() for match in self._IRREVERSIBLE_RE.finditer(task_text)))
        return EngineeringReadinessReceipt(findings=(
            EngineeringReadinessFinding(
                topic="acceptance", status="observed" if tests else "missing", evidence=tests,
                detail="executable acceptance tests were identified" if tests else "no executable acceptance test was identified",
            ),
            EngineeringReadinessFinding(
                topic="targets", status="observed" if targets else "missing", evidence=targets,
                detail="bounded mutation targets were identified" if targets else "no bounded mutation target was identified",
            ),
            EngineeringReadinessFinding(
                topic="interface", status="observed" if interface else "ambiguous", evidence=interface,
                detail="interface facts were extracted from imports/contracts" if interface else "no explicit symbol/call/mapping interface fact was extracted",
            ),
            EngineeringReadinessFinding(
                topic="units", status="observed" if units else "ambiguous", evidence=units,
                detail="task names units/protocol conventions" if units else "task supplies no explicit unit/protocol convention",
            ),
            EngineeringReadinessFinding(
                topic="acceptance_authority", status="observed" if owners else "ambiguous", evidence=owners,
                detail="task explicitly names an acceptance authority" if owners else "no human acceptance authority is evidenced; tests remain the only observed judge",
            ),
            EngineeringReadinessFinding(
                topic="solution_constraint", status="observed" if lockins else "ambiguous", evidence=lockins,
                detail="task contains an explicit solution constraint" if lockins else "no explicit solution constraint was detected; this is not permission to broaden scope",
            ),
            EngineeringReadinessFinding(
                topic="irreversibility", status="observed" if irreversible else "ambiguous", evidence=irreversible,
                detail="task names a potentially irreversible/external action" if irreversible else "no irreversible-action term was detected; capability policy remains authoritative",
            ),
        ))
