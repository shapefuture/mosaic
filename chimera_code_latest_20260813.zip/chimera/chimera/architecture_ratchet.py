"""Architecture growth ratchet.

Baselines existing large legacy modules but blocks further growth or oversized
new modules unless they are explicitly exempted in future policy.
"""
from __future__ import annotations

import json
import pathlib
from dataclasses import asdict, dataclass
from typing import Any


LEGACY_BASELINE = {
    # Baseline all known large legacy/current modules. The ratchet blocks growth
    # above these values while allowing incremental split-down work.
    "chimera/evolution_search.py": 886,
    "chimera/mcp_remote.py": 791,
    "chimera/dag.py": 787,
    "chimera/graph.py": 781,
    "chimera/rlm_provider.py": 743,
    "chimera/mcp_server.py": 705,
    "chimera/long_running.py": 673,
    "chimera/rlm_execution_methods.py": 624,
    "chimera/platform.py": 602,
    "chimera/__init__.py": 598,
    "chimera/semantic_lsp.py": 587,
    "chimera/rlm_dag_solver.py": 565,
    "chimera/action_ir.py": 559,
    "chimera/cloud_state.py": 557,
    "chimera/semantic_code_intelligence.py": 556,
    "chimera/branch.py": 535,
    "chimera/lazycodex_sota_transfers.py": 531,
    "chimera/hierarchical.py": 488,
    "chimera/sandbox.py": 486,
    "chimera/rlm_tool_methods.py": 467,
    "chimera/application.py": 460,
    "chimera/bootstrap.py": 445,
    "chimera/quality.py": 439,
    "chimera/objective.py": 437,
    "chimera/rlm_loop.py": 434,
    "chimera/rlm.py": 403,
    "chimera/rpc_server.py": 398,
    "chimera/verifier.py": 398,
    "chimera/evolution_archive.py": 397,
    "chimera/wire.py": 389,
    "chimera/sandbox_certification.py": 379,
    "chimera/wal.py": 373,
    "chimera/provider_adapters.py": 361,
    "chimera/evolution.py": 356,
    "chimera/release_provenance.py": 354,
}


@dataclass(frozen=True)
class RatchetFinding:
    path: str
    kind: str
    status: str
    evidence: str


class ArchitectureRatchet:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def run(self, *, default_budget: int = 500, new_module_budget: int = 350) -> dict[str, Any]:
        findings: list[RatchetFinding] = []
        for path in sorted((self.root / "chimera").glob("*.py")):
            rel = str(path.relative_to(self.root))
            count = self._loc(path)
            baseline = LEGACY_BASELINE.get(rel)
            if baseline is not None:
                if count > baseline:
                    findings.append(RatchetFinding(rel, "legacy-growth", "fail", f"{count} LOC > baseline {baseline}"))
                continue
            budget = default_budget
            if path.stat().st_mtime > (self.root / "chimera" / "cli.py").stat().st_mtime:
                budget = new_module_budget
            if count > budget:
                findings.append(RatchetFinding(rel, "module-budget", "warn", f"{count} LOC > budget {budget}"))
        return {
            "schema_version": "chimera.architecture-ratchet.v1",
            "root": str(self.root),
            "status": "fail" if any(f.status == "fail" for f in findings) else "review" if findings else "pass",
            "findings": [asdict(f) for f in findings],
            "legacy_baseline_count": len(LEGACY_BASELINE),
            "promotion_allowed": False,
            "rule": "legacy modules may not grow; new/adapter modules should stay small or split",
        }

    @staticmethod
    def _loc(path: pathlib.Path) -> int:
        return sum(1 for line in path.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip() and not line.strip().startswith("#"))
