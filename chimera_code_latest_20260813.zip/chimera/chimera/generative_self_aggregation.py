"""Generative self-aggregation prompt support for patch pools.

GSA is deliberately synthesis, not best-of-N judging.  The model is asked to
combine strengths across candidates and avoid known weaknesses, while the
harness still owns static gates and executable tests.
"""
from __future__ import annotations

import json
from typing import Any, Mapping

from .code_execution_prompt_policy import CODE_EXECUTION_VERDICT_POLICY
from .quality import ChangeTarget


def build_gsa_patch_prompt(
    original_prompt: str,
    target: ChangeTarget,
    candidates: list[Mapping[str, Any]],
    *,
    max_chars: int = 24_000,
) -> str:
    bounded_candidates = json.dumps(candidates, sort_keys=True, default=str)[:max_chars]
    return (
        "RETURN ONLY ONE VALID JSON PATCH OBJECT. NO PROSE, MARKDOWN, SCORES, OR RANKING.\n"
        "GENERATIVE SELF-AGGREGATION PATCH SYNTHESIS:\n"
        "You are given multiple independent candidate patches for the same coding target.\n"
        "Do NOT choose a winner and do NOT score candidates. Instead, synthesize a new patch that combines compatible strengths and avoids each candidate's weaknesses.\n"
        "If candidates conflict, prefer the smallest patch that satisfies the task contract and can pass execution tests.\n"
        f"Target path: {target.path}; target mode: {target.mode}.\n"
        f"{CODE_EXECUTION_VERDICT_POLICY}\n"
        "Output shape must be exactly: {\"summary\":str,\"files\":list,\"edits\":list,\"insertions\":list}.\n"
        "Use only paths allowed by the original target/task.\n\n"
        f"ORIGINAL TASK/PROMPT CONTEXT:\n{original_prompt[-10_000:]}\n\n"
        f"CANDIDATE PATCHES TO SYNTHESIZE (not rank):\n{bounded_candidates}\n"
    )
