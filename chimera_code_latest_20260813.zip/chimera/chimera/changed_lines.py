"""Local unified-diff range parsing and Python symbol anchoring.

This is a conservative first layer for changed-line retrieval. It has no remote
index, embedding model, or authority over test selection; callers receive exact
ranges and enclosing AST symbols, then decide whether to use the bounded spans
or fall back to broader reads.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass
import pathlib
import re
from typing import Iterable


@dataclass(frozen=True)
class ChangedRange:
    path: str
    start_line: int
    end_line: int
    kind: str  # added | deletion_anchor


@dataclass(frozen=True)
class SymbolAnchor:
    path: str
    name: str
    kind: str
    start_line: int
    end_line: int
    changed_ranges: tuple[ChangedRange, ...]


_FILE = re.compile(r"^\+\+\+\s+(?:b/)?(.+)$")
_HUNK = re.compile(r"^@@\s+-\d+(?:,\d+)?\s+\+(\d+)(?:,(\d+))?\s+@@")


def parse_unified_diff_ranges(diff: str) -> tuple[ChangedRange, ...]:
    current: str | None = None
    rows: list[ChangedRange] = []
    for line in str(diff).splitlines():
        file_match = _FILE.match(line)
        if file_match:
            candidate = file_match.group(1)
            current = None if candidate == "/dev/null" else pathlib.PurePosixPath(candidate).as_posix()
            continue
        hunk_match = _HUNK.match(line)
        if hunk_match and current:
            start = int(hunk_match.group(1))
            count = int(hunk_match.group(2) or "1")
            if count == 0:
                rows.append(ChangedRange(current, start, start, "deletion_anchor"))
            else:
                rows.append(ChangedRange(current, start, start + count - 1, "added"))
    return tuple(rows)


def python_symbol_anchors(path: str, source: str, ranges: Iterable[ChangedRange]) -> tuple[SymbolAnchor, ...]:
    relevant = tuple(item for item in ranges if item.path == pathlib.PurePosixPath(path).as_posix())
    if not relevant:
        return ()
    try:
        tree = ast.parse(source, filename=path)
    except SyntaxError:
        # A syntax-broken candidate is precisely when a model needs the exact
        # changed area most. Do not pretend an AST symbol exists; return one
        # explicit module-level fallback so callers can request the bounded
        # lines or run a repair pass instead of falling back to whole-repo text.
        start = min(item.start_line for item in relevant)
        end = max(item.end_line for item in relevant)
        return (SymbolAnchor(path, "<module>", "syntax_fallback", start, end, relevant),)
    nodes: list[tuple[str, str, int, int]] = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            kind = "class" if isinstance(node, ast.ClassDef) else "async_function" if isinstance(node, ast.AsyncFunctionDef) else "function"
            decorators = [int(getattr(item, "lineno", node.lineno)) for item in getattr(node, "decorator_list", ())]
            start_line = min([int(node.lineno), *decorators])
            nodes.append((node.name, kind, start_line, int(getattr(node, "end_lineno", node.lineno))))
    output: list[SymbolAnchor] = []
    for name, kind, start, end in sorted(nodes, key=lambda row: (row[2], -(row[3] - row[2]))):
        hits = tuple(item for item in relevant if not (item.end_line < start or item.start_line > end))
        if hits:
            output.append(SymbolAnchor(path, name, kind, start, end, hits))
    return tuple(output)
