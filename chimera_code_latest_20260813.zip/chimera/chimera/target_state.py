"""Target-state specifications and bounded homeostatic recovery proposals."""
from __future__ import annotations
import hashlib,pathlib,time
from typing import Any,Callable,Iterable,Literal,Mapping,Optional
from pydantic import BaseModel,ConfigDict,Field,model_validator
from .software_evolution import PatchBundle,TransactionalPatchEvaluator
class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
class StateInvariant(FrozenModel):
    id:str
    kind:Literal["path_exists","path_absent","file_digest","metric_min","metric_max","command"]
    path:Optional[str]=None
    expected:Any=None
    command:Optional[str]=None
    @model_validator(mode="after")
    def shape(self):
        if self.kind in {"path_exists","path_absent","file_digest"} and not self.path:raise ValueError("path invariant requires path")
        if self.kind=="command" and not self.command:raise ValueError("command invariant requires command")
        if self.kind in {"metric_min","metric_max"} and not isinstance(self.expected,(int,float)):raise ValueError("metric invariant requires numeric expected")
        return self
class TargetStateSpec(FrozenModel):
    id:str;mission_id:str;invariants:tuple[StateInvariant,...];mutable_paths:tuple[str,...];version:int=1;bistable_update_allowed:bool=True
class InvariantResult(FrozenModel):
    id:str;passed:bool;observed:Any=None;reason:str;evidence_refs:tuple[str,...]=()
class TargetStateReport(FrozenModel):
    spec_id:str;passed:bool;results:tuple[InvariantResult,...];evaluated_at:float
class TargetStateEvaluator:
    def __init__(self,root:pathlib.Path,workspace,branch:str,*,metric_resolver:Optional[Callable[[StateInvariant],tuple[float,Iterable[str]]]]=None,command_runner:Optional[Callable[[str],tuple[int,Iterable[str]]]]=None):self.root=pathlib.Path(root).resolve();self.workspace=workspace;self.branch=branch;self.metric_resolver=metric_resolver;self.command_runner=command_runner
    def evaluate(self,spec:TargetStateSpec)->TargetStateReport:
        rows=[]
        for inv in spec.invariants:
            try:
                if inv.kind in {"path_exists","path_absent","file_digest"}:
                    try:data=self.workspace.read(self.branch,inv.path);exists=True
                    except FileNotFoundError:data=b"";exists=False
                    if inv.kind=="path_exists":passed=exists;observed=exists
                    elif inv.kind=="path_absent":passed=not exists;observed=exists
                    else:
                        observed="sha256:"+hashlib.sha256(data).hexdigest() if exists else None;passed=observed==inv.expected
                    rows.append(InvariantResult(id=inv.id,passed=passed,observed=observed,reason="exact workspace observation"));continue
                if inv.kind=="command":
                    if self.command_runner is None:raise RuntimeError("command runner unavailable")
                    status,refs=self.command_runner(inv.command);rows.append(InvariantResult(id=inv.id,passed=status==0,observed=status,reason="protected command result",evidence_refs=tuple(refs)));continue
                if self.metric_resolver is None:raise RuntimeError("metric resolver unavailable")
                value,refs=self.metric_resolver(inv);passed=value>=float(inv.expected) if inv.kind=="metric_min" else value<=float(inv.expected);rows.append(InvariantResult(id=inv.id,passed=passed,observed=value,reason="protected metric result",evidence_refs=tuple(refs)))
            except Exception as exc:rows.append(InvariantResult(id=inv.id,passed=False,reason=f"{type(exc).__name__}: {exc}"))
        return TargetStateReport(spec_id=spec.id,passed=all(item.passed for item in rows),results=tuple(rows),evaluated_at=time.time())
class RecoveryAttempt(FrozenModel):
    index:int;bundle_hash:str;passed:bool;insights:tuple[str,...]
class RecoveryResult(FrozenModel):
    status:Literal["already_converged","candidate_found","escalate"]
    initial:TargetStateReport
    candidate:Optional[PatchBundle]=None
    attempts:tuple[RecoveryAttempt,...]=()
    reason:str
class HomeostaticRecovery:
    """Find a verified correction candidate; never mutates/promotes the target itself."""
    def __init__(self,evaluator:TargetStateEvaluator,patch_evaluator:TransactionalPatchEvaluator,max_corrections:int=8):self.evaluator=evaluator;self.patch_evaluator=patch_evaluator;self.max=max(1,min(8,int(max_corrections)))
    def search(self,spec:TargetStateSpec,proposer:Callable[[TargetStateSpec,TargetStateReport,int],PatchBundle])->RecoveryResult:
        initial=self.evaluator.evaluate(spec)
        if initial.passed:return RecoveryResult(status="already_converged",initial=initial,reason="target state already holds")
        attempts=[];allowed=set(spec.mutable_paths)
        for index in range(self.max):
            bundle=proposer(spec,initial,index)
            touched={item.path for item in bundle.operations}
            if not touched<=allowed:
                attempts.append(RecoveryAttempt(index=index,bundle_hash="rejected-scope",passed=False,insights=(f"outside TSS mutable scope: {sorted(touched-allowed)}",)));continue
            outcome=self.patch_evaluator.evaluate(bundle.model_dump_json(),index)
            operations={item.path:item for item in bundle.operations};predicates=[]
            for inv in spec.invariants:
                if inv.kind in {"path_exists","path_absent","file_digest"}:
                    operation=operations.get(inv.path)
                    if operation is None:
                        current=next((item for item in initial.results if item.id==inv.id),None);predicates.append(bool(current and current.passed));continue
                    exists=operation.op=="write"
                    if inv.kind=="path_exists":predicates.append(exists)
                    elif inv.kind=="path_absent":predicates.append(not exists)
                    else:predicates.append(exists and "sha256:"+hashlib.sha256((operation.content or "").encode()).hexdigest()==inv.expected)
                elif inv.kind=="command":predicates.append(outcome.passed)
                else:
                    observed=outcome.metrics.get(inv.id);predicates.append(observed is not None and (observed>=float(inv.expected) if inv.kind=="metric_min" else observed<=float(inv.expected)))
            converged=outcome.passed and all(predicates)
            digest="sha256:"+hashlib.sha256(bundle.model_dump_json().encode()).hexdigest();attempts.append(RecoveryAttempt(index=index,bundle_hash=digest,passed=converged,insights=outcome.insights))
            if converged:return RecoveryResult(status="candidate_found",initial=initial,candidate=bundle,attempts=tuple(attempts),reason="candidate passed disposable protected evaluation and typed target-state predicates; promotion remains separately gated")
        return RecoveryResult(status="escalate",initial=initial,attempts=tuple(attempts),reason="bounded local correction budget exhausted")
