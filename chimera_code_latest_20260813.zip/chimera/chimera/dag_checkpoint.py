"""Optional, CAS-backed checkpoints for durable DAG execution.

A completed node is reusable only when the caller explicitly resumes the same
plan identity.  Callers can additionally supply a stable workspace/branch input
root as ``scope``; that opaque value is hashed and checked before reuse. Results
are content-addressed and checkpoint metadata is atomically replaced. This is
deliberately an execution checkpoint, not a cross-task semantic cache: final
integration verification still runs after resume.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
import pathlib
import time
from typing import Any, Mapping

from .artifacts import ContentAddressedArtifactStore


@dataclass(frozen=True)
class CheckpointNode:
    result_ref: str
    completed_at: float


class DAGCheckpointStore:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.dir = self.root / ".chimera" / "dag-checkpoints"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.artifacts = ContentAddressedArtifactStore(self.root)

    @staticmethod
    def plan_identity(plan: Any) -> str:
        # Node inputs receive dependency artifacts during execution. Only stable
        # task-contract fields participate in the plan identity.
        rows = []
        for node in plan.nodes:
            inputs = dict(node.inputs) if isinstance(node.inputs, Mapping) else {}
            # ``propagate`` appends dependency outputs directly to node.inputs
            # during execution. Only plan-authored contract fields may define
            # checkpoint identity; propagated facts are results, not a new plan.
            stable_inputs = {
                key: inputs[key] for key in ("atom_spec", "root_task", "task_slice", "hierarchy_id")
                if key in inputs
            }
            rows.append({
                "id": node.id, "question": node.question, "agent_type": node.agent_type,
                "dependencies": list(node.dependencies), "criteria": node.verification_criteria,
                "effect": node.effect, "inputs": stable_inputs, "outputs": node.outputs,
            })
        payload = {"plan_id": plan.id, "task": plan.task, "nodes": rows}
        return "sha256:" + hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()

    @staticmethod
    def _key(run_key: str) -> str:
        return hashlib.sha256(run_key.encode()).hexdigest()

    @staticmethod
    def scope_identity(scope: str | None) -> str | None:
        """Return a non-secret binding for an explicitly supplied input root.

        A caller can bind checkpoint reuse to an exact branch/workspace input
        root (or another stable contract identity) without persisting that raw
        value.  ``None`` preserves legacy opt-in checkpoint behavior; it does
        not claim workspace validation happened.
        """
        if scope is None:
            return None
        value = str(scope)
        if not value:
            raise ValueError("checkpoint scope must be non-empty when supplied")
        return "sha256:" + hashlib.sha256(value.encode()).hexdigest()

    def _path(self, run_key: str) -> pathlib.Path:
        return self.dir / f"{self._key(run_key)}.json"

    def _read(self, run_key: str) -> dict[str, Any] | None:
        path = self._path(run_key)
        try:
            value = json.loads(path.read_text())
            return value if isinstance(value, dict) else None
        except (OSError, json.JSONDecodeError):
            return None

    def _write(self, run_key: str, row: dict[str, Any]) -> None:
        path = self._path(run_key)
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps(row, sort_keys=True, indent=2, default=str) + "\n")
        os.replace(temp, path)

    @staticmethod
    def normalize_resume_identity(identity: str | None) -> str | None:
        if identity is None:
            return None
        value = str(identity)
        if not value.startswith("sha256:") or len(value.removeprefix("sha256:")) != 64:
            raise ValueError("resume identity must use sha256:<64 hex>")
        return value.lower()

    def assert_scope_compatible(self, run_key: str, plan: Any, *, scope: str | None = None) -> None:
        """Fail before execution when an explicitly bound checkpoint is stale.

        This is intentionally opt-in so legacy callers retain their prior
        semantics.  New durable callers should pass a stable workspace/branch
        input root, not merely a human-readable run label.
        """
        if scope is None:
            return
        row = self._read(run_key)
        if not row:
            return
        if row.get("plan_identity") != self.plan_identity(plan):
            raise ValueError("checkpoint key is already bound to a different plan identity")
        expected = self.scope_identity(scope)
        if row.get("scope_identity") != expected:
            raise ValueError("checkpoint key is already bound to a different scope identity")

    def assert_resume_identity_compatible(self, run_key: str, plan: Any, *, resume_identity: str | None = None) -> None:
        """Reject an explicitly bound checkpoint before any solver side effect."""
        if resume_identity is None:
            return
        row = self._read(run_key)
        if not row:
            return
        if row.get("plan_identity") != self.plan_identity(plan):
            raise ValueError("checkpoint key is already bound to a different plan identity")
        expected = self.normalize_resume_identity(resume_identity)
        if row.get("resume_identity") != expected:
            raise ValueError("checkpoint key is already bound to a different resume identity")

    def restore(self, run_key: str, plan: Any, *, scope: str | None = None, resume_identity: str | None = None) -> dict[str, dict[str, Any]]:
        row = self._read(run_key)
        if not row or row.get("plan_identity") != self.plan_identity(plan):
            return {}
        # A scope-bound checkpoint is never silently reused by an unscoped
        # caller, and vice versa.  Old checkpoints without scope continue to
        # support old callers but cannot claim the stronger binding.
        if row.get("scope_identity") != self.scope_identity(scope):
            return {}
        if row.get("resume_identity") != self.normalize_resume_identity(resume_identity):
            return {}
        restored: dict[str, dict[str, Any]] = {}
        for node_id, raw in (row.get("completed", {}) or {}).items():
            ref = raw.get("result_ref") if isinstance(raw, Mapping) else None
            if not isinstance(ref, str) or not ref.startswith("sha256:"):
                continue
            try:
                value = json.loads(self.artifacts.get(ref).decode())
            except Exception:
                continue
            if isinstance(value, dict) and value.get("verification", {}).get("status") == "pass":
                restored[str(node_id)] = value
        return restored

    def record(
        self,
        run_key: str,
        plan: Any,
        node_id: str,
        result: Mapping[str, Any],
        *,
        scope: str | None = None,
        resume_identity: str | None = None,
    ) -> str:
        scope_identity = self.scope_identity(scope)
        normalized_identity = self.normalize_resume_identity(resume_identity)
        row = self._read(run_key) or {
            "run_key_hash": self._key(run_key), "plan_identity": self.plan_identity(plan),
            "scope_identity": scope_identity, "resume_identity": normalized_identity,
            "created_at": time.time(), "completed": {},
        }
        if row.get("plan_identity") != self.plan_identity(plan):
            raise ValueError("checkpoint key is already bound to a different plan identity")
        if row.get("scope_identity") != scope_identity:
            raise ValueError("checkpoint key is already bound to a different scope identity")
        if row.get("resume_identity") != normalized_identity:
            raise ValueError("checkpoint key is already bound to a different resume identity")
        ref = self.artifacts.put(
            json.dumps(dict(result), sort_keys=True, separators=(",", ":"), default=str),
            media_type="application/vnd.chimera.dag-node-result+json",
            provenance={"run_key_hash": self._key(run_key), "plan_id": plan.id, "node": node_id},
        )
        row.setdefault("completed", {})[node_id] = {"result_ref": ref.digest, "completed_at": time.time()}
        row["updated_at"] = time.time()
        self._write(run_key, row)
        return ref.digest
