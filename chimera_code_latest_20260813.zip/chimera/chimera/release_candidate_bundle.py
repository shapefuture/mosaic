"""Release candidate evidence bundle for Chimera."""
from __future__ import annotations

import base64
import hashlib
import json
import pathlib
import platform
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from typing import Any

from .gate_dashboard import GateDashboardBuilder
from .gate_history import GateHistoryLedger
from .cloud_scale_readiness import CloudScaleReadinessPlanner
from .architecture_ratchet import ArchitectureRatchet
from .token_error_tax import TokenErrorTaxAnalyzer
from .context_evidence import ContextSigner


@dataclass(frozen=True)
class CommandSummary:
    command: str
    status: str
    returncode: int | None
    stdout_tail: str
    stderr_tail: str
    elapsed_ms: float


class ReleaseCandidateBundleBuilder:
    """Collect non-secret release evidence into one portable bundle."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def build(self, *, run_tests: bool = False, test_command: str = "python -m pytest -q", sign: bool = False) -> dict[str, Any]:
        started = time.perf_counter()
        test_summary = self._run(test_command) if run_tests else CommandSummary(test_command, "skipped", None, "", "", 0.0)
        bundle = {
            "schema_version": "chimera.release-candidate-bundle.v1",
            "root": str(self.root),
            "created_at": time.time(),
            "host": {
                "python": sys.version.split()[0],
                "platform": platform.platform(),
            },
            "gate_dashboard": GateDashboardBuilder(self.root).build(recent=100),
            "gate_history": GateHistoryLedger(self.root).trends(limit=200),
            "cloud_scale_readiness": CloudScaleReadinessPlanner(self.root).plan(agents=1000, tenants=100, mode="self-hosted"),
            "architecture_ratchet": ArchitectureRatchet(self.root).run(),
            "token_error_tax": TokenErrorTaxAnalyzer(self.root).analyze(),
            "artifact_digests": self._artifact_digests(),
            "deployment_blueprint_digests": self._deployment_blueprint_digests(),
            "full_suite": asdict(test_summary),
            "secret_values_recorded": False,
            "promotion_allowed": False,
            "release_rule": "Release requires human/operator approval plus review of this bundle, deployment-image smoke, and relevant live endpoint receipts.",
            "duration_ms": round((time.perf_counter() - started) * 1000, 3),
        }
        bundle["bundle_hash"] = self._hash_payload(bundle)
        if sign:
            signer = ContextSigner.from_environment_or_ephemeral()
            payload = self._canonical({k: v for k, v in bundle.items() if k != "signature"})
            bundle["signature"] = {
                "algorithm": "ed25519",
                "key_id": signer.key_id,
                "public_key": signer.public_key,
                "signature": signer.sign(payload),
                "raw_private_key_recorded": False,
            }
        return bundle

    def write(self, path: pathlib.Path, *, run_tests: bool = False, test_command: str = "python -m pytest -q", sign: bool = False) -> dict[str, Any]:
        value = self.build(run_tests=run_tests, test_command=test_command, sign=sign)
        path = pathlib.Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
        return value


    def _artifact_digests(self) -> list[dict[str, Any]]:
        out = []
        artifact_dir = self.root / "artifacts"
        if not artifact_dir.exists():
            return out
        for path in sorted(artifact_dir.glob("*.json"))[-100:]:
            try:
                raw = path.read_bytes()
            except OSError:
                continue
            out.append({"path": str(path.relative_to(self.root)), "sha256": "sha256:" + hashlib.sha256(raw).hexdigest(), "bytes": len(raw)})
        return out

    def _deployment_blueprint_digests(self) -> list[dict[str, Any]]:
        out = []
        artifact_dir = self.root / "artifacts"
        if not artifact_dir.exists():
            return out
        for path in sorted(artifact_dir.glob("deployment-*/*")):
            if not path.is_file():
                continue
            raw = path.read_bytes()
            out.append({"path": str(path.relative_to(self.root)), "sha256": "sha256:" + hashlib.sha256(raw).hexdigest(), "bytes": len(raw)})
        return out

    @classmethod
    def _canonical(cls, value: dict[str, Any]) -> bytes:
        return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()

    @classmethod
    def _hash_payload(cls, value: dict[str, Any]) -> str:
        return "sha256:" + hashlib.sha256(cls._canonical(value)).hexdigest()

    def _run(self, command: str) -> CommandSummary:
        import shlex
        started = time.perf_counter()
        try:
            completed = subprocess.run(
                shlex.split(command), cwd=self.root, text=True, capture_output=True,
                timeout=1800, check=False,
            )
            return CommandSummary(
                command=command,
                status="passed" if completed.returncode == 0 else "failed",
                returncode=completed.returncode,
                stdout_tail=completed.stdout[-4000:],
                stderr_tail=completed.stderr[-4000:],
                elapsed_ms=round((time.perf_counter() - started) * 1000, 3),
            )
        except Exception as exc:
            return CommandSummary(command, "error", None, "", f"{type(exc).__name__}: {str(exc)[:500]}", round((time.perf_counter() - started) * 1000, 3))
