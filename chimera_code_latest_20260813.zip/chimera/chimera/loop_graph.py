"""Result-aware loop guards and static workflow graph audit."""
from __future__ import annotations
import hashlib,json
from collections import deque
from dataclasses import dataclass
from typing import Any,Iterable

@dataclass(frozen=True)
class ProgressLoopObservation:
 fingerprint:str;repeats:int;ping_pong:bool;halt:bool;reason:str
class ProgressLoopGuard:
 def __init__(self,repeat_limit:int=3,window:int=8):self.repeat_limit=max(2,repeat_limit);self.rows=deque(maxlen=max(4,window))
 @staticmethod
 def _fp(calls:Iterable[dict],results:Iterable[dict])->str:
  payload=[]
  for call,result in zip(calls,results):
   payload.append({'tool':call.get('name'),'args':call.get('arguments',{}),'ok':result.get('ok'),'result':hashlib.sha256(json.dumps({k:v for k,v in result.items() if k not in {'content','artifact_ref'}},sort_keys=True,default=str).encode()).hexdigest()[:16]})
  return 'sha256:'+hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
 def observe(self,calls:Iterable[dict],results:Iterable[dict])->ProgressLoopObservation:
  fp=self._fp(calls,results);self.rows.append(fp);repeats=sum(1 for x in self.rows if x==fp);ping=len(self.rows)>=4 and list(self.rows)[-4:]==[self.rows[-2],self.rows[-1],self.rows[-2],self.rows[-1]];halt=repeats>=self.repeat_limit or ping
  return ProgressLoopObservation(fp,repeats,ping,halt,'repeated action/result state' if repeats>=self.repeat_limit else 'ping-pong action/result cycle' if ping else 'progress observed')

@dataclass(frozen=True)
class WorkflowAudit:
 cycles:tuple[tuple[str,...],...];unreachable:tuple[str,...];bounded:bool

def audit_workflow(nodes:dict[str,Iterable[str]],entry:Iterable[str],terminal:Iterable[str],bounds:dict[str,Any])->WorkflowAudit:
 # Tarjan SCC: every cyclic SCC needs finite retry/turn/time budget.
 index=0;stack=[];on=set();idx={};low={};cycles=[]
 def visit(v):
  nonlocal index
  idx[v]=low[v]=index;index+=1;stack.append(v);on.add(v)
  for w in nodes.get(v,()):
   if w not in idx:visit(w);low[v]=min(low[v],low[w])
   elif w in on:low[v]=min(low[v],idx[w])
  if low[v]==idx[v]:
   comp=[]
   while True:
    w=stack.pop();on.remove(w);comp.append(w)
    if w==v:break
   if len(comp)>1 or v in set(nodes.get(v,())):cycles.append(tuple(sorted(comp)))
 for v in nodes:
  if v not in idx:visit(v)
 seen=set(entry);front=list(entry)
 while front:
  v=front.pop()
  for w in nodes.get(v,()):
   if w not in seen:seen.add(w);front.append(w)
 bounded=all(isinstance(bounds.get(k),(int,float)) and bounds[k]>0 for k in ('max_turns','max_tokens','max_seconds'))
 return WorkflowAudit(tuple(cycles),tuple(sorted(set(nodes)-seen)),bounded)
