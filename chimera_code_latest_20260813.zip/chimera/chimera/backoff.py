"""Typed retry/backoff taxonomy with user-action reasons."""
from __future__ import annotations
import random,re
from dataclasses import dataclass, asdict
from email.utils import parsedate_to_datetime
from datetime import datetime,timezone

@dataclass(frozen=True)
class RetryDecision:
    category:str; retryable:bool; delay_seconds:float; reason:str; suggested_action:str
    def as_dict(self): return asdict(self)

def retry_after_seconds(value,now=None):
 if value is None:return None
 try:return max(0,float(value))
 except (TypeError,ValueError):
  try:
   dt=parsedate_to_datetime(str(value));now=now or datetime.now(timezone.utc);return max(0,(dt-now).total_seconds())
  except Exception:return None

def classify_error(*, status_code:int|None=None, body:str="", transport_error:bool=False, validation_error:bool=False)->str:
 text=(body or "").lower()
 if validation_error or status_code in {400,422}: return "validation"
 if status_code in {401,403} or any(w in text for w in ("invalid api key","unauthorized","forbidden")): return "auth"
 if status_code in {402} or any(w in text for w in ("quota","billing","insufficient credits","monthly quota")): return "quota"
 if status_code==429 or "rate limit" in text or "free-models-per-day" in text: return "rate_limit"
 if transport_error or status_code in {408,409}: return "transient_network"
 if status_code and status_code>=500: return "backend"
 return "unknown"

def retry_decision(attempt:int,*,status_code:int|None=None,body:str="",retry_after=None,transport_error:bool=False,validation_error:bool=False,rng=None)->RetryDecision:
 cat=classify_error(status_code=status_code,body=body,transport_error=transport_error,validation_error=validation_error)
 if cat in {"auth","quota"}: return RetryDecision(cat,False,0.0,f"non-retryable {cat}","fix credentials/billing or wait for quota reset")
 if cat=="validation": return RetryDecision(cat, attempt<2, min(2.0,0.5*(attempt+1)), "schema/request validation failure", "repair request shape; do not blind retry")
 if cat=="rate_limit":
  parsed=retry_after_seconds(retry_after); delay=parsed if parsed is not None else min(300,60+random.random()*30)
  return RetryDecision(cat, True, float(delay), "provider rate limit", "respect Retry-After/cooldown window")
 if cat in {"backend","transient_network"}: return RetryDecision(cat, attempt<4, backoff_seconds(attempt, rate_limited=False, rng=rng), "transient provider/network failure", "retry with bounded exponential backoff")
 return RetryDecision(cat, attempt<2, backoff_seconds(attempt, rng=rng), "unknown retryable error class", "retry once, then surface exact failure")

def backoff_seconds(attempt:int,*,rate_limited:bool=False,retry_after=None,base:float=2,max_regular:float=30,max_rate:float=300,jitter:float=.2,rng=None):
 parsed=retry_after_seconds(retry_after)
 if parsed is not None:return min(max_rate,parsed)
 cap=max_rate if rate_limited else max_regular;delay=min(cap,(30 if rate_limited else base)*(2**max(0,attempt-1)))
 rand=rng or random.random;factor=(rand()*2-1)*jitter;return max(0,delay*(1+factor))
