"""Non-blocking local telemetry sink and explicit outbox exporter."""

from __future__ import annotations

import json
import os
import pathlib
import time
import uuid
from collections.abc import Mapping
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class EventSinkResult:
    ok: bool
    sink: str
    error: str | None = None
    queued: bool = False

    def as_dict(self):
        return asdict(self)


class EventSink:
    """Critical-path writes are local only; remote delivery uses the exporter."""

    def __init__(self, root: pathlib.Path, *, max_outbox_bytes: int = 10_000_000):
        self.root = pathlib.Path(root).resolve()
        self.kind = os.environ.get("CHIMERA_EVENT_SINK", "file").lower()
        self.target = os.environ.get("CHIMERA_EVENT_SINK_TARGET", "")
        self.path = self.root / ".chimera" / "events.jsonl"
        self.outbox = self.root / ".chimera" / "telemetry-outbox.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.max_outbox_bytes = max(1_024, int(max_outbox_bytes))

    @staticmethod
    def _append(
        path: pathlib.Path,
        row: Mapping[str, Any],
        *,
        max_bytes: int | None = None,
    ) -> None:
        payload = json.dumps(dict(row), sort_keys=True, default=str) + "\n"
        encoded_bytes = len(payload.encode("utf-8"))
        with path.open("a", encoding="utf-8") as handle:
            try:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            except ImportError:  # pragma: no cover - Windows capability-negative path
                fcntl = None
            try:
                if max_bytes is not None:
                    current_bytes = os.fstat(handle.fileno()).st_size
                    if current_bytes + encoded_bytes > max_bytes:
                        raise BufferError("telemetry outbox capacity exhausted")
                handle.write(payload)
                handle.flush()
            finally:
                if fcntl is not None:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    def emit(self, kind: str, data: dict[str, Any]) -> EventSinkResult:
        row = {
            "id": "event:" + uuid.uuid4().hex,
            "ts": time.time(),
            "kind": str(kind),
            "data": dict(data),
        }
        try:
            if self.kind == "file":
                self._append(self.path, row)
                return EventSinkResult(True, "file")
            if self.kind == "http":
                if os.environ.get("CHIMERA_EVENT_SINK_ALLOW_HTTP") != "1":
                    return EventSinkResult(
                        False,
                        "http",
                        "HTTP event egress requires CHIMERA_EVENT_SINK_ALLOW_HTTP=1",
                    )
                if not self.target:
                    return EventSinkResult(False, "http", "missing HTTP event target")
                self._append(
                    self.outbox,
                    {**row, "target": self.target, "attempts": 0},
                    max_bytes=self.max_outbox_bytes,
                )
                return EventSinkResult(True, "http-outbox", queued=True)
            return EventSinkResult(False, self.kind, "unsupported or missing target")
        except Exception as exc:  # noqa: BLE001 - telemetry cannot mutate task success
            return EventSinkResult(
                False,
                self.kind,
                f"{type(exc).__name__}: {exc}"[:300],
            )


class TelemetryOutboxExporter:
    """Explicit off-critical-path exporter with common egress authorization."""

    def __init__(self, root: pathlib.Path, *, egress, timeout_seconds: float = 5.0):
        self.root = pathlib.Path(root).resolve()
        self.path = self.root / ".chimera" / "telemetry-outbox.jsonl"
        self.egress = egress
        self.timeout_seconds = max(0.1, float(timeout_seconds))

    def drain(self, *, limit: int = 100) -> dict[str, int]:
        if not self.path.exists():
            return {"delivered": 0, "failed": 0, "remaining": 0}
        rows = [
            json.loads(line)
            for line in self.path.read_text().splitlines()
            if line.strip()
        ]
        batch, remaining = (
            rows[: max(1, min(1_000, int(limit)))],
            rows[max(1, min(1_000, int(limit))) :],
        )
        delivered = 0
        failed = []
        import httpx

        with httpx.Client(
            timeout=self.timeout_seconds,
            follow_redirects=False,
            trust_env=False,
        ) as client:
            for row in batch:
                target = str(row.pop("target", ""))
                try:
                    self.egress.authorize(target)
                    response = client.post(target, json=row)
                    if not response.is_success:
                        raise RuntimeError(f"HTTP {response.status_code}")
                    delivered += 1
                except Exception as exc:  # noqa: BLE001 - failed delivery stays queued
                    row["target"] = target
                    row["attempts"] = int(row.get("attempts", 0)) + 1
                    row["last_error"] = type(exc).__name__
                    failed.append(row)
        pending = [*failed, *remaining]
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(
            "".join(
                json.dumps(row, sort_keys=True, default=str) + "\n" for row in pending
            ),
            encoding="utf-8",
        )
        os.replace(temporary, self.path)
        return {
            "delivered": delivered,
            "failed": len(failed),
            "remaining": len(pending),
        }
