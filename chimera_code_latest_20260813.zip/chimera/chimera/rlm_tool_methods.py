"""Tool protocol helper methods for RLMRuntime."""
from __future__ import annotations

import hashlib
import json
import pathlib
import re
from typing import Any, Dict, List, Mapping, Optional


class RLMToolMixin:
    @staticmethod
    def _tool_call_blocks(text: str) -> List[str]:
        """Recover complete *or truncated* textual tool-call blocks.

        Tool-capable providers should use native function calls, but textual
        fallbacks still matter for providers that only emit prose.  Some models
        omit a closing ``</tool_call>`` tag while otherwise emitting a complete
        JSON object.  Treat the next opening tag (or end of message) as the
        boundary; this is safe because the result remains subject to the closed
        action compiler before it can affect the workspace.
        """
        marker = re.compile(r"<tool_call>", re.IGNORECASE)
        close_marker = re.compile(r"</tool_call>", re.IGNORECASE)
        starts = list(marker.finditer(text or ""))
        blocks: List[str] = []
        for index, match in enumerate(starts):
            next_start = starts[index + 1].start() if index + 1 < len(starts) else len(text)
            close = close_marker.search(text, match.end())
            end = close.start() if close is not None and close.start() < next_start else next_start
            block = text[match.end():end].strip()
            if block:
                blocks.append(block)
        return blocks

    @staticmethod
    def _literal_tool_arguments(name: str, body: str) -> Optional[Dict[str, Any]]:
        """Parse a conservative legacy ``tool(\"argument\")`` fallback.

        This is deliberately an AST *literal* parser rather than ``eval``.  It
        only accepts positional/keyword scalar literals and maps positional
        values to the existing closed operation schemas.
        """
        import ast
        positional_names = {
            "read": ("path", "start", "end"), "read_file": ("path", "start", "end"),
            "fs.read": ("path", "start", "end"), "list": ("pattern",),
            "list_files": ("pattern",), "glob": ("pattern",),
            "graph": ("query",), "graph_search": ("query",),
            "search": ("query",), "graph_query": ("query",),
            "artifact": ("digest", "start", "end"), "artifact_read": ("digest", "start", "end"),
            "cas.read": ("digest", "start", "end"), "artifact_search": ("digest", "query", "max_lines"),
            "cas.search": ("digest", "query", "max_lines"), "shell": ("command",),
            "bash": ("command",), "exec": ("command",), "shell_read": ("command",),
            "write": ("path", "content"), "write_file": ("path", "content"),
            "fs.write": ("path", "content"), "edit": ("path", "old_text", "new_text"),
            "edit_file": ("path", "old_text", "new_text"), "fs.edit": ("path", "old_text", "new_text"),
        }
        try:
            expression = ast.parse(f"_tool({body})", mode="eval").body
        except SyntaxError:
            return None
        if not isinstance(expression, ast.Call) or not isinstance(expression.func, ast.Name):
            return None
        names = positional_names.get(name.lower())
        if names is None or len(expression.args) > len(names):
            return None
        arguments: Dict[str, Any] = {}
        try:
            for argument_name, node in zip(names, expression.args):
                value = ast.literal_eval(node)
                if not isinstance(value, (str, int, float, bool, type(None))):
                    return None
                arguments[argument_name] = value
            for keyword in expression.keywords:
                if keyword.arg is None:
                    return None
                value = ast.literal_eval(keyword.value)
                if not isinstance(value, (str, int, float, bool, type(None))):
                    return None
                arguments[keyword.arg] = value
        except (ValueError, TypeError):
            return None
        return arguments

    @classmethod
    def _parse_tool_calls(cls, text: str) -> List[Dict[str, Any]]:
        """Parse native-compatible text fallbacks without evaluating model text.

        Accepted forms are a JSON function envelope, historical XML-like
        argument tags, and a narrow literal-only ``name(\"arg\")`` form.  The
        latter two are compatibility parsing only; all parsed calls still pass
        through ``SingleToolSurface``/``ToolPlanCompiler`` and capability checks.
        """
        calls: List[Dict[str, Any]] = []
        decoder = json.JSONDecoder()
        for block in cls._tool_call_blocks(text):
            value: Any = None
            for start in [match.start() for match in re.finditer(r"\{", block)]:
                try:
                    candidate, _ = decoder.raw_decode(block[start:])
                except json.JSONDecodeError:
                    continue
                if isinstance(candidate, dict) and isinstance(candidate.get("name"), str):
                    value = candidate
                    break
            if isinstance(value, dict):
                calls.append(dict(value))
                continue
            named = re.match(r"([\w.\-]+)\s*(.*)", block, re.DOTALL)
            if not named:
                continue
            name, body = named.group(1), named.group(2).strip()
            keys = re.findall(r"<arg_key>(.*?)</arg_key>", body, re.DOTALL | re.IGNORECASE)
            values = re.findall(r"<arg_value>(.*?)</arg_value>", body, re.DOTALL | re.IGNORECASE)
            if keys:
                calls.append({"name": name, "arguments": {
                    key.strip(): value for key, value in zip(keys, values)
                }})
                continue
            arguments = cls._literal_tool_arguments(name, body[1:-1]) if body.startswith("(") and body.endswith(")") else None
            if arguments is not None:
                calls.append({"name": name, "arguments": arguments})
        return calls

    @staticmethod
    def _unwrap_provider_json(value: Any, depth: int = 0) -> Any:
        """Tolerate provider double-encoded tool arguments without evaluating code."""
        if depth >= 4:
            return value
        if isinstance(value, str) and value.lstrip().startswith(("{", "[", "\"")):
            try:
                return RLMToolMixin._unwrap_provider_json(json.loads(value), depth + 1)
            except json.JSONDecodeError:
                return value
        if isinstance(value, list):
            return [RLMToolMixin._unwrap_provider_json(item, depth + 1) for item in value]
        if isinstance(value, Mapping):
            return {str(key): RLMToolMixin._unwrap_provider_json(item, depth + 1) for key, item in value.items()}
        return value

    @staticmethod
    def _native_tool_calls(value: Any) -> List[Dict[str, Any]]:
        """Normalize OpenAI/OpenRouter function-call envelopes to internal calls."""
        if not isinstance(value, list):
            return []
        calls: List[Dict[str, Any]] = []
        for item in value:
            if not isinstance(item, Mapping):
                continue
            function = item.get("function") if isinstance(item.get("function"), Mapping) else item
            name = function.get("name") if isinstance(function, Mapping) else None
            raw_arguments = function.get("arguments", {}) if isinstance(function, Mapping) else {}
            raw_arguments = RLMToolMixin._unwrap_provider_json(raw_arguments)
            if isinstance(name, str) and isinstance(raw_arguments, Mapping):
                # OpenAI-compatible providers reject dots in function names;
                # keep the public/textual names while using transport-safe
                # aliases on the wire.
                internal_name = {"chimera_run": "chimera.run", "chimera_py": "chimera.py"}.get(name, name)
                calls.append({"name": internal_name, "arguments": dict(raw_arguments)})
        return calls

    def _native_tool_definitions(
        self, allow_write: bool, *, phase: str = "observe", schema_profile: str = "strict"
    ) -> List[Dict[str, Any]]:
        """Return one OpenAI-compatible schema for the selected native phase.

        ``observe`` exposes only read-oriented authority.  ``submit_patch``
        serializes a candidate patch as data through the *same* wrapper tool
        name for the single and kernel surfaces.  The patch is not executed by
        the tool: it is still admitted later by ``_apply_patch_payload`` and
        the transactional/capability gates.  This avoids making fragile prose
        JSON the final authority boundary.
        """
        if phase not in {"observe", "submit_patch"}:
            raise ValueError(f"unknown native tool phase: {phase}")
        if schema_profile not in {"strict", "compact"}:
            raise ValueError(f"unknown native schema profile: {schema_profile}")

        def function(name: str, description: str, properties: Dict[str, Any], required: List[str] | None = None) -> Dict[str, Any]:
            return {"type": "function", "function": {
                "name": name, "description": description,
                "parameters": {"type": "object", "properties": properties,
                               "required": required or [], "additionalProperties": False},
            }}

        string = {"type": "string"}
        integer = {"type": "integer", "minimum": 0}
        patch = {
            "type": "object", "description": "Candidate transactional patch.",
            "properties": {
                "summary": string,
                "files": {"type": "array", "items": {"type": "object", "properties": {
                    "path": string, "content": string,
                }, "required": ["path", "content"], "additionalProperties": False}},
                "edits": {"type": "array", "items": {"type": "object", "properties": {
                    "path": string, "find": string, "replace": string,
                }, "required": ["path", "find", "replace"], "additionalProperties": False}},
                "insertions": {"type": "array", "items": {"type": "object", "properties": {
                    "path": string, "anchor": string, "position": {"type": "string", "enum": ["before", "after"]},
                    "content": string,
                }, "required": ["path", "anchor", "content"], "additionalProperties": False}},
            },
            "required": ["summary", "files", "edits", "insertions"], "additionalProperties": False,
        }
        phase_enum = {"type": "string", "enum": [phase]}

        if self.config.planner.tool_surface == "kernel":
            if phase == "submit_patch":
                return [function(
                    "chimera_py", "Submit a candidate patch after read observations. This is data only; "
                    "the harness validates and applies it transactionally.",
                    {"phase": phase_enum, "patch": patch}, ["phase", "patch"],
                )]
            return [function(
                "chimera_py", "Run one bounded, read-only Chimera kernel program. "
                "Use read, list_files, graph, and artifact only; combine independent reads in this one program.",
                {"phase": phase_enum, "code": string}, ["phase", "code"],
            )]

        if self.config.planner.tool_surface == "single":
            if phase == "submit_patch":
                return [function(
                    "chimera_run", "Submit a candidate patch after typed observations. This is data only; "
                    "the harness validates and applies it transactionally.",
                    {"phase": phase_enum, "patch": patch}, ["phase", "patch"],
                )]
            ops = ["R", "L", "G", "A", "Q", "S"] + (["W", "E"] if allow_write else [])
            action = (
                {"type": "object"}
                if schema_profile == "compact"
                else {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "pattern": "^[A-Za-z][A-Za-z0-9_-]{0,31}$"},
                        "op": {"type": "string", "enum": ops},
                        "args": {"type": "object"},
                        "after": {"type": "array", "items": {"type": "string"}},
                    },
                    "required": ["id", "op", "args"], "additionalProperties": False,
                }
            )
            description = (
                "Execute one bounded declarative DAG of typed Chimera operations. "
                "Batch independent reads in actions; do not use scripts or opaque code."
                if schema_profile == "strict" else
                "Execute one bounded Chimera action DAG. Action objects are validated by the harness."
            )
            return [function(
                "chimera_run", description,
                {"phase": phase_enum,
                 "actions": {"type": "array", "minItems": 1,
                             "maxItems": self.config.planner.max_actions_per_run, "items": action},
                 "outputs": {"type": "array", "items": {"type": "string"}}},
                ["phase", "actions"],
            )]

        # Legacy has multiple top-level tools and retains its normal final JSON
        # path.  The phase/profile parameters therefore only affect the two
        # one-tool surfaces above.
        tools = [
            function("read_file", "Read a workspace-relative text file.",
                     {"path": string, "start": integer, "end": integer,
                      "mode": {"type": "string", "enum": ["auto", "source", "structure"]}}, ["path"]),
            function("list_files", "List workspace-relative files matching a glob.", {"pattern": string}),
            function("graph_query", "Search the repository code graph.", {"query": string}, ["query"]),
            function("artifact_read", "Read a slice of a content-addressed artifact.",
                     {"digest": string, "start": integer, "end": integer}, ["digest"]),
            function("artifact_search", "Search a content-addressed text artifact without replaying it in full.",
                     {"digest": string, "query": string, "max_lines": integer}, ["digest", "query"]),
        ]
        if allow_write:
            tools.extend([
                function("write_file", "Write a complete workspace-relative file.", {"path": string, "content": string}, ["path", "content"]),
                function("edit_file", "Apply one exact text replacement in a workspace-relative file.",
                         {"path": string, "old_text": string, "new_text": string}, ["path", "old_text", "new_text"]),
            ])
        return tools

    @staticmethod
    def _native_patch_submission(calls: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Extract a one-tool native patch submission without executing it."""
        if len(calls) != 1:
            return None
        call = calls[0]
        if str(call.get("name", "")) not in {"chimera.run", "chimera.py"}:
            return None
        arguments = call.get("arguments")
        if not isinstance(arguments, Mapping) or arguments.get("phase") != "submit_patch":
            return None
        patch = arguments.get("patch")
        if not isinstance(patch, Mapping):
            return None
        # Keep the exact object shape as model data; its file/edit content
        # remains subject to _apply_patch_payload's individual validation.
        return dict(patch)

    @staticmethod
    def _coalesce_kernel_calls(calls: List[Dict[str, Any]]) -> tuple[List[Dict[str, Any]], bool]:
        """Canonicalize repeated safe kernel blocks into the one permitted call."""
        if len(calls) <= 1 or not all(str(call.get("name", "")).lower() == "chimera.py" for call in calls):
            return calls, False
        snippets: List[str] = []
        for call in calls:
            arguments = call.get("arguments")
            if not isinstance(arguments, Mapping) or set(arguments) != {"code"} or not isinstance(arguments.get("code"), str):
                return calls, False
            snippets.append(arguments["code"])
        return [{"name": "chimera.py", "arguments": {"code": "\n".join(snippets)}}], True

    @staticmethod
    def _tool_requirement_missing(evidence: List[Dict[str, Any]], requirements: Optional[Mapping[str, Any]]) -> List[str]:
        """Report unmet read-observation requirements for an explicitly gated run."""
        if not requirements:
            return []
        successful = [item for item in evidence if item.get("ok") is True]
        names = {str(item.get("tool", "")).lower() for item in successful}
        missing: List[str] = []
        if requirements.get("list_files") and not names.intersection({"list", "list_files", "glob"}):
            missing.append("list_files")
        required_paths = {str(path) for path in requirements.get("read_paths", ())}
        actual_paths = {
            str(item.get("path")) for item in successful
            if str(item.get("tool", "")).lower() in {"read", "read_file", "fs.read"} and item.get("path")
        }
        for path in sorted(required_paths - actual_paths):
            missing.append(f"read:{path}")
        if requirements.get("graph_query") and not names.intersection({"graph", "graph_search", "search", "graph_query"}):
            missing.append("graph_query")
        return missing

    def _final_patch_context(self, branch: str, paths: List[str], max_chars: int = 24_000) -> str:
        """Build a small trusted final-patch context after broad tool discovery.

        Read-heavy exploration is useful for evidence, but replaying every raw
        observation into the final generation turn can crowd out the target
        implementation and its acceptance tests.  This view is constructed by
        the harness from declared workspace paths, never model-supplied paths.
        """
        chunks: List[str] = []
        used = 0
        for raw_path in paths:
            try:
                rel = self._normalise_tool_path(str(raw_path))
                content = self.workspace.read(branch, rel).decode("utf-8", errors="replace")
            except Exception:
                continue
            remaining = max_chars - used
            if remaining <= 0:
                break
            text = content[:remaining]
            chunks.append(f"--- FINAL EVIDENCE {rel} ---\n{text}\n")
            used += len(text) + len(rel) + 24
        return "\n".join(chunks)

    def _tool_surface_instruction(self, allow_write: bool) -> str:
        """Describe the selected surface with a concrete textual fallback.

        OpenAI-compatible providers receive the equivalent native JSON schema
        when a run explicitly requires tool observations.  The examples below
        keep non-native providers interoperable and, critically, use complete
        closing tags so a model can imitate a valid request exactly.
        """
        if self.config.planner.tool_surface == "kernel":
            return (
                "Tool: chimera.py(code) only; make exactly one call per tool turn. State persists. "
                "Code is bounded read-only Python with assignments, literals, slicing, comparisons, and safe functions "
                "len/sorted/lines/lower/unique/json_loads/json_dumps. Typed host functions are "
                "read(path[,start,end]), list_files([pattern]), graph(query), artifact(digest[,start,end]). "
                "Combine independent host reads in ONE code string, for example: "
                '<tool_call>{"name":"chimera.py","arguments":{"code":"files = list_files(\\"**/*.py\\")\\nsource = read(\\"src/app.py\\")\\nhits = graph(\\"symbol\\")\\n[files, source, hits]"}}</tool_call>. '
                "No imports, attributes, open, subprocess, network, loops, functions, writes, or direct tools. "
                "After a tool result, return the final patch as ordinary JSON outside the tool."
            )
        if self.config.planner.tool_surface == "legacy":
            write_part = ", write_file(path,content), edit_file(path,old_text,new_text)" if allow_write else ""
            return (
                "Available tools: read_file(path[,start,end]), list_files(pattern), graph_search(query), "
                f"artifact_read(digest[,start,end]), artifact_search(digest,query[,max_lines]){write_part}. A shell tool supports one read-only cat/sed/grep/find/ls command. "
                "For each call emit a complete block such as "
                "<tool_call>read_file<arg_key>path</arg_key><arg_value>src/app.py</arg_value></tool_call>. "
                "Use separate complete blocks for independent legacy calls, then wait for tool results before returning a patch."
            )
        operations = "R=read, L=list, G=graph, A=artifact slice, Q=artifact search, S=read-only shell"
        if allow_write:
            operations += ", W=write, E=exact edit"
        return (
            "Tool: chimera.run(actions). Call it at most once per turn. Emit exactly "
            '<tool_call>{"name":"chimera.run","arguments":{"actions":[{"id":"ls","op":"L","args":{"pattern":"src/**/*.py"}},'
            '{"id":"read","op":"R","args":{"path":"src/app.py"}},{"id":"graph","op":"G","args":{"query":"symbol"}}]}}</tool_call>. '
            f"Ops: {operations}. Actions form a bounded declarative DAG; after may name only earlier ids. "
            "For G use args.query (never path/symbol). No opaque Python, loops, scripts, direct tools, or undeclared effects. "
            "R args may set mode=structure|source|auto; large auto reads return outlines plus an artifact digest for a later A action. "
            "Optional outputs=[ids] enables dead-fetch elimination: only those actions and their dependencies execute."
        )

    def _compact_tool_results(self, results: List[Dict[str, Any]], max_chars: int = 20_000) -> tuple[List[Dict[str, Any]], Dict[str, int]]:
        """Give every action a bounded context slot; failures receive priority."""
        if not results:
            return results, {"original_chars": 0, "context_chars": 0, "artifactized": 0}
        original = len(json.dumps(results, ensure_ascii=False, default=str))
        per_result = max(700, max_chars // len(results))
        output: List[Dict[str, Any]] = []
        artifactized = 0
        for result in results:
            row = dict(result)
            content_key = next((key for key in ("error", "content", "output", "stdout", "stderr") if isinstance(row.get(key), str)), None)
            if content_key is not None:
                content = row[content_key]
                quarantine = self.retrieved_content_guard.inspect(
                    content, source=str(row.get("tool") or "unknown"),
                )
                if quarantine.quarantined:
                    # Do not provide either raw text or its CAS address to the
                    # model. An untrusted document must not smuggle an
                    # instruction such as "read artifact X" into a later turn.
                    row[content_key] = quarantine.placeholder
                    row.pop("artifact_ref", None)
                    row["context_quarantined"] = True
                    row["quarantine_reasons"] = list(quarantine.reasons)
                    row["content_hash"] = quarantine.content_hash
                    # Continue through the common projection path with an
                    # empty surrogate; this preserves the placeholder above
                    # without processing the attacker-controlled raw string.
                    content = ""
                allowance = min(4_000 if not row.get("ok", False) else per_result, max_chars)
                projection = self.tool_output_projector.project(
                    tool=str(row.get("tool") or "unknown"),
                    content=content,
                    ok=bool(row.get("ok", False)),
                    max_bytes=allowance,
                    existing_artifact_ref=(row.get("artifact_ref") if isinstance(row.get("artifact_ref"), dict) else None),
                )
                if projection.truncated:
                    row[content_key] = projection.content
                    row["artifact_ref"] = projection.artifact_ref
                    row["context_compacted"] = True
                    row["projection_policy"] = projection.policy
                    row["omitted_bytes"] = projection.omitted_bytes
                    row["critical_lines_retained"] = projection.critical_lines_retained
                    row["critical_lines_total"] = projection.critical_lines_total
                    artifactized += 1
            output.append(row)
        context_chars = len(json.dumps(output, ensure_ascii=False, default=str))
        return output, {
            "original_chars": original, "context_chars": context_chars,
            "artifactized": artifactized,
        }

    @staticmethod
    def _tool_request_summary(text: str, calls: List[Dict[str, Any]]) -> str:
        """Retain tool intent without replaying model-authored file contents."""
        safe_keys = {"path", "pattern", "query", "start", "end", "mode", "command", "id"}
        rows = []
        for index, call in enumerate(calls):
            arguments = call.get("arguments") if isinstance(call.get("arguments"), dict) else {}
            safe = {
                key: (str(value)[:240] if isinstance(value, str) else value)
                for key, value in arguments.items() if key in safe_keys
            }
            omitted = {
                key: {"chars": len(str(value)), "sha256": hashlib.sha256(str(value).encode()).hexdigest()[:16]}
                for key, value in arguments.items() if key not in safe_keys
            }
            rows.append({
                "index": index, "name": call.get("name"), "arguments": safe,
                "omitted_values": omitted,
            })
        return json.dumps({
            "request_hash": "sha256:" + hashlib.sha256(text.encode()).hexdigest(),
            "calls": rows,
        }, sort_keys=True, separators=(",", ":"))[:3000]

    def _normalise_tool_path(self, raw: str) -> str:
        path = pathlib.Path(raw)
        if path.is_absolute():
            resolved = path.resolve()
            if not resolved.is_relative_to(self.root):
                raise ValueError("tool path is outside workspace")
            return str(resolved.relative_to(self.root))
        candidate = (self.root / path).resolve()
        if not candidate.is_relative_to(self.root):
            raise ValueError("tool path traversal")
        return str(candidate.relative_to(self.root))

    def _task_write_scope_error(self, path: str) -> str | None:
        """Enforce the active typed task contract for native write tools.

        Patch payloads already pass ``PatchQualityGate``. Native tool writes
        take a different transport path and must not become a scope bypass.
        """
        contract = getattr(self._thread_local, "contract", None) or self._task_contract
        if contract is None:
            return None
        clean = str(path).replace("\\", "/").removeprefix("./")
        protected = set(getattr(contract, "protected_paths", ()) or ())
        if clean in protected or any(clean.startswith(item.rstrip("/") + "/") for item in protected):
            return f"task contract protects path: {clean}"
        targets = {target.path for target in (getattr(contract, "targets", ()) or ())}
        if targets and clean not in targets and not clean.startswith(".chimera/"):
            return f"out-of-contract native tool write: {clean}"
        return None

    def _budget_tool_text(
        self, text: str, *, max_chars: int, provenance: Dict[str, Any], media_type: str = "text/plain"
    ) -> tuple[str, bool, Optional[Dict[str, Any]]]:
        """Return bounded prompt text while preserving complete bytes in CAS."""
        if len(text) <= max_chars:
            return text, False, None
        ref = self.artifacts.put(text, media_type=media_type, provenance=provenance)
        return text[:max_chars], True, ref.to_dict()
