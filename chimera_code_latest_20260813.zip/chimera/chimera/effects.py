"""Typed effects and least-privilege capability checks.

The checker is deliberately small, deterministic, and fail closed.  It treats
paths and hosts as resources rather than as substrings: deny rules take
precedence, ``*`` never crosses a path separator, and ``**`` may cross one.
"""
from __future__ import annotations

import ipaddress
import posixpath
import re
from functools import lru_cache
from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class EffectRequest(BaseModel):
    effect: str
    needs: Dict[str, List[str]] = Field(default_factory=dict)
    trace: Optional[Dict] = None


class Verdict(BaseModel):
    allowed: bool
    denied_reason: Optional[str] = None
    residual_obligations: List[str] = Field(default_factory=list)
    effect: str = ""


@lru_cache(maxsize=1024)
def _glob_regex(pattern: str) -> re.Pattern[str]:
    """Compile a portable resource glob.

    ``*`` matches within one path component, ``**`` spans components, and
    ``?`` matches one non-separator character.  This avoids ``fnmatch``'s
    platform-dependent slash behaviour.
    """
    out: list[str] = ["^"]
    i = 0
    while i < len(pattern):
        char = pattern[i]
        if char == "*":
            if i + 1 < len(pattern) and pattern[i + 1] == "*":
                i += 1
                # ``dir/**`` also matches the directory itself.
                if i + 1 == len(pattern) and out and out[-1] == "/":
                    out[-1] = "(?:/.*)?"
                else:
                    out.append(".*")
            else:
                out.append("[^/]*")
        elif char == "?":
            out.append("[^/]")
        else:
            out.append(re.escape(char))
        i += 1
    out.append("$")
    return re.compile("".join(out))


def _normalise_fs(value: str) -> tuple[Optional[str], Optional[str]]:
    if not isinstance(value, str) or not value or "\x00" in value:
        return None, "empty or NUL-containing path"
    raw = value.replace("\\", "/")
    dynamic = "${" in raw or "{{" in raw
    if dynamic:
        return raw, None
    absolute = raw.startswith("/")
    # Preserve the leading slash while normalising duplicate separators/dots.
    normal = posixpath.normpath(raw)
    if any(part == ".." for part in raw.split("/")):
        return None, "path traversal"
    if normal in (".", ""):
        normal = "."
    if not absolute:
        normal = normal.removeprefix("./")
    return normal, None


def _normalise_pattern(pattern: str) -> str:
    p = str(pattern).replace("\\", "/")
    if p.startswith("./"):
        p = p[2:]
    while "//" in p:
        p = p.replace("//", "/")
    return p.rstrip("/") or "."


class CapabilitySet(BaseModel):
    fs_allow: List[str] = Field(default_factory=list)
    fs_deny: List[str] = Field(default_factory=list)
    net_allow: List[str] = Field(default_factory=list)
    net_deny: List[str] = Field(default_factory=list)
    env_allow: List[str] = Field(default_factory=list)
    env_deny: List[str] = Field(default_factory=list)
    mcp_allow: List[str] = Field(default_factory=list)
    mcp_deny: List[str] = Field(default_factory=list)

    @staticmethod
    def _match(patterns: List[str], value: str, *, path: bool = False) -> bool:
        candidate = value
        if path:
            candidate, error = _normalise_fs(value)
            if error or candidate is None:
                return False
        for raw_pattern in patterns:
            pattern = _normalise_pattern(raw_pattern) if path else str(raw_pattern).lower().rstrip(".")
            target = candidate if path else value.lower().rstrip(".")
            # Never let a relative pattern grant an absolute path.
            if path and str(target).startswith("/") and not pattern.startswith("/"):
                continue
            if _glob_regex(pattern).fullmatch(str(target)):
                return True
        return False

    def is_fs_denied(self, path: str) -> bool:
        normal, error = _normalise_fs(path)
        if error or normal is None:
            return True
        # Sensitive virtual/system roots stay denied unless policy contains an
        # explicit absolute allow and no matching deny.
        sensitive = ("/etc", "/proc", "/sys", "/dev", "/root")
        if any(normal == root or normal.startswith(root + "/") for root in sensitive):
            if not any(str(p).startswith("/") for p in self.fs_allow):
                return True
        return self._match(self.fs_deny, normal, path=True)

    def is_fs_allowed(self, path: str) -> bool:
        if self.is_fs_denied(path) or not self.fs_allow:
            return False
        return self._match(self.fs_allow, path, path=True)

    @staticmethod
    def _unsafe_network_host(host: str) -> bool:
        h = host.strip().lower().strip("[]").rstrip(".")
        if h in {"localhost", "localhost.localdomain"}:
            return True
        try:
            ip = ipaddress.ip_address(h)
        except ValueError:
            return False
        return bool(
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_multicast
            or ip.is_reserved
            or ip.is_unspecified
        )

    def is_net_allowed(self, host: str) -> bool:
        h = host.strip().lower().strip("[]").rstrip(".")
        if self._match(self.net_deny, h):
            return False
        # Unsafe addresses require an exact grant, never a broad wildcard.
        if self._unsafe_network_host(h) and h not in {x.lower().rstrip(".") for x in self.net_allow}:
            return False
        return bool(self.net_allow and self._match(self.net_allow, h))

    def is_env_allowed(self, key: str) -> bool:
        if self._match(self.env_deny, key):
            return False
        return bool(self.env_allow and self._match(self.env_allow, key))


def check_effect(request: EffectRequest, granted: CapabilitySet) -> Verdict:
    """Check a requested effect and return explicit residual obligations.

    Unknown effect categories are denied.  Dynamic resource expressions are
    not considered proof of access; they become residual obligations that the
    execution boundary must resolve before running.
    """
    residuals: List[str] = []
    effect = request.effect.strip().lower()
    category = effect.split(".", 1)[0]
    needs = request.needs or {}
    known = {"fs", "net", "env", "mcp", "time", "compute"}
    if category not in known:
        return Verdict(allowed=False, denied_reason=f"unknown effect category: {category}", effect=effect)

    for path in needs.get("fs", []):
        if "${" in path or "{{" in path:
            residuals.append(f"fs:{path} requires a resolved runtime path")
            continue
        normal, error = _normalise_fs(path)
        if error or normal is None:
            return Verdict(allowed=False, denied_reason=f"fs deny: {path!r}: {error}", effect=effect)
        if not granted.is_fs_allowed(normal):
            return Verdict(
                allowed=False,
                denied_reason=f"fs deny: {path} not granted by allowlist",
                effect=effect,
                residual_obligations=residuals,
            )

    for host in needs.get("net", []):
        if any(token in host for token in ("${", "{{", "}")):
            residuals.append(f"net:{host} requires a resolved runtime host")
            continue
        if not granted.is_net_allowed(host):
            return Verdict(
                allowed=False,
                denied_reason=f"net deny: {host} not granted or is non-public",
                effect=effect,
                residual_obligations=residuals,
            )

    for key in needs.get("env", []):
        if not granted.is_env_allowed(key):
            return Verdict(allowed=False, denied_reason=f"env deny: {key}", effect=effect)

    for tool in needs.get("mcp", []):
        if granted._match(granted.mcp_deny, tool):
            return Verdict(allowed=False, denied_reason=f"mcp deny: {tool}", effect=effect)
        if not granted.mcp_allow or not granted._match(granted.mcp_allow, tool):
            return Verdict(allowed=False, denied_reason=f"mcp deny: {tool} not granted", effect=effect)

    return Verdict(allowed=True, effect=effect, residual_obligations=residuals)


def capability_from_toml(data: dict) -> CapabilitySet:
    cap = data.get("capabilities", data)
    fs, net, env = cap.get("fs", {}), cap.get("net", {}), cap.get("env", {})
    mcp = cap.get("mcp", {})
    return CapabilitySet(
        fs_allow=fs.get("allow", []),
        fs_deny=fs.get("deny", []),
        net_allow=net.get("allow", []),
        net_deny=net.get("deny", []),
        env_allow=env.get("allow", []),
        env_deny=env.get("deny", []),
        mcp_allow=mcp.get("allow", []),
        mcp_deny=mcp.get("deny", []),
    )
