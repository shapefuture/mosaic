"""Explicit hexagonal deployment port declarations and local bindings.

These ports are capability declarations, not a service locator.  They allow
parallel adapter development without giving any adapter transactional authority.
"""
from __future__ import annotations

import pathlib
from typing import Literal, Protocol

from pydantic import BaseModel, ConfigDict

from .durable_workflow import DurableWorkflowPort, LocalDurableWorkflowPort
from .impact import ImpactAnalyzer
from .sandbox import Sandbox
from .semantic_code_intelligence import SemanticCodeIntelligencePort, SemanticCodeIntelligenceRouter
from .tenancy import TenantContext, TenantWorkspaceResolver


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class PortBinding(_FrozenModel):
    port: str
    adapter_id: str
    state: Literal["available", "unavailable", "configured-unverified"]
    evidence: dict[str, str | bool]


class IsolationPort(Protocol):
    def exec(self, cmd, timeout=None, env=None): ...


class CodeIntelligencePort(Protocol):
    def analyze(self, changed_paths): ...


class TenantDirectoryPort(Protocol):
    def resolve(self, tenant: TenantContext): ...


class LocalPlatformBindings:
    """Reference adapters used in local deterministic deployment."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.durable: DurableWorkflowPort = LocalDurableWorkflowPort(self.root)
        self.code_intelligence: CodeIntelligencePort = ImpactAnalyzer(self.root)
        # No external semantic server is enabled by default.  The explicit port
        # remains useful and deterministically serves snapshot-bound CodeGraph
        # fallback receipts until a contained primary adapter is configured.
        self.semantic_code_intelligence: SemanticCodeIntelligencePort = SemanticCodeIntelligenceRouter(self.root)
        self.tenants: TenantDirectoryPort = TenantWorkspaceResolver(self.root)

    def describe(self) -> tuple[PortBinding, ...]:
        return (
            PortBinding(
                port="DurableWorkflowPort", adapter_id="local-wal-cas-workflow-v1",
                state="available", evidence={"network": False},
            ),
            PortBinding(
                port="CodeIntelligencePort", adapter_id="local-impact-analyzer-v1",
                state="available", evidence={"network": False},
            ),
            PortBinding(
                port="SemanticCodeIntelligencePort", adapter_id="snapshot-bound-semantic-router-v1",
                state="available",
                evidence={"network": False, "external_semantic_primary": False, "codegraph_fallback": True},
            ),
            PortBinding(
                port="TenantDirectoryPort", adapter_id="opaque-tenant-workspace-v1",
                state="available", evidence={"network": False},
            ),
            PortBinding(
                port="IsolationPort", adapter_id="sandbox-local-or-bwrap-v1",
                state="configured-unverified", evidence={"network": False},
            ),
        )
