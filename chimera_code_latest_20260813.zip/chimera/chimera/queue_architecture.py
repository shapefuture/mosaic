"""Single-architecture queue capacity decision from predeclared workloads."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class QueueWorkloadObservation(_FrozenModel):
    architecture: Literal["dbos-postgres"]
    workers: Literal[1, 4, 16, 64, 100]
    jobs: int = Field(gt=0)
    completed_jobs: int = Field(ge=0)
    failed_jobs: int = Field(ge=0)
    drained: bool
    fairness_ratio: float = Field(ge=0, le=1)
    throughput_jobs_per_second: float = Field(ge=0)
    latency_p50_ms: float = Field(ge=0)
    latency_p95_ms: float = Field(ge=0)
    peak_active_workers: int = Field(ge=0)
    duplicate_physical_effects: int = Field(ge=0)
    unknown_effect_outcomes_preserved: bool
    dead_letters_accounted: bool
    retry_storm_bounded: bool
    restore_completed: bool
    pool_control_plane_available: bool
    listener_uses_direct_or_session_connection: bool
    evidence_ref: str


class QueueDecisionPolicy(_FrozenModel):
    required_workers: tuple[int, ...] = (1, 4, 16, 64, 100)
    minimum_fairness_ratio: float = Field(default=0.8, ge=0, le=1)
    maximum_p95_ms: float = Field(default=5_000, gt=0)
    minimum_completion_ratio: float = Field(default=1.0, gt=0, le=1)


class QueueArchitectureDecision(_FrozenModel):
    selected_architecture: Literal["dbos-postgres"] | None
    accepted_for_manual_review: bool
    automatic_enablement: bool = False
    manual_promotion_required: bool = True
    observed_workers: tuple[int, ...]
    reasons: tuple[str, ...]


class QueueArchitectureEvaluator:
    """Select DBOS or nothing; stacked queue architectures are not representable."""

    def assess(
        self,
        observations: list[QueueWorkloadObservation] | tuple[QueueWorkloadObservation, ...],
        *,
        policy: QueueDecisionPolicy | None = None,
    ) -> QueueArchitectureDecision:
        rows = tuple(observations)
        selected_policy = policy or QueueDecisionPolicy()
        reasons: list[str] = []
        workers = tuple(sorted({row.workers for row in rows}))
        missing = sorted(set(selected_policy.required_workers) - set(workers))
        if missing:
            reasons.append("missing predeclared worker workloads: " + ", ".join(map(str, missing)))
        if len(rows) != len(workers):
            reasons.append("queue campaign must contain exactly one observation per worker level")
        for row in rows:
            completion = (row.completed_jobs + row.failed_jobs) / row.jobs
            if completion < selected_policy.minimum_completion_ratio or not row.drained:
                reasons.append(f"queue did not drain/account for every job at {row.workers} workers")
            if row.fairness_ratio < selected_policy.minimum_fairness_ratio:
                reasons.append(f"queue fairness below threshold at {row.workers} workers")
            if row.latency_p95_ms > selected_policy.maximum_p95_ms:
                reasons.append(f"queue p95 latency exceeded threshold at {row.workers} workers")
            if row.duplicate_physical_effects:
                reasons.append(f"duplicate physical effect observed at {row.workers} workers")
            if not row.unknown_effect_outcomes_preserved:
                reasons.append(f"unknown effect outcome weakened at {row.workers} workers")
            if not row.dead_letters_accounted:
                reasons.append(f"dead letters were not accounted at {row.workers} workers")
            if not row.retry_storm_bounded:
                reasons.append(f"retry storm was not bounded at {row.workers} workers")
            if not row.restore_completed:
                reasons.append(f"queue restore did not complete at {row.workers} workers")
            if not row.pool_control_plane_available:
                reasons.append(f"connection pool starved control plane at {row.workers} workers")
            if not row.listener_uses_direct_or_session_connection:
                reasons.append(f"LISTEN/session state lacks direct/session carve-out at {row.workers} workers")
            if not row.evidence_ref:
                reasons.append(f"missing queue evidence at {row.workers} workers")
        accepted = not reasons and bool(rows)
        return QueueArchitectureDecision(
            selected_architecture="dbos-postgres" if accepted else None,
            accepted_for_manual_review=accepted,
            observed_workers=workers,
            reasons=tuple(dict.fromkeys(reasons)),
        )
