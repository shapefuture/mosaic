"""Module entry point for ``python -m chimera``."""
from .cli import main

if __name__ == "__main__":
    main()
