"""Packaged Restate 1.7 Virtual Object service for Chimera durable workflows."""

from __future__ import annotations

import restate

workflow = restate.VirtualObject("ChimeraDurableObject")
registry = restate.VirtualObject("ChimeraDurableRegistry")


@workflow.handler()
async def start(ctx: restate.ObjectContext, request: dict) -> dict:
    current = await ctx.get("record", type_hint=dict)
    if current is None:
        current = {
            **request,
            "workflow_id": ctx.key(),
            "state": "running",
            "checkpoint_ref": None,
        }
        ctx.set("record", current)
    return current


@workflow.handler()
async def checkpoint(ctx: restate.ObjectContext, request: dict) -> dict:
    current = await ctx.get("record", type_hint=dict)
    if current is None:
        return {"accepted": False, "reason": "missing workflow"}
    if current.get("tenant_key") != request.get("tenant_key"):
        return {"accepted": False, "reason": "tenant mismatch"}
    if current.get("state") != "running":
        return {"accepted": False, "reason": "terminal workflow"}
    current = {**current, "checkpoint_ref": request["checkpoint_ref"]}
    ctx.set("record", current)
    return {"accepted": True, **current}


@workflow.handler()
async def finish(ctx: restate.ObjectContext, request: dict) -> dict:
    current = await ctx.get("record", type_hint=dict)
    if current is None:
        return {"accepted": False, "reason": "missing workflow"}
    if current.get("tenant_key") != request.get("tenant_key"):
        return {"accepted": False, "reason": "tenant mismatch"}
    if current.get("state") not in {"running", request.get("state")}:
        return {"accepted": False, "reason": "conflicting terminal state"}
    current = {**current, "state": request["state"]}
    ctx.set("record", current)
    return {"accepted": True, **current}


@workflow.handler(kind="shared")
async def status(ctx: restate.ObjectSharedContext) -> dict | None:
    return await ctx.get("record", type_hint=dict)


@registry.handler()
async def remember(ctx: restate.ObjectContext, workflow_id: str) -> dict:
    values = await ctx.get("workflow_ids", type_hint=list) or []
    if workflow_id not in values:
        values = [*values, workflow_id]
        ctx.set("workflow_ids", values)
    return {"remembered": True, "count": len(values)}


@registry.handler(kind="shared")
async def known_workflows(ctx: restate.ObjectSharedContext) -> list[str]:
    return await ctx.get("workflow_ids", type_hint=list) or []


app = restate.app([workflow, registry])
