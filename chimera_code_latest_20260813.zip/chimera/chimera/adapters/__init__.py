"""Optional infrastructure adapters; importing this package performs no I/O."""
