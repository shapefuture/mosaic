"""Focused-coder executable quality, integrity, mutation, and capsule helpers."""
from __future__ import annotations

import json
from typing import Any, Dict, List, Mapping


class FocusedQualityMixin:
    def _enforce_protected_test_integrity(
        self,
        branch: str,
        test: Mapping[str, Any],
        protected_test_before: Mapping[str, str],
        protected_test_snapshot,
        evidence: List[Dict[str, Any]],
    ) -> tuple[dict[str, Any], bool]:
        from .fable_transfers import TestIntegrityGuard

        protected_test_after: dict[str, str] = {}
        for path in protected_test_before:
            try:
                protected_test_after[path] = self.workspace.read(branch, path).decode(
                    "utf-8", errors="surrogateescape"
                )
            except (FileNotFoundError, ValueError):
                protected_test_after[path] = "<missing-after>"
        protected_tests_unchanged = TestIntegrityGuard.unchanged(
            protected_test_snapshot, protected_test_after
        )
        evidence.append({
            "stage": "protected-test-integrity",
            "ok": protected_tests_unchanged,
            "paths": sorted(protected_test_before),
        })
        updated = dict(test)
        if not protected_tests_unchanged:
            updated = {
                **updated,
                "status": 66,
                "stdout": str(updated.get("stdout", ""))
                + "\nprotected test integrity violation",
                "protected_test_integrity": "changed",
            }
        return updated, protected_tests_unchanged

    def _run_mutation_challenge(
        self,
        *,
        branch: str,
        task: str,
        changed: list[str],
        test_command: str,
        test: Mapping[str, Any],
        evidence: List[Dict[str, Any]],
    ) -> tuple[dict[str, Any], dict[str, Any] | None]:
        mutation_summary = None
        updated = dict(test)
        from .mutation import RiskRanker

        risk_ranking = RiskRanker.rank(list(dict.fromkeys(changed)), task)
        high_risk_task = any(word in task.lower() for word in (
            "security", "auth", "permission", "credential", "tenant", "payment", "financial"
        )) or bool(risk_ranking and risk_ranking[0][1] >= 3)
        mutation_enabled = (
            self.config.quality.mutation_mode == "always"
            or (self.config.quality.mutation_mode == "high-risk" and high_risk_task)
        )
        if mutation_enabled and updated.get("status") == 0 and changed and "pytest" in test_command:
            try:
                from .mutation import MutationVerifier
                ranked_paths = [path for path, _score in risk_ranking]
                mutation = MutationVerifier(
                    self.root, self.workspace, self.config.to_capability_set()
                ).evaluate(
                    branch, ranked_paths, test_command,
                    max_mutants=self.config.quality.max_mutants,
                )
                mutation_summary = {
                    "generated": mutation.generated,
                    "killed": mutation.killed,
                    "survived": mutation.survived,
                    "kill_rate": mutation.kill_rate,
                    "survivors": list(mutation.survivors),
                    "evidence": list(mutation.evidence),
                    "risk_ranking": [
                        {"path": path, "score": score} for path, score in risk_ranking
                    ],
                }
                gate_ok = (
                    mutation.generated == 0
                    or mutation.kill_rate >= self.config.quality.minimum_kill_rate
                )
                evidence.append({"stage": "mutation-challenge", "ok": gate_ok, **mutation_summary})
                if self.config.quality.enforce_mutation_gate and not gate_ok:
                    updated = {
                        **updated,
                        "status": 65,
                        "mutation_gate": mutation_summary,
                        "stdout": str(updated.get("stdout", ""))
                        + "\nmutation contract challenge failed",
                    }
            except Exception as exc:
                evidence.append({
                    "stage": "mutation-challenge",
                    "ok": False,
                    "error": f"{type(exc).__name__}: {exc}"[:500],
                })
        return updated, mutation_summary

    def _store_verified_capsule(
        self,
        *,
        capsule_spec,
        branch: str,
        changed: list[str],
        test: Mapping[str, Any],
        evidence: List[Dict[str, Any]],
    ) -> None:
        if capsule_spec is None or test.get("status") != 0 or not changed:
            return
        try:
            cached_files = []
            for path in list(dict.fromkeys(changed)):
                cached_files.append({
                    "path": path,
                    "content": self.workspace.read(branch, path).decode("utf-8"),
                })
            test_ref = self.artifacts.put(
                json.dumps(test, sort_keys=True, default=str),
                media_type="application/vnd.chimera.test-evidence+json",
                provenance={"capsule_key": capsule_spec.key, "branch": branch},
            )
            record = self.capsule_cache.put(
                capsule_spec,
                {"files": cached_files, "edits": [], "insertions": []},
                {
                    "status": "pass",
                    "test_status": 0,
                    "evidence_refs": (f"artifact:{test_ref.digest}",),
                },
            )
            evidence.append({
                "stage": "capsule-store",
                "ok": True,
                "capsule_key": capsule_spec.key,
                "record_hash": record.record_hash,
            })
        except Exception as exc:
            evidence.append({
                "stage": "capsule-store",
                "ok": False,
                "error": f"{type(exc).__name__}: {exc}"[:500],
            })
