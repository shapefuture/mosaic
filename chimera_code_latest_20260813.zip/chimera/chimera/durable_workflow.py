"""Substitutable durable-workflow port and local WAL/CAS adapter."""

from __future__ import annotations

import json
import pathlib
import time
import uuid
from collections.abc import Mapping
from dataclasses import asdict, dataclass
from typing import Any, Protocol, runtime_checkable

from .artifacts import ContentAddressedArtifactStore
from .wait_registry import WaitKind, WaitRecord, WaitRegistry
from .wal import WAL


@dataclass(frozen=True)
class WorkflowRecord:
    id: str
    state: str
    created_at: float
    checkpoint_ref: str | None = None
    tenant_key: str | None = None


@runtime_checkable
class DurableWorkflowPort(Protocol):
    def start(
        self,
        *,
        workflow_type: str,
        input_identity: str,
        workflow_id: str | None = None,
        tenant_key: str | None = None,
    ) -> WorkflowRecord: ...

    def checkpoint(
        self,
        workflow: WorkflowRecord,
        state: Mapping[str, Any],
        *,
        idempotency_key: str | None = None,
        tenant_key: str | None = None,
    ) -> WorkflowRecord: ...

    def wait(
        self,
        workflow: WorkflowRecord,
        *,
        kind: WaitKind,
        target: Any,
        owner: str,
        timeout_seconds: float,
        tenant_key: str | None = None,
    ) -> WaitRecord: ...

    def finish(
        self,
        workflow: WorkflowRecord,
        *,
        state: str,
        idempotency_key: str | None = None,
        tenant_key: str | None = None,
    ) -> WorkflowRecord: ...

    def cancel(
        self, workflow: WorkflowRecord, *, tenant_key: str | None = None
    ) -> WorkflowRecord: ...

    def recover(
        self, workflow_id: str, *, tenant_key: str | None = None
    ) -> WorkflowRecord | None: ...

    def recover_incomplete(
        self, *, tenant_key: str | None = None
    ) -> tuple[WorkflowRecord, ...]: ...


class LocalDurableWorkflowPort:
    """No scheduler magic: the caller explicitly advances durable local state."""

    adapter_id = "local-wal-cas-workflow-v2"

    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root).resolve()
        self.wal = WAL(self.root)
        self.artifacts = ContentAddressedArtifactStore(self.root)
        self.waits = WaitRegistry(self.root)

    @staticmethod
    def _tenant(workflow: WorkflowRecord, tenant_key: str | None) -> None:
        if workflow.tenant_key != tenant_key:
            raise PermissionError("workflow tenant context does not match the caller")

    def start(
        self,
        *,
        workflow_type: str,
        input_identity: str,
        workflow_id: str | None = None,
        tenant_key: str | None = None,
    ) -> WorkflowRecord:
        identifier = workflow_id or "workflow:" + uuid.uuid4().hex
        existing = self.recover(identifier, tenant_key=tenant_key)
        if existing is not None:
            rows = [
                entry["data"]
                for entry in self.wal.replay(kind="durable_workflow")
                if entry.get("data", {}).get("id") == identifier
                and entry.get("data", {}).get("event") == "started"
            ]
            if (
                not rows
                or rows[0].get("workflow_type") != workflow_type
                or rows[0].get("input_identity") != input_identity
            ):
                raise RuntimeError(
                    "duplicate workflow ID is bound to different immutable input"
                )
            return existing
        record = WorkflowRecord(
            identifier, "running", time.time(), tenant_key=tenant_key
        )
        self.wal.append(
            "durable_workflow",
            {
                "event": "started",
                **asdict(record),
                "workflow_type": workflow_type,
                "input_identity": input_identity,
            },
        )
        return record

    def checkpoint(
        self,
        workflow: WorkflowRecord,
        state: Mapping[str, Any],
        *,
        idempotency_key: str | None = None,
        tenant_key: str | None = None,
    ) -> WorkflowRecord:
        self._tenant(workflow, tenant_key)
        current = self.recover(workflow.id, tenant_key=tenant_key)
        if current is None or current.state != "running":
            raise RuntimeError("cannot checkpoint a missing or terminal workflow")
        ref = self.artifacts.put(
            json.dumps(dict(state), sort_keys=True, separators=(",", ":"), default=str),
            media_type="application/vnd.chimera.workflow-checkpoint+json",
            provenance={"workflow": workflow.id, "tenant_key": tenant_key},
        )
        checkpoint_ref = "artifact:" + ref.digest
        key = idempotency_key or f"checkpoint:{workflow.id}:{ref.digest}"
        prior = [
            entry["data"]
            for entry in self.wal.replay(kind="durable_workflow")
            if entry.get("data", {}).get("idempotency_key") == key
        ]
        if prior:
            if prior[-1].get("checkpoint_ref") != checkpoint_ref:
                raise RuntimeError(
                    "checkpoint idempotency key is bound to different bytes"
                )
            return WorkflowRecord(
                workflow.id, "running", current.created_at, checkpoint_ref, tenant_key
            )
        updated = WorkflowRecord(
            workflow.id, "running", current.created_at, checkpoint_ref, tenant_key
        )
        self.wal.append(
            "durable_workflow",
            {
                "event": "checkpoint",
                **asdict(updated),
                "idempotency_key": key,
            },
        )
        return updated

    def wait(
        self,
        workflow: WorkflowRecord,
        *,
        kind: WaitKind,
        target: Any,
        owner: str,
        timeout_seconds: float,
        tenant_key: str | None = None,
    ) -> WaitRecord:
        self._tenant(workflow, tenant_key)
        return self.waits.register(
            run_id=workflow.id,
            kind=kind,
            target=target,
            owner=owner,
            timeout_seconds=timeout_seconds,
        )

    def finish(
        self,
        workflow: WorkflowRecord,
        *,
        state: str,
        idempotency_key: str | None = None,
        tenant_key: str | None = None,
    ) -> WorkflowRecord:
        self._tenant(workflow, tenant_key)
        if state not in {"completed", "failed", "cancelled"}:
            raise ValueError(
                "workflow terminal state must be completed, failed, or cancelled"
            )
        current = self.recover(workflow.id, tenant_key=tenant_key)
        if current is None:
            raise RuntimeError("cannot finish a missing workflow")
        if current.state != "running":
            if current.state != state:
                raise RuntimeError(
                    "terminal workflow cannot transition to a different state"
                )
            return current
        key = idempotency_key or f"finish:{workflow.id}:{state}"
        updated = WorkflowRecord(
            workflow.id, state, current.created_at, current.checkpoint_ref, tenant_key
        )
        self.wal.append(
            "durable_workflow",
            {
                "event": "finished",
                **asdict(updated),
                "idempotency_key": key,
            },
        )
        return updated

    def cancel(
        self, workflow: WorkflowRecord, *, tenant_key: str | None = None
    ) -> WorkflowRecord:
        return self.finish(
            workflow,
            state="cancelled",
            idempotency_key=f"cancel:{workflow.id}",
            tenant_key=tenant_key,
        )

    def recover(
        self, workflow_id: str, *, tenant_key: str | None = None
    ) -> WorkflowRecord | None:
        target = str(workflow_id)
        valid, position = self.wal.verify_chain()
        if not valid:
            raise RuntimeError(
                f"durable workflow recovery refused: WAL is corrupt near {position}"
            )
        current: WorkflowRecord | None = None
        for entry in self.wal.replay(kind="durable_workflow"):
            data = entry.get("data", {})
            if data.get("id") != target:
                continue
            if data.get("tenant_key") != tenant_key:
                raise PermissionError(
                    "workflow tenant context does not match the caller"
                )
            event = data.get("event")
            try:
                if event == "started":
                    current = WorkflowRecord(
                        id=target,
                        state=str(data["state"]),
                        created_at=float(data["created_at"]),
                        checkpoint_ref=None,
                        tenant_key=tenant_key,
                    )
                elif event == "checkpoint" and current is not None:
                    ref = data.get("checkpoint_ref")
                    if not isinstance(ref, str) or not ref.startswith(
                        "artifact:sha256:"
                    ):
                        raise ValueError("checkpoint reference is invalid")
                    self.artifacts.get(ref.removeprefix("artifact:"))
                    current = WorkflowRecord(
                        target, current.state, current.created_at, ref, tenant_key
                    )
                elif event == "finished" and current is not None:
                    state = str(data["state"])
                    if state not in {"completed", "failed", "cancelled"}:
                        raise ValueError("terminal workflow state is invalid")
                    current = WorkflowRecord(
                        target,
                        state,
                        current.created_at,
                        current.checkpoint_ref,
                        tenant_key,
                    )
            except (KeyError, TypeError, ValueError) as exc:
                raise RuntimeError(
                    f"durable workflow recovery refused: invalid {event!r} record"
                ) from exc
        return current

    def recover_incomplete(
        self, *, tenant_key: str | None = None
    ) -> tuple[WorkflowRecord, ...]:
        valid, position = self.wal.verify_chain()
        if not valid:
            raise RuntimeError(
                f"durable workflow recovery refused: WAL is corrupt near {position}"
            )
        ids = []
        for entry in self.wal.replay(kind="durable_workflow"):
            data = entry.get("data", {})
            if (
                data.get("event") == "started"
                and data.get("tenant_key") == tenant_key
                and isinstance(data.get("id"), str)
            ):
                ids.append(data["id"])
        recovered = [
            self.recover(identifier, tenant_key=tenant_key)
            for identifier in dict.fromkeys(ids)
        ]
        return tuple(
            record
            for record in recovered
            if record is not None and record.state == "running"
        )
