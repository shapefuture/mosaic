"""Offline calibration receipts for focused-test impact selection.

Cases are supplied by an external mutation/seeded-defect harness.  Chimera does
not invent mutants or automatically alter its impact policy from these results.
"""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from .impact import ImpactScope


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ImpactCalibrationCase(_FrozenModel):
    case_id: str
    scope: ImpactScope
    injected_failure_tests: tuple[str, ...] = Field(min_length=1)
    focused_duration_ms: float = Field(ge=0)
    full_duration_ms: float = Field(ge=0)
    focused_completed: bool
    full_completed: bool
    full_failing_tests: tuple[str, ...]


class ImpactCalibrationReport(_FrozenModel):
    cases: tuple[ImpactCalibrationCase, ...]
    completed_cases: int
    mutation_recall: float | None
    focused_to_full_time_ratio: float | None
    mandatory_floor_covered: bool
    advisory_only: bool = True
    policy_change_authorized: bool = False
    reasons: tuple[str, ...]


class TestImpactCalibrator:
    """Measure focused selection recall; never modify the impact selector."""

    def assess(self, cases: list[ImpactCalibrationCase] | tuple[ImpactCalibrationCase, ...]) -> ImpactCalibrationReport:
        rows = tuple(cases)
        completed = [row for row in rows if row.focused_completed and row.full_completed]
        reasons: list[str] = []
        if not rows:
            reasons.append("no calibration cases")
        if len(completed) != len(rows):
            reasons.append("one or more focused/full calibration runs did not complete")
        hits = 0
        expected = 0
        mandatory_ok = True
        ratios: list[float] = []
        for row in completed:
            selected = set(row.scope.mandatory_tests) | set(row.scope.affected_tests)
            injected = {_test_path(item) for item in row.injected_failure_tests}
            expected += len(injected)
            hits += sum(path in selected for path in injected)
            mandatory_ok = mandatory_ok and set(row.scope.mandatory_tests).issubset(selected)
            if row.full_duration_ms > 0:
                ratios.append(row.focused_duration_ms / row.full_duration_ms)
            if not set(row.injected_failure_tests).issubset(set(row.full_failing_tests)):
                reasons.append(f"full run did not expose every injected failure in {row.case_id}")
        recall = hits / expected if expected else None
        ratio = sum(ratios) / len(ratios) if ratios else None
        if recall is None:
            reasons.append("no completed injected failures to measure recall")
        if not mandatory_ok:
            reasons.append("mandatory constitutional tests were omitted")
        return ImpactCalibrationReport(
            cases=rows,
            completed_cases=len(completed),
            mutation_recall=recall,
            focused_to_full_time_ratio=ratio,
            mandatory_floor_covered=mandatory_ok,
            reasons=tuple(dict.fromkeys(reasons)),
        )


def _test_path(node_id: str) -> str:
    return str(node_id).split("::", 1)[0].replace("\\", "/")
