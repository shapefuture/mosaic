"""Provenance-aware replay buffer for governed harness evolution."""
from __future__ import annotations

import hashlib
import json
import pathlib
import time
from collections import defaultdict
from typing import Any, Dict, List, Optional


class ReplayBuffer:
    """Append-only trajectories with provenance and trust-aware retrieval.

    Evolution must not train on its own unaudited claims.  Entries are therefore
    labelled ``verified``, ``unverified``, or ``quarantined`` and hash-linked.
    Legacy entries remain readable but are unverified.
    """
    def __init__(self, root: pathlib.Path = pathlib.Path(".")):
        self.root = pathlib.Path(root)
        self.path = self.root / ".chimera" / "replay.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._entries: List[Dict] = []
        self._quarantine: List[Dict] = []
        self._last_hash = "genesis"
        from .trace_policy import TraceSampler
        from .hypothesis_queue import HypothesisQueue, WarmTraceMiner
        self.trace_sampler = TraceSampler(self.root)
        self.hypothesis_miner = WarmTraceMiner(HypothesisQueue(self.root))
        self._load()

    @staticmethod
    def _hash(entry_without_hash: Dict) -> str:
        return hashlib.sha256(json.dumps(entry_without_hash, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

    def _load(self):
        if not self.path.exists():
            return
        expected_parent = "genesis"
        for line_no, line in enumerate(self.path.read_text().splitlines(), 1):
            if not line.strip():
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                self._quarantine.append({"line": line_no, "reason": "invalid json"})
                continue
            if "entry_hash" not in entry:  # legacy, readable but never trusted
                entry.setdefault("evidence_status", "unverified")
                entry["legacy"] = True
                self._entries.append(entry)
                continue
            candidate = dict(entry)
            actual = candidate.pop("entry_hash")
            if candidate.get("parent_hash") != expected_parent or self._hash(candidate) != actual:
                entry["evidence_status"] = "quarantined"
                self._quarantine.append({"line": line_no, "reason": "hash chain mismatch", "entry": entry})
                continue
            self._entries.append(entry)
            expected_parent = actual
            self._last_hash = actual

    def append(self, model: str, harness_variant: str, task: str, reward: float,
               trace: List[Dict], metadata: Optional[Dict] = None,
               evidence_status: str = "unverified", provenance: Optional[Dict] = None):
        if evidence_status not in {"verified", "unverified", "quarantined"}:
            raise ValueError(f"invalid evidence_status: {evidence_status}")
        sample = self.trace_sampler.sample(
            trace, identity=f"{model}:{harness_variant}:{task}:{self._last_hash}"
        )
        sampled_metadata = dict(metadata or {})
        sampled_metadata["trace_sampling"] = {
            "full_ref": sample.full_ref,
            "dropped": sample.dropped,
            "sampled_success": sample.sampled_success,
            "summary": sample.summary,
        }
        mined = self.hypothesis_miner.mine(sample.events)
        sampled_metadata["warm_hypotheses"] = [item.id for item in mined]
        base = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "model": model,
            "harness_variant": harness_variant,
            "task": task,
            "reward": max(0.0, min(1.0, float(reward))),
            "trace": list(sample.events),
            "metadata": sampled_metadata,
            "evidence_status": evidence_status,
            "provenance": provenance or {"source": "runtime", "actor": model},
            "parent_hash": self._last_hash,
        }
        entry = {**base, "entry_hash": self._hash(base)}
        with self.path.open("a") as handle:
            handle.write(json.dumps(entry, sort_keys=True) + "\n")
        self._entries.append(entry)
        self._last_hash = entry["entry_hash"]
        return entry

    def query(self, model: Optional[str] = None, harness_variant: Optional[str] = None,
              min_reward: Optional[float] = None, trusted_only: bool = False) -> List[Dict]:
        output = []
        for entry in self._entries:
            if model and entry.get("model") != model:
                continue
            if harness_variant and entry.get("harness_variant") != harness_variant:
                continue
            if min_reward is not None and entry.get("reward", 0) < min_reward:
                continue
            if trusted_only and entry.get("evidence_status") != "verified":
                continue
            output.append(entry)
        return output

    def variant_scores(self, trusted_only: bool = True) -> Dict[str, float]:
        scores: Dict[str, List[float]] = defaultdict(list)
        entries = self.query(trusted_only=trusted_only)
        for entry in entries:
            scores[entry["harness_variant"]].append(entry["reward"])
        return {key: sum(values) / len(values) for key, values in scores.items()}

    def best_variant(self) -> Optional[str]:
        scores = self.variant_scores(trusted_only=True)
        return max(scores, key=scores.get) if scores else None

    def seesaw_gate(self, before: Dict[str, float], after: Dict[str, float]) -> tuple[bool, str]:
        regress = any(after.get(key, 0) < value - 0.1 for key, value in before.items() if value >= 0.8)
        unsolved = [key for key, value in before.items() if value < 0.5]
        improve = any(after.get(key, 0) > before[key] + 0.1 for key in unsolved) if unsolved else True
        if regress and not improve:
            return False, "seesaw constraint violated: regressed on solved without improving unsolved"
        return True, "pass"

    def wire_snapshot(self, codec, *, session_key: str = "replay", limit: int = 100,
                      trusted_only: bool = True, mode: str = "auto"):
        """Return a session-delta model view; durable replay remains full JSONL."""
        entries = self.query(trusted_only=trusted_only)[-max(1, int(limit)):]
        rows = [
            {
                "id": entry.get("entry_hash") or f"legacy-{index}",
                "ts": entry.get("ts", ""),
                "model": entry.get("model", ""),
                "variant": entry.get("harness_variant", ""),
                "task": str(entry.get("task", ""))[:240],
                "reward": entry.get("reward", 0),
                "status": entry.get("evidence_status", "unverified"),
            }
            for index, entry in enumerate(entries)
        ]
        return codec.encode_generic_records(
            rows, key="id", session_key=session_key, tool="chimera_replay",
            name="trajectories", mode=mode,
        )

    def stats(self) -> Dict:
        trusted = self.query(trusted_only=True)
        return {
            "total": len(self._entries),
            "verified": len(trusted),
            "unverified": sum(1 for e in self._entries if e.get("evidence_status") == "unverified"),
            "quarantined": len(self._quarantine),
            "variants": list(self.variant_scores().keys()),
            "best": self.best_variant(),
            "avg_reward": sum(e["reward"] for e in trusted) / len(trusted) if trusted else 0,
            "chain_head": self._last_hash,
        }
