"""Composed routing/cost decision pipeline.

This module is intentionally thin: it calls the existing six routing/cost layers
in a fixed order and records their outputs so disagreements are visible instead
of silently hidden across call sites.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Optional

from .execution_profile import TaskExecutionProfiler, TaskExecutionProfile
from .optimization_qualifier import qualify, ProblemProfile, SolverDecision
from .capability_calibration import ContextualCapabilityRegistry, CapabilityChoice
from .routing import CapabilityRouter
from .route_advisor import RouteAdvisor, RouteAdvice
from .cost_governor import CostGovernor
from .provider_reliability import ProviderReliabilityRegistry
from .provider_state import ProviderStateRegistry


@dataclass(frozen=True)
class RouteDecision:
    model: str
    reasoning_chain: list[dict[str, Any]] = field(default_factory=list)
    overridden: bool = False
    override_reason: str = ""


def _problem_profile(context_features: Mapping[str, Any]) -> ProblemProfile:
    defaults = {
        "functional_seed": True,
        "automated_evaluator": True,
        "evaluator_is_protected": True,
        "bounded_mutation_surface": True,
        "semantic_code_search": True,
        "numeric_dimensions": 0,
        "gradients_available": False,
        "convex_or_exact_solver_available": False,
        "noisy_evaluator": False,
        "multi_objective": False,
        "estimated_evaluation_seconds": 1.0,
    }
    defaults.update({key: value for key, value in dict(context_features).items() if key in defaults})
    return ProblemProfile(**defaults)


def _dump(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump()
    if hasattr(value, "as_dict"):
        return value.as_dict()
    if hasattr(value, "evidence"):
        return value.evidence()
    return value


def decide_route(
    *,
    task: str,
    contract: Any,
    readiness: Any,
    context_features: Mapping[str, Any],
    profiler: TaskExecutionProfiler,
    capability_registry: ContextualCapabilityRegistry,
    capability_router: CapabilityRouter,
    route_advisor: RouteAdvisor,
    cost_governor: CostGovernor,
    agent_ids: list[str],
    skill: str,
    task_class: str,
    required: frozenset[str],
    input_tokens: int,
    output_tokens: int,
    explicit_model: Optional[str] = None,
    preferred_model: Optional[str] = None,
    provider_reliability: ProviderReliabilityRegistry | None = None,
    reliability_floor: float = 0.9,
    provider_state: ProviderStateRegistry | None = None,
) -> RouteDecision:
    chain: list[dict[str, Any]] = []

    profile: TaskExecutionProfile = profiler.classify(task, contract, readiness)
    chain.append({"layer": "execution_profile", "output": profile.evidence()})

    solver_decision: SolverDecision = qualify(_problem_profile(context_features))
    chain.append({"layer": "optimization_qualifier", "output": solver_decision.model_dump()})

    posterior_choice: CapabilityChoice = capability_registry.choose(
        agent_ids,
        skill,
        context_features,
        task_value=1.0,
        latency_weight=0.0,
        cost_weight=0.0,
        uncertainty_z=1.0,
    )
    chain.append({"layer": "capability_calibration", "output": posterior_choice.model_dump()})

    router_result = capability_router.choose(
        task_class,
        required,
        input_tokens,
        output_tokens,
        explicit_model=explicit_model,
        context_features=dict(context_features),
    )
    router_route = router_result.get("route") if isinstance(router_result, dict) else router_result
    router_choice = getattr(router_route, "model", router_route)
    if router_choice is None:
        raise RuntimeError("capability router returned no model")
    router_choice = str(router_choice)
    preferred = preferred_model or posterior_choice.agent_id
    overridden = explicit_model is None and router_choice != preferred
    override_reason = (
        f"router chose {router_choice!r} instead of preferred/posterior pick {preferred!r}"
        if overridden else ""
    )
    chain.append({"layer": "capability_router", "output": _dump(router_result), "overridden": overridden, "preferred_model": preferred, "explicit_model": explicit_model})

    advice: RouteAdvice = route_advisor.advise(
        requested_model=explicit_model,
        required_capabilities=required,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        latency_sensitive=bool(context_features.get("latency_sensitive", False)),
    )
    chain.append({"layer": "route_advisor", "output": advice.as_dict()})

    if provider_state is not None and explicit_model is None:
        provider_name = str(context_features.get("provider", "route"))
        selected_state = provider_state.profile(provider_name, router_choice)
        chain.append({"layer": "provider_state", "output": selected_state.as_dict()})
        if selected_state.route_penalty > 2.0:
            alternatives = []
            for route in getattr(route_advisor, "routes", ()): 
                if required <= route.capabilities and route.model != router_choice:
                    state = provider_state.profile(provider_name, route.model)
                    alternatives.append((state.route_penalty, route.estimated_cost(input_tokens, output_tokens), route.latency_class, route.model, state))
            if alternatives:
                penalty, _cost, _lat, replacement, state = sorted(alternatives)[0]
                if penalty < selected_state.route_penalty:
                    override_reason = f"provider_state penalty {selected_state.route_penalty:.2f} for {router_choice!r}; routed to {replacement!r} penalty {penalty:.2f}"
                    router_choice = replacement
                    overridden = True
                    chain.append({"layer": "provider_state_override", "output": state.as_dict(), "selected": replacement})

    if provider_reliability is not None and explicit_model is None:
        provider_name = str(context_features.get("provider", "route"))
        profile = provider_reliability.profile(provider_name, router_choice)
        chain.append({"layer": "provider_reliability", "output": profile.as_dict(), "floor": reliability_floor})
        if profile.calls >= 3 and profile.reliability < reliability_floor:
            alternates = []
            for route in getattr(route_advisor, "routes", ()): 
                if required <= route.capabilities and route.model != router_choice:
                    alt_profile = provider_reliability.profile(provider_name, route.model)
                    if alt_profile.calls < 3 or alt_profile.reliability >= reliability_floor:
                        alternates.append((route.estimated_cost(input_tokens, output_tokens), route.latency_class, route.model, alt_profile))
            if alternates:
                _, _, replacement, alt_profile = sorted(alternates)[0]
                override_reason = f"provider reliability {profile.reliability:.2f} below floor {reliability_floor:.2f}; routed to {replacement!r}"
                router_choice = replacement
                overridden = True
                chain.append({"layer": "provider_reliability_override", "output": alt_profile.as_dict(), "selected": replacement})

    chain.append({"layer": "cost_governor", "output": cost_governor.report()})

    return RouteDecision(
        model=router_choice,
        reasoning_chain=chain,
        overridden=overridden,
        override_reason=override_reason,
    )
