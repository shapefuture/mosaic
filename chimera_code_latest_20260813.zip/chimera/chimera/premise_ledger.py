"""Evidence-bound epistemic premises for plans and verification claims."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import StrEnum
import hashlib
import pathlib
import time
from typing import Callable, Iterable

from .wal import WAL


class PremiseStatus(StrEnum):
    F1 = "F1"  # direct, resolvable current evidence
    F2 = "F2"  # deterministic consistency/type evidence
    F3 = "F3"  # plausible but unresolved; may only spawn validation
    F4 = "F4"  # speculative; may only spawn validation


@dataclass(frozen=True)
class Premise:
    id: str
    claim_hash: str
    status: str
    evidence_refs: tuple[str, ...]
    valid_at_revision: str
    scope: str
    verifier: str
    freshness_token: str
    created_at: float

    def as_dict(self) -> dict: return asdict(self)


class PremiseLedger:
    def __init__(self, root: pathlib.Path, *, evidence_resolver: Callable[[str], bool], freshness_resolver: Callable[[str, str], bool]) -> None:
        self.wal = WAL(pathlib.Path(root)); self.evidence_resolver = evidence_resolver; self.freshness_resolver = freshness_resolver

    @staticmethod
    def _hash(value: str) -> str:
        return "sha256:" + hashlib.sha256(value.encode()).hexdigest()

    def record(self, *, claim: str, status: PremiseStatus, evidence_refs: Iterable[str], valid_at_revision: str, scope: str, verifier: str, freshness_token: str) -> Premise:
        refs = tuple(dict.fromkeys(str(ref) for ref in evidence_refs))
        if not claim or not valid_at_revision or not scope or not verifier or not freshness_token:
            raise ValueError("premise requires claim, revision, scope, verifier, and freshness token")
        # An F1/F2 label is not self-certification: it has to carry actual,
        # resolvable evidence at record time. F3/F4 are deliberately allowed
        # without such evidence but cannot certify a decision.
        if status in {PremiseStatus.F1, PremiseStatus.F2} and (not refs or not all(self.evidence_resolver(ref) for ref in refs)):
            raise ValueError(f"{status.value} premise requires resolvable evidence")
        premise = Premise(
            "premise:" + hashlib.sha256((claim + str(time.time_ns())).encode()).hexdigest()[:24], self._hash(claim), status.value,
            refs, valid_at_revision, scope, verifier, freshness_token, time.time(),
        )
        self.wal.append("premise", {"event": "recorded", **premise.as_dict()})
        return premise

    def certifiable(self, premise: Premise) -> tuple[bool, str]:
        if premise.status not in {PremiseStatus.F1.value, PremiseStatus.F2.value}:
            return False, f"{premise.status} premise may only trigger validation work"
        if not premise.evidence_refs or not all(self.evidence_resolver(ref) for ref in premise.evidence_refs):
            return False, "premise evidence is missing or unresolvable"
        if not self.freshness_resolver(premise.valid_at_revision, premise.freshness_token):
            return False, "premise is stale at current revision"
        return True, "premise evidence is current and certifiable"
