"""Deterministic recovery decisions from reduced run lifecycle events.

This does not replay an action. It identifies the last durable boundary and
requires an executor/harness to decide whether a *new*, idempotent action may
continue. Effectful action replay remains prohibited unless an external
idempotency contract is supplied.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Iterable, Mapping

from .run_reducer import RunEventReducer, RunProjection


@dataclass(frozen=True)
class RecoveryDecision:
    run_id: str
    mode: str  # finalized | retry_from_start | resume_after_action | repair_required
    last_action_id: str | None
    reason: str
    projection_hash: str
    requires_new_request: bool = True

    def as_dict(self) -> dict:
        return asdict(self)


class RunRecoveryPlanner:
    @staticmethod
    def decide(entries: Iterable[Mapping], *, run_id: str) -> RecoveryDecision:
        projection: RunProjection = RunEventReducer.reduce(entries, run_id=run_id)
        if projection.terminal is not None:
            return RecoveryDecision(run_id, "finalized", None, "stream already has terminal event", projection.projection_hash, False)
        if not projection.actions:
            return RecoveryDecision(run_id, "retry_from_start", None, "no action reached a durable boundary", projection.projection_hash)
        unfinished = [action for action in projection.actions if action.state not in {"completed", "failed", "rejected", "cancelled"}]
        if unfinished:
            return RecoveryDecision(
                run_id, "repair_required", unfinished[-1].action_id,
                "action was started but did not reach a terminal result; do not replay automatically",
                projection.projection_hash,
            )
        last = projection.actions[-1]
        return RecoveryDecision(
            run_id, "resume_after_action", last.action_id,
            "all observed actions are terminal but stream did not finish; continue with a new request",
            projection.projection_hash,
        )
