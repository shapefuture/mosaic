"""No-gold-plating diff budget; warns/blocks only objectively excessive patches."""
from __future__ import annotations
from dataclasses import dataclass
@dataclass(frozen=True)
class DiffBudgetVerdict:
 allowed:bool;changed_lines:int;limit:int;reason:str
class DiffBudget:
 def check(self,before:str,after:str,requested_paths:int=1)->DiffBudgetVerdict:
  changed=sum(1 for a,b in zip(before.splitlines(),after.splitlines()) if a!=b)+abs(len(before.splitlines())-len(after.splitlines()))
  limit=max(60, min(600, 120*max(1,requested_paths)))
  return DiffBudgetVerdict(changed<=limit,changed,limit,'within focused diff budget' if changed<=limit else 'diff exceeds focused-task budget; split or justify scope')
