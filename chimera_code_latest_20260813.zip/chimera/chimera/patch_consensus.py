"""AST-canonicalized patch consensus for future multi-candidate generation."""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Mapping
import ast, hashlib, json


@dataclass(frozen=True)
class ConsensusResult:
    selected: dict[str, Any] | None
    abstained: bool
    reason: str
    votes: dict[str, int]
    def as_dict(self) -> dict[str, Any]: return asdict(self)


def _canon_source(path: str, source: str) -> str:
    if path.endswith(".py"):
        try:
            tree = ast.parse(source)
            return ast.dump(tree, annotate_fields=True, include_attributes=False)
        except SyntaxError:
            return "syntax-error:" + source
    return source.strip()


def patch_signature(payload: Mapping[str, Any]) -> str:
    rows=[]
    for item in payload.get("files", []) or []:
        if isinstance(item, Mapping) and isinstance(item.get("path"), str) and isinstance(item.get("content"), str):
            rows.append((item["path"], _canon_source(item["path"], item["content"])))
    if isinstance(payload.get("f"), Mapping):
        for path, content in payload["f"].items():
            if isinstance(path, str) and isinstance(content, str): rows.append((path, _canon_source(path, content)))
    edits=[]
    for item in payload.get("edits", []) or []:
        if isinstance(item, Mapping):
            path=str(item.get("path") or item.get("p") or "")
            old=str(item.get("find") or item.get("old") or item.get("old_text") or item.get("oldText") or item.get("o") or "")
            new=str(item.get("replace") or item.get("new") or item.get("new_text") or item.get("newText") or item.get("n") or "")
            if path and old and new:
                edits.append((path, old.strip(), new.strip()))
    raw=json.dumps({"files": sorted(rows), "edits": sorted(edits)}, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(raw.encode()).hexdigest()


def consensus(payloads: list[Mapping[str, Any]], *, min_votes: int = 2, never_abstain: bool = False) -> ConsensusResult:
    votes: dict[str, int] = {}
    first: dict[str, Any] = {}
    for payload in payloads:
        sig = patch_signature(payload)
        votes[sig] = votes.get(sig, 0) + 1
        first.setdefault(sig, dict(payload))
    if not votes:
        return ConsensusResult(None, not never_abstain, "no candidates", {})
    best, count = max(votes.items(), key=lambda kv: (kv[1], kv[0]))
    if count >= min_votes or never_abstain:
        return ConsensusResult(first[best], False, f"selected {count}/{len(payloads)} AST-canonical votes", votes)
    return ConsensusResult(None, True, f"no candidate reached {min_votes} AST-canonical votes", votes)
