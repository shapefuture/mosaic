"""Compaction trigger hygiene, idle opportunism, and per-message accounting."""
from __future__ import annotations

from dataclasses import dataclass, asdict
import time
from typing import Iterable, Any

@dataclass(frozen=True)
class CompactionTriggerDecision:
    should_compact: bool
    trigger: str
    reason: str
    def as_dict(self): return asdict(self)

@dataclass(frozen=True)
class MessageDisposition:
    index:int; disposition:str; reason:str
    def as_dict(self): return asdict(self)

class CompactionPolicy:
    def __init__(self, *, idle_ttl_seconds:float=1800.0, min_loss_chars:int=140_000):
        self.idle_ttl_seconds=idle_ttl_seconds; self.min_loss_chars=min_loss_chars
    def should_compact(self, *, text_chars:int, max_chars:int, now:float|None=None, last_activity:float|None=None, last_compaction:float|None=None, usage_ts:float|None=None, usage_model:str|None=None, current_model:str|None=None, window_known:bool=True, explicit_overflow:bool=False, input_tokens:int=0, cache_read_tokens:int=0, window_tokens:int|None=None, stop_reason:str|None=None)->CompactionTriggerDecision:
        now=time.time() if now is None else now
        if last_compaction and usage_ts and usage_ts < last_compaction:
            return CompactionTriggerDecision(False,"stale-usage","usage predates last compaction")
        if usage_model and current_model and usage_model != current_model:
            return CompactionTriggerDecision(False,"wrong-model","usage belongs to different model")
        if not window_known and not explicit_overflow:
            return CompactionTriggerDecision(False,"unknown-window","no threshold compaction without known context window or explicit overflow")
        if window_tokens and stop_reason == "stop" and input_tokens + cache_read_tokens > window_tokens:
            return CompactionTriggerDecision(True,"silent-overflow","completed response exceeded window including cache-read tokens")
        if explicit_overflow:
            return CompactionTriggerDecision(True,"explicit-overflow","provider reported overflow")
        if last_activity and now-last_activity >= self.idle_ttl_seconds and text_chars >= self.min_loss_chars:
            return CompactionTriggerDecision(True,"cache-cold-idle","session idle beyond cache TTL and large enough to benefit")
        if text_chars > max_chars:
            return CompactionTriggerDecision(True,"hard-threshold","transcript exceeds maximum chars")
        return CompactionTriggerDecision(False,"none","no trigger")
    @staticmethod
    def dispositions(messages:Iterable[Any], keep_last:int=4)->tuple[MessageDisposition,...]:
        rows=list(messages); out=[]
        for i,_ in enumerate(rows):
            if i >= max(0,len(rows)-keep_last): out.append(MessageDisposition(i,"preserved-verbatim","recent tail"))
            else: out.append(MessageDisposition(i,"summarized-or-dropped","older than retained tail; recoverable via artifact if compacted"))
        return tuple(out)

def reversible_collapse(text:str, *, head:int=4000, tail:int=8000)->tuple[str,bool]:
    if len(text) <= head+tail+200: return text, False
    collapsed=text[:head]+f"\n...[deterministically collapsed {len(text)-head-tail} chars]...\n"+text[-tail:]
    return (collapsed, True) if len(collapsed) < len(text) else (text, False)
