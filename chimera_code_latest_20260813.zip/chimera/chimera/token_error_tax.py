"""Token/cost/error-tax telemetry report."""
from __future__ import annotations

import pathlib
from dataclasses import asdict, dataclass
from typing import Any

from .wal import WAL


@dataclass(frozen=True)
class TokenErrorTaxReport:
    schema_version: str
    input_tokens: int
    output_tokens: int
    total_tokens: int
    failed_tokens: int
    retry_tokens: int
    repair_tokens: int
    useful_tokens: int
    token_error_tax: float
    model_calls: int
    failed_calls: int
    retry_calls: int
    repair_calls: int
    successful_tasks: int
    cost_per_successful_task_tokens: float | None
    promotion_allowed: bool

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class TokenErrorTaxAnalyzer:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def analyze(self) -> dict[str, Any]:
        input_tokens = output_tokens = total_tokens = 0
        failed_tokens = retry_tokens = repair_tokens = 0
        model_calls = failed_calls = retry_calls = repair_calls = successful_tasks = 0
        for row in WAL(self.root).replay():
            kind = str(row.get("kind", "")).lower()
            data = row.get("data") if isinstance(row.get("data"), dict) else {}
            usage = data.get("usage") if isinstance(data.get("usage"), dict) else data
            inp = self._num(usage, "input_tokens", "prompt_tokens")
            out = self._num(usage, "output_tokens", "completion_tokens")
            tot = self._num(usage, "total_tokens", "tokens") or inp + out
            if tot:
                model_calls += 1
            input_tokens += inp
            output_tokens += out
            total_tokens += tot
            failed = bool(data.get("error") or data.get("failed") or "fail" in kind or "error" in kind)
            retry = bool(data.get("retry") or data.get("attempt", 1) not in {0, 1} or "retry" in kind or "repair" in kind)
            repair = bool("repair" in kind or data.get("repair_round") is not None)
            if failed:
                failed_calls += 1
                failed_tokens += tot
            if retry:
                retry_calls += 1
                retry_tokens += tot
            if repair:
                repair_calls += 1
                repair_tokens += tot
            if any(word in kind for word in ("task.completed", "focused.result", "run.finished")) and not failed:
                successful_tasks += 1
        waste = min(total_tokens, failed_tokens + retry_tokens + repair_tokens)
        useful = max(0, total_tokens - waste)
        report = TokenErrorTaxReport(
            schema_version="chimera.token-error-tax.v1",
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
            failed_tokens=failed_tokens,
            retry_tokens=retry_tokens,
            repair_tokens=repair_tokens,
            useful_tokens=useful,
            token_error_tax=round(waste / total_tokens, 6) if total_tokens else 0.0,
            model_calls=model_calls,
            failed_calls=failed_calls,
            retry_calls=retry_calls,
            repair_calls=repair_calls,
            successful_tasks=successful_tasks,
            cost_per_successful_task_tokens=round(total_tokens / successful_tasks, 3) if successful_tasks else None,
            promotion_allowed=False,
        )
        return report.as_dict()

    @staticmethod
    def _num(mapping: dict[str, Any], *keys: str) -> int:
        for key in keys:
            value = mapping.get(key)
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                return int(value)
        return 0
