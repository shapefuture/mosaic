"""Linux multi-indicator worker health analysis; silence alone never means stuck."""
from __future__ import annotations
import os,pathlib,time
from dataclasses import dataclass
@dataclass(frozen=True)
class ProcessSample:
 exists:bool;state:str="";wchan:str="";cpu_ticks:int=0;ctx_switches:int=0;network_connections:int=0;data_in_flight:bool=False;syn_sent:bool=False

def read_sample(pid:int)->ProcessSample:
 root=pathlib.Path(f"/proc/{pid}")
 if not root.exists():return ProcessSample(False)
 try:
  stat=(root/"stat").read_text().split();status=(root/"status").read_text();ctx=0
  import re;m=re.search(r"voluntary_ctxt_switches:\s+(\d+)",status);ctx=int(m.group(1)) if m else 0
  w=(root/"wchan").read_text().strip() if (root/"wchan").exists() else ""
  return ProcessSample(True,stat[2],w,int(stat[13])+int(stat[14]),ctx)
 except Exception:return ProcessSample(True)

def analyze_samples(first:ProcessSample,second:ProcessSample,sample_seconds:float):
 if not first.exists or not second.exists:return {"status":"unavailable","stuck":None,"reason":"process missing"}
 cpu=((second.cpu_ticks-first.cpu_ticks)/100/max(sample_seconds,.001))*100;switches=second.ctx_switches-first.ctx_switches;score=0;ind={"sleeping":second.state=="S","blocked":("poll" in second.wchan or "wait" in second.wchan),"low_cpu":cpu<1,"low_ctx_switches":switches<10,"no_data_in_flight":second.network_connections>0 and not second.data_in_flight,"syn_sent":second.syn_sent,"data_in_flight":second.data_in_flight}
 score+=sum(int(ind[k]) for k in ("sleeping","blocked","low_cpu","low_ctx_switches"));score+=.5 if ind["no_data_in_flight"] else 0;score+=1 if ind["syn_sent"] else 0;score=max(0,score-2 if ind["data_in_flight"] else score)
 return {"status":"measured","stuck":score>=3.5,"confidence":"high" if score>=4.5 else "medium" if score>=3.5 else "low","score":score,"cpu_percent":cpu,"ctx_switches":switches,"indicators":ind}
def analyze_process(pid:int,sample_ms:int=500):
 first=read_sample(pid);time.sleep(max(10,sample_ms)/1000);second=read_sample(pid);return analyze_samples(first,second,max(10,sample_ms)/1000)
