"""Explicit evidence contracts for intentionally deferred Chimera features.

A feature is not enabled merely because an implementation exists or a model can
suggest it.  Each registry item names the observation, fault injection, and
kill condition required before a separate promotion decision can occur.
"""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class DeferredFeatureEvidence(_FrozenModel):
    id: str
    state: Literal["deferred", "negative-control", "testable"]
    default_enabled: bool = False
    required_evidence: tuple[str, ...] = Field(min_length=1)
    required_test_harness: tuple[str, ...] = Field(min_length=1)
    kill_criterion: str = Field(min_length=8)


class DeferredEvidenceRegistry:
    """Versioned inventory; callers may not auto-enable an entry from this table."""

    @staticmethod
    def entries() -> tuple[DeferredFeatureEvidence, ...]:
        return (
            DeferredFeatureEvidence(
                id="provider-terminal-cancellation",
                state="testable",
                required_evidence=("terminal provider acknowledgement", "terminal outcome receipt", "billing/effect semantics"),
                required_test_harness=("ProviderTerminalCancellationCanary", "route-specific live canary with explicit authorization"),
                kill_criterion="client disconnect or missing billing/effect proof is reported as provider cancellation",
            ),
            DeferredFeatureEvidence(
                id="native-structured-output",
                state="testable",
                required_evidence=("exact route/model schema completion", "finish reason", "bounded malformed-output rate"),
                required_test_harness=("ProviderCanary strict_json", "fixed schema repeated route canary"),
                kill_criterion="length/incomplete output or adapter-only parsing is treated as native schema support",
            ),
            DeferredFeatureEvidence(
                id="sandbox-isolation",
                state="testable",
                required_evidence=("filesystem containment", "network containment", "process teardown", "escape-attempt results"),
                required_test_harness=("certified bwrap matrix", "host-specific mount/network/process escape tests"),
                kill_criterion="host subprocess fallback is labelled microVM/container isolated",
            ),
            DeferredFeatureEvidence(
                id="host-admission-platform-probe",
                state="testable",
                required_evidence=("fresh presence/power/headroom samples", "probe-failure deny receipt", "platform adapter provenance"),
                required_test_harness=("HostAdmissionGate fake probes", "platform integration test"),
                kill_criterion="unknown/stale/probe-error observation permits discretionary work",
            ),
            DeferredFeatureEvidence(
                id="remote-mcp-behavioral-attestation",
                state="testable",
                required_evidence=("adapter-specific behavior observations", "egress/process fault injection", "terminal/unknown effect receipts"),
                required_test_harness=("isolated MCP adapter fault suite", "schema/pin plus behavior mismatch tests"),
                kill_criterion="schema pinning alone is reported as behavioral attestation",
            ),
            DeferredFeatureEvidence(
                id="external-event-delivery",
                state="testable",
                required_evidence=("destination authorization", "idempotency", "durable retry/unknown outcome", "restore drill"),
                required_test_harness=("local HTTP sink fault injector", "delivery replay/duplicate/timeout matrix"),
                kill_criterion="HTTP transport success is reported as durable cloud delivery semantics",
            ),
            DeferredFeatureEvidence(
                id="model-generated-tests-skills-policies",
                state="negative-control",
                required_evidence=("protected oracle agreement", "held-out regression evidence", "human/explicit promotion"),
                required_test_harness=("branch-local generated artifact tests", "promotion oracle and held-out campaign"),
                kill_criterion="model-authored artifact becomes authority or default policy without protected evaluation",
            ),
            DeferredFeatureEvidence(
                id="generic-semantic-response-cache",
                state="negative-control",
                required_evidence=("effect-free task class", "exact semantic equivalence proof", "staleness/side-effect fault results"),
                required_test_harness=("cache poisoning/staleness suite", "effectful-task exclusion suite"),
                kill_criterion="cache replay bypasses coding/effect verification or reads stale workspace state",
            ),
            DeferredFeatureEvidence(
                id="generic-provider-hedging-or-auto-switching",
                state="negative-control",
                required_evidence=("explicit user route policy", "cancellation/billing proof", "equal-config cost/safety evaluation"),
                required_test_harness=("RouteAuthority regression tests", "provider cancellation canary"),
                kill_criterion="concrete requested model is replaced or parallel billable requests are silently issued",
            ),
            DeferredFeatureEvidence(
                id="autonomous-portfolio-generation",
                state="testable",
                required_evidence=("explicit ambiguity declaration", "same-frame candidates", "held-out deterministic evaluation", "no automatic merge"),
                required_test_harness=("BranchCandidatePortfolio", "EqualConfigCampaign", "protected-test integrity suite"),
                kill_criterion="candidate diversity score is treated as correctness or candidates are merged automatically",
            ),
            DeferredFeatureEvidence(
                id="focused-test-policy-promotion",
                state="testable",
                required_evidence=("mutation/seeded defect recall", "full-suite comparison", "constitutional floor coverage"),
                required_test_harness=("TestImpactCalibrator", "offline mutation corpus"),
                kill_criterion="focused-only verification is promoted without calibrated recall and full fallback",
            ),
            DeferredFeatureEvidence(
                id="independent-model-checker",
                state="testable",
                required_evidence=("transcript-minimized input", "read-only capability", "human/deterministic calibration", "false-positive/negative study"),
                required_test_harness=("IndependentVerificationBrief", "CheckerReviewLedger", "held-out review corpus"),
                kill_criterion="checker verdict gains merge/promotion authority without deterministic evidence",
            ),
        )

    @classmethod
    def by_id(cls, feature_id: str) -> DeferredFeatureEvidence:
        for item in cls.entries():
            if item.id == feature_id:
                return item
        raise KeyError(feature_id)
