"""Focused-coder deterministic scaffolds, adapters, and contract normalization."""
from __future__ import annotations

import os
import pathlib
import re
from typing import Any, Dict, List, Optional

from .quality import ChangeTarget, TaskContract


class FocusedCapsuleMixin:
        def _deterministic_domain_scaffold(self, contract: TaskContract, target: ChangeTarget) -> Optional[Dict[str, Any]]:
            """Return only a registered deterministic scaffold.

            Scaffold generation is an opt-in deterministic shortcut, not a model
            privilege.  Unknown cases fall through to normal patch synthesis; no
            legacy body or silent import failure changes task authority.
            """
            if os.environ.get("CHIMERA_DISABLE_DOMAIN_SCAFFOLDS") == "1":
                return None
            from .scaffolds import ScaffoldRegistry
            return ScaffoldRegistry(self.root).match(contract, target)
        def _deterministic_adapter_payload(self, contract: TaskContract, target: ChangeTarget,
                                           branch: Optional[str] = None) -> Optional[Dict[str, Any]]:
            """Generate low-entropy framework glue; leave domain logic to the model."""
            if target.path != "chimera/cli.py" or target.mode != "edit":
                return None
            quoted_commands = re.findall(
                r"\bcommand\s+[\"'`](?:chimera\s+)?([a-z][a-z0-9_-]*)[\"'`]",
                contract.task.lower(),
            )
            if quoted_commands:
                command = quoted_commands[-1]
            else:
                match = re.search(r"\bcommand\s+(?:chimera\s+)?([a-z][a-z0-9_-]*)", contract.task.lower())
                if not match or match.group(1) in {"and", "with", "root", "the"}:
                    return None
                command = match.group(1)
            created = [candidate for candidate in contract.targets if candidate.mode == "create" and candidate.path.startswith("chimera/") and candidate.path.endswith(".py")]
            if not created and self._task_contract:
                created = [candidate for candidate in self._task_contract.targets if candidate.mode == "create" and candidate.path.startswith("chimera/") and candidate.path.endswith(".py")]
            if not created:
                return None
            module_path = created[0].path
            symbols = contract.required_symbols.get(module_path, [])
            if not symbols and self._task_contract:
                symbols = self._task_contract.required_symbols.get(module_path, [])
            if not symbols:
                return None
            symbol = symbols[0]
            module = pathlib.PurePosixPath(module_path).stem
            function_name = re.sub(r"[^a-z0-9_]", "_", command) + "_cmd"
            required_positional = 0
            if branch:
                try:
                    import ast
                    module_source = self.workspace.read(branch, module_path).decode("utf-8", errors="ignore")
                    tree = ast.parse(module_source)
                    function = next(
                        node for node in tree.body
                        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == symbol
                    )
                    positional = len(function.args.posonlyargs) + len(function.args.args)
                    required_positional = max(0, positional - len(function.args.defaults))
                except Exception:
                    required_positional = 0
            if required_positional:
                default_objective = "Build a service with database, authentication, API, audit logging, tests, docs, and deployment."
                argument_decorator = f'@click.argument("objective", required=False, default={default_objective!r})\n'
                signature = "objective"
                invocation = f"{symbol}(objective)"
            else:
                argument_decorator = ""
                signature = ""
                invocation = f"{symbol}()"
            block = (
                f'\n@main.command("{command}")\n'
                f'{argument_decorator}'
                f'def {function_name}({signature}):\n'
                f'    """Run the {command} workflow and print its evidence report."""\n'
                f'    from .{module} import {symbol}\n'
                f'    report = {invocation}\n'
                f'    click.echo("{command.upper()} WAL evidence")\n'
                f'    click.echo(str(report))\n'
            )
            current = (self.root / target.path).read_text(encoding="utf-8", errors="ignore")
            anchor = '\nif __name__ == "__main__":\n' if '\nif __name__ == "__main__":\n' in current else "\nif __name__ == '__main__':\n"
            if anchor not in current:
                return None
            return {
                "summary": f"deterministic Click adapter for {command}", "files": [], "edits": [],
                "insertions": [{"path": target.path, "anchor": anchor, "position": "before", "content": block}],
            }
        def _normalise_contract_values(self, payload: Dict[str, Any], contract: TaskContract) -> List[str]:
            """Apply deterministic value-format postconditions to complete Python files."""
            import ast
            changed: List[str] = []
            for item in payload.get("files", []) if isinstance(payload, dict) else []:
                if not isinstance(item, dict) or not isinstance(item.get("content"), str):
                    continue
                path = item.get("path", "")
                prefixes = contract.required_prefixes.get(path, {})
                if not prefixes or not str(path).endswith(".py"):
                    continue
                try:
                    tree = self._parse_python_safely(item["content"], path)
                except SyntaxError:
                    continue

                class PrefixTransformer(ast.NodeTransformer):
                    changed = False

                    def visit_Dict(self, node):
                        self.generic_visit(node)
                        for index, key_node in enumerate(node.keys):
                            if not isinstance(key_node, ast.Constant) or key_node.value not in prefixes:
                                continue
                            prefix = prefixes[key_node.value]
                            value = node.values[index]
                            rendered = ast.unparse(value)
                            if repr(prefix) in rendered or (prefix == "hier-" and rendered.endswith(".id")):
                                continue
                            node.values[index] = ast.BinOp(
                                left=ast.Constant(prefix), op=ast.Add(),
                                right=ast.Call(func=ast.Name("str", ast.Load()), args=[value], keywords=[]),
                            )
                            self.changed = True
                        return node

                transformer = PrefixTransformer()
                transformed = transformer.visit(tree)
                if transformer.changed:
                    ast.fix_missing_locations(transformed)
                    item["content"] = ast.unparse(transformed).strip() + "\n"
                    changed.append(f"{path}:prefix-normalized")
            return changed
