
"""
Evolution — HarnessX AEGIS + SIA co-evolution + VeRO + AHE

Per PRD §7.6: Two loops sharing replay buffer (model, harness, outcome):
1. Harness loop (AEGIS): Digester -> Planner -> Evolver -> Critic (substitution algebra, seesaw)
2. Model loop (SIA/GRPO): harness-oblivious GRPO via verl on same buffer, interleaving

Processors (9 dimensions from HarnessX):
 guidance, memory, reflection, delegation, verification, tool_use, context, planning, recovery

Also:
- VeRO 2602.22480: Versioning/Rewards/Observations outer harness
- AHE 2604.25850: Component/experience/decision observability
- Better-harness: module_attr/workspace_file minimal surfaces

Simulates GRPO weight update as reward-weighted config tuning (verl backend stub).
"""
from __future__ import annotations
import json, pathlib, time, copy, random, os
from typing import List, Dict, Any, Optional, Mapping
from .replay import ReplayBuffer
try:
    from .drift import CPEPreserver, CuratorGate, DriftMonitor
    _has_drift=True
except ImportError:
    # Optional module absence is explicit; runtime evolution receipts record
    # any later degraded path that would have used it.
    _has_drift=False

PROCESSORS = ["guidance","memory","reflection","delegation","verification","tool_use","context","planning","recovery"]

# Better-harness minimal surfaces (LangChain deepagents)
BETTER_SURFACES = ["module_attr", "workspace_file"]

class SIAWrapper:
    """SIA 2605.27276: harness+weight shared replay + GRPO via verl-project/uni-agent"""
    def __init__(self, buffer: ReplayBuffer):
        self.buffer=buffer

    def grpo_update(self, variant: str) -> Dict:
        """
        Estimate a hypothetical GRPO update from verified replay. No weights
        are changed unless a real backend is configured (currently unavailable).
        """
        entries=self.buffer.query(harness_variant=variant, trusted_only=True)
        if not entries:
            entries=self.buffer.query(trusted_only=True)
        # Reward-weighted: higher reward -> higher grad
        avg_reward=sum(e["reward"] for e in entries)/len(entries) if entries else 0.5
        # Simulate GRPO via verl: learning rate * advantage
        advantage=avg_reward - 0.5
        lr=0.01
        delta={
            "kind": "offline-estimate-no-weight-update",
            "advantage": advantage, "lr_assumption": lr,
            "estimated_weight_delta": advantage*lr, "samples": len(entries),
            "weights_changed": False,
            "reason": "verl/GRPO backend is not configured",
        }
        return delta

class VeROOuter:
    """VeRO 2602.22480: Versioning/Rewards/Observations outer harness"""
    def __init__(self, root: pathlib.Path):
        self.root=pathlib.Path(root).resolve()
        self.versions_dir=self.root / ".chimera" / "vero"
        self.versions_dir.mkdir(parents=True, exist_ok=True)

    def record_version(self, variant: str, reward: float, observations: Dict) -> str:
        ver_id=f"vero-{variant}-{int(time.time())}"
        data={"version": ver_id, "variant": variant, "reward": reward, "observations": observations, "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        (self.versions_dir / f"{ver_id}.json").write_text(json.dumps(data, indent=2))
        return ver_id

    def list_versions(self) -> List[Dict]:
        out=[]
        for p in self.versions_dir.glob("*.json"):
            out.append(json.loads(p.read_text()))
        return sorted(out, key=lambda x: x["ts"])

class AHEObservability:
    """AHE 2604.25850: Component/experience/decision observability"""
    def __init__(self, buffer: ReplayBuffer):
        self.buffer=buffer

    def component_trace(self, entry: Dict) -> Dict:
        return {"component": entry.get("harness_variant"), "experience": entry.get("task"), "decision": entry.get("reward")}

    def report(self, limit: int=5) -> List[Dict]:
        entries=self.buffer.query()[-limit:]
        return [self.component_trace(e) for e in entries]

class EvolutionEngine:
    def __init__(self, root: pathlib.Path = pathlib.Path("."), buffer: Optional[ReplayBuffer]=None,
                 promotion_evaluator=None, protected_core=None):
        self.root = pathlib.Path(root)
        self.buffer = buffer or ReplayBuffer(root)
        if protected_core is None and (self.root/".chimera"/"governance"/"protected_manifest.json").exists():
            from .protected_core import ProtectedCore
            protected_core=ProtectedCore(self.root,{})
        self.protected_core=protected_core
        self.variant_dir = self.root / ".chimera" / "variants"
        self.variant_dir.mkdir(parents=True, exist_ok=True)
        self.max_variants = 5
        self.sia=SIAWrapper(self.buffer)
        self.vero=VeROOuter(root)
        self.ahe=AHEObservability(self.buffer)
        if promotion_evaluator is None:
            from .artifacts import ContentAddressedArtifactStore
            from .objective import ObjectivePolicy, PromotionEvaluator
            store = ContentAddressedArtifactStore(self.root)

            def resolve_evidence(ref: str) -> bool:
                if ref.startswith("artifact:"):
                    digest = ref.removeprefix("artifact:")
                    try:
                        return store.has(digest)
                    except (ValueError, OSError):
                        return False
                if ref.startswith("replay:"):
                    target = ref.removeprefix("replay:")
                    return any(entry.get("entry_hash") == target for entry in self.buffer.query(trusted_only=True))
                return False

            promotion_evaluator = PromotionEvaluator(ObjectivePolicy.default(), resolve_evidence)
        self.promotion_evaluator = promotion_evaluator

    def digest(self, limit: int=50) -> Dict:
        entries = self.buffer.query(trusted_only=True)[-limit:]
        if not entries:
            return {"summary": "no data", "fail_reasons": [], "token_avg": 0, "ahe": []}
        fail_reasons=[]
        total_tokens=0
        for e in entries:
            total_tokens+=len(json.dumps(e.get("trace",[])))
            if e["reward"] < 0.6:
                trace_str = json.dumps(e["trace"]).lower()
                if "source url" in trace_str or "url" in trace_str: fail_reasons.append("missing citations")
                if "outsideallow" in trace_str or "denied" in trace_str: fail_reasons.append("capability deny")
                if "timeout" in trace_str: fail_reasons.append("timeout")
                if "hallucinated" in trace_str: fail_reasons.append("hallucinated")
        from collections import Counter
        top = Counter(fail_reasons).most_common(3)
        return {
            "total": len(entries),
            "avg_reward": sum(e["reward"] for e in entries)/len(entries),
            "fail_reasons": top,
            "by_variant": self.buffer.variant_scores(),
            "ahe": self.ahe.report(limit=3),
            "vero_versions": len(self.vero.list_versions()),
            "token_avg": total_tokens/max(1,len(entries)),
        }

    def plan_adaptation(self, digest: Dict) -> List[Dict]:
        mapping={
            "missing citations": {"processor": "verification", "action": "strengthen verification_criteria to require 2+ URLs (better-harness workspace_file)", "delta": {"verification": {"strictness": "high"}}, "surface": "workspace_file"},
            "capability deny": {"processor": "tool_use", "action": "expand fs allowlist or tighten effect declarations (Etas)", "delta": {"tool_use": {"allow_more": False}}, "surface": "module_attr"},
            "timeout": {"processor": "planning", "action": "reduce DAG breadth, increase timeout (VMAO diminishing)", "delta": {"planning": {"max_parallel": 2}}, "surface": "workspace_file"},
            "hallucinated": {"processor": "context", "action": "graph pruning + RAG (InfiGraph)", "delta": {"context": {"prune": True}}, "surface": "module_attr"},
        }
        plans=[]
        for reason, count in digest.get("fail_reasons", []):
            if reason in mapping:
                plans.append({"reason": reason, "count": count, **mapping[reason]})
        if not plans:
            plans.append({
                "reason": "insufficient_verified_evidence", "count": 0,
                "processor": "reflection",
                "action": "collect verified failures before changing behavior",
                "delta": {"reflection": {"observe_only": True}},
                "surface": "workspace_file",
            })
        # CPE Fisher-regularized adaptation: dampen protected processors (2605.09315)
        if _has_drift:
            try:
                cpe = CPEPreserver(self.root)
                plans = cpe.fisher_regularize(plans)
            except Exception as exc:
                from .degradation_ledger import confess_degradation
                confess_degradation(self.root, "evolution_regularization", "evolution.plan", type(exc).__name__)
        return plans

    def evolve(self, adaptation_plan: List[Dict], base_variant: str = "default") -> str:
        """Stage a typed harness patch on a transactional candidate branch.

        Candidates remain isolated until the critic accepts deterministic
        benchmark evidence.
        """
        import ast
        import uuid
        from .branch import TransactionalWorkspace

        new_id = f"variant-{uuid.uuid4().hex[:10]}"
        branch_name = f"evolve-{new_id}"
        workspace = TransactionalWorkspace(self.root)
        workspace.branch(branch_name, from_branch="main")
        base_path = self.variant_dir / f"{base_variant}.json"
        if base_path.exists():
            base_config = json.loads(base_path.read_text())
        else:
            base_config = {
                "id": base_variant,
                "processors": {processor: 0.5 for processor in PROCESSORS},
                "surfaces": {surface: 0.5 for surface in BETTER_SURFACES},
            }
        config = copy.deepcopy(base_config)
        config.update({
            "id": new_id, "parent": base_variant, "candidate_branch": branch_name,
            "created": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "adaptation_plan": adaptation_plan, "status": "staged",
        })
        patches: List[str] = []
        contracts: List[Dict[str, Any]] = []
        for plan in adaptation_plan:
            processor = plan.get("processor")
            surface = plan.get("surface")
            if processor not in PROCESSORS or surface not in BETTER_SURFACES:
                continue
            if plan.get("cpe_dampened"):
                contracts.append({"processor": processor, "status": "protected", "reason": plan.get("cpe_reason")})
                continue
            target = f"chimera/processors/{processor}.py"
            safe_plan = json.dumps({
                "reason": plan.get("reason"), "action": plan.get("action"),
                "delta": plan.get("delta", {}), "surface": surface,
            }, sort_keys=True)
            content = (
                f'"""Evidence-gated AEGIS processor: {processor}.\n\n'
                f'Variant: {new_id}; parent: {base_variant}.\n'
                'This module is staged transactionally and activated only after held-out tests.\n"""\n'
                'from __future__ import annotations\nimport json\n\n'
                f'PROCESSOR = {processor!r}\nVARIANT = {new_id!r}\n'
                'EFFECT_ROW = {"fs": ["chimera/**", "tests/**"], "net": []}\n'
                f'ADAPTATION = json.loads({safe_plan!r})\n\n'
                'def handle(trace):\n'
                '    """Return a side-effect-free, auditable processor decision."""\n'
                '    return {"processor": PROCESSOR, "variant": VARIANT, "adaptation": ADAPTATION, "trace_events": len(trace or [])}\n'
            )
            ast.parse(content, filename=target)
            workspace.write(branch_name, target, content)
            patches.append(target)
            contracts.append({
                "processor": processor, "target": target,
                "effect_row": {"fs": ["chimera/**", "tests/**"], "net": []},
                "prediction": plan.get("action"), "protected": False,
            })
            config["processors"][processor] = min(1.0, config["processors"].get(processor, 0.5) + 0.1)
            if surface in config.get("surfaces", {}):
                config["surfaces"][surface] = min(1.0, config["surfaces"].get(surface, 0.5) + 0.1)

        diff = workspace.diff(branch_name)
        config["substitution_algebra"] = {
            "typed_patch": bool(patches), "real_files": patches, "contracts": contracts,
            "diff_hash": diff.get("id"), "ops": diff.get("ops", []),
        }
        config["real_patch"] = patches
        (self.variant_dir / f"{new_id}.json").write_text(json.dumps(config, indent=2))
        return new_id

    def critic(self, new_variant: str, before: Any, after: Any, *, oracle_result: Mapping[str, Any] | None = None) -> tuple[bool, str]:
        """Promote only from structured, sealed, evidence-resolvable reports.

        Legacy task->score maps are intentionally no longer promotion evidence:
        they omit hard constraints, corpus identity, query receipts, and
        resolvable per-task evidence.
        """
        from .branch import TransactionalWorkspace
        from .objective import EvaluationReport

        variant_path = self.variant_dir / f"{new_variant}.json"
        if not variant_path.exists():
            return False, f"candidate {new_variant} missing"
        config = json.loads(variant_path.read_text())
        if os.environ.get("CHIMERA_EVOLUTION_REQUIRE_ORACLE") == "1":
            if not isinstance(oracle_result, Mapping):
                return False, "promotion oracle receipt is required"
            if str(oracle_result.get("candidate_id", "")) != new_variant:
                return False, "promotion oracle candidate does not match staged variant"
            if not bool(oracle_result.get("accepted")):
                return False, "promotion oracle rejected candidate"
        branch = config.get("candidate_branch")
        workspace = TransactionalWorkspace(self.root)
        decision = None
        try:
            baseline = before if isinstance(before, EvaluationReport) else EvaluationReport.model_validate(before)
            challenger = after if isinstance(after, EvaluationReport) else EvaluationReport.model_validate(after)
        except Exception:
            baseline = challenger = None

        if baseline is None or challenger is None:
            ok, message = False, (
                "no structured sealed benchmark evidence; legacy score maps cannot promote; fail closed"
            )
        elif challenger.candidate_id != new_variant:
            ok, message = False, (
                f"challenger report candidate {challenger.candidate_id!r} does not match staged variant {new_variant!r}"
            )
        else:
            known_receipts = {
                entry.get("data", {}).get("receipt")
                for entry in workspace.wal.replay(kind="corpus_query")
            }
            missing_receipts = [
                report.query_receipt for report in (baseline, challenger)
                if report.query_receipt not in known_receipts
            ]
            if missing_receipts:
                ok, message = False, "sealed corpus query receipt is not present in the WAL"
            else:
                decision = self.promotion_evaluator.compare(baseline, challenger)
                ok, message = decision.accepted, decision.reason

        if ok and self.protected_core is not None:
            core_status=self.protected_core.verify()
            if not core_status["valid"]:ok=False;message="protected core does not match signed manifest"
            else:
                protected=set(self.protected_core.load().entries);delta=workspace.diff(branch);touched={item.get("path") for item in delta.get("ops",[])}
                if protected&touched:ok=False;message=f"candidate touches protected core: {sorted(protected&touched)}"
                else:
                    suspicious=[]
                    markers=("private_key","signing key","quorum","sovereign gate","veto","trust anchor")
                    for item in delta.get("ops",[]):
                        path=item.get("path","")
                        if item.get("op")=="write" and path not in protected:
                            try:text=workspace.read(branch,path).decode("utf-8",errors="ignore").lower()
                            except Exception:text=""
                            if any(marker in text for marker in markers):suspicious.append(path)
                    if suspicious:ok=False;message=f"new safety-relevant component requires human manifest classification: {sorted(suspicious)}"
        if ok and decision is not None and baseline is not None and challenger is not None:
            commit_hash = workspace.commit(branch, f"evolution: activate {new_variant}")
            decision_record = {
                **decision.model_dump(mode="json"), "decision_hash": decision.decision_hash,
            }
            config.update({
                "status": "accepted", "commit": commit_hash,
                "baseline_report": baseline.report_hash,
                "challenger_report": challenger.report_hash,
                "promotion_decision": decision_record,
            })
            variant_path.write_text(json.dumps(config, indent=2))
            reward = sum(item.score for item in challenger.outcomes) / len(challenger.outcomes)
            self.vero.record_version(new_variant, reward, {
                "baseline_report": baseline.report_hash,
                "challenger_report": challenger.report_hash,
                "decision_hash": decision.decision_hash,
                "commit": commit_hash,
            })
            workspace.wal.append("evolution_promoted", {
                "variant": new_variant, "commit": commit_hash,
                "decision_hash": decision.decision_hash,
                "corpus_hash": challenger.corpus_hash,
                "cycle_id": challenger.cycle_id,
            })
            return True, f"accepted {new_variant}: {message}; commit={commit_hash}"

        if branch in workspace.list_branches():
            workspace.abort(branch)
        rejection = {
            "status": "rejected", "rejection": message,
            "baseline_report": baseline.report_hash if baseline is not None else None,
            "challenger_report": challenger.report_hash if challenger is not None else None,
            "promotion_decision": (
                {**decision.model_dump(mode="json"), "decision_hash": decision.decision_hash}
                if decision is not None else None
            ),
        }
        config.update(rejection)
        variant_path.write_text(json.dumps(config, indent=2))
        return False, f"rejected {new_variant}: {message}"

    def run_iteration(self, benchmark: Optional[callable] = None) -> Dict:
        digest = self.digest()
        plan = self.plan_adaptation(digest)
        base = self.buffer.best_variant() or "default"
        new_variant = self.evolve(plan, base)
        sia_delta = self.sia.grpo_update(new_variant)
        if callable(benchmark):
            before = benchmark(base)
            after = benchmark(new_variant)
        else:
            before, after = {}, {}
        accepted, message = self.critic(new_variant, before, after)
        return {
            "digester": digest, "plan": plan, "new_variant": new_variant,
            "before": before, "after": after, "accepted": accepted, "msg": message,
            "sia": sia_delta, "ahe": self.ahe.report(),
        }

    def evolve_loop(self, iterations: int=3, benchmark: Optional[callable]=None) -> List[Dict]:
        results=[]
        for i in range(iterations):
            results.append(self.run_iteration(benchmark))
        return results
