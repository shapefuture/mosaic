"""Fail-closed versioned migration registry for durable Chimera envelopes."""

from __future__ import annotations

import pathlib
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .core_primitives import atomic_write_json, digest_json


class DurableEnvelope(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)
    schema_name: str = Field(alias="schema", min_length=1, max_length=200)
    version: int = Field(ge=1)
    payload: dict[str, Any]
    payload_digest: str

    @classmethod
    def create(cls, schema: str, version: int, payload: Mapping[str, Any]):
        value = dict(payload)
        return cls(
            schema=schema,
            version=version,
            payload=value,
            payload_digest=digest_json(value),
        )

    def verify(self) -> None:
        if digest_json(self.payload) != self.payload_digest:
            raise ValueError("durable envelope payload digest mismatch")


Migration = Callable[[dict[str, Any]], dict[str, Any]]


@dataclass(frozen=True)
class MigrationReceipt:
    schema: str
    from_version: int
    to_version: int
    steps: tuple[str, ...]
    before_digest: str
    after_digest: str


class SchemaMigrator:
    def __init__(self) -> None:
        self._steps: dict[tuple[str, int], Migration] = {}
        self._current: dict[str, int] = {}

    def declare(self, schema: str, current_version: int) -> None:
        if current_version < 1:
            raise ValueError("schema version must be positive")
        self._current[schema] = int(current_version)

    def register(self, schema: str, from_version: int, migrate: Migration) -> None:
        key = (schema, int(from_version))
        if key in self._steps:
            raise ValueError(f"duplicate migration step: {schema} v{from_version}")
        self._steps[key] = migrate

    def migrate(
        self, envelope: DurableEnvelope
    ) -> tuple[DurableEnvelope, MigrationReceipt]:
        envelope.verify()
        try:
            target = self._current[envelope.schema_name]
        except KeyError as exc:
            raise ValueError(f"unknown durable schema: {envelope.schema_name}") from exc
        if envelope.version > target:
            raise ValueError(
                f"durable schema {envelope.schema_name} v{envelope.version} is newer than supported v{target}"
            )
        payload = dict(envelope.payload)
        version = envelope.version
        steps = []
        while version < target:
            try:
                migration = self._steps[(envelope.schema_name, version)]
            except KeyError as exc:
                raise ValueError(
                    f"missing migration for {envelope.schema_name} v{version}->v{version + 1}"
                ) from exc
            payload = migration(dict(payload))
            version += 1
            steps.append(f"v{version - 1}->v{version}")
        result = DurableEnvelope.create(envelope.schema_name, version, payload)
        return result, MigrationReceipt(
            schema=envelope.schema_name,
            from_version=envelope.version,
            to_version=version,
            steps=tuple(steps),
            before_digest=envelope.payload_digest,
            after_digest=result.payload_digest,
        )

    def load_and_migrate(
        self,
        path: pathlib.Path,
        *,
        persist: bool = False,
    ) -> tuple[DurableEnvelope, MigrationReceipt]:
        envelope = DurableEnvelope.model_validate_json(pathlib.Path(path).read_text())
        result, receipt = self.migrate(envelope)
        if persist and result != envelope:
            atomic_write_json(
                pathlib.Path(path), result.model_dump(mode="json", by_alias=True)
            )
        return result, receipt
