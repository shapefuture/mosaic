"""Optional DBOS/PostgreSQL implementation of Chimera's durable workflow port.

Each Chimera workflow is represented by an immutable DBOS root workflow plus
idempotently named checkpoint and terminal-command workflows. This event-sourced
shape avoids keeping an executor thread blocked merely because a logical Chimera
workflow is still running. Checkpoint payloads remain in Chimera CAS; DBOS stores
only exact content-addressed references and immutable tenant/input identity.

External effects are deliberately *not* executed by this adapter. Callers must
continue to use Chimera's outbox and preserve unknown outcomes. DBOS currently
owns a process-global runtime, so only one adapter may be live per process.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import threading
import time
import uuid
from typing import Any, Mapping

from pydantic import BaseModel, ConfigDict, Field

from .artifacts import ContentAddressedArtifactStore
from .durable_workflow import WorkflowRecord
from .wait_registry import WaitKind, WaitRecord, WaitRegistry


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class DBOSAdapterConfig(_FrozenModel):
    system_database_url: str = Field(min_length=1)
    application_name: str = Field(default="chimera_durable", min_length=1, max_length=200)
    application_version: str = Field(default="chimera-durable-adapter-v1", min_length=1, max_length=200)
    executor_id: str = Field(default="chimera-local", min_length=1, max_length=200)
    system_pool_size: int = Field(default=20, ge=2, le=1_000)
    polling_concurrency: int = Field(default=5, ge=1, le=1_000)
    use_listen_notify: bool = True
    acknowledgement_timeout_seconds: float = Field(default=30.0, ge=0.1, le=600)


class DBOSDurableWorkflowError(RuntimeError):
    pass


class DBOSVersionDriftError(DBOSDurableWorkflowError):
    pass


class DBOSTenantMismatchError(DBOSDurableWorkflowError):
    pass


class DBOSDurableWorkflowPort:
    """DBOS-backed start/checkpoint/recover/wait/finish/cancel contract."""

    adapter_id = "dbos-postgres-durable-workflow-v1"
    _instance_lock = threading.RLock()
    _active_owner: int | None = None
    _ROOT_NAME = "chimera_durable_root_v1"
    _CHECKPOINT_NAME = "chimera_durable_checkpoint_v1"
    _TERMINAL_NAME = "chimera_durable_terminal_v1"

    def __init__(self, root: pathlib.Path, config: DBOSAdapterConfig, *, artifact_store=None) -> None:
        self.root = pathlib.Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.config = config
        self.artifacts = artifact_store or ContentAddressedArtifactStore(self.root)
        self.waits = WaitRegistry(self.root)
        self._closed = False
        self._initialize()

    def _initialize(self) -> None:
        with self._instance_lock:
            if self.__class__._active_owner is not None:
                raise DBOSDurableWorkflowError("DBOS has a process-global runtime; close the existing adapter first")
            try:
                from dbos import DBOS
            except ImportError as exc:  # pragma: no cover - optional dependency
                raise DBOSDurableWorkflowError("install the 'durable-postgres' extra to use DBOS") from exc
            self.__class__._active_owner = id(self)
            try:
                DBOS(config={
                    "name": self.config.application_name,
                    "application_version": self.config.application_version,
                    "executor_id": self.config.executor_id,
                    "system_database_url": self.config.system_database_url,
                    "sys_db_pool_size": self.config.system_pool_size,
                    "sys_db_polling_concurrency": self.config.polling_concurrency,
                    "use_listen_notify": self.config.use_listen_notify,
                    "console_log_level": "ERROR",
                })

                @DBOS.workflow(name=self._ROOT_NAME)
                def root_workflow(workflow_type: str, input_identity: str, tenant_key: str | None) -> dict[str, Any]:
                    return {
                        "workflow_type": workflow_type,
                        "input_identity": input_identity,
                        "tenant_key": tenant_key,
                        "logical_state": "running",
                        "adapter_version": "1",
                    }

                @DBOS.workflow(name=self._CHECKPOINT_NAME)
                def checkpoint_workflow(
                    parent_id: str,
                    checkpoint_ref: str,
                    tenant_key: str | None,
                    command_id: str,
                ) -> dict[str, Any]:
                    return {
                        "operation": "checkpoint",
                        "parent_id": parent_id,
                        "checkpoint_ref": checkpoint_ref,
                        "tenant_key": tenant_key,
                        "command_id": command_id,
                    }

                @DBOS.workflow(name=self._TERMINAL_NAME)
                def terminal_workflow(
                    parent_id: str,
                    state: str,
                    checkpoint_ref: str | None,
                    tenant_key: str | None,
                    command_id: str,
                ) -> dict[str, Any]:
                    return {
                        "operation": "terminal",
                        "parent_id": parent_id,
                        "state": state,
                        "checkpoint_ref": checkpoint_ref,
                        "tenant_key": tenant_key,
                        "command_id": command_id,
                    }

                self._root_workflow = root_workflow
                self._checkpoint_workflow = checkpoint_workflow
                self._terminal_workflow = terminal_workflow
                DBOS.launch()
            except Exception:
                try:
                    DBOS.destroy(destroy_registry=True)
                finally:
                    self.__class__._active_owner = None
                raise

    @staticmethod
    def _command_id(operation: str, idempotency_key: str) -> str:
        raw = json.dumps([operation, idempotency_key], separators=(",", ":")).encode()
        return hashlib.sha256(raw).hexdigest()

    @staticmethod
    def _operation_workflow_id(parent_id: str, operation: str, command_id: str) -> str:
        return f"{parent_id}::{operation}::{command_id}"

    def _assert_open(self) -> None:
        if self._closed:
            raise DBOSDurableWorkflowError("DBOS durable adapter is closed")

    def start(
        self,
        *,
        workflow_type: str,
        input_identity: str,
        workflow_id: str | None = None,
        tenant_key: str | None = None,
    ) -> WorkflowRecord:
        self._assert_open()
        from dbos import DBOS, SetWorkflowID

        identifier = workflow_id or "workflow:" + uuid.uuid4().hex
        with SetWorkflowID(identifier):
            handle = DBOS.start_workflow(
                self._root_workflow, str(workflow_type), str(input_identity), tenant_key,
            )
        metadata = handle.get_result(polling_interval_sec=0.05)
        expected = {
            "workflow_type": str(workflow_type),
            "input_identity": str(input_identity),
            "tenant_key": tenant_key,
            "logical_state": "running",
            "adapter_version": "1",
        }
        if metadata != expected:
            raise DBOSDurableWorkflowError("duplicate workflow id is bound to different immutable input")
        status = handle.get_status()
        created = (float(status.created_at) / 1_000.0) if status.created_at else time.time()
        return WorkflowRecord(identifier, "running", created, tenant_key=tenant_key)

    def checkpoint(
        self,
        workflow: WorkflowRecord,
        state: Mapping[str, Any],
        *,
        idempotency_key: str | None = None,
        tenant_key: str | None = None,
    ) -> WorkflowRecord:
        self._assert_open()
        from dbos import DBOS, SetWorkflowID

        current = self.recover(workflow.id, tenant_key=tenant_key)
        if current is None or current.state != "running":
            raise DBOSDurableWorkflowError("cannot checkpoint a missing or terminal workflow")
        ref = self.artifacts.put(
            json.dumps(dict(state), sort_keys=True, separators=(",", ":"), default=str),
            media_type="application/vnd.chimera.workflow-checkpoint+json",
            provenance={"workflow": workflow.id, "adapter": self.adapter_id},
        )
        checkpoint_ref = "artifact:" + ref.digest
        key = idempotency_key or f"checkpoint:{workflow.id}:{ref.digest}"
        command_id = self._command_id("checkpoint", key)
        operation_id = self._operation_workflow_id(workflow.id, "checkpoint", command_id)
        with SetWorkflowID(operation_id):
            handle = DBOS.start_workflow(
                self._checkpoint_workflow,
                workflow.id, checkpoint_ref, tenant_key, command_id,
            )
        acknowledgement = handle.get_result(polling_interval_sec=0.05)
        if not isinstance(acknowledgement, dict) or acknowledgement.get("checkpoint_ref") != checkpoint_ref:
            raise DBOSDurableWorkflowError(
                "checkpoint idempotency key was previously bound to different checkpoint bytes"
            )
        return WorkflowRecord(workflow.id, "running", current.created_at, checkpoint_ref, tenant_key)

    def wait(
        self,
        workflow: WorkflowRecord,
        *,
        kind: WaitKind,
        target: Any,
        owner: str,
        timeout_seconds: float,
        tenant_key: str | None = None,
    ) -> WaitRecord:
        self._assert_open()
        current = self.recover(workflow.id, tenant_key=tenant_key)
        if current is None or current.state != "running":
            raise DBOSDurableWorkflowError("cannot wait on a missing or terminal workflow")
        return self.waits.register(
            run_id=workflow.id, kind=kind, target=target,
            owner=owner, timeout_seconds=timeout_seconds,
        )

    def finish(
        self,
        workflow: WorkflowRecord,
        *,
        state: str,
        idempotency_key: str | None = None,
        tenant_key: str | None = None,
    ) -> WorkflowRecord:
        self._assert_open()
        if state not in {"completed", "failed", "cancelled"}:
            raise ValueError("workflow terminal state must be completed, failed, or cancelled")
        from dbos import DBOS, SetWorkflowID

        current = self.recover(workflow.id, tenant_key=tenant_key)
        if current is None:
            raise DBOSDurableWorkflowError("cannot finish a missing workflow")
        if current.state != "running":
            if current.state != state:
                raise DBOSDurableWorkflowError("terminal workflow cannot transition to a different state")
            return current
        key = idempotency_key or f"finish:{workflow.id}:{state}"
        command_id = self._command_id("terminal", key)
        operation_id = self._operation_workflow_id(workflow.id, "terminal", command_id)
        with SetWorkflowID(operation_id):
            handle = DBOS.start_workflow(
                self._terminal_workflow,
                workflow.id, state, current.checkpoint_ref, tenant_key, command_id,
            )
        result = handle.get_result(polling_interval_sec=0.05)
        if not isinstance(result, dict) or result.get("state") != state:
            raise DBOSDurableWorkflowError("terminal idempotency key was previously bound to a different state")
        return WorkflowRecord(workflow.id, state, current.created_at, current.checkpoint_ref, tenant_key)

    def cancel(self, workflow: WorkflowRecord, *, tenant_key: str | None = None) -> WorkflowRecord:
        return self.finish(
            workflow, state="cancelled",
            idempotency_key=f"cancel:{workflow.id}", tenant_key=tenant_key,
        )

    def recover(self, workflow_id: str, *, tenant_key: str | None = None) -> WorkflowRecord | None:
        self._assert_open()
        from dbos import DBOS

        status = DBOS.get_workflow_status(str(workflow_id))
        if status is None:
            return None
        if status.app_version != self.config.application_version:
            raise DBOSVersionDriftError(
                f"workflow app version {status.app_version!r} differs from adapter version {self.config.application_version!r}"
            )
        if status.status != "SUCCESS" or not isinstance(status.output, dict):
            raise DBOSDurableWorkflowError(f"root workflow is not recoverable: DBOS status={status.status}")
        metadata = status.output
        if metadata.get("tenant_key") != tenant_key:
            raise DBOSTenantMismatchError("workflow tenant context does not match the caller")
        checkpoint_ref: str | None = None
        terminal_state: str | None = None
        operations = DBOS.list_workflows(
            workflow_id_prefix=f"{workflow_id}::",
            name=[self._CHECKPOINT_NAME, self._TERMINAL_NAME],
            app_version=self.config.application_version,
            status="SUCCESS",
            load_output=True,
            limit=10_000,
            sort_desc=False,
        )
        for operation in sorted(
            operations,
            key=lambda row: (int(row.created_at or 0), row.workflow_id),
        ):
            output = operation.output
            if not isinstance(output, dict) or output.get("parent_id") != workflow_id:
                raise DBOSDurableWorkflowError("durable operation receipt has invalid parent identity")
            if output.get("tenant_key") != tenant_key:
                raise DBOSTenantMismatchError("durable operation tenant context does not match the caller")
            if output.get("operation") == "checkpoint":
                if terminal_state is not None:
                    raise DBOSDurableWorkflowError("checkpoint was recorded after terminal state")
                checkpoint_ref = output.get("checkpoint_ref")
            elif output.get("operation") == "terminal":
                state = str(output.get("state"))
                if terminal_state is not None and terminal_state != state:
                    raise DBOSDurableWorkflowError("conflicting terminal workflow receipts")
                terminal_state = state
                # The terminal receipt freezes the latest checkpoint it saw.
                if output.get("checkpoint_ref") != checkpoint_ref:
                    raise DBOSDurableWorkflowError("terminal receipt checkpoint does not match durable history")
        if checkpoint_ref is not None:
            if not isinstance(checkpoint_ref, str) or not checkpoint_ref.startswith("artifact:sha256:"):
                raise DBOSDurableWorkflowError("DBOS checkpoint receipt is malformed")
            self.artifacts.get(checkpoint_ref.removeprefix("artifact:"))
        created = (float(status.created_at) / 1_000.0) if status.created_at else time.time()
        return WorkflowRecord(
            str(workflow_id), terminal_state or "running", created, checkpoint_ref, tenant_key,
        )

    def recover_incomplete(self, *, tenant_key: str | None = None) -> tuple[WorkflowRecord, ...]:
        self._assert_open()
        from dbos import DBOS

        roots = DBOS.list_workflows(
            status="SUCCESS",
            name=self._ROOT_NAME,
            app_version=self.config.application_version,
            limit=10_000,
            load_output=True,
        )
        recovered: list[WorkflowRecord] = []
        for root in roots:
            if not isinstance(root.output, dict) or root.output.get("tenant_key") != tenant_key:
                continue
            item = self.recover(root.workflow_id, tenant_key=tenant_key)
            if item is not None and item.state == "running":
                recovered.append(item)
        return tuple(sorted(recovered, key=lambda item: item.id))

    def close(self) -> None:
        with self._instance_lock:
            if self._closed:
                return
            try:
                from dbos import DBOS
                DBOS.destroy(destroy_registry=True, workflow_completion_timeout_sec=5)
            finally:
                self._closed = True
                if self.__class__._active_owner == id(self):
                    self.__class__._active_owner = None

    def __enter__(self) -> "DBOSDurableWorkflowPort":
        return self

    def __exit__(self, exc_type, exc, traceback) -> None:
        self.close()
