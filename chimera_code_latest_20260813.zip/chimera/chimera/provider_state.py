"""Unified provider state profile for routing decisions."""
from __future__ import annotations
from dataclasses import dataclass, asdict
import pathlib, time
from .provider_capabilities import ProviderCapabilityRegistry, ProviderCapabilities
from .provider_reliability import ProviderReliabilityRegistry, ProviderReliabilityProfile
from .provider_qos import ProviderQoSLedger, ProviderQoSProfile
from .provider_cooldown import ProviderCooldownLedger
from .context_ceiling import ObservedContextCeilings

@dataclass(frozen=True)
class ProviderState:
    provider: str
    model: str
    capabilities: dict
    reliability: dict
    qos: dict
    cooldown_active: bool
    effective_context_tokens: int | None
    route_penalty: float
    def as_dict(self): return asdict(self)

class ProviderStateRegistry:
    def __init__(self, root: pathlib.Path):
        self.root=pathlib.Path(root)
        self.capabilities=ProviderCapabilityRegistry(self.root)
        self.reliability=ProviderReliabilityRegistry(self.root)
        self.qos=ProviderQoSLedger(self.root)
        self.cooldowns=ProviderCooldownLedger(self.root)
        self.ceilings=ObservedContextCeilings(self.root)
    def profile(self, provider: str, model: str, *, configured_context: int | None = None, key: str | None = None) -> ProviderState:
        caps=self.capabilities.get(provider, model)
        rel=self.reliability.profile(provider, model)
        qos=self.qos.profile(provider, model)
        cooldown=False
        if key:
            cooldown=not bool(self.cooldowns.available([key]))
        effective=self.ceilings.effective(model, configured_context) if configured_context else None
        penalty=1.0
        if rel.calls >= 3: penalty *= max(0.05, 1.0 / max(0.05, rel.reliability))
        if qos.samples >= 3 and qos.p95_ms: penalty *= 1.0 + qos.p95_ms/1000.0
        if qos.samples >= 3 and qos.avg_tokens: penalty *= 1.0 + qos.avg_tokens/10000.0
        if cooldown: penalty *= 1e6
        return ProviderState(provider,model,caps.__dict__,rel.as_dict(),qos.as_dict(),cooldown,effective,round(penalty,4))
