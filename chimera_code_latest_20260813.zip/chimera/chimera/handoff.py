"""Compact signed agent handoffs bound to workspace diffs and evidence."""
from __future__ import annotations
import base64,hashlib,json,pathlib,time
from typing import Any,Iterable,Optional
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from pydantic import BaseModel,ConfigDict,Field
from .artifacts import ContentAddressedArtifactStore
from .context_evidence import ContextSigner
from .wal import WAL
class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
def _canonical(value:Any)->bytes:return json.dumps(value,sort_keys=True,separators=(",",":"),default=str).encode()
class DecisionItem(FrozenModel):id:str;outcome:str;confidence:float=Field(ge=0,le=1);evidence_refs:tuple[str,...]
class SignedHandoff(FrozenModel):
    from_agent:str;to_agent:str;task_summary:str;decisions:tuple[DecisionItem,...];workspace_diff_hash:str;payload_ref:str;created_at:str;key_id:str;public_key:str;signing_scope:str;signature:str
    def unsigned(self):return self.model_dump(mode="json",exclude={"signature"})
    @property
    def digest(self):return "sha256:"+hashlib.sha256(_canonical(self.model_dump(mode="json"))).hexdigest()
    def verify(self)->bool:
        try:
            public=base64.b64decode(self.public_key,validate=True)
            if "ed25519:"+hashlib.sha256(public).hexdigest()!=self.key_id:return False
            Ed25519PublicKey.from_public_bytes(public).verify(base64.b64decode(self.signature,validate=True),_canonical(self.unsigned()));return True
        except (ValueError,InvalidSignature):return False
class HandoffProtocol:
    def __init__(self,root:pathlib.Path,signer:Optional[ContextSigner]=None):self.root=pathlib.Path(root).resolve();self.store=ContentAddressedArtifactStore(self.root);self.signer=signer or ContextSigner.from_environment_or_ephemeral();self.wal=WAL(self.root)
    def create(self,from_agent:str,to_agent:str,task_summary:str,decisions:Iterable[DecisionItem],workspace_diff:dict[str,Any])->SignedHandoff:
        rows=tuple(decisions)
        if any(not item.evidence_refs for item in rows):raise ValueError("handoff decisions require evidence refs")
        diff_hash="sha256:"+hashlib.sha256(_canonical(workspace_diff)).hexdigest();payload={"task_summary":task_summary,"decisions":[item.model_dump(mode="json") for item in rows],"workspace_diff":workspace_diff};ref=self.store.put(_canonical(payload),media_type="application/vnd.chimera.handoff+json",provenance={"from":from_agent,"to":to_agent,"diff_hash":diff_hash})
        unsigned={"from_agent":from_agent,"to_agent":to_agent,"task_summary":task_summary[:2000],"decisions":rows,"workspace_diff_hash":diff_hash,"payload_ref":ref.digest,"created_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"key_id":self.signer.key_id,"public_key":self.signer.public_key,"signing_scope":self.signer.scope}
        serial={**unsigned,"decisions":[item.model_dump(mode="json") for item in rows]};handoff=SignedHandoff(**unsigned,signature=self.signer.sign(_canonical(serial)))
        if not handoff.verify():raise RuntimeError("new handoff signature failed")
        self.wal.append("agent_handoff",{"handoff_hash":handoff.digest,"from":from_agent,"to":to_agent,"payload_ref":ref.digest,"workspace_diff_hash":diff_hash})
        return handoff
    def resolve(self,handoff:SignedHandoff)->dict[str,Any]:
        if not handoff.verify():raise ValueError("handoff signature invalid")
        payload=json.loads(self.store.get(handoff.payload_ref))
        if "sha256:"+hashlib.sha256(_canonical(payload["workspace_diff"])).hexdigest()!=handoff.workspace_diff_hash:raise ValueError("handoff diff hash mismatch")
        return payload
