"""Static HTML accessibility/evidence analysis; not browser verification."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from html.parser import HTMLParser
import hashlib
from typing import Any


@dataclass(frozen=True)
class StaticUIEvidence:
    html_hash: str
    ids: tuple[str, ...]
    duplicate_ids: tuple[str, ...]
    images_missing_alt: int
    unlabeled_controls: int
    heading_levels: tuple[int, ...]
    heading_jump: bool
    semantic_issues: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]: return asdict(self)


class _Parser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.ids: list[str] = []; self.labels: set[str] = set(); self.images_missing_alt = 0
        self.controls: list[dict[str, str]] = []; self.headings: list[int] = []; self.issues: list[str] = []
    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        row = {key.lower(): value or "" for key, value in attrs}
        if row.get("id"): self.ids.append(row["id"])
        if tag == "label" and row.get("for"): self.labels.add(row["for"])
        if tag == "img" and "alt" not in row: self.images_missing_alt += 1
        if tag in {"input", "select", "textarea"} and row.get("type", "").lower() not in {"hidden", "submit", "button", "reset"}:
            self.controls.append(row)
        if tag == "button" and not row.get("aria-label") and not row.get("title"):
            self.issues.append("button requires visible text or aria-label (static analyzer cannot inspect text)")
        if len(tag) == 2 and tag[0] == "h" and tag[1].isdigit() and 1 <= int(tag[1]) <= 6: self.headings.append(int(tag[1]))


def analyze_static_html(html: str) -> StaticUIEvidence:
    parser = _Parser(); parser.feed(html); parser.close()
    duplicates = tuple(sorted({value for value in parser.ids if parser.ids.count(value) > 1}))
    unlabeled = sum(1 for control in parser.controls if not (control.get("id") in parser.labels or control.get("aria-label") or control.get("aria-labelledby") or control.get("title")))
    jump = any(next_level > level + 1 for level, next_level in zip(parser.headings, parser.headings[1:]))
    issues = list(parser.issues)
    if duplicates: issues.append("duplicate HTML IDs")
    if parser.images_missing_alt: issues.append("images missing alt attribute")
    if unlabeled: issues.append("form controls missing static label evidence")
    if jump: issues.append("heading level jump")
    return StaticUIEvidence(
        "sha256:" + hashlib.sha256(html.encode()).hexdigest(), tuple(parser.ids), duplicates,
        parser.images_missing_alt, unlabeled, tuple(parser.headings), jump, tuple(issues),
    )
