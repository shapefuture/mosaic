"""Evaluator-owned waivers for conservative scanner findings."""
from __future__ import annotations

import hashlib
import math
import json
import pathlib
import time
import base64
from dataclasses import dataclass, asdict
from typing import Any, Iterable, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from .context_evidence import ContextSigner
from .trusted_evaluators import TrustedEvaluatorRegistry


@dataclass(frozen=True)
class EvaluatorWaiver:
    path: str
    kind: str
    finding_hash: str
    reason: str
    evaluator_id: str
    expires_at: float | None = None
    key_id: str | None = None
    public_key: str | None = None
    signature: str | None = None

    def unsigned(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "kind": self.kind,
            "finding_hash": self.finding_hash,
            "reason": self.reason,
            "evaluator_id": self.evaluator_id,
            "expires_at": self.expires_at,
        }

    def signed_payload(self) -> bytes:
        return json.dumps(self.unsigned(), sort_keys=True, separators=(",", ":"), default=str).encode()

    def verify_signature(self) -> bool:
        if not (self.key_id and self.public_key and self.signature):
            return False
        try:
            public_raw = base64.b64decode(self.public_key, validate=True)
            expected_key_id = "ed25519:" + hashlib.sha256(public_raw).hexdigest()
            if expected_key_id != self.key_id:
                return False
            Ed25519PublicKey.from_public_bytes(public_raw).verify(
                base64.b64decode(self.signature, validate=True),
                self.signed_payload(),
            )
            return True
        except (ValueError, InvalidSignature):
            return False

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class EvaluatorWaiverLedger:
    """Read/write waiver files without making waivers easy or silent.

    A waiver matches only the exact path + finding kind + evidence hash.  This
    prevents a broad "ignore all scanner findings" bypass.  Signatures can be
    layered later with Chimera's existing signing utilities; the current local
    format is still evaluator-owned because candidates cannot create it unless
    the evaluator chooses to mount/provide it to the gate.
    """

    DEFAULT_NAME = ".chimera-evaluator-waivers.json"

    @staticmethod
    def finding_hash(finding: Mapping[str, Any]) -> str:
        payload = {
            "path": finding.get("path"),
            "kind": finding.get("kind"),
            "evidence": finding.get("evidence"),
        }
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    @classmethod
    def load(cls, path: pathlib.Path) -> list[EvaluatorWaiver]:
        path = pathlib.Path(path)
        if not path.exists():
            return []
        data = json.loads(path.read_text(encoding="utf-8"))
        rows = data if isinstance(data, list) else data.get("waivers", [])
        out = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            out.append(EvaluatorWaiver(
                path=str(row["path"]),
                kind=str(row["kind"]),
                finding_hash=str(row["finding_hash"]),
                reason=str(row.get("reason") or "explicit evaluator waiver"),
                evaluator_id=str(row.get("evaluator_id") or "unknown"),
                expires_at=float(row["expires_at"]) if row.get("expires_at") is not None else None,
                key_id=str(row["key_id"]) if row.get("key_id") is not None else None,
                public_key=str(row["public_key"]) if row.get("public_key") is not None else None,
                signature=str(row["signature"]) if row.get("signature") is not None else None,
            ))
        return out

    @classmethod
    def apply(cls, findings: Iterable[Mapping[str, Any]], waivers: Iterable[EvaluatorWaiver], *, now: float | None = None, require_signature: bool = False, trusted: TrustedEvaluatorRegistry | None = None) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        now = time.time() if now is None else float(now)
        active = {}
        for waiver in waivers:
            if waiver.expires_at is not None and (not math.isfinite(waiver.expires_at) or waiver.expires_at <= now):
                continue
            if (require_signature or trusted is not None) and not waiver.verify_signature():
                continue
            if trusted is not None and not trusted.allows(waiver.key_id, scope="waiver"):
                continue
            active[(waiver.path, waiver.kind, waiver.finding_hash)] = waiver
        remaining: list[dict[str, Any]] = []
        waived: list[dict[str, Any]] = []
        for finding in findings:
            row = dict(finding)
            digest = cls.finding_hash(row)
            key = (str(row.get("path")), str(row.get("kind")), digest)
            waiver = active.get(key)
            row["finding_hash"] = digest
            if waiver is None:
                remaining.append(row)
            else:
                row["waiver"] = waiver.as_dict()
                waived.append(row)
        return remaining, waived

    @classmethod
    def write_template(cls, path: pathlib.Path, findings: Iterable[Mapping[str, Any]], *, evaluator_id: str = "evaluator", reason: str = "reviewed fixture/non-candidate finding", signer: ContextSigner | None = None) -> dict[str, Any]:
        path = pathlib.Path(path)
        rows = []
        for finding in findings:
            waiver = EvaluatorWaiver(
                path=str(finding.get("path")),
                kind=str(finding.get("kind")),
                finding_hash=cls.finding_hash(finding),
                reason=reason,
                evaluator_id=evaluator_id,
                expires_at=None,
            )
            row = waiver.as_dict()
            if signer is not None:
                row["key_id"] = signer.key_id
                row["public_key"] = signer.public_key
                row["signature"] = signer.sign(waiver.signed_payload())
            rows.append(row)
        payload = {"schema_version": "chimera.evaluator-waivers.v1", "signed": signer is not None, "waivers": rows}
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return payload
