"""Deterministic shared-prefix contract for provider cache hygiene."""
from __future__ import annotations

import hashlib
import json
import re
from typing import Iterable

from pydantic import BaseModel, ConfigDict


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class PromptPrefixReceipt(_FrozenModel):
    prefix_hash: str
    prefix_chars: int
    stable: bool
    lint: tuple[str, ...]
    suffix_hash: str


class PromptPrefixContract:
    """Reject volatile identity/time fields before a shared cache boundary."""

    _VOLATILE = (
        (re.compile(r"\b20\d\d[-/]\d\d[-/]\d\d"), "timestamp-like value in shared prefix"),
        (re.compile(r"\b(?:agent|worker|tenant|session|run)[_-]?[a-z0-9]{3,}\b", re.I), "identity-like value in shared prefix"),
        (re.compile(r"\b(?:request_id|trace_id|nonce|uuid)\b", re.I), "request identity field in shared prefix"),
    )

    @classmethod
    def compile(cls, *, stable_sections: Iterable[str], volatile_sections: Iterable[str]) -> PromptPrefixReceipt:
        prefix = "\n".join(str(value) for value in stable_sections)
        suffix = "\n".join(str(value) for value in volatile_sections)
        lint = []
        for pattern, reason in cls._VOLATILE:
            if pattern.search(prefix):
                lint.append(reason)
        return PromptPrefixReceipt(
            prefix_hash="sha256:" + hashlib.sha256(prefix.encode("utf-8")).hexdigest(),
            prefix_chars=len(prefix),
            stable=not lint,
            lint=tuple(dict.fromkeys(lint)),
            suffix_hash="sha256:" + hashlib.sha256(suffix.encode("utf-8")).hexdigest(),
        )
