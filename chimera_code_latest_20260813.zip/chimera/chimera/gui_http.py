"""Minimal GUI HTTP adapter over hexagonal GUI ports.

Designed for hosted web dashboards and Tauri dev mode.  It is intentionally a
thin adapter: no runtime internals, no secret rendering, no tenant bypass.
"""
from __future__ import annotations

import json
import pathlib
from dataclasses import asdict, is_dataclass
from typing import Any
from urllib.parse import parse_qs, urlparse

from .bootstrap import build_local_application, new_run_context
from .config import DeploymentProfile
from .gui_application import DefaultGuiApplication
from .gui_ports import GuiAction, GuiTenantSession
from .telemetry_snapshot import TelemetrySnapshotBuilder


class GuiHttpAdapter:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        app, _composition = build_local_application(self.root)
        self.gui = DefaultGuiApplication(
            self.root,
            app,
            lambda: new_run_context(profile=DeploymentProfile.LOCAL_DETERMINISTIC),
        )

    @staticmethod
    def _session(headers: dict[str, str] | None = None) -> GuiTenantSession:
        headers = headers or {}
        return GuiTenantSession(
            tenant_key=headers.get("x-chimera-tenant-key"),
            principal_hash=headers.get("x-chimera-principal-hash"),
            trace_id=headers.get("traceparent") or headers.get("x-chimera-trace-id"),
        )

    @staticmethod
    def _plain(value: Any) -> Any:
        return asdict(value) if is_dataclass(value) else value

    @classmethod
    def _response(cls, status: int, payload: Any) -> dict[str, Any]:
        return {
            "status": status,
            "headers": {"content-type": "application/json; charset=utf-8"},
            "body": json.dumps(cls._plain(payload), sort_keys=True, default=str),
        }

    def handle(self, method: str, path: str, *, body: bytes | str = b"", headers: dict[str, str] | None = None) -> dict[str, Any]:
        parsed = urlparse(path)
        query = parse_qs(parsed.query)
        session = self._session(headers)
        try:
            if method == "GET" and parsed.path == "/api/telemetry":
                recent = int(query.get("recent", ["200"])[0])
                return self._response(200, TelemetrySnapshotBuilder(self.root).build(recent=recent).model_dump(mode="json"))
            if method == "GET" and parsed.path == "/api/gui/dashboard":
                return self._response(200, self.gui.dashboard(session))
            if method == "GET" and parsed.path == "/api/gates/dashboard":
                from .gate_dashboard import GateDashboardBuilder
                recent = int(query.get("recent", ["50"])[0])
                return self._response(200, GateDashboardBuilder(self.root).build(recent=recent))
            if method == "GET" and parsed.path == "/api/runs/events":
                from .run_event_bus import RunEventBus
                run_id = query.get("run_id", [None])[0]
                after_id = query.get("after_id", [None])[0]
                limit = int(query.get("limit", ["200"])[0])
                fmt = str(query.get("format", ["chimera"])[0]).lower()
                bus = RunEventBus(self.root)
                events = bus.replay_ag_ui(after_id=after_id, run_id=run_id, limit=limit) if fmt in {"ag-ui", "agui"} else bus.replay(after_id=after_id, run_id=run_id, limit=limit)
                return self._response(200, {"events": events, "format": "ag-ui" if fmt in {"ag-ui", "agui"} else "chimera"})
            if method == "POST" and parsed.path == "/api/gui/action":
                raw = body.decode() if isinstance(body, bytes) else str(body)
                payload = json.loads(raw or "{}")
                action = GuiAction(
                    id=str(payload.get("id", payload.get("kind", "action"))),
                    kind=payload["kind"],
                    payload=payload.get("payload", {}),
                )
                from .run_event_bus import RunEventBus
                bus = RunEventBus(self.root)
                bus.append(action.id, "gui.action.started", {"kind": action.kind, "payload_keys": sorted(action.payload)})
                result = self.gui.dispatch(session, action)
                bus.append(action.id, "gui.action.completed" if result.ok else "gui.action.failed", {"status": result.status, "error": result.error})
                return self._response(200, result)
            if method == "POST" and parsed.path == "/api/wire/decode":
                raw = body.decode() if isinstance(body, bytes) else str(body)
                try:
                    payload = json.loads(raw or "{}")
                    text = str(payload.get("text", ""))
                except json.JSONDecodeError:
                    text = raw
                from .wire import WireCodec
                return self._response(200, {"decoded": WireCodec().decode(text)})
            if method == "POST" and parsed.path == "/api/tenant/issue":
                import os
                raw = body.decode() if isinstance(body, bytes) else str(body)
                payload = json.loads(raw or "{}")
                encoded = os.environ.get("CHIMERA_GUI_TENANT_SIGNING_KEY")
                if not encoded:
                    return self._response(403, {"error": "missing_gui_tenant_signing_key"})
                from .context_evidence import ContextSigner
                from .tenant_authorization import TenantAuthorizationAuthority
                from .tenancy import TenantContext
                signer = ContextSigner.from_base64_private_key(encoded, scope="gui-tenant-authority")
                scopes = tuple(payload.get("scopes") or ["cli", "mcp", "rpc", "artifact"])
                grant = TenantAuthorizationAuthority(signer).issue(
                    tenant=TenantContext.from_id(str(payload["tenant_id"])),
                    authenticated_principal=str(payload["principal"]),
                    scopes=scopes,
                    ttl_seconds=float(payload.get("ttl_seconds", 3600)),
                )
                return self._response(200, {
                    "grant": grant.model_dump(mode="json"),
                    "trusted_key_id": signer.key_id,
                    "raw_key_recorded": False,
                })
            if method == "GET" and parsed.path == "/api/gui/health":
                return self._response(200, {"ok": True, "service": "chimera-gui", "redacted": True})
            return self._response(404, {"error": "not_found"})
        except Exception as exc:
            return self._response(500, {"error": type(exc).__name__, "message": str(exc)[:300]})
