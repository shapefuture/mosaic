"""Optional GCF/evidence proxy for third-party MCP stdio servers."""
from __future__ import annotations

import copy
import hashlib
import json
import os
import pathlib
import signal
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
from typing import Any, Iterable, Optional, Protocol

from .context_evidence import ContextEvidenceBinder
from .wal import WAL
from .wire import WireCodec
from .tool_attestation import ToolManifestAttestor, ToolManifestChangeDetector
from .mcp_catalog_cache import MCPToolCatalogCache
from .trace_context import inject_trace_context_into_meta


class MCPUpstream(Protocol):
    def request(self, payload: dict[str, Any]) -> dict[str, Any]: ...
    def close(self) -> None: ...


class MCPSubprocessClient:
    """One persistent JSON-RPC stdio process; never invokes a shell."""

    def __init__(self, command: Iterable[str], *, timeout: float = 30.0, allowed_env: Iterable[str] = ()) -> None:
        self.command = tuple(str(item) for item in command)
        if not self.command:
            raise ValueError("MCP upstream command is required")
        env = {key: value for key, value in os.environ.items() if key in {"PATH", "LANG", "LC_ALL", *allowed_env}}
        self.process = subprocess.Popen(
            self.command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, bufsize=1, env=env, start_new_session=True,
        )
        self.timeout = timeout
        self._lock = threading.Lock()
        self._reader = ThreadPoolExecutor(max_workers=1)
        self._closed = False

    def request(self, payload: dict[str, Any]) -> dict[str, Any]:
        if self._closed or self.process.poll() is not None:
            raise RuntimeError(f"MCP upstream exited {self.process.returncode}")
        line = json.dumps(payload, separators=(",", ":"))
        with self._lock:
            assert self.process.stdin is not None and self.process.stdout is not None
            self.process.stdin.write(line + "\n")
            self.process.stdin.flush()
            future = self._reader.submit(self.process.stdout.readline)
            try:
                response_line = future.result(timeout=self.timeout)
            except FutureTimeout as exc:
                # A timed-out stdio response cannot be safely left in the
                # stream: a later caller could consume its stale JSON-RPC line
                # as the answer to a different request.  Terminate rather than
                # layering an outer timeout over a still-live operation.
                self._terminate()
                raise TimeoutError(f"MCP upstream response exceeded {self.timeout}s; upstream terminated to prevent reply desynchronization") from exc
        if not response_line:
            stderr = self.process.stderr.read()[-1000:] if self.process.stderr else ""
            raise RuntimeError(f"MCP upstream closed stdout: {stderr}")
        value = json.loads(response_line)
        if not isinstance(value, dict):
            raise ValueError("MCP upstream response must be a JSON object")
        return value

    def _terminate(self) -> None:
        self._closed = True
        self._reader.shutdown(wait=False, cancel_futures=True)
        if self.process.poll() is None:
            try:
                os.killpg(self.process.pid, signal.SIGTERM)
                self.process.wait(timeout=2)
            except Exception:
                try:
                    os.killpg(self.process.pid, signal.SIGKILL)
                    self.process.wait(timeout=2)
                except (ProcessLookupError, subprocess.TimeoutExpired):
                    pass

    def close(self) -> None:
        self._terminate()


class GCFMCPProxy:
    def __init__(
        self,
        root: pathlib.Path,
        upstream: MCPUpstream,
        *,
        allowed_tools: Iterable[str],
        codec: Optional[WireCodec] = None,
        pinned_manifest_hash: str | None = None,
        pinned_tool_hashes: Optional[dict[str, str]] = None,
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.upstream = upstream
        self.allowed_tools = frozenset(allowed_tools)
        self.codec = codec or WireCodec(default="auto")
        # Pins are operator-provided deployment policy.  The proxy never pins a
        # first-seen upstream manifest automatically: that would make a
        # poisoned discovery response the trust baseline.
        self.pinned_manifest_hash = pinned_manifest_hash
        self.pinned_tool_hashes = dict(pinned_tool_hashes or {})
        self.binder = ContextEvidenceBinder(self.root)
        self.wal = WAL(self.root)
        # Persist only observed hashes, not a first-seen trust decision.  On a
        # reconnect/restart, an unchanged registry therefore stays quiet while
        # a real schema/description change remains auditable.
        previous_manifest_hash = None
        try:
            rows = self.wal.replay(kind="mcp_manifest_observation")
            if rows:
                prior = rows[-1].get("data", {})
                candidate = prior.get("manifest_hash") if isinstance(prior, dict) else None
                if isinstance(candidate, str) and candidate.startswith("sha256:"):
                    previous_manifest_hash = candidate
        except Exception:
            # WAL construction already verifies its chain.  Observation must
            # not become an availability dependency for explicitly allowed MCP
            # tools, and operator pins still enforce their own fail-closed gate.
            previous_manifest_hash = None
        self.manifest_changes = ToolManifestChangeDetector(previous_manifest_hash)
        # 2026-07-28 tool catalog caching is exact and server-hinted.  The
        # proxy intentionally caches public catalog pages only: it does not
        # have a verified per-caller authorization partition for private data.
        self.tool_catalog_cache = MCPToolCatalogCache()

    @staticmethod
    def _hash(value: Any) -> str:
        return "sha256:" + hashlib.sha256(
            json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()
        ).hexdigest()

    def _encode_content(self, response: dict[str, Any], mode: str, request_id: Any) -> dict[str, Any]:
        if mode == "json":
            return response
        transformed = copy.deepcopy(response)
        content = transformed.get("result", {}).get("content", [])
        for index, item in enumerate(content if isinstance(content, list) else []):
            if not isinstance(item, dict) or item.get("type") != "text" or not isinstance(item.get("text"), str):
                continue
            try:
                value = json.loads(item["text"])
            except json.JSONDecodeError:
                continue
            envelope = self.codec.encode_generic(value, mode=mode)
            receipt = self.binder.bind_envelope(
                envelope, purpose="third-party-mcp-result", model="mcp-upstream",
                session=f"mcp:{request_id}:{index}",
            )
            item["text"] = envelope.model_text()
            item["chimeraWire"] = {
                "format": envelope.format,
                "packRoot": receipt.pack_root,
                "receiptHash": receipt.receipt_hash,
            }
        return transformed

    def handle(self, request: dict[str, Any]) -> dict[str, Any]:
        forwarded = copy.deepcopy(request)
        method = forwarded.get("method")
        mode = "json"
        tool_name = None
        if isinstance(forwarded.get("params"), dict):
            forwarded["params"]["_meta"] = inject_trace_context_into_meta(forwarded["params"].get("_meta") if isinstance(forwarded["params"].get("_meta"), dict) else {})
        if method == "tools/call":
            params = forwarded.get("params") if isinstance(forwarded.get("params"), dict) else {}
            tool_name = params.get("name")
            if tool_name not in self.allowed_tools:
                return {
                    "jsonrpc": "2.0", "id": request.get("id"),
                    "error": {"code": -32602, "message": f"MCP tool not allowed by proxy policy: {tool_name}"},
                }
            arguments = params.get("arguments") if isinstance(params.get("arguments"), dict) else {}
            mode = str(arguments.pop("wire_format", "json"))
            if mode not in {"json", "gcf", "auto"}:
                return {
                    "jsonrpc": "2.0", "id": request.get("id"),
                    "error": {"code": -32602, "message": f"invalid wire_format {mode}"},
                }
            params["arguments"] = arguments

        catalog_cache_status = "not-applicable"
        catalog_cache_reason = "not a tool catalog request"
        list_params: dict[str, Any] | None = None
        if method == "tools/list":
            list_params = forwarded.get("params") if isinstance(forwarded.get("params"), dict) else {}
            cached_result, receipt = self.tool_catalog_cache.get(list_params)
            catalog_cache_status, catalog_cache_reason = receipt.status, receipt.reason
            if cached_result is not None:
                response = {"jsonrpc": "2.0", "id": request.get("id"), "result": cached_result}
            else:
                response = self.upstream.request(forwarded)
        else:
            response = self.upstream.request(forwarded)

        if method == "tools/list" and isinstance(response.get("result", {}).get("tools"), list):
            upstream_tools = response["result"]["tools"]
            observation = self.manifest_changes.observe(upstream_tools)
            # Do not log no-op rediscoveries.  A first observation or a genuine
            # content hash change is evidence, not approval: only explicit
            # operator pins below can authorize a third-party tool contract.
            if observation.state != "unchanged":
                self.wal.append("mcp_manifest_observation", {
                    "state": observation.state,
                    "manifest_hash": observation.actual.manifest_hash,
                    "previous_manifest_hash": observation.previous_manifest_hash,
                    "tool_count": observation.actual.count,
                })
            if self.pinned_manifest_hash or self.pinned_tool_hashes:
                verdict = ToolManifestAttestor.verify(
                    upstream_tools,
                    expected_manifest_hash=self.pinned_manifest_hash,
                    expected_tool_hashes=self.pinned_tool_hashes,
                )
                if not verdict.allowed:
                    self.wal.append("mcp_manifest_attestation", {
                        "allowed": False, "manifest_hash": verdict.actual.manifest_hash,
                        "mismatched_tools": list(verdict.mismatched_tools),
                        "unexpected_tools": list(verdict.unexpected_tools),
                        "missing_tools": list(verdict.missing_tools),
                    })
                    return {
                        "jsonrpc": "2.0", "id": request.get("id"),
                        "error": {"code": -32003, "message": "MCP tool manifest diverged from pinned policy"},
                    }
                self.wal.append("mcp_manifest_attestation", {
                    "allowed": True, "manifest_hash": verdict.actual.manifest_hash,
                    "tool_count": verdict.actual.count,
                })
            # Cache only a fresh modern ``resultType=complete`` public page
            # after it has passed any configured operator pin.  Older MCP
            # responses without explicit cache hints intentionally stay live.
            if list_params is not None and catalog_cache_status != "hit":
                stored = self.tool_catalog_cache.put(list_params, response)
                catalog_cache_status, catalog_cache_reason = stored.status, stored.reason
            response = copy.deepcopy(response)
            for tool in response["result"]["tools"]:
                schema = tool.setdefault("inputSchema", {"type": "object", "properties": {}})
                schema.setdefault("properties", {})["wire_format"] = {
                    "type": "string", "enum": ["json", "gcf", "auto"], "default": "json",
                }
        # The protocol permits an early re-fetch when a tool call reports that
        # a method or parameter is no longer valid.  We cannot infer a schema
        # change from normal tool-level errors, so invalidate only JSON-RPC's
        # precise method/invalid-params cases.
        if method == "tools/call":
            error = response.get("error") if isinstance(response, dict) else None
            code = error.get("code") if isinstance(error, dict) else None
            if code in {-32601, -32602}:
                removed = self.tool_catalog_cache.invalidate()
                self.wal.append("mcp_catalog_invalidation", {
                    "reason": "tool_call_method_or_params_error", "entries_removed": removed,
                })
        transformed = self._encode_content(response, mode, request.get("id"))
        self.wal.append("mcp_proxy", {
            "request_hash": self._hash(forwarded),
            "response_hash": self._hash(transformed),
            "method": method, "tool": tool_name, "wire_format": mode,
            "catalog_cache": catalog_cache_status,
            "catalog_cache_reason": catalog_cache_reason,
            "upstream_error": "error" in response,
        })
        return transformed

    def notify_tools_list_changed(self) -> int:
        """Invalidate catalog pages after a trusted subscription notification.

        No subscription client is started implicitly.  A future modern
        Streamable-HTTP adapter may call this only after it has validated an
        opted-in ``notifications/tools/list_changed`` event.
        """
        removed = self.tool_catalog_cache.invalidate()
        self.wal.append("mcp_catalog_invalidation", {
            "reason": "tools_list_changed_notification", "entries_removed": removed,
        })
        return removed

    def close(self) -> None:
        self.upstream.close()


def serve_proxy_stdio(proxy: GCFMCPProxy) -> None:
    import sys
    try:
        for line in sys.stdin:
            if not line.strip():
                continue
            try:
                request = json.loads(line)
                response = proxy.handle(request)
            except Exception as exc:
                response = {"jsonrpc": "2.0", "error": {"code": -32603, "message": str(exc)}}
            sys.stdout.write(json.dumps(response, separators=(",", ":")) + "\n")
            sys.stdout.flush()
    finally:
        proxy.close()
