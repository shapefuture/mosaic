"""Evidence/allocation policies derived from empirical-closure style gates."""
from __future__ import annotations
import hashlib,json,pathlib,time
from dataclasses import dataclass
from typing import Any,Iterable,Literal
from .wal import WAL

@dataclass(frozen=True)
class SimulabilityDecision:
 stage:Literal['compute','bound','neutralize','expensive'];allowed:bool;reason:str
class SimulabilityGate:
 def decide(self,*,has_computation:bool,has_bound:bool,neutralizable:bool,expensive_requested:bool)->SimulabilityDecision:
  if has_computation:return SimulabilityDecision('compute',True,'deterministic computation available')
  if has_bound:return SimulabilityDecision('bound',True,'conservative bound available')
  if neutralizable:return SimulabilityDecision('neutralize',True,'reversible/adapter neutralization available')
  return SimulabilityDecision('expensive',bool(expensive_requested),'expensive evaluation is last resort')

@dataclass(frozen=True)
class NeutralizationAssessment:
 resolve_cost:float;neutralize_cost:float;choose_neutralize:bool
class NeutralizationAdvisor:
 def assess(self,resolve_cost:float,neutralize_cost:float)->NeutralizationAssessment:
  return NeutralizationAssessment(resolve_cost,neutralize_cost,neutralize_cost<resolve_cost)

@dataclass(frozen=True)
class EvidenceClaim:
 text:str;status:Literal['observed','derived','plausible','speculative'];sources:tuple[str,...]
class ProvenanceRegistry:
 def __init__(self,root:pathlib.Path):self.wal=WAL(pathlib.Path(root))
 @staticmethod
 def origin(source:str)->str:
  value=source.split('://',1)[-1].split('/',1)[0].lower();return value
 def corroborated(self,sources:Iterable[str])->bool:
  roots={self.origin(s) for s in sources if s};return len(roots)>=2
 def record(self,claim:EvidenceClaim)->dict:
  row={'id':'claim:'+hashlib.sha256((claim.text+claim.status).encode()).hexdigest()[:16],'status':claim.status,'sources':claim.sources,'independent':self.corroborated(claim.sources),'at':time.time()};self.wal.append('evidence_claim',row);return row

@dataclass(frozen=True)
class BenchmarkProfile:
 model:str;provider:str;tool_surface:str;context_budget:int;cache_state:str;concurrency:int;task_type:str;environment:str
 def fingerprint(self)->str:return 'sha256:'+hashlib.sha256(json.dumps(self.__dict__,sort_keys=True).encode()).hexdigest()

class CapabilityProofLedger:
 def __init__(self,root:pathlib.Path):self.wal=WAL(pathlib.Path(root))
 def record(self,provider:str,capability:str,verified:bool,evidence_ref:str)->dict:
  if not evidence_ref:raise ValueError('capability proof requires evidence')
  row={'provider':provider,'capability':capability,'verified':verified,'evidence_ref':evidence_ref,'at':time.time()};self.wal.append('provider_capability_proof',row);return row

class CandidateDiversityGate:
 @staticmethod
 def _kind(candidate:dict)->str:
  paths=' '.join(candidate.get('paths',[])).lower();text=str(candidate.get('mechanism','')).lower()
  if 'test' in paths or 'contract' in text:return 'contract-test'
  if 'api' in paths or 'interface' in text:return 'interface'
  if 'guard' in text or 'check' in text:return 'local-guard'
  return hashlib.sha256(text.encode()).hexdigest()[:8]
 def validate(self,candidates:Iterable[dict])->bool:
  kinds=[self._kind(c) for c in candidates];return len(kinds)==len(set(kinds))

@dataclass(frozen=True)
class Signpost:
 assumption:str;metric:str;threshold:float;action:str
@dataclass(frozen=True)
class AdditionJustification:
 component:str;replaces:str;metric:str
class SubtractionReview:
 def admit(self,change:AdditionJustification)->bool:
  # A default component must either replace/defer existing work or expose a
  # measurable benefit; otherwise it is prompt/middleware accumulation.
  return bool(change.replaces.strip() or change.metric.strip())

class SignpostMonitor:
 def evaluate(self,signpost:Signpost,value:float)->dict:
  return {'triggered':value>=signpost.threshold,'action':signpost.action if value>=signpost.threshold else None,'value':value,'metric':signpost.metric}

class AfterActionReview:
 def __init__(self,root:pathlib.Path):self.wal=WAL(pathlib.Path(root))
 def record(self,intended:str,actual:dict,retain:str,remove:str,evidence_refs:Iterable[str])->dict:
  # WAL replay can be served from an in-process cache before JSON is parsed
  # again, so persist JSON-native containers rather than relying on encoder
  # tuple coercion for observable receipt shape.
  refs=list(evidence_refs)
  if not refs:raise ValueError('AAR requires evidence')
  row={'intended':intended,'actual':actual,'retain':retain,'remove':remove,'evidence_refs':refs,'at':time.time()};self.wal.append('after_action_review',row);return row
