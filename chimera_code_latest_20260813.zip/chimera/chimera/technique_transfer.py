"""Evidence-bound far-transfer library for optimization techniques.

Techniques are hypotheses, never executable authority. Retrieval maps problem
structure rather than matching domain names.
"""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import time
import uuid
from typing import Any, Iterable, Mapping

from pydantic import BaseModel, ConfigDict, Field

from .wal import WAL


class Technique(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    id: str
    source_domain: str
    mechanism: str
    structural_tags: frozenset[str]
    preconditions: tuple[str, ...]
    failure_modes: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    observed_deltas: dict[str, float] = Field(default_factory=dict)
    confidence: float = Field(ge=0.0, le=1.0)


class TransferProposal(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    technique_id: str
    mechanism: str
    structural_similarity: float
    matched_tags: tuple[str, ...]
    missing_preconditions: tuple[str, ...]
    status: str = "hypothesis-only"
    required_gate: str = "isolated evaluation against frozen baseline"


class TechniqueLibrary:
    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root)
        self.path = self.root / ".chimera" / "techniques.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.wal = WAL(self.root)

    def _load(self) -> dict[str, Technique]:
        if not self.path.exists():
            return {}
        return {key: Technique.model_validate(value) for key, value in json.loads(self.path.read_text()).items()}

    def _save(self, rows: Mapping[str, Technique]) -> None:
        temp = self.path.with_name(f".{self.path.name}.{uuid.uuid4().hex}.tmp")
        try:
            temp.write_text(json.dumps({key: value.model_dump(mode="json") for key, value in rows.items()}, indent=2, sort_keys=True) + "\n")
            os.replace(temp, self.path)
        finally:
            if temp.exists(): temp.unlink()

    def add(self, technique: Technique) -> None:
        if not technique.evidence_refs:
            raise ValueError("far-transfer technique requires evidence refs")
        if any(not ref.startswith(("artifact:sha256:", "url:https://", "doi:")) for ref in technique.evidence_refs):
            raise ValueError("evidence refs must be content-addressed artifacts, HTTPS URLs, or DOIs")
        rows = self._load()
        rows[technique.id] = technique
        self._save(rows)
        self.wal.append("technique_add", {
            "id": technique.id, "source_domain": technique.source_domain,
            "evidence_root": "sha256:" + hashlib.sha256(json.dumps(sorted(technique.evidence_refs)).encode()).hexdigest(),
        })

    def retrieve(self, target_tags: Iterable[str], satisfied_preconditions: Iterable[str], limit: int = 5) -> list[TransferProposal]:
        target = frozenset(target_tags)
        satisfied = set(satisfied_preconditions)
        output = []
        for technique in self._load().values():
            union = target | technique.structural_tags
            similarity = len(target & technique.structural_tags) / len(union) if union else 0.0
            if similarity <= 0:
                continue
            output.append(TransferProposal(
                technique_id=technique.id,
                mechanism=technique.mechanism,
                structural_similarity=similarity * technique.confidence,
                matched_tags=tuple(sorted(target & technique.structural_tags)),
                missing_preconditions=tuple(item for item in technique.preconditions if item not in satisfied),
            ))
        return sorted(output, key=lambda item: (-item.structural_similarity, item.technique_id))[:limit]

    def bootstrap(self) -> None:
        techniques = [
            Technique(id="quality-diversity-map-elites", source_domain="evolutionary computation", mechanism="Preserve one elite per behavioral feature cell instead of one global optimum.", structural_tags=frozenset({"multimodal", "premature-convergence", "multiple-objectives", "discrete-candidates"}), preconditions=("measurable behavioral features",), failure_modes=("meaningless feature axes", "archive explosion"), evidence_refs=("url:https://arxiv.org/abs/1504.04909",), confidence=0.95),
            Technique(id="ucb-resource-allocation", source_domain="multi-armed bandits", mechanism="Allocate proposal budget by upper-confidence bound over observed improvement per cost.", structural_tags=frozenset({"multiple-generators", "nonstationary-performance", "limited-budget", "online-feedback"}), preconditions=("comparable reward", "cost accounting"), failure_modes=("delayed rewards", "context confounding"), evidence_refs=("doi:10.1023/A:1013689704352",), confidence=0.9),
            Technique(id="successive-halving", source_domain="hyperparameter optimization", mechanism="Use cheap fidelity stages to eliminate weak candidates before expensive evaluation.", structural_tags=frozenset({"expensive-evaluation", "correlated-fidelities", "many-candidates", "limited-budget"}), preconditions=("cheap predictive stage",), failure_modes=("low-fidelity ranking inversion",), evidence_refs=("url:https://arxiv.org/abs/1502.07943",), confidence=0.9),
            Technique(id="common-random-numbers", source_domain="simulation optimization", mechanism="Evaluate parent and child with matched random seeds to reduce comparison variance.", structural_tags=frozenset({"noisy-evaluator", "paired-comparison", "stochastic-system"}), preconditions=("controllable random seed",), failure_modes=("seed overfitting",), evidence_refs=("url:https://business.columbia.edu/sites/default/files-efs/pubfiles/4261/glasserman_yao_guidelines.pdf",), confidence=0.9),
            Technique(id="coordinate-descent", source_domain="numerical optimization", mechanism="Change one numeric coordinate at a time so gains remain attributable.", structural_tags=frozenset({"numeric-parameters", "expensive-evaluation", "local-smoothness", "attribution-required"}), preconditions=("bounded parameter ranges",), failure_modes=("strong parameter interactions", "local optimum"), evidence_refs=("doi:10.1007/s10107-015-0892-3",), confidence=0.85),
            Technique(id="sequential-probability-racing", source_domain="sequential statistics", mechanism="Stop repeated evaluation early when confidence bounds prove win or loss.", structural_tags=frozenset({"noisy-evaluator", "repeated-measurements", "expensive-evaluation", "minimum-effect"}), preconditions=("iid or modeled samples", "precommitted error bounds"), failure_modes=("optional-stopping misuse", "distribution drift"), evidence_refs=("url:https://arxiv.org/abs/1810.08240",), confidence=0.8),
            Technique(id="metamorphic-testing", source_domain="software verification", mechanism="Check invariant relations across transformed inputs when exact outputs are unavailable.", structural_tags=frozenset({"weak-oracle", "deterministic-transformations", "correctness-gate"}), preconditions=("known metamorphic relations",), failure_modes=("invalid relation assumptions",), evidence_refs=("doi:10.1145/3143561",), confidence=0.9),
        ]
        rows = self._load()
        for technique in techniques:
            rows.setdefault(technique.id, technique)
        self._save(rows)
