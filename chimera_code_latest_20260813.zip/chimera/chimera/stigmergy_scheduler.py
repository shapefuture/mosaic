"""Durable pressure-field scheduler for long-lived, weakly-coupled agent tasks."""
from __future__ import annotations
import concurrent.futures,hashlib,json,math,pathlib,sqlite3,threading,time
from typing import Any,Callable,Iterable,Literal,Mapping,Optional
from pydantic import BaseModel,ConfigDict,Field
from .wal import WAL
class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
class PressureTask(FrozenModel):
    id:str;agent_id:str;payload:dict[str,Any]=Field(default_factory=dict);dependencies:tuple[str,...]=();base_priority:float=Field(default=0,ge=0);wake_threshold:float=Field(default=.4,ge=0);max_attempts:int=Field(default=2,ge=1)
class PressureTaskResult(FrozenModel):status:Literal["succeeded","failed"];output:Any=None;evidence_refs:tuple[str,...]=();error:Optional[str]=None
_SCHEMA="""
CREATE TABLE IF NOT EXISTS pressure_tasks(id TEXT PRIMARY KEY,payload TEXT NOT NULL,status TEXT NOT NULL,attempts INTEGER NOT NULL,updated_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS pressure_signals(id TEXT PRIMARY KEY,target_task TEXT NOT NULL,intensity REAL NOT NULL,created_at REAL NOT NULL,half_life REAL NOT NULL,evidence_refs TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_pressure_signal_target ON pressure_signals(target_task,created_at);
"""
class PressureScheduler:
    def __init__(self,root:pathlib.Path,max_parallel:int=4):self.root=pathlib.Path(root).resolve();self.path=self.root/".chimera"/"pressure.sqlite";self.path.parent.mkdir(parents=True,exist_ok=True);self.db=sqlite3.connect(self.path,check_same_thread=False);self.db.executescript(_SCHEMA);self.lock=threading.RLock();self.max_parallel=max(1,int(max_parallel));self.wal=WAL(self.root)
    def close(self):self.db.close()
    def add_task(self,task:PressureTask):
        with self.lock,self.db:self.db.execute("INSERT INTO pressure_tasks VALUES(?,?,?,?,?)",(task.id,task.model_dump_json(),"pending",0,time.time()))
    def signal(self,target_task:str,intensity:float,evidence_refs:Iterable[str],half_life_seconds:float=300.,*,now:Optional[float]=None):
        refs=tuple(evidence_refs)
        if not refs:raise ValueError("pressure signal requires evidence refs")
        created=time.time() if now is None else float(now);semantic=json.dumps({"task":target_task,"intensity":intensity,"created":created,"refs":refs},sort_keys=True);sid="pressure-"+hashlib.sha256(semantic.encode()).hexdigest()[:20]
        with self.lock,self.db:self.db.execute("INSERT OR IGNORE INTO pressure_signals VALUES(?,?,?,?,?,?)",(sid,target_task,max(0.,float(intensity)),created,max(1.,float(half_life_seconds)),json.dumps(refs)))
    def _tasks(self):return [(PressureTask.model_validate_json(row[0]),row[1],int(row[2])) for row in self.db.execute("SELECT payload,status,attempts FROM pressure_tasks").fetchall()]
    def _pressure(self,task:PressureTask,now:float):
        rows=self.db.execute("SELECT intensity,created_at,half_life FROM pressure_signals WHERE target_task=?",(task.id,)).fetchall();return task.base_priority+sum(float(v)*2**(-max(0.,now-float(t))/float(h)) for v,t,h in rows)
    def run(self,dispatch:Callable[[PressureTask],PressureTaskResult|Mapping[str,Any]],max_seconds:float=60.)->dict[str,Any]:
        started=time.monotonic();running={};results={};pool=concurrent.futures.ThreadPoolExecutor(max_workers=self.max_parallel,thread_name_prefix="chimera-pressure")
        try:
            while time.monotonic()-started<max_seconds:
                rows=self._tasks();status={task.id:state for task,state,_ in rows};ready=[];now=time.time()
                for task,state,attempts in rows:
                    if state!="pending" or attempts>=task.max_attempts:continue
                    if not all(status.get(dep)=="succeeded" for dep in task.dependencies):continue
                    pressure=self._pressure(task,now)
                    if pressure>=task.wake_threshold:ready.append((pressure,task,attempts))
                ready.sort(key=lambda item:(-item[0],item[1].id))
                while ready and len(running)<self.max_parallel:
                    pressure,task,attempts=ready.pop(0)
                    with self.lock,self.db:
                        changed=self.db.execute("UPDATE pressure_tasks SET status='running',attempts=attempts+1,updated_at=? WHERE id=? AND status='pending'",(time.time(),task.id)).rowcount
                    if changed:running[pool.submit(dispatch,task)]=(task,pressure)
                if not running:
                    pending=any(state in {"pending","running"} for _,state,_ in rows)
                    if not pending or not ready:break
                if running:
                    done,_=concurrent.futures.wait(running,return_when=concurrent.futures.FIRST_COMPLETED)
                    for future in done:
                        task,pressure=running.pop(future)
                        try:raw=future.result();result=raw if isinstance(raw,PressureTaskResult) else PressureTaskResult.model_validate(raw)
                        except Exception as exc:result=PressureTaskResult(status="failed",error=f"{type(exc).__name__}: {exc}")
                        if result.status=="succeeded" and not result.evidence_refs:result=PressureTaskResult(status="failed",error="successful pressure task lacks evidence refs")
                        row=self.db.execute("SELECT attempts FROM pressure_tasks WHERE id=?",(task.id,)).fetchone();attempts=int(row[0]);final="succeeded" if result.status=="succeeded" else "pending" if attempts<task.max_attempts else "failed"
                        with self.lock,self.db:self.db.execute("UPDATE pressure_tasks SET status=?,updated_at=? WHERE id=?",(final,time.time(),task.id))
                        results[task.id]=result;self.wal.append("pressure_task_result",{"task_id":task.id,"agent_id":task.agent_id,"status":result.status,"pressure":pressure,"attempt":attempts,"evidence_refs":list(result.evidence_refs)})
                        if result.status=="failed" and attempts<task.max_attempts:self.signal(task.id,.2,result.evidence_refs or (f"task:{task.id}:failure",),half_life_seconds=60)
        finally:pool.shutdown(wait=True,cancel_futures=True)
        states={task.id:state for task,state,_ in self._tasks()};return {"states":states,"results":results,"elapsed_seconds":time.monotonic()-started}
