"""Static guardrails for the RLM strangler-fig split."""
from __future__ import annotations
from dataclasses import dataclass, asdict
import pathlib, re

@dataclass(frozen=True)
class RLMFacadeAudit:
    direct_patch_calls:int; direct_test_calls:int; facade_attrs:tuple[str,...]; passed:bool
    def as_dict(self): return asdict(self)

def audit_rlm_facades(root:pathlib.Path=pathlib.Path('.'))->RLMFacadeAudit:
    path=pathlib.Path(root)/'chimera'/'rlm.py'
    text=path.read_text()
    # Exclude method definitions and doc/comments by looking only for self._ calls.
    direct_patch=len(re.findall(r'self\._apply_patch_payload\(', text))
    direct_test=len(re.findall(r'self\._run_branch_tests\(', text))
    facades=tuple(name for name in ('action_executor','provider_client','prompt_assembler','tool_protocol','aci','speculative_tools') if f'self.{name}' in text)
    return RLMFacadeAudit(direct_patch,direct_test,facades,direct_patch==0 and direct_test==0 and len(facades)>=6)
