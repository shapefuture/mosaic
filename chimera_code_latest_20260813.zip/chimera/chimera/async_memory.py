"""Non-blocking next-turn decision-memory retrieval."""
from __future__ import annotations
import concurrent.futures,threading
from dataclasses import dataclass
from typing import Any,Callable,Optional
from .decision_memory import DecisionMemory
@dataclass(frozen=True)
class MemoryRecall:
 id:str;text:str;score:float;evidence_refs:tuple[str,...]
class AsyncMemoryRecall:
 def __init__(self,memory:DecisionMemory,max_workers:int=1,verifier:Optional[Callable[[dict[str,Any]],bool]]=None):
  self.memory=memory;self.pool=concurrent.futures.ThreadPoolExecutor(max_workers=max_workers,thread_name_prefix="chimera-memory");self.verifier=verifier;self.futures={};self.lock=threading.Lock()
 def submit(self,session:str,context:str,limit:int=5)->bool:
  with self.lock:
   old=self.futures.get(session)
   if old and not old.done():return False
   def work():
    output=[]
    for hit in self.memory.search(context,limit=limit):
     if hit["status"]!="fresh":continue
     d=hit["decision"];record={"id":d.id,"summary":d.summary,"rationale":d.rationale,"references":d.references,"evidence_refs":d.evidence_refs,"score":hit["score"]}
     if self.verifier and not self.verifier(record):continue
     output.append(MemoryRecall(d.id,f"{d.summary}: {d.rationale}",hit["score"],d.evidence_refs))
    return output
   self.futures[session]=self.pool.submit(work);return True
 def take_ready(self,session:str):
  with self.lock:
   future=self.futures.get(session)
   if not future or not future.done():return []
   self.futures.pop(session,None)
  try:return future.result()
  except Exception:return []
 def close(self):self.pool.shutdown(wait=False,cancel_futures=True)
