"""Action execution facade extracted from RLMRuntime.

This is the first strangler-fig boundary: callers can depend on ActionExecutor
while the large runtime method remains the compatibility implementation behind
it.  Follow-up refactors can move more logic behind this facade without changing
callers again.
"""
from __future__ import annotations

from typing import Any


class ActionExecutor:
    def __init__(self, runtime: Any) -> None:
        self.runtime = runtime

    @staticmethod
    def lint_before_apply(path: str, source: str) -> list[str]:
        problems: list[str] = []
        if path.endswith(".py"):
            try:
                import ast
                ast.parse(source, filename=path)
            except SyntaxError as exc:
                problems.append(f"SyntaxError: {exc}")
        return problems

    def apply_patch_payload(self, branch: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.runtime._apply_patch_payload(branch, payload)

    def run_branch_tests(self, branch: str, command: str = "pytest -q", *, impact_scope: bool = True) -> dict[str, Any]:
        return self.runtime._run_branch_tests(branch, command, impact_scope=impact_scope)
