"""Exact exposure tracking for adaptive unchanged-result suppression."""
from __future__ import annotations
import threading
class ExposureTracker:
 def __init__(self):self.lock=threading.RLock();self.state={}
 def _session(self,session,state_root):
  row=self.state.setdefault(session,{"root":state_root,"keys":set()})
  if row["root"]!=state_root:row={"root":state_root,"keys":set()};self.state[session]=row
  return row
 def first(self,session,state_root,key):
  with self.lock:
   row=self._session(session,state_root)
   if key in row["keys"]:return False
   row["keys"].add(key);return True
 def filter_ids(self,session,state_root,ids):
  fresh=[];seen=[]
  with self.lock:
   row=self._session(session,state_root)
   for item in ids:
    key=f"graph:{item}"
    if key in row["keys"]:seen.append(item)
    else:row["keys"].add(key);fresh.append(item)
  return fresh,seen
 def report(self,session):
  with self.lock:
   row=self.state.get(session,{"root":None,"keys":set()});return {"state_root":row["root"],"exposures":len(row["keys"])}
