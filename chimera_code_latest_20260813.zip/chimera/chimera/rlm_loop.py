"""Model tool loop for RLMRuntime."""
from __future__ import annotations

import hashlib
import json
import time
from typing import Any, Dict, List, Mapping, Optional

from .wal import WALBatchScope
from .action_ir import ToolSurfaceError


class RLMLoopMixin:
    def _model_tool_loop(self, prompt: str, branch: str, model: str, *, allow_write: bool,
                         max_turns: int = 6, tool_requirements: Optional[Mapping[str, Any]] = None,
                         native_schema_profile: str = "compact", native_final_patch: Optional[bool] = None,
                         final_context_paths: Optional[List[str]] = None,
                         stop_after_tool_requirements: bool = False) -> tuple[Dict[str, Any], List[Dict[str, Any]], int]:
        if native_schema_profile not in {"strict", "compact"}:
            raise ValueError("native_schema_profile must be 'strict' or 'compact'")
        if native_final_patch is None:
            native_final_patch = bool(tool_requirements) and self.config.planner.tool_surface in {"single", "kernel"}
        # The legacy catalog intentionally retains prose/JSON final responses;
        # one-tool surfaces can keep one model-visible function name through a
        # phase-tagged native submission instead.
        use_native_final_patch = bool(native_final_patch) and self.config.planner.tool_surface in {"single", "kernel"}
        transcript = ""
        self._thread_local.exposure_session = f"{branch}:{hashlib.sha256(prompt.encode()).hexdigest()[:12]}"
        evidence: List[Dict[str, Any]] = []
        total_tokens = 0
        last_response: Dict[str, Any] = {}
        seen_calls: set[str] = set()
        call_count = 0
        from .trajectory import TrajectoryRecorder
        from .run_lifecycle import RunTerminal
        trajectory = TrajectoryRecorder(self.root, branch)
        lifecycle_run = self.run_lifecycle.begin_run(branch, task=prompt, source="model_tool_loop")
        lifecycle_terminal = RunTerminal.MAX_TURNS
        current_lifecycle_request = None
        tool_cutoff = min(max(1, max_turns - 2), 4 if allow_write else max_turns)
        for turn in range(max_turns):
            inject_observations = not transcript
            from .microcompaction import microcompact
            micro = microcompact(transcript)
            if micro is not None:
                transcript = micro.text
                evidence.append({"tool": "microcompaction", "ok": True,
                                 "removed_chars": micro.removed_chars, "breadcrumb": micro.breadcrumb})
            compacted = self.compactor.compact(transcript, branch)
            if compacted is not None:
                inject_observations = True
                transcript = compacted.text
                evidence.append({"tool": "context_compaction", "ok": True,
                                 "artifact_ref": compacted.artifact_ref,
                                 "manifest_ref": compacted.manifest_ref,
                                 "source_hash": compacted.source_hash,
                                 "retained_hash": compacted.retained_hash,
                                 "protected_fact_count": compacted.protected_fact_count,
                                 "removed_chars": compacted.removed_chars,
                                 "summary": compacted.summary})
            from .rlm_loop_context import prepare_loop_context
            prepared_context = prepare_loop_context(
                self,
                prompt=prompt,
                branch=branch,
                model=model,
                transcript=transcript,
                evidence=evidence,
                allow_write=allow_write,
                turn=turn,
                tool_cutoff=tool_cutoff,
                tool_requirements=tool_requirements,
                use_native_final_patch=use_native_final_patch,
                final_context_paths=final_context_paths,
                inject_observations=inject_observations,
            )
            directive = prepared_context.directive
            missing_before_call = list(prepared_context.missing_requirements)
            native_final_this_turn = prepared_context.native_final_this_turn
            observation_session = prepared_context.observation_session
            history = prepared_context.history
            request = prepared_context.request
            compiled_context = prepared_context.compiled_context
            from .rlm_loop_provider_turn import execute_provider_turn
            try:
                provider_turn = execute_provider_turn(
                    self,
                    branch=branch,
                    model=model,
                    prompt=prompt,
                    request=request,
                    directive=directive,
                    history=history,
                    allow_write=allow_write,
                    native_schema_profile=native_schema_profile,
                    missing_before_call=missing_before_call,
                    native_final_this_turn=native_final_this_turn,
                    evidence=evidence,
                    lifecycle_run=lifecycle_run,
                    trajectory=trajectory,
                    turn=turn,
                )
            except Exception:
                lifecycle_terminal = RunTerminal.PROVIDER_UNAVAILABLE
                raise
            last_response = provider_turn.response
            current_lifecycle_request = provider_turn.lifecycle_request
            turn_latency = provider_turn.turn_latency
            native_calls = provider_turn.native_calls
            call_count += 1
            total_tokens += int(last_response.get("tokens", 0) or 0)
            text = last_response.get("answer", "") or ""
            calls = native_calls or self._parse_tool_calls(text)
            if str(last_response.get("finish_reason", "")).lower() == "length" and calls:
                evidence.append({
                    "tool": "truncated_tool_call_kill_switch", "ok": False, "turn": turn + 1,
                    "calls_failed": len(calls),
                    "error": "assistant response hit length limit; tool calls may have incomplete arguments and must be re-issued",
                })
                transcript += (
                    "\n\nTool-call safety correction: your previous response hit the output length limit. "
                    "No tool calls were executed. Re-issue only the necessary complete tool call(s) with complete arguments.\n"
                )
                continue
            submitted_patch = self._native_patch_submission(native_calls)
            if submitted_patch is not None:
                if missing_before_call:
                    evidence.append({
                        "tool": "tool_protocol", "ok": False, "turn": turn + 1,
                        "missing": missing_before_call,
                        "error": "patch submission arrived before required tool observations",
                    })
                else:
                    last_response["answer"] = json.dumps(submitted_patch, separators=(",", ":"))
                    last_response["native_patch_submission"] = True
                    evidence.append({
                        "tool": "native_patch_submission", "ok": True, "turn": turn + 1,
                        "surface": self.config.planner.tool_surface,
                        "top_level_keys": sorted(str(key) for key in submitted_patch),
                    })
                    break
            if native_calls:
                # ``phase`` is transport metadata, not part of the closed
                # internal tool language. Remove it only after checking for a
                # native patch submission above.
                calls = [
                    {**call, "arguments": {
                        key: value for key, value in dict(call.get("arguments", {})).items()
                        if key != "phase"
                    }}
                    for call in calls
                ]
            if native_final_this_turn and not missing_before_call:
                # Providers occasionally return a valid JSON patch as ordinary
                # message content despite a required native submit function.
                # Accept that only after parsing it as data; it then traverses
                # the same transactional patch gate. This avoids discarding a
                # valid deterministic answer merely because the provider chose
                # the text channel, while still retrying malformed prose.
                text_patch = self._json_from_model(text)
                if isinstance(text_patch, dict) and {"summary", "files", "edits", "insertions"}.issubset(text_patch):
                    last_response["answer"] = json.dumps(text_patch, separators=(",", ":"))
                    last_response["native_patch_fallback"] = True
                    evidence.append({
                        "tool": "native_patch_fallback", "ok": True, "turn": turn + 1,
                        "surface": self.config.planner.tool_surface,
                        "top_level_keys": sorted(str(key) for key in text_patch),
                    })
                    break
                evidence.append({
                    "tool": "tool_protocol", "ok": False, "turn": turn + 1,
                    "error": "final native patch submission was missing or malformed",
                })
                if turn + 1 < max_turns:
                    transcript += (
                        "\n\nFinal protocol correction: call the provided native wrapper with "
                        "phase=submit_patch and a patch object now; do not emit prose.\n"
                    )
                    continue
                break
            if not calls:
                if missing_before_call:
                    evidence.append({
                        "tool": "tool_protocol", "ok": False, "turn": turn + 1,
                        "missing": missing_before_call,
                        "error": "required tool observations were not requested by the model",
                    })
                    if turn + 1 < max_turns:
                        transcript += (
                            "\n\nTool protocol correction: do not return a final answer yet. "
                            f"Request the missing observations now: {', '.join(missing_before_call)}. "
                            "Use the provided native function tool (or one complete textual fallback block).\n"
                        )
                        continue
                interrupts = self.soft_interrupts.drain(branch, point="B")
                if interrupts:
                    injected = "\n\n".join(item.content for item in interrupts)
                    evidence.append({"tool": "soft_interrupt", "ok": True, "point": "B",
                                     "ids": [item.id for item in interrupts]})
                    transcript += f"\n\nAssistant completed:\n{text[-8000:]}\n\nUser soft interrupt:\n{injected[:12000]}\n"
                    continue
                break
            program = None
            if self.config.planner.tool_surface == "kernel":
                model_outer_blocks = len(calls)
                calls, kernel_coalesced = self._coalesce_kernel_calls(calls)
                surface_record = {
                    "tool": "tool_surface", "ok": True, "surface": "kernel",
                    "model_visible_tools": ["chimera.py"], "outer_tool_calls": len(calls),
                    "model_outer_blocks": model_outer_blocks, "canonicalized": kernel_coalesced,
                }
                evidence.append(surface_record)
                if allow_write and turn >= tool_cutoff:
                    kernel_result, kernel_evidence = ({
                        "ok": False, "tool": "chimera.py",
                        "error": "read budget exhausted; return the final JSON patch",
                    }, [])
                else:
                    kernel_result, kernel_evidence = self._execute_kernel_call(branch, calls)
                evidence.extend(kernel_evidence)
                evidence.append({key: value for key, value in kernel_result.items() if key != "output"})
                wire = self.wire.encode_generic({"tool_result": kernel_result}, mode="auto")
                evidence.append(self._bind_wire_evidence(
                    wire, purpose="kernel-tool-result", model=model, branch=branch
                ))
                evidence.append({
                    "tool": "wire_codec", "ok": True, "format": wire.format,
                    "source_bytes": wire.source_bytes, "wire_bytes": wire.wire_bytes,
                    "reduction": wire.reduction,
                })
                transcript += (
                    f"\n\nAssistant tool request:\n{text[-8000:]}\n\n"
                    f"Tool result ({wire.format}, reduction={wire.reduction:.1%}):\n"
                    f"{wire.model_text()[:24000]}\n"
                )
                interrupts = self.soft_interrupts.drain(branch, point="D")
                if interrupts:
                    transcript += "\nUser soft interrupt:\n" + "\n\n".join(item.content for item in interrupts)[:12000] + "\n"
                    evidence.append({"tool": "soft_interrupt", "ok": True, "point": "D",
                                     "ids": [item.id for item in interrupts]})
                continue
            if self.config.planner.tool_surface == "single":
                try:
                    program = self.single_tool_surface.decode(calls)
                except ToolSurfaceError as exc:
                    surface_error = {
                        "tool": "tool_surface", "ok": False,
                        "surface": "single", "model_visible_tools": ["chimera.run"],
                        "outer_tool_calls": len(calls), "error": str(exc),
                    }
                    evidence.append(surface_error)
                    wire = self.wire.encode_generic({"tool_result": surface_error}, mode="auto")
                    evidence.append(self._bind_wire_evidence(
                        wire, purpose="tool-surface-error", model=model, branch=branch
                    ))
                    transcript += (
                        f"\n\nAssistant tool request:\n{text[-8000:]}\n\n"
                        f"Tool result ({wire.format}):\n{wire.model_text()[:12000]}\n"
                    )
                    interrupts = self.soft_interrupts.drain(branch, point="D")
                    if interrupts:
                        transcript += "\nUser soft interrupt:\n" + "\n\n".join(item.content for item in interrupts)[:12000] + "\n"
                        evidence.append({"tool": "soft_interrupt", "ok": True, "point": "D",
                                         "ids": [item.id for item in interrupts]})
                    continue
                source_calls = list(program.calls)
                evidence.append({"tool": "adaptive_action_cap", "ok": True,
                                 "cap": self.adaptive_action_cap.cap(), "requested": len(source_calls)})
                evidence.append({
                    "tool": "tool_surface", "ok": True, "surface": "single",
                    "model_visible_tools": ["chimera.run"], "outer_tool_calls": 1,
                    "program_hash": program.program_hash, "actions": len(source_calls),
                    "requested_outputs": list(program.requested_outputs),
                    "dead_fetches_eliminated": list(program.eliminated),
                })
            else:
                source_calls = calls[:6]
                evidence.append({
                    "tool": "tool_surface", "ok": True, "surface": "legacy",
                    "model_visible_tools": sorted({str(call.get("name", "")) for call in source_calls}),
                    "outer_tool_calls": len(source_calls), "actions": len(source_calls),
                })
            tool_results: List[Optional[Dict[str, Any]]] = [None] * len(source_calls)
            compile_inputs: List[Dict[str, Any]] = []
            compile_to_source: List[int] = []
            batch_signatures: set[str] = set()
            read_aliases = {
                "read", "read_file", "fs.read", "list", "list_files", "glob",
                "graph", "graph_search", "search", "graph_query", "shell", "bash",
                "exec", "shell_read", "artifact", "artifact_read", "cas.read", "artifact_search", "cas.search",
            }
            for source_index, call in enumerate(source_calls):
                signature = json.dumps(call, sort_keys=True)
                tool_name = str(call.get("name", "")).lower()
                if allow_write and turn >= tool_cutoff and tool_name in read_aliases:
                    tool_results[source_index] = {
                        "ok": False, "tool": tool_name,
                        "error": "read budget exhausted; emit chimera.run W/E actions or final JSON patch",
                    }
                elif not program and signature in seen_calls:
                    tool_results[source_index] = {
                        "ok": False, "tool": tool_name, "error": "duplicate tool call suppressed",
                    }
                else:
                    compile_to_source.append(source_index)
                    compile_inputs.append(call)
                    batch_signatures.add(signature)
            if not program:
                seen_calls.update(batch_signatures)

            plan = self.tool_compiler.compile(
                compile_inputs, capability=self.config.to_capability_set(), allow_write=allow_write
            )
            from .verification_policy import verification_stack
            compiler_record = {
                "tool": "action_compiler", "ok": not plan.diagnostics,
                "surface": self.config.planner.tool_surface,
                "verification_stacks": {
                    action.action_id: verification_stack(action).model_dump(mode="json")
                    for action in plan.actions
                },
                "model_visible_tools": ["chimera.run"] if program else sorted(
                    {str(call.get("name", "")) for call in source_calls}
                ),
                "outer_tool_calls": 1 if program else len(source_calls),
                "program_hash": program.program_hash if program else None,
                **plan.evidence(),
            }
            evidence.append(compiler_record)
            for diagnostic in plan.diagnostics:
                original = compile_to_source[diagnostic.source_index]
                tool_results[original] = {
                    "ok": False, "tool": diagnostic.tool,
                    "error": f"{diagnostic.code}: {diagnostic.message}",
                }

            from .verification_policy import SemanticLoopDetector
            detector = self._loop_detectors.setdefault(branch, SemanticLoopDetector())
            loop = detector.observe(
                plan.actions, state_root=self.workspace.diff(branch).get("id", ""),
                method=self.config.planner.tool_surface,
            )
            evidence.append({"tool": "semantic_loop", "ok": not loop.rotation_required and not loop.halt,
                             **loop.model_dump(mode="json")})
            blocked_for_loop = loop.rotation_required or loop.halt
            if blocked_for_loop:
                for action in plan.actions:
                    for compiled_index in action.source_indices:
                        original = compile_to_source[compiled_index]
                        tool_results[original] = {
                            "ok": False, "tool": action.kind.value,
                            "error": loop.reason,
                            "rotation_required": loop.rotation_required,
                            "halt": loop.halt,
                        }

            action_results: Dict[str, Dict[str, Any]] = {}
            if not blocked_for_loop:
                tool_started = time.perf_counter()
                action_results, action_schedule = self._execute_compiled_actions(
                    branch, plan, allow_write, lifecycle_request=current_lifecycle_request,
                    certificate_context_hash=compiled_context.plan_hash,
                )
                turn_latency.tool_ms += (time.perf_counter() - tool_started) * 1000
                evidence.append({"tool": "action_scheduler", "ok": True, **action_schedule})
            if not blocked_for_loop:
                for action in plan.actions:
                    result = action_results[action.action_id]
                    for compiled_index in action.source_indices:
                        original = compile_to_source[compiled_index]
                        tool_results[original] = dict(result)

            final_tool_results: List[Dict[str, Any]] = []
            for source_index, result in enumerate(tool_results):
                resolved = result or {
                    "ok": False, "tool": str(source_calls[source_index].get("name", "")),
                    "error": "compiler produced no executable action",
                }
                if program:
                    resolved = {"id": str(source_calls[source_index].get("id", source_index)), **resolved}
                evidence.append({key: value for key, value in resolved.items() if key != "content"})
                final_tool_results.append(resolved)
            tool_results = final_tool_results
            from .loop_graph import ProgressLoopGuard
            progress_guard = self._progress_loop_detectors.setdefault(branch, ProgressLoopGuard())
            progress = progress_guard.observe(source_calls, tool_results)
            evidence.append({"tool": "progress_loop_guard", "ok": not progress.halt, **progress.__dict__})
            from .fable_transfers import FailureStreakEscalator
            escalator = self._failure_escalators.setdefault(branch, FailureStreakEscalator())
            escalation = None
            for item in tool_results:
                if not item.get("ok"):
                    escalation = escalator.observe(str(item.get("error", "tool failure")))
            if escalation is not None:
                evidence.append({"tool": "failure_streak", "ok": False, **escalation.__dict__})
            if program:
                self.adaptive_action_cap.observe(len(tool_results), sum(1 for item in tool_results if item.get("ok")), len(json.dumps(tool_results, default=str)))
            from .rlm_loop_transcript import materialize_tool_transcript
            transcript += materialize_tool_transcript(
                self,
                branch=branch,
                model=model,
                prompt=prompt,
                model_text=text,
                program=program,
                plan=plan,
                source_calls=source_calls,
                tool_results=tool_results,
                evidence=evidence,
            )
            failures=[result for result in tool_results if not result.get("ok")];tool_names=[str(result.get("tool","unknown")) for result in tool_results];paths=[str(result.get("path")) for result in tool_results if result.get("path")]
            observation=self.observations.observe(observation_session,f"tool turn: tools={tool_names}; paths={paths}; failures={len(failures)}",json.dumps(tool_results,sort_keys=True,default=str),importance="critical" if failures else "informational",evidence_refs=[f"plan:{plan.plan_hash}"],untrusted=True)
            reflected=self.observations.reflect_deterministic(observation_session) if self.observations.needs_reflection(observation_session) else []
            evidence.append({"tool":"observational_memory","ok":True,"recorded":observation.id,"importance":observation.importance,"reflections":[item.id for item in reflected]})
            interrupts = self.soft_interrupts.drain(branch, point="D")
            if interrupts:
                injected = "\n\n".join(item.content for item in interrupts)
                transcript += f"\nUser soft interrupt (injected after all tool results):\n{injected[:12000]}\n"
                evidence.append({"tool": "soft_interrupt", "ok": True, "point": "D",
                                 "ids": [item.id for item in interrupts]})
            self.latency_attribution.record(turn_latency.finish())
            if progress.halt or escalation is not None:
                reason = progress.reason if progress.halt else escalation.action
                evidence.append({"tool": "loop_escalation", "ok": False, "reason": reason,
                                 "action": "halt and require a new strategy or human clarification"})
                break
            if stop_after_tool_requirements and not self._tool_requirement_missing(evidence, tool_requirements):
                evidence.append({
                    "tool": "tool_observation_complete", "ok": True,
                    "turn": turn + 1, "stopped_before_final_generation": True,
                })
                break
        remaining_requirements = self._tool_requirement_missing(evidence, tool_requirements)
        if remaining_requirements:
            evidence.append({
                "tool": "tool_protocol", "ok": False, "terminal": True,
                "missing": remaining_requirements,
                "error": "tool-observation contract was not satisfied before the turn budget ended",
            })
        last_response["_harness_call_count"] = call_count
        if lifecycle_terminal is RunTerminal.MAX_TURNS and call_count < max_turns:
            lifecycle_terminal = RunTerminal.DONE
        self.run_lifecycle.finish(lifecycle_run, lifecycle_terminal, detail=str(last_response.get("finish_reason", "")))
        lifecycle_projection = self.run_lifecycle.projection(lifecycle_run.run_id)
        evidence.append({
            "tool": "run_lifecycle", "ok": lifecycle_terminal is RunTerminal.DONE and lifecycle_projection.valid,
            "conversation_id": lifecycle_run.conversation_id, "run_id": lifecycle_run.run_id,
            "terminal": lifecycle_terminal.value,
            "summary": self.run_lifecycle.summary(lifecycle_run.run_id),
            "projection_hash": lifecycle_projection.projection_hash,
            "projection_valid": lifecycle_projection.valid,
            "projection_errors": list(lifecycle_projection.errors),
        })
        return last_response, evidence, total_tokens
