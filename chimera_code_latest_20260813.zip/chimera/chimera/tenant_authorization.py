"""Signed principal-to-tenant authorization and immutable propagation context.

Opaque workspace paths are isolation mechanics, not authentication. Transport
boundaries must validate a signed grant, hash the authenticated principal, and
propagate only ``TenantExecutionContext`` to authority-bearing adapters. There
is no default tenant and no unauthenticated tenant label fallback.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import pathlib
import time
from typing import Any, Literal
import uuid

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .artifacts import ArtifactRef, ContentAddressedArtifactStore
from .tenancy import TenantContext, TenantWorkspace, TenantWorkspaceResolver


TenantScope = Literal[
    "cli", "rpc", "mcp", "scheduler", "sandbox", "durable", "artifact", "lsp",
]


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


def _canonical(value: Any) -> bytes:
    if isinstance(value, BaseModel):
        value = value.model_dump(mode="json")
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _principal_hash(principal: str) -> str:
    raw = str(principal).strip()
    if not raw or "\x00" in raw:
        raise ValueError("authenticated principal must be non-empty and NUL-free")
    return "sha256:" + hashlib.sha256(raw.encode("utf-8")).hexdigest()


class TenantAuthorizationError(PermissionError):
    pass


class TenantAuthorizationGrant(_FrozenModel):
    schema_version: Literal["chimera.tenant-authorization.v1"] = "chimera.tenant-authorization.v1"
    grant_id: str
    tenant_key: str = Field(pattern=r"^[0-9a-f]{64}$")
    principal_hash: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    scopes: tuple[TenantScope, ...] = Field(min_length=1)
    issued_at: float
    expires_at: float
    issuer_key_id: str
    issuer_public_key: str
    signing_scope: str
    signature: str

    @model_validator(mode="after")
    def _valid(self) -> "TenantAuthorizationGrant":
        if self.expires_at <= self.issued_at:
            raise ValueError("tenant authorization expiry must follow issuance")
        if len(self.scopes) != len(set(self.scopes)):
            raise ValueError("tenant authorization scopes must be unique")
        return self

    def signed_payload(self) -> dict[str, Any]:
        return self.model_dump(exclude={"signature"}, mode="json")

    @property
    def digest(self) -> str:
        return "sha256:" + hashlib.sha256(_canonical(self)).hexdigest()

    def signature_valid(self, trusted_key_ids: set[str] | frozenset[str]) -> bool:
        try:
            public = base64.b64decode(self.issuer_public_key, validate=True)
            key_id = "ed25519:" + hashlib.sha256(public).hexdigest()
            if key_id != self.issuer_key_id or key_id not in trusted_key_ids:
                return False
            Ed25519PublicKey.from_public_bytes(public).verify(
                base64.b64decode(self.signature, validate=True),
                _canonical(self.signed_payload()),
            )
            return True
        except (ValueError, InvalidSignature):
            return False


class TenantExecutionContext(_FrozenModel):
    schema_version: Literal["chimera.tenant-execution-context.v1"] = "chimera.tenant-execution-context.v1"
    tenant_key: str = Field(pattern=r"^[0-9a-f]{64}$")
    principal_hash: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    grant_digest: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    scope: TenantScope


class TenantAuthorizationReceipt(_FrozenModel):
    authorized: bool
    tenant_key: str
    principal_hash: str
    scope: TenantScope
    grant_digest: str
    reason: str


class TenantAuthorizationAuthority:
    def __init__(self, signer) -> None:
        if getattr(signer, "scope", "") in {"", "ephemeral-process"}:
            raise ValueError("tenant grants require a non-ephemeral signing scope")
        self.signer = signer

    def issue(
        self,
        *,
        tenant: TenantContext,
        authenticated_principal: str,
        scopes: tuple[TenantScope, ...] | list[TenantScope],
        ttl_seconds: float,
        now: float | None = None,
    ) -> TenantAuthorizationGrant:
        if ttl_seconds <= 0:
            raise ValueError("tenant authorization TTL must be positive")
        current = time.time() if now is None else float(now)
        unsigned = {
            "schema_version": "chimera.tenant-authorization.v1",
            "grant_id": "tenant-grant:" + uuid.uuid4().hex,
            "tenant_key": tenant.tenant_key,
            "principal_hash": _principal_hash(authenticated_principal),
            "scopes": tuple(sorted(set(scopes))),
            "issued_at": current,
            "expires_at": current + float(ttl_seconds),
            "issuer_key_id": str(self.signer.key_id),
            "issuer_public_key": str(self.signer.public_key),
            "signing_scope": str(self.signer.scope),
        }
        if not unsigned["scopes"]:
            raise ValueError("tenant authorization requires at least one scope")
        return TenantAuthorizationGrant(**unsigned, signature=self.signer.sign(_canonical(unsigned)))


class TenantAuthorizationGuard:
    def __init__(self, *, trusted_key_ids: set[str] | frozenset[str]) -> None:
        if not trusted_key_ids:
            raise ValueError("tenant authorization requires at least one trusted key id")
        self.trusted_key_ids = frozenset(trusted_key_ids)

    def authorize(
        self,
        grant: TenantAuthorizationGrant,
        *,
        tenant: TenantContext,
        authenticated_principal: str,
        scope: TenantScope,
        now: float | None = None,
    ) -> tuple[TenantExecutionContext, TenantAuthorizationReceipt]:
        current = time.time() if now is None else float(now)
        principal = _principal_hash(authenticated_principal)
        reason = "authorized signed principal-to-tenant scope"
        if not grant.signature_valid(self.trusted_key_ids):
            raise TenantAuthorizationError("tenant authorization signature is invalid or untrusted")
        if grant.tenant_key != tenant.tenant_key:
            raise TenantAuthorizationError("tenant authorization does not cover the requested tenant")
        if grant.principal_hash != principal:
            raise TenantAuthorizationError("tenant authorization does not cover the authenticated principal")
        if scope not in grant.scopes:
            raise TenantAuthorizationError("tenant authorization does not cover the requested scope")
        if current < grant.issued_at or current >= grant.expires_at:
            raise TenantAuthorizationError("tenant authorization is not currently valid")
        context = TenantExecutionContext(
            tenant_key=tenant.tenant_key,
            principal_hash=principal,
            grant_digest=grant.digest,
            scope=scope,
        )
        return context, TenantAuthorizationReceipt(
            authorized=True,
            tenant_key=context.tenant_key,
            principal_hash=context.principal_hash,
            scope=scope,
            grant_digest=context.grant_digest,
            reason=reason,
        )


class TenantScopedArtifactStore:
    """CAS wrapper requiring per-tenant admission before a digest can be read."""

    def __init__(self, workspace: TenantWorkspace, context: TenantExecutionContext) -> None:
        if context.scope != "artifact" or workspace.tenant_key != context.tenant_key:
            raise TenantAuthorizationError("artifact store requires matching artifact-scoped tenant context")
        self.context = context
        self.root = pathlib.Path(workspace.workspace_root).resolve()
        self.store = ContentAddressedArtifactStore(self.root)
        self.index = self.root / ".chimera" / "tenant-artifact-index.json"

    def _load(self) -> set[str]:
        if not self.index.exists():
            return set()
        try:
            value = json.loads(self.index.read_text(encoding="utf-8"))
            return {str(item) for item in value}
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            raise TenantAuthorizationError("tenant artifact authorization index is invalid") from exc

    def _save(self, values: set[str]) -> None:
        temporary = self.index.with_suffix(".tmp")
        temporary.write_text(json.dumps(sorted(values)), encoding="utf-8")
        os.replace(temporary, self.index)

    def put(self, data: bytes | str, *, media_type: str = "application/octet-stream") -> ArtifactRef:
        ref = self.store.put(data, media_type=media_type, provenance={
            "tenant_key": self.context.tenant_key,
            "principal_hash": self.context.principal_hash,
            "grant_digest": self.context.grant_digest,
        })
        values = self._load(); values.add(ref.digest); self._save(values)
        return ref

    def get(self, digest: str) -> bytes:
        if digest not in self._load():
            raise TenantAuthorizationError("artifact digest is not admitted for this tenant")
        return self.store.get(digest)


class AuthorizedTenantWorkspaceBoundary:
    """Transport helper that authorizes before resolving any tenant workspace."""

    def __init__(
        self,
        root: pathlib.Path,
        *,
        trusted_key_ids: set[str] | frozenset[str],
    ) -> None:
        self.resolver = TenantWorkspaceResolver(root)
        self.guard = TenantAuthorizationGuard(trusted_key_ids=trusted_key_ids)

    def resolve(
        self,
        *,
        tenant: TenantContext,
        authenticated_principal: str,
        grant: TenantAuthorizationGrant,
        scope: TenantScope,
        now: float | None = None,
    ) -> tuple[TenantWorkspace, TenantExecutionContext, TenantAuthorizationReceipt]:
        context, receipt = self.guard.authorize(
            grant,
            tenant=tenant,
            authenticated_principal=authenticated_principal,
            scope=scope,
            now=now,
        )
        workspace = self.resolver.resolve(tenant)
        from .wal import WAL
        WAL(pathlib.Path(workspace.workspace_root)).append("tenant_authorization", {
            "tenant_key": context.tenant_key,
            "principal_hash": context.principal_hash,
            "grant_digest": context.grant_digest,
            "scope": context.scope,
            "authorized": True,
        })
        return workspace, context, receipt


def grant_from_file(path: pathlib.Path) -> TenantAuthorizationGrant:
    return TenantAuthorizationGrant.model_validate_json(pathlib.Path(path).read_text(encoding="utf-8"))
