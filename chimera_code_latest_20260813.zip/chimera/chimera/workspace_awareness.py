"""File-read/write awareness and soft conflict notifications across agents."""
from __future__ import annotations
import hashlib,pathlib
from .soft_interrupt import SoftInterruptQueue
from .wal import WAL
class WorkspaceAwareness:
 def __init__(self,root:pathlib.Path):self.root=pathlib.Path(root);self.wal=WAL(self.root);self.interrupts=SoftInterruptQueue(self.root)
 def read(self,actor:str,path:str,data:bytes):
  digest="sha256:"+hashlib.sha256(data).hexdigest();self.wal.append("workspace_read",{"actor":actor,"path":path,"digest":digest});return digest
 def write(self,actor:str,path:str,data:bytes):
  digest="sha256:"+hashlib.sha256(data).hexdigest();events=self.wal.replay();last_write=-1
  for e in events:
   if e["kind"]=="workspace_write" and e["data"].get("path")==path:last_write=e["seq"]
  readers=[]
  for e in events:
   if e["seq"]>last_write and e["kind"]=="workspace_read" and e["data"].get("path")==path and e["data"].get("actor")!=actor:readers.append(e["data"]["actor"])
  readers=list(dict.fromkeys(readers));self.wal.append("workspace_write",{"actor":actor,"path":path,"digest":digest,"notified":readers})
  for reader in readers:self.interrupts.enqueue(reader,f"File {path} changed in agent {actor} after you read it; refresh before editing. New digest {digest}.",source="system")
  return {"digest":digest,"notified":readers}
