"""Explicit branch-local candidate portfolios for genuinely ambiguous tasks.

This is a registration/comparison control plane, not an automatic multi-model
fan-out.  A host must explicitly create branches and candidates under the same
sealed campaign frame; no candidate is merged, selected, or promoted here.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import time
import uuid
from typing import Iterable, Literal

from pydantic import BaseModel, ConfigDict, Field

from .branch import TransactionalWorkspace
from .quality import TaskContract
from .wal import WAL


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class PortfolioFrame(_FrozenModel):
    model: str
    route: str
    max_output_tokens: int = Field(gt=0)
    request_deadline_seconds: float = Field(gt=0)
    corpus_hash: str
    evaluator_epoch: str
    protected_test_manifest_hash: str
    test_command: str = "pytest -q"

    @property
    def frame_hash(self) -> str:
        return _hash(self.model_dump(mode="json"))


class PortfolioCampaign(_FrozenModel):
    id: str
    task_hash: str
    contract_hash: str
    ambiguity_reason: str = Field(min_length=8, max_length=1_000)
    frame: PortfolioFrame
    created_at: float
    automatic_merge: bool = False
    automatic_promotion: bool = False


class PortfolioCandidate(_FrozenModel):
    id: str
    campaign_id: str
    branch: str
    frame_kind: Literal["hardened-conventional", "contradiction-resolution", "evidence-grounded-far-transfer"]
    diff_id: str
    operation_fingerprint: str
    changed_paths: tuple[str, ...]
    evidence_refs: tuple[str, ...] = ()
    registered_at: float


class DistinctnessAssessment(_FrozenModel):
    comparable: bool
    exact_duplicate: bool
    frame_kinds_distinct: bool
    path_overlap_ratio: float
    structural_status: Literal["observed-distinct", "unproven", "duplicate"]
    reason: str


class BranchCandidatePortfolio:
    """Register and compare explicit isolated candidates without winner authority."""

    def __init__(self, root: pathlib.Path, workspace: TransactionalWorkspace | None = None):
        self.root = pathlib.Path(root).resolve()
        self.workspace = workspace or TransactionalWorkspace(self.root)
        self.wal = WAL(self.root)

    @staticmethod
    def _contract_hash(contract: TaskContract) -> str:
        return _hash({
            "task": contract.task,
            "targets": [(item.path, item.mode, item.reason) for item in contract.targets],
            "tests": {path: hashlib.sha256(value.encode()).hexdigest() for path, value in sorted(contract.tests.items())},
            "protected": sorted(contract.protected_paths),
        })

    def create_campaign(self, *, contract: TaskContract, ambiguity_reason: str, frame: PortfolioFrame) -> PortfolioCampaign:
        if not frame.model or not frame.route:
            raise ValueError("portfolio frame requires an explicit model and route")
        campaign = PortfolioCampaign(
            id="portfolio:" + uuid.uuid4().hex,
            task_hash=_hash(contract.task),
            contract_hash=self._contract_hash(contract),
            ambiguity_reason=ambiguity_reason.strip(),
            frame=frame,
            created_at=time.time(),
        )
        self.wal.append("candidate_portfolio", {
            "event": "created", "campaign_id": campaign.id, "task_hash": campaign.task_hash,
            "contract_hash": campaign.contract_hash, "frame_hash": frame.frame_hash,
            "automatic_merge": False, "automatic_promotion": False,
        })
        return campaign

    def register(
        self,
        *,
        campaign: PortfolioCampaign,
        branch: str,
        frame_kind: Literal["hardened-conventional", "contradiction-resolution", "evidence-grounded-far-transfer"],
        evidence_refs: Iterable[str] = (),
    ) -> PortfolioCandidate:
        if not branch or branch == "main":
            raise ValueError("portfolio candidate requires an isolated non-main branch")
        if not (self.workspace.branches_dir / branch).exists():
            raise FileNotFoundError(f"candidate branch does not exist: {branch}")
        refs = tuple(sorted(set(str(item) for item in evidence_refs if str(item))))
        if frame_kind == "evidence-grounded-far-transfer" and not refs:
            raise ValueError("evidence-grounded far-transfer requires evidence references")
        diff = self.workspace.diff(branch)
        ops = diff.get("ops", [])
        if not isinstance(ops, list) or not ops:
            raise ValueError("portfolio candidate requires a non-empty branch diff")
        normalized = []
        paths = []
        for operation in ops:
            path = str(operation.get("path", ""))
            if not path or path.startswith("/") or ".." in pathlib.PurePosixPath(path).parts:
                raise ValueError("candidate contains unsafe diff path")
            paths.append(path)
            normalized.append({
                "op": str(operation.get("op", "")), "path": path,
                "hash": operation.get("hash"), "bytes": operation.get("bytes"),
            })
        candidate = PortfolioCandidate(
            id="candidate:" + uuid.uuid4().hex,
            campaign_id=campaign.id,
            branch=branch,
            frame_kind=frame_kind,
            diff_id=str(diff.get("id", "")),
            operation_fingerprint=_hash(normalized),
            changed_paths=tuple(sorted(set(paths))),
            evidence_refs=refs,
            registered_at=time.time(),
        )
        self.wal.append("candidate_portfolio", {
            "event": "registered", "campaign_id": campaign.id, "candidate_id": candidate.id,
            "branch": branch, "frame_kind": frame_kind, "diff_id": candidate.diff_id,
            "operation_fingerprint": candidate.operation_fingerprint,
            "changed_paths": list(candidate.changed_paths), "evidence_refs": list(refs),
        })
        return candidate

    @staticmethod
    def assess(left: PortfolioCandidate, right: PortfolioCandidate) -> DistinctnessAssessment:
        if left.campaign_id != right.campaign_id:
            return DistinctnessAssessment(
                comparable=False, exact_duplicate=False, frame_kinds_distinct=False,
                path_overlap_ratio=0.0, structural_status="unproven",
                reason="candidates belong to different campaigns",
            )
        exact = left.operation_fingerprint == right.operation_fingerprint
        left_paths, right_paths = set(left.changed_paths), set(right.changed_paths)
        overlap = len(left_paths & right_paths) / max(1, len(left_paths | right_paths))
        if exact:
            status: Literal["observed-distinct", "unproven", "duplicate"] = "duplicate"
            reason = "candidate diffs have identical operation fingerprints"
        elif overlap < 0.5 and left.frame_kind != right.frame_kind:
            status = "observed-distinct"
            reason = "different declared frames and low changed-path overlap"
        else:
            status = "unproven"
            reason = "diffs differ, but changed-path overlap does not prove mechanism distinctness"
        return DistinctnessAssessment(
            comparable=True,
            exact_duplicate=exact,
            frame_kinds_distinct=left.frame_kind != right.frame_kind,
            path_overlap_ratio=overlap,
            structural_status=status,
            reason=reason,
        )


def _hash(value: object) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()
