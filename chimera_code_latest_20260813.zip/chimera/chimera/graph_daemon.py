"""Private Unix-socket CodeGraph query daemon with snapshot drift checks."""

from __future__ import annotations

import hashlib
import json
import os
import pathlib
import socket
import socketserver
import threading
from typing import Any

from .graph import CodeGraph


def _snapshot(path: pathlib.Path) -> str:
    if not path.exists():
        return "missing"
    stat = path.stat()
    raw = f"{stat.st_dev}:{stat.st_ino}:{stat.st_size}:{stat.st_mtime_ns}".encode()
    return "sha256:" + hashlib.sha256(raw).hexdigest()


class _GraphService:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.graph = CodeGraph(self.root)
        self.lock = threading.RLock()
        self.loaded_snapshot = ""

    def query(self, request: dict[str, Any]) -> dict[str, Any]:
        query = request.get("query")
        limit = request.get("limit", 10)
        kind = request.get("kind")
        if not isinstance(query, str) or not query or not isinstance(limit, int):
            raise ValueError("graph daemon requires query and integer limit")
        if limit < 1 or limit > 200 or (kind is not None and not isinstance(kind, str)):
            raise ValueError("graph daemon query bounds are invalid")
        current = _snapshot(self.graph.store_path)
        expected = request.get("snapshot_id")
        if expected is not None and expected != current:
            raise RuntimeError("graph snapshot changed before query")
        with self.lock:
            # CodeGraph.search uses the persisted exact index without rebuilding
            # the full graph when the sidecar is current.
            if current != self.loaded_snapshot:
                self.graph = CodeGraph(self.root)
                self.loaded_snapshot = current
            items = self.graph.search(query, limit=limit, kind=kind)
        return {"items": items, "snapshot_id": current}


class _Handler(socketserver.StreamRequestHandler):
    def handle(self):
        line = self.rfile.readline(2_000_001)
        if len(line) > 2_000_000:
            response = {"error": "request too large"}
        else:
            try:
                request = json.loads(line)
                if not isinstance(request, dict):
                    raise TypeError("request must be an object")
                response = self.server.service.query(request)
            except Exception as exc:  # noqa: BLE001 - JSON-RPC transport boundary
                response = {"error": type(exc).__name__, "message": str(exc)[:300]}
        self.wfile.write(json.dumps(response, separators=(",", ":")).encode() + b"\n")


class GraphDaemon:
    def __init__(self, root: pathlib.Path, socket_path: pathlib.Path | None = None):
        self.root = pathlib.Path(root).resolve()
        self.socket_path = pathlib.Path(
            socket_path or self.root / ".chimera" / "graph.sock"
        )
        self.socket_path.parent.mkdir(parents=True, exist_ok=True)
        if self.socket_path.exists():
            self.socket_path.unlink(missing_ok=True)
        self.server = socketserver.ThreadingUnixStreamServer(
            str(self.socket_path), _Handler
        )
        self.server.daemon_threads = True
        self.server.service = _GraphService(self.root)
        os.chmod(self.socket_path, 0o600)

    def serve_forever(self) -> None:
        try:
            self.server.serve_forever(poll_interval=0.2)
        finally:
            self.server.server_close()
            if self.socket_path.exists():
                self.socket_path.unlink(missing_ok=True)

    def close(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        if self.socket_path.exists():
            self.socket_path.unlink(missing_ok=True)


class GraphDaemonClient:
    def __init__(
        self,
        root: pathlib.Path,
        socket_path: pathlib.Path | None = None,
        *,
        timeout: float = 2.0,
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.socket_path = pathlib.Path(
            socket_path or self.root / ".chimera" / "graph.sock"
        )
        self.timeout = max(0.05, float(timeout))

    @property
    def available(self) -> bool:
        return self.socket_path.exists() and self.socket_path.is_socket()

    def query(self, query: str, *, limit: int, kind: str | None = None):
        if not self.available:
            raise RuntimeError("graph daemon is unavailable")
        payload = (
            json.dumps(
                {
                    "query": query,
                    "limit": int(limit),
                    "kind": kind,
                },
                separators=(",", ":"),
            ).encode()
            + b"\n"
        )
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.settimeout(self.timeout)
            client.connect(str(self.socket_path))
            client.sendall(payload)
            chunks = bytearray()
            while not chunks.endswith(b"\n"):
                block = client.recv(65_536)
                if not block:
                    break
                chunks.extend(block)
                if len(chunks) > 8_000_000:
                    raise RuntimeError("graph daemon response exceeded limit")
        response = json.loads(chunks)
        if "error" in response:
            raise RuntimeError(
                "graph daemon query failed: "
                + str(response.get("message", response["error"]))
            )
        return response["items"]
