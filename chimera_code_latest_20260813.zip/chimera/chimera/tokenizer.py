"""Exact tokenizer measurement adapters with explicit unavailability.

Byte/4 estimates remain useful sizing heuristics but are never returned as
measured provider tokens by this module.
"""
from __future__ import annotations

import json
import os
import pathlib
import shlex
import subprocess
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict


class TokenMeasurement(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    status: Literal["measured", "unavailable", "error"]
    model: str
    tokenizer: Optional[str]
    tokens: Optional[int]
    reason: str


class TokenComparison(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    source: TokenMeasurement
    wire: TokenMeasurement
    reduction: Optional[float]


class TokenizerMeasurer:
    def __init__(self, command: Optional[str] = None, tokenizer_json: Optional[pathlib.Path] = None) -> None:
        self.command = command or os.environ.get("CHIMERA_TOKENIZER_CMD")
        configured_json = tokenizer_json or (
            pathlib.Path(os.environ["CHIMERA_TOKENIZER_JSON"])
            if os.environ.get("CHIMERA_TOKENIZER_JSON") else None
        )
        self.tokenizer_json = pathlib.Path(configured_json).resolve() if configured_json else None

    def _subprocess(self, model: str, text: str) -> TokenMeasurement:
        try:
            argv = shlex.split(self.command or "")
            if not argv:
                raise ValueError("empty tokenizer command")
            result = subprocess.run(
                argv, input=json.dumps({"model": model, "text": text}),
                capture_output=True, text=True, timeout=30,
                env={"PATH": os.environ.get("PATH", "")},
            )
            if result.returncode != 0:
                return TokenMeasurement(
                    status="error", model=model, tokenizer="subprocess", tokens=None,
                    reason=f"tokenizer command exited {result.returncode}: {result.stderr[-500:]}",
                )
            value = json.loads(result.stdout)
            tokens = value.get("tokens")
            if not isinstance(tokens, int) or tokens < 0:
                raise ValueError("tokenizer output must contain non-negative integer tokens")
            return TokenMeasurement(
                status="measured", model=model,
                tokenizer=str(value.get("tokenizer") or "subprocess"), tokens=tokens,
                reason="exact external tokenizer command",
            )
        except Exception as exc:
            return TokenMeasurement(
                status="error", model=model, tokenizer="subprocess", tokens=None,
                reason=f"{type(exc).__name__}: {exc}",
            )

    def _local_json(self, model: str, text: str) -> Optional[TokenMeasurement]:
        if self.tokenizer_json is None:
            return None
        if not self.tokenizer_json.exists():
            return TokenMeasurement(
                status="error", model=model, tokenizer="tokenizers-json", tokens=None,
                reason=f"tokenizer JSON not found: {self.tokenizer_json}",
            )
        try:
            from tokenizers import Tokenizer
        except ImportError:
            return TokenMeasurement(
                status="unavailable", model=model, tokenizer="tokenizers-json", tokens=None,
                reason="Python package 'tokenizers' is not installed",
            )
        try:
            tokenizer = Tokenizer.from_file(str(self.tokenizer_json))
            count = len(tokenizer.encode(text).ids)
            return TokenMeasurement(
                status="measured", model=model, tokenizer=str(self.tokenizer_json),
                tokens=count, reason="exact local tokenizer.json",
            )
        except Exception as exc:
            return TokenMeasurement(
                status="error", model=model, tokenizer="tokenizers-json", tokens=None,
                reason=f"{type(exc).__name__}: {exc}",
            )

    @staticmethod
    def _tiktoken(model: str, text: str) -> Optional[TokenMeasurement]:
        try:
            import tiktoken
        except ImportError:
            return None
        try:
            encoding = tiktoken.encoding_for_model(model)
        except KeyError:
            return None
        return TokenMeasurement(
            status="measured", model=model, tokenizer=f"tiktoken:{encoding.name}",
            tokens=len(encoding.encode(text)), reason="exact tiktoken model mapping",
        )

    def measure(self, model: str, text: str) -> TokenMeasurement:
        if self.command:
            return self._subprocess(model, text)
        local = self._local_json(model, text)
        if local is not None:
            return local
        known = self._tiktoken(model, text)
        if known is not None:
            return known
        return TokenMeasurement(
            status="unavailable", model=model, tokenizer=None, tokens=None,
            reason=(
                "no exact tokenizer configured for this model; set CHIMERA_TOKENIZER_CMD "
                "or CHIMERA_TOKENIZER_JSON. Byte estimates were not relabeled as measurements."
            ),
        )

    def compare(self, model: str, source: str, wire: str) -> TokenComparison:
        left = self.measure(model, source)
        right = self.measure(model, wire)
        reduction = None
        if left.status == right.status == "measured" and left.tokens is not None and right.tokens is not None:
            reduction = 0.0 if left.tokens == 0 else 1.0 - right.tokens / left.tokens
        return TokenComparison(source=left, wire=right, reduction=reduction)
