"""Single typed compiler for model-visible prompt context.

This wraps existing ContextPackBuilder and TypedContextCompiler behind one
versioned object.  It deliberately preserves the model-facing text order while
making selection/manifests reproducible and reusable across tool loops, DAG
handoffs, and focused coding prompts.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Iterable

from .context_pack import ContextPackBuilder
from .typed_context import TypedContextCompiler, TypedContextItem, TypedContextSelection


@dataclass(frozen=True)
class ContextPlan:
    model: str
    snapshot_id: str
    items: tuple[TypedContextItem, ...]
    max_tokens: int
    max_chars: int

    @property
    def digest(self) -> str:
        payload = {
            "model": self.model, "snapshot_id": self.snapshot_id,
            "items": [
                {**asdict(item), "content_hash": item.content_hash}
                for item in self.items
            ],
            "max_tokens": self.max_tokens, "max_chars": self.max_chars,
        }
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True)
class CompiledContextPlan:
    plan_hash: str
    text: str
    selection: TypedContextSelection

    def evidence(self) -> dict:
        return {
            "plan_hash": self.plan_hash,
            "tokens": self.selection.selection.tokens,
            "chars": self.selection.selection.chars,
            "token_kind": self.selection.selection.token_kind,
            "budget_satisfied": self.selection.selection.budget_satisfied,
            "max_tokens": self.selection.selection.max_tokens,
            "max_chars": self.selection.selection.max_chars,
            "overrun_tokens": self.selection.selection.overrun_tokens,
            "overrun_chars": self.selection.selection.overrun_chars,
            "decisions": [asdict(row) for row in self.selection.selection.decisions],
            "manifest": self.selection.manifest_dict(),
        }


class ContextBudgetExceeded(RuntimeError):
    pass


class ContextPlanCompiler:
    def __init__(self, typed: TypedContextCompiler | None = None) -> None:
        self.typed = typed or TypedContextCompiler()
        self._builders: dict[str, ContextPackBuilder] = {}

    def compile(self, plan: ContextPlan) -> CompiledContextPlan:
        builder = self._builders.setdefault(plan.model, ContextPackBuilder(plan.model))
        selection = self.typed.compile(
            plan.items, builder=builder, max_tokens=plan.max_tokens, max_chars=plan.max_chars,
        )
        if not selection.selection.budget_satisfied:
            raise ContextBudgetExceeded(
                "required preserved context exceeds the declared token/character budget: "
                f"tokens+={selection.selection.overrun_tokens}, "
                f"chars+={selection.selection.overrun_chars}"
            )
        return CompiledContextPlan(plan.digest, selection.selection.text, selection)
