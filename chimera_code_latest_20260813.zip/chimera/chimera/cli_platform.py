"""Platform readiness CLI commands."""
from __future__ import annotations

import json
import pathlib

import click
from rich.json import JSON


def register(main: click.Group, *, console, cli_root, emit) -> None:
    _cli_root = cli_root
    _emit = emit

    @main.group("platform")
    def platform_group():
        """Local-to-cloud deployment readiness evidence."""
        pass


    @platform_group.command("doctor")
    @click.option("--workspace", default=".")
    @click.option("--profile", type=click.Choice([
        "LOCAL_DETERMINISTIC", "DEV_EXTERNAL", "SELF_HOSTED", "CLOUD_MULTI_TENANT",
        "local", "cloud", "enterprise", "cloud-postgres", "durable-restate", "sandbox-linux", "cloud-runtime",
    ]), default="LOCAL_DETERMINISTIC")
    def platform_doctor(workspace, profile):
        from .platform import PlatformDoctor
        report = PlatformDoctor(pathlib.Path(workspace)).inspect(profile)
        console.print(JSON(report.model_dump_json(indent=2)))


    @platform_group.command("certify-bwrap")
    @click.option("--workspace", default=".")
    def platform_certify_bwrap(workspace):
        from .sandbox_certification import MaterializedBubblewrapCertifier
        receipt = MaterializedBubblewrapCertifier(pathlib.Path(workspace)).run()
        console.print(JSON(receipt.model_dump_json(indent=2)))


    @platform_group.command("compute-plan")
    @click.argument("task")
    @click.option("--latency-priority", is_flag=True)
    def platform_compute_plan(task, latency_priority):
        """Plan System-1/System-2 reasoning budget without a provider call."""
        from .inference_compute import InferenceComputePlanner
        click.echo(InferenceComputePlanner().plan(task, latency_priority=latency_priority).model_dump_json(indent=2))

    @platform_group.command("capability-per-kb-plan")
    def platform_capability_per_kb_plan():
        """Print disruptive capability-per-resident-KB optimization plan."""
        from .per_kb_optimizer import CapabilityPerKbPlanner
        click.echo(json.dumps(CapabilityPerKbPlanner().plan(), indent=2, sort_keys=True, default=str))

    @platform_group.command("sota-invariant-audit")
    @click.argument("path", required=False, default=".")
    def platform_sota_invariant_audit(path):
        """Audit SOTA-style router/scoreboard/release/hook invariants."""
        from .lazycodex_sota_transfers import SOTASkillInvariantAudit
        click.echo(json.dumps(SOTASkillInvariantAudit(pathlib.Path(path)).run(), indent=2, sort_keys=True, default=str))

    @platform_group.command("lazycodex-transfer-smoke")
    def platform_lazycodex_transfer_smoke():
        """Smoke-test ranked WAF, visual diff, comment extraction, and team-state transfers."""
        from .lazycodex_sota_transfers import (
            CommentRequestExtractor, DecodedImage, RankedWAFProfileDetector,
            TeamCoordinationState, VisualDiffHotspots,
        )
        waf = RankedWAFProfileDetector().rank(headers={"cf-ray":"x"}, cookies={"cf_clearance":"y"}, body="")
        ref = DecodedImage(1, 1, bytes([0,0,0,255]))
        act = DecodedImage(1, 1, bytes([255,0,0,255]))
        diff = VisualDiffHotspots.diff(ref, act)
        comments = CommentRequestExtractor().extract({"toolName":"Write","input":{"file_path":"a.py","content":"x"},"content":[{"type":"text","text":"ok"}]})
        team = TeamCoordinationState(team_name="T", session_name="S")
        team.add_member("a", "api"); team.add_member("b", "tests")
        click.echo(json.dumps({"schema_version":"chimera.lazycodex-transfer-smoke.v1","waf":waf,"diff":diff,"comments":comments,"team":team.as_dict(),"team_ready":team.ready(),"promotion_allowed":False}, indent=2, sort_keys=True, default=str))

    @platform_group.command("skill-library-audit")
    @click.argument("path", required=False, default=".")
    def platform_skill_library_audit(path):
        """Audit Skill-style instruction libraries for SOTA-style invariants."""
        from .skill_library_audit import SkillLibraryAudit
        click.echo(json.dumps(SkillLibraryAudit(pathlib.Path(path)).run(), indent=2, sort_keys=True, default=str))

    @platform_group.command("session-start-guard-smoke")
    @click.option("--namespace", default="default", show_default=True)
    def platform_session_start_guard_smoke(namespace):
        """Exercise stale-lock/cooldown guard used by optional session-start probes."""
        from .session_start_guard import SessionStartGuard
        guard = SessionStartGuard(_cli_root(), namespace=namespace)
        lock = guard.acquire_lock(stale_seconds=1)
        owned = bool(lock.get("lock") and guard.lock_is_owned(lock["lock"]))
        released = bool(lock.get("lock") and guard.release_lock(lock["lock"]))
        failure = guard.record_failure("smoke", base_seconds=1, max_seconds=4)
        cooldown = guard.read_cooldown(base_seconds=1, max_seconds=4)
        guard.clear_cooldown()
        click.echo(json.dumps({"schema_version":"chimera.session-start-guard-smoke.v1","lock":lock,"owned":owned,"released":released,"failure":failure,"cooldown":cooldown,"promotion_allowed":False}, indent=2, sort_keys=True, default=str))

    @platform_group.command("project-forge-plan")
    @click.argument("prompt")
    @click.option("--path", "paths", multiple=True, help="optional repo/file paths that make this mid-build/post-build")
    def platform_project_forge_plan(prompt, paths):
        """Run Project Forge gates for build-vs-reuse/architecture decisions."""
        from .project_forge_agent import ProjectForgeAgent
        click.echo(json.dumps(ProjectForgeAgent(_cli_root()).plan(prompt, paths=paths), indent=2, sort_keys=True, default=str))

    @platform_group.command("self-improvement-task-bank-campaign")
    @click.option("--chimera-copies", default=3, type=click.IntRange(1, 16), show_default=True)
    @click.option("--levels", default=3, type=click.IntRange(1, 3), show_default=True)
    @click.option("--output", type=click.Path(path_type=pathlib.Path), default=None)
    @click.option("--record-history", is_flag=True)
    def platform_self_improvement_task_bank_campaign(chimera_copies, levels, output, record_history):
        """Run short self-improvement campaign through evaluator-owned task bank."""
        from .self_improvement_task_bank_campaign import SelfImprovementTaskBankCampaign
        result = SelfImprovementTaskBankCampaign(_cli_root()).run(chimera_copies=chimera_copies, levels=levels)
        if output is not None:
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(json.dumps(result, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
        if record_history:
            from .gate_history import GateHistoryLedger
            GateHistoryLedger(_cli_root()).append(result)
        click.echo(json.dumps(result, indent=2, sort_keys=True, default=str))

    @platform_group.command("recursive-self-improvement-plan")
    @click.option("--current-levels", default=3, type=click.IntRange(1, 3), show_default=True)
    @click.option("--next-levels", default=3, type=click.IntRange(1, 3), show_default=True)
    @click.option("--chimera-copies", default=4, type=click.IntRange(1, 64), show_default=True)
    @click.option("--receipt", is_flag=True, help="emit structural non-promotional recursive receipt")
    def platform_recursive_self_improvement_plan(current_levels, next_levels, chimera_copies, receipt):
        """Plan self-improvement that also improves the next self-improvement iteration."""
        from .self_improvement_recursion import RecursiveSelfImprovementPlanner
        planner = RecursiveSelfImprovementPlanner(_cli_root())
        value = planner.structural_receipt(current_levels=current_levels, next_levels=next_levels, chimera_copies=chimera_copies) if receipt else planner.plan(current_levels=current_levels, next_levels=next_levels, chimera_copies=chimera_copies)
        click.echo(json.dumps(value, indent=2, sort_keys=True, default=str))

    @platform_group.command("self-improvement-plan")
    @click.option("--chimera-copies", default=3, type=click.IntRange(1, 64), show_default=True)
    @click.option("--levels", default=3, type=click.IntRange(1, 3), show_default=True)
    @click.option("--receipt", is_flag=True, help="emit a non-promotional structural receipt")
    def platform_self_improvement_plan(chimera_copies, levels, receipt):
        """Plan multi-Chimera adversarial self-improvement without self-certification."""
        from .self_improvement_gauntlet import SelfImprovementGauntlet
        gauntlet = SelfImprovementGauntlet(_cli_root())
        value = gauntlet.simulated_receipt(chimera_copies=chimera_copies, levels=levels) if receipt else gauntlet.plan(chimera_copies=chimera_copies, levels=levels)
        click.echo(json.dumps(value, indent=2, sort_keys=True, default=str))



    @platform_group.command("stack-alternatives-plan")
    def platform_stack_alternatives_plan():
        """Emit benchmark-gated optional stack alternatives matrix."""
        from .stack_alternatives import StackAlternativesPlanner
        click.echo(json.dumps(StackAlternativesPlanner(_cli_root()).plan(), indent=2, sort_keys=True, default=str))


    @platform_group.command("event-bus-benchmark")
    @click.option("--candidate", default="jsonl,nats,redpanda,honker,forq,smoothmq,pgmq", show_default=True, help="comma-separated event bus candidates")
    @click.option("--operations", default=1000, type=click.IntRange(1, 100000), show_default=True)
    def platform_event_bus_benchmark(candidate, operations):
        """Benchmark local event bus baseline and honestly skip unavailable external buses."""
        from .stack_benchmarks import StackBenchmarkRunner
        candidates = tuple(part.strip() for part in str(candidate).split(",") if part.strip())
        click.echo(json.dumps(StackBenchmarkRunner(_cli_root()).event_bus(candidates=candidates, operations=operations), indent=2, sort_keys=True, default=str))

    @platform_group.command("cache-benchmark")
    @click.option("--candidate", default="memory,valkey,dragonfly,garnet", show_default=True, help="comma-separated cache candidates")
    @click.option("--operations", default=1000, type=click.IntRange(1, 100000), show_default=True)
    def platform_cache_benchmark(candidate, operations):
        """Benchmark local cache baseline and honestly skip unavailable external caches."""
        from .stack_benchmarks import StackBenchmarkRunner
        candidates = tuple(part.strip() for part in str(candidate).split(",") if part.strip())
        click.echo(json.dumps(StackBenchmarkRunner(_cli_root()).cache(candidates=candidates, operations=operations), indent=2, sort_keys=True, default=str))

    @platform_group.command("gateway-fidelity-benchmark")
    @click.option("--endpoint", required=True, help="OpenAI-compatible /chat/completions endpoint; host only is recorded")
    @click.option("--model", required=True)
    @click.option("--auth-env", default=None, help="env var containing bearer token; name only is recorded")
    @click.option("--stream", "stream", is_flag=True)
    @click.option("--prompt", default="ping", show_default=True)
    @click.option("--record-history", is_flag=True)
    def platform_gateway_fidelity_benchmark(endpoint, model, auth_env, stream, prompt, record_history):
        """Benchmark OpenAI-compatible gateway fidelity for trace/session/usage/streaming."""
        from .gateway_fidelity import OpenAIGatewayFidelityBenchmark
        result = OpenAIGatewayFidelityBenchmark(_cli_root()).run(endpoint=endpoint, model=model, auth_env=auth_env, stream=stream, prompt=prompt)
        if record_history:
            from .gate_history import GateHistoryLedger
            GateHistoryLedger(_cli_root()).append(result)
        click.echo(json.dumps(result, indent=2, sort_keys=True, default=str))

    @platform_group.command("gateway-benchmark")
    @click.option("--candidate", default="direct-mock,litellm,agentgateway,agentify-gateway,bifrost,aisix", show_default=True, help="comma-separated gateway candidates")
    @click.option("--operations", default=1000, type=click.IntRange(1, 100000), show_default=True)
    @click.option("--endpoint", default=None, help="operator-supplied OpenAI-compatible /chat/completions endpoint for candidate=http")
    @click.option("--model", default="mock", show_default=True)
    def platform_gateway_benchmark(candidate, operations, endpoint, model):
        """Benchmark direct mock gateway baseline and skip unconfigured gateway services honestly."""
        from .stack_benchmarks import StackBenchmarkRunner
        candidates = tuple(part.strip() for part in str(candidate).split(",") if part.strip())
        click.echo(json.dumps(StackBenchmarkRunner(_cli_root()).gateway(candidates=candidates, operations=operations, endpoint=endpoint, model=model), indent=2, sort_keys=True, default=str))

    @platform_group.command("durable-benchmark")
    @click.option("--candidate", default="local-step,restate,dbos,obelisk,go-workflows,pg-durable,honker,rivet-actors,orch8,durable-workflow-server,durabletask-go,wippy", show_default=True)
    @click.option("--operations", default=1000, type=click.IntRange(1, 100000), show_default=True)
    def platform_durable_benchmark(candidate, operations):
        """Benchmark local durable-step baseline and honestly skip unconfigured workflow engines."""
        from .stack_benchmarks import StackBenchmarkRunner
        candidates = tuple(part.strip() for part in str(candidate).split(",") if part.strip())
        click.echo(json.dumps(StackBenchmarkRunner(_cli_root()).durable(candidates=candidates, operations=operations), indent=2, sort_keys=True, default=str))

    @platform_group.command("sandbox-benchmark")
    @click.option("--candidate", default="local-process,wasmtime,crun,youki,cubesandbox,hyperlight-wasm,sandlock,agentjail,kata-cloud-hypervisor,matchlock,boxlite,cocoon,openshell,ai-jail-greywall", show_default=True)
    @click.option("--operations", default=10, type=click.IntRange(1, 1000), show_default=True)
    def platform_sandbox_benchmark(candidate, operations):
        """Benchmark local process spawn and honestly skip unconfigured sandbox engines."""
        from .stack_benchmarks import StackBenchmarkRunner
        candidates = tuple(part.strip() for part in str(candidate).split(",") if part.strip())
        click.echo(json.dumps(StackBenchmarkRunner(_cli_root()).sandbox(candidates=candidates, operations=operations), indent=2, sort_keys=True, default=str))

    @platform_group.command("sandbox-alternatives-plan")
    def platform_sandbox_alternatives_plan():
        """Emit sandbox candidates and explicit non-equivalence warnings."""
        from .stack_alternatives import StackAlternativesPlanner
        plan = StackAlternativesPlanner(_cli_root()).plan()
        plan["alternatives"] = [item for item in plan["alternatives"] if item.get("category") == "sandbox"]
        click.echo(json.dumps(plan, indent=2, sort_keys=True, default=str))

    @platform_group.command("tokenrouter-transient-smoke")
    @click.option("--authorize-live-call", is_flag=True, help="required; consumes TokenRouter quota")
    @click.option("--no-provider-canary", is_flag=True, help="only run direct OpenAI-compatible ping")
    @click.option("--prompt", default="ping", show_default=True)
    @click.option("--model", default="moonshotai/kimi-k3-free", show_default=True, help="allowed transient TokenRouter model")
    def platform_tokenrouter_transient_smoke(authorize_live_call, no_provider_canary, prompt, model):
        """Run guarded live TokenRouter/Kimi transient smoke without recording the raw key."""
        if not authorize_live_call:
            raise click.UsageError("--authorize-live-call is required; also set CHIMERA_TESTING_ENVIRONMENT=1 and CHIMERA_TEST_ROUTE=tokenrouter-kimi-cancellation-v1")
        from .tokenrouter_transient import TokenRouterTransientSmoke
        result = TokenRouterTransientSmoke(_cli_root()).run(
            authorize_live_call=authorize_live_call,
            run_provider_canary=not no_provider_canary,
            prompt=prompt,
            model=model,
        )
        click.echo(json.dumps(result, indent=2, sort_keys=True, default=str))

    @platform_group.command("verify-adversarial-campaign")
    @click.option("--live-tokenrouter", is_flag=True, help="run TokenRouter/Kimi canary only if transient testing env guard is set")
    @click.option("--output", type=click.Path(path_type=pathlib.Path), default=None, help="optional artifact path")
    def platform_verify_adversarial_campaign(live_tokenrouter, output):
        """Run short verify_benchmark-inspired adversarial tasks against Chimera itself."""
        from .verify_adversarial_campaign import ShortChimeraVerifyAdversarialCampaign
        result = ShortChimeraVerifyAdversarialCampaign(_cli_root()).run(live_tokenrouter=live_tokenrouter)
        if output is not None:
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(json.dumps(result, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
        click.echo(json.dumps(result, indent=2, sort_keys=True, default=str))

    @platform_group.command("trusted-evaluators-template")
    @click.argument("path", type=click.Path(path_type=pathlib.Path))
    @click.option("--key-id", default="ed25519:<fill>", show_default=True)
    @click.option("--name", default="evaluator", show_default=True)
    def platform_trusted_evaluators_template(path, key_id, name):
        """Write a trusted evaluator registry template."""
        from .trusted_evaluators import TrustedEvaluatorRegistry
        click.echo(json.dumps(TrustedEvaluatorRegistry.write_template(path, key_id=key_id, name=name), indent=2, sort_keys=True, default=str))

    @platform_group.command("exploit-scan")
    @click.argument("path", required=False, default=".")
    @click.option("--waiver-file", type=click.Path(path_type=pathlib.Path), default=None, help="exact evaluator-owned waiver file")
    @click.option("--require-signed-waivers", is_flag=True, help="ignore unsigned waivers")
    @click.option("--trusted-evaluators", type=click.Path(path_type=pathlib.Path), default=None, help="trusted evaluator key registry")
    @click.option("--write-waiver-template", type=click.Path(path_type=pathlib.Path), default=None, help="write template waivers for current findings and exit")
    @click.option("--sign-waiver-template", is_flag=True, help="sign template with CHIMERA_CONTEXT_SIGNING_KEY or ephemeral key")
    @click.option("--record-history", is_flag=True)
    def platform_exploit_scan(path, waiver_file, require_signed_waivers, trusted_evaluators, write_waiver_template, sign_waiver_template, record_history):
        """Scan benchmark/eval worktrees for verifier-cheating and sandbox-escape patterns."""
        from .benchmark_exploit_scanner import BenchmarkExploitScanner
        from .evaluator_waivers import EvaluatorWaiverLedger
        scanner = BenchmarkExploitScanner(pathlib.Path(path))
        if write_waiver_template is not None:
            raw = scanner.scan(waiver_path=pathlib.Path("/__no_such_waiver__"))
            signer = None
            if sign_waiver_template:
                from .context_evidence import ContextSigner
                signer = ContextSigner.from_environment_or_ephemeral()
            template = EvaluatorWaiverLedger.write_template(write_waiver_template, raw.get("findings", []), signer=signer)
            click.echo(json.dumps(template, indent=2, sort_keys=True, default=str))
            return
        result = scanner.scan(waiver_path=waiver_file, require_signed_waivers=require_signed_waivers, trusted_evaluators_path=trusted_evaluators)
        if record_history:
            from .gate_history import GateHistoryLedger
            GateHistoryLedger(_cli_root()).append(result)
        click.echo(json.dumps(result, indent=2, sort_keys=True, default=str))

    @platform_group.command("cloud-scale-smoke")
    @click.option("--agents", default=1000, type=click.IntRange(1, 1000000), show_default=True)
    @click.option("--tenants", default=100, type=click.IntRange(1, 1000000), show_default=True)
    def platform_cloud_scale_smoke(agents, tenants):
        """Execute deterministic shard lease/hibernate/drain smoke for many agents."""
        from .agent_shard_controller import cloud_scale_smoke
        click.echo(json.dumps(cloud_scale_smoke(_cli_root(), agents=agents, tenants=tenants), indent=2, sort_keys=True, default=str))

    @platform_group.command("evaluator-task-bank")
    @click.option("--levels", default=3, type=click.IntRange(1, 3), show_default=True)
    @click.option("--smoke", is_flag=True, help="also verify hidden-test materialization seals without leaking bodies")
    def platform_evaluator_task_bank(levels, smoke):
        """Emit evaluator-owned task catalog with hidden-test seals only."""
        from .evaluator_task_bank import EvaluatorOwnedTaskBank
        bank = EvaluatorOwnedTaskBank()
        value = bank.smoke() if smoke else bank.public_catalog(levels=levels)
        click.echo(json.dumps(value, indent=2, sort_keys=True, default=str))

    @platform_group.command("candidate-promotion-gate")
    @click.argument("candidate_path", type=click.Path(path_type=pathlib.Path))
    @click.option("--task", default="", help="task/change summary for Project Forge gates")
    @click.option("--visible-test", default=None, help="shell-free command parsed with shlex; e.g. 'pytest -q tests/x.py'")
    @click.option("--hidden-test", default=None, help="evaluator-owned hidden test command; required for promotion_allowed")
    @click.option("--task-bank-id", default=None, help="use evaluator-owned task bank visible/hidden tests by id")
    @click.option("--waiver-file", type=click.Path(path_type=pathlib.Path), default=None, help="exact evaluator-owned exploit-scan waiver file")
    @click.option("--require-signed-waivers", is_flag=True, help="ignore unsigned exploit-scan waivers")
    @click.option("--trusted-evaluators", type=click.Path(path_type=pathlib.Path), default=None, help="trusted evaluator key registry")
    @click.option("--authorize-promotion-evaluation", is_flag=True, help="allows gate to return promotion_allowed when all checks pass; never applies promotion")
    @click.option("--timeout-seconds", default=120.0, type=float, show_default=True)
    @click.option("--output", type=click.Path(path_type=pathlib.Path), default=None)
    @click.option("--record-history", is_flag=True)
    def platform_candidate_promotion_gate(candidate_path, task, visible_test, hidden_test, task_bank_id, waiver_file, require_signed_waivers, trusted_evaluators, authorize_promotion_evaluation, timeout_seconds, output, record_history):
        """Compose exploit scan + visible/hidden tests + architecture gates for a candidate."""
        from .candidate_promotion_gate import CandidatePromotionGate
        result = CandidatePromotionGate(_cli_root()).evaluate(
            candidate_path,
            task=task,
            visible_test=visible_test,
            hidden_test=hidden_test,
            task_bank_id=task_bank_id,
            waiver_file=waiver_file,
            require_signed_waivers=require_signed_waivers,
            trusted_evaluators_file=trusted_evaluators,
            authorize_promotion_evaluation=authorize_promotion_evaluation,
            timeout_seconds=timeout_seconds,
        )
        if output is not None:
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(json.dumps(result, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
        if record_history:
            from .gate_history import GateHistoryLedger
            GateHistoryLedger(_cli_root()).append(result)
        click.echo(json.dumps(result, indent=2, sort_keys=True, default=str))

    @platform_group.command("release-candidate-bundle")
    @click.option("--output", type=click.Path(path_type=pathlib.Path), default=pathlib.Path("artifacts/release_candidate_bundle.json"), show_default=True)
    @click.option("--run-tests", is_flag=True, help="include a full test-suite command summary")
    @click.option("--test-command", default="python -m pytest -q", show_default=True)
    @click.option("--record-history", is_flag=True)
    @click.option("--sign", is_flag=True, help="sign bundle with CHIMERA_CONTEXT_SIGNING_KEY or ephemeral key")
    def platform_release_candidate_bundle(output, run_tests, test_command, record_history, sign):
        """Collect release-candidate evidence bundle without secrets."""
        from .release_candidate_bundle import ReleaseCandidateBundleBuilder
        result = ReleaseCandidateBundleBuilder(_cli_root()).write(output, run_tests=run_tests, test_command=test_command, sign=sign)
        if record_history:
            from .gate_history import GateHistoryLedger
            GateHistoryLedger(_cli_root()).append(result)
        click.echo(json.dumps(result, indent=2, sort_keys=True, default=str))

    @platform_group.group("trusted-evaluators")
    def platform_trusted_evaluators():
        """Manage trusted evaluator registry templates."""
        pass

    @platform_trusted_evaluators.command("template")
    @click.argument("path", type=click.Path(path_type=pathlib.Path))
    @click.option("--key-id", default="ed25519:<fill>", show_default=True)
    @click.option("--name", default="evaluator", show_default=True)
    def platform_trusted_evaluators_template2(path, key_id, name):
        from .trusted_evaluators import TrustedEvaluatorRegistry
        click.echo(json.dumps(TrustedEvaluatorRegistry.write_template(path, key_id=key_id, name=name), indent=2, sort_keys=True, default=str))

    @platform_trusted_evaluators.command("list")
    @click.argument("path", type=click.Path(path_type=pathlib.Path))
    def platform_trusted_evaluators_list(path):
        from .trusted_evaluators import TrustedEvaluatorRegistry
        click.echo(json.dumps(TrustedEvaluatorRegistry.load(path).as_dict(), indent=2, sort_keys=True, default=str))

    @platform_trusted_evaluators.command("verify-waiver")
    @click.argument("waiver_file", type=click.Path(path_type=pathlib.Path))
    @click.argument("trusted_file", type=click.Path(path_type=pathlib.Path))
    def platform_trusted_evaluators_verify_waiver(waiver_file, trusted_file):
        from .evaluator_waivers import EvaluatorWaiverLedger
        from .trusted_evaluators import TrustedEvaluatorRegistry
        waivers = EvaluatorWaiverLedger.load(waiver_file)
        trusted = TrustedEvaluatorRegistry.load(trusted_file)
        rows = [{"path": w.path, "kind": w.kind, "signature_valid": w.verify_signature(), "trusted": trusted.allows(w.key_id, scope="waiver"), "key_id": w.key_id} for w in waivers]
        click.echo(json.dumps({"schema_version":"chimera.trusted-waiver-verification.v1","waiver_count":len(rows),"all_valid_and_trusted":all(r["signature_valid"] and r["trusted"] for r in rows),"rows":rows}, indent=2, sort_keys=True, default=str))

    @platform_group.command("deployment-blueprint")
    @click.option("--profile", type=click.Choice(["self-hosted-dense", "k8s", "edge-notes"]), default="self-hosted-dense", show_default=True)
    @click.option("--write", "write_dir", type=click.Path(path_type=pathlib.Path), default=None, help="optional directory to write blueprint files")
    def platform_deployment_blueprint(profile, write_dir):
        """Generate cloud/self-hosted deployment skeletons without secret values."""
        from .deployment_blueprints import DeploymentBlueprintBuilder
        builder = DeploymentBlueprintBuilder()
        result = builder.write(write_dir, profile=profile) if write_dir else builder.build(profile=profile)
        click.echo(json.dumps(result, indent=2, sort_keys=True, default=str))

    @platform_group.group("gate-history")
    def platform_gate_history():
        """Append/replay gate artifact history for trend tracking."""
        pass

    @platform_gate_history.command("append")
    @click.argument("artifact", type=click.Path(path_type=pathlib.Path))
    def platform_gate_history_append(artifact):
        from .gate_history import GateHistoryLedger
        click.echo(json.dumps(GateHistoryLedger(_cli_root()).append_artifact(artifact), indent=2, sort_keys=True, default=str))

    @platform_gate_history.command("trends")
    @click.option("--limit", default=100, type=click.IntRange(1, 10000), show_default=True)
    def platform_gate_history_trends(limit):
        from .gate_history import GateHistoryLedger
        click.echo(json.dumps(GateHistoryLedger(_cli_root()).trends(limit=limit), indent=2, sort_keys=True, default=str))

    @platform_group.command("gate-dashboard")
    @click.option("--recent", default=50, type=click.IntRange(1, 500), show_default=True)
    def platform_gate_dashboard(recent):
        """Summarize latest gate artifacts and cheap live readiness signals."""
        from .gate_dashboard import GateDashboardBuilder
        click.echo(json.dumps(GateDashboardBuilder(_cli_root()).build(recent=recent), indent=2, sort_keys=True, default=str))

    @platform_group.command("supreme-gate")
    @click.option("--scan-path", type=click.Path(path_type=pathlib.Path), default=None, help="path to exploit-scan; default is repo root")
    @click.option("--agents", default=1000, type=click.IntRange(1, 1000000), show_default=True)
    @click.option("--tenants", default=100, type=click.IntRange(1, 1000000), show_default=True)
    @click.option("--prompt", default="Should Chimera add or modify infrastructure for this engineering task?", show_default=True)
    @click.option("--output", type=click.Path(path_type=pathlib.Path), default=None)
    @click.option("--record-history", is_flag=True)
    def platform_supreme_gate(scan_path, agents, tenants, prompt, output, record_history):
        """Run composed local 11/10 readiness gate."""
        from .supreme_gate import SupremeGate
        result = SupremeGate(_cli_root()).run(scan_path=scan_path, agents=agents, tenants=tenants, project_prompt=prompt)
        if output is not None:
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(json.dumps(result, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
        if record_history:
            from .gate_history import GateHistoryLedger
            GateHistoryLedger(_cli_root()).append(result)
        click.echo(json.dumps(result, indent=2, sort_keys=True, default=str))

    @platform_group.command("architecture-ratchet")
    def platform_architecture_ratchet():
        """Block legacy module growth and flag oversized new modules."""
        from .architecture_ratchet import ArchitectureRatchet
        click.echo(json.dumps(ArchitectureRatchet(_cli_root()).run(), indent=2, sort_keys=True, default=str))

    @platform_group.command("architecture-audit")
    def platform_architecture_audit():
        """Audit antifragile hexagonal organization and promotion gates."""
        from .antifragile_architecture import AntifragileArchitectureAudit
        result = AntifragileArchitectureAudit(_cli_root()).run()
        click.echo(json.dumps(result, indent=2, sort_keys=True, default=str))

    @platform_group.command("cloud-scale-readiness")
    @click.option("--agents", default=1000, type=click.IntRange(1, 1000000), show_default=True)
    @click.option("--tenants", default=100, type=click.IntRange(1, 1000000), show_default=True)
    @click.option("--mode", type=click.Choice(["self-hosted", "k8s", "edge"]), default="self-hosted", show_default=True)
    def platform_cloud_scale_readiness(agents, tenants, mode):
        """Plan readiness for thousands of cloud Chimera agents without false certification."""
        from .cloud_scale_readiness import CloudScaleReadinessPlanner
        click.echo(json.dumps(CloudScaleReadinessPlanner(_cli_root()).plan(agents=agents, tenants=tenants, mode=mode), indent=2, sort_keys=True, default=str))

    @platform_group.command("runtime-density-benchmark")
    @click.option("--counts", default="1,10", show_default=True, help="comma-separated shell counts, capped at 1000 each")
    @click.option("--no-optional", is_flag=True, help="skip optional Rust/BEAM probes")
    def platform_runtime_density_benchmark(counts, no_optional):
        """Measure resident runtime overhead before promoting zygote/BEAM/Rust lanes."""
        from .runtime_density import RuntimeDensityBenchmark
        parsed = tuple(int(part.strip()) for part in str(counts).split(",") if part.strip())
        click.echo(json.dumps(RuntimeDensityBenchmark(_cli_root()).run(counts=parsed, include_optional=not no_optional), indent=2, sort_keys=True, default=str))

    @platform_group.command("rust-candidate-plan")
    @click.argument("module_or_path", default="chimera", required=False)
    def platform_rust_candidate_plan(module_or_path):
        """Rank typed Python hot paths for PyO3/depyler/py2many experiments."""
        from .rust_candidate_plan import RustCandidatePlanner
        click.echo(json.dumps(RustCandidatePlanner(_cli_root()).plan(module_or_path), indent=2, sort_keys=True, default=str))

    @platform_group.command("cloud-profile")
    @click.option("--mode", type=click.Choice(["selfhosted-cloud", "local"]), default="selfhosted-cloud", show_default=True)
    def platform_cloud_profile(mode):
        """Print cloud-native deployment guidance without secrets."""
        from .cloud_native_profile import CloudNativeProfilePlanner
        click.echo(CloudNativeProfilePlanner().build(mode=mode).model_dump_json(indent=2))

    @platform_group.command("slo")
    @click.option("--dashboard", type=click.Path(path_type=pathlib.Path), default=None)
    def platform_slo(dashboard):
        from .operational_slo import OperationalSLO
        slo = OperationalSLO(_cli_root())
        value = slo.snapshot()
        if dashboard is not None:
            value["dashboard"] = str(slo.write_dashboard(dashboard))
        _emit(value, failure=value["status"] == "breached")


