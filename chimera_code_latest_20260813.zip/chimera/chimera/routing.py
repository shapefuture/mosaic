"""Cheapest-capable model routing with evidence-earned locks and immediate unlock."""
from __future__ import annotations
import pathlib
from dataclasses import dataclass
from typing import Iterable,Optional
from .wal import WAL, wal_write

@dataclass(frozen=True)
class ModelRoute:
    model:str;capabilities:frozenset[str];input_cost:float;output_cost:float;latency_class:int
    def estimated_cost(self,input_tokens:int,output_tokens:int):return input_tokens/1e6*self.input_cost+output_tokens/1e6*self.output_cost

class RoutingLedger:
    def __init__(self,root:pathlib.Path):self.wal=WAL(pathlib.Path(root))
    def record(self,task_class:str,model:str,success:bool,quality:float,evidence_ref:str):
        if not evidence_ref:raise ValueError("routing outcomes require evidence")
        wal_write(self.wal, "routing_outcome",{"task_class":task_class,"model":model,"success":success,"quality":quality,"evidence_ref":evidence_ref})
    def history(self,task_class,model):return [e["data"] for e in self.wal.replay(kind="routing_outcome") if e["data"]["task_class"]==task_class and e["data"]["model"]==model]

class CapabilityRouter:
    def __init__(self,root:pathlib.Path,routes:Iterable[ModelRoute],quality_floor:float=.9,lock_after:int=3,context_registry=None):
        self.routes=tuple(routes);self.ledger=RoutingLedger(root);self.floor=quality_floor;self.lock_after=lock_after;self.context_registry=context_registry
    def _clean(self,task_class,route):
        rows=self.ledger.history(task_class,route.model);tail=rows[-self.lock_after:]
        return len(tail)>=self.lock_after and all(r["success"] and r["quality"]>=self.floor for r in tail)
    def choose(self,task_class:str,required:frozenset[str],input_tokens:int,output_tokens:int,explicit_model:Optional[str]=None,context_features:Optional[dict]=None):
        if explicit_model:
            route=next((r for r in self.routes if r.model==explicit_model),None)
            if route is None:raise KeyError(explicit_model)
            if not required<=route.capabilities:raise ValueError("explicit model lacks required capabilities")
            return {"route":route,"locked":False,"reason":"explicit user model preserved"}
        candidates=[r for r in self.routes if required<=r.capabilities]
        if not candidates:raise RuntimeError("no capable model route")
        candidates.sort(key=lambda r:(r.estimated_cost(input_tokens,output_tokens),r.latency_class,r.model))
        locked=[r for r in candidates if self._clean(task_class,r)]
        if self.context_registry is not None and context_features:
            contextual=self.context_registry.choose([item.model for item in candidates],task_class,context_features,task_value=1.,latency_weight=.0001,cost_weight=1.)
            if contextual.posterior.samples>=3:
                route=next(item for item in candidates if item.model==contextual.agent_id)
                return {"route":route,"locked":False,"reason":"evidence-backed contextual capability lower bound","contextual":contextual}
        route=locked[0] if locked else candidates[0]
        return {"route":route,"locked":bool(locked),"reason":"learned clean lock" if locked else "cheapest capable cold route"}
    def record(self,task_class:str,model:str,success:bool,quality:float,evidence_ref:str,*,context_features:Optional[dict]=None,latency_ms:float=0.,cost:float=0.):
        self.ledger.record(task_class,model,success,quality,evidence_ref)
        if self.context_registry is not None and context_features:
            self.context_registry.update(model,task_class,context_features,success=bool(success and quality>=self.floor),latency_ms=latency_ms,cost=cost,evidence_refs=[evidence_ref])
    def cascade(self,task_class:str,required:frozenset[str],input_tokens:int,output_tokens:int,gate):
        candidates=[r for r in self.routes if required<=r.capabilities];candidates.sort(key=lambda r:(r.estimated_cost(input_tokens,output_tokens),r.latency_class,r.model));attempts=[]
        for route in candidates:
            response=gate(route);attempts.append({"model":route.model,"accepted":bool(response.get("accepted")),"evidence":response.get("evidence")})
            if response.get("accepted"):return {"route":route,"response":response,"attempts":attempts,"escalated":len(attempts)>1}
        return {"route":None,"response":None,"attempts":attempts,"escalated":True}
