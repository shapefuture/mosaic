"""Protocol-hinted exact caching for modern MCP tool catalog pages.

MCP 2026-07-28 makes ``tools/list`` cacheable only when a complete result
supplies ``ttlMs`` and ``cacheScope``.  This cache follows those server hints
conservatively:

* caches the exact JSON result, never model/semantic similarity;
* keys on the complete request parameters for a single ``tools/list`` page;
* accepts only explicit ``resultType=complete``, a positive TTL, and public
  scope -- the proxy has no authenticated caller partition, so private results
  cannot safely be shared;
* caps freshness and performs no background refresh; and
* never caches MRTR ``input_required`` results or error responses.

It is deliberately small and in-memory.  It lowers repeated catalog-discovery
latency/token overhead but has no tool-call, capability, or trust authority.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
import hashlib
import json
import time
from typing import Any, Callable, Mapping


@dataclass(frozen=True)
class CatalogCacheReceipt:
    status: str  # hit | miss | bypass
    reason: str
    ttl_ms: int | None = None


@dataclass
class _CatalogEntry:
    result: dict[str, Any]
    expires_at: float
    ttl_ms: int


class MCPToolCatalogCache:
    def __init__(
        self,
        *,
        max_entries: int = 32,
        max_ttl_ms: int = 300_000,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.max_entries = max(1, int(max_entries))
        self.max_ttl_ms = max(0, int(max_ttl_ms))
        self.clock = clock
        self._entries: dict[str, _CatalogEntry] = {}

    @staticmethod
    def _key(params: Mapping[str, Any]) -> str:
        raw = json.dumps(dict(params), sort_keys=True, separators=(",", ":"), default=str).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    @staticmethod
    def _complete_public_ttl(response: Mapping[str, Any]) -> tuple[int | None, str]:
        result = response.get("result")
        if not isinstance(result, Mapping):
            return None, "no JSON-RPC result"
        if result.get("resultType") != "complete":
            return None, "not a modern complete result"
        # A client must not turn an absent/invalid newer-server cache hint into
        # a cacheable response.  Legacy results without this shape remain live.
        ttl = result.get("ttlMs")
        if isinstance(ttl, bool) or not isinstance(ttl, int) or ttl <= 0:
            return None, "non-positive or missing ttlMs"
        if result.get("cacheScope") != "public":
            return None, "non-public cache scope"
        return ttl, "server public cache hint"

    def get(self, params: Mapping[str, Any]) -> tuple[dict[str, Any] | None, CatalogCacheReceipt]:
        key = self._key(params)
        entry = self._entries.get(key)
        if entry is None:
            return None, CatalogCacheReceipt("miss", "no cached catalog page")
        if self.clock() >= entry.expires_at:
            self._entries.pop(key, None)
            return None, CatalogCacheReceipt("miss", "catalog page TTL expired", entry.ttl_ms)
        return copy.deepcopy(entry.result), CatalogCacheReceipt("hit", "fresh public catalog page", entry.ttl_ms)

    def put(self, params: Mapping[str, Any], response: Mapping[str, Any]) -> CatalogCacheReceipt:
        ttl, reason = self._complete_public_ttl(response)
        if ttl is None:
            return CatalogCacheReceipt("bypass", reason)
        ttl = min(ttl, self.max_ttl_ms)
        if ttl <= 0:
            return CatalogCacheReceipt("bypass", "TTL exceeds a zero local freshness cap")
        result = response.get("result")
        assert isinstance(result, Mapping)  # narrowed by _complete_public_ttl
        key = self._key(params)
        if len(self._entries) >= self.max_entries and key not in self._entries:
            # Exact caches need bounded lifecycle as much as prompt context.
            oldest = min(self._entries, key=lambda item: self._entries[item].expires_at)
            self._entries.pop(oldest, None)
        self._entries[key] = _CatalogEntry(
            result=copy.deepcopy(dict(result)),
            expires_at=self.clock() + ttl / 1000,
            ttl_ms=ttl,
        )
        return CatalogCacheReceipt("miss", reason, ttl)

    def invalidate(self, params: Mapping[str, Any] | None = None) -> int:
        if params is None:
            count = len(self._entries)
            self._entries.clear()
            return count
        return int(self._entries.pop(self._key(params), None) is not None)

    def snapshot(self) -> dict[str, int]:
        now = self.clock()
        return {
            "entries": sum(entry.expires_at > now for entry in self._entries.values()),
            "max_entries": self.max_entries,
            "max_ttl_ms": self.max_ttl_ms,
        }
