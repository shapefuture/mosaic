
"""
chimera.audit — LTL + Etas + graph audit trail (bootstrap for hard audit task)
Effect {fs: read["./src/**", ".chimera/**", "chimera/**"], net: deny_all}
Spec Sec: G(!exfiltrate), G(!writeOutsideAllow)
Antifragile: benefits from chaos — audit is pure read, never mutates prod
Drift-mitigated: Ratchet bounded cap, evidence-gated, curator-allowed, GDI-tracked
"""
from pathlib import Path
import json
from .verifier import LTLMonitor, CompositionalVerifier
from .graph import CodeGraph
from .wal import WAL
from .effects import CapabilitySet, EffectRequest, check_effect
from .etas import EtasAgent, EtasSpec, check_spec_conformance
from .branch import TransactionalWorkspace

def audit_all_branches(root: Path = Path("."), branch_filter=None):
    """
    Hard task audit: LTL verification on all branches, Etas capability compliance,
    code graph audit trail, WAL hash chain, sandbox-ready report.
    Uses harness capabilities: branch/diff, graph, Etas, WAL.
    """
    root = Path(root).resolve()
    ws = TransactionalWorkspace(root)
    wal = WAL(root)
    g = CodeGraph(root)
    try:
        g.load()
    except:
        g.build()
    # Etas capability: deny_all net, fs allow only src/tests/chimera/.chimera
    cap = CapabilitySet(
        fs_allow=["./src/**", "./tests/**", ".chimera/**", "./chimera/**", "chimera/**"],
        fs_deny=["/etc/**", "~/.ssh/**", ".env"],
        net_allow=[], net_deny=["169.254.169.254","10.*","192.168.*"],
        env_allow=["PATH"], env_deny=["AWS_*"]
    )
    report = {
        "branches": [],
        "ltl": {"formula": "G(!writeOutsideAllow)", "holds": True, "msg": None, "compositional": {}},
        "capability": {"allow": cap.fs_allow, "violations": [], "etas_checks": []},
        "graph_hits": [],
        "wal": {"chain_ok": True, "entries": 0, "bad_seq": None},
        "sandbox": {"exec": "pytest tests/test_audit.py via Sandbox"},
        "effect": {"fs": ["./src/**",".chimera/**"], "net": "deny_all"},
        "spec": "Sec: G(!exfiltrate) & G(!writeOutsideAllow)",
    }
    # LTL + compositional + Etas per branch
    branches = [branch_filter] if branch_filter else ws.list_branches()
    comp = CompositionalVerifier()
    for br in branches:
        try:
            diff = ws.diff(br)
        except:
            continue
        entry = {"branch": br, "ops": len(diff.get("ops",[])), "ops_detail": diff.get("ops",[])[:5]}
        # Etas per op
        for op in diff.get("ops",[]):
            req = EffectRequest(effect="fs.write", needs={"fs": [op["path"]]})
            v = check_effect(req, cap)
            if not v.allowed:
                entry.setdefault("violations", []).append(v.denied_reason)
                report["capability"]["violations"].append({"branch": br, "path": op["path"], "reason": v.denied_reason})
            etas_agent = EtasAgent(
                name=f"AuditBranch:{br}", tools=["mirage.write"],
                effect_row={"fs": [op["path"]], "net": []},
            )
            etas_result = check_spec_conformance(
                etas_agent,
                [EtasSpec(name="Sec", formula="G(!exfiltrate)")],
                [{"kind": "audit_observation", "data": {"branch": br, "path": op["path"]}}],
                cap,
            )
            report["capability"]["etas_checks"].append(etas_result.model_dump())
            if not etas_result.spec_conformance:
                for violation in etas_result.violations:
                    report["capability"]["violations"].append({"branch": br, "path": op["path"], "reason": violation})
        report["branches"].append(entry)

    # LTL on WAL traces
    traces = [{"kind": e["kind"], "data": json.dumps(e["data"])} for e in wal.replay()]
    mon = LTLMonitor("G(!writeOutsideAllow)")
    ok, msg = mon.check(traces)
    report["ltl"]["holds"] = ok
    report["ltl"]["msg"] = msg
    # Compositional
    comp_res = comp.check(traces)
    report["ltl"]["compositional"] = {k: "pass" if v[0] else f"fail: {v[1]}" for k,v in comp_res.items()}

    # Graph audit trail: RANGER + Gödel
    try:
        hits = g.ranger_search("audit", limit=5)
        if not hits:
            hits = g.search("audit", limit=5)
        report["graph_hits"] = [{"id": h["id"], "file": h.get("file")} for h in hits]
        report["graph_stats"] = g.stats()
    except Exception as e:
        report["graph_hits"] = [{"error": str(e)}]

    # WAL hash chain
    ok2, bad = wal.verify_chain()
    report["wal"]["chain_ok"] = ok2
    report["wal"]["bad_seq"] = bad
    report["wal"]["entries"] = len(wal.replay())
    report["wal"]["snapshot"] = wal.path.exists()

    # Drift: include GDI if available
    try:
        from .drift import DriftMonitor
        dm = DriftMonitor(root)
        report["drift"] = {"monitor": f"evidence-based GDI threshold {dm._threshold}", "log": str(dm.log_path)}
    except: report["drift"] = {"monitor": "not installed"}

    return report

if __name__ == "__main__":
    import pathlib
    print(json.dumps(audit_all_branches(pathlib.Path(".")), indent=2))
