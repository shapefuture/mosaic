"""Wire-format CLI commands."""
from __future__ import annotations

import json
import pathlib

import click
from rich.json import JSON


def register(main: click.Group, *, console) -> None:
    @main.group("wire")
    def wire_group():
        """GCF/JSON model-wire encoding utilities."""
        pass

    @wire_group.command("encode")
    @click.argument("path", type=click.Path(exists=True, dir_okay=False, path_type=pathlib.Path))
    @click.option("--format", "wire_format", type=click.Choice(["gcf", "auto", "json"]), default="gcf")
    def wire_encode(path, wire_format):
        from .wire import WireCodec
        data = json.loads(path.read_text())
        envelope = WireCodec().encode_generic(data, mode=wire_format)
        click.echo(envelope.model_text(), nl=False)

    @wire_group.command("decode")
    @click.argument("path", type=click.Path(exists=True, dir_okay=False, path_type=pathlib.Path))
    def wire_decode(path):
        from .wire import WireCodec
        value = WireCodec().decode(path.read_text())
        if hasattr(value, "__dict__"):
            value = value.__dict__
        click.echo(json.dumps(value, indent=2, default=str))

    @wire_group.command("stats")
    @click.argument("path", type=click.Path(exists=True, dir_okay=False, path_type=pathlib.Path))
    @click.option("--model", default=None, help="Model id for exact tokenizer measurement")
    @click.option("--tokenizer-command", default=None, help="Exact tokenizer CLI (JSON stdin/stdout contract)")
    def wire_stats(path, model, tokenizer_command):
        from .wire import WireCodec
        data = json.loads(path.read_text())
        codec = WireCodec()
        envelope = codec.encode_generic(data, mode="gcf")
        result = {
            "format": envelope.format,
            "source_bytes": envelope.source_bytes,
            "wire_bytes": envelope.wire_bytes,
            "reduction": envelope.reduction,
            "estimated_source_tokens": envelope.estimated_source_tokens,
            "estimated_wire_tokens": envelope.estimated_wire_tokens,
            "token_measurement": None,
        }
        if model:
            from .tokenizer import TokenizerMeasurer
            source = codec._json(data)
            result["token_measurement"] = TokenizerMeasurer(
                command=tokenizer_command
            ).compare(model, source, envelope.model_text()).model_dump(mode="json")
        console.print(JSON(json.dumps(result, indent=2)))

