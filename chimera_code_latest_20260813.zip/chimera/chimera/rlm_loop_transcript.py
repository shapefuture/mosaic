"""Tool-result projection and transcript materialisation for the model loop."""
from __future__ import annotations

import hashlib
from typing import Any


def materialize_tool_transcript(
    runtime: Any,
    *,
    branch: str,
    model: str,
    prompt: str,
    model_text: str,
    program: Any,
    plan: Any,
    source_calls: list[dict[str, Any]],
    tool_results: list[dict[str, Any]],
    evidence: list[dict[str, Any]],
) -> str:
    """Bound/model-wire tool observations without retaining raw graph payloads twice."""
    wire_session = f"{branch}:{hashlib.sha256(prompt.encode()).hexdigest()[:12]}"
    generic_results: list[dict[str, Any]] = []
    graph_sections: list[str] = []
    for result in tool_results:
        if isinstance(result, dict) and isinstance(result.get("hits"), list):
            graph_wire = runtime.wire.encode_graph(
                result["hits"], tool=str(result.get("tool") or "graph_search"),
                session_key=wire_session, mode="gcf",
            )
            generic_results.append({key: value for key, value in result.items() if key != "hits"} | {"hits_wire": "see following GCF graph section"})
            graph_sections.append(graph_wire.model_text())
            evidence.append(runtime._bind_wire_evidence(graph_wire, purpose="graph-tool-result", model=model, branch=branch))
            evidence.append({"tool": "wire_codec_graph", "ok": True, "format": graph_wire.format, "source_bytes": graph_wire.source_bytes, "wire_bytes": graph_wire.wire_bytes, "reduction": graph_wire.reduction})
        else:
            generic_results.append(result)
    context_results, compaction_stats = runtime._compact_tool_results(generic_results)
    evidence.append({"tool": "tool_context_compaction", "ok": True, **compaction_stats})
    wire_payload = (
        {"tool_result": {"tool": "chimera.run", "ok": all(bool(result.get("ok")) for result in context_results), "program_hash": program.program_hash, "plan_hash": plan.plan_hash, "steps": context_results}}
        if program else {"tool_results": context_results}
    )
    wire = runtime.wire.encode_generic(wire_payload, mode="auto")
    evidence.append(runtime._bind_wire_evidence(wire, purpose="tool-results", model=model, branch=branch))
    evidence.append({"tool": "wire_codec", "ok": True, "format": wire.format, "source_bytes": wire.source_bytes, "wire_bytes": wire.wire_bytes, "reduction": wire.reduction})
    graph_text = "\n".join(graph_sections)
    request_summary = runtime._tool_request_summary(model_text, source_calls)
    return (
        f"\n\nAssistant tool request summary:\n{request_summary}\n\n"
        f"Tool results ({wire.format}, reduction={wire.reduction:.1%}):\n{wire.model_text()[:24000]}\n"
        + (f"Graph sections (GCF session-deduplicated):\n{graph_text[:12000]}\n" if graph_text else "")
    )
