"""Hosted ASGI adapter for Chimera GUI HTTP/SSE endpoints."""
from __future__ import annotations

import asyncio
import json
import pathlib
import time
from typing import Any

from .gui_http import GuiHttpAdapter
from .run_event_bus import RunEventBus
from .telemetry_snapshot import TelemetrySnapshotBuilder


class ChimeraGuiASGI:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.http = GuiHttpAdapter(self.root)

    @staticmethod
    async def _send_json(send, status: int, payload: Any) -> None:
        body = json.dumps(payload, sort_keys=True, default=str).encode()
        await send({"type": "http.response.start", "status": status, "headers": [(b"content-type", b"application/json; charset=utf-8"), (b"cache-control", b"no-store")]})
        await send({"type": "http.response.body", "body": body})

    async def _sse(self, scope, receive, send) -> None:
        await send({"type": "http.response.start", "status": 200, "headers": [(b"content-type", b"text/event-stream; charset=utf-8"), (b"cache-control", b"no-cache"), (b"x-accel-buffering", b"no")]})
        for index in range(10):
            snapshot = TelemetrySnapshotBuilder(self.root).build(recent=50).model_dump(mode="json")
            payload = f"event: telemetry\nid: {index}\ndata: {json.dumps(snapshot, sort_keys=True, default=str)}\n\n".encode()
            await send({"type": "http.response.body", "body": payload, "more_body": True})
            try:
                message = await asyncio.wait_for(receive(), timeout=1.0)
                if message.get("type") == "http.disconnect":
                    return
            except asyncio.TimeoutError:
                pass
        await send({"type": "http.response.body", "body": b"event: done\ndata: {}\n\n", "more_body": False})

    async def _websocket(self, scope, receive, send) -> None:
        await send({"type": "websocket.accept", "headers": [(b"cache-control", b"no-store")]})
        bus = RunEventBus(self.root)
        after_id = None
        run_id = None
        for index in range(120):
            events = bus.replay(after_id=after_id, run_id=run_id, limit=100)
            if events:
                after_id = events[-1].get("id")
            snapshot = TelemetrySnapshotBuilder(self.root).build(recent=50).model_dump(mode="json")
            await send({
                "type": "websocket.send",
                "text": json.dumps({"type": "tick", "id": index, "ts": time.time(), "events": events, "snapshot": snapshot}, sort_keys=True, default=str),
            })
            try:
                message = await asyncio.wait_for(receive(), timeout=1.0)
                if message.get("type") == "websocket.disconnect":
                    return
                if message.get("type") == "websocket.receive" and message.get("text"):
                    try:
                        payload = json.loads(message.get("text") or "{}")
                        if isinstance(payload, dict) and isinstance(payload.get("run_id"), str):
                            run_id = payload["run_id"]
                    except json.JSONDecodeError:
                        pass
                    await send({"type": "websocket.send", "text": json.dumps({"type": "ack", "received": True, "run_id": run_id})})
            except asyncio.TimeoutError:
                pass
        await send({"type": "websocket.close", "code": 1000})

    async def __call__(self, scope, receive, send) -> None:
        if scope.get("type") == "websocket":
            await self._websocket(scope, receive, send)
            return
        if scope.get("type") != "http":
            return
        method = str(scope.get("method", "GET"))
        path = scope.get("path", "/")
        query = scope.get("query_string", b"").decode()
        full_path = path + (("?" + query) if query else "")
        if method == "GET" and path == "/api/events":
            await self._sse(scope, receive, send); return
        chunks = []
        while True:
            message = await receive()
            if message.get("type") == "http.disconnect":
                return
            if message.get("type") == "http.request":
                chunks.append(message.get("body", b""))
                if not message.get("more_body"):
                    break
        headers = {key.decode().lower(): value.decode() for key, value in scope.get("headers", [])}
        result = self.http.handle(method, full_path, body=b"".join(chunks), headers=headers)
        await send({"type": "http.response.start", "status": int(result["status"]), "headers": [(k.encode(), v.encode()) for k, v in result.get("headers", {}).items()]})
        await send({"type": "http.response.body", "body": str(result.get("body", "")).encode()})


def create_app(root: str | pathlib.Path = ".") -> ChimeraGuiASGI:
    return ChimeraGuiASGI(pathlib.Path(root))
