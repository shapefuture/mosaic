"""Tenant-scoped telemetry retention policies."""
from __future__ import annotations

import json
import os
import pathlib
import time
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class TelemetryRetentionReceipt:
    schema_version: str
    path: str
    before: int
    after: int
    removed: int
    tenant_key: str | None
    max_age_seconds: float | None
    max_rows: int
    dry_run: bool

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class TelemetryRetentionPolicy:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    @staticmethod
    def _tenant_of(row: dict[str, Any]) -> str | None:
        data = row.get("data") if isinstance(row.get("data"), dict) else row
        value = data.get("tenant_key") or data.get("tenant")
        return str(value) if value is not None else None

    @staticmethod
    def _ts_of(row: dict[str, Any]) -> float:
        for key in ("ts", "created_at", "observed_at"):
            value = row.get(key)
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                return float(value)
        data = row.get("data") if isinstance(row.get("data"), dict) else {}
        for key in ("ts", "created_at", "observed_at"):
            value = data.get(key)
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                return float(value)
        return time.time()

    def prune_file(
        self,
        path: pathlib.Path,
        *,
        tenant_key: str | None = None,
        max_age_seconds: float | None = None,
        max_rows: int = 10_000,
        dry_run: bool = False,
    ) -> TelemetryRetentionReceipt:
        path = pathlib.Path(path)
        rows: list[dict[str, Any]] = []
        if path.exists():
            for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
                if not line.strip():
                    continue
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    rows.append({"kind": "invalid-json", "ts": 0})
        cutoff = time.time() - max_age_seconds if max_age_seconds is not None else None
        kept = []
        for row in rows:
            if tenant_key is not None and self._tenant_of(row) != tenant_key:
                kept.append(row); continue
            if cutoff is not None and self._ts_of(row) < cutoff:
                continue
            kept.append(row)
        if tenant_key is None:
            kept = kept[-max(1, int(max_rows)):]
        else:
            tenant_rows = [row for row in kept if self._tenant_of(row) == tenant_key]
            overflow = max(0, len(tenant_rows) - max(1, int(max_rows)))
            if overflow:
                skipped = 0; new_kept = []
                for row in kept:
                    if self._tenant_of(row) == tenant_key and skipped < overflow:
                        skipped += 1; continue
                    new_kept.append(row)
                kept = new_kept
        if not dry_run:
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_text("".join(json.dumps(row, sort_keys=True, default=str) + "\n" for row in kept), encoding="utf-8")
            os.replace(tmp, path)
        return TelemetryRetentionReceipt(
            schema_version="chimera.telemetry-retention-receipt.v1",
            path=str(path), before=len(rows), after=len(kept), removed=max(0, len(rows) - len(kept)),
            tenant_key=tenant_key, max_age_seconds=max_age_seconds, max_rows=int(max_rows), dry_run=dry_run,
        )

    def prune_default(self, *, tenant_key: str | None = None, max_age_seconds: float | None = None, max_rows: int = 10_000, dry_run: bool = False) -> list[TelemetryRetentionReceipt]:
        files = [self.root / ".chimera" / "events.jsonl", self.root / ".chimera" / "telemetry-outbox.jsonl"]
        return [self.prune_file(path, tenant_key=tenant_key, max_age_seconds=max_age_seconds, max_rows=max_rows, dry_run=dry_run) for path in files]
