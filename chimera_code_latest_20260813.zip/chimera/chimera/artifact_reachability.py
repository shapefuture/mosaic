"""Conservative dry-run reachability analysis for Chimera CAS artifacts."""
from __future__ import annotations

import json
import pathlib
import re
from typing import Any

from .artifacts import ContentAddressedArtifactStore
from .wal import WAL

_REF = re.compile(r"(?:artifact:)?(sha256:[0-9a-f]{64})")


def _refs(value: Any) -> set[str]:
    if isinstance(value, str): return set(_REF.findall(value))
    if isinstance(value, dict):
        out: set[str] = set()
        for key, item in value.items(): out |= _refs(key); out |= _refs(item)
        return out
    if isinstance(value, (list, tuple)):
        out: set[str] = set()
        for item in value: out |= _refs(item)
        return out
    return set()


def artifact_reachability_report(root: pathlib.Path) -> dict[str, Any]:
    root = pathlib.Path(root)
    store = ContentAddressedArtifactStore(root)
    wal = WAL(root)
    reachable: set[str] = set()
    root_sources: dict[str, int] = {"wal": 0, "evidence_portfolio_ring": 0}
    for entry in wal.replay():
        refs = _refs(entry.get("data", {}))
        reachable |= refs
        root_sources["wal"] += len(refs)
    # The evidence portfolio ring is a deliberately bounded, atomically
    # replaced forensic root. It may retain a selected capture reference after
    # older WAL compaction in a future deployment, so include it explicitly in
    # dry-run reachability rather than assuming WAL is the sole root category.
    ring_path = pathlib.Path(root) / ".chimera" / "evidence-portfolio-ring.json"
    if ring_path.exists():
        try:
            ring_value = json.loads(ring_path.read_text())
            refs = _refs(ring_value)
            reachable |= refs
            root_sources["evidence_portfolio_ring"] += len(refs)
        except (OSError, json.JSONDecodeError):
            # A corrupt advisory ring must not enable deletion; surface it in
            # the report and treat no ring-derived references as collectible.
            root_sources["evidence_portfolio_ring_corrupt"] = 1
    available: set[str] = set()
    for path in store.store.rglob("*.blob"):
        digest = "sha256:" + path.stem
        available.add(digest)
    return {
        "mode": "dry-run-only",
        "reachable": sorted(reachable),
        "available": sorted(available),
        "unreachable": sorted(available - reachable),
        "missing": sorted(reachable - available),
        "root_sources": root_sources,
        "warning": "no artifact is deleted; roots still need live snapshots, accepted cards, command proofs, handoff bundles, retention/legal/incident and external-reference policy before GC promotion",
    }
