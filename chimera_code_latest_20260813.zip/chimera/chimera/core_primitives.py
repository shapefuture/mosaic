"""Canonical hashes, atomic durable JSON, clocks, identifiers, and redaction."""

from __future__ import annotations

import hashlib
import json
import os
import pathlib
import re
import time
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

HASH_ALGORITHM = "sha256"


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def digest_bytes(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def digest_json(value: Any) -> str:
    return digest_bytes(canonical_json(value))


def atomic_write(path: pathlib.Path, data: bytes, *, mode: int = 0o600) -> None:
    target = pathlib.Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.{uuid.uuid4().hex}.tmp")
    try:
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
        try:
            directory_fd = os.open(target.parent, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        except OSError:
            # Some filesystems do not permit directory fsync; the file itself
            # remains fsynced and callers can expose this as a capability limit.
            pass
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_write_json(path: pathlib.Path, value: Any, *, mode: int = 0o600) -> None:
    atomic_write(path, canonical_json(value) + b"\n", mode=mode)


@dataclass(frozen=True)
class SystemClock:
    def time(self) -> float:
        return time.time()

    def monotonic(self) -> float:
        return time.monotonic()


@dataclass(frozen=True)
class UUIDIdentifierFactory:
    def new(self, prefix: str) -> str:
        if not prefix or any(character.isspace() for character in prefix):
            raise ValueError("identifier prefix must be non-empty and whitespace-free")
        return prefix.rstrip(":") + ":" + uuid.uuid4().hex


_SECRET_KEYS = re.compile(
    r"(?:secret|token|password|authorization|api[_-]?key)", re.IGNORECASE
)


def redact(value: Any, *, depth: int = 0) -> Any:
    if depth > 8:
        return "<depth-redacted>"
    if isinstance(value, Mapping):
        return {
            str(key): (
                "<redacted>"
                if _SECRET_KEYS.search(str(key))
                else redact(item, depth=depth + 1)
            )
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [redact(item, depth=depth + 1) for item in value[:1_000]]
    if isinstance(value, bytes):
        return {"bytes": len(value), "digest": digest_bytes(value)}
    if isinstance(value, str):
        return value[:4_000] + ("…" if len(value) > 4_000 else "")
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return str(value)[:1_000]
