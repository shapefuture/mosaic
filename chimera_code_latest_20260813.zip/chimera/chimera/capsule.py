"""Verified exact-capsule memoization.

A cache hit is permitted only when task, model revision, tools, policy, full
workspace input root, contract, and parameters are identical. Only artifacts
with independently resolvable passing test evidence are admitted.
"""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
import concurrent.futures
import pathlib
import sys
import time
import uuid
from dataclasses import dataclass
from typing import Any, Callable, Optional

from pydantic import BaseModel, ConfigDict, field_validator

from .artifacts import ArtifactRef, ContentAddressedArtifactStore
from .wal import WAL


class FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class CapsuleSpec(FrozenModel):
    schema_version: str = "chimera.capsule.v1"
    task_hash: str
    model_id: str
    model_revision: str
    tool_versions: tuple[str, ...]
    policy_hash: str
    input_root: str
    contract_hash: str
    parameters_hash: str

    @field_validator("task_hash", "policy_hash", "input_root", "contract_hash", "parameters_hash")
    @classmethod
    def _digest(cls, value: str) -> str:
        raw = value.removeprefix("sha256:")
        if not value.startswith("sha256:") or len(raw) != 64 or any(c not in "0123456789abcdef" for c in raw.lower()):
            raise ValueError("capsule digest fields must use sha256:<64 hex>")
        return value.lower()

    @property
    def key(self) -> str:
        return _hash(self.model_dump(mode="json"))


class CapsuleRecord(FrozenModel):
    spec_key: str
    artifact: ArtifactRef
    verification_hash: str
    evidence_refs: tuple[str, ...]
    created_at: str

    @property
    def record_hash(self) -> str:
        return _hash(self.model_dump(mode="json"))


@dataclass(frozen=True)
class CapsuleHit:
    spec: CapsuleSpec
    record: CapsuleRecord
    artifact: dict[str, Any]


class VerifiedCapsuleCache:
    def __init__(
        self,
        root: pathlib.Path,
        *,
        artifact_store: Optional[ContentAddressedArtifactStore] = None,
        evidence_resolver: Optional[Callable[[str], bool]] = None,
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.dir = self.root / ".chimera" / "capsules"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.artifacts = artifact_store or ContentAddressedArtifactStore(self.root)
        self.wal = WAL(self.root)
        self.evidence_resolver = evidence_resolver or self._resolve_evidence

    def _resolve_evidence(self, ref: str) -> bool:
        if not ref.startswith("artifact:"):
            return False
        try:
            return self.artifacts.has(ref.removeprefix("artifact:"))
        except (ValueError, OSError):
            return False

    def _path(self, spec: CapsuleSpec) -> pathlib.Path:
        return self.dir / f"{spec.key.removeprefix('sha256:')}.json"

    @staticmethod
    def _atomic_write(path: pathlib.Path, data: str) -> None:
        temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        try:
            with temporary.open("w") as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, path)
        finally:
            if temporary.exists():
                temporary.unlink()

    def put(self, spec: CapsuleSpec, artifact: dict[str, Any], verification: dict[str, Any]) -> CapsuleRecord:
        refs = tuple(str(ref) for ref in verification.get("evidence_refs", ()))
        if (
            verification.get("status") != "pass"
            or verification.get("test_status") != 0
            or not refs
            or not all(self.evidence_resolver(ref) for ref in refs)
        ):
            raise ValueError("capsule admission requires verified passing test evidence with resolvable refs")
        encoded = json.dumps(artifact, sort_keys=True, separators=(",", ":"), default=str)
        artifact_ref = self.artifacts.put(
            encoded, media_type="application/vnd.chimera.cached-patch+json",
            provenance={"capsule_key": spec.key, "verification": _hash(verification)},
        )
        record = CapsuleRecord(
            spec_key=spec.key,
            artifact=artifact_ref,
            verification_hash=_hash(verification),
            evidence_refs=refs,
            created_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        )
        payload = {**record.model_dump(mode="json"), "record_hash": record.record_hash}
        self._atomic_write(self._path(spec), json.dumps(payload, indent=2, sort_keys=True) + "\n")
        self.wal.append("capsule_store", {
            "capsule_key": spec.key, "record_hash": record.record_hash,
            "artifact_digest": artifact_ref.digest,
            "verification_hash": record.verification_hash,
        })
        return record

    def get(self, spec: CapsuleSpec) -> Optional[CapsuleHit]:
        path = self._path(spec)
        if not path.exists():
            self.wal.append("capsule_miss", {"capsule_key": spec.key, "reason": "not_found"})
            return None
        try:
            payload = json.loads(path.read_text())
            expected_record_hash = payload.pop("record_hash")
            record = CapsuleRecord.model_validate(payload)
            if record.spec_key != spec.key or record.record_hash != expected_record_hash:
                raise ValueError("record hash/spec mismatch")
            if not all(self.evidence_resolver(ref) for ref in record.evidence_refs):
                raise ValueError("evidence no longer resolves")
            artifact = json.loads(self.artifacts.get(record.artifact.digest))
            if not isinstance(artifact, dict):
                raise ValueError("cached patch artifact is not an object")
        except Exception as exc:
            self.wal.append("capsule_corrupt", {
                "capsule_key": spec.key, "error": f"{type(exc).__name__}: {exc}"[:500],
            })
            return None
        self.wal.append("capsule_hit", {
            "capsule_key": spec.key, "record_hash": record.record_hash,
            "artifact_digest": record.artifact.digest,
        })
        return CapsuleHit(spec=spec, record=record, artifact=artifact)

    def stats(self) -> dict[str, Any]:
        events = self.wal.replay()
        return {
            "entries": len(list(self.dir.glob("*.json"))),
            "hits": sum(1 for item in events if item.get("kind") == "capsule_hit"),
            "misses": sum(1 for item in events if item.get("kind") == "capsule_miss"),
            "corrupt": sum(1 for item in events if item.get("kind") == "capsule_corrupt"),
        }


def model_revision(model: str) -> Optional[str]:
    if "mock" in model.lower() or model.startswith("deterministic-"):
        return f"builtin:{model}"
    if "@" in model:
        revision = model.rsplit("@", 1)[1].strip()
        return revision or None
    return os.environ.get("CHIMERA_MODEL_REVISION") or None


def _exact_file_digest(path: pathlib.Path, root: pathlib.Path) -> tuple[str, int]:
    """Hash exact bytes; symlinks may never escape the workspace root."""
    if path.is_symlink():
        resolved = path.resolve(strict=True)
        if not resolved.is_relative_to(root):
            raise ValueError(f"workspace input symlink escapes root: {path}")
    data = path.read_bytes()
    return hashlib.sha256(data).hexdigest(), len(data)

def workspace_input_root(root: pathlib.Path, workspace, branch: str) -> str:
    root = pathlib.Path(root).resolve()
    ignored_dirs = {
        ".git", ".chimera", ".venv", "node_modules", "__pycache__", ".pytest_cache",
        "build", "dist", "target", "out",
    }
    ignored_names = {".env", "auth.json"}
    paths: set[str] = set()
    for path in root.rglob("*"):
        if not path.is_file() or any(part in ignored_dirs for part in path.relative_to(root).parts):
            continue
        if path.name in ignored_names or path.name.startswith(".env.") or path.suffix in {".pem", ".key"}:
            continue
        paths.add(path.relative_to(root).as_posix())
    paths.update(workspace.list_overlay(branch))
    branch_dir = workspace.branches_dir / branch
    deletion_path = branch_dir / "deletions.json"
    deletions = set(json.loads(deletion_path.read_text())) if deletion_path.exists() else set()
    paths -= deletions
    overlay_root = workspace.branches_dir / branch / "overlay"
    sources = [
        (rel, (overlay_root / rel) if (overlay_root / rel).exists() else root / rel)
        for rel in sorted(paths)
    ]
    def digest_row(item: tuple[str, pathlib.Path]) -> tuple[str, str, int] | None:
        rel, source = item
        try:
            digest, size = _exact_file_digest(source, root)
            return rel, digest, size
        except FileNotFoundError:
            return None
    total_bytes = sum(source.stat().st_size for _, source in sources if source.exists())
    # Tiny-file trees are syscall-bound and benchmark faster sequentially. Use
    # parallel hashing only when there is enough large-file work to amortize a pool.
    parallel = len(sources) >= 16 and total_bytes >= 32 * 1024 * 1024 and total_bytes / len(sources) >= 64 * 1024
    if parallel:
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=min(8, max(2, os.cpu_count() or 2)),
            thread_name_prefix="chimera-merkle",
        ) as pool:
            rows = [row for row in pool.map(digest_row, sources) if row is not None]
    else:
        rows = [row for item in sources if (row := digest_row(item)) is not None]
    return _hash(rows)


def build_capsule_spec(
    *,
    root: pathlib.Path,
    workspace,
    branch: str,
    task: str,
    model: str,
    config: Any,
    contract: Any,
    parameters: dict[str, Any],
) -> Optional[CapsuleSpec]:
    revision = model_revision(model)
    if revision is None:
        return None
    try:
        package_version = importlib.metadata.version("chimera-agent-harness")
    except importlib.metadata.PackageNotFoundError:
        from . import __version__
        package_version = __version__
    versions = [f"chimera={package_version}", f"python={sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"]
    for package in ("pytest", "gcf-python"):
        try:
            versions.append(f"{package}={importlib.metadata.version(package)}")
        except importlib.metadata.PackageNotFoundError:
            versions.append(f"{package}=unavailable")
    contract_value = contract.__dict__ if hasattr(contract, "__dict__") else contract
    return CapsuleSpec(
        task_hash=_hash(task),
        model_id=model,
        model_revision=revision,
        tool_versions=tuple(sorted(versions)),
        policy_hash=_hash(config.model_dump(mode="json")),
        input_root=workspace_input_root(pathlib.Path(root), workspace, branch),
        contract_hash=_hash(contract_value),
        parameters_hash=_hash(parameters),
    )


def _hash(value: Any) -> str:
    return "sha256:" + hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()
    ).hexdigest()
