"""Generated-code mapping CLI commands."""
from __future__ import annotations

import json
import pathlib

import click
from rich.json import JSON


def register(main: click.Group, *, console) -> None:
    @main.group("mapping")
    def mapping_group():
        """Verify and query explicit source-to-generated mapping contracts."""
        pass


    @mapping_group.command("verify")
    @click.option("--workspace", default=".")
    @click.option("--mapping", "mapping_path", type=click.Path(path_type=pathlib.Path), required=True)
    @click.option("--trusted-key-id", "trusted_key_ids", multiple=True, help="Trusted Ed25519 key id for shared-use verification")
    @click.option("--require-trusted-signature", is_flag=True, help="Reject unsigned or untrusted producer attestations")
    def mapping_verify(workspace, mapping_path, trusted_key_ids, require_trusted_signature):
        from .artifacts import ContentAddressedArtifactStore
        from .generated_code_mapping import GeneratedMappingVerifier, contract_from_json
        root = pathlib.Path(workspace)
        contract = contract_from_json(mapping_path)
        store = ContentAddressedArtifactStore(root)
        receipt = GeneratedMappingVerifier(
            root,
            evidence_resolver=lambda ref: store.has(ref.removeprefix("artifact:")),
            evidence_loader=lambda ref: store.get(ref.removeprefix("artifact:")),
            trusted_signing_key_ids=set(trusted_key_ids),
            require_trusted_signature=require_trusted_signature,
        ).verify(contract)
        console.print(JSON(receipt.model_dump_json(indent=2)))


    @mapping_group.command("produce-tool-schemas")
    @click.option("--workspace", default=".")
    @click.option("--source", type=click.Path(path_type=pathlib.Path), required=True, help="JSON tool catalog")
    @click.option("--bundle", type=click.Path(path_type=pathlib.Path), required=True, help="New immutable output directory")
    @click.option("--signing-key-env", default=None, help="Environment variable containing a raw Ed25519 private key in base64")
    @click.option("--signing-scope", default="operator-pinned-generator", show_default=True)
    def mapping_produce_tool_schemas(workspace, source, bundle, signing_key_env, signing_scope):
        """Compile a real tool catalog and atomically emit its attested mapping bundle."""
        import os
        from .context_evidence import ContextSigner
        from .tool_schema_generator import ToolSchemaBundleGenerator

        signer = None
        if signing_key_env:
            encoded = os.environ.get(signing_key_env)
            if not encoded:
                raise click.UsageError(f"generator signing key environment variable is absent: {signing_key_env}")
            signer = ContextSigner.from_base64_private_key(encoded, scope=signing_scope)
        try:
            receipt = ToolSchemaBundleGenerator(pathlib.Path(workspace), signer=signer).generate(source=source, bundle=bundle)
        except (ValueError, FileNotFoundError, FileExistsError) as exc:
            raise click.UsageError(str(exc)) from exc
        console.print(JSON(receipt.model_dump_json(indent=2)))


    @mapping_group.command("query")
    @click.option("--workspace", default=".")
    @click.option("--mapping", "mapping_path", type=click.Path(path_type=pathlib.Path), required=True)
    @click.option("--direction", type=click.Choice(["source-to-generated", "generated-to-source"]), required=True)
    @click.option("--path", "source_path", required=True)
    @click.option("--line", type=int, required=True)
    @click.option("--character", type=int, required=True)
    @click.option("--trusted-key-id", "trusted_key_ids", multiple=True, help="Trusted Ed25519 key id for shared-use verification")
    @click.option("--require-trusted-signature", is_flag=True, help="Reject unsigned or untrusted producer attestations")
    def mapping_query(workspace, mapping_path, direction, source_path, line, character, trusted_key_ids, require_trusted_signature):
        """Resolve only an exact verified mapping edge; never heuristically infer one."""
        from .artifacts import ContentAddressedArtifactStore
        from .generated_code_mapping import GeneratedMappingError, GeneratedMappingIndex, GeneratedMappingVerifier, contract_from_json
        root = pathlib.Path(workspace)
        contract = contract_from_json(mapping_path)
        store = ContentAddressedArtifactStore(root)
        receipt = GeneratedMappingVerifier(
            root,
            evidence_resolver=lambda ref: store.has(ref.removeprefix("artifact:")),
            evidence_loader=lambda ref: store.get(ref.removeprefix("artifact:")),
            trusted_signing_key_ids=set(trusted_key_ids),
            require_trusted_signature=require_trusted_signature,
        ).verify(contract)
        if receipt.status != "verified":
            raise click.UsageError("mapping contract is not verified; inspect `chimera mapping verify` receipt")
        index = GeneratedMappingIndex(contract, receipt)
        try:
            values = index.source_to_generated(path=source_path, line=line, character=character) if direction == "source-to-generated" else index.generated_to_source(path=source_path, line=line, character=character)
        except GeneratedMappingError as exc:
            raise click.UsageError(str(exc)) from exc
        console.print(JSON(json.dumps({"direction": direction, "matches": [item.model_dump(mode="json") for item in values], "receipt": receipt.model_dump(mode="json")}, indent=2)))


