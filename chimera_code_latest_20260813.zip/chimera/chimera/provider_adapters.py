"""Protocol-specific provider adapters with common deadline, egress, and secret ports."""

from __future__ import annotations

import asyncio
import os
import time
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

import httpx
from pydantic import BaseModel, ConfigDict

from .runtime_ports import (
    CompletionOutcome,
    CompletionRequest,
    CompletionResult,
    EgressPort,
    ModelCompletionPort,
    SecretPort,
)


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ProviderCapabilityManifest(_FrozenModel):
    adapter_id: str
    protocol: str
    models: tuple[str, ...] = ()
    streaming: bool = False
    native_tools: bool = False
    strict_json: bool = False
    prompt_cache: bool = False
    terminal_cancellation_proven: bool = False
    idempotent_request_replay_proven: bool = False
    local: bool = False


class EnvironmentSecretPort:
    """Single-tenant/local environment adapter; cloud tenant use must inject another port."""

    def get(self, *, tenant_key: str | None, name: str) -> str | None:
        if tenant_key is not None:
            raise PermissionError(
                "process environment secrets are not a tenant-scoped cloud secret port"
            )
        return os.environ.get(name)


class MappingSecretPort:
    def __init__(self, values: Mapping[tuple[str | None, str], str]) -> None:
        self._values = dict(values)

    def get(self, *, tenant_key: str | None, name: str) -> str | None:
        return self._values.get((tenant_key, name))


@dataclass(frozen=True)
class ProviderRetryPolicy:
    max_attempts: int = 1
    retry_statuses: frozenset[int] = frozenset({408, 409, 429, 500, 502, 503, 504})

    def attempts(
        self, request: CompletionRequest, manifest: ProviderCapabilityManifest
    ) -> int:
        if (
            self.max_attempts > 1
            and request.idempotency_key
            and manifest.idempotent_request_replay_proven
        ):
            return self.max_attempts
        return 1


class _HTTPAdapter(ModelCompletionPort):
    manifest: ProviderCapabilityManifest

    def __init__(
        self,
        *,
        base_url: str,
        egress: EgressPort,
        secrets: SecretPort,
        secret_name: str | None,
        client: httpx.Client | None = None,
        async_client: httpx.AsyncClient | None = None,
        retry: ProviderRetryPolicy | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.egress = egress
        self.secrets = secrets
        self.secret_name = secret_name
        self._client = client or httpx.Client(
            timeout=httpx.Timeout(120.0, connect=20.0),
            follow_redirects=False,
            trust_env=False,
        )
        self._async_client = async_client
        self.retry = retry or ProviderRetryPolicy()

    def _timeout(self, request: CompletionRequest) -> float:
        if request.deadline_unix_ms is None:
            return 120.0
        remaining = request.deadline_unix_ms / 1_000 - time.time()
        if remaining <= 0:
            raise TimeoutError("provider request deadline expired before dispatch")
        return max(0.1, min(120.0, remaining))

    def _credential(self, request: CompletionRequest) -> str | None:
        if self.secret_name is None:
            return None
        return self.secrets.get(tenant_key=request.tenant_key, name=self.secret_name)

    def _request_parts(
        self, request: CompletionRequest, credential: str | None
    ) -> tuple[str, dict[str, str], dict[str, Any]]:
        raise NotImplementedError

    def _decode(
        self, response: httpx.Response, request: CompletionRequest
    ) -> CompletionResult:
        raise NotImplementedError

    def complete(self, request: CompletionRequest) -> CompletionResult:
        credential = self._credential(request)
        if self.secret_name and not credential:
            return CompletionResult(
                CompletionOutcome.FAILED,
                model=request.model,
                error_class="MissingCredential",
                request_id=request.request_id,
            )
        url, headers, payload = self._request_parts(request, credential)
        self.egress.authorize(url, tenant_key=request.tenant_key)
        attempts = self.retry.attempts(request, self.manifest)
        for attempt in range(attempts):
            try:
                response = self._client.post(
                    url,
                    headers=headers,
                    json=payload,
                    timeout=self._timeout(request),
                )
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                # Without a provider-specific idempotency/terminal-cancel proof,
                # a transport exception after dispatch is conservatively unknown.
                return CompletionResult(
                    CompletionOutcome.UNKNOWN,
                    model=request.model,
                    provider=self.manifest.adapter_id,
                    request_id=request.request_id,
                    retry_count=attempt,
                    error_class=type(exc).__name__,
                    reconciliation_required=True,
                )
            if response.is_success:
                value = self._decode(response, request)
                return CompletionResult(
                    **{
                        **value.__dict__,
                        "retry_count": attempt,
                    }
                )
            if (
                response.status_code not in self.retry.retry_statuses
                or attempt + 1 >= attempts
            ):
                return CompletionResult(
                    CompletionOutcome.FAILED,
                    model=request.model,
                    provider=self.manifest.adapter_id,
                    request_id=request.request_id,
                    retry_count=attempt,
                    error_class=f"HTTP{response.status_code}",
                )
        raise AssertionError("provider retry loop exhausted without a result")

    async def acomplete(self, request: CompletionRequest) -> CompletionResult:
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(
                timeout=httpx.Timeout(120.0, connect=20.0),
                follow_redirects=False,
                trust_env=False,
            )
        credential = self._credential(request)
        if self.secret_name and not credential:
            return CompletionResult(
                CompletionOutcome.FAILED,
                model=request.model,
                error_class="MissingCredential",
                request_id=request.request_id,
            )
        url, headers, payload = self._request_parts(request, credential)
        self.egress.authorize(url, tenant_key=request.tenant_key)
        try:
            response = await self._async_client.post(
                url,
                headers=headers,
                json=payload,
                timeout=self._timeout(request),
            )
        except asyncio.CancelledError:
            return CompletionResult(
                CompletionOutcome.CANCELLED,
                model=request.model,
                provider=self.manifest.adapter_id,
                request_id=request.request_id,
                reconciliation_required=not self.manifest.terminal_cancellation_proven,
            )
        except (httpx.TimeoutException, httpx.TransportError) as exc:
            return CompletionResult(
                CompletionOutcome.UNKNOWN,
                model=request.model,
                provider=self.manifest.adapter_id,
                request_id=request.request_id,
                error_class=type(exc).__name__,
                reconciliation_required=True,
            )
        if not response.is_success:
            return CompletionResult(
                CompletionOutcome.FAILED,
                model=request.model,
                provider=self.manifest.adapter_id,
                request_id=request.request_id,
                error_class=f"HTTP{response.status_code}",
            )
        return self._decode(response, request)

    def close(self) -> None:
        self._client.close()

    async def aclose(self) -> None:
        if self._async_client is not None:
            await self._async_client.aclose()
            self._async_client = None


class OpenAICompatibleAdapter(_HTTPAdapter):
    def __init__(self, *, adapter_id: str, local: bool = False, **kwargs: Any) -> None:
        self.manifest = ProviderCapabilityManifest(
            adapter_id=adapter_id,
            protocol="openai-compatible-chat",
            streaming=True,
            native_tools=True,
            strict_json=True,
            local=local,
        )
        super().__init__(**kwargs)

    def _request_parts(self, request: CompletionRequest, credential: str | None):
        headers = {"Content-Type": "application/json"}
        if credential:
            headers["Authorization"] = "Bearer " + credential
        payload: dict[str, Any] = {
            "model": request.model.split("/", 1)[-1],
            "messages": [{"role": "user", "content": request.prompt}],
            "max_tokens": request.max_output_tokens or 4_096,
        }
        if request.tools:
            payload["tools"] = list(request.tools)
        if request.response_schema:
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": dict(request.response_schema),
            }
        if request.idempotency_key:
            headers["Idempotency-Key"] = request.idempotency_key
        return self.base_url + "/chat/completions", headers, payload

    def _decode(
        self, response: httpx.Response, request: CompletionRequest
    ) -> CompletionResult:
        data = response.json()
        choices = data.get("choices") if isinstance(data, Mapping) else None
        message = (
            choices[0].get("message", {})
            if isinstance(choices, list) and choices
            else {}
        )
        usage = data.get("usage", {}) if isinstance(data, Mapping) else {}
        return CompletionResult(
            CompletionOutcome.SUCCEEDED,
            answer=str(message.get("content") or ""),
            model=request.model,
            provider=self.manifest.adapter_id,
            usage=dict(usage) if isinstance(usage, Mapping) else {},
            request_id=request.request_id,
            metadata={"tool_calls": message.get("tool_calls", [])},
        )


class OllamaAdapter(_HTTPAdapter):
    manifest = ProviderCapabilityManifest(
        adapter_id="ollama-local",
        protocol="ollama-generate",
        local=True,
    )

    def _request_parts(self, request: CompletionRequest, credential: str | None):
        return (
            self.base_url + "/api/generate",
            {"Content-Type": "application/json"},
            {
                "model": request.model.split("/", 1)[-1],
                "prompt": request.prompt,
                "stream": False,
                "options": {"num_predict": request.max_output_tokens or 4_096},
            },
        )

    def _decode(
        self, response: httpx.Response, request: CompletionRequest
    ) -> CompletionResult:
        data = response.json()
        usage = {
            "input_tokens": int(data.get("prompt_eval_count", 0) or 0),
            "output_tokens": int(data.get("eval_count", 0) or 0),
        }
        usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]
        return CompletionResult(
            CompletionOutcome.SUCCEEDED,
            answer=str(data.get("response") or ""),
            model=request.model,
            provider=self.manifest.adapter_id,
            usage=usage,
            request_id=request.request_id,
        )


class AnthropicMessagesAdapter(_HTTPAdapter):
    manifest = ProviderCapabilityManifest(
        adapter_id="anthropic-messages",
        protocol="anthropic-messages",
        streaming=True,
        native_tools=True,
        prompt_cache=True,
    )

    def _request_parts(self, request: CompletionRequest, credential: str | None):
        payload: dict[str, Any] = {
            "model": request.model,
            "max_tokens": request.max_output_tokens or 4_096,
            "messages": [{"role": "user", "content": request.prompt}],
        }
        if request.tools:
            payload["tools"] = list(request.tools)
        return (
            self.base_url + "/v1/messages",
            {
                "x-api-key": credential or "",
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            payload,
        )

    def _decode(
        self, response: httpx.Response, request: CompletionRequest
    ) -> CompletionResult:
        data = response.json()
        content = data.get("content", []) if isinstance(data, Mapping) else []
        answer = "".join(
            str(item.get("text", ""))
            for item in content
            if isinstance(item, Mapping) and item.get("type") == "text"
        )
        usage = data.get("usage", {}) if isinstance(data, Mapping) else {}
        return CompletionResult(
            CompletionOutcome.SUCCEEDED,
            answer=answer,
            model=request.model,
            provider=self.manifest.adapter_id,
            usage=dict(usage) if isinstance(usage, Mapping) else {},
            request_id=request.request_id,
        )


class ProviderAdapterRegistry:
    """The bound adapter registry is the only advertised provider capability source."""

    def __init__(self) -> None:
        self._adapters: dict[str, ModelCompletionPort] = {}
        self._manifests: dict[str, ProviderCapabilityManifest] = {}

    def bind(
        self,
        name: str,
        adapter: ModelCompletionPort,
        manifest: ProviderCapabilityManifest,
    ) -> None:
        if name in self._adapters:
            raise ValueError(f"provider adapter already bound: {name}")
        self._adapters[name] = adapter
        self._manifests[name] = manifest

    def complete(
        self, name: str, request: CompletionRequest
    ) -> CompletionResult | Mapping[str, Any]:
        try:
            adapter = self._adapters[name]
        except KeyError as exc:
            raise KeyError(f"provider adapter is not bound: {name}") from exc
        return adapter.complete(request)

    def capabilities(self) -> tuple[ProviderCapabilityManifest, ...]:
        return tuple(self._manifests[name] for name in sorted(self._manifests))
