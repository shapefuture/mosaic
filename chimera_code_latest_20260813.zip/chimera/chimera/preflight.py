"""Fail-fast runtime readiness checks before expensive model execution."""
from __future__ import annotations

import importlib.util
import os
import pathlib
import shutil
from typing import Any, Dict, List

from pydantic import BaseModel, Field

from .effects import EffectRequest, check_effect
from .quality import TaskContract


class PreflightCheck(BaseModel):
    name: str
    status: str  # pass | warn | fail
    detail: str
    evidence: Dict[str, Any] = Field(default_factory=dict)


class PreflightReport(BaseModel):
    ok: bool
    model: str
    checks: List[PreflightCheck]

    @property
    def failures(self) -> List[PreflightCheck]:
        return [check for check in self.checks if check.status == "fail"]


class HarnessPreflight:
    """Validate tool/runtime contracts without consuming a model request."""

    def __init__(self, runtime):
        self.runtime = runtime
        self.root = runtime.root

    def _provider_check(self, model: str) -> PreflightCheck:
        if getattr(self.runtime, "_provider_injected", False):
            return PreflightCheck(name="provider", status="pass", detail="injected provider callable available")
        if "mock" in model.lower():
            return PreflightCheck(name="provider", status="pass", detail="mock provider explicitly selected")
        provider = self.runtime.auth_storage.resolve_provider(model)
        env_map = {
            "claude": ("ANTHROPIC_API_KEY",),
            "openai": ("OPENAI_API_KEY",),
            "openrouter": ("OPENROUTER_API_KEY", "OPENROUTER_API_KEYS"),
            "kimi": ("MOONSHOT_API_KEY", "OPENROUTER_API_KEY", "OPENROUTER_API_KEYS"),
            "deepseek": ("DEEPSEEK_API_KEY", "OPENROUTER_API_KEY", "OPENROUTER_API_KEYS"),
            "qwen": ("DASHSCOPE_API_KEY", "OPENROUTER_API_KEY", "OPENROUTER_API_KEYS"),
            "gemini": ("GEMINI_API_KEY", "GOOGLE_API_KEY", "GEMINI_API_KEYS", "GOOGLE_API_KEYS", "OPENROUTER_API_KEY", "OPENROUTER_API_KEYS"),
            "cerebras": ("CEREBRAS_API_KEY",),
            "tokenrouter": ("TOKENROUTER_API_KEY", "TOKENROUTER_KEY"),
            "ollama": ("OLLAMA_HOST",),
        }
        if "/" in model and provider == "openrouter":
            provider = "openrouter"
        names = env_map.get(provider, ("OPENROUTER_API_KEY", "OPENROUTER_API_KEYS"))
        present = [name for name in names if os.environ.get(name)]
        if not present:
            return PreflightCheck(
                name="provider", status="fail",
                detail=f"no environment credential available for provider {provider}",
                evidence={"provider": provider, "accepted_env": list(names)},
            )
        return PreflightCheck(
            name="provider", status="pass", detail=f"environment credential source available for {provider}",
            evidence={"provider": provider, "environment_slots": len(present), "stored": False},
        )

    def run(self, task: str, model: str) -> PreflightReport:
        checks: List[PreflightCheck] = [self._provider_check(model)]

        required_modules = ["pydantic", "pytest", "httpx"]
        missing = [name for name in required_modules if importlib.util.find_spec(name) is None]
        checks.append(PreflightCheck(
            name="python-runtime", status="fail" if missing else "pass",
            detail="required Python modules available" if not missing else f"missing modules: {missing}",
            evidence={"missing": missing},
        ))
        gcf_available = importlib.util.find_spec("gcf") is not None
        checks.append(PreflightCheck(
            name="gcf-wire-codec", status="pass" if gcf_available else "warn",
            detail="GCF codec available" if gcf_available else "GCF unavailable; explicit JSON wire fallback active",
            evidence={"gcf_available": gcf_available, "fallback": None if gcf_available else "json"},
        ))

        contract = TaskContract.compile(self.root, task)
        from .task_readiness import TaskReadinessAudit
        readiness = TaskReadinessAudit().audit(task, contract)
        readiness_status = "fail" if readiness.irreversible and not readiness.judge_independent else "warn" if not (readiness.observable and readiness.scoped) else "pass"
        checks.append(PreflightCheck(
            name="task-readiness", status=readiness_status,
            detail="task has scope and independent executable acceptance" if readiness_status == "pass" else "; ".join(readiness.reasons) or "readiness requires review",
            evidence=readiness.evidence(),
        ))
        from .engineering_readiness import EngineeringReadinessAuditor
        engineering = EngineeringReadinessAuditor().audit(task, contract)
        engineering_status = "warn" if engineering.missing_topics or engineering.ambiguous_topics else "pass"
        checks.append(PreflightCheck(
            name="engineering-requirements-interface",
            status=engineering_status,
            detail=(
                "explicit engineering acceptance/interface facts were observed"
                if engineering_status == "pass"
                else "advisory requirements/interface facts remain missing or ambiguous"
            ),
            evidence=engineering.as_preflight_evidence(),
        ))
        denied = []
        capability = self.runtime.config.to_capability_set()
        for target in contract.targets:
            verdict = check_effect(EffectRequest(effect="fs.write", needs={"fs": [target.path]}), capability)
            if not verdict.allowed or verdict.residual_obligations:
                denied.append({"path": target.path, "reason": verdict.denied_reason or verdict.residual_obligations})
        checks.append(PreflightCheck(
            name="target-capabilities", status="fail" if denied else "pass",
            detail="all inferred target paths are writable" if not denied else f"{len(denied)} target paths denied",
            evidence={"targets": [target.path for target in contract.targets], "denied": denied},
        ))

        probe = self.root / ".chimera" / "preflight-write.tmp"
        try:
            probe.parent.mkdir(parents=True, exist_ok=True)
            probe.write_text("ok")
            probe.unlink()
            checks.append(PreflightCheck(name="workspace-write", status="pass", detail="workspace metadata path writable"))
        except OSError as exc:
            checks.append(PreflightCheck(name="workspace-write", status="fail", detail=str(exc)))

        try:
            if not self.runtime.graph.graph.get("nodes"):
                self.runtime.graph.load()
            checks.append(PreflightCheck(
                name="code-graph", status="pass", detail="code graph is loadable",
                evidence={"nodes": len(self.runtime.graph.graph.get("nodes", []))},
            ))
        except Exception:
            try:
                try:
                    self.runtime.graph.load()
                except Exception:
                    self.runtime.graph.build()
                graph = self.runtime.graph.graph
                checks.append(PreflightCheck(
                    name="code-graph", status="pass", detail="code graph loaded or built during preflight",
                    evidence={"nodes": len(graph.get("nodes", []))},
                ))
            except Exception as exc:
                checks.append(PreflightCheck(name="code-graph", status="fail", detail=str(exc)))

        checks.append(PreflightCheck(
            name="test-runner", status="pass" if shutil.which("pytest") else "fail",
            detail="pytest executable available" if shutil.which("pytest") else "pytest executable missing",
        ))

        from .sandbox import Sandbox
        backend = Sandbox(self.root, capability).with_backend("auto")
        checks.append(PreflightCheck(
            name="sandbox-backend",
            status="warn" if backend == "host-subprocess-unisolated" else "pass",
            detail=backend,
            evidence={"production_safe": backend != "host-subprocess-unisolated"},
        ))

        return PreflightReport(ok=not any(check.status == "fail" for check in checks), model=model, checks=checks)
