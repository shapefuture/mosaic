"""GCF/JSON wire negotiation for model-facing structured data.

Durable evidence stays JSON. GCF is used only at the model/tool boundary where
repeated keys and identifiers consume context tokens.
"""
from __future__ import annotations

import hashlib
import json
import threading
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Literal, Optional


WireFormat = Literal["auto", "json", "gcf"]

try:
    from gcf import (
        Edge, Payload, Session, Symbol, decode, decode_generic,
        encode, encode_generic, encode_with_session,
        GenericDeltaSession, GenericSet, fixed_n,
        StreamEncoder, GenericStreamEncoder,
    )
    GCF_AVAILABLE = True
except ImportError:  # pragma: no cover - exercised in minimal installations
    Edge = Payload = Session = Symbol = None
    GenericDeltaSession = GenericSet = fixed_n = None
    StreamEncoder = GenericStreamEncoder = None
    GCF_AVAILABLE = False


@dataclass
class WireEnvelope:
    format: str
    text: str
    content_hash: str
    source_bytes: int
    wire_bytes: int
    reduction: float
    estimated_source_tokens: int
    estimated_wire_tokens: int
    metadata: Dict[str, Any] = field(default_factory=dict)

    def model_text(self) -> str:
        return self.text


@dataclass(frozen=True)
class WireStreamReceipt:
    profile: str
    pack_root: str
    wire_hash: str
    wire_bytes: int
    records: int
    edges: int = 0


class _HashingWriter:
    def __init__(self, writer: Any):
        self.writer = writer
        self.hasher = hashlib.sha256()
        self.bytes = 0

    def write(self, text: str) -> Any:
        raw = text.encode()
        self.hasher.update(raw)
        self.bytes += len(raw)
        return self.writer.write(text)

    def receipt_hash(self) -> str:
        return "sha256:" + self.hasher.hexdigest()


class WireCodec:
    """Thread-safe codec with optional graph-session deduplication."""

    def __init__(self, default: WireFormat = "auto", min_savings: float = 0.05,
                 max_decode_bytes: int = 2_000_000, max_depth: int = 64,
                 max_records: int = 100_000, max_sessions: int = 256):
        self.default = default
        self.min_savings = min_savings
        self.max_decode_bytes = max_decode_bytes
        self.max_depth = max_depth
        self.max_records = max_records
        self.max_sessions = max(1, int(max_sessions))
        self._sessions: OrderedDict[str, Any] = OrderedDict()
        self._generic_delta_sessions: OrderedDict[str, Dict[str, Any]] = OrderedDict()
        self._lock = threading.RLock()
        self.metrics = {
            "encodes": 0, "gcf_encodes": 0, "json_encodes": 0,
            "source_bytes": 0, "wire_bytes": 0,
        }

    @staticmethod
    def _json(data: Any) -> str:
        return json.dumps(data, ensure_ascii=False, separators=(",", ":"), default=str)

    def _bound_sessions(self) -> None:
        while len(self._sessions) + len(self._generic_delta_sessions) > self.max_sessions:
            if self._generic_delta_sessions:
                self._generic_delta_sessions.popitem(last=False)
            elif self._sessions:
                self._sessions.popitem(last=False)

    @staticmethod
    def _estimated_tokens(text: str) -> int:
        # Explicitly an estimate. Provider usage remains the authoritative count.
        return max(1, (len(text.encode("utf-8")) + 3) // 4)

    def _envelope(self, source: str, wire: str, fmt: str,
                  metadata: Optional[Dict[str, Any]] = None) -> WireEnvelope:
        source_bytes = len(source.encode("utf-8"))
        wire_bytes = len(wire.encode("utf-8"))
        reduction = 0.0 if source_bytes == 0 else 1.0 - (wire_bytes / source_bytes)
        envelope = WireEnvelope(
            format=fmt, text=wire,
            content_hash="sha256:" + hashlib.sha256(source.encode()).hexdigest(),
            source_bytes=source_bytes, wire_bytes=wire_bytes, reduction=round(reduction, 4),
            estimated_source_tokens=self._estimated_tokens(source),
            estimated_wire_tokens=self._estimated_tokens(wire),
            metadata=metadata or {},
        )
        with self._lock:
            self.metrics["encodes"] += 1
            self.metrics[f"{fmt}_encodes"] += 1
            self.metrics["source_bytes"] += source_bytes
            self.metrics["wire_bytes"] += wire_bytes
        return envelope

    def encode_generic(self, data: Any, mode: Optional[WireFormat] = None) -> WireEnvelope:
        mode = mode or self.default
        source = self._json(data)
        if mode == "json" or not GCF_AVAILABLE:
            return self._envelope(source, source, "json", {"gcf_available": GCF_AVAILABLE})
        gcf_text = encode_generic(data)
        savings = 1.0 - (len(gcf_text.encode()) / max(1, len(source.encode())))
        if mode == "auto" and savings < self.min_savings:
            return self._envelope(source, source, "json", {
                "gcf_available": True, "gcf_candidate_bytes": len(gcf_text.encode()),
                "reason": "GCF savings below threshold",
            })
        return self._envelope(source, gcf_text, "gcf", {"profile": "generic"})

    def encode_generic_records(
        self,
        records: Iterable[Dict[str, Any]],
        *,
        key: str,
        session_key: str,
        tool: str = "table_state",
        name: str = "rows",
        fields: Optional[List[str]] = None,
        reanchor_every: int = 10,
        mode: Optional[WireFormat] = None,
    ) -> WireEnvelope:
        """Encode a repeated keyed table as a full anchor or generic delta.

        Session state is in-memory model-wire state only. Durable replay/plan
        evidence remains full JSON/WAL and can independently reconstruct every
        transmitted root.
        """
        rows = [dict(record) for record in records]
        mode = mode or self.default
        if not key or not session_key:
            raise ValueError("generic delta encoding requires key and session_key")
        if any(key not in row for row in rows):
            raise ValueError(f"every generic delta row must contain identity key {key!r}")
        identities = [row[key] for row in rows]
        if len(identities) != len({json.dumps(item, sort_keys=True, default=str) for item in identities}):
            raise ValueError(f"generic delta rows contain duplicate identity key {key!r}")
        if fields is None:
            discovered = sorted({field for row in rows for field in row})
            fields = [key, *[field for field in discovered if field != key]]
        if key not in fields:
            fields = [key, *fields]
        normalized = [{field: row.get(field) for field in fields} for row in rows]
        source_data = {name: normalized}
        source = self._json(source_data)
        pack_root = "sha256:" + hashlib.sha256(source.encode()).hexdigest()
        if mode == "json" or not GCF_AVAILABLE:
            return self._envelope(source, source, "json", {
                "profile": "generic-delta", "pack_root": pack_root,
                "gcf_available": GCF_AVAILABLE, "session": session_key,
                "is_full": True, "delta": False,
            })

        current = GenericSet(key=key, fields=list(fields), rows=normalized, name=name)
        with self._lock:
            state = self._generic_delta_sessions.pop(session_key, None)
            if state is None:
                session = GenericDeltaSession(current, tool, fixed_n(max(1, int(reanchor_every))))
                state = {
                    "session": session, "key": key, "fields": list(fields), "name": name,
                }
                self._generic_delta_sessions[session_key] = state
                self._bound_sessions()
                wire = session.current_full()
                is_full = True
                turn = 0
            else:
                self._generic_delta_sessions[session_key] = state
                session = state["session"]
                wire, is_full = session.next(current)
                state.update({"key": key, "fields": list(fields), "name": name})
                turn = session.turn
        savings = 1.0 - len(wire.encode()) / max(1, len(source.encode()))
        metadata = {
            "profile": "generic-delta", "pack_root": pack_root,
            "session": session_key, "turn": turn,
            "is_full": is_full, "delta": not is_full,
            "key": key, "fields": list(fields),
        }
        if mode == "auto" and savings < self.min_savings:
            return self._envelope(source, source, "json", {
                **metadata, "gcf_candidate_bytes": len(wire.encode()),
                "reason": "GCF delta savings below threshold",
            })
        return self._envelope(source, wire, "gcf", metadata)

    def encode_graph(self, nodes: Iterable[Dict[str, Any]], edges: Optional[Iterable[Dict[str, Any]]] = None,
                     *, tool: str = "code_graph", token_budget: int = 0,
                     session_key: Optional[str] = None, mode: Optional[WireFormat] = None) -> WireEnvelope:
        node_list = list(nodes)
        edge_list = list(edges or [])
        source_data = {"tool": tool, "nodes": node_list, "edges": edge_list}
        source = self._json(source_data)
        mode = mode or self.default
        if mode == "json" or not GCF_AVAILABLE:
            return self._envelope(source, source, "json", {"profile": "graph", "gcf_available": GCF_AVAILABLE})

        symbols = []
        qnames = set()
        for index, node in enumerate(node_list):
            qname = str(node.get("qualified_name") or node.get("id") or node.get("file") or node.get("name") or f"node-{index}")
            if qname in qnames:
                qname = f"{qname}#{index}"
            qnames.add(qname)
            symbols.append(Symbol(
                qualified_name=qname,
                kind=str(node.get("kind") or "symbol").lower(),
                score=float(node.get("score") or 0.0),
                provenance=str(node.get("provenance") or "chimera_graph"),
                distance=int(node.get("distance") or 0),
                signature=str(node.get("signature") or node.get("description") or ""),
            ))
        gcf_edges = [Edge(
            source=str(item.get("source") or item.get("from") or ""),
            target=str(item.get("target") or item.get("to") or ""),
            edge_type=str(item.get("edge_type") or item.get("type") or "related"),
            status=str(item.get("status") or ""),
        ) for item in edge_list]
        pack_root = hashlib.sha256(source.encode()).hexdigest()
        payload = Payload(
            tool=tool, token_budget=token_budget, pack_root=pack_root,
            symbols=symbols, edges=gcf_edges,
        )
        if session_key:
            with self._lock:
                session = self._sessions.pop(session_key, None)
                if session is None:
                    session = Session()
                self._sessions[session_key] = session
                self._bound_sessions()
                gcf_text = encode_with_session(payload, session)
                session_size = session.size()
        else:
            gcf_text = encode(payload)
            session_size = 0
        savings = 1.0 - (len(gcf_text.encode()) / max(1, len(source.encode())))
        if mode == "auto" and savings < self.min_savings:
            return self._envelope(source, source, "json", {
                "profile": "graph", "gcf_candidate_bytes": len(gcf_text.encode()),
                "reason": "GCF savings below threshold",
            })
        return self._envelope(source, gcf_text, "gcf", {
            "profile": "graph", "pack_root": pack_root,
            "session": bool(session_key), "session_symbols": session_size,
        })

    def stream_graph(
        self,
        nodes: Iterable[Dict[str, Any]],
        edges: Iterable[Dict[str, Any]],
        *,
        writer: Any,
        tool: str,
        pack_root: str,
        token_budget: int = 0,
    ) -> WireStreamReceipt:
        """Incrementally emit a graph pack without retaining complete wire text."""
        if not GCF_AVAILABLE:
            raise RuntimeError("GCF streaming unavailable: gcf-python is not installed")
        if not pack_root:
            raise ValueError("streaming requires a precomputed durable pack_root")
        normalized_root = pack_root if pack_root.startswith("sha256:") else "sha256:" + pack_root
        hashing = _HashingWriter(writer)
        encoder = StreamEncoder(
            hashing, tool, token_budget=token_budget,
            pack_root=normalized_root.removeprefix("sha256:"),
            labeled_trailer_counts=True,
        )
        seen: set[str] = set()
        count = 0
        for index, node in enumerate(nodes):
            qname = str(node.get("qualified_name") or node.get("id") or node.get("file") or node.get("name") or f"node-{index}")
            if qname in seen:
                qname = f"{qname}#{index}"
            seen.add(qname)
            encoder.write_symbol(Symbol(
                qualified_name=qname,
                kind=str(node.get("kind") or "symbol").lower(),
                score=float(node.get("score") or 0.0),
                provenance=str(node.get("provenance") or "chimera_graph"),
                distance=int(node.get("distance") or 0),
                signature=str(node.get("signature") or node.get("description") or ""),
            ))
            count += 1
        edge_count = 0
        for item in edges:
            before = encoder.edge_count
            encoder.write_edge(Edge(
                source=str(item.get("source") or item.get("from") or ""),
                target=str(item.get("target") or item.get("to") or ""),
                edge_type=str(item.get("edge_type") or item.get("type") or "related"),
                status=str(item.get("status") or ""),
            ))
            if encoder.edge_count > before:
                edge_count += 1
        encoder.close()
        return WireStreamReceipt(
            profile="graph", pack_root=normalized_root,
            wire_hash=hashing.receipt_hash(), wire_bytes=hashing.bytes,
            records=count, edges=edge_count,
        )

    def stream_generic_records(
        self,
        records: Iterable[Dict[str, Any]],
        *,
        fields: List[str],
        writer: Any,
        name: str = "rows",
        pack_root: str,
    ) -> WireStreamReceipt:
        """Incrementally emit a flat generic table with deferred row count."""
        if not GCF_AVAILABLE:
            raise RuntimeError("GCF streaming unavailable: gcf-python is not installed")
        if not fields or not pack_root:
            raise ValueError("streaming requires fields and a precomputed durable pack_root")
        normalized_root = pack_root if pack_root.startswith("sha256:") else "sha256:" + pack_root
        hashing = _HashingWriter(writer)
        encoder = GenericStreamEncoder(hashing)
        encoder.write_kv("pack_root", normalized_root.removeprefix("sha256:"))
        encoder.begin_array(name, fields)
        count = 0
        for row in records:
            encoder.write_row([row.get(field) for field in fields])
            count += 1
        encoder.end_array()
        encoder.close()
        return WireStreamReceipt(
            profile="generic", pack_root=normalized_root,
            wire_hash=hashing.receipt_hash(), wire_bytes=hashing.bytes,
            records=count,
        )

    def decode(self, text: str) -> Any:
        size = len(text.encode("utf-8"))
        if size > self.max_decode_bytes:
            raise ValueError(f"wire payload exceeds {self.max_decode_bytes} bytes")
        stripped = text.lstrip()
        if stripped.startswith("GCF profile=graph") or (stripped.startswith("GCF ") and "profile=graph" in stripped.splitlines()[0]):
            value = decode(text)
        elif stripped.startswith("GCF profile=generic"):
            value = decode_generic(text)
        else:
            value = json.loads(text)
        self._validate_shape(value)
        return value

    def _validate_shape(self, value: Any) -> None:
        records = 0

        def walk(item: Any, depth: int) -> None:
            nonlocal records
            if depth > self.max_depth:
                raise ValueError(f"decoded payload exceeds max depth {self.max_depth}")
            records += 1
            if records > self.max_records:
                raise ValueError(f"decoded payload exceeds max records {self.max_records}")
            if isinstance(item, dict):
                for key, child in item.items():
                    if not isinstance(key, str):
                        raise ValueError("decoded mapping contains non-string key")
                    walk(child, depth + 1)
            elif isinstance(item, (list, tuple)):
                for child in item:
                    walk(child, depth + 1)
            elif hasattr(item, "__dict__"):
                walk(vars(item), depth + 1)

        walk(value, 0)

    def reset_session(self, session_key: str) -> None:
        with self._lock:
            self._sessions.pop(session_key, None)
            self._generic_delta_sessions.pop(session_key, None)

    def close(self) -> None:
        with self._lock:
            self._sessions.clear()
            self._generic_delta_sessions.clear()

    def report(self) -> Dict[str, Any]:
        with self._lock:
            source = self.metrics["source_bytes"]
            wire = self.metrics["wire_bytes"]
            return {
                **self.metrics,
                "gcf_available": GCF_AVAILABLE,
                "byte_reduction": round(0.0 if source == 0 else 1.0 - wire / source, 4),
                "active_sessions": len(self._sessions) + len(self._generic_delta_sessions),
                "graph_sessions": len(self._sessions),
                "generic_delta_sessions": len(self._generic_delta_sessions),
            }
