"""Intent and scope fence: assessment is not authorization to mutate."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Literal
@dataclass(frozen=True)
class IntentDecision:
 mode:Literal['assessment','implementation','ambiguous'];allow_write:bool;reason:str
class IntentGate:
 WRITE=('implement','fix','change','edit','add','remove','refactor','update','create','migrate','patch','build')
 ASSESS=('analyze','analyse','review','audit','diagnose','explain','what','why','investigate','assess','check')
 def decide(self,task:str)->IntentDecision:
  lower=task.lower();write=any(f' {w}' in ' '+lower for w in self.WRITE);assess=any(f' {w}' in ' '+lower for w in self.ASSESS)
  if write:return IntentDecision('implementation',True,'explicit mutation verb')
  if assess:return IntentDecision('assessment',False,'assessment request is not mutation authorization')
  return IntentDecision('ambiguous',False,'ambiguous task defaults to assessment-only')
