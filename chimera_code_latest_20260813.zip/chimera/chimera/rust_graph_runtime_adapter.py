"""Runtime adapter boundary for Rust graph mirror with fail-closed promotion."""
from __future__ import annotations

import json
import pathlib
from typing import Any

from pydantic import BaseModel, ConfigDict

from .graph import CodeGraph
from .rust_graph_mirror import RustGraphMirror


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class RustGraphPromotionStatus(_Frozen):
    schema_version: str = "chimera.rust-graph-runtime-promotion-status.v1"
    batch_conformance: bool
    incremental_conformance: bool
    watch_adapter_conformance: bool
    search_conformance: bool
    persisted_index_conformance: bool
    cross_platform_certified: bool = False
    runtime_integration_certified: bool = False
    mirror_only: bool = True
    production_replacement_authorized: bool = False
    reasons: tuple[str, ...]


class RustGraphRuntimeAdapter:
    """Expose Rust graph as an explicit mirror, never an automatic replacement."""

    ARTIFACTS = {
        "batch_conformance": "rust_graph_conformance_campaign_2026-08-11.json",
        "incremental_conformance": "rust_graph_incremental_campaign_2026-08-11.json",
        "watch_adapter_conformance": "rust_graph_watch_campaign_2026-08-11.json",
        "search_conformance": "rust_graph_search_campaign_2026-08-11.json",
        "persisted_index_conformance": "rust_graph_persisted_index_campaign_2026-08-11.json",
    }

    def __init__(self, root: pathlib.Path, binary: pathlib.Path | None = None):
        self.root = pathlib.Path(root).resolve()
        self.binary = pathlib.Path(binary).resolve() if binary is not None else self.root / "polyglot/rust_graph_mirror/target/release/chimera-rust-graph-mirror"

    def _artifact_passed(self, name: str) -> bool:
        path = self.root / "artifacts" / name
        if not path.exists():
            return False
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return False
        mirror_only = value.get("mirror_only")
        production_authorized = value.get("production_replacement_authorized")
        receipt = value.get("receipt") if isinstance(value.get("receipt"), dict) else {}
        if mirror_only is None:
            mirror_only = receipt.get("mirror_only")
        if production_authorized is None:
            production_authorized = receipt.get("production_replacement_authorized", False)
        return bool(value.get("all_passed") and mirror_only and not production_authorized)

    def promotion_status(self) -> RustGraphPromotionStatus:
        observed = {key: self._artifact_passed(path) for key, path in self.ARTIFACTS.items()}
        reasons: list[str] = []
        for key, passed in observed.items():
            if not passed:
                reasons.append(f"missing-or-failed:{key}")
        reasons.extend([
            "cross-platform certification is not complete",
            "runtime integration is mirror-only with Python fallback",
            "production replacement requires an explicit future authorization artifact",
        ])
        return RustGraphPromotionStatus(
            **observed,
            reasons=tuple(reasons),
        )

    def search(self, query: str, *, limit: int = 10, use_mirror: bool = False) -> dict[str, Any]:
        """Search with Python fallback unless mirror use is explicitly requested."""
        if use_mirror:
            status = self.promotion_status()
            if not self.binary.exists() or not status.search_conformance:
                return {"backend": "python-fallback", "reason": "rust mirror unavailable or uncertified", "hits": CodeGraph(self.root).build(persist=False).get("nodes", [])[:0]}
            try:
                hits = [item.model_dump(mode="json") for item in RustGraphMirror(self.root, self.binary).search(query, limit=limit)]
                return {"backend": "rust-mirror", "production_replacement_authorized": False, "hits": hits}
            except Exception as exc:
                return {"backend": "python-fallback", "reason": f"rust mirror failed: {type(exc).__name__}", "hits": CodeGraph(self.root).search(query, limit=limit)}
        graph = CodeGraph(self.root)
        graph.build(persist=False)
        return {"backend": "python", "hits": graph.search(query, limit=limit)}
