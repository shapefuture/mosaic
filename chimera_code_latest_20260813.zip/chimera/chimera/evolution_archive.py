"""Persistent quality-diversity program archive for long-running evolution."""
from __future__ import annotations

import json
import math
import pathlib
import random
import sqlite3
import threading
import time
from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Iterable, Mapping, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class Direction(StrEnum):
    MAXIMIZE = "maximize"
    MINIMIZE = "minimize"


class MetricSpec(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    name: str
    direction: Direction = Direction.MAXIMIZE
    weight: float = Field(default=1.0, ge=0.0)
    hard_min: Optional[float] = None
    hard_max: Optional[float] = None


class FeatureSpec(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    name: str
    bins: int = Field(default=10, ge=1, le=1000)
    minimum: float
    maximum: float

    @model_validator(mode="after")
    def _range(self) -> "FeatureSpec":
        if self.maximum <= self.minimum:
            raise ValueError("feature maximum must exceed minimum")
        return self

    def bin(self, value: float) -> int:
        ratio = (float(value) - self.minimum) / (self.maximum - self.minimum)
        return min(self.bins - 1, max(0, int(ratio * self.bins)))


class EvolutionCandidate(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    id: str
    code_ref: str
    code_digest: str
    parent_id: Optional[str] = None
    island: int = 0
    generation: int = 0
    metrics: dict[str, float]
    features: dict[str, float]
    feasible: bool
    insights: tuple[str, ...] = ()
    artifact_refs: tuple[str, ...] = ()
    model: str = ""
    operator: str = "mutation"
    cost: float = Field(default=0.0, ge=0.0)
    evaluator_digest: str
    complexity: float = Field(default=0.0, ge=0.0)
    proposal_context_hash: str = ""
    evaluation_seed: int = 0
    created_at: str

    @field_validator("metrics", "features")
    @classmethod
    def _finite_values(cls, values: dict[str, float]) -> dict[str, float]:
        if any(not math.isfinite(float(value)) for value in values.values()):
            raise ValueError("candidate metrics and features must be finite")
        return values


_SCHEMA = """
CREATE TABLE IF NOT EXISTS candidates (
 id TEXT PRIMARY KEY, payload TEXT NOT NULL, code_digest TEXT NOT NULL,
 parent_id TEXT, island INTEGER NOT NULL, generation INTEGER NOT NULL,
 feasible INTEGER NOT NULL, created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_candidate_code_eval ON candidates(code_digest, json_extract(payload,'$.evaluator_digest'));
CREATE INDEX IF NOT EXISTS idx_candidate_island ON candidates(island,generation);
CREATE TABLE IF NOT EXISTS cells (
 island INTEGER NOT NULL, cell_key TEXT NOT NULL, candidate_id TEXT NOT NULL,
 PRIMARY KEY(island,cell_key)
);
CREATE TABLE IF NOT EXISTS evolution_state (key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""


class EvolutionArchive:
    def __init__(
        self,
        path: pathlib.Path,
        metrics: Iterable[MetricSpec],
        features: Iterable[FeatureSpec],
        *,
        num_islands: int = 4,
        primary_metric: Optional[str] = None,
        archive_size: int = 500,
    ) -> None:
        self.path = pathlib.Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.path, check_same_thread=False)
        self.connection.executescript(_SCHEMA)
        self.metrics = tuple(metrics)
        self.features = tuple(features)
        if not self.metrics:
            raise ValueError("at least one objective metric is required")
        metric_names = [item.name for item in self.metrics]
        feature_names = [item.name for item in self.features]
        if len(metric_names) != len(set(metric_names)):
            raise ValueError("objective metric names must be unique")
        if len(feature_names) != len(set(feature_names)):
            raise ValueError("feature names must be unique")
        self.num_islands = int(num_islands)
        self.archive_size = int(archive_size)
        if self.num_islands < 1:
            raise ValueError("num_islands must be positive")
        if self.archive_size < max(10, self.num_islands):
            raise ValueError("archive_size must be at least max(10, num_islands)")
        self.primary_metric = primary_metric or self.metrics[0].name
        if self.primary_metric not in set(metric_names):
            raise ValueError("primary metric is not declared")
        self.lock = threading.RLock()
        self._candidate_cache: Optional[tuple[EvolutionCandidate, ...]] = None
        self._candidate_by_id: dict[str, EvolutionCandidate] = {}
        self._sqlite_data_version = int(self.connection.execute("PRAGMA data_version").fetchone()[0])
        config_identity = {
            "metrics": [item.model_dump(mode="json") for item in self.metrics],
            "features": [item.model_dump(mode="json") for item in self.features],
            "num_islands": self.num_islands, "primary_metric": self.primary_metric,
            "archive_size": self.archive_size,
        }
        existing = self.load_state("archive_config")
        if existing is not None and existing != config_identity:
            raise ValueError("archive configuration differs from persisted experiment")
        self.save_state("archive_config", config_identity)

    def close(self) -> None:
        self.connection.close()

    def feasible(self, values: Mapping[str, float]) -> bool:
        for spec in self.metrics:
            if spec.name not in values:
                return False
            value = float(values[spec.name])
            if spec.hard_min is not None and value < spec.hard_min:
                return False
            if spec.hard_max is not None and value > spec.hard_max:
                return False
        return True

    def _oriented(self, candidate: EvolutionCandidate, spec: MetricSpec) -> float:
        value = float(candidate.metrics[spec.name])
        return value if spec.direction is Direction.MAXIMIZE else -value

    def dominates(self, left: EvolutionCandidate, right: EvolutionCandidate) -> bool:
        if left.feasible and not right.feasible:
            return True
        if not left.feasible:
            return False
        weak = all(self._oriented(left, metric) >= self._oriented(right, metric) for metric in self.metrics)
        strict = any(self._oriented(left, metric) > self._oriented(right, metric) for metric in self.metrics)
        return weak and strict

    def utility(self, candidate: EvolutionCandidate) -> float:
        if not candidate.feasible:
            return float("-inf")
        total_weight = sum(metric.weight for metric in self.metrics) or 1.0
        return sum(metric.weight * self._oriented(candidate, metric) for metric in self.metrics) / total_weight

    def cell_key(self, candidate: EvolutionCandidate) -> str:
        return ":".join(str(spec.bin(candidate.features.get(spec.name, spec.minimum))) for spec in self.features) or "default"

    def _invalidate_candidates(self) -> None:
        self._candidate_cache = None
        self._candidate_by_id = {}
        self._sqlite_data_version = int(self.connection.execute("PRAGMA data_version").fetchone()[0])

    def _refresh_candidates(self) -> tuple[EvolutionCandidate, ...]:
        data_version = int(self.connection.execute("PRAGMA data_version").fetchone()[0])
        if self._candidate_cache is None or data_version != self._sqlite_data_version:
            rows = self.connection.execute("SELECT payload FROM candidates ORDER BY rowid").fetchall()
            self._candidate_cache = tuple(EvolutionCandidate.model_validate_json(row[0]) for row in rows)
            self._candidate_by_id = {item.id: item for item in self._candidate_cache}
            self._sqlite_data_version = data_version
        return self._candidate_cache

    def get(self, candidate_id: str) -> Optional[EvolutionCandidate]:
        self._refresh_candidates()
        return self._candidate_by_id.get(candidate_id)

    def all(self, island: Optional[int] = None) -> list[EvolutionCandidate]:
        rows = self._refresh_candidates()
        return list(rows if island is None else (candidate for candidate in rows if candidate.island == island))

    def contains_code(self, code_digest: str, evaluator_digest: str) -> bool:
        row = self.connection.execute(
            "SELECT 1 FROM candidates WHERE code_digest=? AND json_extract(payload,'$.evaluator_digest')=? LIMIT 1",
            (code_digest, evaluator_digest),
        ).fetchone()
        return bool(row)

    def add(self, candidate: EvolutionCandidate, *, minimum_gain: float = 0.0,
            complexity_penalty: float = 0.0) -> dict[str, Any]:
        if candidate.island < 0 or candidate.island >= self.num_islands:
            raise ValueError("candidate island out of range")
        if set(candidate.metrics) < {metric.name for metric in self.metrics}:
            raise ValueError("candidate is missing declared objective metrics")
        if candidate.feasible and not self.feasible(candidate.metrics):
            raise ValueError("candidate claims feasibility but violates objective bounds")
        key = self.cell_key(candidate)
        with self.lock, self.connection:
            if self.contains_code(candidate.code_digest, candidate.evaluator_digest):
                return {"added": False, "reason": "duplicate-code", "cell": key}
            incumbent_row = self.connection.execute(
                "SELECT candidate_id FROM cells WHERE island=? AND cell_key=?", (candidate.island, key)
            ).fetchone()
            incumbent = self.get(incumbent_row[0]) if incumbent_row else None
            accepted_cell = incumbent is None
            threshold = minimum_gain
            if incumbent is not None:
                growth = max(0.0, candidate.complexity - incumbent.complexity) / max(1.0, incumbent.complexity)
                threshold += growth * complexity_penalty
                accepted_cell = self.dominates(candidate, incumbent) or (
                    not self.dominates(incumbent, candidate)
                    and self.utility(candidate) >= self.utility(incumbent) + threshold
                )
            self.connection.execute(
                "INSERT INTO candidates(id,payload,code_digest,parent_id,island,generation,feasible,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (candidate.id, candidate.model_dump_json(), candidate.code_digest, candidate.parent_id,
                 candidate.island, candidate.generation, int(candidate.feasible), candidate.created_at),
            )
            if accepted_cell:
                self.connection.execute(
                    "INSERT INTO cells(island,cell_key,candidate_id) VALUES(?,?,?) "
                    "ON CONFLICT(island,cell_key) DO UPDATE SET candidate_id=excluded.candidate_id",
                    (candidate.island, key, candidate.id),
                )
            self._invalidate_candidates()
            self._prune_if_needed()
            self._invalidate_candidates()
            return {
                "added": True, "cell": key, "cell_elite": accepted_cell,
                "replaced": incumbent.id if incumbent and accepted_cell else None,
                "required_gain": threshold,
            }

    def _crowding_order(self, rows: Iterable[EvolutionCandidate]) -> list[EvolutionCandidate]:
        """Order a Pareto set by NSGA-II-style crowding, preserving extremes."""
        candidates = list(rows)
        if len(candidates) <= 2:
            return sorted(candidates, key=lambda item: (self.utility(item), item.id), reverse=True)
        distance = {item.id: 0.0 for item in candidates}
        for metric in self.metrics:
            ordered = sorted(candidates, key=lambda item: (self._oriented(item, metric), item.id))
            low = self._oriented(ordered[0], metric)
            high = self._oriented(ordered[-1], metric)
            distance[ordered[0].id] = float("inf")
            distance[ordered[-1].id] = float("inf")
            span = high - low
            if span <= 0:
                continue
            for index in range(1, len(ordered) - 1):
                before = self._oriented(ordered[index - 1], metric)
                after = self._oriented(ordered[index + 1], metric)
                distance[ordered[index].id] += (after - before) / span
        return sorted(
            candidates,
            key=lambda item: (distance[item.id], self.utility(item), item.id),
            reverse=True,
        )

    def _prune_if_needed(self) -> None:
        """Enforce a hard cap while retaining island champions and Pareto spread."""
        rows = self.all()
        if len(rows) <= self.archive_size:
            return
        by_id = {item.id: item for item in rows}
        keep: list[str] = []

        def include(items: Iterable[EvolutionCandidate]) -> None:
            for item in items:
                if item.id not in keep and len(keep) < self.archive_size:
                    keep.append(item.id)

        # One native champion per non-empty island is the only hard protection.
        include(item for island in range(self.num_islands) if (item := self.best(island)) is not None)
        # Preserve objective extremes before scalar utility, then MAP-Elites coverage.
        include(self._crowding_order(self.pareto_front()))
        cell_ids = [row[0] for row in self.connection.execute(
            "SELECT candidate_id FROM cells ORDER BY island,cell_key"
        ).fetchall()]
        include(sorted(
            (by_id[item_id] for item_id in cell_ids if item_id in by_id),
            key=lambda item: (self.utility(item), -item.complexity, item.id), reverse=True,
        ))
        include(sorted(
            rows, key=lambda item: (self.utility(item), -item.complexity, item.generation, item.id),
            reverse=True,
        ))
        doomed = [item.id for item in rows if item.id not in set(keep)]
        for candidate_id in doomed:
            self.connection.execute("DELETE FROM cells WHERE candidate_id=?", (candidate_id,))
            self.connection.execute("DELETE FROM candidates WHERE id=?", (candidate_id,))

        # If pruning removed a cell occupant, restore the best retained native member.
        occupied = {
            (int(island), str(cell)): candidate_id
            for island, cell, candidate_id in self.connection.execute(
                "SELECT island,cell_key,candidate_id FROM cells"
            ).fetchall()
        }
        for candidate_id in keep:
            item = by_id[candidate_id]
            slot = (item.island, self.cell_key(item))
            incumbent = by_id.get(occupied.get(slot, ""))
            if incumbent is None or self.dominates(item, incumbent) or (
                not self.dominates(incumbent, item) and self.utility(item) > self.utility(incumbent)
            ):
                self.connection.execute(
                    "INSERT INTO cells(island,cell_key,candidate_id) VALUES(?,?,?) "
                    "ON CONFLICT(island,cell_key) DO UPDATE SET candidate_id=excluded.candidate_id",
                    (slot[0], slot[1], item.id),
                )
                occupied[slot] = item.id

    def elites(self, island: Optional[int] = None) -> list[EvolutionCandidate]:
        query = (
            "SELECT c.payload FROM cells x JOIN candidates c ON c.id=x.candidate_id ORDER BY x.island,x.cell_key"
            if island is None else
            "SELECT c.payload FROM cells x JOIN candidates c ON c.id=x.candidate_id WHERE x.island=? ORDER BY x.cell_key"
        )
        rows = self.connection.execute(query, () if island is None else (island,)).fetchall()
        return [EvolutionCandidate.model_validate_json(row[0]) for row in rows]

    def pareto_front(self, island: Optional[int] = None) -> list[EvolutionCandidate]:
        rows = [candidate for candidate in self.all(island) if candidate.feasible]
        return [candidate for candidate in rows if not any(
            other.id != candidate.id and self.dominates(other, candidate) for other in rows
        )]

    def best(self, island: Optional[int] = None) -> Optional[EvolutionCandidate]:
        rows = [candidate for candidate in self.all(island) if candidate.feasible]
        if not rows:
            return None
        spec = next(metric for metric in self.metrics if metric.name == self.primary_metric)
        return max(rows, key=lambda candidate: (self._oriented(candidate, spec), -candidate.complexity, candidate.id))

    def _island_pool(self, island: int) -> list[EvolutionCandidate]:
        """Native candidates plus elites lazily migrated into this island's cells."""
        rows = [*self.all(island), *self.elites(island)]
        return list({candidate.id: candidate for candidate in rows if candidate.feasible}.values())

    def sample_parent(self, island: int, rng: random.Random, alpha: float = 1.5) -> EvolutionCandidate:
        rows = self._island_pool(island)
        if not rows:
            rows = [candidate for candidate in self.all() if candidate.feasible]
        if not rows:
            raise RuntimeError("archive has no feasible parent")
        ranked = sorted(rows, key=self.utility, reverse=True)
        weights = [1.0 / ((index + 1) ** max(0.01, alpha)) for index in range(len(ranked))]
        return rng.choices(ranked, weights=weights, k=1)[0]

    def inspirations(self, parent: EvolutionCandidate, rng: random.Random, *, island: Optional[int] = None,
                     top: int = 2, diverse: int = 2,
                     random_count: int = 1) -> list[EvolutionCandidate]:
        pool = [
            candidate for candidate in self._island_pool(parent.island if island is None else island)
            if candidate.id != parent.id
        ]
        chosen: list[EvolutionCandidate] = []
        for candidate in sorted(pool, key=self.utility, reverse=True)[:top]:
            if candidate.id not in {item.id for item in chosen}:
                chosen.append(candidate)
        parent_cell = self.cell_key(parent)
        extremes = [candidate for candidate in pool if self.cell_key(candidate) != parent_cell]
        for candidate in sorted(extremes, key=lambda item: self.cell_key(item))[:diverse]:
            if candidate.id not in {item.id for item in chosen}:
                chosen.append(candidate)
        remaining = [candidate for candidate in pool if candidate.id not in {item.id for item in chosen}]
        if remaining:
            chosen.extend(rng.sample(remaining, min(random_count, len(remaining))))
        return chosen

    def migrate(self, rng: random.Random, rate: float = 0.1) -> list[dict[str, Any]]:
        """Ring-share non-champion elites into destination cells; champions stay home."""
        migrations: list[dict[str, Any]] = []
        with self.lock, self.connection:
            for island in range(self.num_islands):
                elites = self.elites(island)
                champion = self.best(island)
                # Only native elites migrate. This prevents a migrant from cascading
                # through every island in one migration tick.
                candidates = [
                    item for item in elites
                    if item.island == island and (champion is None or item.id != champion.id)
                ]
                count = min(len(candidates), max(0, math.ceil(len(candidates) * max(0.0, min(1.0, rate)))))
                if count == 0:
                    continue
                target = (island + 1) % self.num_islands
                for source in rng.sample(candidates, count):
                    key = self.cell_key(source)
                    row = self.connection.execute(
                        "SELECT candidate_id FROM cells WHERE island=? AND cell_key=?", (target, key)
                    ).fetchone()
                    incumbent = self.get(row[0]) if row else None
                    if incumbent is not None and not (
                        self.dominates(source, incumbent)
                        or (not self.dominates(incumbent, source) and self.utility(source) > self.utility(incumbent))
                    ):
                        continue
                    self.connection.execute(
                        "INSERT INTO cells(island,cell_key,candidate_id) VALUES(?,?,?) "
                        "ON CONFLICT(island,cell_key) DO UPDATE SET candidate_id=excluded.candidate_id",
                        (target, key, source.id),
                    )
                    migrations.append({"source": source.id, "from_island": island, "target_island": target, "cell": key})
        return migrations

    def save_states(self, values: Mapping[str, Any]) -> None:
        """Atomically advance related checkpoint keys in one SQLite transaction."""
        rows = [
            (key, json.dumps(value, sort_keys=True, default=str))
            for key, value in values.items()
        ]
        with self.lock, self.connection:
            self.connection.executemany(
                "INSERT INTO evolution_state(key,value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                rows,
            )

    def save_state(self, key: str, value: Any) -> None:
        self.save_states({key: value})

    def load_state(self, key: str, default: Any = None) -> Any:
        row = self.connection.execute("SELECT value FROM evolution_state WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else default
