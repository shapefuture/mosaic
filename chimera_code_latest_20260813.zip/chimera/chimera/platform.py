"""Deployment profile truthfulness and local platform readiness inspection.

The doctor inspects only local process/filesystem capabilities. It never opens a
network connection, creates cloud resources, or upgrades a configured endpoint
to a certified deployment claim.
"""
from __future__ import annotations

import importlib.metadata
import importlib.util
import json
import os
import pathlib
import platform as host_platform
import shutil
import subprocess
import sys
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from .config import DeploymentProfile


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


# Compatibility name for the former doctor-only enum. Runtime and doctor now
# share one profile vocabulary.
PlatformProfile = DeploymentProfile


LegacyCapabilityState = Literal["available", "unavailable", "configured-unverified", "certified"]
CapabilityStatus = Literal[
    "ready",
    "installed-not-certified",
    "missing-dependency",
    "configured-but-untested",
    "manual-only",
    "not-supported-on-host",
]
DoctorProfile = Literal[
    "local",
    "cloud",
    "enterprise",
    "cloud-postgres",
    "durable-restate",
    "sandbox-linux",
    "cloud-runtime",
]


class PlatformCapability(_FrozenModel):
    name: str
    state: LegacyCapabilityState
    detail: str
    evidence: dict[str, str | bool | int | float | None] = Field(default_factory=dict)
    # New truth-status vocabulary for `chimera doctor`. Kept optional in the
    # legacy model so existing `platform doctor` callers remain compatible.
    status: CapabilityStatus | None = None
    required_for: tuple[str, ...] = ()


class CapabilityLane(_FrozenModel):
    name: str
    status: CapabilityStatus
    detail: str
    required_for: tuple[str, ...] = ()
    evidence: dict[str, str | bool | int | float | None] = Field(default_factory=dict)
    remediation: str | None = None


class CapabilityReport(_FrozenModel):
    schema_version: str = "chimera.capability-doctor.v1"
    profile: DoctorProfile
    root: str
    generated_by: str = "local-no-egress-inspection"
    certified: bool = False
    lanes: tuple[CapabilityLane, ...]
    summary: dict[CapabilityStatus, int]
    blockers: tuple[str, ...]
    notes: tuple[str, ...] = (
        "ready means the dependency is present and a bounded local evidence artifact or live local probe passed.",
        "configured-but-untested means configuration exists but this command did not perform a destructive, billable, or networked certification drill.",
        "manual-only means no local command can truthfully certify the lane without external operator evidence.",
    )


class DeploymentAttestation(_FrozenModel):
    profile: PlatformProfile
    root: str
    capabilities: tuple[PlatformCapability, ...]
    certified: bool = False

    @property
    def blockers(self) -> tuple[str, ...]:
        return tuple(item.name for item in self.capabilities if item.state == "unavailable")


def _command(command: str) -> str | None:
    return shutil.which(command)


def _version(command: list[str]) -> str | None:
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    text = (result.stdout + result.stderr).strip()
    return text.splitlines()[0] if text else None


def _import_available(module: str) -> bool:
    return importlib.util.find_spec(module) is not None


def _distribution_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def _truthy_env(*names: str) -> tuple[bool, tuple[str, ...]]:
    present = tuple(name for name in names if bool(os.environ.get(name)))
    return bool(present), present


def _artifact(root: pathlib.Path, name: str) -> dict[str, object] | None:
    path = root / "artifacts" / name
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"unreadable": True, "path": str(path)}


def _artifact_passed(root: pathlib.Path, name: str, *keys: str) -> bool:
    value = _artifact(root, name)
    if not value:
        return False
    if keys:
        return all(bool(value.get(key)) for key in keys)
    if bool(value.get("all_passed") or value.get("passed") or value.get("certified")):
        return True
    observed = value.get("observed")
    if isinstance(observed, dict) and observed and all(bool(item) for item in observed.values()):
        return True
    operation_summary = value.get("operation_summary")
    if isinstance(operation_summary, dict) and operation_summary and all(
        isinstance(item, dict) and bool(item.get("all_passed"))
        for item in operation_summary.values()
    ):
        return True
    if value.get("accepted_for_manual_review") is True:
        recall = value.get("case_recall")
        return bool(recall == 1.0 and value.get("stale_state_rejected") is True)
    return False


def _status_to_legacy(status: CapabilityStatus, *, name: str = "") -> LegacyCapabilityState:
    if status == "ready":
        # Existing `platform doctor` callers use `available` for simple local
        # facts and `certified` only for lanes with explicit certification
        # receipts such as Bubblewrap. The new top-level doctor exposes the
        # more precise status field for every lane.
        return "certified" if name in {"bubblewrap", "bubblewrap-materialized"} else "available"
    if status == "installed-not-certified":
        return "configured-unverified"
    if status == "configured-but-untested":
        return "configured-unverified"
    return "unavailable"


def _lane(
    name: str,
    status: CapabilityStatus,
    detail: str,
    *,
    required_for: tuple[str, ...] = (),
    evidence: dict[str, str | bool | int | float | None] | None = None,
    remediation: str | None = None,
) -> CapabilityLane:
    return CapabilityLane(
        name=name,
        status=status,
        detail=detail,
        required_for=required_for,
        evidence=evidence or {},
        remediation=remediation,
    )


class PlatformDoctor:
    """Local, no-egress deployment readiness view with no false certification."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def _workspace_writable(self) -> tuple[bool, pathlib.Path]:
        tenant_root = self.root / ".chimera" / "tenants"
        writable = False
        try:
            tenant_root.mkdir(parents=True, exist_ok=True)
            probe = tenant_root / ".doctor-probe"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink()
            writable = True
        except OSError:
            pass
        return writable, tenant_root

    def inspect(self, profile: PlatformProfile | str) -> DeploymentAttestation:
        legacy = {
            "SELF_HOSTED": DeploymentProfile.SINGLE_TENANT_PRODUCTION.value,
            "CLOUD_MULTI_TENANT": DeploymentProfile.MULTI_TENANT_PRODUCTION.value,
            "local": DeploymentProfile.LOCAL_DETERMINISTIC.value,
            "cloud": DeploymentProfile.MULTI_TENANT_PRODUCTION.value,
            "enterprise": DeploymentProfile.REGULATED.value,
            "cloud-postgres": DeploymentProfile.MULTI_TENANT_PRODUCTION.value,
            "durable-restate": DeploymentProfile.MULTI_TENANT_PRODUCTION.value,
            "sandbox-linux": DeploymentProfile.LOCAL_DETERMINISTIC.value,
            "cloud-runtime": DeploymentProfile.MULTI_TENANT_PRODUCTION.value,
        }
        selected = DeploymentProfile(legacy.get(str(profile), str(profile)))
        report_profile: DoctorProfile = "cloud" if selected is DeploymentProfile.MULTI_TENANT_PRODUCTION else "enterprise" if selected is DeploymentProfile.REGULATED else "local"
        lanes = self.capability_matrix(report_profile).lanes
        capabilities = tuple(
            PlatformCapability(
                name="bubblewrap-materialized" if lane.name == "bubblewrap" else lane.name,
                state=_status_to_legacy(lane.status, name=lane.name),
                detail=lane.detail,
                evidence=lane.evidence,
                status=lane.status,
                required_for=lane.required_for,
            )
            for lane in lanes
        )
        legacy_names = {item.name for item in capabilities}
        if selected is DeploymentProfile.MULTI_TENANT_PRODUCTION and "cloud-tenant-attestation" not in legacy_names:
            capabilities += (
                PlatformCapability(
                    name="cloud-tenant-attestation",
                    state="unavailable",
                    status="manual-only",
                    detail="cloud multi-tenant isolation requires deployment and restore drills; local configuration is insufficient",
                    evidence={"certified": False},
                    required_for=("cloud", "enterprise"),
                ),
            )
        return DeploymentAttestation(profile=selected, root=str(self.root), capabilities=capabilities)

    def capability_matrix(self, profile: DoctorProfile | str = "local") -> CapabilityReport:
        aliases = {
            "LOCAL_DETERMINISTIC": "local",
            "LOCAL_OFFLINE": "local",
            "DEV_EXTERNAL": "local",
            "SELF_HOSTED": "cloud",
            "CLOUD_MULTI_TENANT": "cloud",
            "SINGLE_TENANT_PRODUCTION": "cloud",
            "MULTI_TENANT_PRODUCTION": "cloud",
            "REGULATED": "enterprise",
        }
        selected = aliases.get(str(profile), str(profile))
        if selected not in {
            "local",
            "cloud",
            "enterprise",
            "cloud-postgres",
            "durable-restate",
            "sandbox-linux",
            "cloud-runtime",
        }:
            raise ValueError(f"unknown doctor profile: {profile}")
        selected_profile: DoctorProfile = selected  # type: ignore[assignment]
        required = self._required_profiles(selected_profile)
        lanes = self._lanes(required)
        summary: dict[CapabilityStatus, int] = {
            "ready": 0,
            "installed-not-certified": 0,
            "missing-dependency": 0,
            "configured-but-untested": 0,
            "manual-only": 0,
            "not-supported-on-host": 0,
        }
        for item in lanes:
            summary[item.status] += 1
        blockers = tuple(
            item.name
            for item in lanes
            if item.required_for
            and item.status
            in {
                "installed-not-certified",
                "missing-dependency",
                "configured-but-untested",
                "manual-only",
                "not-supported-on-host",
            }
        )
        certified = not blockers and all(
            item.status == "ready" for item in lanes if item.required_for
        )
        return CapabilityReport(
            profile=selected_profile,
            root=str(self.root),
            lanes=tuple(lanes),
            summary=summary,
            blockers=blockers,
            certified=certified,
        )

    @staticmethod
    def _required_profiles(profile: DoctorProfile) -> tuple[str, ...]:
        if profile == "local":
            return ("local",)
        if profile == "cloud-postgres":
            return ("cloud-postgres",)
        if profile == "durable-restate":
            return ("durable-restate",)
        if profile == "sandbox-linux":
            return ("sandbox-linux",)
        if profile == "cloud-runtime":
            return ("cloud-runtime",)
        if profile == "cloud":
            return ("local", "cloud-postgres", "durable-restate", "cloud")
        return ("local", "cloud-postgres", "durable-restate", "sandbox-linux", "cloud", "enterprise")

    def _required_for(self, lane_profiles: tuple[str, ...], required: tuple[str, ...]) -> tuple[str, ...]:
        return tuple(item for item in lane_profiles if item in required)

    def _lanes(self, required: tuple[str, ...]) -> list[CapabilityLane]:
        lanes: list[CapabilityLane] = []
        writable, tenant_root = self._workspace_writable()
        lanes.append(_lane(
            "workspace-state",
            "ready" if writable else "missing-dependency",
            "tenant/deployment state root is writable" if writable else "tenant/deployment state root is not writable",
            required_for=self._required_for(("local", "cloud-postgres", "durable-restate", "sandbox-linux", "cloud-runtime", "enterprise"), required),
            evidence={"path": str(tenant_root), "writable": writable},
            remediation="make the workspace writable or choose a different --workspace",
        ))
        lanes.append(_lane(
            "python-runtime",
            "ready" if sys.version_info >= (3, 11) else "missing-dependency",
            f"Python {sys.version.split()[0]} detected; Chimera requires >=3.11",
            required_for=self._required_for(("local", "cloud-postgres", "durable-restate", "sandbox-linux", "cloud-runtime", "enterprise"), required),
            evidence={"version": sys.version.split()[0], "executable": sys.executable},
            remediation="install Python 3.11 or newer",
        ))
        core_missing = [name for name in ("click", "httpx", "pydantic", "rich", "gcf-python", "cryptography") if _distribution_version(name) is None]
        lanes.append(_lane(
            "python-package-core-deps",
            "ready" if not core_missing else "missing-dependency",
            "all core Python distributions are importable" if not core_missing else f"missing distributions: {', '.join(core_missing)}",
            required_for=self._required_for(("local", "cloud-postgres", "durable-restate", "sandbox-linux", "cloud-runtime", "enterprise"), required),
            evidence={name: _distribution_version(name) for name in ("click", "httpx", "pydantic", "rich", "gcf-python", "cryptography")},
            remediation="run: python -m pip install -e .",
        ))
        lanes.append(self._bubblewrap_lane(required))
        lanes.append(self._gvisor_lane(required))
        lanes.append(self._rust_lane(required))
        lanes.append(self._scip_lane(required))
        lanes.append(self._pyright_lane(required))
        lanes.append(self._typescript_lsp_lane(required))
        lanes.append(self._semantic_lsp_lane(required))
        lanes.append(self._postgres_lane(required))
        lanes.append(self._dbos_lane(required))
        lanes.append(self._restate_lane(required))
        lanes.append(self._postgres_runtime_endpoint_lane(required))
        lanes.append(self._restate_runtime_endpoint_lane(required))
        lanes.append(self._provider_lane(required))
        lanes.append(self._cloud_state_lane(required))
        lanes.append(self._release_signing_lane(required))
        lanes.append(self._offline_wheelhouse_lane(required))
        lanes.append(self._microvm_lane(required))
        lanes.append(_lane(
            "provider-cancellation-billing-stop",
            "manual-only",
            "local cancellation can reserve worst-case exposure, but provider-side terminal billing stop requires authoritative provider receipts",
            required_for=self._required_for(("enterprise",), required),
            evidence={"local_ledger_module": str((self.root / "chimera" / "provider_billing.py").exists()), "certified": False},
            remediation="collect provider-specific cancellation and billing receipts before claiming billing termination",
        ))
        return lanes

    def _bubblewrap_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        binary = _command("bwrap")
        try:
            from .sandbox_certification import MaterializedBubblewrapCertifier
            local_receipt = MaterializedBubblewrapCertifier(self.root).load()
        except Exception:
            local_receipt = None
        local_ready = bool(local_receipt and local_receipt.certified)
        artifact_ready = local_ready or _artifact_passed(self.root, "bubblewrap_campaign_2026-08-11.json", "all_passed") or _artifact_passed(self.root, "sandbox_ladder_campaign_2026-08-11.json")
        if host_platform.system() != "Linux":
            status: CapabilityStatus = "not-supported-on-host"
            detail = "Bubblewrap requires Linux namespaces"
        elif binary and artifact_ready:
            status = "ready"
            detail = "bubblewrap binary exists and bounded host-local campaign evidence passed"
        elif binary:
            status = "installed-not-certified"
            detail = "bubblewrap binary exists, but no current campaign evidence was found"
        else:
            status = "missing-dependency"
            detail = "bubblewrap binary is absent"
        return _lane(
            "bubblewrap",
            status,
            detail,
            required_for=self._required_for(("sandbox-linux", "enterprise"), required),
            evidence={"binary": binary, "local_receipt_certified": local_ready, "campaign_all_passed": artifact_ready, "host_system": host_platform.system()},
            remediation="install bubblewrap and run evals/deployment/bubblewrap_campaign.py --results artifacts/bubblewrap_campaign_2026-08-11.json",
        )

    def _gvisor_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        binary = _command("runsc")
        pinned = pathlib.Path("/tmp/gvisor/runsc")
        receipt_path = self.root / ".chimera" / "sandbox-gvisor-certification.json"
        try:
            receipt = json.loads(receipt_path.read_text(encoding="utf-8")) if receipt_path.exists() else None
        except (OSError, json.JSONDecodeError):
            receipt = None
        receipt_ready = bool(isinstance(receipt, dict) and receipt.get("certified"))
        pinned_ready = pinned.is_file() and receipt_ready
        if host_platform.system() != "Linux":
            status: CapabilityStatus = "not-supported-on-host"
            detail = "gVisor/runsc requires Linux"
        elif pinned_ready:
            status = "ready"
            detail = "checksum-pinned /tmp/gvisor/runsc exists and the rootful ptrace certification receipt passed"
        elif binary or pinned.is_file():
            status = "installed-not-certified"
            detail = "runsc exists, but this workspace has no passing pinned gVisor certification receipt"
        else:
            status = "missing-dependency"
            detail = "runsc binary is absent"
        return _lane("gvisor-runsc", status, detail, required_for=self._required_for(("enterprise",), required), evidence={"binary": binary, "pinned_binary": str(pinned) if pinned.is_file() else None, "receipt_certified": receipt_ready})

    def _rust_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        rustc = _command("rustc")
        cargo = _command("cargo")
        artifact_ready = _artifact_passed(self.root, "rust_graph_conformance_campaign_2026-08-11.json", "all_passed") or _artifact_passed(self.root, "rust_graph_mirror_campaign_2026-08-11.json")
        if rustc and cargo and artifact_ready:
            status: CapabilityStatus = "ready"
            detail = "Rust toolchain exists and graph mirror conformance evidence passed; mirror remains non-authoritative"
        elif rustc and cargo:
            status = "installed-not-certified"
            detail = "Rust toolchain exists, but graph mirror conformance evidence is absent"
        else:
            status = "missing-dependency"
            detail = "rustc/cargo are absent"
        return _lane(
            "rust-graph-mirror",
            status,
            detail,
            required_for=self._required_for(("enterprise",), required),
            evidence={"rustc": _version(["rustc", "--version"]) if rustc else None, "cargo": _version(["cargo", "--version"]) if cargo else None, "mirror_only": True, "campaign_all_passed": artifact_ready},
        )

    def _scip_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        binary = _command("scip-typescript") or _command("scip-ts")
        artifact_ready = _artifact_passed(self.root, "typescript_semantic_lsp_candidate_campaign.json")
        if binary and artifact_ready:
            status: CapabilityStatus = "ready"
            detail = "SCIP TypeScript producer is present and candidate evidence exists"
        elif binary:
            status = "installed-not-certified"
            detail = "SCIP TypeScript producer is present, but no evidence artifact passed"
        else:
            status = "missing-dependency"
            detail = "SCIP TypeScript producer is absent"
        return _lane("scip-typescript", status, detail, required_for=self._required_for(("enterprise",), required), evidence={"binary": binary, "candidate_artifact": artifact_ready})

    def _pyright_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        binary = _command("pyright")
        artifact_ready = _artifact_passed(self.root, "chimera_semantic_retrieval_pyright_2026-08-11.json")
        if binary and artifact_ready:
            status: CapabilityStatus = "ready"
            detail = "Pyright executable is present and semantic retrieval evidence exists"
        elif binary:
            status = "installed-not-certified"
            detail = "Pyright executable is present, but no semantic retrieval evidence passed"
        else:
            status = "missing-dependency"
            detail = "Pyright executable is absent"
        return _lane("pyright-lsp", status, detail, required_for=self._required_for(("local", "enterprise"), required), evidence={"binary": binary, "version": _version(["pyright", "--version"]) if binary else None, "campaign_artifact": artifact_ready})

    def _typescript_lsp_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        binary = _command("typescript-language-server")
        tsc = _command("tsc")
        artifact_ready = _artifact_passed(self.root, "typescript_warm_monorepo_campaign_2026-08-11.json")
        if binary and tsc and artifact_ready:
            status: CapabilityStatus = "ready"
            detail = "TypeScript language server and tsc exist with warm-session evidence"
        elif binary and tsc:
            status = "installed-not-certified"
            detail = "TypeScript language server exists, but warm-session evidence is absent"
        else:
            status = "missing-dependency"
            detail = "typescript-language-server or tsc is absent"
        return _lane("typescript-lsp", status, detail, required_for=self._required_for(("enterprise",), required), evidence={"typescript_language_server": binary, "tsc": tsc, "warm_campaign": artifact_ready})

    def _semantic_lsp_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        modules = all(_import_available(name) for name in ("chimera.semantic_lsp", "chimera.semantic_code_intelligence"))
        corpus = (self.root / "evals" / "code_intelligence" / "chimera_semantic_retrieval_corpus_v1.json").exists()
        status: CapabilityStatus = "ready" if modules and corpus else "missing-dependency"
        return _lane("semantic-code-intelligence", status, "semantic LSP modules and retrieval corpus are present" if status == "ready" else "semantic code intelligence modules or corpus are missing", required_for=self._required_for(("local", "enterprise"), required), evidence={"modules_importable": modules, "corpus_present": corpus})

    def _postgres_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        configured, names = _truthy_env("CHIMERA_POSTGRES_URL", "DATABASE_URL")
        psycopg = _import_available("psycopg")
        artifact_ready = _artifact_passed(self.root, "cloud_state_postgres_rls_campaign_2026-08-11.json", "all_passed") or _artifact_passed(self.root, "cloud_state_postgres_campaign_2026-08-11.json")
        if psycopg and artifact_ready:
            status: CapabilityStatus = "ready"
            detail = "psycopg and bounded PostgreSQL RLS/cloud-state campaign evidence are present" + (" with a configured runtime URL" if configured else "")
        elif configured and psycopg:
            status = "configured-but-untested"
            detail = "PostgreSQL URL and psycopg exist, but no local campaign evidence passed in this workspace"
        else:
            status = "missing-dependency"
            detail = "PostgreSQL runtime is not configured and/or psycopg is absent"
        return _lane("postgres-cloud-state-rls", status, detail, required_for=self._required_for(("cloud-postgres", "enterprise"), required), evidence={"configured_envs": ",".join(names), "psycopg_importable": psycopg, "rls_campaign": artifact_ready})

    def _dbos_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        dbos = _import_available("dbos")
        artifact_ready = _artifact_passed(self.root, "dbos_durable_adapter_campaign_2026-08-11.json")
        status: CapabilityStatus
        if dbos and artifact_ready:
            status = "ready"
            detail = "DBOS package is importable and durable adapter evidence exists"
        elif dbos:
            status = "installed-not-certified"
            detail = "DBOS package is importable, but no durable adapter campaign evidence passed"
        else:
            status = "missing-dependency"
            detail = "DBOS package is absent"
        return _lane("dbos-durable-adapter", status, detail, required_for=self._required_for(("cloud-postgres", "enterprise"), required), evidence={"dbos_importable": dbos, "campaign_artifact": artifact_ready})

    def _restate_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        restate = _import_available("restate")
        configured, names = _truthy_env("RESTATE_ENDPOINT", "CHIMERA_RESTATE_ENDPOINT")
        artifact_ready = _artifact_passed(self.root, "restate_local_campaign_2026-08-11.json", "all_passed") or _artifact_passed(self.root, "restate_durable_adapter_campaign_2026-08-11.json")
        if restate and artifact_ready:
            status: CapabilityStatus = "ready"
            detail = "Restate SDK and bounded local durable campaign evidence are present" + (" with a configured endpoint" if configured else "")
        elif restate and configured:
            status = "configured-but-untested"
            detail = "Restate SDK and endpoint are configured, but no local campaign evidence passed"
        elif restate or artifact_ready:
            status = "installed-not-certified"
            detail = "Restate code or evidence exists, but the SDK/evidence pair is incomplete"
        else:
            status = "missing-dependency"
            detail = "Restate SDK and endpoint are absent"
        return _lane("restate-durable-adapter", status, detail, required_for=self._required_for(("durable-restate", "enterprise"), required), evidence={"restate_importable": restate, "configured_envs": ",".join(names), "campaign_artifact": artifact_ready})

    def _postgres_runtime_endpoint_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        configured, names = _truthy_env("CHIMERA_POSTGRES_URL", "DATABASE_URL")
        psycopg = _import_available("psycopg")
        artifact_ready = _artifact_passed(self.root, "cloud_state_postgres_rls_campaign_2026-08-11.json", "all_passed") or _artifact_passed(self.root, "cloud_state_postgres_campaign_2026-08-11.json")
        if configured and psycopg and artifact_ready:
            status: CapabilityStatus = "ready"
            detail = "persistent PostgreSQL endpoint configuration is present with psycopg and bounded certification evidence"
        elif configured and psycopg:
            status = "configured-but-untested"
            detail = "persistent PostgreSQL endpoint configuration is present, but bounded certification evidence is missing"
        else:
            status = "missing-dependency"
            detail = "no persistent CHIMERA_POSTGRES_URL or DATABASE_URL is configured"
        return _lane(
            "postgres-runtime-endpoint",
            status,
            detail,
            required_for=self._required_for(("cloud-runtime", "enterprise"), required),
            evidence={"configured_envs": ",".join(names), "psycopg_importable": psycopg, "rls_campaign": artifact_ready},
            remediation="set CHIMERA_POSTGRES_URL/DATABASE_URL via a secret manager and run the PostgreSQL certification bundle",
        )

    def _restate_runtime_endpoint_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        configured, names = _truthy_env("RESTATE_ENDPOINT", "CHIMERA_RESTATE_ENDPOINT", "CHIMERA_RESTATE_INGRESS")
        restate = _import_available("restate")
        artifact_ready = _artifact_passed(self.root, "restate_local_campaign_2026-08-11.json", "all_passed") or _artifact_passed(self.root, "restate_durable_adapter_campaign_2026-08-11.json")
        if configured and restate and artifact_ready:
            status: CapabilityStatus = "ready"
            detail = "persistent Restate endpoint configuration is present with SDK and bounded certification evidence"
        elif configured and restate:
            status = "configured-but-untested"
            detail = "persistent Restate endpoint configuration is present, but bounded certification evidence is missing"
        else:
            status = "missing-dependency"
            detail = "no persistent Restate endpoint environment variable is configured"
        return _lane(
            "restate-runtime-endpoint",
            status,
            detail,
            required_for=self._required_for(("cloud-runtime", "enterprise"), required),
            evidence={"configured_envs": ",".join(names), "restate_importable": restate, "campaign_artifact": artifact_ready},
            remediation="set CHIMERA_RESTATE_INGRESS/CHIMERA_RESTATE_ENDPOINT via a secret manager and run the Restate certification bundle",
        )

    def _provider_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        configured, names = _truthy_env(
            "OPENROUTER_API_KEY",
            "OPENROUTER_API_KEYS",
            "CEREBRAS_API_KEY",
            "GOOGLE_API_KEY",
            "GEMINI_API_KEY",
            "TOKENROUTER_KEY",
            "TOKENROUTER_API_KEY",
        )
        artifact_ready = (self.root / "chimera" / "provider_adapters.py").exists()
        status: CapabilityStatus = "configured-but-untested" if configured else "missing-dependency"
        detail = "provider credentials are present; live quota/capability canaries were not run by doctor" if configured else "no provider credential environment variables are present"
        return _lane("llm-provider-credentials", status, detail, required_for=(), evidence={"configured_envs": ",".join(names), "adapter_module_present": artifact_ready}, remediation="run provider canaries explicitly with --authorize-live-call before production routing")

    def _cloud_state_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        module = _import_available("chimera.cloud_state")
        configured, names = _truthy_env("CHIMERA_POSTGRES_URL", "DATABASE_URL", "RESTATE_ENDPOINT", "CHIMERA_RESTATE_ENDPOINT")
        artifact_ready = _artifact_passed(self.root, "cloud_state_postgres_rls_campaign_2026-08-11.json", "all_passed")
        if module and configured and artifact_ready:
            status: CapabilityStatus = "ready"
            detail = "cloud state module, configuration, and RLS evidence are present"
        elif module and configured:
            status = "configured-but-untested"
            detail = "cloud state configuration exists, but local RLS/durability campaign evidence was not verified"
        else:
            status = "missing-dependency"
            detail = "cloud state is not configured for this process"
        return _lane("cloud-state-configured", status, detail, required_for=self._required_for(("cloud", "enterprise"), required), evidence={"module_importable": module, "configured_envs": ",".join(names), "rls_campaign": artifact_ready})

    def _release_signing_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        configured, names = _truthy_env("CHIMERA_RELEASE_SIGNING_KEY")
        workflow = (self.root / ".github" / "workflows" / "release-provenance.yml").exists()
        status: CapabilityStatus = "manual-only" if workflow else "missing-dependency"
        detail = "release workflow exists; protected environment and external signing approval cannot be locally certified" if workflow else "release-provenance workflow is absent"
        return _lane("release-provenance-signing", status, detail, required_for=self._required_for(("enterprise",), required), evidence={"workflow_present": workflow, "configured_envs": ",".join(names), "local_secret_present": configured}, remediation="configure protected release-signing environment and verify signed provenance in CI")

    def _offline_wheelhouse_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        artifact = _artifact(self.root, "offline_wheelhouse_campaign_2026-08-11.json")
        passed = bool(artifact and (artifact.get("all_passed") or artifact.get("passed")))
        if passed:
            status: CapabilityStatus = "ready"
            detail = "offline wheelhouse campaign artifact passed"
        else:
            status = "installed-not-certified" if (self.root / "artifacts").exists() else "missing-dependency"
            detail = "offline wheelhouse evidence is missing or did not pass"
        wheels = artifact.get("wheel_count") if isinstance(artifact, dict) else None
        return _lane("offline-wheelhouse", status, detail, required_for=self._required_for(("enterprise",), required), evidence={"campaign_present": bool(artifact), "wheel_count": wheels})

    def _microvm_lane(self, required: tuple[str, ...]) -> CapabilityLane:
        kvm = pathlib.Path("/dev/kvm").exists() and os.access("/dev/kvm", os.R_OK | os.W_OK)
        firecracker = _command("firecracker")
        kata = _command("kata-runtime")
        if not kvm:
            status: CapabilityStatus = "not-supported-on-host"
            detail = "/dev/kvm is unavailable or inaccessible; Kata/Firecracker certification cannot run here"
        elif firecracker or kata:
            status = "installed-not-certified"
            detail = "KVM and a microVM runtime exist, but no certification drill has passed"
        else:
            status = "missing-dependency"
            detail = "KVM is present but Kata/Firecracker runtime is absent"
        return _lane("microvm-sandbox", status, detail, required_for=self._required_for(("enterprise",), required), evidence={"kvm_access": kvm, "firecracker": firecracker, "kata_runtime": kata})
