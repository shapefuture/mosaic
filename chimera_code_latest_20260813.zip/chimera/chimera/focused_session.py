"""Focused-coder setup, acceptance, protected-test, and capsule-hit helpers."""
from __future__ import annotations

from typing import Any, Dict, Optional

from .capsule import build_capsule_spec
from .quality import ChangeTarget, TaskContract


class FocusedSessionMixin:
    def _focused_contract(self, task: str, contract_override: Optional[TaskContract]) -> TaskContract:
        contract = contract_override or TaskContract.compile(self.root, task)
        self._thread_local.contract = contract
        if not contract.targets:
            # Fall back to the graph's strongest existing file rather than ask
            # the model to browse the whole repository.
            _, hits = self._repository_context(task, max_files=3, max_chars=4_000)
            for hit in hits:
                path = hit.get("file")
                if path and (self.root / path).is_file() and not path.startswith("tests/"):
                    contract.targets.append(ChangeTarget(path, "edit", "top graph retrieval target"))
                    break
        return contract

    def _acceptance_setup(self, contract: TaskContract, test_command: str):
        from .acceptance_ledger import AcceptanceLedger

        acceptance_ledger = AcceptanceLedger(self.root)
        acceptance_contract = {
            "task": contract.task,
            "targets": [target.__dict__ for target in contract.targets],
            "tests": sorted(contract.tests),
            "protected_paths": list(contract.protected_paths),
            "required_symbols": contract.required_symbols,
            "required_calls": contract.required_calls,
        }
        acceptance_hash = acceptance_ledger.contract_hash(acceptance_contract)
        acceptance_cards = [
            acceptance_ledger.card(
                f"{test_command or 'declared verification'} passes after the scoped change",
                (target.path, *sorted(contract.tests)), acceptance_hash,
            )
            for target in contract.targets
        ]
        acceptance_states = list(acceptance_ledger.reconcile(acceptance_cards))
        return acceptance_ledger, acceptance_cards, acceptance_states

    def _protected_test_setup(self, branch: str, contract: TaskContract) -> tuple[dict[str, str], Any]:
        from .fable_transfers import TestIntegrityGuard

        protected_test_before: dict[str, str] = {}
        for path in contract.protected_paths:
            if path.startswith("tests/"):
                try:
                    protected_test_before[path] = self.workspace.read(branch, path).decode(
                        "utf-8", errors="surrogateescape"
                    )
                except (FileNotFoundError, ValueError):
                    protected_test_before[path] = "<missing-before>"
        return protected_test_before, TestIntegrityGuard.snapshot(protected_test_before)

    def _maybe_generate_branch_local_tests(
        self,
        branch: str,
        contract: TaskContract,
        protected_test_before: dict[str, str],
    ) -> None:
        import os

        if os.environ.get("CHIMERA_ENABLE_TESTER_AGENT") != "1":
            return
        try:
            from .tester_agent import GeneratedTestLedger, TesterAgent

            tester = TesterAgent(self.root)
            ledger = GeneratedTestLedger(self.root)
            for target in contract.targets:
                for rel, content in tester.generate(contract.task, target.path).items():
                    # Generated tests are branch-local evidence. Writing them to
                    # self.root would mutate the caller workspace before patch
                    # admission and bypass the transaction.
                    self.workspace.write(branch, rel, content)
                    seal = ledger.seal_content(rel, content)
                    protected_test_before[rel] = content
                    evidence_seed = getattr(self._thread_local, "tester_agent_evidence", [])
                    evidence_seed.append({
                        "stage": "tester-agent",
                        "target": target.path,
                        "path": rel,
                        "seal": seal.as_dict(),
                        "branch_local": True,
                    })
                    self._thread_local.tester_agent_evidence = evidence_seed
        except Exception as exc:
            self._thread_local.tester_agent_evidence = [{
                "stage": "tester-agent",
                "ok": False,
                "error": f"{type(exc).__name__}: {exc}"[:300],
            }]

    def _baseline_test(self, branch: str, test_command: str, verification_scope: str) -> dict[str, Any]:
        # A micro transaction trades baseline regression classification for one
        # final full-suite proof. It never skips the post-patch executable gate;
        # it only avoids running the same full suite before bytes exist.
        if test_command and verification_scope == "impact":
            return self.action_executor.run_branch_tests(branch, command=test_command, impact_scope=False)
        return {"status": None, "skipped": "micro/full verification performs one post-patch full gate"}

    def _focused_interfaces(self, task: str, shared_context: str, context_mode: str) -> str:
        interfaces = "" if context_mode == "micro" else self._interface_context(task, max_chars=12_000)
        if shared_context:
            interfaces += "\n--- SHARED OBSERVATION EVIDENCE ---\n" + shared_context[:12_000]
        return interfaces

    def _run_focused_tests(self, branch: str, test_command: str, verification_scope: str) -> dict[str, Any]:
        with self._workspace_lock:
            return self.action_executor.run_branch_tests(
                branch, command=test_command, impact_scope=(verification_scope == "impact")
            )

    def _focused_capsule_spec(
        self,
        *,
        branch: str,
        task: str,
        model: str,
        contract: TaskContract,
        test_command: str,
        context_mode: str,
    ):
        return build_capsule_spec(
            root=self.root,
            workspace=self.workspace,
            branch=branch,
            task=task,
            model=model,
            config=self.config,
            contract=contract,
            parameters={
                "test_command": test_command,
                "focused_coder": "v2",
                "context_mode": context_mode,
                "tool_surface": self.config.planner.tool_surface,
            },
        )

    def _try_replay_focused_capsule(self, *, capsule_spec, branch: str, contract: TaskContract, model: str):
        if capsule_spec is None:
            return None
        cached = self.capsule_cache.get(capsule_spec)
        if cached is None:
            return None
        replay = self.action_executor.apply_patch_payload(branch, cached.artifact)
        expected = len(cached.artifact.get("files", []))
        if replay.get("rejected") or len(replay.get("applied", [])) != expected:
            return None
        diff = self.workspace.diff(branch)
        changed_paths = list(dict.fromkeys(replay.get("applied", [])))
        cached_test = {
            "status": 0,
            "cached": True,
            "capsule_key": capsule_spec.key,
            "record_hash": cached.record.record_hash,
            "evidence_refs": list(cached.record.evidence_refs),
        }
        return {
            "artifacts": {
                "answer": f"Verified capsule hit: changed={changed_paths}; tests=0 (cached exact capsule)",
                "patch": replay,
                "diff": diff,
                "ops": diff.get("ops", []),
                "test_status": 0,
                "test_evidence": cached_test,
                "quality_evidence": [{
                    "stage": "capsule-hit",
                    "ok": True,
                    "capsule_key": capsule_spec.key,
                    "record_hash": cached.record.record_hash,
                }],
                "quality": {
                    "admissible": bool(changed_paths),
                    "score": 1.0,
                    "repair_rounds": 0,
                    "target_coverage": len(set(changed_paths)) / max(1, len(contract.targets)),
                    "protected_paths_unchanged": not any(path in contract.protected_paths for path in changed_paths),
                    "semantic_fallback_used": False,
                    "model_outputs_admitted": 0,
                    "capsule_hit": True,
                },
                "contract": {
                    "targets": [target.__dict__ for target in contract.targets],
                    "protected_paths": contract.protected_paths,
                    "required_literals": contract.required_literals,
                    "required_symbols": contract.required_symbols,
                    "required_calls": contract.required_calls,
                    "required_mapping_keys": contract.required_mapping_keys,
                    "required_prefixes": contract.required_prefixes,
                    "required_call_arity": contract.required_call_arity,
                },
                "provider": {
                    "model": model,
                    "provider": "verified-capsule",
                    "real_call": False,
                    "api_calls": 0,
                    "key_slots": [],
                    "key_pool_size": 0,
                },
            },
            "trace": [
                {"kind": "capsule_hit", "data": {
                    "capsule_key": capsule_spec.key,
                    "record_hash": cached.record.record_hash,
                }},
                {"kind": "patch_applied", "data": replay},
                {"kind": "test_result", "data": {
                    "status": 0,
                    "cached": True,
                    "repair_rounds": 0,
                }},
            ],
            "tokens": 0,
        }
