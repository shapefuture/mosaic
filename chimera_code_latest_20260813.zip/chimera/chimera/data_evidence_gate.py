"""Data-backed, manual-only promotion gate for deferred features.

Unit tests prove mechanics; they do not prove a feature is superior.  This gate
requires a sealed frame and paired held-out observations before a human may
consider enabling a feature.  It never enables anything itself.
"""
from __future__ import annotations

import math
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class DataEvidenceFrame(_FrozenModel):
    feature_id: str
    corpus_hash: str
    evaluator_epoch: str
    configuration_hash: str
    protected_test_manifest_hash: str
    source_manifest_ref: str


class FeatureEvidencePolicy(_FrozenModel):
    feature_id: str
    metric_name: str
    direction: Literal["higher", "lower"]
    minimum_pairs: int = Field(default=5, ge=2, le=10_000)
    minimum_win_rate: float = Field(default=0.70, gt=0.5, le=1.0)
    minimum_relative_gain: float = Field(default=0.02, ge=0.0, le=10.0)
    require_live_or_platform_evidence: bool = True


class PairedFeatureObservation(_FrozenModel):
    case_id: str
    repetition: int = Field(ge=0)
    baseline_metric: float = Field(ge=0)
    challenger_metric: float = Field(ge=0)
    baseline_success: bool
    challenger_success: bool
    baseline_safety_ok: bool
    challenger_safety_ok: bool
    baseline_full_tests_ok: bool
    challenger_full_tests_ok: bool
    baseline_protected_ok: bool
    challenger_protected_ok: bool
    baseline_unknown: bool = False
    challenger_unknown: bool = False
    evidence_refs: tuple[str, ...] = Field(min_length=1)
    live_or_platform: bool = False


class FeatureEvidenceDecision(_FrozenModel):
    feature_id: str
    accepted_for_manual_review: bool
    automatic_enablement: bool = False
    manual_promotion_required: bool = True
    comparable_pairs: int
    win_rate: float | None
    median_relative_gain: float | None
    reasons: tuple[str, ...]


class DataEvidenceGate:
    """Reject incomplete/unsafe/incomparable observations before scoring gains."""

    def evaluate(
        self,
        *,
        frame: DataEvidenceFrame,
        policy: FeatureEvidencePolicy,
        observations: list[PairedFeatureObservation] | tuple[PairedFeatureObservation, ...],
    ) -> FeatureEvidenceDecision:
        reasons: list[str] = []
        rows = tuple(observations)
        if frame.feature_id != policy.feature_id:
            reasons.append("feature frame and evidence policy differ")
        keys = [(row.case_id, row.repetition) for row in rows]
        if len(keys) != len(set(keys)):
            reasons.append("duplicate case/repetition observation")
        if len(rows) < policy.minimum_pairs:
            reasons.append(f"requires at least {policy.minimum_pairs} paired observations")
        if policy.require_live_or_platform_evidence and not all(row.live_or_platform for row in rows):
            reasons.append("requires live or platform evidence; fixture-only observations are insufficient")
        for row in rows:
            if row.baseline_unknown or row.challenger_unknown:
                reasons.append(f"unknown outcome in {row.case_id}/{row.repetition}")
            if not row.challenger_safety_ok or not row.challenger_full_tests_ok or not row.challenger_protected_ok:
                reasons.append(f"challenger safety/full/protected gate failed in {row.case_id}/{row.repetition}")
            if row.baseline_success and not row.challenger_success:
                reasons.append(f"challenger regressed task success in {row.case_id}/{row.repetition}")
            if not row.evidence_refs:
                reasons.append(f"missing evidence references in {row.case_id}/{row.repetition}")
        gains: list[float] = []
        wins = 0
        for row in rows:
            if policy.direction == "higher":
                denominator = max(row.baseline_metric, 1e-12)
                gain = (row.challenger_metric - row.baseline_metric) / denominator
            else:
                denominator = max(row.baseline_metric, 1e-12)
                gain = (row.baseline_metric - row.challenger_metric) / denominator
            gains.append(gain)
            if gain >= policy.minimum_relative_gain:
                wins += 1
        win_rate = wins / len(rows) if rows else None
        median_gain = sorted(gains)[len(gains) // 2] if gains else None
        if win_rate is not None and win_rate < policy.minimum_win_rate:
            reasons.append(f"win rate {win_rate:.3f} below required {policy.minimum_win_rate:.3f}")
        if median_gain is not None and median_gain < policy.minimum_relative_gain:
            reasons.append(f"median relative gain {median_gain:.3f} below required {policy.minimum_relative_gain:.3f}")
        return FeatureEvidenceDecision(
            feature_id=policy.feature_id,
            accepted_for_manual_review=not reasons,
            comparable_pairs=len(rows),
            win_rate=win_rate,
            median_relative_gain=median_gain,
            reasons=tuple(dict.fromkeys(reasons)),
        )
