
"""
DAG Planner — VMAO + VeriMAP verified orchestration

Per PRD §7.5 / VMAO 2603.11445 + VeriMAP 2510.17109:
- VMAO: Verified Multi-Agent Orchestration, 5-phase Plan->Execute->Verify->Replan->Synthesize
  DAG of sub-questions, dependency-aware parallel execution, automatic context propagation,
  LLM verifier completeness 3.1->4.2 / source quality 2.6->4.1 (1-5 scale), verification-driven adaptive replanning,
  configurable stop conditions (completeness threshold, confidence, resource constraints)
- VeriMAP: Verification-Aware Planning, verification functions (VFs) Python+NL, Structured/Named I/O,
  per-subtask Verifier returns complete/partial/incomplete + self-refine

Spec: plan = {id, question, agent_type, dependencies, verification_criteria, effect, token_budget, priority, io_spec}
Scheduler: work-stealing DAG — priority + dependencies + verification_criteria, token_budget/agent_timeout/diminishing_returns
"""
from __future__ import annotations
import time, json, pathlib, concurrent.futures, re
from typing import List, Dict, Any, Optional, Callable, Mapping
from pydantic import BaseModel, Field
from .verifier import Verifier
from .hierarchical import HierarchicalTaskCompiler, HierarchicalPlan
from .task_slice import TaskSlice
from .execution_coverage import DAGCoverageBuilder, CoverageFailureClass, persisted_manifest_payload

class DAGNode(BaseModel):
    """VeriMAP: Structured and Named I/O + VF per subtask"""
    id: str
    question: str
    agent_type: str = "general"
    dependencies: List[str] = Field(default_factory=list)
    verification_criteria: str = ""
    effect: Dict[str, Any] = Field(default_factory=dict)
    priority: int = 0
    token_budget: int = 10_000
    timeout: int = 60
    status: str = "pending"  # pending|running|complete|partial|failed (VeriMAP)
    # VeriMAP Structured I/O
    inputs: Dict[str, Any] = Field(default_factory=dict)  # Named I/O: input name -> type/desc
    outputs: Dict[str, Any] = Field(default_factory=dict)  # Named I/O
    vf_python: Optional[str] = None  # VeriMAP Python VF code
    vf_nl: Optional[str] = None  # VeriMAP NL criteria
    model_route: Optional[str] = None  # cost-governor decision, evidence not an override of explicit user model

class Plan(BaseModel):
    id: str
    task: str
    nodes: List[DAGNode]
    verification_criteria: str = ""
    created_at: str = ""
    # VMAO configurable stop conditions
    stop_conditions: Dict[str, Any] = Field(default_factory=lambda: {"completeness_threshold": 0.9, "source_quality_threshold": 4.0, "max_iters": 3, "token_budget": 100_000})
    planning_evidence: Dict[str, Any] = Field(default_factory=dict)

class DAGPlanner:
    """VMAO planner with dependency-aware parallel execution + automatic context propagation (VMAO §3.1)"""
    def __init__(self, max_parallel: int=4, token_budget: int=100_000, agent_timeout: int=300, verifier: Optional[Verifier]=None,
                 completeness_threshold: float=0.9, source_quality_threshold: float=4.0, max_iters: int=3,
                 root: pathlib.Path = pathlib.Path("."), graph=None, cost_governor=None,
                 admission_max_pending: int | None = None, queue_budget_seconds: float | None = None):
        self.max_parallel = max_parallel
        self.token_budget = token_budget
        self.agent_timeout = agent_timeout
        # A DAG is a finite local work inventory, not a durable global queue.
        # Admission is still applied at each launch so queue age/priority is
        # explicit. A finite pending limit is opt-in until product-level queue
        # SLOs and a truthful user-facing deferral channel exist.
        self.admission_max_pending = None if admission_max_pending is None else max(0, int(admission_max_pending))
        self.queue_budget_seconds = None if queue_budget_seconds is None else max(0.001, float(queue_budget_seconds))
        self.verifier = verifier or Verifier()
        self.root = pathlib.Path(root).resolve()
        self.graph = graph
        if cost_governor is None:
            from .cost_governor import CostGovernor
            cost_governor = CostGovernor()
        self.cost_governor = cost_governor
        from .scheduling import HistoricalCPMScheduler, LatencyLedger
        self.latency_ledger = LatencyLedger(self.root)
        self.historical_scheduler = HistoricalCPMScheduler(self.latency_ledger)
        self._last_schedule_evidence = None
        from .plan_cache import PlanCache
        self.plan_cache = PlanCache(self.root)
        from .artifacts import ContentAddressedArtifactStore
        self.artifacts = ContentAddressedArtifactStore(self.root)
        from .dag_checkpoint import DAGCheckpointStore
        self.checkpoints = DAGCheckpointStore(self.root)
        self.compiler_version = "hierarchical-v3-streaming"
        # VMAO configurable stop conditions: balance quality vs cost
        self.completeness_threshold = completeness_threshold  # VMAO 3.1->4.2 on 1-5 scale
        self.source_quality_threshold = source_quality_threshold  # VMAO 2.6->4.1
        self.max_iters = max_iters

    def _hierarchical_plan(self, task: str, compiler: HierarchicalTaskCompiler,
                           integration_branch: str = "integration") -> Plan:
        hierarchy = compiler.compile(task, integration_branch=integration_branch)
        nodes: List[DAGNode] = []
        for atom_id in hierarchy.atoms:
            atom = hierarchy.units[atom_id]
            if atom.kind == "integration":
                agent_type = "verifier"
                criteria = "Full integration tests pass; root acceptance contract is satisfied; LTL/effect checks hold"
                priority = 2
            else:
                agent_type = "coder"
                criteria = "Diff/proof artifact exists and relevant tests pass; " + "; ".join(atom.acceptance)
                priority = max(3, 12 - atom.depth * 2 - len(atom.dependencies))
            task_slice = hierarchy.metadata.get("task_slices", {}).get(atom.id)
            inputs = {"atom_spec": atom.model_dump(), "root_task": task}
            if task_slice is not None:
                inputs["task_slice"] = task_slice
            nodes.append(DAGNode(
                id=atom.id,
                question=atom.goal,
                agent_type=agent_type,
                dependencies=list(atom.dependencies),
                verification_criteria=criteria,
                effect=atom.effect,
                priority=priority,
                token_budget=atom.token_budget,
                timeout=min(self.agent_timeout, 600),
                inputs=inputs,
                outputs={"diff": "Patch", "test_status": "int", "quality": "QualityEvidence", "task_slice": "TaskSlice"},
                vf_nl="Atom output must satisfy its local acceptance contract with executable evidence",
            ))
        integration_ids = [atom_id for atom_id in hierarchy.atoms if hierarchy.units[atom_id].kind == "integration"]
        nodes.append(DAGNode(
            id="sq_syn", question="Synthesize the hierarchical implementation evidence into the root result",
            agent_type="synthesizer", dependencies=integration_ids or list(hierarchy.atoms),
            verification_criteria="Synthesis includes the integration test status, changed paths, and diff hash",
            priority=1, inputs={"hierarchy_id": hierarchy.id, "root_task": task},
        ))
        for node in nodes:
            phase = "validation" if node.agent_type in {"verifier", "synthesizer"} else "evolver"
            node.model_route = self.cost_governor.route(phase)
        return Plan(
            id=hierarchy.id, task=task, nodes=nodes,
            verification_criteria="All atomic contracts and final integration verification pass",
            created_at=hierarchy.created_at,
            planning_evidence={
                "mode": "hierarchical",
                "hierarchy": hierarchy.model_dump(),
                "cost_routes": {node.id: node.model_route for node in nodes},
            },
        )

    def plan(self, task: str, hints: Optional[List[str]]=None) -> Plan:
        hints = list(hints or [])
        try:
            if not self.graph:
                from .graph import CodeGraph
                self.graph = CodeGraph(self.root)
            if not self.graph.graph.get("nodes"):
                try: self.graph.load()
                except Exception: self.graph.build()
            graph_root = self.plan_cache.graph_root(self.graph)
        except Exception:
            graph_root = "unavailable"
        key = self.plan_cache.key(
            task=task, graph_root=graph_root, compiler_version=self.compiler_version,
            policy={
                "max_parallel": self.max_parallel, "token_budget": self.token_budget,
                "completeness": self.completeness_threshold,
            }, hints=hints,
        )
        cached = self.plan_cache.get(key, Plan)
        if cached is not None:
            cached.planning_evidence = {
                **cached.planning_evidence, "plan_cache": {"hit": True, "key": key, "graph_root": graph_root},
            }
            return cached
        plan = self._plan_uncached(task, hints)
        plan.planning_evidence = {
            **plan.planning_evidence, "plan_cache": {"hit": False, "key": key, "graph_root": graph_root},
        }
        self.plan_cache.put(key, plan)
        return plan

    def _plan_uncached(self, task: str, hints: Optional[List[str]]=None) -> Plan:
        """
        VMAO DAG-Based Query Decomposition (VMAO §3.1): complex query -> DAG of sub-questions
        + VeriMAP Structured I/O per sub-question
        """
        hierarchy_compiler = HierarchicalTaskCompiler(self.root, graph=self.graph)
        complexity = hierarchy_compiler.complexity(task)
        # A long acceptance contract for one named function/command is still a
        # cohesive feature, not a program of work. Keep it in focused mode.
        from .quality import TaskContract
        root_contract = TaskContract.compile(self.root, task)
        cohesive_named_feature = bool(
            re.search(r"\b(?:add|implement|create)\s+(?:a\s+|an\s+)?(?:new\s+)?(?:cli\s+command|function|method|class)\b", task, re.IGNORECASE)
            and len(root_contract.targets) <= 3
            and complexity.get("explicit_lists", 0) < 3
        )
        integration_branch = "integration"
        for hint in hints or []:
            if isinstance(hint, str) and hint.startswith("integration_branch="):
                integration_branch = hint.split("=", 1)[1] or integration_branch
        if complexity["broad"] and not cohesive_named_feature:
            return self._hierarchical_plan(task, hierarchy_compiler, integration_branch=integration_branch)

        # Graph-aware planning is a retrieval stage with explicit evidence.  A
        # full natural-language task is usually a poor code-search query, so we
        # search both the task and salient identifiers/capability nouns.
        graph_hits: List[Dict[str, Any]] = []
        graph_queries: List[str] = []
        graph_error: Optional[str] = None
        try:
            from .graph import CodeGraph
            graph = self.graph or CodeGraph(self.root)
            if not graph.graph.get("nodes"):
                try:
                    graph.load()
                except Exception:
                    graph.build()
            quoted = re.findall(r"[`\"]([A-Za-z_][\w.\-/]*)[`\"]", task)
            words = re.findall(r"[A-Za-z_][A-Za-z0-9_]{2,}", task.lower())
            stop = {"add", "new", "that", "with", "runs", "all", "uses", "into", "from", "this", "agent", "command", "task", "tests"}
            salient = [word for word in words if word not in stop]
            graph_queries = list(dict.fromkeys([*quoted, *salient[:8], task[:160]]))
            seen: set[str] = set()
            for query in graph_queries:
                try:
                    hits = graph.ranger_search(query, limit=5)
                except Exception:
                    hits = graph.search(query, limit=5)
                for hit in hits:
                    node_id = hit.get("id")
                    if node_id and node_id not in seen:
                        graph_hits.append(hit)
                        seen.add(node_id)
                if len(graph_hits) >= 12:
                    break
        except Exception as exc:
            graph_error = str(exc)
        graph_files = list(dict.fromkeys(h.get("file", "") for h in graph_hits if h.get("file")))
        graph_context = ", ".join(graph_files[:6])
        task_l = task.lower()
        nodes: List[DAGNode] = []
        # Graph-aware: if task mentions harness capabilities (audit, branch, verify, graph, sandbox), use harness-specific plan
        is_harness_task = any(k in task_l for k in ["audit", "harness", "chimera", "capability", "ltl", "wal"])
        if is_harness_task:
            # Hard harness task: add audit command — uses all capabilities (branch/graph/verify/sandbox/evolution)
            nodes = [
                DAGNode(id="sq_001", question=f"Locate relevant files via code graph for: {task[:60]} (graph hits: {graph_context})", agent_type="explorer", dependencies=[], verification_criteria="Answer cites graph query results and lists 2+ affected files with paths", priority=10,
                        inputs={"codebase": "graph", "graph_hits": graph_context}, outputs={"relevant_files": "list[File]"},
                        vf_python='def vf(output): return "graph_hits" in output or "file" in str(output.get("answer","")).lower()',
                        vf_nl="Answer cites graph query results"),
                DAGNode(id="sq_002", question=f"Implement feature: {task} — ensure typed effects {{fs,net}} and write to allowed paths only", agent_type="coder", dependencies=["sq_001"], verification_criteria="Diff shows only allowed paths edited and tests pass, effect row declared", priority=9,
                        inputs={"relevant_files": "from sq_001"}, outputs={"diff": "Patch"},
                        vf_python='def vf(output): return output.get("test_status")==0 and "diff" in output',
                        vf_nl="Diff shows only allowed paths edited and tests pass"),
                DAGNode(id="sq_003", question="Verify via sandbox tests + LTL proof G(!writeOutsideAllow) and Etas HIR", agent_type="verifier", dependencies=["sq_002"], verification_criteria="Verification contract passes with completeness >=0.95 and LTL proof present and Etas spec conformance", priority=8,
                        inputs={"diff": "from sq_002"}, outputs={"verification": "VerificationResult"},
                        vf_python='def vf(output): return output.get("test_status")==0',
                        vf_nl="Verification contract passes"),
            ]
        elif any(k in task_l for k in ["auth", "blast radius"]):
            # VeriMAP Structured/Named I/O + Python VFs per subtask (Figure 1)
            nodes = [
                DAGNode(id="sq_001", question="Identify blast radius via code graph (MATCH functions calling auth)", agent_type="explorer", dependencies=[], verification_criteria="Answer cites graph query results and lists 2+ affected files", priority=10,
                        inputs={"codebase": "graph"}, outputs={"blast_radius": "list[File]", "sources": "list[URL]"},
                        vf_python='def vf(output): return "graph_hits" in output and output["answer"].count("http")>=2',
                        vf_nl="Answer cites graph query results and lists 2+ affected files with URLs"),
                DAGNode(id="sq_002", question="Implement fix and ensure file writes are within allowed fs capabilities", agent_type="coder", dependencies=["sq_001"], verification_criteria="Diff shows only allowed paths edited and tests pass", priority=9,
                        inputs={"blast_radius": "from sq_001"}, outputs={"diff": "Patch", "test_result": "pass/fail"},
                        vf_python='def vf(output): return output.get("test_status")==0 and "diff" in output',
                        vf_nl="Diff shows only allowed paths edited and tests pass"),
                DAGNode(id="sq_003", question="Verify fix via tests + LTL proof G(!writeOutsideAllow)", agent_type="verifier", dependencies=["sq_002"], verification_criteria="Verification contract passes with completeness >=0.95 and LTL proof present", priority=8,
                        inputs={"diff": "from sq_002"}, outputs={"verification": "VerificationResult"},
                        vf_python='def vf(output): return output.get("test_status")==0',
                        vf_nl="Verification contract passes with completeness >=0.95 and LTL proof present"),
            ]
        else:
            # Generic decomposition: split by ';' or ' and ' or numbered list, but not by '.' inside IPs/numbers (to avoid splitting 169.254.169.254)
            # Use ';' and ' and ' only, not '.' for hard tasks with IPs
            if re.search(r"\d+\.\d+\.\d+\.\d+", task):
                # Contains IP, split only by ';' and ' and ', not '.'
                parts = re.split(r"[;]|\band\b", task)
            else:
                parts = re.split(r"[.;]|\band\b", task)
            parts = [p.strip() for p in parts if len(p.strip())>10][:5]
            if len(parts) <=1:
                nodes = [DAGNode(id="sq_001", question=task, agent_type="general", dependencies=[], verification_criteria="Answer addresses task directly with evidence", priority=5)]
            else:
                explicitly_sequential = bool(re.search(r"\b(?:then|after|before|finally|subsequently)\b", task, re.I))
                for i, part in enumerate(parts):
                    # Conjunction is not causality. Independent clauses fan out;
                    # explicit temporal language retains the chain.
                    deps = [f"sq_{i:03d}"] if i > 0 and explicitly_sequential else []
                    nodes.append(DAGNode(id=f"sq_{i+1:03d}", question=part, agent_type="general", dependencies=deps, verification_criteria="Sub-answer provides evidence and cites sources if applicable", priority=5-i))
        # Add synthesis node if >1.  Source URLs are not mandatory for local
        # coding tasks; repository paths, test logs, and hashes are stronger
        # evidence in that setting.
        if len(nodes) > 1:
            nodes.append(DAGNode(
                id="sq_syn",
                question="Synthesize sub-results into a final report with repository paths, test evidence, and diff hash",
                agent_type="synthesizer",
                dependencies=[n.id for n in nodes if n.id != "sq_syn"],
                verification_criteria="Synthesis includes repository paths, test status, and a diff/proof artifact",
                priority=1,
            ))
        for node in nodes:
            phase = "validation" if node.agent_type in {"verifier", "synthesizer"} else "planner" if node.agent_type == "explorer" else "evolver"
            node.model_route = self.cost_governor.route(phase)
        return Plan(
            id=f"plan-{int(time.time())}", task=task, nodes=nodes,
            created_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            planning_evidence={
                "graph_queries": graph_queries,
                "graph_hits": [
                    {"id": hit.get("id"), "file": hit.get("file"), "kind": hit.get("kind")}
                    for hit in graph_hits[:12]
                ],
                "graph_error": graph_error,
                "cost_routes": {node.id: node.model_route for node in nodes},
            },
        )

    def execution_order(self, plan: Plan) -> List[List[DAGNode]]:
        batches, evidence = self.historical_scheduler.execution_order(plan.nodes)
        self._last_schedule_evidence = evidence
        return batches

    def execute(self, plan: Plan, solver: Callable[[DAGNode], Dict[str,Any]], trace_sink: Optional[List[Dict]]=None,
                *, checkpoint_key: str | None = None, checkpoint_scope: str | None = None,
                checkpoint_resume_identity: str | None = None, resume: bool = False) -> Dict:
        """Execute a dependency DAG without level barriers.

        A child is dispatched as soon as its own dependencies finish; it does
        not wait for unrelated stragglers in the same topological level. One
        executor is reused for the run, retries retain dependency gating, and
        historical critical-path estimates order the ready queue.
        """
        trace_sink = trace_sink if trace_sink is not None else []
        planned_batches = self.execution_order(plan)  # validates acyclicity and records CPM evidence
        by_id = {node.id: node for node in plan.nodes}
        # Freeze the exact work inventory before any checkpoint re-use or
        # concurrent dispatch.  This is observability/provenance only: it never
        # changes the verifier, task-slice, or CAS merge authority.
        plan_identity = self.checkpoints.plan_identity(plan)
        coverage = DAGCoverageBuilder(
            plan_id=plan.id,
            plan_identity=plan_identity,
            checkpoint_key_hash=self.checkpoints._key(checkpoint_key) if checkpoint_key else None,
            checkpoint_scope_identity=self.checkpoints.scope_identity(checkpoint_scope),
        )
        for node in plan.nodes:
            coverage.register_selected(node)
        coverage.seal_selected()

        if resume and checkpoint_key and checkpoint_scope is not None:
            self.checkpoints.assert_scope_compatible(checkpoint_key, plan, scope=checkpoint_scope)
        if resume and checkpoint_key and checkpoint_resume_identity is not None:
            self.checkpoints.assert_resume_identity_compatible(
                checkpoint_key, plan, resume_identity=checkpoint_resume_identity,
            )
        restored = (
            self.checkpoints.restore(
                checkpoint_key, plan, scope=checkpoint_scope,
                resume_identity=checkpoint_resume_identity,
            )
            if (resume and checkpoint_key) else {}
        )
        # A malformed checkpoint must not manufacture a result for a node the
        # current plan did not select.  Valid checkpoint restore is already
        # plan-identity bound; this additional filter keeps the runtime result
        # and frozen coverage denominator aligned.
        results: Dict[str, Dict] = {node_id: value for node_id, value in restored.items() if node_id in by_id}
        restored_nodes = set(results)
        completed: set[str] = set(results)
        # ``completed`` means terminal, not verified. Keep a separate set so
        # downstream coding work never treats a failed prerequisite as usable
        # evidence merely because its worker returned.
        verified_passed: set[str] = {
            node_id for node_id, value in results.items()
            if isinstance(value, Mapping) and isinstance(value.get("verification"), Mapping)
            and value["verification"].get("status") == "pass"
        }
        for node_id in completed:
            by_id[node_id].status = "complete"
            coverage.mark_reused(node_id)
        unscheduled: set[str] = set(by_id) - completed
        blocked_nodes: dict[str, tuple[str, ...]] = {}
        provisional: Dict[str, Dict] = {}
        retried: set[str] = set()
        all_traces: List[Dict[str, Any]] = [
            trace for value in results.values() for trace in value.get("trace", [])
            if isinstance(trace, dict)
        ]
        trace_sink.extend(all_traces)
        total_tokens = 0
        for value in results.values():
            try:
                total_tokens += max(0, int(value.get("tokens", 0) or 0))
            except (TypeError, ValueError):
                pass
        start = time.monotonic()
        dispatch_waves = 0
        from .admission_control import AdmissionController, WorkItem
        admission = AdmissionController(
            max_active=self.max_parallel,
            # The default admits the finite plan inventory. A restrictive
            # pending capacity is opt-in and produces explicit terminal
            # deferral receipts rather than silently losing work.
            max_pending=(len(by_id) if self.admission_max_pending is None else self.admission_max_pending),
        )
        ready_since: Dict[str, float] = {}
        admission_events: list[dict[str, Any]] = []

        def propagate(node: DAGNode) -> None:
            for dep_id in node.dependencies:
                if dep_id not in results:
                    continue
                dep_art = results[dep_id].get("artifacts", {})
                if not isinstance(dep_art, dict):
                    continue
                for key, value in dep_art.items():
                    if key not in node.inputs and key in {"answer", "diff"}:
                        continue
                    try:
                        rendered = json.dumps(value, sort_keys=True, default=str) if not isinstance(value, str) else value
                    except Exception:
                        rendered = str(value)
                    if len(rendered) < 500:
                        node.inputs[key] = value
                    else:
                        ref = self.artifacts.put(
                            rendered,
                            media_type="application/json" if not isinstance(value, str) else "text/plain",
                            provenance={"plan": plan.id, "dependency": dep_id, "field": key},
                        )
                        node.inputs[key] = {
                            "artifact_ref": ref.digest, "chars": len(rendered), "preview": rendered[:240],
                        }
                if "answer" in dep_art:
                    answer = str(dep_art["answer"])
                    if len(answer) <= 300:
                        node.inputs[f"from_{dep_id}"] = answer
                    else:
                        ref = self.artifacts.put(
                            answer, media_type="text/plain",
                            provenance={"plan": plan.id, "dependency": dep_id, "field": "answer"},
                        )
                        node.inputs[f"from_{dep_id}"] = {
                            "artifact_ref": ref.digest, "chars": len(answer), "preview": answer[:240],
                        }

        def verify_result(node: DAGNode, value: Any) -> Dict[str, Any]:
            if not isinstance(value, dict):
                value = {"artifacts": {"answer": str(value)}, "trace": [], "tokens": 0}
            if not isinstance(value.get("artifacts"), dict):
                value["artifacts"] = {"answer": str(value.get("artifacts"))}
            traces = value.get("trace", []) if isinstance(value.get("trace"), list) else []
            all_traces.extend(traces)
            trace_sink.extend(traces)
            slice_violations: tuple[str, ...] = ()
            raw_slice = node.inputs.get("task_slice")
            if isinstance(raw_slice, dict):
                try:
                    task_slice = TaskSlice.model_validate(raw_slice)
                    artifacts = value["artifacts"]
                    operations = artifacts.get("ops", [])
                    if not isinstance(operations, list) and isinstance(artifacts.get("diff"), dict):
                        operations = artifacts["diff"].get("ops", [])
                    paths = [str(item.get("path")) for item in operations if isinstance(item, dict) and item.get("path")]
                    slice_violations = task_slice.violations(paths)
                    if slice_violations:
                        artifacts["task_slice_violation"] = {
                            "owned_paths": list(task_slice.owned_paths), "paths": list(slice_violations),
                            "contract_hash": task_slice.contract_hash,
                        }
                        traces.append({"kind": "task_slice_violation", "data": artifacts["task_slice_violation"]})
                except Exception as exc:
                    slice_violations = (f"invalid task slice: {type(exc).__name__}",)
            try:
                verification = self.verifier.verify(
                    node.id, node.verification_criteria, value.get("artifacts", {}), traces,
                )
                value["verification"] = verification.model_dump()
                if slice_violations:
                    value["verification"] = {
                        "status": "fail", "completeness": 0.0,
                        "missing": [f"task slice ownership violation: {path}" for path in slice_violations],
                        "recommendation": "escalate",
                    }
                    node.status = "failed"
                else:
                    node.status = "complete" if verification.status == "pass" else (
                        "partial" if verification.status in {"partial", "incomplete"} else "failed"
                    )
            except Exception as exc:
                value["verification"] = {
                    "status": "fail", "completeness": 0,
                    "missing": [str(exc)], "recommendation": "escalate",
                }
                node.status = "failed"
            return value

        def record_coverage_outcome(node: DAGNode, value: Mapping[str, Any]) -> None:
            """Close one selected node with a verifier-observed outcome.

            The model's answer is never sufficient for completion: only the
            deterministic verifier status can put a node in ``completed``.
            """
            verification = value.get("verification", {}) if isinstance(value, Mapping) else {}
            status = verification.get("status") if isinstance(verification, Mapping) else None
            if status == "pass":
                coverage.mark_completed(node.id)
                return
            if value.get("error"):
                coverage.mark_failed(node.id, CoverageFailureClass.EXECUTION, value.get("error"))
                return
            missing = verification.get("missing", []) if isinstance(verification, Mapping) else []
            if isinstance(missing, list) and missing:
                reason = "; ".join(str(item) for item in missing[:4])
            else:
                reason = f"verification status was {status or 'missing'}"
            coverage.mark_failed(node.id, CoverageFailureClass.VERIFICATION, reason)

        def mutation_capable(node: DAGNode) -> bool:
            """Whether dispatching this node could mutate a candidate branch.

            Generic/explorer/verifier/synthesis nodes receive a read-only
            solver surface in the current runtime. Coder/evolver nodes and any
            node declaring a write-like effect must not run on failed evidence.
            """
            if node.agent_type in {"explorer", "verifier", "synthesizer", "reviewer", "reporter", "general"}:
                return False
            effects = node.effect if isinstance(node.effect, Mapping) else {}
            rendered = json.dumps(effects, sort_keys=True, default=str).lower()
            return node.agent_type in {"coder", "evolver", "implementation"} or any(
                token in rendered for token in ("write", "edit", "patch", "commit", "merge", "delete")
            )

        def block_failed_dependencies() -> None:
            """Terminally block mutation nodes whose prerequisite did not pass."""
            for node_id in sorted(tuple(unscheduled)):
                node = by_id[node_id]
                failed = tuple(sorted(dep for dep in node.dependencies if dep in completed and dep not in verified_passed))
                if not failed or not mutation_capable(node):
                    continue
                unscheduled.remove(node_id)
                blocked_nodes[node_id] = failed
                node.status = "blocked"
                value = {
                    "status": "blocked",
                    "artifacts": {"dependency_blocked": {"dependencies": list(failed)}},
                    "trace": [{"kind": "dependency_blocked", "data": {"node": node_id, "dependencies": list(failed)}}],
                    "tokens": 0,
                    "verification": {
                        "status": "fail", "completeness": 0.0,
                        "missing": [f"dependency did not verify: {dependency}" for dependency in failed],
                        "recommendation": "escalate",
                    },
                }
                results[node_id] = value
                coverage.mark_failed(node_id, CoverageFailureClass.DEPENDENCY, "failed prerequisite verification")
                all_traces.extend(value["trace"])
                trace_sink.extend(value["trace"])
                completed.add(node_id)

        running: Dict[concurrent.futures.Future, tuple[DAGNode, bool, int]] = {}
        pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=self.max_parallel, thread_name_prefix="chimera-dag",
        )
        try:
            while unscheduled or running:
                # Resolve dependency barriers before creating the ready set.
                # Read-only reporting nodes may still run with partial evidence;
                # mutation-capable nodes are made terminally blocked.
                block_failed_dependencies()
                elapsed = time.monotonic() - start
                reserved = sum(item[2] for item in running.values())
                ready = [
                    by_id[node_id] for node_id in unscheduled
                    if set(by_id[node_id].dependencies) <= completed
                ]
                ready_now = time.monotonic()
                for node in ready:
                    ready_since.setdefault(node.id, ready_now)
                def effective_priority(node: DAGNode) -> int:
                    return node.priority + int((ready_now - ready_since[node.id]) // admission.aging)

                if self._last_schedule_evidence is not None and self._last_schedule_evidence.active:
                    ready.sort(key=lambda node: (
                        -self._last_schedule_evidence.remaining_ms[node.id], -effective_priority(node), node.id,
                    ))
                else:
                    ready.sort(key=lambda node: (-effective_priority(node), node.id))

                launched = 0
                while ready and len(running) < self.max_parallel and elapsed <= self.agent_timeout:
                    node = ready.pop(0)
                    now = time.monotonic()
                    entered = ready_since.setdefault(node.id, now)
                    decision = admission.decide(
                        WorkItem(
                            id=node.id, priority=node.priority, created_at=entered,
                            queue_budget_seconds=(self.queue_budget_seconds if self.queue_budget_seconds is not None else float("inf")),
                        ),
                        active=len(running), pending=max(0, len(unscheduled) - 1), now=now,
                    )
                    wait_ms = round((now - entered) * 1000, 3)
                    admission_event = {
                        "kind": "admission", "data": {
                            "node": node.id, "allowed": decision.allowed, "reason": decision.reason,
                            "effective_priority": decision.effective_priority,
                            "queue_wait_ms": wait_ms, "active": len(running),
                            "pending": max(0, len(unscheduled) - 1),
                        },
                    }
                    admission_events.append(admission_event)
                    all_traces.append(admission_event)
                    trace_sink.append(admission_event)
                    if not decision.allowed:
                        if decision.reason == "queue_budget_expired":
                            # No disappearance under pressure: make the
                            # deferral a typed terminal result and coverage
                            # failure rather than an implicit queue eviction.
                            unscheduled.remove(node.id)
                            node.status = "deferred"
                            value = {
                                "status": "deferred", "artifacts": {"admission": admission_event["data"]},
                                "trace": [admission_event], "tokens": 0,
                                "verification": {
                                    "status": "fail", "completeness": 0.0,
                                    "missing": ["queue budget expired before dispatch"], "recommendation": "escalate",
                                },
                            }
                            results[node.id] = value
                            coverage.mark_failed(node.id, CoverageFailureClass.BUDGET, "queue budget expired before dispatch")
                            completed.add(node.id)
                            continue
                        # A finite caller-configured pending limit applies
                        # backpressure. Keep the work visible and queued; it is
                        # reconsidered after a running node completes.
                        break
                    reservation = min(max(1, int(node.token_budget)), self.token_budget)
                    if total_tokens + reserved + reservation > self.token_budget and running:
                        break
                    if total_tokens >= self.token_budget:
                        break
                    propagate(node)
                    node.status = "running"
                    unscheduled.remove(node.id)
                    future = pool.submit(self._run_node, node, solver)
                    running[future] = (node, False, reservation)
                    reserved += reservation
                    launched += 1
                if launched:
                    dispatch_waves += 1

                if not running:
                    if unscheduled:
                        reason = "token budget exhausted" if total_tokens >= self.token_budget else (
                            "global timeout" if elapsed > self.agent_timeout else "dependency deadlock"
                        )
                        failure_class = (
                            CoverageFailureClass.BUDGET if reason == "token budget exhausted" else
                            CoverageFailureClass.TIMEOUT if reason == "global timeout" else
                            CoverageFailureClass.DEPENDENCY
                        )
                        for node_id in sorted(unscheduled):
                            by_id[node_id].status = "failed"
                            coverage.mark_failed(node_id, failure_class, reason)
                            all_traces.append({"kind": "not_dispatched", "data": {"node": node_id, "reason": reason}})
                        unscheduled.clear()
                    break

                wait_seconds = max(0.01, self.agent_timeout - elapsed)
                done, _ = concurrent.futures.wait(
                    running, timeout=wait_seconds,
                    return_when=concurrent.futures.FIRST_COMPLETED,
                )
                if not done:
                    # Solvers carry their own provider/process timeouts. Stop new
                    # dispatch and drain to avoid returning while workers mutate.
                    # Record every node we deliberately did not start; dropping
                    # it here would let a timeout masquerade as complete work.
                    for node_id in sorted(unscheduled):
                        by_id[node_id].status = "failed"
                        coverage.mark_failed(node_id, CoverageFailureClass.TIMEOUT, "global timeout before dispatch")
                        all_traces.append({"kind": "not_dispatched", "data": {"node": node_id, "reason": "global timeout"}})
                    unscheduled.clear()
                    done, _ = concurrent.futures.wait(running)
                for future in done:
                    node, is_retry, _reservation = running.pop(future)
                    try:
                        value = future.result()
                    except Exception as exc:
                        value = {"status": "failed", "error": str(exc), "artifacts": {}, "trace": []}
                    value = verify_result(node, value)
                    try:
                        total_tokens += max(0, int(value.get("tokens", 0)))
                    except (TypeError, ValueError):
                        pass

                    if is_retry:
                        old = provisional.pop(node.id)
                        old_score = float(old.get("verification", {}).get("completeness", 0))
                        new_score = float(value.get("verification", {}).get("completeness", 0))
                        results[node.id] = value if new_score > old_score else old
                        node.status = "complete" if results[node.id].get("verification", {}).get("status") == "pass" else node.status
                        record_coverage_outcome(node, results[node.id])
                        if results[node.id].get("verification", {}).get("status") == "pass":
                            verified_passed.add(node.id)
                        if checkpoint_key and results[node.id].get("verification", {}).get("status") == "pass":
                            self.checkpoints.record(
                                checkpoint_key, plan, node.id, results[node.id], scope=checkpoint_scope,
                                resume_identity=checkpoint_resume_identity,
                            )
                        completed.add(node.id)
                        continue

                    should_retry = (
                        value.get("verification", {}).get("recommendation") == "retry"
                        and not value.get("artifacts", {}).get("quality_evidence")
                        and node.id not in retried
                        and total_tokens < self.token_budget * 0.9
                    )
                    if should_retry:
                        retried.add(node.id)
                        provisional[node.id] = value
                        reservation = min(max(1, int(node.token_budget)), self.token_budget)
                        running[pool.submit(self._run_node, node, solver)] = (node, True, reservation)
                    else:
                        results[node.id] = value
                        record_coverage_outcome(node, value)
                        if value.get("verification", {}).get("status") == "pass":
                            verified_passed.add(node.id)
                        if checkpoint_key and value.get("verification", {}).get("status") == "pass":
                            self.checkpoints.record(
                                checkpoint_key, plan, node.id, value, scope=checkpoint_scope,
                                resume_identity=checkpoint_resume_identity,
                            )
                        completed.add(node.id)
        finally:
            pool.shutdown(wait=True, cancel_futures=True)

        synthesized = self._synthesize(plan, results)
        plan_with_artifacts = plan.model_dump()
        for node in plan_with_artifacts.get("nodes", []):
            if node["id"] in results:
                node["artifacts"] = results[node["id"]].get("artifacts", {})
        overall = self.verifier.verify_plan(plan_with_artifacts, all_traces)
        if plan.planning_evidence.get("mode") == "hierarchical":
            non_passing = [item for item in overall.get("results", []) if item.get("status") != "pass"]
            if non_passing:
                overall["status"] = "partial" if any(item.get("completeness", 0) >= 0.5 for item in non_passing) else "fail"
                overall["recommendation"] = "retry" if overall["status"] == "partial" else "escalate"
                overall["hierarchical_gate"] = {
                    "all_atoms_pass": False,
                    "non_passing": [item.get("subtask") for item in non_passing],
                }
            else:
                overall["status"] = "pass"
                overall["recommendation"] = "accept"
                overall["hierarchical_gate"] = {"all_atoms_pass": True, "non_passing": []}
        if overall.get("completeness", 0) < 0.5:
            overall["recommendation"] = "escalate"

        # Persist a finished, redacted execution receipt in CAS.  The returned
        # object remains convenient for callers, while the reference provides a
        # durable, exact record for later audit/resume diagnostics.
        coverage_manifest = coverage.finalize(elapsed_ms=(time.monotonic() - start) * 1000)
        coverage_payload = coverage_manifest.as_dict()
        coverage_artifact = self.artifacts.put(
            persisted_manifest_payload(coverage_manifest),
            media_type="application/vnd.chimera.dag-coverage+json",
            provenance={"kind": "dag-execution-coverage", "plan_id": plan.id, "plan_identity": plan_identity},
        )
        coverage_payload["evidence_ref"] = "artifact:" + coverage_artifact.digest

        return {
            "plan_id": plan.id,
            "status": overall["status"],
            "completeness": overall["completeness"],
            "results": results,
            "synthesized": synthesized,
            "traces": all_traces,
            "total_tokens": total_tokens,
            "verification": overall,
            "batches": len(planned_batches),
            "dispatch_waves": dispatch_waves,
            "checkpoint": {
                "enabled": bool(checkpoint_key),
                "run_key_hash": self.checkpoints._key(checkpoint_key) if checkpoint_key else None,
                "scope_identity": self.checkpoints.scope_identity(checkpoint_scope),
                "resume_identity": self.checkpoints.normalize_resume_identity(checkpoint_resume_identity),
                "resumed_nodes": sorted(restored_nodes),
            },
            "coverage": coverage_payload,
            "dependency_barrier": {
                "blocked_nodes": {node_id: list(dependencies) for node_id, dependencies in sorted(blocked_nodes.items())},
                "verified_passed": sorted(verified_passed),
            },
            "scheduler": "dependency-streaming",
            "admission": {
                "mode": "local-dag-launch",
                "max_active": self.max_parallel,
                "max_pending": self.admission_max_pending,
                "queue_budget_seconds": self.queue_budget_seconds,
                "launch_decisions": len(admission_events),
                "deferred": sorted(
                    event["data"]["node"] for event in admission_events
                    if not event["data"].get("allowed") and event["data"].get("reason") == "queue_budget_expired"
                ),
            },
            "schedule": (
                {
                    "active": self._last_schedule_evidence.active,
                    "reason": self._last_schedule_evidence.reason,
                    "critical_path": list(self._last_schedule_evidence.critical_path),
                    "critical_length_ms": self._last_schedule_evidence.critical_length_ms,
                    "remaining_ms": self._last_schedule_evidence.remaining_ms,
                    "samples": self._last_schedule_evidence.samples,
                }
                if self._last_schedule_evidence is not None else None
            ),
        }

    def _run_node(self, node: DAGNode, solver: Callable) -> Dict:
        started = time.perf_counter()
        trace_entry = {"kind": "node_start", "data": {"node": node.id, "question": node.question}, "ts": time.time()}
        try:
            out = solver(node)
            # Anti-fragile: handle solver returning None, non-dict, malformed artifacts/trace/tokens
            if out is None:
                out = {"artifacts": {"answer": ""}, "trace": [trace_entry], "tokens": 0, "error": "solver returned None"}
            if not isinstance(out, dict):
                out = {"answer": str(out), "artifacts": {"answer": str(out)}, "trace": [trace_entry], "tokens": len(str(out))//4}
            # Normalize artifacts: must be dict
            if not isinstance(out.get("artifacts"), dict):
                out["artifacts"] = {"answer": str(out.get("artifacts", ""))}
            # Normalize trace: must be list of dicts
            tr = out.get("trace")
            if not isinstance(tr, list):
                tr = [trace_entry] if isinstance(tr, str) else [trace_entry]
                # Filter only dict entries
                tr = [x for x in tr if isinstance(x, dict)]
                if not tr: tr = [trace_entry]
                out["trace"] = tr
            else:
                # Ensure at least trace_entry
                if trace_entry not in tr:
                    out.setdefault("trace", [trace_entry])
            out.setdefault("artifacts", {"answer": out.get("answer","")})
            # Normalize tokens: must be int
            tok = out.get("tokens", 0)
            try:
                out["tokens"] = int(tok) if isinstance(tok, (int,float,str)) and str(tok).isdigit() else len(json.dumps(out.get("artifacts", {})))//4
            except:
                out["tokens"] = len(json.dumps(out.get("artifacts", {})))//4
            if "trace" in out and isinstance(out["trace"], list):
                # Ensure trace ends with node_end
                if not any(x.get("kind")=="node_end" for x in out["trace"] if isinstance(x, dict)):
                    out["trace"].append({"kind": "node_end", "data": {"node": node.id, "status": "ok"}, "ts": time.time()})
            self.latency_ledger.record(
                agent_type=node.agent_type, question=node.question,
                duration_ms=(time.perf_counter() - started) * 1000,
                success=not bool(out.get("error")) and out.get("status") != "failed",
            )
            return out
        except Exception as e:
            # Never crash harness on agent failure — bulkhead contains
            self.latency_ledger.record(
                agent_type=node.agent_type, question=node.question,
                duration_ms=(time.perf_counter() - started) * 1000,
                success=False,
            )
            return {"artifacts": {}, "trace": [trace_entry, {"kind":"error","data":str(e)}], "tokens": 0, "error": str(e), "status": "failed"}

    def _synthesize(self, plan: Plan, results: Dict[str, Dict]) -> str:
        parts=[]
        for node in plan.nodes:
            if node.id in results and not node.id.startswith("sq_syn"):
                ans = results[node.id].get("artifacts",{}).get("answer") or results[node.id].get("answer","")
                if ans:
                    parts.append(f"## {node.id}: {node.question}\n{ans}")
        return "\n\n".join(parts) if parts else "No synthesis (all nodes failed or pending)"
