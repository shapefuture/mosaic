"""Local outbox/inbox ledger for effect intent, receipt correlation, and unknown outcomes.

The ledger records durable intent before an external effect is attempted. It
never promises exactly-once delivery; non-idempotent timeout/transport loss is
explicitly ``unknown`` and may not be automatically retried.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import StrEnum
import hashlib
import json
import pathlib
import time
import uuid
from typing import Any, Callable, Mapping

from .wal import WAL


class EffectOutcome(StrEnum):
    PENDING = "pending"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    UNKNOWN = "unknown"
    CANCELLED = "cancelled"


@dataclass(frozen=True)
class EffectIntent:
    id: str
    idempotency_key: str
    effect_kind: str
    payload_hash: str
    idempotent: bool
    state: str
    created_at: float

    def as_dict(self) -> dict: return asdict(self)


class OutboxInboxLedger:
    def __init__(self, root: pathlib.Path) -> None:
        self.wal = WAL(pathlib.Path(root))

    @staticmethod
    def _hash(value: Any) -> str:
        return "sha256:" + hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()

    def enqueue(self, *, effect_kind: str, payload: Mapping[str, Any], idempotent: bool, idempotency_key: str | None = None) -> EffectIntent:
        key = idempotency_key or "effect:" + uuid.uuid4().hex
        intent = EffectIntent("outbox:" + uuid.uuid4().hex, key, str(effect_kind), self._hash(dict(payload)), bool(idempotent), EffectOutcome.PENDING.value, time.time())
        self.wal.append("effect_outbox", {"event": "enqueued", **intent.as_dict()})
        return intent

    def receipt(self, intent: EffectIntent, *, outcome: EffectOutcome, detail: str = "") -> None:
        if outcome is EffectOutcome.PENDING:
            raise ValueError("receipt must be terminal")
        self.wal.append("effect_outbox", {"event": "receipt", "intent_id": intent.id, "idempotency_key": intent.idempotency_key, "outcome": outcome.value, "detail_hash": self._hash(detail)})

    def inbox(self, *, idempotency_key: str, outcome: EffectOutcome, detail: str = "") -> bool:
        """Return false for duplicate async confirmations with the same key."""
        prior = [entry["data"] for entry in self.wal.replay(kind="effect_inbox") if entry.get("data", {}).get("idempotency_key") == idempotency_key]
        if prior:
            self.wal.append("effect_inbox", {"event": "duplicate", "idempotency_key": idempotency_key})
            return False
        self.wal.append("effect_inbox", {"event": "receipt", "idempotency_key": idempotency_key, "outcome": outcome.value, "detail_hash": self._hash(detail)})
        return True

    @staticmethod
    def retry_allowed(intent: EffectIntent, outcome: EffectOutcome) -> bool:
        """State a capability, never schedule a retry.

        A caller may only consider retrying after it has an adapter-specific
        idempotency proof. ``UNKNOWN`` never triggers an automatic replay here;
        this method merely describes whether an idempotency key makes an
        explicit reconciliation/retry decision *eligible*.
        """
        return intent.idempotent and outcome in {EffectOutcome.FAILED, EffectOutcome.UNKNOWN}

    def cancelled(self, intent: EffectIntent, *, reason: str = "cancelled before dispatch") -> None:
        """Record a cancellation request for a not-yet-dispatched local intent.

        This cannot revoke a request already accepted by a third party. A
        cancelled/ambiguous in-flight remote operation remains a reconciliation
        problem rather than a proof that no side effect occurred.
        """
        self.receipt(intent, outcome=EffectOutcome.CANCELLED, detail=reason)

    def latest_outcome(self, intent: EffectIntent) -> EffectOutcome:
        """Derive the latest known local outcome from the append-only ledger."""
        latest = EffectOutcome.PENDING
        for entry in self.wal.replay(kind="effect_outbox"):
            data = entry.get("data", {})
            if data.get("intent_id") != intent.id:
                continue
            value = data.get("outcome")
            try:
                latest = EffectOutcome(str(value))
            except ValueError:
                continue
        return latest


class UnknownEffectOutcome(RuntimeError):
    """A side effect may have happened; automatic replay is prohibited."""


@dataclass(frozen=True)
class EffectDispatchResult:
    intent: EffectIntent
    outcome: EffectOutcome
    value: Any | None = None
    reconciliation_required: bool = False


class EffectDispatchController:
    """One-shot local dispatcher that makes cancellation/outcome ambiguity explicit.

    It has no background worker and never retries. Real adapters must supply an
    idempotency key to their endpoint separately; this controller only records
    local intent and outcome evidence around the adapter call.
    """

    def __init__(self, ledger: OutboxInboxLedger) -> None:
        self.ledger = ledger

    def dispatch(
        self,
        *,
        effect_kind: str,
        payload: Mapping[str, Any],
        idempotent: bool,
        send: Callable[[str], Any],
        idempotency_key: str | None = None,
        cancelled: bool = False,
    ) -> EffectDispatchResult:
        intent = self.ledger.enqueue(
            effect_kind=effect_kind, payload=payload, idempotent=idempotent,
            idempotency_key=idempotency_key,
        )
        if cancelled:
            self.ledger.cancelled(intent)
            return EffectDispatchResult(intent, EffectOutcome.CANCELLED, reconciliation_required=False)
        self.ledger.wal.append("effect_outbox", {
            "event": "dispatch_started", "intent_id": intent.id,
            "idempotency_key": intent.idempotency_key,
        })
        try:
            value = send(intent.idempotency_key)
        except Exception as exc:
            # A callback exception tells us only that the caller lacks a
            # receipt. It does not establish whether a remote effect occurred.
            self.ledger.receipt(intent, outcome=EffectOutcome.UNKNOWN, detail=type(exc).__name__)
            return EffectDispatchResult(intent, EffectOutcome.UNKNOWN, reconciliation_required=True)
        self.ledger.receipt(intent, outcome=EffectOutcome.SUCCEEDED)
        return EffectDispatchResult(intent, EffectOutcome.SUCCEEDED, value=value)
