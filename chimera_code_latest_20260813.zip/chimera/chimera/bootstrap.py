"""Fail-closed composition roots for local, offline, and cloud Chimera profiles."""

from __future__ import annotations

import ipaddress
import pathlib
import socket
import time
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

from pydantic import BaseModel, ConfigDict

from .application import (
    ApplicationError,
    ChimeraApplication,
    CommitBranchCommand,
    RunContext,
    RunTaskCommand,
    VerifyBranchCommand,
)
from .config import ChimeraConfig, DeploymentProfile


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ProfilePolicy(_FrozenModel):
    profile: DeploymentProfile
    offline: bool
    require_tenant: bool
    allow_remote_mcp: bool
    allow_remote_provider: bool
    require_shared_state: bool
    require_external_signing: bool


_PROFILE_POLICIES = {
    DeploymentProfile.LOCAL_OFFLINE: ProfilePolicy(
        profile=DeploymentProfile.LOCAL_OFFLINE,
        offline=True,
        require_tenant=False,
        allow_remote_mcp=False,
        allow_remote_provider=False,
        require_shared_state=False,
        require_external_signing=False,
    ),
    DeploymentProfile.LOCAL_DETERMINISTIC: ProfilePolicy(
        profile=DeploymentProfile.LOCAL_DETERMINISTIC,
        offline=False,
        require_tenant=False,
        allow_remote_mcp=False,
        allow_remote_provider=True,
        require_shared_state=False,
        require_external_signing=False,
    ),
    DeploymentProfile.DEV_EXTERNAL: ProfilePolicy(
        profile=DeploymentProfile.DEV_EXTERNAL,
        offline=False,
        require_tenant=False,
        allow_remote_mcp=True,
        allow_remote_provider=True,
        require_shared_state=False,
        require_external_signing=False,
    ),
    DeploymentProfile.SHADOW_PRODUCTION: ProfilePolicy(
        profile=DeploymentProfile.SHADOW_PRODUCTION,
        offline=False,
        require_tenant=False,
        allow_remote_mcp=True,
        allow_remote_provider=True,
        require_shared_state=True,
        require_external_signing=True,
    ),
    DeploymentProfile.SINGLE_TENANT_PRODUCTION: ProfilePolicy(
        profile=DeploymentProfile.SINGLE_TENANT_PRODUCTION,
        offline=False,
        require_tenant=False,
        allow_remote_mcp=True,
        allow_remote_provider=True,
        require_shared_state=True,
        require_external_signing=True,
    ),
    DeploymentProfile.MULTI_TENANT_PRODUCTION: ProfilePolicy(
        profile=DeploymentProfile.MULTI_TENANT_PRODUCTION,
        offline=False,
        require_tenant=True,
        allow_remote_mcp=True,
        allow_remote_provider=True,
        require_shared_state=True,
        require_external_signing=True,
    ),
    DeploymentProfile.HIGH_AUTONOMY: ProfilePolicy(
        profile=DeploymentProfile.HIGH_AUTONOMY,
        offline=False,
        require_tenant=True,
        allow_remote_mcp=True,
        allow_remote_provider=True,
        require_shared_state=True,
        require_external_signing=True,
    ),
    DeploymentProfile.REGULATED: ProfilePolicy(
        profile=DeploymentProfile.REGULATED,
        offline=False,
        require_tenant=True,
        allow_remote_mcp=True,
        allow_remote_provider=True,
        require_shared_state=True,
        require_external_signing=True,
    ),
}


class EgressDecision(_FrozenModel):
    allowed: bool
    url: str
    host: str
    reason: str


class ProfileEgressPolicy:
    """Common host-side egress gate used by providers, MCP, events, and federation."""

    def __init__(
        self,
        policy: ProfilePolicy,
        *,
        allowed_hosts: set[str] | frozenset[str] = frozenset(),
        offline_loopback_ports: set[int] | frozenset[int] = frozenset({11434}),
    ) -> None:
        self.policy = policy
        self.allowed_hosts = frozenset(
            host.lower().rstrip(".") for host in allowed_hosts
        )
        self.offline_loopback_ports = frozenset(
            int(port) for port in offline_loopback_ports
        )

    @staticmethod
    def _addresses(host: str, port: int) -> set[str]:
        try:
            return {
                str(row[4][0])
                for row in socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
            }
        except socket.gaierror as exc:
            raise ApplicationError(
                "egress_dns_failed", "egress destination cannot be resolved"
            ) from exc

    def authorize(self, url: str, *, tenant_key: str | None = None) -> EgressDecision:
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower().rstrip(".")
        if parsed.scheme not in {"http", "https"} or not host:
            raise ApplicationError(
                "egress_invalid_url", "egress requires an HTTP(S) URL"
            )
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        addresses = self._addresses(host, port)
        loopback = bool(addresses) and all(
            ipaddress.ip_address(value).is_loopback for value in addresses
        )
        if loopback and port in self.offline_loopback_ports:
            return EgressDecision(
                allowed=True,
                url=url,
                host=host,
                reason="profile explicitly permits this loopback endpoint",
            )
        if self.policy.offline:
            raise ApplicationError(
                "offline_egress_denied", "offline profile denies non-local egress"
            )
        if host not in self.allowed_hosts:
            raise ApplicationError(
                "egress_host_denied", "egress host is not explicitly allowed"
            )
        for value in addresses:
            address = ipaddress.ip_address(value)
            if (
                address.is_private
                or address.is_link_local
                or address.is_multicast
                or address.is_unspecified
            ):
                raise ApplicationError(
                    "egress_address_denied", "egress resolved to a non-public address"
                )
        return EgressDecision(
            allowed=True,
            url=url,
            host=host,
            reason="host and resolved addresses passed profile egress policy",
        )


@dataclass
class _CodeAdapter:
    graph: Any

    def query(self, query: str, *, limit: int, kind: str | None = None):
        return self.graph.search(query, limit=limit, kind=kind)


class LocalComposition:
    """Local adapter graph. Cloud profiles must use an explicit cloud composition."""

    def __init__(
        self, root: pathlib.Path, config: ChimeraConfig, *, independent_checker=None
    ):
        self.root = pathlib.Path(root).resolve()
        self.config = config
        self.independent_checker = independent_checker
        self.policy = _PROFILE_POLICIES[config.deployment_profile]
        if self.policy.require_shared_state:
            raise ApplicationError(
                "cloud_composition_required",
                f"{self.policy.profile.value} requires an explicit shared-state cloud composition",
            )
        from .artifacts import ContentAddressedArtifactStore
        from .branch import TransactionalWorkspace
        from .graph import CodeGraph
        from .graph_daemon import GraphDaemonClient
        from .rpc_server import SessionProtocol
        from .tenancy import LocalTenantQuotaPort

        self.workspace = TransactionalWorkspace(self.root)
        self.artifacts = ContentAddressedArtifactStore(self.root)
        self.quota = LocalTenantQuotaPort(self.root)
        daemon = GraphDaemonClient(self.root)
        self.graph = daemon if daemon.available else CodeGraph(self.root)
        self.sessions = SessionProtocol(self.root)
        self._harness = None

    def _harness_instance(self):
        if self._harness is None:
            from .orchestrator import ChimeraHarness

            self._harness = ChimeraHarness(self.root, config=self.config)
        return self._harness

    @staticmethod
    def _completion_context(command: RunTaskCommand) -> dict[str, Any]:
        context = command.context
        return {
            "tenant_key": context.tenant_key,
            "principal_hash": context.principal_hash,
            "run_id": context.run_id,
            "request_id": context.request_id,
            "trace_id": context.trace_id,
            "deadline_unix_ms": context.deadline_unix_ms,
            "max_input_tokens": context.max_input_tokens,
            "max_output_tokens": context.max_output_tokens,
            "max_cost_usd": context.max_cost_usd,
            "idempotency_key": context.request_id,
            "cancellation_token": context.cancellation_token,
        }

    def _run_task(self, command: RunTaskCommand) -> Mapping[str, Any]:
        if self.policy.offline and not any(
            token in command.model.lower() for token in ("mock", "ollama", "local/")
        ):
            raise ApplicationError(
                "offline_provider_denied",
                "offline profile permits only mock or explicitly local inference adapters",
            )
        harness = self._harness_instance()
        previous = getattr(
            harness.rlm_runtime._thread_local, "completion_context", None
        )
        harness.rlm_runtime._thread_local.completion_context = self._completion_context(
            command
        )
        try:
            return harness.run(
                command.task,
                branch=command.branch,
                model=command.model,
                auto_commit=command.auto_commit,
            )
        finally:
            if previous is None:
                try:
                    del harness.rlm_runtime._thread_local.completion_context
                except AttributeError:
                    pass
            else:
                harness.rlm_runtime._thread_local.completion_context = previous

    def _verify(self, command: VerifyBranchCommand) -> Mapping[str, Any]:
        from .sandbox import Sandbox

        sandbox = Sandbox(
            self.root,
            self.config.to_capability_set(),
            branch=command.branch,
            workspace=self.workspace,
        )
        timeout = max(
            1,
            min(
                3_600,
                int((command.context.deadline_unix_ms - time.time() * 1_000) / 1_000),
            ),
        )
        result = sandbox.exec(command.command, timeout=timeout)
        return {
            "status": result.status,
            "duration_ms": result.duration_ms,
            "stdout": result.stdout[-4_000:],
            "stderr": result.stderr[-4_000:],
            "evidence": dict(result.evidence),
        }

    def _commit(self, command: CommitBranchCommand) -> str:
        return self._harness_instance().commit_approved(
            command.branch,
            command.task,
            message=command.message,
        )

    def _review(self, command: RunTaskCommand, raw: Mapping[str, Any]):
        if self.independent_checker is None:
            return None
        from .checker_port import CheckerReviewLedger
        from .quality import TaskContract
        from .verification_brief import IndependentVerificationBriefBuilder

        diff_value = raw.get("diff")
        diff = (
            {str(key): value for key, value in diff_value.items()}
            if isinstance(diff_value, Mapping)
            else {}
        )
        verification_value = raw.get("verification")
        verification = (
            {str(key): value for key, value in verification_value.items()}
            if isinstance(verification_value, Mapping)
            else {}
        )
        contract = TaskContract.compile(self.root, command.task)
        builder = IndependentVerificationBriefBuilder(
            self.root, artifacts=self.artifacts
        )
        brief = builder.build(
            branch=command.branch,
            contract=contract,
            diff=diff,
            verification=verification,
            evidence_refs=tuple(
                ref
                for ref in (raw.get("evidence_refs", ()) or ())
                if isinstance(ref, str)
            ),
        )
        ref = builder.persist(brief)
        ledger = CheckerReviewLedger(self.root, artifacts=self.artifacts)
        review = ledger.run(
            self.independent_checker,
            ledger.request_for(ref.digest),
        )
        return {
            **review.model_dump(mode="json"),
            "brief_ref": ref.digest,
            "brief_hash": brief.brief_hash,
        }

    def application(self) -> ChimeraApplication:
        return ChimeraApplication(
            workspace=self.workspace,
            code=_CodeAdapter(self.graph),
            artifacts=self.artifacts,
            run_task=self._run_task,
            verify_branch=self._verify,
            commit_branch=self._commit,
            sessions=self.sessions,
            quota=self.quota,
            independent_review=self._review
            if self.independent_checker is not None
            else None,
        )


def profile_policy(profile: DeploymentProfile | str) -> ProfilePolicy:
    return _PROFILE_POLICIES[DeploymentProfile(profile)]


def new_run_context(
    *,
    profile: DeploymentProfile | str,
    deadline_seconds: float = 1_800,
    trace_id: str | None = None,
    tenant_key: str | None = None,
    principal_hash: str | None = None,
    grant_digest: str | None = None,
    max_input_tokens: int = 25_000,
    max_output_tokens: int = 4_096,
    max_cost_usd: float = 10.0,
) -> RunContext:
    policy = profile_policy(profile)
    if policy.require_tenant and not all((tenant_key, principal_hash, grant_digest)):
        raise ApplicationError(
            "tenant_context_required",
            f"{policy.profile.value} requires authenticated tenant context",
        )
    return RunContext(
        profile=policy.profile.value,
        tenant_key=tenant_key,
        principal_hash=principal_hash,
        grant_digest=grant_digest,
        run_id="run:" + uuid.uuid4().hex,
        request_id="request:" + uuid.uuid4().hex,
        trace_id=trace_id or "trace:" + uuid.uuid4().hex,
        deadline_unix_ms=int((time.time() + max(0.1, float(deadline_seconds))) * 1_000),
        max_input_tokens=max_input_tokens,
        max_output_tokens=max_output_tokens,
        max_cost_usd=max_cost_usd,
    )


def build_cloud_application(
    *,
    config: ChimeraConfig,
    workspace,
    code,
    artifacts,
    cloud_state,
    run_task,
    verify_branch,
    commit_branch,
    sessions,
    independent_review=None,
) -> ChimeraApplication:
    """Compose only explicitly supplied shared adapters for a cloud profile."""
    policy = profile_policy(config.deployment_profile)
    if not policy.require_shared_state:
        raise ApplicationError(
            "cloud_profile_required",
            "cloud composition requires a shared-state deployment profile",
        )
    required = {
        "workspace": workspace,
        "code": code,
        "artifacts": artifacts,
        "cloud_state": cloud_state,
        "run_task": run_task,
        "verify_branch": verify_branch,
        "commit_branch": commit_branch,
        "sessions": sessions,
    }
    missing = [name for name, value in required.items() if value is None]
    if missing:
        raise ApplicationError(
            "cloud_adapter_missing",
            "cloud composition is missing required adapters: " + ", ".join(missing),
        )
    return ChimeraApplication(
        workspace=workspace,
        code=code,
        artifacts=artifacts,
        run_task=run_task,
        verify_branch=verify_branch,
        commit_branch=commit_branch,
        sessions=sessions,
        quota=cloud_state,
        independent_review=independent_review,
    )


def build_local_application(
    root: pathlib.Path,
    *,
    config: ChimeraConfig | None = None,
    independent_checker=None,
) -> tuple[ChimeraApplication, LocalComposition]:
    resolved = pathlib.Path(root).resolve()
    selected = config or ChimeraConfig.load(resolved / "chimera.toml")
    composition = LocalComposition(
        resolved,
        selected,
        independent_checker=independent_checker,
    )
    return composition.application(), composition
