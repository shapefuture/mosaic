"""Transcript-minimized evidence brief for an explicitly independent reviewer.

The brief is an artifact, not a verdict.  It carries task/diff/test facts and
pointers to immutable evidence while intentionally excluding generation prose,
chain-of-thought, raw provider output, and checker authority.  A reviewer that
uses it must remain read-only and its opinion cannot promote or merge work.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
from typing import Any, Iterable, Mapping

from pydantic import BaseModel, ConfigDict, Field

from .artifacts import ArtifactRef, ContentAddressedArtifactStore
from .quality import TaskContract
from .wal import WAL


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class VerificationOperation(_FrozenModel):
    path: str
    operation: str
    bytes: int | None = Field(default=None, ge=0)
    content_hash: str | None = None


class IndependentVerificationBrief(_FrozenModel):
    schema_version: str = "chimera.independent-verification-brief.v1"
    branch: str
    task_hash: str
    contract_hash: str
    diff_id: str
    operations: tuple[VerificationOperation, ...]
    protected_paths: tuple[str, ...]
    acceptance_test_hashes: tuple[str, ...]
    required_symbols: tuple[str, ...]
    required_calls: tuple[str, ...]
    verification_facts: dict[str, Any]
    command_proof_refs: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    exclusions: tuple[str, ...] = (
        "generation_transcript",
        "provider_response_text",
        "chain_of_thought",
        "candidate_rationale",
        "checker_authority",
    )

    @property
    def brief_hash(self) -> str:
        return _hash(self.model_dump(mode="json"))

    def render(self) -> str:
        """Read-only reviewer prompt with evidence references, never candidate prose."""
        ops = "\n".join(
            f"- {item.operation} {item.path} bytes={item.bytes if item.bytes is not None else 'n/a'} hash={item.content_hash or 'n/a'}"
            for item in self.operations
        ) or "- no operations"
        return (
            "INDEPENDENT VERIFICATION BRIEF — evidence only\n"
            "You are not given the generator's rationale. Inspect the branch and referenced evidence yourself. "
            "Do not modify files, invent passing tests, or treat your opinion as merge authority.\n\n"
            f"TASK_HASH: {self.task_hash}\nCONTRACT_HASH: {self.contract_hash}\nBRANCH: {self.branch}\nDIFF_ID: {self.diff_id}\n\n"
            f"OPERATIONS:\n{ops}\n\n"
            f"PROTECTED PATHS: {list(self.protected_paths)}\n"
            f"ACCEPTANCE TEST HASHES: {list(self.acceptance_test_hashes)}\n"
            f"REQUIRED SYMBOLS: {list(self.required_symbols)}\n"
            f"REQUIRED HARNESS CALLS: {list(self.required_calls)}\n"
            f"VERIFICATION FACTS: {json.dumps(self.verification_facts, sort_keys=True, default=str)}\n"
            f"COMMAND PROOFS: {list(self.command_proof_refs)}\n"
            f"EVIDENCE REFS: {list(self.evidence_refs)}\n"
            "Return only discrepancies, missing evidence, or a scoped read-only review."
        )


class IndependentVerificationBriefBuilder:
    """Build/persist deterministic reviewer context from allowed fact channels."""

    _VERIFICATION_FACT_KEYS = {
        "status", "test_status", "protected_tests_unchanged", "changed_paths",
        "verification_status", "quality", "tests", "errors", "warnings",
        "impact_scope", "full_output_ref",
    }

    def __init__(self, root: pathlib.Path, *, artifacts: ContentAddressedArtifactStore | None = None):
        self.root = pathlib.Path(root).resolve()
        self.artifacts = artifacts or ContentAddressedArtifactStore(self.root)
        self.wal = WAL(self.root)

    @staticmethod
    def _contract_hash(contract: TaskContract) -> str:
        payload = {
            "task": contract.task,
            "tests": {path: _hash(text) for path, text in sorted(contract.tests.items())},
            "targets": [
                {"path": target.path, "mode": target.mode, "reason": target.reason}
                for target in contract.targets
            ],
            "protected_paths": sorted(contract.protected_paths),
            "required_symbols": {path: sorted(items) for path, items in sorted(contract.required_symbols.items())},
            "required_calls": {path: sorted(items) for path, items in sorted(contract.required_calls.items())},
        }
        return _hash(payload)

    @staticmethod
    def _operation(value: Mapping[str, Any]) -> VerificationOperation:
        path = str(value.get("path", ""))
        if not path or path.startswith("/") or ".." in pathlib.PurePosixPath(path).parts:
            raise ValueError("verification diff contains unsafe operation path")
        operation = str(value.get("op", ""))
        if operation not in {"write", "unlink"}:
            raise ValueError("verification brief accepts only write/unlink diff operations")
        raw_bytes = value.get("bytes")
        return VerificationOperation(
            path=path,
            operation=operation,
            bytes=int(raw_bytes) if isinstance(raw_bytes, int) and raw_bytes >= 0 else None,
            content_hash=str(value["hash"]) if isinstance(value.get("hash"), str) else None,
        )

    @staticmethod
    def _sanitize_fact(value: Any, *, depth: int = 0) -> Any:
        """Keep bounded deterministic facts; strip model/proposal narrative keys."""
        if depth > 4:
            return "<depth-truncated>"
        if isinstance(value, Mapping):
            output: dict[str, Any] = {}
            for key in sorted(value, key=str):
                name = str(key).lower()
                if any(token in name for token in ("transcript", "rationale", "chain_of_thought", "provider_response", "prompt", "completion")):
                    continue
                if len(output) >= 32:
                    output["<truncated>"] = True
                    break
                output[str(key)] = IndependentVerificationBriefBuilder._sanitize_fact(value[key], depth=depth + 1)
            return output
        if isinstance(value, (list, tuple)):
            return [IndependentVerificationBriefBuilder._sanitize_fact(item, depth=depth + 1) for item in value[:32]]
        if isinstance(value, str):
            return value[:1_000] + ("…" if len(value) > 1_000 else "")
        if value is None or isinstance(value, (bool, int, float)):
            return value
        return str(value)[:300]

    def build(
        self,
        *,
        branch: str,
        contract: TaskContract,
        diff: Mapping[str, Any],
        verification: Mapping[str, Any] | None = None,
        command_proof_refs: Iterable[str] = (),
        evidence_refs: Iterable[str] = (),
    ) -> IndependentVerificationBrief:
        if not branch:
            raise ValueError("verification brief requires a branch")
        diff_id = str(diff.get("id", ""))
        operations_raw = diff.get("ops", ())
        if (
            not diff_id.startswith("sha256:")
            or len(diff_id.removeprefix("sha256:")) != 64
            or any(char not in "0123456789abcdef" for char in diff_id.removeprefix("sha256:").lower())
            or not isinstance(operations_raw, list)
        ):
            raise ValueError("verification brief requires a hashed diff with operations")
        facts_source = verification or {}
        facts = {
            key: self._sanitize_fact(facts_source[key])
            for key in sorted(self._VERIFICATION_FACT_KEYS)
            if key in facts_source
        }
        test_hashes = tuple(
            f"{path}={_hash(text)}" for path, text in sorted(contract.tests.items())
        )
        symbols = tuple(
            f"{path}:{symbol}"
            for path, values in sorted(contract.required_symbols.items())
            for symbol in sorted(set(values))
        )
        calls = tuple(
            f"{path}:{call}"
            for path, values in sorted(contract.required_calls.items())
            for call in sorted(set(values))
        )
        return IndependentVerificationBrief(
            branch=branch,
            task_hash=_hash(contract.task),
            contract_hash=self._contract_hash(contract),
            diff_id=diff_id,
            operations=tuple(self._operation(item) for item in operations_raw),
            protected_paths=tuple(sorted(set(contract.protected_paths))),
            acceptance_test_hashes=test_hashes,
            required_symbols=symbols,
            required_calls=calls,
            verification_facts=facts,
            command_proof_refs=tuple(sorted(set(str(ref) for ref in command_proof_refs if str(ref)))),
            evidence_refs=tuple(sorted(set(str(ref) for ref in evidence_refs if str(ref)))),
        )

    def persist(self, brief: IndependentVerificationBrief) -> ArtifactRef:
        payload = brief.model_dump_json(indent=2)
        ref = self.artifacts.put(
            payload,
            media_type="application/vnd.chimera.independent-verification-brief+json",
            provenance={"brief_hash": brief.brief_hash, "branch": brief.branch, "diff_id": brief.diff_id},
        )
        self.wal.append("independent_verification_brief", {
            "brief_hash": brief.brief_hash,
            "artifact_ref": ref.digest,
            "branch": brief.branch,
            "diff_id": brief.diff_id,
            "operation_count": len(brief.operations),
        })
        return ref


def _hash(value: Any) -> str:
    if isinstance(value, str):
        raw = value.encode("utf-8")
    else:
        raw = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()
