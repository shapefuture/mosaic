"""Optional DeltaFS/reflink/overlay capability probe for future fast C/R backend."""
from __future__ import annotations
from dataclasses import dataclass, asdict
import os, pathlib, shutil, subprocess, tempfile

@dataclass(frozen=True)
class DeltaFSCapability:
    available: bool
    overlayfs: bool
    reflink: bool
    bwrap: bool
    reason: str
    def as_dict(self): return asdict(self)

class DeltaFSProbe:
    def __init__(self, root:pathlib.Path): self.root=pathlib.Path(root)
    def probe(self)->DeltaFSCapability:
        bwrap=shutil.which('bwrap') is not None
        overlay=pathlib.Path('/proc/filesystems').exists() and 'overlay' in pathlib.Path('/proc/filesystems').read_text(errors='ignore')
        reflink=False
        try:
            with tempfile.TemporaryDirectory(dir=self.root if self.root.exists() else None) as td:
                p=pathlib.Path(td); (p/'a').write_bytes(b'x'*4096)
                cp=subprocess.run(['cp','--reflink=always',str(p/'a'),str(p/'b')],capture_output=True,timeout=5)
                reflink=cp.returncode==0
        except Exception:
            reflink=False
        ok=bool(bwrap and overlay)
        reason='deltafs candidate usable' if ok else 'requires bubblewrap and overlayfs; reflink optional but preferred'
        return DeltaFSCapability(ok,overlay,reflink,bwrap,reason)
