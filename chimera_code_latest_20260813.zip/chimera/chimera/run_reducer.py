"""Deterministic shadow reducer for Chimera run lifecycle events.

The live RLM loop remains authoritative during migration.  This reducer consumes
its WAL-backed lifecycle events and builds a replayable projection, allowing
fault-injection/parity tests before any event-sourced runtime promotion.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Any, Iterable, Mapping

from .run_types import ActionState


@dataclass(frozen=True)
class ReducedAction:
    action_id: str
    kind: str
    state: str
    request_id: str


@dataclass(frozen=True)
class RunProjection:
    conversation_id: str | None
    run_id: str
    request_ids: tuple[str, ...]
    actions: tuple[ReducedAction, ...]
    terminal: str | None
    valid: bool
    errors: tuple[str, ...]
    projection_hash: str

    def as_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["actions"] = [asdict(action) for action in self.actions]
        return value


class RunEventReducer:
    _ALLOWED = {
        ActionState.PROPOSED.value: {ActionState.ACCEPTED.value, ActionState.REJECTED.value, ActionState.CANCELLED.value},
        ActionState.ACCEPTED.value: {ActionState.STARTED.value, ActionState.REJECTED.value, ActionState.CANCELLED.value},
        ActionState.STARTED.value: {ActionState.COMPLETED.value, ActionState.FAILED.value, ActionState.CANCELLED.value},
    }
    _TERMINAL = {ActionState.COMPLETED.value, ActionState.FAILED.value, ActionState.REJECTED.value, ActionState.CANCELLED.value}

    @classmethod
    def bounded_model_check(cls, *, bound: int = 8):
        """Check the declared action table, without promoting the shadow reducer.

        The report's liveness field is conditional on scheduler progress; it is
        not a claim that real provider/MCP/process actions eventually finish.
        """
        from .bounded_lifecycle import BoundedLifecycleModelChecker
        return BoundedLifecycleModelChecker(terminal=cls._TERMINAL).verify(cls._ALLOWED, bound=bound)

    @classmethod
    def reduce(cls, entries: Iterable[Mapping[str, Any]], *, run_id: str) -> RunProjection:
        conversation_id: str | None = None
        requests: list[str] = []
        actions: dict[str, ReducedAction] = {}
        terminal: str | None = None
        errors: list[str] = []
        saw_init = False
        for entry in sorted(entries, key=lambda item: int(item.get("seq", -1))):
            data = entry.get("data", {})
            if not isinstance(data, Mapping) or data.get("run_id") != run_id:
                continue
            event = data.get("event")
            if event == "stream_init":
                if saw_init:
                    errors.append("duplicate stream_init")
                saw_init = True
                conversation_id = str(data.get("conversation_id")) if data.get("conversation_id") else conversation_id
            elif event == "request_started":
                request_id = data.get("request_id")
                if not saw_init:
                    errors.append("request_started before stream_init")
                elif not isinstance(request_id, str) or not request_id:
                    errors.append("request_started missing request_id")
                elif request_id in requests:
                    errors.append(f"duplicate request_id {request_id}")
                else:
                    requests.append(request_id)
            elif event == "client_action":
                action_id, state, request_id = data.get("action_id"), data.get("state"), data.get("request_id")
                if not isinstance(action_id, str) or not isinstance(state, str) or not isinstance(request_id, str):
                    errors.append("malformed client_action")
                    continue
                if request_id not in requests:
                    errors.append(f"action {action_id} references unknown request")
                    continue
                prior = actions.get(action_id)
                if prior is None:
                    if state != ActionState.PROPOSED.value:
                        errors.append(f"action {action_id} begins at {state}")
                        continue
                elif prior.state in cls._TERMINAL:
                    errors.append(f"action {action_id} transitions after terminal state")
                    continue
                elif state not in cls._ALLOWED.get(prior.state, set()):
                    errors.append(f"invalid action transition {prior.state}->{state}")
                    continue
                actions[action_id] = ReducedAction(action_id, str(data.get("kind", "unknown")), state, request_id)
            elif event == "stream_finished":
                if terminal is not None:
                    errors.append("duplicate stream_finished")
                terminal = str(data.get("terminal")) if data.get("terminal") else None
        if not saw_init:
            errors.append("missing stream_init")
        if terminal is None:
            errors.append("missing stream_finished")
        unfinished = sorted(action.action_id for action in actions.values() if action.state not in cls._TERMINAL)
        if unfinished:
            errors.append("unterminated actions: " + ",".join(unfinished))
        action_rows = tuple(sorted(actions.values(), key=lambda action: action.action_id))
        unsigned = {
            "conversation_id": conversation_id, "run_id": run_id,
            "request_ids": requests, "actions": [asdict(action) for action in action_rows],
            "terminal": terminal, "valid": not errors, "errors": errors,
        }
        digest = "sha256:" + hashlib.sha256(json.dumps(unsigned, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        return RunProjection(
            conversation_id=conversation_id, run_id=run_id, request_ids=tuple(requests),
            actions=action_rows, terminal=terminal, valid=not errors,
            errors=tuple(errors), projection_hash=digest,
        )
