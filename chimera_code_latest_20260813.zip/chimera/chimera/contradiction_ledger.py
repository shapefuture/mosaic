"""Tiny contradiction ledger for subagent/parent merge points."""
from __future__ import annotations
from dataclasses import dataclass, asdict
import pathlib, time
from typing import Any
from .wal import WAL

TRUST={"external":0,"agent":1,"tool":2,"user":3,"policy":4}

@dataclass(frozen=True)
class Claim:
    subject:str; predicate:str; value:str; source:str; trust:str; evidence_ref:str; ts:float
    def as_dict(self): return asdict(self)

class ContradictionLedger:
    def __init__(self, root:pathlib.Path): self.wal=WAL(pathlib.Path(root))
    def record_claim(self, subject:str, predicate:str, value:str, *, source:str, trust:str="agent", evidence_ref:str="") -> dict[str,Any]:
        claim=Claim(subject,predicate,value,source,trust,evidence_ref,time.time())
        row=claim.as_dict(); self.wal.append("claim",row); return row
    def conflicts(self, subject:str|None=None, predicate:str|None=None)->list[dict[str,Any]]:
        rows=[e["data"] for e in self.wal.replay(kind="claim")]
        if subject is not None: rows=[r for r in rows if r.get("subject")==subject]
        if predicate is not None: rows=[r for r in rows if r.get("predicate")==predicate]
        groups={}
        for r in rows: groups.setdefault((r.get("subject"),r.get("predicate")),[]).append(r)
        out=[]
        for (s,p),items in groups.items():
            values={i.get("value") for i in items}
            if len(values)>1:
                preferred=max(items,key=lambda r:(TRUST.get(str(r.get("trust")),0),float(r.get("ts",0))))
                out.append({"subject":s,"predicate":p,"values":sorted(values),"preferred":preferred,"claims":items})
        return out
