"""Proof-carrying local admission certificates for ActionIR dispatch.

A model proposal is not execution authority.  This certificate binds one already
compiled ActionIR node to the policy snapshot, run/request identity, and
freshness observations that were checked immediately before dispatch.  It is a
local deterministic certificate, not a formal proof of arbitrary tool behavior.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import pathlib
import time
import uuid
from typing import Any, Mapping

from .action_ir import ActionIR, Reversibility
from .wal import WAL


@dataclass(frozen=True)
class ActionCertificate:
    id: str
    run_id: str
    request_id: str
    action_id: str
    action_digest: str
    policy_hash: str
    context_hash: str
    preconditions_hash: str
    approval_class: str
    issued_at: float
    expires_at: float

    def as_dict(self) -> dict: return asdict(self)


class ActionCertificateAuthority:
    def __init__(self, root: pathlib.Path, *, ttl_seconds: float = 60.0) -> None:
        self.wal = WAL(pathlib.Path(root)); self.ttl_seconds = max(1.0, float(ttl_seconds))

    @staticmethod
    def _hash(value: Any) -> str:
        raw = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    def issue(self, *, action: ActionIR, run_id: str, request_id: str, policy: Mapping[str, Any], context_hash: str, preconditions: Mapping[str, Any], approval_grant_id: str | None = None) -> ActionCertificate:
        if not run_id or not request_id or not context_hash:
            raise ValueError("action certificate requires run, request, and context identity")
        if action.reversibility is Reversibility.IRREVERSIBLE and not approval_grant_id:
            raise PermissionError("irreversible ActionIR dispatch requires an explicit approval grant")
        now = time.time()
        approval_class = "scoped-grant" if approval_grant_id else "deterministic-policy"
        cert = ActionCertificate(
            "certificate:" + uuid.uuid4().hex, str(run_id), str(request_id), action.action_id,
            self._hash(action.evidence()), self._hash(dict(policy)), str(context_hash), self._hash(dict(preconditions)),
            approval_class, now, now + self.ttl_seconds,
        )
        self.wal.append("action_certificate", {"event": "issued", **cert.as_dict(), "approval_grant_id": approval_grant_id})
        return cert

    def valid_for(
        self,
        cert: ActionCertificate,
        *,
        action: ActionIR,
        policy: Mapping[str, Any],
        context_hash: str,
        preconditions: Mapping[str, Any],
        run_id: str | None = None,
        request_id: str | None = None,
    ) -> bool:
        """Check every locally bound fact before an executor consumes a grant.

        ``run_id``/``request_id`` are optional for backwards-compatible unit
        callers, but executor adapters supply both so a certificate cannot be
        transplanted across a run or request merely because the ActionIR is
        identical.
        """
        if time.time() > cert.expires_at:
            return False
        if run_id is not None and cert.run_id != str(run_id):
            return False
        if request_id is not None and cert.request_id != str(request_id):
            return False
        return (
            cert.action_digest == self._hash(action.evidence())
            and cert.policy_hash == self._hash(dict(policy))
            and cert.context_hash == context_hash
            and cert.preconditions_hash == self._hash(dict(preconditions))
        )
