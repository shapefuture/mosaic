"""Small deterministic JSON Schema subset validator for tool result contracts.

The purpose is not to implement every JSON Schema keyword. It validates the
bounded shape commonly used by MCP/provider tool outputs before structured data
is reintroduced into model context. Unknown schema forms fail closed.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class SchemaViolation:
    path: str
    message: str


def validate_json_value(schema: Mapping[str, Any], value: Any, *, path: str = "$") -> tuple[SchemaViolation, ...]:
    if not isinstance(schema, Mapping):
        return (SchemaViolation(path, "schema is not an object"),)
    if "anyOf" in schema:
        candidates = schema.get("anyOf")
        if not isinstance(candidates, list) or not candidates:
            return (SchemaViolation(path, "anyOf must be a non-empty array"),)
        if any(not validate_json_value(candidate, value, path=path) for candidate in candidates if isinstance(candidate, Mapping)):
            return ()
        return (SchemaViolation(path, "value does not satisfy any anyOf branch"),)
    if "enum" in schema and value not in schema["enum"]:
        return (SchemaViolation(path, "value is not in enum"),)
    kind = schema.get("type")
    if kind == "object":
        if not isinstance(value, Mapping):
            return (SchemaViolation(path, "expected object"),)
        violations: list[SchemaViolation] = []
        required = schema.get("required", [])
        if not isinstance(required, list):
            return (SchemaViolation(path, "required must be array"),)
        for key in required:
            if not isinstance(key, str) or key not in value:
                violations.append(SchemaViolation(path, f"missing required property {key!r}"))
        properties = schema.get("properties", {})
        if not isinstance(properties, Mapping):
            return (SchemaViolation(path, "properties must be object"),)
        if schema.get("additionalProperties") is False:
            for key in value:
                if key not in properties:
                    violations.append(SchemaViolation(path, f"unexpected property {key!r}"))
        for key, child in properties.items():
            if key in value and isinstance(child, Mapping):
                violations.extend(validate_json_value(child, value[key], path=f"{path}.{key}"))
        return tuple(violations)
    if kind == "array":
        if not isinstance(value, list): return (SchemaViolation(path, "expected array"),)
        items = schema.get("items", {})
        if not isinstance(items, Mapping): return (SchemaViolation(path, "items must be object"),)
        violations: list[SchemaViolation] = []
        for index, item in enumerate(value): violations.extend(validate_json_value(items, item, path=f"{path}[{index}]"))
        return tuple(violations)
    expected = {
        "string": lambda item: isinstance(item, str),
        "integer": lambda item: type(item) is int,
        "number": lambda item: type(item) in {int, float},
        "boolean": lambda item: type(item) is bool,
        "null": lambda item: item is None,
    }.get(kind)
    if expected is None:
        return (SchemaViolation(path, f"unsupported or missing schema type {kind!r}"),)
    return () if expected(value) else (SchemaViolation(path, f"expected {kind}"),)
