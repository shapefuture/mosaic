"""Profile-gated Rust graph mirror; never an automatic CodeGraph replacement."""
from __future__ import annotations

import pathlib
import subprocess
import time

from pydantic import BaseModel, ConfigDict, Field

from .graph import CodeGraph
from .semantic_code_intelligence import WorkspaceSnapshotter


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class RustGraphSymbol(_Frozen):
    path: str
    kind: str
    name: str
    line: int = Field(ge=1)


class RustGraphCall(_Frozen):
    path: str
    caller: str
    callee: str


class RustGraphSearchHit(_Frozen):
    path: str
    kind: str
    name: str
    line: int = Field(ge=0)
    score: float


class RustGraphConformanceReceipt(_Frozen):
    source_snapshot_digest: str
    rust_symbols: int
    codegraph_symbols: int
    matched_symbols: int
    precision: float
    recall: float
    contains_edges: int = 0
    contains_precision: float = 0.0
    contains_recall: float = 0.0
    rust_call_edges: int = 0
    codegraph_call_edges: int = 0
    calls_precision: float = 0.0
    calls_recall: float = 0.0
    calls_edges_mirrored: bool = False
    duration_ms: float
    mirror_only: bool = True
    production_replacement_authorized: bool = False


class RustGraphMirror:
    def __init__(self, root: pathlib.Path, binary: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.binary = pathlib.Path(binary).resolve()

    def _scan_all(self) -> tuple[tuple[RustGraphSymbol, ...], tuple[RustGraphCall, ...]]:
        result = subprocess.run(
            [str(self.binary), str(self.root)],
            capture_output=True,
            text=True,
            timeout=60,
            check=True,
        )
        symbols: list[RustGraphSymbol] = []
        calls: list[RustGraphCall] = []
        for line in result.stdout.splitlines():
            fields = line.split("\t")
            if len(fields) == 5 and fields[0] == "SYMBOL":
                _, path, kind, name, number = fields
                symbols.append(
                    RustGraphSymbol(path=path, kind=kind, name=name, line=int(number))
                )
            elif len(fields) == 4 and fields[0] == "CALL":
                _, path, caller, callee = fields
                calls.append(RustGraphCall(path=path, caller=caller, callee=callee))
            else:
                raise ValueError(f"invalid Rust graph mirror output row: {line!r}")
        return tuple(symbols), tuple(calls)

    def scan(self) -> tuple[RustGraphSymbol, ...]:
        return self._scan_all()[0]

    def calls(self) -> tuple[RustGraphCall, ...]:
        return self._scan_all()[1]

    @staticmethod
    def _parse_search_rows(text: str) -> tuple[RustGraphSearchHit, ...]:
        hits: list[RustGraphSearchHit] = []
        for line in text.splitlines():
            fields = line.split("\t")
            if len(fields) != 6 or fields[0] != "SEARCH":
                raise ValueError(f"invalid Rust graph search output row: {line!r}")
            _, path, kind, name, line_number, score = fields
            hits.append(RustGraphSearchHit(
                path=path, kind=kind, name=name, line=int(line_number), score=float(score),
            ))
        return tuple(hits)

    def search(self, query: str, limit: int = 10) -> tuple[RustGraphSearchHit, ...]:
        result = subprocess.run(
            [str(self.binary), "--search", str(self.root), query, str(int(limit))],
            capture_output=True,
            text=True,
            timeout=60,
            check=True,
        )
        return self._parse_search_rows(result.stdout)

    def save_index(self, index_path: pathlib.Path, source_digest: str) -> None:
        subprocess.run(
            [str(self.binary), "--save-index", str(self.root), str(index_path), source_digest],
            capture_output=True,
            text=True,
            timeout=60,
            check=True,
        )

    def load_index(self, index_path: pathlib.Path, source_digest: str) -> tuple[tuple[RustGraphSymbol, ...], tuple[RustGraphCall, ...]]:
        result = subprocess.run(
            [str(self.binary), "--load-index", str(index_path), source_digest],
            capture_output=True,
            text=True,
            timeout=60,
            check=True,
        )
        symbols: list[RustGraphSymbol] = []
        calls: list[RustGraphCall] = []
        for line in result.stdout.splitlines():
            fields = line.split("\t")
            if len(fields) == 5 and fields[0] == "SYMBOL":
                _, path, kind, name, number = fields
                symbols.append(RustGraphSymbol(path=path, kind=kind, name=name, line=int(number)))
            elif len(fields) == 4 and fields[0] == "CALL":
                _, path, caller, callee = fields
                calls.append(RustGraphCall(path=path, caller=caller, callee=callee))
            else:
                raise ValueError(f"invalid Rust graph persisted-index output row: {line!r}")
        return tuple(symbols), tuple(calls)

    def search_index(self, index_path: pathlib.Path, source_digest: str, query: str, limit: int = 10) -> tuple[RustGraphSearchHit, ...]:
        result = subprocess.run(
            [str(self.binary), "--search-index", str(index_path), source_digest, query, str(int(limit))],
            capture_output=True,
            text=True,
            timeout=60,
            check=True,
        )
        return self._parse_search_rows(result.stdout)

    def incremental_snapshots(self, ops_file: pathlib.Path) -> dict[str, tuple[tuple[RustGraphSymbol, ...], tuple[RustGraphCall, ...]]]:

        """Run the Rust mirror's stateful incremental command and parse labeled snapshots."""
        result = subprocess.run(
            [str(self.binary), "--incremental", str(self.root), str(ops_file)],
            capture_output=True,
            text=True,
            timeout=60,
            check=True,
        )
        snapshots: dict[str, tuple[list[RustGraphSymbol], list[RustGraphCall]]] = {}
        current: str | None = None
        for line in result.stdout.splitlines():
            fields = line.split("\t")
            if len(fields) == 2 and fields[0] == "BEGIN":
                current = fields[1]
                if current in snapshots:
                    raise ValueError(f"duplicate Rust graph incremental snapshot: {current}")
                snapshots[current] = ([], [])
                continue
            if len(fields) == 2 and fields[0] == "END":
                if current != fields[1]:
                    raise ValueError(f"mismatched Rust graph incremental END row: {line!r}")
                current = None
                continue
            if current is None:
                raise ValueError(f"Rust graph incremental row outside snapshot: {line!r}")
            symbols, calls = snapshots[current]
            if len(fields) == 5 and fields[0] == "SYMBOL":
                _, path, kind, name, number = fields
                symbols.append(RustGraphSymbol(path=path, kind=kind, name=name, line=int(number)))
            elif len(fields) == 4 and fields[0] == "CALL":
                _, path, caller, callee = fields
                calls.append(RustGraphCall(path=path, caller=caller, callee=callee))
            else:
                raise ValueError(f"invalid Rust graph incremental output row: {line!r}")
        if current is not None:
            raise ValueError(f"unterminated Rust graph incremental snapshot: {current}")
        return {key: (tuple(value[0]), tuple(value[1])) for key, value in snapshots.items()}

    def conformance(self) -> RustGraphConformanceReceipt:
        snapshot = WorkspaceSnapshotter(self.root).capture()
        started = time.perf_counter()
        rust, rust_call_rows = self._scan_all()
        graph = CodeGraph(self.root)
        graph.build(persist=False)

        rust_symbols = {(row.path, row.kind, row.name) for row in rust}
        nodes = {
            str(node.get("id")): node for node in graph.graph.get("nodes", [])
        }
        codegraph_symbols = {
            (
                str(node.get("file")),
                str(node.get("kind")),
                str(node.get("name")),
            )
            for node in nodes.values()
            if node.get("kind") in {"Function", "Class"}
        }
        matched_symbols = len(rust_symbols & codegraph_symbols)

        # Each mirrored symbol corresponds to a file-CONTAINS-symbol edge.
        rust_contains = set(rust_symbols)
        codegraph_contains: set[tuple[str, str, str]] = set()
        for edge in graph.graph.get("edges", []):
            if edge.get("type") != "CONTAINS":
                continue
            target = nodes.get(str(edge.get("to")))
            if target and target.get("kind") in {"Function", "Class"}:
                codegraph_contains.add(
                    (
                        str(target.get("file")),
                        str(target.get("kind")),
                        str(target.get("name")),
                    )
                )
        matched_contains = len(rust_contains & codegraph_contains)

        rust_calls = {
            (row.path, row.caller, row.callee) for row in rust_call_rows
        }
        codegraph_calls: set[tuple[str, str, str]] = set()
        for edge in graph.graph.get("edges", []):
            if edge.get("type") != "CALLS":
                continue
            caller = nodes.get(str(edge.get("from")))
            callee = nodes.get(str(edge.get("to")))
            if caller and callee:
                codegraph_calls.add(
                    (
                        str(caller.get("file")),
                        str(caller.get("qualified_name") or caller.get("name")),
                        str(callee.get("qualified_name") or callee.get("name")),
                    )
                )
        matched_calls = len(rust_calls & codegraph_calls)

        observed = WorkspaceSnapshotter(self.root).capture()
        if observed.digest != snapshot.digest:
            raise RuntimeError("workspace changed during Rust graph conformance")

        calls_precision = (
            matched_calls / len(rust_calls) if rust_calls else 1.0
        )
        calls_recall = (
            matched_calls / len(codegraph_calls) if codegraph_calls else 1.0
        )
        return RustGraphConformanceReceipt(
            source_snapshot_digest=snapshot.digest,
            rust_symbols=len(rust_symbols),
            codegraph_symbols=len(codegraph_symbols),
            matched_symbols=matched_symbols,
            precision=matched_symbols / len(rust_symbols) if rust_symbols else 1.0,
            recall=(
                matched_symbols / len(codegraph_symbols)
                if codegraph_symbols
                else 1.0
            ),
            contains_edges=len(rust_contains),
            contains_precision=(
                matched_contains / len(rust_contains) if rust_contains else 1.0
            ),
            contains_recall=(
                matched_contains / len(codegraph_contains)
                if codegraph_contains
                else 1.0
            ),
            rust_call_edges=len(rust_calls),
            codegraph_call_edges=len(codegraph_calls),
            calls_precision=calls_precision,
            calls_recall=calls_recall,
            calls_edges_mirrored=(
                calls_precision == 1.0 and calls_recall == 1.0
            ),
            duration_ms=(time.perf_counter() - started) * 1_000,
        )
