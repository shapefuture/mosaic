"""Evidence-backed remote MCP health, cooldown, and malformed-response quarantine.

The controller intentionally quarantines only transport/protocol failures. A
normal tool business error may be useful feedback and must not make an endpoint
unavailable. No automatic replay of a tool call occurs here.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import pathlib
import threading
import time
from typing import Literal

from .wal import WAL


@dataclass(frozen=True)
class MCPHealthDecision:
    allowed: bool
    endpoint_hash: str
    cooldown_remaining_ms: int
    reason: str


@dataclass(frozen=True)
class MCPHealthObservation:
    endpoint_hash: str
    method: str
    elapsed_ms: float
    kind: Literal["success", "transport_failure", "protocol_failure", "schema_drift"]
    consecutive_failures: int
    quarantined_until: float | None


class MCPHealthLedger:
    def __init__(self, root: pathlib.Path, *, failure_threshold: int = 3, cooldown_seconds: float = 30.0) -> None:
        self.wal = WAL(pathlib.Path(root))
        self.failure_threshold = max(1, int(failure_threshold))
        self.cooldown_seconds = max(1.0, float(cooldown_seconds))
        self._state: dict[str, dict[str, float | int]] = {}
        self._lock = threading.RLock()

    @staticmethod
    def endpoint_hash(endpoint: str) -> str:
        return "sha256:" + hashlib.sha256(str(endpoint).encode()).hexdigest()

    def admit(self, endpoint: str) -> MCPHealthDecision:
        digest = self.endpoint_hash(endpoint)
        now = time.monotonic()
        with self._lock:
            until = float(self._state.get(digest, {}).get("quarantined_until", 0.0))
        if until > now:
            remaining = int((until - now) * 1000)
            decision = MCPHealthDecision(False, digest, remaining, "endpoint is in protocol/transport cooldown")
            self.wal.append("mcp_health", {"event": "admission_denied", **asdict(decision)})
            return decision
        return MCPHealthDecision(True, digest, 0, "endpoint admitted")

    def observe(self, endpoint: str, *, method: str, elapsed_ms: float, kind: str) -> MCPHealthObservation:
        if kind not in {"success", "transport_failure", "protocol_failure", "schema_drift"}:
            raise ValueError("unknown MCP health observation kind")
        digest = self.endpoint_hash(endpoint)
        now = time.monotonic()
        with self._lock:
            state = self._state.setdefault(digest, {"failures": 0, "quarantined_until": 0.0})
            if kind == "success":
                state["failures"] = 0
                state["quarantined_until"] = 0.0
            elif kind in {"transport_failure", "protocol_failure"}:
                state["failures"] = int(state["failures"]) + 1
                if int(state["failures"]) >= self.failure_threshold:
                    state["quarantined_until"] = now + self.cooldown_seconds
            # Schema drift is an integrity signal that should trigger catalog
            # refresh/attestation, but not an availability quarantine by itself.
            observation = MCPHealthObservation(
                endpoint_hash=digest, method=str(method), elapsed_ms=round(max(0.0, elapsed_ms), 3),
                kind=kind, consecutive_failures=int(state["failures"]),
                quarantined_until=(float(state["quarantined_until"]) if float(state["quarantined_until"]) > now else None),
            )
        self.wal.append("mcp_health", {"event": "observation", **asdict(observation)})
        return observation
