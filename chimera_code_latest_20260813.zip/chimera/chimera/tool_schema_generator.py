"""Real, attested generator for compact tool-schema bundles.

Unlike the mapping evaluation fixture, this producer invokes Chimera's actual
``compile_tool_schema`` implementation over a project tool catalog.  It emits a
compact bundle, typed source/generated mappings, and a CAS-backed producer
attestation as one staged directory.  The directory becomes visible through one
same-filesystem rename, so consumers never observe a partially written bundle.
"""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import re
import shutil
import uuid
from typing import Any, Mapping

from pydantic import BaseModel, ConfigDict

from .artifacts import ContentAddressedArtifactStore
from .generated_code_mapping import (
    GeneratedMappingVerifier,
    GeneratorIdentity,
    GeneratorManifestEntry,
    GeneratorMappingContract,
    GeneratorProducerAttestation,
    MappingVerificationReceipt,
    SourceGeneratedEdge,
    SourceRange,
    generator_manifest_digest,
    sign_generator_attestation,
)
from .tool_schema_compiler import compile_tool_schema


GENERATOR_ID = "chimera-tool-schema-bundle-generator"
GENERATOR_VERSION = "1"
_TOOL_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_.-]{0,199}$")


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class GeneratedToolSchemaBundle(_FrozenModel):
    bundle_path: str
    output_path: str
    mapping_path: str
    attestation_path: str
    signature_path: str | None = None
    producer_evidence_ref: str
    producer_signature_ref: str | None = None
    shareable_with_trusted_signature: bool = False
    contract_digest: str
    verification: MappingVerificationReceipt


def _sha(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _relative(root: pathlib.Path, value: pathlib.Path | str) -> tuple[pathlib.Path, str]:
    candidate = pathlib.Path(value)
    candidate = (root / candidate).resolve() if not candidate.is_absolute() else candidate.resolve()
    if not candidate.is_relative_to(root) or candidate == root:
        raise ValueError("generator paths must be workspace-relative and remain below the workspace")
    return candidate, candidate.relative_to(root).as_posix()


def _entry(path: str, data: bytes) -> GeneratorManifestEntry:
    return GeneratorManifestEntry(path=path, digest=_sha(data), size=len(data))


def _position(text: str, start: int, end: int) -> tuple[int, int, int, int]:
    start_line = text.count("\n", 0, start)
    start_character = start - (text.rfind("\n", 0, start) + 1)
    end_line = text.count("\n", 0, end)
    end_character = end - (text.rfind("\n", 0, end) + 1)
    return start_line, start_character, end_line, end_character


def _source_name_ranges(text: str, names: list[str]) -> dict[str, tuple[int, int, int, int]]:
    """Locate each top-level tool name in catalog order.

    Tool names are deliberately restricted to an unescaped identifier alphabet,
    making source character ranges exact in both JSON and the generated text.
    """

    cursor = 0
    ranges: dict[str, tuple[int, int, int, int]] = {}
    for name in names:
        encoded = json.dumps(name)
        pattern = re.compile(r'"name"\s*:\s*(' + re.escape(encoded) + r")")
        match = pattern.search(text, cursor)
        if match is None:
            raise ValueError(f"cannot locate exact source range for tool name {name!r}")
        # Exclude JSON quote characters from the semantic name range.
        start, end = match.start(1) + 1, match.end(1) - 1
        ranges[name] = _position(text, start, end)
        cursor = match.end()
    return ranges


def _implementation_digest() -> str:
    digest = hashlib.sha256(b"chimera-tool-schema-generator-implementation-v1\0")
    for path in (pathlib.Path(__file__).resolve(), pathlib.Path(compile_tool_schema.__code__.co_filename).resolve()):
        data = path.read_bytes()
        digest.update(path.name.encode("utf-8")); digest.update(b"\0"); digest.update(data); digest.update(b"\0")
    return "sha256:" + digest.hexdigest()


class ToolSchemaBundleGenerator:
    """Compile one JSON tool catalog into an immutable, attested bundle."""

    def __init__(self, root: pathlib.Path, *, signer=None) -> None:
        self.root = pathlib.Path(root).resolve()
        if not self.root.is_dir():
            raise ValueError("generator workspace root must be a directory")
        self.artifacts = ContentAddressedArtifactStore(self.root)
        self.signer = signer

    def generate(
        self,
        *,
        source: pathlib.Path | str,
        bundle: pathlib.Path | str,
    ) -> GeneratedToolSchemaBundle:
        source_path, source_relative = _relative(self.root, source)
        bundle_path, bundle_relative = _relative(self.root, bundle)
        if not source_path.is_file():
            raise FileNotFoundError(source_relative)
        if bundle_path.exists():
            raise FileExistsError(f"generated bundle already exists: {bundle_relative}")
        if source_path.is_relative_to(bundle_path):
            raise ValueError("source catalog cannot be inside its generated bundle")

        source_bytes = source_path.read_bytes()
        try:
            source_text = source_bytes.decode("utf-8")
            raw = json.loads(source_text)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("tool catalog must be UTF-8 JSON") from exc
        tools_value = raw.get("tools") if isinstance(raw, Mapping) else raw
        if not isinstance(tools_value, list) or not tools_value:
            raise ValueError("tool catalog must be a non-empty list or an object with non-empty 'tools'")
        if not all(isinstance(item, Mapping) for item in tools_value):
            raise ValueError("every tool catalog entry must be an object")
        tools: list[Mapping[str, Any]] = [dict(item) for item in tools_value]
        names = [str(item.get("name", "")) for item in tools]
        if any(not _TOOL_NAME.fullmatch(name) for name in names):
            raise ValueError("tool names must be unique identifier-like values of at most 200 characters")
        if len(names) != len(set(names)):
            raise ValueError("tool names must be unique")
        source_ranges = _source_name_ranges(source_text, names)

        compiled = [compile_tool_schema(tool) for tool in tools]
        output_lines = [
            "# chimera generated tool-schema bundle v1",
            *[f"{item.name}\t{item.schema_hash}\t{item.text}" for item in compiled],
        ]
        output_text = "\n".join(output_lines) + "\n"
        output_bytes = output_text.encode("utf-8")
        output_relative = f"{bundle_relative}/tool-schemas.txt"
        mapping_relative = f"{bundle_relative}/generated.mapping.json"
        attestation_relative = f"{bundle_relative}/producer-attestation.json"
        signature_relative = f"{bundle_relative}/producer-attestation.sig.json"

        input_manifest = (_entry(source_relative, source_bytes),)
        output_manifest = (_entry(output_relative, output_bytes),)
        arguments = (
            "chimera", "mapping", "produce-tool-schemas",
            "--workspace", ".", "--source", source_relative, "--bundle", bundle_relative,
        )
        command_digest = _sha(json.dumps(list(arguments), separators=(",", ":")).encode("utf-8"))
        attestation = GeneratorProducerAttestation(
            generator_id=GENERATOR_ID,
            generator_version=GENERATOR_VERSION,
            generator_binary_digest=_implementation_digest(),
            generator_arguments=arguments,
            generator_command_digest=command_digest,
            input_manifest=input_manifest,
            input_manifest_digest=generator_manifest_digest(input_manifest),
            output_manifest=output_manifest,
            output_manifest_digest=generator_manifest_digest(output_manifest),
        )
        attestation_bytes = (attestation.model_dump_json(indent=2) + "\n").encode("utf-8")
        evidence = self.artifacts.put(
            attestation_bytes,
            media_type="application/vnd.chimera.generator-producer-attestation+json",
            provenance={"generator_id": GENERATOR_ID, "generator_version": GENERATOR_VERSION},
        )
        signed = sign_generator_attestation(attestation, self.signer) if self.signer is not None else None
        signature_bytes = (signed.model_dump_json(indent=2) + "\n").encode("utf-8") if signed else None
        signature_ref = self.artifacts.put(
            signature_bytes,
            media_type="application/vnd.chimera.signed-generator-attestation+json",
            provenance={"generator_id": GENERATOR_ID, "key_id": signed.key_id},
        ) if signed is not None and signature_bytes is not None else None

        source_digest = _sha(source_bytes)
        output_digest = _sha(output_bytes)
        edges: list[SourceGeneratedEdge] = []
        output_cursor = len(output_lines[0]) + 1
        for item in compiled:
            line = f"{item.name}\t{item.schema_hash}\t{item.text}"
            name_start = output_cursor
            name_end = output_cursor + len(item.name)
            sl, sc, el, ec = source_ranges[item.name]
            gl, gc, gel, gec = _position(output_text, name_start, name_end)
            edges.append(SourceGeneratedEdge(
                id="tool-schema:" + item.name,
                source=SourceRange(
                    path=source_relative,
                    start_line=sl,
                    start_character=sc,
                    end_line=el,
                    end_character=ec,
                    file_digest=source_digest,
                ),
                generated=SourceRange(
                    path=output_relative,
                    start_line=gl,
                    start_character=gc,
                    end_line=gel,
                    end_character=gec,
                    file_digest=output_digest,
                ),
            ))
            output_cursor += len(line) + 1
        contract = GeneratorMappingContract(
            generator=GeneratorIdentity(
                generator_id=GENERATOR_ID,
                generator_version=GENERATOR_VERSION,
                generator_command_digest=attestation.generator_command_digest,
                input_manifest_digest=attestation.input_manifest_digest,
                output_manifest_digest=attestation.output_manifest_digest,
                generator_binary_digest=attestation.generator_binary_digest,
                producer_evidence_ref="artifact:" + evidence.digest,
                producer_signature_ref=("artifact:" + signature_ref.digest) if signature_ref else None,
            ),
            edges=tuple(edges),
        )
        mapping_bytes = (contract.model_dump_json(indent=2) + "\n").encode("utf-8")

        bundle_path.parent.mkdir(parents=True, exist_ok=True)
        staging = bundle_path.with_name(f".{bundle_path.name}.{uuid.uuid4().hex}.tmp")
        try:
            staging.mkdir(mode=0o700)
            self._durable_write(staging / "tool-schemas.txt", output_bytes)
            self._durable_write(staging / "generated.mapping.json", mapping_bytes)
            self._durable_write(staging / "producer-attestation.json", attestation_bytes)
            if signature_bytes is not None:
                self._durable_write(staging / "producer-attestation.sig.json", signature_bytes)
            directory_fd = os.open(staging, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
            os.replace(staging, bundle_path)
            parent_fd = os.open(bundle_path.parent, os.O_RDONLY)
            try:
                os.fsync(parent_fd)
            finally:
                os.close(parent_fd)
        finally:
            if staging.exists():
                shutil.rmtree(staging)

        verifier = GeneratedMappingVerifier(
            self.root,
            evidence_resolver=lambda ref: self.artifacts.has(ref.removeprefix("artifact:")),
            evidence_loader=lambda ref: self.artifacts.get(ref.removeprefix("artifact:")),
        )
        verification = verifier.verify(contract)
        if verification.status != "verified":
            # The immutable bundle remains for forensic inspection, but a caller
            # cannot mistake the typed receipt for a successful generation.
            raise RuntimeError(f"generated bundle failed self-verification: {verification.errors}")
        return GeneratedToolSchemaBundle(
            bundle_path=bundle_relative,
            output_path=output_relative,
            mapping_path=mapping_relative,
            attestation_path=attestation_relative,
            signature_path=signature_relative if signature_bytes is not None else None,
            producer_evidence_ref=contract.generator.producer_evidence_ref,
            producer_signature_ref=contract.generator.producer_signature_ref,
            shareable_with_trusted_signature=signature_bytes is not None,
            contract_digest=contract.digest,
            verification=verification,
        )

    @staticmethod
    def _durable_write(path: pathlib.Path, data: bytes) -> None:
        with path.open("xb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
