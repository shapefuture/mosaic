"""Provider-turn execution for the model tool loop."""
from __future__ import annotations

from dataclasses import dataclass
import time
from typing import Any


@dataclass(frozen=True)
class ProviderTurnResult:
    response: dict[str, Any]
    lifecycle_request: Any
    turn_latency: Any
    native_calls: list[dict[str, Any]]


def execute_provider_turn(
    runtime: Any,
    *,
    branch: str,
    model: str,
    prompt: str,
    request: str,
    directive: str,
    history: str,
    allow_write: bool,
    native_schema_profile: str,
    missing_before_call: list[str],
    native_final_this_turn: bool,
    evidence: list[dict[str, Any]],
    lifecycle_run: Any,
    trajectory: Any,
    turn: int,
) -> ProviderTurnResult:
    """Perform one provider request and restore all transport thread-local state."""
    previous_tools = getattr(runtime._thread_local, "provider_tools", None)
    previous_choice = getattr(runtime._thread_local, "provider_tool_choice", None)
    previous_json_object = getattr(runtime._thread_local, "provider_json_object", None)
    previous_stream_dispatcher = getattr(runtime._thread_local, "stream_tool_dispatcher", None)
    if missing_before_call:
        runtime._thread_local.provider_tools = runtime._native_tool_definitions(
            allow_write, phase="observe", schema_profile=native_schema_profile,
        )
        runtime._thread_local.provider_tool_choice = "required"
        runtime._thread_local.provider_json_object = False
    elif native_final_this_turn:
        runtime._thread_local.provider_tools = runtime._native_tool_definitions(
            allow_write, phase="submit_patch", schema_profile=native_schema_profile,
        )
        runtime._thread_local.provider_tool_choice = "required"
        runtime._thread_local.provider_json_object = False
    else:
        runtime._thread_local.provider_tools = None
        runtime._thread_local.provider_tool_choice = None
        runtime._thread_local.provider_json_object = bool(missing_before_call)

    cache_changes = runtime.prompt_cache.attribute_break(branch, {
        "model": model,
        "surface": runtime.config.planner.tool_surface,
        "native_tools": runtime._thread_local.provider_tools,
        "tool_choice": runtime._thread_local.provider_tool_choice,
    })
    if cache_changes:
        evidence.append({"tool": "prompt_cache_break", "ok": True, "changed_dimensions": list(cache_changes)})

    def stream_dispatch(block: str):
        calls = runtime._parse_tool_calls("<tool_call>" + block + "</tool_call>")
        rows = []
        readonly = {"read_file", "read", "fs.read", "list_files", "list", "glob", "graph_search", "graph", "graph_query", "artifact_read", "artifact", "artifact_search"}
        for call in calls:
            if str(call.get("name", "")).lower() in readonly:
                rows.append(runtime._execute_model_tool(branch, call, allow_write=False))
            else:
                rows.append({"ok": False, "tool": call.get("name"), "error": "stream-time dispatch is read-only"})
        return {"ok": True, "calls": len(calls), "results": rows}

    runtime._thread_local.stream_tool_dispatcher = stream_dispatch
    lifecycle_request = runtime.run_lifecycle.begin_request(lifecycle_run, model=model)
    segment_receipt = runtime.context_segments.record(
        session=branch,
        request_id=lifecycle_request.request_id,
        model=model,
        segments={
            "system_prompt": prompt,
            "conversation_history": history,
            "latest_input": directive,
            "tool_definitions": runtime._thread_local.provider_tools or [],
        },
        fallback_window_tokens=runtime.config.planner.context_max_tokens,
    )
    evidence.append({"tool": "context_window_segments", "ok": True, **segment_receipt.as_dict()})
    turn_latency = runtime.latency_attribution.start(branch, turn + 1)
    started = time.perf_counter()
    try:
        response = runtime.model_provider(request, model=model)
    finally:
        turn_latency.model_ms += (time.perf_counter() - started) * 1000
        runtime._thread_local.provider_tools = previous_tools
        runtime._thread_local.provider_tool_choice = previous_choice
        runtime._thread_local.provider_json_object = previous_json_object
        runtime._thread_local.stream_tool_dispatcher = previous_stream_dispatcher
    if not isinstance(response, dict):
        response = dict(response)
    usage_value = response.get("usage", {}) if isinstance(response.get("usage"), dict) else {}
    evidence.append({"tool": "latency_attribution", "ok": True, "turn": turn + 1, "model_ms": round(turn_latency.model_ms, 3)})
    if usage_value:
        runtime.usage_ledger.record(getattr(runtime._thread_local, "agent_role", "unknown"), response.get("model", model), response.get("provider"), usage_value)
    cache_health = runtime.prompt_cache.observe_usage(branch, usage_value, provider=response.get("provider"))
    evidence.append({"tool": "prompt_cache_health", "ok": cache_health.status not in {"unexpected-miss"}, **cache_health.__dict__})
    if response.get("stream_tool_events"):
        evidence.append({"tool": "stream_time_tool_dispatch", "ok": True, "events": response.get("stream_tool_events")})
    native_calls = runtime._native_tool_calls(response.get("tool_calls"))
    evidence.append({
        "tool": "provider_usage", "ok": True, "turn": turn + 1,
        "model": response.get("model", model), "provider": response.get("provider"),
        "real_call": bool(response.get("real_call")), "tokens": int(response.get("tokens", 0) or 0),
        "usage": response.get("usage", {}), "prompt_cache": response.get("prompt_cache", {}),
        "key_slot": response.get("key_slot"), "native_tool_transport": bool(response.get("native_tool_transport")),
        "native_tool_calls": len(native_calls), "finish_reason": response.get("finish_reason"),
        "refusal": bool(response.get("refusal")),
        "capabilities": runtime.provider_capabilities.get(str(response.get("provider") or "")).__dict__,
    })
    trajectory.append("model_turn", {"turn": turn + 1, "model": response.get("model", model), "provider": response.get("provider"), "tokens": response.get("tokens", 0), "native_tool_calls": len(native_calls)})
    return ProviderTurnResult(response, lifecycle_request, turn_latency, native_calls)
