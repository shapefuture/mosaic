"""Resident-agent density probes for Python/Rust/BEAM runtime choices."""
from __future__ import annotations

import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from typing import Any, Iterable


@dataclass(frozen=True)
class MemorySample:
    pid: int
    rss_kb: int | None
    pss_kb: int | None
    uss_kb: int | None


def _read_status_kb(pid: int, key: str) -> int | None:
    try:
        for line in pathlib.Path(f"/proc/{pid}/status").read_text(errors="ignore").splitlines():
            if line.startswith(key + ":"):
                parts = line.split()
                return int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else None
    except Exception:
        return None
    return None


def sample_memory(pid: int) -> MemorySample:
    rss = _read_status_kb(pid, "VmRSS")
    pss = uss = None
    try:
        for line in pathlib.Path(f"/proc/{pid}/smaps_rollup").read_text(errors="ignore").splitlines():
            if line.startswith("Pss:"):
                pss = int(line.split()[1])
            elif line.startswith("Private_Clean:"):
                uss = (uss or 0) + int(line.split()[1])
            elif line.startswith("Private_Dirty:"):
                uss = (uss or 0) + int(line.split()[1])
    except Exception:
        pass
    return MemorySample(pid=pid, rss_kb=rss, pss_kb=pss, uss_kb=uss)


class RuntimeDensityBenchmark:
    """Bounded, dependency-light runtime density benchmark.

    The benchmark intentionally starts inert shells, not real LLM agents, so it
    measures resident runtime overhead and crash containment without live model
    spend.  Optional runtimes are skipped honestly when missing.
    """

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def run(self, *, counts: Iterable[int] = (1, 10), include_optional: bool = True) -> dict[str, Any]:
        normalized = tuple(max(1, min(1000, int(c))) for c in counts)
        results = [self._python_subprocess(count) for count in normalized]
        if include_optional:
            results.extend(self._optional_runtimes(normalized))
        return {
            "schema_version": "chimera.runtime-density-benchmark.v1",
            "root": str(self.root),
            "counts": list(normalized),
            "probes": results,
            "promotion_allowed": False,
            "promotion_rule": "runtime changes require repeated density benchmarks plus full test suite",
        }

    def _python_subprocess(self, count: int) -> dict[str, Any]:
        code = "import time, signal\nsignal.signal(signal.SIGTERM, lambda *a: exit(0))\ntime.sleep(300)\n"
        processes: list[subprocess.Popen[str]] = []
        started = time.perf_counter()
        try:
            for _ in range(count):
                processes.append(subprocess.Popen([sys.executable, "-c", code], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True))
            time.sleep(0.10)
            samples = [sample_memory(p.pid) for p in processes if p.poll() is None]
            elapsed_ms = (time.perf_counter() - started) * 1000
            return self._summarize("python-subprocess", count, elapsed_ms, samples, skipped=False)
        finally:
            for p in processes:
                if p.poll() is None:
                    p.terminate()
            for p in processes:
                try:
                    p.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    p.kill()

    def _optional_runtimes(self, counts: tuple[int, ...]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        rustc = shutil.which("rustc")
        if rustc:
            out.append(self._rust_stub(counts[0]))
        else:
            out.append({"runtime": "rust-stub", "skipped": True, "reason": "rustc not on PATH"})
        elixir = shutil.which("elixir")
        if elixir:
            out.append(self._elixir_stub(counts[0], elixir))
        else:
            out.append({"runtime": "beam-elixir-stub", "skipped": True, "reason": "elixir not on PATH"})
        return out

    def _rust_stub(self, count: int) -> dict[str, Any]:
        src = 'fn main(){std::thread::sleep(std::time::Duration::from_secs(300));}'
        with tempfile.TemporaryDirectory(prefix="chimera-density-rust-") as td:
            path = pathlib.Path(td)
            rs = path / "stub.rs"
            bin_path = path / "stub"
            rs.write_text(src)
            compile_run = subprocess.run(["rustc", "-O", str(rs), "-o", str(bin_path)], text=True, capture_output=True, timeout=30)
            if compile_run.returncode != 0:
                return {"runtime": "rust-stub", "skipped": True, "reason": "rustc compile failed"}
            procs: list[subprocess.Popen[str]] = []
            started = time.perf_counter()
            try:
                for _ in range(count):
                    procs.append(subprocess.Popen([str(bin_path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True))
                time.sleep(0.10)
                return self._summarize("rust-stub", count, (time.perf_counter() - started) * 1000, [sample_memory(p.pid) for p in procs if p.poll() is None], skipped=False)
            finally:
                for p in procs:
                    if p.poll() is None:
                        p.terminate()
                for p in procs:
                    try: p.wait(timeout=2)
                    except subprocess.TimeoutExpired: p.kill()

    def _elixir_stub(self, count: int, elixir: str) -> dict[str, Any]:
        code = "Process.sleep(:infinity)"
        procs: list[subprocess.Popen[str]] = []
        started = time.perf_counter()
        try:
            for _ in range(count):
                procs.append(subprocess.Popen([elixir, "-e", code], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True))
            time.sleep(0.25)
            return self._summarize("beam-elixir-stub", count, (time.perf_counter() - started) * 1000, [sample_memory(p.pid) for p in procs if p.poll() is None], skipped=False)
        finally:
            for p in procs:
                if p.poll() is None:
                    p.terminate()
            for p in procs:
                try: p.wait(timeout=2)
                except subprocess.TimeoutExpired: p.kill()

    @staticmethod
    def _summarize(runtime: str, count: int, elapsed_ms: float, samples: list[MemorySample], *, skipped: bool) -> dict[str, Any]:
        def total(attr: str) -> int | None:
            vals = [getattr(s, attr) for s in samples]
            return sum(v for v in vals if isinstance(v, int)) if any(isinstance(v, int) for v in vals) else None
        rss = total("rss_kb")
        pss = total("pss_kb")
        uss = total("uss_kb")
        return {
            "runtime": runtime,
            "count": count,
            "skipped": skipped,
            "cold_start_total_ms": round(elapsed_ms, 3),
            "cold_start_per_shell_ms": round(elapsed_ms / max(1, count), 3),
            "rss_kb_total": rss,
            "pss_kb_total": pss,
            "uss_kb_total": uss,
            "rss_kb_per_shell": round(rss / count, 3) if isinstance(rss, int) else None,
            "pss_kb_per_shell": round(pss / count, 3) if isinstance(pss, int) else None,
            "uss_kb_per_shell": round(uss / count, 3) if isinstance(uss, int) else None,
            "sampled_pids": [s.pid for s in samples],
        }


def main() -> None:  # pragma: no cover
    print(json.dumps(RuntimeDensityBenchmark(pathlib.Path.cwd()).run(), indent=2, sort_keys=True))


if __name__ == "__main__":  # pragma: no cover
    main()
