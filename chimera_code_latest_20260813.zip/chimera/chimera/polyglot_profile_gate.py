"""Profiler gate that prevents speculative Rust/Zig/BEAM ownership changes."""
from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, ConfigDict, Field


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class PhysicalProfileObservation(_FrozenModel):
    component: Literal["vfs", "sandbox", "graph", "ledger", "supervision"]
    samples: int = Field(ge=1)
    wall_ms: float = Field(ge=0)
    cpu_ms: float = Field(ge=0)
    peak_rss_kb: int = Field(ge=0)
    evidence_ref: str


class PolyglotProfileDecision(_FrozenModel):
    authorized_candidate: Literal["rust", "zig", "beam"] | None
    target_component: str | None
    authorized_for_mirror_only: bool
    production_replacement_authorized: bool = False
    bottleneck_share: float | None
    reasons: tuple[str, ...]


class PolyglotProfileGate:
    CANDIDATE = {"vfs": "rust", "sandbox": "rust", "graph": "rust", "ledger": "rust", "supervision": "beam"}

    def assess(
        self,
        observations: list[PhysicalProfileObservation] | tuple[PhysicalProfileObservation, ...],
        *,
        minimum_samples: int = 20,
        minimum_bottleneck_share: float = 0.40,
    ) -> PolyglotProfileDecision:
        rows=tuple(observations);reasons=[]
        if not rows: reasons.append("no physical profile observations")
        if any(row.samples < minimum_samples for row in rows): reasons.append("profile sample floor is incomplete")
        if any(not row.evidence_ref for row in rows): reasons.append("profile evidence reference is missing")
        total=sum(row.wall_ms for row in rows)
        target=max(rows,key=lambda row:row.wall_ms) if rows else None
        share=(target.wall_ms/total) if target and total else None
        if share is None or share < minimum_bottleneck_share: reasons.append("no component dominates the measured physical profile")
        candidate=self.CANDIDATE.get(target.component) if target else None
        return PolyglotProfileDecision(
            authorized_candidate=candidate if not reasons else None,
            target_component=target.component if target else None,
            authorized_for_mirror_only=not reasons,
            bottleneck_share=share,
            reasons=tuple(reasons),
        )
