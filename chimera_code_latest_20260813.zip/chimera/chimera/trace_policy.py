"""Adaptive trace sampling with lossless content-addressed backing."""
from __future__ import annotations
import hashlib,json,pathlib
from dataclasses import dataclass
from typing import Any,Iterable
from .artifacts import ContentAddressedArtifactStore

CRITICAL_KINDS={"error","timeout","test_result","capability_denied","exfiltrate","writeoutsideallow","frozen","merge_conflict","capsule_corrupt","semantic_loop"}

@dataclass(frozen=True)
class TraceSample:
    events: tuple[dict[str,Any],...]
    full_ref: str
    dropped: int
    sampled_success: bool
    summary: dict[str,Any]

class TraceSampler:
    def __init__(self,root:pathlib.Path,success_rate:float=.1,max_prompt_events:int=80):
        self.root=pathlib.Path(root);self.rate=max(0,min(1,success_rate));self.max=max(10,max_prompt_events);self.store=ContentAddressedArtifactStore(self.root)
    @staticmethod
    def _critical(event):
        kind=str(event.get("kind","")).lower();data=event.get("data",{})
        if kind in CRITICAL_KINDS:return True
        if kind=="test_result" and isinstance(data,dict) and data.get("status") not in (0,"pass","ok"):return True
        return any(token in kind for token in ("violation","denied","failed","corrupt","conflict"))
    def sample(self,trace:Iterable[dict[str,Any]],*,identity:str)->TraceSample:
        rows=[dict(e) for e in trace if isinstance(e,dict)]
        raw=json.dumps(rows,sort_keys=True,separators=(",",":"),default=str)
        ref=self.store.put(raw,media_type="application/vnd.chimera.trace+json",provenance={"identity":identity,"events":len(rows)})
        critical=[e for e in rows if self._critical(e)]
        digest=int(hashlib.sha256(identity.encode()).hexdigest()[:16],16)/(16**16-1)
        sample_success=digest<self.rate
        if sample_success:kept=rows[:self.max]
        else:
            boundary=[e for e in rows if e.get("kind") in {"node_start","node_end","patch_applied"}]
            seen=set();kept=[]
            for event in [*critical,*boundary]:
                key=hashlib.sha256(json.dumps(event,sort_keys=True,default=str).encode()).hexdigest()
                if key not in seen:kept.append(event);seen.add(key)
            kept=kept[:self.max]
        counts={}
        for e in rows:counts[str(e.get("kind","unknown"))]=counts.get(str(e.get("kind","unknown")),0)+1
        return TraceSample(events=tuple(kept),full_ref=f"artifact:{ref.digest}",dropped=max(0,len(rows)-len(kept)),sampled_success=sample_success,
                           summary={"events":len(rows),"kept":len(kept),"kinds":counts})
