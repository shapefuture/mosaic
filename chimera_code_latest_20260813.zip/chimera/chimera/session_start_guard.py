"""Session-start lock and cooldown guard.

Ported conceptually from lazycodex's codegraph hook runtime.  Chimera uses this
for any optional session-start warmers/probes so failed startup work does not
stampede thousands of agents and stale locks can be reclaimed safely.
"""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import time
import uuid
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class SessionLock:
    path: str
    token: str


@dataclass(frozen=True)
class SessionLockDecision:
    kind: str  # acquired | locked | inconclusive
    lock: SessionLock | None = None
    recovered_stale: bool = False
    reason: str | None = None


@dataclass(frozen=True)
class CooldownDecision:
    kind: str  # active | inactive | inconclusive
    failure_count: int = 0
    cooldown_until: float | None = None
    reason: str | None = None


class SessionStartGuard:
    def __init__(self, root: pathlib.Path, *, namespace: str = "default") -> None:
        self.root = pathlib.Path(root).resolve()
        self.namespace = self._safe(namespace)
        digest = hashlib.sha256(str(self.root).encode()).hexdigest()[:24]
        self.state_dir = self.root / ".chimera" / "session-start" / self.namespace / digest
        self.lock_path = self.state_dir / "probe.lock"
        self.cooldown_path = self.state_dir / "cooldown.json"

    def acquire_lock(self, *, stale_seconds: float = 300.0, now: float | None = None) -> dict[str, Any]:
        now = time.time() if now is None else float(now)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        initial = self._try_create_lock()
        if initial.kind != "locked":
            return asdict(initial)
        snapshot = self._read_lock_snapshot()
        if snapshot["kind"] == "missing":
            return asdict(self._try_create_lock())
        if snapshot["kind"] == "inconclusive":
            return asdict(SessionLockDecision("inconclusive", reason=snapshot["reason"]))
        if now - float(snapshot["mtime"]) < max(1.0, stale_seconds):
            return asdict(SessionLockDecision("locked"))
        reclaim = self._try_create_marker(self.lock_path.with_suffix(".reclaim"))
        if reclaim != "acquired":
            return asdict(SessionLockDecision("locked" if reclaim == "locked" else "inconclusive", reason=None if reclaim == "locked" else reclaim))
        try:
            current = self._read_lock_snapshot()
            if current["kind"] == "present":
                changed = current.get("raw") != snapshot.get("raw") or current.get("mtime") != snapshot.get("mtime")
                if changed or now - float(current["mtime"]) < max(1.0, stale_seconds):
                    return asdict(SessionLockDecision("locked"))
                self.lock_path.unlink(missing_ok=True)
            acquired = self._try_create_lock()
            if acquired.kind == "acquired":
                acquired = SessionLockDecision("acquired", lock=acquired.lock, recovered_stale=True)
            return asdict(acquired)
        finally:
            self.lock_path.with_suffix(".reclaim").unlink(missing_ok=True)

    def release_lock(self, lock: SessionLock | dict[str, Any]) -> bool:
        value = lock if isinstance(lock, SessionLock) else SessionLock(**lock)
        snapshot = self._read_lock_snapshot()
        if snapshot["kind"] != "present" or snapshot.get("token") != value.token:
            return False
        pathlib.Path(value.path).unlink(missing_ok=True)
        return True

    def lock_is_owned(self, lock: SessionLock | dict[str, Any]) -> bool:
        value = lock if isinstance(lock, SessionLock) else SessionLock(**lock)
        snapshot = self._read_lock_snapshot()
        return snapshot["kind"] == "present" and snapshot.get("token") == value.token

    def read_cooldown(self, *, base_seconds: float = 900.0, max_seconds: float = 86400.0, now: float | None = None) -> dict[str, Any]:
        now = time.time() if now is None else float(now)
        state = self._read_cooldown_state()
        if state["kind"] == "missing":
            return asdict(CooldownDecision("inactive"))
        if state["kind"] == "inconclusive":
            return asdict(CooldownDecision("inconclusive", reason=state["reason"]))
        value = state["value"]
        until = float(value["last_failure_at"]) + self._cooldown_duration(base_seconds, int(value["failure_count"]), max_seconds)
        if now < until:
            return asdict(CooldownDecision("active", failure_count=int(value["failure_count"]), cooldown_until=until))
        return asdict(CooldownDecision("inactive", failure_count=int(value["failure_count"])))

    def record_failure(self, action: str, *, base_seconds: float = 900.0, max_seconds: float = 86400.0, now: float | None = None) -> dict[str, Any]:
        now = time.time() if now is None else float(now)
        state = self._read_cooldown_state()
        count = int(state["value"]["failure_count"]) + 1 if state["kind"] == "present" else 1
        value = {
            "version": 1,
            "action": str(action),
            "failure_count": count,
            "last_failure_at": now,
            "cooldown_until": now + self._cooldown_duration(base_seconds, count, max_seconds),
            "project_root": str(self.root),
        }
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self._atomic_write_json(self.cooldown_path, value)
        return value

    def clear_cooldown(self) -> None:
        self.cooldown_path.unlink(missing_ok=True)

    def _try_create_lock(self) -> SessionLockDecision:
        token = uuid.uuid4().hex
        body = {"version": 1, "project_root": str(self.root), "token": token}
        try:
            fd = os.open(self.lock_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(body, handle, sort_keys=True)
                handle.write("\n")
            return SessionLockDecision("acquired", lock=SessionLock(str(self.lock_path), token))
        except FileExistsError:
            return SessionLockDecision("locked")
        except OSError as exc:
            return SessionLockDecision("inconclusive", reason=str(exc))

    @staticmethod
    def _try_create_marker(path: pathlib.Path) -> str:
        try:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(uuid.uuid4().hex + "\n")
            return "acquired"
        except FileExistsError:
            return "locked"
        except OSError as exc:
            return str(exc)

    def _read_lock_snapshot(self) -> dict[str, Any]:
        try:
            raw = self.lock_path.read_text(encoding="utf-8")
            parsed = json.loads(raw)
            token = parsed.get("token") if isinstance(parsed, dict) else None
            if not isinstance(token, str) or not token:
                return {"kind": "inconclusive", "reason": "lock token missing"}
            return {"kind": "present", "raw": raw, "token": token, "mtime": self.lock_path.stat().st_mtime}
        except FileNotFoundError:
            return {"kind": "missing"}
        except Exception as exc:
            return {"kind": "inconclusive", "reason": str(exc)}

    def _read_cooldown_state(self) -> dict[str, Any]:
        try:
            value = json.loads(self.cooldown_path.read_text(encoding="utf-8"))
            if not isinstance(value, dict) or int(value.get("version", 0)) != 1:
                return {"kind": "inconclusive", "reason": "invalid cooldown state"}
            if value.get("project_root") != str(self.root):
                return {"kind": "inconclusive", "reason": "cooldown state belongs to different project"}
            return {"kind": "present", "value": value}
        except FileNotFoundError:
            return {"kind": "missing"}
        except Exception as exc:
            return {"kind": "inconclusive", "reason": str(exc)}

    @staticmethod
    def _cooldown_duration(base: float, failure_count: int, max_seconds: float) -> float:
        duration = min(max(1.0, base), max_seconds)
        for _ in range(1, max(1, failure_count)):
            duration = min(duration * 2, max_seconds)
        return duration

    @staticmethod
    def _atomic_write_json(path: pathlib.Path, value: dict[str, Any]) -> None:
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(value, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(tmp, path)

    @staticmethod
    def _safe(value: str) -> str:
        return "".join(ch if ch.isalnum() or ch in {"-", "_"} else "-" for ch in str(value))[:80] or "default"
