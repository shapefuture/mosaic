"""Fresh required handoff gates backed by reusable signed command proofs."""
from __future__ import annotations
import time
from typing import Any,Iterable,Literal
from pydantic import BaseModel,ConfigDict
from .capsule import workspace_input_root
class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
class RequiredGate(FrozenModel):
 id:str;command:str;scope:str="repository";max_age_seconds:int=3600
class GateReceipt(FrozenModel):
 id:str;status:Literal["PASS","FAIL","UNAVAILABLE"];command:str;exit_code:int|None;output_ref:str|None;completed_at:float;workspace_root:str;proof_receipt:str|None;stale:bool=False;reason:str=""
class GateDecision(FrozenModel):authorized:bool;receipts:tuple[GateReceipt,...];reasons:tuple[str,...]
class QualityGateRunner:
 def __init__(self,runtime):self.runtime=runtime
 def run(self,branch:str,gates:Iterable[RequiredGate]):
  root=workspace_input_root(self.runtime.root,self.runtime.workspace,branch);rows=[]
  for gate in gates:
   try:
    result=self.runtime._run_branch_tests(branch,command=gate.command,impact_scope=False);status="PASS" if result["status"]==0 else "FAIL";proof=result["evidence"].get("command_proof",{})
    completed=time.time()
    if proof.get("completed_at"):
     try:
      from datetime import datetime
      completed=datetime.fromisoformat(str(proof["completed_at"]).replace("Z","+00:00")).timestamp()
     except (TypeError, ValueError, OverflowError):
      completed=time.time()
    rows.append(GateReceipt(id=gate.id,status=status,command=gate.command,exit_code=result["status"],output_ref=result.get("full_output_ref"),completed_at=completed,workspace_root=root,proof_receipt=proof.get("receipt_hash"),reason="command completed"))
   except Exception as exc:rows.append(GateReceipt(id=gate.id,status="UNAVAILABLE",command=gate.command,exit_code=None,output_ref=None,completed_at=time.time(),workspace_root=root,proof_receipt=None,reason=f"{type(exc).__name__}: {exc}"))
  return tuple(rows)
 def authorize(self,branch:str,gates:Iterable[RequiredGate],receipts:Iterable[GateReceipt]):
  gates={g.id:g for g in gates};rows={r.id:r for r in receipts};root=workspace_input_root(self.runtime.root,self.runtime.workspace,branch);reasons=[];now=time.time()
  for gid,gate in gates.items():
   r=rows.get(gid)
   if not r:reasons.append(f"missing gate {gid}");continue
   if r.status!="PASS":reasons.append(f"gate {gid} status {r.status}")
   if r.stale or now-r.completed_at>gate.max_age_seconds:reasons.append(f"gate {gid} evidence stale")
   if r.workspace_root!=root:reasons.append(f"gate {gid} workspace root changed")
   if not r.proof_receipt:reasons.append(f"gate {gid} lacks command proof")
  return GateDecision(authorized=not reasons,receipts=tuple(rows.values()),reasons=tuple(reasons))
