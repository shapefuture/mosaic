"""OpenAI-compatible TokenRouter cancellation adapter for one fixed canary.

The adapter deliberately cannot certify provider-side cancellation: OpenAI chat
completions streaming exposes no standard cancellation acknowledgement or
billing-stop receipt.  It only proves when the local streaming worker ended.
The strict canary therefore remains unproven unless TokenRouter supplies a
route-specific adapter with stronger evidence.
"""
from __future__ import annotations

import threading
import time
from typing import Any, Callable

from .provider_cancellation_canary import ProviderTerminalEvent
from .testing_environment import TestingEnvironment


class TokenRouterCancellablePort:
    provider = "tokenrouter"
    adapter_id = "tokenrouter-openai-chat-stream-local-cancel-v1"

    def __init__(
        self,
        *,
        base_url: str = "https://api.tokenrouter.com/v1",
        max_output_tokens: int = 1024,
        request_timeout_seconds: float = 60.0,
        credential_supplier: Callable[[], str] | None = None,
        egress=None,
    ) -> None:
        if max_output_tokens <= 0 or request_timeout_seconds <= 0:
            raise ValueError("TokenRouter canary bounds must be positive")
        self.base_url = base_url.rstrip("/")
        self.max_output_tokens = int(max_output_tokens)
        self.request_timeout_seconds = float(request_timeout_seconds)
        self.credential_supplier = credential_supplier
        self.egress = egress

    def start_fixed_canary(self, *, model: str, request_id: str) -> "_TokenRouterCancellationHandle":
        TestingEnvironment.require_tokenrouter_kimi(model=model)
        key = self.credential_supplier() if self.credential_supplier is not None else TestingEnvironment.read_one_shot_credential()
        if not key:
            raise RuntimeError("TokenRouter test credential supplier returned no credential")
        if self.egress is None:
            raise PermissionError("common egress policy is required for live provider canary")
        self.egress.authorize(self.base_url + "/chat/completions")
        return _TokenRouterCancellationHandle(
            base_url=self.base_url,
            api_key=key,
            model=model,
            request_id=request_id,
            max_output_tokens=self.max_output_tokens,
            request_timeout_seconds=self.request_timeout_seconds,
        )


class _TokenRouterCancellationHandle:
    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        model: str,
        request_id: str,
        max_output_tokens: int,
        request_timeout_seconds: float,
    ) -> None:
        self._cancel = threading.Event()
        self._lock = threading.RLock()
        self._result: ProviderTerminalEvent | None = None
        self._client: Any = None
        self._started = time.monotonic()
        self._thread = threading.Thread(
            target=self._run,
            args=(base_url, api_key, model, request_id, max_output_tokens, request_timeout_seconds),
            daemon=True,
            name="chimera-tokenrouter-cancel-canary",
        )
        self._thread.start()

    def _run(
        self,
        base_url: str,
        api_key: str,
        model: str,
        request_id: str,
        max_output_tokens: int,
        request_timeout_seconds: float,
    ) -> None:
        try:
            import httpx
            client = httpx.Client(
                timeout=httpx.Timeout(request_timeout_seconds, connect=min(20.0, request_timeout_seconds)),
                limits=httpx.Limits(max_connections=1, max_keepalive_connections=0),
            )
            with self._lock:
                self._client = client
            payload = {
                "model": model,
                "stream": True,
                "stream_options": {"include_usage": True},
                "max_tokens": max_output_tokens,
                "reasoning_effort": "low",
                "messages": [{
                    "role": "user",
                    "content": "CHIMERA_FIXED_CANCELLATION_CANARY_V1. Produce a long numbered sequence until cancelled.",
                }],
            }
            with client.stream(
                "POST", f"{base_url}/chat/completions",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json=payload,
            ) as response:
                response.raise_for_status()
                for _chunk in response.iter_bytes():
                    if self._cancel.is_set():
                        break
            outcome = "unknown" if self._cancel.is_set() else "completed"
            result = ProviderTerminalEvent(
                terminal=True,
                outcome=outcome,
                provider_acknowledged_cancel=False,
                billing_semantics="unknown",
                detail="local TokenRouter stream worker ended; provider cancellation/billing acknowledgement unavailable",
            )
        except Exception as exc:
            result = ProviderTerminalEvent(
                terminal=not self._thread.is_alive(),
                outcome="unknown",
                provider_acknowledged_cancel=False,
                billing_semantics="unknown",
                detail=f"local TokenRouter stream ended with {type(exc).__name__}; provider cancellation unproven",
            )
        finally:
            with self._lock:
                self._result = result
                client = self._client
                self._client = None
            if client is not None:
                try:
                    client.close()
                except Exception:
                    pass

    def cancel(self, _reason: str) -> ProviderTerminalEvent:
        self._cancel.set()
        with self._lock:
            client = self._client
        if client is not None:
            try:
                client.close()
            except Exception:
                pass
        # Closing a local stream has no OpenAI-compatible provider acknowledgement.
        return ProviderTerminalEvent(
            terminal=False,
            outcome="unknown",
            provider_acknowledged_cancel=False,
            billing_semantics="unknown",
            detail="local stream close requested; provider-side cancellation/billing acknowledgement unavailable",
        )

    def wait_terminal(self, timeout_seconds: float) -> ProviderTerminalEvent:
        self._thread.join(max(0.0, float(timeout_seconds)))
        with self._lock:
            result = self._result
        if result is not None:
            return result
        return ProviderTerminalEvent(
            terminal=False,
            outcome="unknown",
            provider_acknowledged_cancel=False,
            billing_semantics="unknown",
            detail="local stream worker did not terminate before canary deadline",
        )
