"""Structured pytest-failure repair planning for model repair prompts."""
from __future__ import annotations

import re
from dataclasses import dataclass, asdict


@dataclass(frozen=True)
class RepairHints:
    hints: tuple[str, ...]
    anchors: tuple[str, ...]
    failing_inputs: tuple[str, ...] = ()
    assertion_snippets: tuple[str, ...] = ()
    def as_dict(self): return asdict(self)


@dataclass(frozen=True)
class LocalRepairPlan:
    text: str
    hints: RepairHints
    current_source_chars: int
    def as_dict(self): return asdict(self)


def _unique(items: list[str], limit: int) -> tuple[str, ...]:
    return tuple(dict.fromkeys(item for item in items if item))[:limit]


def extract_repair_hints(stdout: str = "", stderr: str = "") -> RepairHints:
    text = f"{stdout}\n{stderr}"
    lower = text.lower()
    hints: list[str] = []
    anchors = list(dict.fromkeys(re.findall(r"(?:tests|chimera|pkg)/[^:\s]+\.py:\d+", text)))
    failing_inputs: list[str] = []
    assertion_snippets: list[str] = []

    if "failed: did not raise" in lower:
        hints.append("A test expected an exception. Add validation that raises ValueError/expected exception for the listed bad input.")
    if "assertionerror" in lower or re.search(r"assert .*==", text):
        hints.append("A value/schema assertion failed. Match the exact expected keys, value types, ordering, and edge-case behavior shown in pytest output.")
    if "importerror" in lower or "cannot import name" in lower:
        hints.append("A required symbol is missing or not top-level. Define the imported function/class exactly at module top level.")
    if "modulenotfounderror" in lower or "no module named" in lower:
        hints.append("A required module file is missing. Create the exact module path requested by the test/import.")
    if "valueerror" in lower and "invalid" in lower:
        hints.append("A parser rejected a valid hidden/edge input. Broaden accepted syntax while retaining explicit rejection for malformed inputs.")
    if "keyerror" in lower:
        hints.append("A dictionary output or input key is missing. Use .get/defaults for inputs and return exactly the expected output schema.")
    if "typeerror" in lower:
        hints.append("A function signature or value type is wrong. Match the test's call shape and return type exactly.")
    if "left contains" in lower or "right contains" in lower or "at index" in lower:
        hints.append("Pytest diff shows exact schema/content mismatch. Prefer the expected right-hand schema and remove extra keys/items.")
    if "no such command" in lower:
        hints.append("A CLI command is missing. Register the exact command name before the CLI entrypoint runs.")

    for match in re.finditer(r"E\s+AssertionError:([^\n]{0,260})", text):
        assertion_snippets.append(match.group(1).strip())
        hints.append("Assertion diff: " + match.group(1).strip())
    for match in re.finditer(r"assert\s+([^\n]{0,220})", text):
        assertion_snippets.append("assert " + match.group(1).strip())
    # Pull quoted values from failing pytest snippets; useful for parser edge cases.
    for match in re.finditer(r"['\"]([^'\"\n]{0,80})['\"]", text):
        value = match.group(1)
        if value and any(ch.isdigit() or ch.isalpha() for ch in value):
            failing_inputs.append(value)
    return RepairHints(
        hints=_unique(hints, 10),
        anchors=_unique(anchors, 16),
        failing_inputs=_unique(failing_inputs, 20),
        assertion_snippets=_unique(assertion_snippets, 8),
    )


def build_local_repair_plan(*, target_path: str, current_source: str, stdout: str = "", stderr: str = "") -> LocalRepairPlan:
    """Build a compact source+pytest-diff repair briefing before provider retry.

    This does not guess a patch. It turns noisy pytest output into structured,
    bounded facts plus the current source that actually failed.
    """
    hints = extract_repair_hints(stdout, stderr)
    source = current_source[-12_000:]
    lines = [
        "LOCAL REPAIR PLAN (deterministic, from pytest + current branch source):",
        f"target={target_path}",
    ]
    if hints.anchors:
        lines.append("failing_anchors=" + ", ".join(hints.anchors))
    if hints.hints:
        lines.append("hints:")
        lines.extend(f"- {hint}" for hint in hints.hints)
    if hints.failing_inputs:
        lines.append("quoted_values_seen_in_failure=" + repr(list(hints.failing_inputs)[:12]))
    if hints.assertion_snippets:
        lines.append("assertion_snippets:")
        lines.extend(f"- {snippet[:240]}" for snippet in hints.assertion_snippets)
    lines.append("current_source_tail:")
    lines.append(source)
    return LocalRepairPlan("\n".join(lines)[:16_000], hints, len(current_source))
