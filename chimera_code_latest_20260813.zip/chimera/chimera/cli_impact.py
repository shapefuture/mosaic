"""Dynamic impact/TIA CLI commands."""
from __future__ import annotations

import json
import pathlib

import click
from rich.json import JSON


def register(main: click.Group, *, console) -> None:
    @main.group("impact")
    def impact_group():
        """Evidence-gated test impact collection and inspection."""
        pass


    @impact_group.command("collect-coverage")
    @click.option("--workspace", default=".")
    @click.option("--coverage-file", type=click.Path(path_type=pathlib.Path), default=pathlib.Path(".coverage"))
    @click.option("--evidence-ref", required=True)
    def impact_collect_coverage(workspace, coverage_file, evidence_ref):
        from .dynamic_impact import DynamicCoverageCollector
        root = pathlib.Path(workspace)
        path = coverage_file if coverage_file.is_absolute() else root / coverage_file
        receipt = DynamicCoverageCollector(root).collect(path, evidence_ref=evidence_ref)
        console.print(JSON(receipt.model_dump_json(indent=2)))


    @impact_group.command("select")
    @click.argument("changed_paths", nargs=-1, required=True)
    @click.option("--workspace", default=".")
    def impact_select(changed_paths, workspace):
        """Print an advisory dynamic-coverage test selection for declared paths.

        This command never executes a test, rewrites a task's command, or promotes
        focused verification. A stale, missing, or incomplete map returns the
        ordinary full-suite command with its explicit reason.
        """
        from .dynamic_impact import DynamicImpactSelector
        selection = DynamicImpactSelector(pathlib.Path(workspace)).select(list(changed_paths))
        console.print(JSON(selection.model_dump_json(indent=2)))


