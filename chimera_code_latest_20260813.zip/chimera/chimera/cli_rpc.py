"""JSON-RPC/ACP CLI commands."""
from __future__ import annotations

import pathlib

import click


def register(main: click.Group, *, console, cli_state, tenant_transport_root) -> None:
    _cli_state = cli_state
    _tenant_transport_root = tenant_transport_root

    @main.group("rpc")
    def rpc_group():
        """Branch-per-session JSON-RPC/ACP protocol."""
        pass

    @rpc_group.command("serve")
    @click.option("--workspace", default=".")
    @click.option("--tenant-id", default=None)
    @click.option("--principal", default=None)
    @click.option("--authorization-file", type=click.Path(path_type=pathlib.Path), default=None)
    @click.option("--trusted-key-id", "trusted_key_ids", multiple=True)
    def rpc_serve(workspace, tenant_id, principal, authorization_file, trusted_key_ids):
        from .bootstrap import build_local_application, new_run_context
        from .rpc_server import serve_stdio

        cache = {}
        def context_factory():
            root, tenant_context = _tenant_transport_root(
                workspace, tenant_id, principal, authorization_file, trusted_key_ids, "rpc",
            )
            key = str(root.resolve())
            if key not in cache:
                cache[key] = build_local_application(root)
            application, composition = cache[key]
            values = tenant_context.model_dump(mode="json") if tenant_context is not None else {}
            return application, new_run_context(
                profile=composition.config.deployment_profile,
                deadline_seconds=_cli_state().get("deadline_seconds", 1_800.0),
                trace_id=_cli_state().get("trace_id"),
                tenant_key=values.get("tenant_key"),
                principal_hash=values.get("principal_hash"),
                grant_digest=values.get("grant_digest"),
            )

        root, _tenant_context = _tenant_transport_root(
            workspace, tenant_id, principal, authorization_file, trusted_key_ids, "rpc",
        )
        serve_stdio(root, context_factory=context_factory)

