"""Focused-coder final acceptance, regression, and result construction."""
from __future__ import annotations

import tempfile
import pathlib
from typing import Any, Dict, List, Mapping

from .quality import TaskContract


class FocusedResultMixin:
    def _focused_acceptance_snapshot(
        self,
        *,
        acceptance_ledger,
        acceptance_cards,
        acceptance_states,
        test: Mapping[str, Any],
        changed: list[str],
    ) -> dict[str, Any]:
        test_ref = test.get("full_output_ref") if isinstance(test, Mapping) else None
        if test.get("status") == 0 and changed and isinstance(test_ref, str):
            changed_set = set(changed)
            for index, card in enumerate(acceptance_cards):
                if not set(card.paths).intersection(changed_set):
                    continue
                acceptance_states[index] = acceptance_ledger.close(card, [test_ref])
        return {
            "cards": [state.as_dict() for state in acceptance_states],
            "closed": sum(state.status == "closed" for state in acceptance_states),
            "open": sum(state.status == "open" for state in acceptance_states),
            "stale": sum(state.status == "stale" for state in acceptance_states),
        }


    def _focused_candidate_promotion_gate(
        self,
        *,
        branch: str,
        contract: TaskContract,
        changed: list[str],
        test: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Run a non-promotional candidate gate over materialized changed files.

        Focused coder branches are transactional overlays, not necessarily a real
        candidate worktree.  Materialize only changed files into a temp candidate
        and compose exploit-scan + Project Forge + test-status evidence.  Hidden
        tests are not available here, so promotion remains false; the standalone
        candidate-promotion-gate can later re-run with evaluator-owned hidden
        tests or task-bank IDs.
        """
        from .candidate_promotion_gate import CandidatePromotionGate
        if not changed:
            return {
                "schema_version": "chimera.focused-candidate-promotion-summary.v1",
                "promotion_allowed": False,
                "reason": "no changed files",
            }
        with tempfile.TemporaryDirectory(prefix="chimera-focused-candidate-") as td:
            candidate = pathlib.Path(td)
            materialized = []
            for rel in list(dict.fromkeys(changed)):
                try:
                    data = self.workspace.read(branch, rel)
                except Exception:
                    continue
                out = candidate / rel
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(data)
                materialized.append(rel)
            gate = CandidatePromotionGate(self.root).evaluate(
                candidate,
                task=contract.task,
                visible_test=None,
                hidden_test=None,
                authorize_promotion_evaluation=False,
            )
        return {
            "schema_version": "chimera.focused-candidate-promotion-summary.v1",
            "materialized_changed_files": materialized,
            "external_hidden_gate_required": True,
            "test_status": test.get("status"),
            "promotion_allowed": False,
            "gate": gate,
        }

    def _focused_result(
        self,
        *,
        branch: str,
        model: str,
        contract: TaskContract,
        changed: list[str],
        test: Mapping[str, Any],
        baseline_test: Mapping[str, Any],
        evidence: List[Dict[str, Any]],
        acceptance_ledger,
        acceptance_cards,
        acceptance_states,
        protected_tests_unchanged: bool,
        mutation_summary: dict[str, Any] | None,
        capsule_spec,
        repair_rounds: int,
        provider_records: list[dict[str, Any]],
        last_response: Mapping[str, Any],
        api_calls: int,
        total_tokens: int,
    ) -> Dict[str, Any]:
        diff = self.workspace.diff(branch)
        acceptance_snapshot = self._focused_acceptance_snapshot(
            acceptance_ledger=acceptance_ledger,
            acceptance_cards=acceptance_cards,
            acceptance_states=acceptance_states,
            test=test,
            changed=changed,
        )
        regression = self.regression_ledger.record(
            diff,
            baseline_test.get("status"),
            int(test.get("status", 1)),
            test.get("evidence", {}).get("verification_scope", {}),
        )
        unique_changed = list(dict.fromkeys(changed))
        candidate_gate = self._focused_candidate_promotion_gate(
            branch=branch, contract=contract, changed=unique_changed, test=test,
        )
        return {
            "artifacts": {
                "answer": f"Focused patch: targets={[t.path for t in contract.targets]}; changed={unique_changed}; tests={test.get('status')}",
                "patch": {
                    "applied": unique_changed,
                    "rejected": [item for event in evidence for item in event.get("rejected", [])],
                },
                "diff": diff,
                "ops": diff.get("ops", []),
                "test_status": test.get("status"),
                "baseline_test": baseline_test,
                "regression": regression,
                "test_evidence": test,
                "quality_evidence": evidence,
                "quality": {
                    "admissible": bool(changed) and test.get("status") == 0,
                    "score": 1.0 if bool(changed) and test.get("status") == 0 else 0.35 if changed else 0.0,
                    "repair_rounds": repair_rounds,
                    "target_coverage": len(set(changed)) / max(1, len(contract.targets)),
                    "protected_paths_unchanged": not any(path in contract.protected_paths for path in changed),
                    "protected_tests_unchanged": protected_tests_unchanged,
                    "semantic_fallback_used": any(item.get("stage") == "semantic-scaffold-fallback" for item in evidence),
                    "model_outputs_admitted": sum(
                        1 for item in evidence
                        if item.get("ok") and (item.get("stage") == "apply" or str(item.get("stage", "")).startswith("repair-"))
                    ),
                    "capsule_hit": False,
                    "capsule_eligible": capsule_spec is not None,
                    "mutation": mutation_summary,
                },
                "acceptance": acceptance_snapshot,
                "candidate_promotion_gate": candidate_gate,
                "contract": {
                    "targets": [target.__dict__ for target in contract.targets],
                    "protected_paths": contract.protected_paths,
                    "required_literals": contract.required_literals,
                    "required_symbols": contract.required_symbols,
                    "required_calls": contract.required_calls,
                    "required_mapping_keys": contract.required_mapping_keys,
                    "required_prefixes": contract.required_prefixes,
                    "required_call_arity": contract.required_call_arity,
                },
                "provider": {
                    "model": model,
                    "provider": provider_records[-1].get("provider") if provider_records else last_response.get("provider", "local"),
                    "real_call": bool(provider_records),
                    "api_calls": api_calls,
                    "key_slots": [record.get("key_slot") for record in provider_records if record.get("key_slot")],
                    "key_pool_size": max((record.get("key_pool_size") or 0 for record in provider_records), default=0),
                },
            },
            "trace": [
                {"kind": "quality_contract", "data": {"targets": [target.path for target in contract.targets], "protected": contract.protected_paths}},
                {"kind": "quality_stages", "data": evidence},
                {"kind": "patch_applied", "data": {"applied": unique_changed}},
                {"kind": "test_result", "data": {"status": test.get("status"), "duration_ms": test.get("duration_ms"), "repair_rounds": repair_rounds}},
                {"kind": "candidate_promotion_gate", "data": {"promotion_allowed": candidate_gate.get("promotion_allowed"), "external_hidden_gate_required": candidate_gate.get("external_hidden_gate_required")}},
            ],
            "tokens": total_tokens,
        }
