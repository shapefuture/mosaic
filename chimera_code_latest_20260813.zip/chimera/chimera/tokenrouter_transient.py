"""Transient TokenRouter/Kimi live-test lane.

This module is intentionally narrow.  It only authorizes the provisioned
TokenRouter Kimi route when the non-production testing environment guard is set.
It never writes, logs, or returns the raw credential.
"""
from __future__ import annotations

import json
import os
import pathlib
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, asdict
from typing import Any, Callable, Mapping

from .testing_environment import TestingEnvironment, TransientEnvironmentError

TOKENROUTER_ENDPOINT = "https://api.tokenrouter.com/v1/chat/completions"
TOKENROUTER_MODEL = "moonshotai/kimi-k3-free"
TOKENROUTER_NEMOTRON_MODEL = "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free"
CHIMERA_PROVIDER_MODEL = "tokenrouter/moonshotai/kimi-k3-free"
ALLOWED_MODELS = {TOKENROUTER_MODEL, TOKENROUTER_NEMOTRON_MODEL}
MODEL_ROUTE_HINTS = {
    TOKENROUTER_MODEL: TestingEnvironment.TOKENROUTER_ROUTE,
    TOKENROUTER_NEMOTRON_MODEL: "tokenrouter-nemotron-free-v1",
}


@dataclass(frozen=True)
class TokenRouterTransientResult:
    schema_version: str
    authorized_by_user: bool
    testing_environment_enabled: bool
    route: str
    endpoint_host: str
    model: str
    credential_source: str
    raw_key_recorded: bool
    direct_status: str
    direct_status_code: int | None
    direct_elapsed_ms: float | None
    direct_usage_seen: bool
    direct_content_chars: int
    provider_canary_status: str
    provider_canary_summary: dict[str, Any]
    errors: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class TokenRouterTransientSmoke:
    def __init__(
        self,
        root: pathlib.Path,
        *,
        http_post: Callable[[str, dict[str, str], bytes, float], tuple[int, bytes]] | None = None,
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.http_post = http_post or self._urllib_post

    def run(
        self,
        *,
        authorize_live_call: bool,
        run_provider_canary: bool = True,
        prompt: str = "ping",
        model: str = TOKENROUTER_MODEL,
        timeout_seconds: float = 30.0,
        environ: Mapping[str, str] | None = None,
    ) -> dict[str, Any]:
        env = os.environ if environ is None else environ
        errors: list[str] = []
        credential_source = "none"
        direct_status = "skipped"
        direct_status_code: int | None = None
        direct_elapsed_ms: float | None = None
        direct_usage_seen = False
        direct_content_chars = 0
        provider_status = "skipped"
        provider_summary: dict[str, Any] = {}

        try:
            if not authorize_live_call:
                raise TransientEnvironmentError("--authorize-live-call is required for TokenRouter live smoke")
            self._require_authorized_model(model, env)
            key = env.get("TOKENROUTER_API_KEY") or env.get("TOKENROUTER_KEY")
            if key:
                credential_source = "environment:TOKENROUTER_API_KEY_or_TOKENROUTER_KEY"
            else:
                key = TestingEnvironment.read_one_shot_credential(environ=env)
                credential_source = "one-shot-fd:CHIMERA_TEST_CREDENTIAL_FD"
        except Exception as exc:
            errors.append(str(exc))
            key = None

        if key:
            try:
                started = time.perf_counter()
                status_code, raw = self.http_post(
                    TOKENROUTER_ENDPOINT,
                    {
                        "Authorization": "Bearer " + key,
                        "Content-Type": "application/json",
                    },
                    json.dumps(self._payload(prompt, model=model), separators=(",", ":")).encode("utf-8"),
                    max(1.0, float(timeout_seconds)),
                )
                direct_elapsed_ms = round((time.perf_counter() - started) * 1000, 3)
                direct_status_code = status_code
                parsed = json.loads(raw.decode("utf-8", errors="replace")) if raw else {}
                direct_usage_seen = isinstance(parsed, dict) and isinstance(parsed.get("usage"), dict)
                direct_content_chars = len(self._extract_content(parsed))
                direct_status = "passed" if 200 <= status_code < 300 and direct_content_chars >= 0 else "failed"
            except urllib.error.HTTPError as exc:
                direct_status_code = exc.code
                direct_status = "failed"
                try:
                    body = exc.read().decode("utf-8", errors="replace")[:300]
                except Exception:
                    body = ""
                errors.append(f"direct HTTPError {exc.code}: {body}")
                lowered = body.lower()
                if exc.code in {429, 500, 502, 503, 504} and any(part in lowered for part in ("no available channel", "model_not_found", "overloaded", "rate")):
                    direct_status = "transient_unavailable"
                if exc.code in {402, 403} and any(part in lowered for part in ("insufficient_user_quota", "credit limit", "quota", "recharge")):
                    direct_status = "quota_exhausted"
            except Exception as exc:
                direct_status = "failed"
                errors.append(f"direct {type(exc).__name__}: {str(exc)[:300]}")

            if run_provider_canary:
                if direct_status == "passed":
                    provider_status, provider_summary = self._run_provider_canary(key)
                else:
                    provider_status = "skipped"
                    provider_summary = {"reason": "direct smoke did not pass", "direct_status": direct_status, "raw_key_recorded": False}

        result = TokenRouterTransientResult(
            schema_version="chimera.tokenrouter-transient-smoke.v1",
            authorized_by_user=bool(authorize_live_call),
            testing_environment_enabled=TestingEnvironment.enabled(env),
            route=str(env.get(TestingEnvironment.ROUTE, "")),
            endpoint_host="api.tokenrouter.com",
            model=model,
            credential_source=credential_source,
            raw_key_recorded=False,
            direct_status=direct_status,
            direct_status_code=direct_status_code,
            direct_elapsed_ms=direct_elapsed_ms,
            direct_usage_seen=direct_usage_seen,
            direct_content_chars=direct_content_chars,
            provider_canary_status=provider_status,
            provider_canary_summary=provider_summary,
            errors=tuple(errors),
        )
        return result.as_dict()

    @staticmethod
    def _payload(prompt: str, *, model: str = TOKENROUTER_MODEL) -> dict[str, Any]:
        return {
            "model": model,
            "messages": [{"role": "user", "content": str(prompt)}],
            "max_tokens": 64,
            "reasoning_effort": "low",
            "stream": False,
        }

    @staticmethod
    def _require_authorized_model(model: str, env: Mapping[str, str]) -> None:
        if env.get(TestingEnvironment.FLAG) != "1":
            raise TransientEnvironmentError(f"{TestingEnvironment.FLAG}=1 is required for transient live provider testing")
        if model not in ALLOWED_MODELS:
            raise TransientEnvironmentError("testing environment route does not authorize this model")
        route = env.get(TestingEnvironment.ROUTE)
        expected = MODEL_ROUTE_HINTS[model]
        # Backwards compatibility: the original Kimi route guard stays exact.
        # The newly user-authorized Nemotron lane uses its own route hint so a
        # Kimi-only CI job cannot accidentally spend on a different model.
        if route != expected:
            raise TransientEnvironmentError(f"{TestingEnvironment.ROUTE} must equal {expected}")

    @staticmethod
    def _extract_content(parsed: Any) -> str:
        try:
            choices = parsed.get("choices") if isinstance(parsed, dict) else None
            if isinstance(choices, list) and choices:
                message = choices[0].get("message") if isinstance(choices[0], dict) else None
                if isinstance(message, dict):
                    return str(message.get("content") or "")
        except Exception:
            pass
        return ""

    @staticmethod
    def _urllib_post(url: str, headers: dict[str, str], data: bytes, timeout: float) -> tuple[int, bytes]:
        request = urllib.request.Request(url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310 - explicit user-authorized live endpoint
            return int(response.status), response.read()

    def _run_provider_canary(self, key: str) -> tuple[str, dict[str, Any]]:
        # The provider runtime reads the conventional env names.  Mutate only
        # this process and restore immediately afterwards.
        previous_api = os.environ.get("TOKENROUTER_API_KEY")
        previous_key = os.environ.get("TOKENROUTER_KEY")
        os.environ["TOKENROUTER_API_KEY"] = key
        try:
            from .rlm import RLMRuntime

            runtime = RLMRuntime(self.root)
            try:
                canary = runtime.run_provider_canary(CHIMERA_PROVIDER_MODEL, ("strict_json",))
            finally:
                runtime.close()
            summary = {
                "capabilities": canary.get("capabilities", {}),
                "promoted": canary.get("promoted", []),
                "artifact": canary.get("artifact"),
                "raw_key_recorded": False,
            }
            return ("passed" if "strict_json" in summary["promoted"] else "failed"), summary
        except Exception as exc:
            return "failed", {"error": type(exc).__name__, "message": str(exc)[:300], "raw_key_recorded": False}
        finally:
            if previous_api is None:
                os.environ.pop("TOKENROUTER_API_KEY", None)
            else:
                os.environ["TOKENROUTER_API_KEY"] = previous_api
            if previous_key is None:
                os.environ.pop("TOKENROUTER_KEY", None)
            else:
                os.environ["TOKENROUTER_KEY"] = previous_key
