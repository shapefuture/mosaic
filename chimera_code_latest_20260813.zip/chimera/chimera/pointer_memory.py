"""Pointer-row memory with outcome-conditioned reinforcement.

A tiny middle path between no memory and heavy belief/causal memory: inject a
TOC row, fetch body only when needed, and bump only on unambiguous outcomes.
"""
from __future__ import annotations

import json, os, pathlib, time
from dataclasses import dataclass, asdict

@dataclass(frozen=True)
class PointerMemoryRow:
    id:str; activation:str; tags:tuple[str,...]; body_ref:str; successes:int=0; failures:int=0; updated_at:float=0.0; pinned:bool=False
    def as_dict(self): return asdict(self)

class PointerMemoryStore:
    def __init__(self, root:pathlib.Path):
        self.path=pathlib.Path(root)/".chimera"/"pointer-memory.json"; self.path.parent.mkdir(parents=True,exist_ok=True)
    def _read(self):
        try: return json.loads(self.path.read_text())
        except Exception: return {}
    def _write(self, rows):
        tmp=self.path.with_suffix('.tmp'); tmp.write_text(json.dumps(rows,sort_keys=True,indent=2)+"\n"); os.replace(tmp,self.path)
    def upsert(self,row:PointerMemoryRow):
        rows=self._read(); data=row.as_dict(); data['updated_at']=data['updated_at'] or time.time(); rows[row.id]=data; self._write(rows); return row
    def toc(self, limit:int=15):
        rows=list(self._read().values())
        rows.sort(key=lambda r:(not r.get('pinned',False), -(r.get('successes',0)+r.get('failures',0)), -r.get('updated_at',0), r.get('id','')))
        return [{k:r[k] for k in ('id','activation','tags','updated_at','successes','failures') if k in r} for r in rows[:limit]]
    def bump(self, surfaced_ids:list[str], outcome:str):
        if outcome not in {'success','failure'}: return []
        rows=self._read(); changed=[]
        for mid in surfaced_ids:
            if mid in rows:
                rows[mid]['successes' if outcome=='success' else 'failures']=int(rows[mid].get('successes' if outcome=='success' else 'failures',0))+1
                rows[mid]['updated_at']=time.time(); changed.append(mid)
        if changed:self._write(rows)
        return changed
