"""Fail-closed context-projection sidecars over an immutable transcript.

A cache state is a cost signal, never a reason to rewrite canonical history.
Projections summarize a covered prefix and are reused only while model, lineage,
cache key, and provider-visible prefix fingerprint all still match.
"""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import tempfile
import time
from typing import Any, Iterable, Mapping, Optional

from pydantic import BaseModel, ConfigDict, Field

from .artifacts import ContentAddressedArtifactStore
from .request_stability import StableRequestBuilder
from .wal import WAL


class FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ContextProjection(FrozenModel):
    schema_version: str = "chimera.context-projection.v1"
    session: str
    lineage: str
    model: str
    prompt_cache_key: str
    covered_count: int = Field(ge=1)
    covered_prefix_hash: str
    summary: str
    summary_hash: str
    projection_version: int = Field(ge=1)
    source_artifact_ref: str
    created_at: float


class ProjectionView(FrozenModel):
    projection: ContextProjection
    messages: tuple[dict[str, Any], ...]
    canonical_count: int
    projected_count: int


class ContextProjectionStore:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.dir = self.root / ".chimera" / "context-projections"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.artifacts = ContentAddressedArtifactStore(self.root)
        self.wal = WAL(self.root)

    @staticmethod
    def _safe_session(session: str) -> str:
        value = hashlib.sha256(session.encode()).hexdigest()[:24]
        return f"session-{value}.json"

    def _path(self, session: str) -> pathlib.Path:
        return self.dir / self._safe_session(session)

    @staticmethod
    def cache_key(session: str, lineage: str, model: str) -> str:
        raw = json.dumps(
            {"session": session, "lineage": lineage, "model": model},
            sort_keys=True, separators=(",", ":"),
        ).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    @staticmethod
    def _visible_messages(messages: Iterable[Mapping[str, Any]]) -> tuple[dict[str, Any], ...]:
        frozen = StableRequestBuilder.freeze(system=(), messages=messages, tools=(), params={})
        return tuple(frozen.payload()["messages"])

    @staticmethod
    def _prefix_hash(messages: tuple[dict[str, Any], ...], count: int) -> str:
        raw = json.dumps(messages[:count], sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    @staticmethod
    def _atomic_write(path: pathlib.Path, data: bytes) -> None:
        fd, raw = tempfile.mkstemp(prefix=".projection-", dir=path.parent)
        temp = pathlib.Path(raw)
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(data); handle.flush(); os.fsync(handle.fileno())
            os.replace(temp, path)
        finally:
            if temp.exists(): temp.unlink()

    def build(
        self,
        *,
        session: str,
        lineage: str,
        model: str,
        canonical_messages: Iterable[Mapping[str, Any]],
        covered_count: int,
        summary: str,
        evidence_refs: Iterable[str],
        now: Optional[float] = None,
    ) -> ContextProjection:
        visible = self._visible_messages(canonical_messages)
        if covered_count < 1 or covered_count > len(visible):
            raise ValueError("covered_count must select a non-empty canonical prefix")
        if not summary.strip():
            raise ValueError("projection summary is required; no mechanical fake summary is installed")
        refs = tuple(dict.fromkeys(str(item) for item in evidence_refs if str(item)))
        if not refs:
            raise ValueError("projection evidence refs are required")
        prior = self.load(session)
        version = 1 if prior is None else prior.projection_version + 1
        prefix_bytes = json.dumps(
            visible[:covered_count], sort_keys=True, separators=(",", ":"), ensure_ascii=False,
        ).encode()
        artifact = self.artifacts.put(
            prefix_bytes,
            media_type="application/vnd.chimera.provider-messages+json",
            provenance={"kind": "context-projection-source", "session": session, "version": version},
        )
        created = time.time() if now is None else float(now)
        projection = ContextProjection(
            session=session,
            lineage=lineage,
            model=model,
            prompt_cache_key=self.cache_key(session, lineage, model),
            covered_count=covered_count,
            covered_prefix_hash=self._prefix_hash(visible, covered_count),
            summary=summary,
            summary_hash="sha256:" + hashlib.sha256(summary.encode()).hexdigest(),
            projection_version=version,
            source_artifact_ref=f"artifact:{artifact.digest}",
            created_at=created,
        )
        payload = (projection.model_dump_json(indent=2) + "\n").encode()
        self._atomic_write(self._path(session), payload)
        self.wal.append("context_projection_built", {
            "session_hash": "sha256:" + hashlib.sha256(session.encode()).hexdigest(),
            "lineage_hash": "sha256:" + hashlib.sha256(lineage.encode()).hexdigest(),
            "model": model,
            "projection_version": version,
            "covered_count": covered_count,
            "covered_prefix_hash": projection.covered_prefix_hash,
            "summary_hash": projection.summary_hash,
            "source_artifact_ref": projection.source_artifact_ref,
            "evidence_root": "sha256:" + hashlib.sha256(json.dumps(sorted(refs)).encode()).hexdigest(),
        })
        return projection

    def load(self, session: str) -> Optional[ContextProjection]:
        path = self._path(session)
        if not path.exists(): return None
        try:
            return ContextProjection.model_validate_json(path.read_text())
        except Exception:
            return None

    def view_if_valid(
        self,
        *,
        session: str,
        lineage: str,
        model: str,
        canonical_messages: Iterable[Mapping[str, Any]],
    ) -> Optional[ProjectionView]:
        projection = self.load(session)
        if projection is None: return None
        if projection.lineage != lineage or projection.model != model:
            return None
        if projection.prompt_cache_key != self.cache_key(session, lineage, model):
            return None
        visible = self._visible_messages(canonical_messages)
        if len(visible) < projection.covered_count:
            return None
        if self._prefix_hash(visible, projection.covered_count) != projection.covered_prefix_hash:
            return None
        digest = projection.source_artifact_ref.removeprefix("artifact:")
        if not self.artifacts.has(digest):
            return None
        summary_message = {
            "role": "user",
            "content": f"<compaction-summary>\n{projection.summary}\n</compaction-summary>",
            "synthetic": True,
        }
        tail = visible[projection.covered_count:]
        messages = (summary_message, *tail)
        return ProjectionView(
            projection=projection,
            messages=messages,
            canonical_count=len(visible),
            projected_count=len(messages),
        )

    def invalidate(self, session: str, reason: str) -> None:
        # In-memory callers stop using the projection immediately. Keeping the
        # sidecar on disk is safe: view_if_valid still performs full validation.
        self.wal.append("context_projection_invalidated", {
            "session_hash": "sha256:" + hashlib.sha256(session.encode()).hexdigest(),
            "reason": reason,
        })
