"""Parallel research/context subagents with centralised output.

The orchestrator fans out to small bounded research adapters (local graph,
configured web/MCP/browser adapters in future) but returns one compact evidence
bundle to the main Chimera run.  It deliberately does not add new MCP tool
surfaces; callers use it internally or through existing run/session/GUI flows.
"""
from __future__ import annotations

import concurrent.futures
import hashlib
import json
import os
import pathlib
import re
import shlex
import subprocess
import time
from dataclasses import asdict, dataclass
from typing import Any, Protocol


@dataclass(frozen=True)
class ResearchHit:
    source: str
    title: str
    url: str | None
    text: str
    score: float

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ResearchBundle:
    schema_version: str
    query: str
    hits: tuple[ResearchHit, ...]
    context: str
    token_budget_chars: int
    elapsed_ms: float
    adapters: tuple[str, ...]
    omitted: int
    no_new_tool_surface: bool = True

    def as_dict(self) -> dict[str, Any]:
        return {
            **asdict(self),
            "hits": [hit.as_dict() for hit in self.hits],
        }


class ResearchAdapter(Protocol):
    name: str
    def search(self, query: str, *, limit: int) -> list[ResearchHit]: ...


class LocalGraphResearchAdapter:
    name = "local-code-graph"

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def search(self, query: str, *, limit: int) -> list[ResearchHit]:
        from .graph import CodeGraph
        graph = CodeGraph(self.root)
        try:
            graph.load()
        except Exception:
            graph.build(persist=False)
        hits = graph.search(query, limit=limit)
        out: list[ResearchHit] = []
        for row in hits:
            title = f"{row.get('kind')} {row.get('name')}"
            text = json.dumps({k: row.get(k) for k in ("file", "kind", "name", "qualified_name", "line", "description")}, sort_keys=True)
            out.append(ResearchHit(self.name, title, None, text, 1.0))
        return out


class StaticWebResearchAdapter:
    """Non-network adapter for tests and offline runs.

    Live web/MCP/browser search should be injected as another adapter by the
    deployment layer so secrets and network policy remain centralized.
    """
    name = "static-research-cache"

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.path = self.root / ".chimera" / "research-cache.jsonl"

    def search(self, query: str, *, limit: int) -> list[ResearchHit]:
        if not self.path.exists():
            return []
        terms = {item.lower() for item in re.findall(r"[a-zA-Z][a-zA-Z0-9_-]{2,}", query)}
        hits = []
        for line in self.path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            text = str(row.get("text", ""))
            title = str(row.get("title", "untitled"))
            score = sum(1 for term in terms if term in (title + " " + text).lower())
            if score:
                hits.append(ResearchHit(self.name, title, row.get("url"), text[:2000], float(score)))
        return sorted(hits, key=lambda hit: (-hit.score, hit.title))[:limit]


class ExaResearchAdapter:
    name = "exa-live-search"

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or os.environ.get("EXA_API_KEY")

    def search(self, query: str, *, limit: int) -> list[ResearchHit]:
        if not self.api_key:
            return []
        import httpx
        with httpx.Client(timeout=10.0, trust_env=False) as client:
            response = client.post(
                "https://api.exa.ai/search",
                headers={"x-api-key": self.api_key, "content-type": "application/json"},
                json={"query": query, "numResults": max(1, min(10, limit)), "type": "auto"},
            )
            response.raise_for_status()
            data = response.json()
        rows = data.get("results") if isinstance(data, dict) else []
        hits = []
        for row in rows[:limit] if isinstance(rows, list) else []:
            if not isinstance(row, dict):
                continue
            hits.append(ResearchHit(
                self.name,
                str(row.get("title") or row.get("url") or "exa-result"),
                str(row.get("url")) if row.get("url") else None,
                str(row.get("text") or row.get("snippet") or row.get("summary") or "")[:2000],
                float(row.get("score") or 1.0),
            ))
        return hits


class HeadlessBrowserResearchAdapter:
    name = "headless-browser-research"

    def __init__(self, command: str | None = None):
        self.command = command or os.environ.get("CHIMERA_HEADLESS_BROWSER_CMD")

    def search(self, query: str, *, limit: int) -> list[ResearchHit]:
        if not self.command:
            return []
        payload = json.dumps({"query": query, "limit": max(1, min(10, limit)), "network": True})
        result = subprocess.run(
            shlex.split(self.command),
            input=payload,
            capture_output=True,
            text=True,
            timeout=20,
            check=False,
            env={"PATH": os.environ.get("PATH", ""), "LANG": os.environ.get("LANG", "C.UTF-8")},
        )
        if result.returncode != 0:
            return [ResearchHit(self.name, "browser-adapter-error", None, result.stderr[-500:], 0.0)]
        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []
        rows = data.get("results") if isinstance(data, dict) else []
        hits = []
        for row in rows[:limit] if isinstance(rows, list) else []:
            if not isinstance(row, dict):
                continue
            hits.append(ResearchHit(
                self.name,
                str(row.get("title") or row.get("url") or "browser-result"),
                str(row.get("url")) if row.get("url") else None,
                str(row.get("text") or row.get("snippet") or "")[:2000],
                float(row.get("score") or 1.0),
            ))
        return hits


class ResearchContextOrchestrator:
    def __init__(self, root: pathlib.Path, adapters: list[ResearchAdapter] | None = None):
        self.root = pathlib.Path(root).resolve()
        if adapters is None:
            adapters = [LocalGraphResearchAdapter(self.root), StaticWebResearchAdapter(self.root)]
            if os.environ.get("EXA_API_KEY"):
                adapters.append(ExaResearchAdapter())
            if os.environ.get("CHIMERA_HEADLESS_BROWSER_CMD"):
                adapters.append(HeadlessBrowserResearchAdapter())
        self.adapters = adapters

    @staticmethod
    def _dedupe(hits: list[ResearchHit]) -> list[ResearchHit]:
        seen = set(); out = []
        for hit in sorted(hits, key=lambda item: (-item.score, item.source, item.title)):
            key = hashlib.sha256((hit.source + "\0" + (hit.url or "") + "\0" + hit.text[:500]).encode()).hexdigest()
            if key in seen:
                continue
            seen.add(key); out.append(hit)
        return out

    def gather(self, query: str, *, per_adapter: int = 5, max_workers: int = 4, token_budget_chars: int = 6000) -> ResearchBundle:
        started = time.perf_counter()
        max_workers = max(1, min(max_workers, len(self.adapters), int(os.environ.get("CHIMERA_RESEARCH_MAX_WORKERS", max_workers))))
        hits: list[ResearchHit] = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = [pool.submit(adapter.search, query, limit=per_adapter) for adapter in self.adapters]
            for future in concurrent.futures.as_completed(futures, timeout=20):
                try:
                    hits.extend(future.result())
                except Exception as exc:
                    hits.append(ResearchHit("adapter-error", type(exc).__name__, None, str(exc)[:500], 0.0))
        deduped = self._dedupe(hits)
        chunks = []
        used = 0
        selected = []
        for hit in deduped:
            row = f"[{hit.source}] {hit.title}\n{hit.text.strip()}\n"
            if used + len(row) > token_budget_chars:
                break
            chunks.append(row); selected.append(hit); used += len(row)
        return ResearchBundle(
            schema_version="chimera.research-context-bundle.v1",
            query=query,
            hits=tuple(selected),
            context="\n".join(chunks),
            token_budget_chars=token_budget_chars,
            elapsed_ms=round((time.perf_counter() - started) * 1000, 3),
            adapters=tuple(adapter.name for adapter in self.adapters),
            omitted=max(0, len(deduped) - len(selected)),
        )
