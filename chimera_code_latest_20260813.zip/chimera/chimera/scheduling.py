"""Historical-latency critical-path scheduling.

CPM activates only when every node has enough measured successful samples.
Otherwise callers retain their deterministic priority/topological fallback; no
model-supplied or hash-derived latency is treated as evidence.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import statistics
from dataclasses import dataclass
from typing import Any, Iterable

from .wal import WAL


class LatencyLedger:
    def __init__(self, root: pathlib.Path) -> None:
        self.wal = WAL(pathlib.Path(root))

    @staticmethod
    def fingerprint(agent_type: str, question: str) -> str:
        normalized = " ".join(str(question).lower().split())
        return "sha256:" + hashlib.sha256(
            json.dumps({"agent_type": agent_type, "question": normalized}, sort_keys=True).encode()
        ).hexdigest()

    def record(self, *, agent_type: str, question: str, duration_ms: float, success: bool) -> None:
        self.wal.append("node_latency", {
            "fingerprint": self.fingerprint(agent_type, question),
            "agent_type": agent_type,
            "duration_ms": max(0.0, float(duration_ms)),
            "success": bool(success),
        })

    def samples(self, agent_type: str, question: str) -> list[float]:
        fingerprint = self.fingerprint(agent_type, question)
        return [
            float(entry["data"]["duration_ms"])
            for entry in self.wal.replay(kind="node_latency")
            if entry.get("data", {}).get("fingerprint") == fingerprint
            and entry.get("data", {}).get("success") is True
        ]

    @staticmethod
    def _summary(rows: list[float], minimum_samples: int) -> dict[str, Any]:
        if len(rows) < minimum_samples:
            return {"status": "insufficient-data", "samples": len(rows), "median_ms": None, "p90_ms": None}
        ordered = sorted(rows)
        p90_index = min(len(ordered) - 1, max(0, int(0.9 * len(ordered)) - 1))
        return {
            "status": "measured", "samples": len(rows),
            "median_ms": statistics.median(rows), "p90_ms": ordered[p90_index],
        }

    def estimate(self, agent_type: str, question: str, *, minimum_samples: int = 3) -> dict[str, Any]:
        return self._summary(self.samples(agent_type, question), minimum_samples)

    def estimate_many(self, requests: Iterable[tuple[str, str]], *, minimum_samples: int = 3) -> dict[str, dict[str, Any]]:
        """Project the WAL once rather than once per DAG node."""
        fingerprints = {
            self.fingerprint(agent_type, question)
            for agent_type, question in requests
        }
        grouped: dict[str, list[float]] = {fingerprint: [] for fingerprint in fingerprints}
        for entry in self.wal.replay(kind="node_latency"):
            data = entry.get("data", {})
            fingerprint = data.get("fingerprint")
            if fingerprint in grouped and data.get("success") is True:
                grouped[fingerprint].append(float(data["duration_ms"]))
        return {
            fingerprint: self._summary(rows, minimum_samples)
            for fingerprint, rows in grouped.items()
        }


@dataclass(frozen=True)
class ScheduleEvidence:
    active: bool
    reason: str
    critical_path: tuple[str, ...]
    critical_length_ms: float
    remaining_ms: dict[str, float]
    samples: dict[str, int]


class HistoricalCPMScheduler:
    def __init__(self, ledger: LatencyLedger, *, minimum_samples: int = 3) -> None:
        self.ledger = ledger
        self.minimum_samples = minimum_samples

    def analyze(self, nodes: Iterable[Any]) -> ScheduleEvidence:
        rows = list(nodes)
        by_id = {node.id: node for node in rows}
        projected = self.ledger.estimate_many(
            ((node.agent_type, node.question) for node in rows),
            minimum_samples=self.minimum_samples,
        )
        estimates = {
            node.id: projected[self.ledger.fingerprint(node.agent_type, node.question)]
            for node in rows
        }
        samples = {node_id: int(value["samples"]) for node_id, value in estimates.items()}
        if not rows or any(value["status"] != "measured" for value in estimates.values()):
            return ScheduleEvidence(
                active=False, reason="historical latency coverage below minimum",
                critical_path=(), critical_length_ms=0.0, remaining_ms={}, samples=samples,
            )
        children: dict[str, list[str]] = {node.id: [] for node in rows}
        indegree = {node.id: 0 for node in rows}
        for node in rows:
            for dep in node.dependencies:
                if dep not in by_id:
                    raise ValueError(f"unknown dependency {dep!r}")
                children[dep].append(node.id)
                indegree[node.id] += 1
        frontier = sorted(node_id for node_id, degree in indegree.items() if degree == 0)
        topo: list[str] = []
        while frontier:
            current = frontier.pop(0)
            topo.append(current)
            for child in children[current]:
                indegree[child] -= 1
                if indegree[child] == 0:
                    frontier.append(child)
                    frontier.sort()
        if len(topo) != len(rows):
            raise ValueError("cannot schedule cyclic DAG")
        duration = {node_id: float(estimates[node_id]["median_ms"]) for node_id in by_id}
        remaining: dict[str, float] = {}
        next_on_path: dict[str, str | None] = {}
        for node_id in reversed(topo):
            if children[node_id]:
                child = max(children[node_id], key=lambda item: remaining[item])
                remaining[node_id] = duration[node_id] + remaining[child]
                next_on_path[node_id] = child
            else:
                remaining[node_id] = duration[node_id]
                next_on_path[node_id] = None
        root = max(topo, key=lambda item: remaining[item])
        path: list[str] = []
        current: str | None = root
        while current is not None:
            path.append(current)
            current = next_on_path[current]
        return ScheduleEvidence(
            active=True, reason="measured median latency CPM", critical_path=tuple(path),
            critical_length_ms=remaining[root], remaining_ms=remaining, samples=samples,
        )

    def execution_order(self, nodes: Iterable[Any]) -> tuple[list[list[Any]], ScheduleEvidence]:
        rows = list(nodes)
        evidence = self.analyze(rows)
        by_id = {node.id: node for node in rows}
        remaining_ids = set(by_id)
        done: set[str] = set()
        batches: list[list[Any]] = []
        while remaining_ids:
            ready = [
                by_id[node_id] for node_id in remaining_ids
                if set(by_id[node_id].dependencies) <= done
            ]
            if not ready:
                raise ValueError("Circular dependency in DAG")
            if evidence.active:
                ready.sort(key=lambda node: (-evidence.remaining_ms[node.id], -node.priority, node.id))
            else:
                ready.sort(key=lambda node: (-node.priority, node.id))
            batches.append(ready)
            for node in ready:
                remaining_ids.remove(node.id)
                done.add(node.id)
        return batches, evidence
