"""Explicit, dual-era remote Streamable-HTTP MCP client.

This module is intentionally an *adapter*, not an automatic runtime default.
It supports a caller that has already decided to expose a particular remote MCP
endpoint through Chimera's GCF proxy and task/capability policy.  It provides
only deterministic transport mechanics:

* 2026-07-28 per-request metadata/header construction;
* safe ``x-mcp-header`` schema projection for modern tool calls;
* bounded HTTP/SSE response parsing with no redirect following;
* ``server/discover`` negotiation and a narrow legacy-initialize fallback;
* exact, server-hinted public ``tools/list`` caching; and
* explicit, in-memory MRTR continuations and subscription event validation.

It does **not** persist credentials, automatically perform OAuth/DCR, replay a
possibly-effectful request, create a TOFU pin, or fulfil elicitation/sampling/
roots requests.  A caller must provide a separate explicit policy and human or
otherwise-authorized input path for those operations.
"""
from __future__ import annotations

import base64
import copy
from dataclasses import dataclass
import hashlib
import json
import secrets
import threading
import time
from typing import Any, Callable, Iterable, Iterator, Mapping
from urllib.parse import urlparse

import httpx

from .context_quarantine import RetrievedContentGuard
from .mcp_catalog_cache import CatalogCacheReceipt, MCPToolCatalogCache
from .mcp_health import MCPHealthLedger
from .schema_guard import validate_json_value
from .tool_attestation import ToolAttestation, ToolManifestAttestor, ToolManifestChangeDetector
from .trace_context import inject_trace_context_into_meta, trace_context_headers


MODERN_PROTOCOL_VERSION = "2026-07-28"
LEGACY_PROTOCOL_VERSIONS = ("2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05")
_MAX_SAFE_INTEGER = 2**53 - 1
_MAX_RESPONSE_BYTES = 2 * 1024 * 1024
_RESERVED_META_PREFIX = "io.modelcontextprotocol/"


class MCPRemoteError(RuntimeError):
    """Base error for a remote MCP transport or protocol failure."""


class MCPRemoteProtocolError(MCPRemoteError):
    """An endpoint response violates the selected MCP era's contract."""


class MCPRemotePolicyError(MCPRemoteError):
    """A caller attempted a prohibited or unsafe remote-MCP operation."""


@dataclass(frozen=True)
class MCPServerNegotiation:
    era: str  # modern | legacy
    protocol_version: str
    server_info: dict[str, Any] | None
    capabilities: dict[str, Any]
    supported_versions: tuple[str, ...]


@dataclass(frozen=True)
class MCPHeaderRule:
    name: str
    path: tuple[str, ...]
    value_type: str


@dataclass(frozen=True)
class MCPToolCatalog:
    tools: tuple[dict[str, Any], ...]
    attestation: ToolAttestation
    observed_state: str
    cache: CatalogCacheReceipt
    rejected_tools: tuple[dict[str, str], ...]


@dataclass(frozen=True)
class MCPMRTRNotice:
    continuation_id: str
    request_keys: tuple[str, ...]
    request_state_present: bool
    quarantined: bool
    quarantine_reasons: tuple[str, ...]
    expires_at: float


@dataclass(frozen=True)
class MCPSubscriptionAck:
    subscription_id: str
    tools_list_changed: bool


@dataclass
class _PendingMRTR:
    method: str
    params: dict[str, Any]
    request_state: str | None
    request_keys: tuple[str, ...]
    expires_at: float


class MCPMRTRContinuationStore:
    """In-memory, explicit continuation state for modern ``input_required``.

    Opaque ``requestState`` and caller-provided answers are never written to a
    WAL or log.  Registration never executes an input request; ``resume`` only
    creates the next JSON-RPC request parameters after an explicit caller has
    supplied answers for exactly the server-requested keys.
    """

    def __init__(self, *, ttl_seconds: float = 600.0, clock: Callable[[], float] = time.monotonic) -> None:
        self.ttl_seconds = max(1.0, float(ttl_seconds))
        self.clock = clock
        self._pending: dict[str, _PendingMRTR] = {}
        self._lock = threading.RLock()
        self._guard = RetrievedContentGuard()

    def register(self, *, method: str, params: Mapping[str, Any], result: Mapping[str, Any]) -> MCPMRTRNotice:
        if result.get("resultType") != "input_required":
            raise MCPRemoteProtocolError("MRTR registration requires resultType=input_required")
        if method not in {"tools/call", "resources/read", "prompts/get"}:
            raise MCPRemoteProtocolError(f"MRTR is not allowed for {method!r}")
        raw_requests = result.get("inputRequests", {})
        if not isinstance(raw_requests, Mapping) or not all(isinstance(key, str) and isinstance(value, Mapping) for key, value in raw_requests.items()):
            raise MCPRemoteProtocolError("input_required result has malformed inputRequests")
        request_state = result.get("requestState")
        if request_state is not None and not isinstance(request_state, str):
            raise MCPRemoteProtocolError("requestState must be an opaque string when present")
        # Treat upstream input instructions as untrusted content.  The notice
        # exposes only keys/reasons; direct callers that need the full schema
        # must inspect it under their own human/authorization boundary.
        rendered = json.dumps(raw_requests, sort_keys=True, default=str)
        decision = self._guard.inspect(rendered, source="remote-mcp-mrtr")
        continuation_id = "mrtr:" + secrets.token_urlsafe(24)
        expires_at = self.clock() + self.ttl_seconds
        pending = _PendingMRTR(
            method=method,
            params=copy.deepcopy(dict(params)),
            request_state=request_state,
            request_keys=tuple(sorted(raw_requests)),
            expires_at=expires_at,
        )
        with self._lock:
            self._purge_locked()
            self._pending[continuation_id] = pending
        return MCPMRTRNotice(
            continuation_id=continuation_id,
            request_keys=pending.request_keys,
            request_state_present=request_state is not None,
            quarantined=decision.quarantined,
            quarantine_reasons=decision.reasons,
            expires_at=expires_at,
        )

    def resume(self, continuation_id: str, input_responses: Mapping[str, Any]) -> tuple[str, dict[str, Any]]:
        if not isinstance(input_responses, Mapping):
            raise MCPRemotePolicyError("MRTR input responses must be an object")
        with self._lock:
            self._purge_locked()
            pending = self._pending.get(str(continuation_id))
            if pending is None:
                raise MCPRemotePolicyError("MRTR continuation is unknown, expired, or already consumed")
            keys = tuple(sorted(str(key) for key in input_responses))
            if keys != pending.request_keys:
                # A malformed answer must not consume the continuation; a
                # human/authorized caller can correct its response instead of
                # being forced to restart the upstream operation.
                raise MCPRemotePolicyError("MRTR input response keys must exactly match the server-requested keys")
            self._pending.pop(str(continuation_id), None)
        params = copy.deepcopy(pending.params)
        if "inputResponses" in params or "requestState" in params:
            raise MCPRemoteProtocolError("original MRTR request already contains continuation fields")
        params["inputResponses"] = copy.deepcopy(dict(input_responses))
        if pending.request_state is not None:
            params["requestState"] = pending.request_state
        return pending.method, params

    def discard(self, continuation_id: str) -> bool:
        with self._lock:
            self._purge_locked()
            return self._pending.pop(str(continuation_id), None) is not None

    def _purge_locked(self) -> None:
        now = self.clock()
        for key in tuple(self._pending):
            if self._pending[key].expires_at <= now:
                self._pending.pop(key, None)


class MCPHeaderProjector:
    """Validate/project the narrow 2026 ``x-mcp-header`` schema extension."""

    _TOKEN = set("!#$%&'*+-.^_`|~0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")

    @classmethod
    def rules_for_tool(cls, tool: Mapping[str, Any]) -> tuple[MCPHeaderRule, ...]:
        name = tool.get("name")
        schema = tool.get("inputSchema")
        if not isinstance(name, str) or not name:
            raise MCPRemoteProtocolError("tool has no non-empty name")
        if not isinstance(schema, Mapping):
            raise MCPRemoteProtocolError(f"tool {name!r} inputSchema must be an object")
        rules: list[MCPHeaderRule] = []
        seen: set[str] = set()

        def visit(node: Any, path: tuple[str, ...], *, static: bool) -> None:
            if not isinstance(node, Mapping):
                return
            annotation = node.get("x-mcp-header")
            if annotation is not None:
                if not static:
                    raise MCPRemoteProtocolError(
                        f"tool {name!r} x-mcp-header at {'.'.join(path) or '<root>'} is not statically reachable"
                    )
                if not isinstance(annotation, str) or not annotation or any(char not in cls._TOKEN for char in annotation):
                    raise MCPRemoteProtocolError(f"tool {name!r} has invalid x-mcp-header name")
                lowered = annotation.lower()
                if lowered in seen:
                    raise MCPRemoteProtocolError(f"tool {name!r} repeats x-mcp-header {annotation!r}")
                value_type = node.get("type")
                if value_type not in {"string", "integer", "boolean"}:
                    raise MCPRemoteProtocolError(
                        f"tool {name!r} x-mcp-header {annotation!r} must annotate string, integer, or boolean"
                    )
                if "$ref" in node or any(key in node for key in ("oneOf", "anyOf", "allOf", "not", "if", "then", "else")):
                    raise MCPRemoteProtocolError(
                        f"tool {name!r} x-mcp-header {annotation!r} cannot use $ref, composition, or conditionals"
                    )
                seen.add(lowered)
                rules.append(MCPHeaderRule(annotation, path, str(value_type)))
            properties = node.get("properties")
            if isinstance(properties, Mapping):
                for child_name, child in properties.items():
                    if isinstance(child_name, str):
                        visit(child, path + (child_name,), static=static)
            # A header below these schema branches is not statically reachable
            # through a pure ``properties`` path and must be rejected.
            for key in ("items", "prefixItems", "oneOf", "anyOf", "allOf", "not", "if", "then", "else", "$defs", "definitions", "patternProperties", "additionalProperties", "dependentSchemas"):
                value = node.get(key)
                if isinstance(value, Mapping):
                    visit(value, path + (f"<{key}>",), static=False)
                elif isinstance(value, list):
                    for index, child in enumerate(value):
                        visit(child, path + (f"<{key}:{index}>",), static=False)

        visit(schema, (), static=True)
        return tuple(rules)

    @staticmethod
    def _safe_header_value(value: str) -> str:
        plain = (
            bool(value)
            and value.strip(" \t") == value
            and not value.startswith("=?base64?")
            and not value.endswith("?=")
            and all(0x20 <= ord(char) <= 0x7E for char in value)
        )
        if plain:
            return value
        encoded = base64.b64encode(value.encode("utf-8")).decode("ascii")
        return f"=?base64?{encoded}?="

    @classmethod
    def project(cls, tool: Mapping[str, Any], arguments: Mapping[str, Any]) -> dict[str, str]:
        if not isinstance(arguments, Mapping):
            raise MCPRemotePolicyError("tool arguments must be an object")
        headers: dict[str, str] = {}
        for rule in cls.rules_for_tool(tool):
            current: Any = arguments
            missing = False
            for segment in rule.path:
                if not isinstance(current, Mapping) or segment not in current:
                    missing = True
                    break
                current = current[segment]
            if missing or current is None:
                continue
            if rule.value_type == "string":
                if not isinstance(current, str):
                    raise MCPRemotePolicyError(f"header argument {'.'.join(rule.path)} must be string")
                rendered = current
            elif rule.value_type == "boolean":
                if type(current) is not bool:
                    raise MCPRemotePolicyError(f"header argument {'.'.join(rule.path)} must be boolean")
                rendered = "true" if current else "false"
            else:
                if type(current) is not int or not (-_MAX_SAFE_INTEGER <= current <= _MAX_SAFE_INTEGER):
                    raise MCPRemotePolicyError(f"header argument {'.'.join(rule.path)} must be a safe integer")
                rendered = str(current)
            headers[f"Mcp-Param-{rule.name}"] = cls._safe_header_value(rendered)
        return headers

    @classmethod
    def standard_headers(cls, *, version: str, method: str, params: Mapping[str, Any]) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            "MCP-Protocol-Version": version,
            "Mcp-Method": method,
        }
        source: Any = None
        if method in {"tools/call", "prompts/get"}:
            source = params.get("name")
        elif method == "resources/read":
            source = params.get("uri")
        if source is not None:
            if not isinstance(source, str) or not source:
                raise MCPRemotePolicyError(f"{method} requires a non-empty header source value")
            headers["Mcp-Name"] = cls._safe_header_value(source)
        return headers


class MCPRemoteHTTPClient:
    """A no-credential-persistence remote MCP client with explicit negotiation."""

    def __init__(
        self,
        endpoint: str,
        *,
        client_name: str = "chimera",
        client_version: str = "4.4.0",
        client_capabilities: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
        timeout_seconds: float = 30.0,
        max_response_bytes: int = _MAX_RESPONSE_BYTES,
        allow_insecure_localhost: bool = False,
        http_client: httpx.Client | None = None,
        expected_manifest_hash: str | None = None,
        expected_tool_hashes: Mapping[str, str] | None = None,
        health_ledger: MCPHealthLedger | None = None,
        egress=None,
    ) -> None:
        parsed = urlparse(endpoint)
        localhost = parsed.hostname in {"localhost", "127.0.0.1", "::1"}
        if parsed.scheme not in {"https", "http"} or not parsed.netloc:
            raise ValueError("remote MCP endpoint must be an absolute http(s) URL")
        if parsed.scheme != "https" and not (allow_insecure_localhost and localhost):
            raise ValueError("remote MCP endpoint must use HTTPS unless explicit localhost override is enabled")
        if any(key.lower() in {"host", "content-length", "mcp-method", "mcp-name", "mcp-protocol-version"} for key in (headers or {})):
            raise ValueError("caller headers may not override transport-controlled MCP headers")
        self.endpoint = endpoint
        self.egress = egress
        if self.egress is None and http_client is None:
            raise ValueError("a common egress policy is required for live MCP transport")
        if self.egress is not None:
            self.egress.authorize(endpoint)
        self.client_name = str(client_name)
        self.client_version = str(client_version)
        self.client_capabilities = copy.deepcopy(dict(client_capabilities or {}))
        self.headers = {str(key): str(value) for key, value in (headers or {}).items()}
        self.timeout_seconds = max(0.1, float(timeout_seconds))
        self.max_response_bytes = max(1024, int(max_response_bytes))
        self._owned_client = http_client is None
        self._http = http_client or httpx.Client(
            timeout=httpx.Timeout(self.timeout_seconds),
            follow_redirects=False,
            trust_env=False,
        )
        self._lock = threading.RLock()
        self._next_id = 0
        self._negotiation: MCPServerNegotiation | None = None
        self._legacy_session_id: str | None = None
        self._catalog_cache = MCPToolCatalogCache()
        self._tools: dict[str, dict[str, Any]] = {}
        self._manifest_observer = ToolManifestChangeDetector()
        self.expected_manifest_hash = expected_manifest_hash
        self.expected_tool_hashes = dict(expected_tool_hashes or {})
        self.health_ledger = health_ledger
        self.mrtr = MCPMRTRContinuationStore()

    def close(self) -> None:
        if self._owned_client:
            self._http.close()

    def __enter__(self) -> "MCPRemoteHTTPClient":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    @property
    def negotiation(self) -> MCPServerNegotiation | None:
        return self._negotiation

    def negotiate(self) -> MCPServerNegotiation:
        with self._lock:
            if self._negotiation is not None:
                return self._negotiation
            modern_params = self._modern_params({})
            modern, status, _notifications, _headers = self._post(
                request_id=self._new_id(), method="server/discover", params=modern_params,
                version=MODERN_PROTOCOL_VERSION,
            )
            result = modern.get("result") if isinstance(modern, Mapping) else None
            if status == 200 and isinstance(result, Mapping) and result.get("resultType") == "complete":
                supported = tuple(str(item) for item in result.get("supportedVersions", ()) if isinstance(item, str))
                if MODERN_PROTOCOL_VERSION not in supported:
                    raise MCPRemoteProtocolError("modern server/discover did not advertise the requested protocol version")
                meta = result.get("_meta", {})
                info = meta.get(f"{_RESERVED_META_PREFIX}serverInfo") if isinstance(meta, Mapping) else None
                self._negotiation = MCPServerNegotiation(
                    era="modern", protocol_version=MODERN_PROTOCOL_VERSION,
                    server_info=copy.deepcopy(dict(info)) if isinstance(info, Mapping) else None,
                    capabilities=copy.deepcopy(dict(result.get("capabilities", {}))) if isinstance(result.get("capabilities"), Mapping) else {},
                    supported_versions=supported,
                )
                return self._negotiation
            error = modern.get("error") if isinstance(modern, Mapping) else None
            supported = ()
            if isinstance(error, Mapping) and error.get("code") == -32022:
                data = error.get("data", {})
                if isinstance(data, Mapping):
                    supported = tuple(str(item) for item in data.get("supported", ()) if isinstance(item, str))
            legacy = next((value for value in LEGACY_PROTOCOL_VERSIONS if value in supported), None)
            if legacy is None:
                # A legacy endpoint frequently emits a non-modern JSON-RPC 400
                # such as -32600. Only this narrow negotiation request may
                # fall back; arbitrary tool calls are never replayed.
                legacy = "2025-11-25"
            return self._initialize_legacy(legacy)

    def list_tools(self, *, cursor: str | None = None) -> MCPToolCatalog:
        negotiation = self.negotiate()
        params: dict[str, Any] = {}
        if cursor is not None:
            params["cursor"] = str(cursor)
        if negotiation.era == "modern":
            request_params = self._modern_params(params)
            cached, cache_receipt = self._catalog_cache.get(request_params)
            if cached is not None:
                response = {"jsonrpc": "2.0", "id": self._new_id(), "result": cached}
                return self._accept_catalog(response, cache_receipt)
        else:
            request_params = params
        response = self.request("tools/list", request_params)
        cache_receipt = CatalogCacheReceipt("bypass", "legacy catalog result")
        if negotiation.era == "modern":
            cache_receipt = self._catalog_cache.put(request_params, response)
        return self._accept_catalog(response, cache_receipt)

    def call_tool(self, name: str, arguments: Mapping[str, Any]) -> tuple[dict[str, Any], MCPMRTRNotice | None]:
        if not isinstance(name, str) or not name:
            raise MCPRemotePolicyError("tool name must be non-empty")
        if not isinstance(arguments, Mapping):
            raise MCPRemotePolicyError("tool arguments must be an object")
        negotiation = self.negotiate()
        if name not in self._tools:
            self.list_tools()
        tool = self._tools.get(name)
        if tool is None:
            raise MCPRemotePolicyError(f"tool {name!r} is not in the current remote catalog")
        base = {"name": name, "arguments": copy.deepcopy(dict(arguments))}
        extra_headers: dict[str, str] = {}
        if negotiation.era == "modern":
            extra_headers = MCPHeaderProjector.project(tool, arguments)
            params = self._modern_params(base)
        else:
            params = base
        response = self.request("tools/call", params, extra_headers=extra_headers)
        # A schema/header mismatch is a *response*, not proof that the remote
        # tool had no side effect. Refresh the read-only catalog, but never
        # replay a tools/call automatically: an endpoint may have performed the
        # effect and then emitted an error while constructing its response.
        error = response.get("error") if isinstance(response, Mapping) else None
        if negotiation.era == "modern" and isinstance(error, Mapping) and error.get("code") == -32020:
            if self.health_ledger is not None:
                self.health_ledger.observe(self.endpoint, method="tools/call", elapsed_ms=0.0, kind="schema_drift")
            self.notify_tools_list_changed()
            self.list_tools()  # catalog read only; no invocation replay
            response = {
                "jsonrpc": "2.0", "id": response.get("id"),
                "error": {
                    "code": -32025,
                    "message": "tool schema drift observed; invocation was not replayed automatically",
                    "data": {"tool": name, "reconciliation_required": True},
                },
            }
        elif isinstance(error, Mapping) and error.get("code") in {-32601, -32602}:
            self.notify_tools_list_changed()
        result = response.get("result") if isinstance(response, Mapping) else None
        output_schema = tool.get("outputSchema") if isinstance(tool, Mapping) else None
        if isinstance(result, Mapping) and isinstance(output_schema, Mapping) and "structuredContent" in result:
            violations = validate_json_value(output_schema, result.get("structuredContent"))
            if violations:
                if self.health_ledger is not None:
                    self.health_ledger.observe(self.endpoint, method="tools/call", elapsed_ms=0.0, kind="schema_drift")
                response = {
                    "jsonrpc": "2.0", "id": response.get("id"),
                    "error": {"code": -32024, "message": "tool structured output violated declared schema", "data": [violation.__dict__ for violation in violations[:8]]},
                }
                result = None
        notice = None
        if negotiation.era == "modern" and isinstance(result, Mapping) and result.get("resultType") == "input_required":
            notice = self.mrtr.register(method="tools/call", params=params, result=result)
        return response, notice

    def resume_mrtr(self, continuation_id: str, input_responses: Mapping[str, Any]) -> tuple[dict[str, Any], MCPMRTRNotice | None]:
        negotiation = self.negotiate()
        if negotiation.era != "modern":
            raise MCPRemotePolicyError("MRTR is available only for a modern MCP negotiation")
        method, params = self.mrtr.resume(continuation_id, input_responses)
        headers: dict[str, str] = {}
        if method == "tools/call":
            name = params.get("name")
            args = params.get("arguments", {})
            if isinstance(name, str) and isinstance(args, Mapping):
                tool = self._tools.get(name)
                if tool is None:
                    self.list_tools()
                    tool = self._tools.get(name)
                if tool is None:
                    raise MCPRemotePolicyError(f"tool {name!r} is no longer available for MRTR retry")
                headers = MCPHeaderProjector.project(tool, args)
        response = self.request(method, params, extra_headers=headers)
        result = response.get("result") if isinstance(response, Mapping) else None
        notice = None
        if isinstance(result, Mapping) and result.get("resultType") == "input_required":
            notice = self.mrtr.register(method=method, params=params, result=result)
        return response, notice

    def notify_tools_list_changed(self) -> int:
        self._tools.clear()
        return self._catalog_cache.invalidate()

    def listen_tools_list_changed(self, *, max_events: int | None = None) -> Iterator[dict[str, Any]]:
        """Yield validated modern tools-list change notifications synchronously.

        The caller controls the iterator lifetime; closing it closes the HTTP
        SSE response stream, which is the 2026 cancellation signal.  There is
        deliberately no background daemon, reconnect loop, or automatic retry.
        """
        negotiation = self.negotiate()
        if negotiation.era != "modern":
            raise MCPRemotePolicyError("subscriptions/listen requires a modern MCP negotiation")
        request_id = self._new_id()
        params = self._modern_params({"notifications": {"toolsListChanged": True}})
        headers = MCPHeaderProjector.standard_headers(
            version=MODERN_PROTOCOL_VERSION, method="subscriptions/listen", params=params,
        )
        headers.update(self.headers)
        body = {"jsonrpc": "2.0", "id": request_id, "method": "subscriptions/listen", "params": params}
        ack: MCPSubscriptionAck | None = None
        yielded = 0
        try:
            with self._http.stream("POST", self.endpoint, headers=headers, json=body, follow_redirects=False) as response:
                if response.status_code != 200:
                    raise MCPRemoteProtocolError(f"subscription endpoint returned HTTP {response.status_code}")
                if not response.headers.get("content-type", "").lower().startswith("text/event-stream"):
                    raise MCPRemoteProtocolError("subscription endpoint did not return SSE")
                for message in self._iter_sse_stream(response.iter_lines()):
                    ack, invalidated = self.validate_subscription_message(message, ack)
                    if invalidated:
                        yielded += 1
                        yield {"subscription_id": ack.subscription_id if ack else None, "invalidated": True}
                        if max_events is not None and yielded >= max(0, int(max_events)):
                            return
        except httpx.HTTPError as exc:
            raise MCPRemoteError(f"remote MCP subscription transport failed: {type(exc).__name__}") from exc

    def validate_subscription_message(self, message: Mapping[str, Any], ack: MCPSubscriptionAck | None) -> tuple[MCPSubscriptionAck | None, bool]:
        """Validate one modern subscription stream message without background I/O.

        Returns an updated acknowledgment and whether a verified
        ``tools/list_changed`` notification invalidated the exact catalog.
        """
        method = message.get("method")
        params = message.get("params", {})
        if not isinstance(params, Mapping):
            raise MCPRemoteProtocolError("subscription notification params must be an object")
        meta = params.get("_meta", {})
        subscription_id = meta.get(f"{_RESERVED_META_PREFIX}subscriptionId") if isinstance(meta, Mapping) else None
        if method == "notifications/subscriptions/acknowledged":
            notifications = params.get("notifications", {})
            if subscription_id is None or not isinstance(notifications, Mapping):
                raise MCPRemoteProtocolError("subscription acknowledgment is malformed")
            return MCPSubscriptionAck(str(subscription_id), bool(notifications.get("toolsListChanged"))), False
        if ack is None:
            raise MCPRemoteProtocolError("subscription notification arrived before acknowledgment")
        if str(subscription_id) != ack.subscription_id:
            raise MCPRemoteProtocolError("subscription notification has an unexpected subscription ID")
        if method == "notifications/tools/list_changed":
            if not ack.tools_list_changed:
                raise MCPRemoteProtocolError("server sent unrequested tools-list notification")
            self.notify_tools_list_changed()
            return ack, True
        return ack, False

    def request(self, method: str, params: Mapping[str, Any] | None = None, *, extra_headers: Mapping[str, str] | None = None) -> dict[str, Any]:
        negotiation = self.negotiate()
        raw_params = dict(params or {})
        if negotiation.era == "modern":
            # Public API methods pass modern params already; reject missing
            # metadata rather than silently creating a malformed request.
            meta = raw_params.get("_meta")
            if not isinstance(meta, Mapping) or meta.get(f"{_RESERVED_META_PREFIX}protocolVersion") != MODERN_PROTOCOL_VERSION:
                raise MCPRemoteProtocolError("modern MCP request is missing required _meta protocol metadata")
        request_id = self._new_id()
        response, status, _notifications, _headers = self._post(
            request_id=request_id, method=method, params=raw_params,
            version=negotiation.protocol_version, extra_headers=extra_headers,
        )
        if status < 200 or status >= 300:
            # Retain the JSON-RPC error shape for callers, but reject a non-JSON
            # HTTP response rather than allowing an HTML/proxy body downstream.
            if not isinstance(response, Mapping) or ("error" not in response and "result" not in response):
                raise MCPRemoteProtocolError(f"remote MCP returned HTTP {status} without JSON-RPC response")
        if not isinstance(response, dict):
            raise MCPRemoteProtocolError("remote MCP returned a non-object JSON-RPC message")
        return response

    def _initialize_legacy(self, version: str) -> MCPServerNegotiation:
        request_id = self._new_id()
        params = {
            "protocolVersion": version,
            "capabilities": {},
            "clientInfo": {"name": self.client_name, "version": self.client_version},
        }
        response, status, _notifications, headers = self._post(
            request_id=request_id, method="initialize", params=params, version=version,
        )
        result = response.get("result") if isinstance(response, Mapping) else None
        if status != 200 or not isinstance(result, Mapping):
            raise MCPRemoteProtocolError("remote MCP did not accept modern discovery or legacy initialize")
        actual = result.get("protocolVersion")
        if not isinstance(actual, str) or actual not in LEGACY_PROTOCOL_VERSIONS:
            raise MCPRemoteProtocolError("legacy MCP initialize returned an unsupported protocol version")
        session = headers.get("mcp-session-id")
        self._legacy_session_id = session if isinstance(session, str) and session else None
        # Notifications are only required for established session-era servers.
        # Sending it for a no-session endpoint can create an uncorrelated error,
        # so only send when the server minted the session header.
        if self._legacy_session_id:
            try:
                self._post(
                    request_id=None, method="notifications/initialized", params={}, version=actual,
                    is_notification=True,
                )
            except MCPRemoteError:
                self._legacy_session_id = None
                raise
        self._negotiation = MCPServerNegotiation(
            era="legacy", protocol_version=actual,
            server_info=copy.deepcopy(dict(result.get("serverInfo", {}))) if isinstance(result.get("serverInfo"), Mapping) else None,
            capabilities=copy.deepcopy(dict(result.get("capabilities", {}))) if isinstance(result.get("capabilities"), Mapping) else {},
            supported_versions=(actual,),
        )
        return self._negotiation

    def _modern_params(self, params: Mapping[str, Any]) -> dict[str, Any]:
        value = copy.deepcopy(dict(params))
        prior = value.get("_meta")
        if prior is not None and not isinstance(prior, Mapping):
            raise MCPRemotePolicyError("MCP params _meta must be an object")
        reserved = inject_trace_context_into_meta(prior if isinstance(prior, Mapping) else {})
        for key in tuple(reserved):
            if str(key).startswith(_RESERVED_META_PREFIX):
                reserved.pop(key)
        reserved.update({
            f"{_RESERVED_META_PREFIX}protocolVersion": MODERN_PROTOCOL_VERSION,
            f"{_RESERVED_META_PREFIX}clientInfo": {"name": self.client_name, "version": self.client_version},
            f"{_RESERVED_META_PREFIX}clientCapabilities": copy.deepcopy(self.client_capabilities),
        })
        value["_meta"] = reserved
        return value

    def _accept_catalog(self, response: Mapping[str, Any], cache: CatalogCacheReceipt) -> MCPToolCatalog:
        result = response.get("result")
        if not isinstance(result, Mapping) or not isinstance(result.get("tools"), list):
            raise MCPRemoteProtocolError("tools/list did not return a tools array")
        raw_tools = [dict(item) for item in result["tools"] if isinstance(item, Mapping)]
        attestation = ToolManifestAttestor.attest(raw_tools)
        observation = self._manifest_observer.observe(raw_tools)
        if self.expected_manifest_hash or self.expected_tool_hashes:
            verdict = ToolManifestAttestor.verify(
                raw_tools, expected_manifest_hash=self.expected_manifest_hash,
                expected_tool_hashes=self.expected_tool_hashes,
            )
            if not verdict.allowed:
                raise MCPRemotePolicyError("remote MCP tool manifest diverged from configured pin")
        admitted: list[dict[str, Any]] = []
        rejected: list[dict[str, str]] = []
        for tool in raw_tools:
            name = tool.get("name")
            if not isinstance(name, str) or not name:
                rejected.append({"name": "<invalid>", "reason": "missing tool name"})
                continue
            if self._negotiation and self._negotiation.era == "modern":
                try:
                    MCPHeaderProjector.rules_for_tool(tool)
                except MCPRemoteError as exc:
                    rejected.append({"name": name, "reason": str(exc)})
                    continue
            admitted.append(copy.deepcopy(tool))
        self._tools = {str(tool["name"]): tool for tool in admitted}
        return MCPToolCatalog(tuple(admitted), attestation, observation.state, cache, tuple(rejected))

    def _new_id(self) -> str:
        self._next_id += 1
        return f"chimera-mcp-{self._next_id}"

    def _post(
        self,
        *,
        request_id: str | None,
        method: str,
        params: Mapping[str, Any],
        version: str,
        extra_headers: Mapping[str, str] | None = None,
        is_notification: bool = False,
    ) -> tuple[dict[str, Any], int, list[dict[str, Any]], dict[str, str]]:
        started = time.perf_counter()
        if self.health_ledger is not None:
            decision = self.health_ledger.admit(self.endpoint)
            if not decision.allowed:
                raise MCPRemotePolicyError(decision.reason)
        headers = MCPHeaderProjector.standard_headers(version=version, method=method, params=params)
        headers.update(trace_context_headers())
        headers.update(self.headers)
        headers.update({str(key): str(value) for key, value in (extra_headers or {}).items()})
        if self._legacy_session_id:
            headers["Mcp-Session-Id"] = self._legacy_session_id
        body: dict[str, Any] = {"jsonrpc": "2.0", "method": method, "params": dict(params)}
        if not is_notification:
            body["id"] = request_id
        try:
            response = self._http.post(self.endpoint, headers=headers, json=body, follow_redirects=False)
        except httpx.HTTPError as exc:
            if self.health_ledger is not None:
                self.health_ledger.observe(self.endpoint, method=method, elapsed_ms=(time.perf_counter() - started) * 1000, kind="transport_failure")
            raise MCPRemoteError(f"remote MCP transport failed: {type(exc).__name__}") from exc
        output_headers = {str(key).lower(): str(value) for key, value in response.headers.items()}
        # A notification acknowledgement is explicitly an empty HTTP 202
        # response; do not force it through the JSON/SSE response decoder.
        if is_notification and response.status_code == 202:
            if self.health_ledger is not None:
                self.health_ledger.observe(self.endpoint, method=method, elapsed_ms=(time.perf_counter() - started) * 1000, kind="success")
            return {}, response.status_code, [], output_headers
        try:
            messages, notifications = self._decode_response(response, request_id)
        except MCPRemoteProtocolError:
            if self.health_ledger is not None:
                self.health_ledger.observe(self.endpoint, method=method, elapsed_ms=(time.perf_counter() - started) * 1000, kind="protocol_failure")
            raise
        if is_notification:
            raise MCPRemoteProtocolError(f"legacy notification returned HTTP {response.status_code}")
        final = next((item for item in reversed(messages) if item.get("id") == request_id), None)
        if not isinstance(final, dict) and method == "server/discover" and response.status_code >= 400:
            # Some legacy endpoints emit an implementation-defined error ID
            # (for example ``server-error``) when probed with a modern method.
            # Accept that *only* for the single era-detection request; normal
            # calls must retain strict JSON-RPC ID correlation.
            final = next((item for item in reversed(messages) if isinstance(item.get("error"), Mapping)), None)
        if not isinstance(final, dict):
            if self.health_ledger is not None:
                self.health_ledger.observe(self.endpoint, method=method, elapsed_ms=(time.perf_counter() - started) * 1000, kind="protocol_failure")
            raise MCPRemoteProtocolError("remote SSE/JSON response did not contain matching JSON-RPC ID")
        if self.health_ledger is not None:
            self.health_ledger.observe(self.endpoint, method=method, elapsed_ms=(time.perf_counter() - started) * 1000, kind="success")
        return final, response.status_code, notifications, output_headers

    def _decode_response(self, response: httpx.Response, request_id: str | None) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        raw = response.content
        if len(raw) > self.max_response_bytes:
            raise MCPRemoteProtocolError("remote MCP response exceeded configured byte limit")
        content_type = response.headers.get("content-type", "").lower()
        values: list[dict[str, Any]] = []
        if content_type.startswith("application/json"):
            try:
                value = response.json()
            except json.JSONDecodeError as exc:
                raise MCPRemoteProtocolError("remote MCP returned malformed JSON") from exc
            if not isinstance(value, dict):
                raise MCPRemoteProtocolError("remote MCP JSON response must be an object")
            values.append(value)
        elif content_type.startswith("text/event-stream"):
            values.extend(self._decode_sse(raw))
        else:
            raise MCPRemoteProtocolError(f"remote MCP returned unsupported content type {content_type!r}")
        notifications = [item for item in values if "method" in item and "id" not in item]
        return values, notifications

    def _iter_sse_stream(self, lines: Iterable[str]) -> Iterator[dict[str, Any]]:
        data_lines: list[str] = []
        total_bytes = 0
        for line in lines:
            if not isinstance(line, str):
                raise MCPRemoteProtocolError("remote MCP SSE line is not text")
            total_bytes += len(line.encode("utf-8", errors="replace")) + 1
            if total_bytes > self.max_response_bytes:
                raise MCPRemoteProtocolError("remote MCP subscription exceeded configured byte limit")
            if not line:
                if data_lines:
                    try:
                        value = json.loads("\n".join(data_lines))
                    except json.JSONDecodeError as exc:
                        raise MCPRemoteProtocolError("remote MCP subscription SSE data is not JSON") from exc
                    if not isinstance(value, dict):
                        raise MCPRemoteProtocolError("remote MCP subscription SSE event must be an object")
                    yield value
                    data_lines = []
                continue
            if line.startswith(":"):
                continue
            if line.startswith("data:"):
                data_lines.append(line[5:].lstrip(" "))
        if data_lines:
            try:
                value = json.loads("\n".join(data_lines))
            except json.JSONDecodeError as exc:
                raise MCPRemoteProtocolError("remote MCP subscription trailing SSE data is not JSON") from exc
            if not isinstance(value, dict):
                raise MCPRemoteProtocolError("remote MCP subscription SSE event must be an object")
            yield value

    @staticmethod
    def _decode_sse(raw: bytes) -> list[dict[str, Any]]:
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise MCPRemoteProtocolError("remote MCP SSE is not valid UTF-8") from exc
        values: list[dict[str, Any]] = []
        data_lines: list[str] = []
        for line in text.splitlines():
            if not line:
                if data_lines:
                    try:
                        value = json.loads("\n".join(data_lines))
                    except json.JSONDecodeError as exc:
                        raise MCPRemoteProtocolError("remote MCP SSE data is not JSON") from exc
                    if not isinstance(value, dict):
                        raise MCPRemoteProtocolError("remote MCP SSE event must be a JSON object")
                    values.append(value)
                    data_lines = []
                continue
            if line.startswith(":"):
                continue
            if line.startswith("data:"):
                data_lines.append(line[5:].lstrip(" "))
        if data_lines:
            try:
                value = json.loads("\n".join(data_lines))
            except json.JSONDecodeError as exc:
                raise MCPRemoteProtocolError("remote MCP trailing SSE data is not JSON") from exc
            if not isinstance(value, dict):
                raise MCPRemoteProtocolError("remote MCP SSE event must be a JSON object")
            values.append(value)
        if not values:
            raise MCPRemoteProtocolError("remote MCP SSE response contained no JSON-RPC event")
        return values


class MCPStreamableHTTPUpstream:
    """Adapt :class:`MCPRemoteHTTPClient` to the GCF proxy's upstream port.

    Construction is explicit; no Chimera runtime automatically opens a remote
    endpoint.  The outer ``GCFMCPProxy`` still applies its allowed-tool,
    attestation, wire-format, and WAL policies.
    """

    def __init__(self, client: MCPRemoteHTTPClient) -> None:
        self.client = client

    def request(self, payload: dict[str, Any]) -> dict[str, Any]:
        method = payload.get("method")
        if not isinstance(method, str) or not method:
            raise MCPRemoteProtocolError("upstream request has no method")
        params = payload.get("params") if isinstance(payload.get("params"), Mapping) else {}
        negotiation = self.client.negotiate()
        # The GCF proxy speaks transport-neutral JSON-RPC.  Add modern
        # per-request metadata here, rather than asking callers to know which
        # era an endpoint selected.  For calls, route through ``call_tool`` so
        # any validated x-mcp-header fields are mirrored correctly.
        if method == "tools/call":
            name = params.get("name")
            arguments = params.get("arguments", {})
            if not isinstance(name, str) or not isinstance(arguments, Mapping):
                raise MCPRemoteProtocolError("tools/call requires name and object arguments")
            response, _notice = self.client.call_tool(name, arguments)
        else:
            normalized = self.client._modern_params(params) if negotiation.era == "modern" else params
            response = self.client.request(method, normalized)
        # The remote client owns request IDs because an MRTR retry must have a
        # fresh ID. Preserve the caller's ID in the returned envelope only.
        response = copy.deepcopy(response)
        response["id"] = payload.get("id")
        return response

    def close(self) -> None:
        self.client.close()
