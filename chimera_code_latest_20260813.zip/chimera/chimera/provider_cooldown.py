"""Secret-free provider quota cooldown ledger."""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import time
from typing import Iterable


class ProviderCooldownLedger:
    def __init__(self, root: pathlib.Path):
        self.path = pathlib.Path(root) / ".chimera" / "provider-cooldowns.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def fingerprint(key: str) -> str:
        return "key:" + hashlib.sha256(key.encode()).hexdigest()[:24]

    def _read(self) -> dict[str, float]:
        try:
            value = json.loads(self.path.read_text())
            return {str(key): float(expiry) for key, expiry in value.items()}
        except (OSError, ValueError, json.JSONDecodeError):
            return {}

    def _write(self, rows: dict[str, float]) -> None:
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(rows, sort_keys=True) + "\n")
        os.replace(temp, self.path)

    def available(self, keys: Iterable[str], now: float | None = None) -> list[str]:
        now = time.time() if now is None else float(now)
        rows = self._read()
        active = {key: expiry for key, expiry in rows.items() if expiry > now}
        if active != rows:
            self._write(active)
        return [key for key in keys if active.get(self.fingerprint(key), 0.0) <= now]

    def cooldown(self, key: str, until: float) -> None:
        rows = self._read()
        rows[self.fingerprint(key)] = max(float(until), rows.get(self.fingerprint(key), 0.0))
        self._write(rows)
