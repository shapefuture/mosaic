"""Explicit route-specific terminal-cancellation capability canary.

Normal coding execution never invokes this module.  A positive receipt requires
more than closing a local socket: the adapter must provide a terminal provider
acknowledgement, cancelled outcome, and explicit billing/outcome semantics.
"""
from __future__ import annotations

import pathlib
import time
import uuid
from typing import Literal, Protocol

from pydantic import BaseModel, ConfigDict, Field

from .artifacts import ContentAddressedArtifactStore, ArtifactRef
from .wal import WAL


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ProviderTerminalEvent(_FrozenModel):
    terminal: bool
    outcome: Literal["cancelled", "completed", "failed", "unknown"]
    provider_acknowledged_cancel: bool = False
    billing_semantics: Literal["proven-stopped", "known-continues", "unknown"] = "unknown"
    detail: str = Field(default="", max_length=500)


class ProviderCancellationHandle(Protocol):
    def cancel(self, reason: str) -> ProviderTerminalEvent: ...
    def wait_terminal(self, timeout_seconds: float) -> ProviderTerminalEvent: ...


class CancellableProviderPort(Protocol):
    provider: str
    adapter_id: str
    def start_fixed_canary(self, *, model: str, request_id: str) -> ProviderCancellationHandle: ...


class ProviderCancellationCanaryReceipt(_FrozenModel):
    schema_version: str = "chimera.provider-cancellation-canary.v1"
    request_id: str
    provider: str
    adapter_id: str
    model: str
    cancel_event: ProviderTerminalEvent
    terminal_event: ProviderTerminalEvent
    capability_proven: bool
    reason: str
    created_at: float


class ProviderTerminalCancellationCanary:
    """Run only after an operator explicitly authorizes the exact live canary."""

    def __init__(self, root: pathlib.Path, *, artifacts: ContentAddressedArtifactStore | None = None):
        self.root = pathlib.Path(root).resolve()
        self.artifacts = artifacts or ContentAddressedArtifactStore(self.root)
        self.wal = WAL(self.root)

    def run(
        self,
        port: CancellableProviderPort,
        *,
        model: str,
        authorize_live_call: bool,
        cancel_after_seconds: float = 0.05,
        terminal_wait_seconds: float = 5.0,
    ) -> ProviderCancellationCanaryReceipt:
        if not authorize_live_call:
            raise PermissionError("provider cancellation canary requires explicit authorize_live_call=True")
        if cancel_after_seconds < 0 or terminal_wait_seconds <= 0:
            raise ValueError("invalid cancellation canary time bounds")
        request_id = "provider-cancel-canary:" + uuid.uuid4().hex
        handle = port.start_fixed_canary(model=model, request_id=request_id)
        if cancel_after_seconds:
            time.sleep(cancel_after_seconds)
        cancelled = handle.cancel("chimera fixed terminal-cancellation capability canary")
        terminal = handle.wait_terminal(terminal_wait_seconds)
        proven = bool(
            cancelled.terminal
            and terminal.terminal
            and (cancelled.provider_acknowledged_cancel or terminal.provider_acknowledged_cancel)
            and terminal.outcome == "cancelled"
            and terminal.billing_semantics == "proven-stopped"
        )
        reason = (
            "terminal provider cancellation, cancelled outcome, and billing stop were explicitly proven"
            if proven else
            "route cancellation is not proven; local cancellation/disconnect is insufficient"
        )
        receipt = ProviderCancellationCanaryReceipt(
            request_id=request_id,
            provider=str(port.provider),
            adapter_id=str(port.adapter_id),
            model=model,
            cancel_event=cancelled,
            terminal_event=terminal,
            capability_proven=proven,
            reason=reason,
            created_at=time.time(),
        )
        self.wal.append("provider_cancellation_canary", receipt.model_dump(mode="json"))
        return receipt

    def persist(self, receipt: ProviderCancellationCanaryReceipt) -> ArtifactRef:
        return self.artifacts.put(
            receipt.model_dump_json(indent=2),
            media_type="application/vnd.chimera.provider-cancellation-canary+json",
            provenance={"request_id": receipt.request_id, "provider": receipt.provider, "model": receipt.model},
        )
