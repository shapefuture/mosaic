"""Evidence-derived operational SLO snapshot and dependency-free dashboard."""

from __future__ import annotations

import html
import json
import math
import pathlib
from collections.abc import Mapping
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .core_primitives import atomic_write
from .wal import WAL


class SLOPolicy(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    provider_p95_ms: float = Field(default=120_000, gt=0)
    tool_p95_ms: float = Field(default=30_000, gt=0)
    verification_p95_ms: float = Field(default=120_000, gt=0)
    maximum_unknown_outcome_rate: float = Field(default=0.01, ge=0, le=1)
    maximum_quota_denial_rate: float = Field(default=0.20, ge=0, le=1)


def _percentile(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    return ordered[
        max(0, min(len(ordered) - 1, math.ceil(quantile * len(ordered)) - 1))
    ]


class OperationalSLO:
    def __init__(self, root: pathlib.Path, policy: SLOPolicy | None = None) -> None:
        self.root = pathlib.Path(root).resolve()
        self.wal = WAL(self.root)
        self.policy = policy or SLOPolicy()

    def snapshot(self) -> dict[str, Any]:
        rows = self.wal.replay()
        provider = []
        tools = []
        verification = []
        unknown = 0
        outcomes = 0
        quota_denials = 0
        quota_total = 0
        cache_hits = 0
        cache_total = 0
        for entry in rows:
            kind = str(entry.get("kind", ""))
            data = (
                entry.get("data", {}) if isinstance(entry.get("data"), Mapping) else {}
            )
            if kind in {"provider_qos", "provider_call"} and isinstance(
                data.get("latency_ms"), (int, float)
            ):
                provider.append(float(data["latency_ms"]))
            if kind in {"tool_trace", "action_execution_receipt"} and isinstance(
                data.get("duration_ms"), (int, float)
            ):
                tools.append(float(data["duration_ms"]))
            if kind in {"quality_gate", "verification"} and isinstance(
                data.get("duration_ms"), (int, float)
            ):
                verification.append(float(data["duration_ms"]))
            if kind == "effect_outbox" and data.get("event") == "receipt":
                outcomes += 1
                unknown += data.get("outcome") == "unknown"
            if kind == "tenant_quota":
                quota_total += 1
                quota_denials += not bool(data.get("allowed"))
            if kind in {"cache_projection", "prompt_cache"}:
                cache_total += 1
                cache_hits += data.get("status") in {"hit", "warm"}
        unknown_rate = unknown / outcomes if outcomes else None
        quota_rate = quota_denials / quota_total if quota_total else None
        metrics = {
            "provider_latency_ms": {
                "samples": len(provider),
                "p50": _percentile(provider, 0.5),
                "p95": _percentile(provider, 0.95),
            },
            "tool_latency_ms": {
                "samples": len(tools),
                "p50": _percentile(tools, 0.5),
                "p95": _percentile(tools, 0.95),
            },
            "verification_latency_ms": {
                "samples": len(verification),
                "p50": _percentile(verification, 0.5),
                "p95": _percentile(verification, 0.95),
            },
            "unknown_outcome_rate": unknown_rate,
            "quota_denial_rate": quota_rate,
            "cache_hit_rate": cache_hits / cache_total if cache_total else None,
            "wal_entries": len(rows),
        }
        breaches = []
        if (
            metrics["provider_latency_ms"]["p95"] is not None
            and metrics["provider_latency_ms"]["p95"] > self.policy.provider_p95_ms
        ):
            breaches.append("provider_p95")
        if (
            metrics["tool_latency_ms"]["p95"] is not None
            and metrics["tool_latency_ms"]["p95"] > self.policy.tool_p95_ms
        ):
            breaches.append("tool_p95")
        if (
            metrics["verification_latency_ms"]["p95"] is not None
            and metrics["verification_latency_ms"]["p95"]
            > self.policy.verification_p95_ms
        ):
            breaches.append("verification_p95")
        if (
            unknown_rate is not None
            and unknown_rate > self.policy.maximum_unknown_outcome_rate
        ):
            breaches.append("unknown_outcomes")
        if (
            quota_rate is not None
            and quota_rate > self.policy.maximum_quota_denial_rate
        ):
            breaches.append("quota_denials")
        return {
            "schema_version": "chimera.operational-slo.v1",
            "status": "breached" if breaches else "within_observed_limits",
            "metrics": metrics,
            "breaches": breaches,
            "limitations": [
                "missing samples remain unavailable rather than being treated as zero",
                "local WAL view is not a cloud metrics backend",
            ],
        }

    def write_dashboard(self, path: pathlib.Path) -> pathlib.Path:
        value = self.snapshot()
        rows = "".join(
            f"<tr><th>{html.escape(str(key))}</th><td><pre>{html.escape(json.dumps(item, indent=2))}</pre></td></tr>"
            for key, item in value["metrics"].items()
        )
        document = f"""<!doctype html><meta charset="utf-8"><title>Chimera SLO</title>
<style>body{{font:14px system-ui;margin:2rem;max-width:1000px}}table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #bbb;padding:.6rem;text-align:left}}pre{{margin:0;white-space:pre-wrap}}.status{{font-size:1.3rem;font-weight:700}}</style>
<h1>Chimera operational SLO</h1><p class="status">{html.escape(value["status"])}</p>
<table>{rows}</table><h2>Breaches</h2><pre>{html.escape(json.dumps(value["breaches"], indent=2))}</pre>
<h2>Limitations</h2><pre>{html.escape(json.dumps(value["limitations"], indent=2))}</pre>"""
        target = pathlib.Path(path)
        atomic_write(target, document.encode("utf-8"), mode=0o644)
        return target
