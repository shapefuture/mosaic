"""Content-addressed storage for complete tool and verification artifacts.

Prompt-facing results may be truncated for budget reasons, but evidence must not
be discarded.  The full bytes live under a SHA-256 address and are verified on
every read.  References, not large payloads, are suitable for WAL/model context.
"""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import time
import uuid
from dataclasses import asdict, dataclass
from typing import Any, Mapping


class ArtifactError(RuntimeError):
    """Base error for the content-addressed artifact store."""


class ArtifactIntegrityError(ArtifactError):
    """Stored bytes do not match the requested content address."""


@dataclass(frozen=True)
class ArtifactRef:
    digest: str
    size: int
    media_type: str
    provenance_digest: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class ContentAddressedArtifactStore:
    """Small local CAS with atomic writes and read-time integrity checks."""

    def __init__(self, root: pathlib.Path = pathlib.Path(".")) -> None:
        self.root = pathlib.Path(root).resolve()
        self.store = self.root / ".chimera" / "artifacts" / "sha256"
        self.store.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _digest(data: bytes) -> str:
        return "sha256:" + hashlib.sha256(data).hexdigest()

    @staticmethod
    def _canonical_hash(value: Mapping[str, Any]) -> str:
        encoded = json.dumps(dict(value), sort_keys=True, separators=(",", ":"), default=str).encode()
        return "sha256:" + hashlib.sha256(encoded).hexdigest()

    @staticmethod
    def _hex(digest: str) -> str:
        if not isinstance(digest, str) or not digest.startswith("sha256:"):
            raise ValueError("artifact digest must use sha256:<64 hex>")
        value = digest.removeprefix("sha256:")
        if len(value) != 64 or any(char not in "0123456789abcdef" for char in value.lower()):
            raise ValueError("artifact digest must use sha256:<64 hex>")
        return value.lower()

    def path_for(self, digest: str) -> pathlib.Path:
        value = self._hex(digest)
        return self.store / value[:2] / f"{value}.blob"

    def metadata_path_for(self, digest: str) -> pathlib.Path:
        return self.path_for(digest).with_suffix(".json")

    def attestation_path_for(self, digest: str, provenance_digest: str) -> pathlib.Path:
        value = self._hex(digest)
        provenance = self._hex(provenance_digest)
        return self.store / value[:2] / f"{value}.attestations" / f"{provenance}.json"

    @staticmethod
    def _atomic_write(path: pathlib.Path, data: bytes) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        try:
            with temporary.open("wb") as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, path)
        finally:
            if temporary.exists():
                temporary.unlink()

    def put(
        self,
        data: bytes | str,
        *,
        media_type: str = "application/octet-stream",
        provenance: Mapping[str, Any] | None = None,
    ) -> ArtifactRef:
        raw = data.encode() if isinstance(data, str) else data
        if not isinstance(raw, bytes):
            raise TypeError("artifact content must be bytes or str")
        provenance_value = dict(provenance or {})
        digest = self._digest(raw)
        provenance_digest = self._canonical_hash(provenance_value)
        ref = ArtifactRef(digest=digest, size=len(raw), media_type=media_type, provenance_digest=provenance_digest)
        blob = self.path_for(digest)
        if blob.exists():
            # Existing data is trusted only after re-verification.
            if self._digest(blob.read_bytes()) != digest:
                raise ArtifactIntegrityError(f"existing artifact is corrupt: {digest}")
        else:
            self._atomic_write(blob, raw)
        # Content metadata and provenance attestations have separate immutable
        # identities. The same bytes may legitimately be observed by multiple
        # workflows without the first writer silently replacing later provenance.
        metadata = {
            "schema_version": "chimera.artifact-metadata.v2",
            "digest": digest,
            "size": len(raw),
            "media_type": media_type,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        metadata["metadata_digest"] = self._canonical_hash(metadata)
        metadata_path = self.metadata_path_for(digest)
        if not metadata_path.exists():
            self._atomic_write(
                metadata_path,
                (json.dumps(metadata, sort_keys=True, indent=2) + "\n").encode(),
            )
        else:
            # Validate existing identity before adding another attestation and
            # preserve the content type chosen for the immutable content row.
            stored_metadata = self.metadata(digest)
            ref = ArtifactRef(
                digest=digest,
                size=len(raw),
                media_type=str(stored_metadata.get("media_type", media_type)),
                provenance_digest=provenance_digest,
            )
        attestation = {
            "schema_version": "chimera.artifact-attestation.v1",
            "digest": digest,
            "provenance": provenance_value,
            "provenance_digest": provenance_digest,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        attestation["attestation_digest"] = self._canonical_hash(attestation)
        attestation_path = self.attestation_path_for(digest, provenance_digest)
        if not attestation_path.exists():
            self._atomic_write(
                attestation_path,
                (json.dumps(attestation, sort_keys=True, indent=2, default=str) + "\n").encode(),
            )
        return ref

    def has(self, digest: str) -> bool:
        path = self.path_for(digest)
        if not path.exists():
            return False
        return self._digest(path.read_bytes()) == digest

    def get(self, digest: str) -> bytes:
        path = self.path_for(digest)
        if not path.exists():
            raise FileNotFoundError(digest)
        data = path.read_bytes()
        actual = self._digest(data)
        if actual != digest:
            raise ArtifactIntegrityError(f"artifact hash mismatch: requested={digest}, actual={actual}")
        return data

    def metadata(self, digest: str) -> dict[str, Any]:
        data = self.get(digest)
        path = self.metadata_path_for(digest)
        if not path.exists():
            raise FileNotFoundError(f"artifact metadata missing: {digest}")
        value = json.loads(path.read_text())
        if value.get("digest") != digest or int(value.get("size", -1)) != len(data):
            raise ArtifactIntegrityError(f"artifact metadata identity mismatch: {digest}")
        if value.get("schema_version") == "chimera.artifact-metadata.v2":
            claimed = value.get("metadata_digest")
            payload = {key: item for key, item in value.items() if key != "metadata_digest"}
            if claimed != self._canonical_hash(payload):
                raise ArtifactIntegrityError(f"artifact metadata envelope mismatch: {digest}")
        else:
            # Read-only compatibility for v1 metadata; new writes use v2 plus
            # separately addressed attestations.
            provenance = value.get("provenance", {})
            if not isinstance(provenance, dict) or value.get("provenance_digest") != self._canonical_hash(provenance):
                raise ArtifactIntegrityError(f"legacy artifact provenance mismatch: {digest}")
        attestations = []
        directory = self.path_for(digest).with_suffix(".attestations")
        for attestation_path in sorted(directory.glob("*.json")) if directory.exists() else []:
            row = json.loads(attestation_path.read_text())
            claimed = row.get("attestation_digest")
            payload = {key: item for key, item in row.items() if key != "attestation_digest"}
            if (
                row.get("digest") != digest
                or row.get("provenance_digest") != self._canonical_hash(row.get("provenance", {}))
                or claimed != self._canonical_hash(payload)
            ):
                raise ArtifactIntegrityError(f"artifact attestation mismatch: {attestation_path.name}")
            attestations.append(row)
        result = {**value, "attestations": attestations}
        if attestations:
            # Compatibility projection for callers that expect one provenance;
            # the complete v2 history remains in ``attestations``.
            result["provenance_digest"] = attestations[-1]["provenance_digest"]
            result["provenance"] = attestations[-1]["provenance"]
        return result
