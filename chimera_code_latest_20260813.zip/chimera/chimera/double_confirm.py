"""KIRA-style double-confirmation for high-risk or suspect completions.

This is deliberately opt-in/conditional because it costs one extra model turn.
It asks a second, constrained question after code-side gates have run.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Callable, Mapping
import json


@dataclass(frozen=True)
class DoubleConfirmResult:
    enabled: bool
    passed: bool | None
    reason: str
    raw_excerpt: str = ""
    def as_dict(self) -> dict[str, Any]: return asdict(self)


class DoubleConfirm:
    RISK_WORDS = ("auth", "security", "credential", "payment", "permission", "delete", "migration", "deploy")

    @classmethod
    def should_run(cls, *, task: str, completion_gate: Mapping[str, Any] | None = None, forced: bool = False) -> bool:
        if forced:
            return True
        if completion_gate and completion_gate.get("allowed") is False:
            return True
        lower = task.lower()
        return any(word in lower for word in cls.RISK_WORDS)

    @staticmethod
    def _json(text: str) -> dict[str, Any] | None:
        decoder = json.JSONDecoder()
        for i, ch in enumerate(text or ""):
            if ch == "{":
                try:
                    value, _ = decoder.raw_decode(text[i:])
                    if isinstance(value, dict): return value
                except json.JSONDecodeError:
                    pass
        return None

    def run(self, *, task: str, answer: str, verification: Mapping[str, Any] | None, provider: Callable[[str], Mapping[str, Any]], forced: bool = False, completion_gate: Mapping[str, Any] | None = None) -> DoubleConfirmResult:
        if not self.should_run(task=task, completion_gate=completion_gate, forced=forced):
            return DoubleConfirmResult(False, None, "not high-risk and completion gate did not object")
        prompt = (
            "You are a completion verifier. Return ONLY JSON with keys "
            "passed:boolean and reason:string. Check whether the answer is fully supported by the verification evidence.\n"
            f"TASK:\n{task[:2000]}\nANSWER:\n{answer[:2000]}\nVERIFICATION:\n{json.dumps(dict(verification or {}), sort_keys=True, default=str)[:2000]}"
        )
        try:
            row = provider(prompt)
            text = str(row.get("answer", "")) if isinstance(row, Mapping) else str(row)
            parsed = self._json(text)
            if isinstance(parsed, dict) and isinstance(parsed.get("passed"), bool):
                return DoubleConfirmResult(True, bool(parsed["passed"]), str(parsed.get("reason", ""))[:300], text[:300])
            # Conservative fallback: require an explicit negative word to fail; otherwise flag unknown but non-blocking.
            lower = text.lower()
            if "fail" in lower or "unsupported" in lower or "no" == lower.strip():
                return DoubleConfirmResult(True, False, "model-side confirmation rejected completion", text[:300])
            return DoubleConfirmResult(True, None, "confirmation returned unparseable response", text[:300])
        except Exception as exc:
            return DoubleConfirmResult(True, None, f"confirmation_error:{type(exc).__name__}", "")
