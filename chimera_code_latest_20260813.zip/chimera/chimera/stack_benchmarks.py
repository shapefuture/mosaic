"""Local benchmark receipts for optional stack alternatives.

These benchmarks are intentionally modest and dependency-light.  They establish
schema, promotion gates, and local baselines while skipping uninstalled external
systems honestly.  Heavier adapters can plug into the same receipt shape later.
"""
from __future__ import annotations

import json
import pathlib
import shutil
import statistics
import tempfile
import time
from dataclasses import asdict, dataclass
from typing import Any, Callable, Iterable


@dataclass(frozen=True)
class BenchResult:
    candidate: str
    status: str  # ran | skipped | failed
    reason: str
    operations: int
    elapsed_ms: float | None
    p50_ms: float | None
    p95_ms: float | None
    p99_ms: float | None
    ops_per_second: float | None
    details: dict[str, Any]


def _percentile(values: list[float], pct: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, int(round((pct / 100.0) * (len(ordered) - 1)))))
    return round(ordered[index], 6)


def _summary(candidate: str, timings_ms: list[float], details: dict[str, Any] | None = None) -> BenchResult:
    elapsed = sum(timings_ms)
    ops = len(timings_ms)
    return BenchResult(
        candidate=candidate,
        status="ran",
        reason="ok",
        operations=ops,
        elapsed_ms=round(elapsed, 6),
        p50_ms=_percentile(timings_ms, 50),
        p95_ms=_percentile(timings_ms, 95),
        p99_ms=_percentile(timings_ms, 99),
        ops_per_second=round(1000.0 * ops / elapsed, 3) if elapsed > 0 else None,
        details=details or {},
    )


def _skipped(candidate: str, reason: str, details: dict[str, Any] | None = None) -> BenchResult:
    return BenchResult(candidate, "skipped", reason, 0, None, None, None, None, None, details or {})


class StackBenchmarkRunner:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def event_bus(self, *, candidates: Iterable[str] = ("jsonl", "nats", "redpanda", "honker", "forq", "smoothmq", "pgmq"), operations: int = 1000) -> dict[str, Any]:
        results: list[BenchResult] = []
        for candidate in candidates:
            name = candidate.strip().lower()
            if name in {"jsonl", "wal", "local"}:
                results.append(self._bench_jsonl_event_bus(max(1, int(operations))))
            elif name == "nats":
                results.append(_skipped("nats", "nats-server not detected; external service benchmark not run", {"install_probe": "nats-server", "available": shutil.which("nats-server") is not None}))
            elif name == "redpanda":
                results.append(_skipped("redpanda", "redpanda not detected; Kafka-compatible external benchmark not run", {"install_probe": "redpanda", "available": shutil.which("redpanda") is not None}))
            elif name == "honker":
                results.append(_skipped("honker", "Honker SQLite extension not supplied; queue/stream only", {"semantic_warning": "queue tier, not durable workflow"}))
            elif name == "forq":
                results.append(_skipped("forq", "Forq HTTP queue endpoint/binary not supplied", {"available": shutil.which("forq") is not None, "semantic_warning": "queue tier only"}))
            elif name == "smoothmq":
                results.append(_skipped("smoothmq", "SmoothMQ SQS-compatible endpoint/binary not supplied", {"available": shutil.which("smoothmq") is not None, "semantic_warning": "queue tier only"}))
            elif name == "pgmq":
                results.append(_skipped("pgmq", "PGMQ requires configured Postgres extension", {"psql": shutil.which("psql") is not None, "semantic_warning": "queue tier only; keeps Postgres"}))
            else:
                results.append(_skipped(name, "unknown candidate"))
        return self._receipt("chimera.event-bus-benchmark.v1", results, "event-bus")

    def cache(self, *, candidates: Iterable[str] = ("memory", "valkey", "dragonfly", "garnet"), operations: int = 1000) -> dict[str, Any]:
        results: list[BenchResult] = []
        for candidate in candidates:
            name = candidate.strip().lower()
            if name in {"memory", "dict", "local"}:
                results.append(self._bench_memory_cache(max(1, int(operations))))
            elif name in {"redis", "valkey"}:
                results.append(_skipped("valkey", "valkey-server/redis endpoint not configured; external cache benchmark not run", {"valkey_server": shutil.which("valkey-server") is not None, "redis_server": shutil.which("redis-server") is not None}))
            elif name == "dragonfly":
                results.append(_skipped("dragonfly", "dragonfly binary not detected; external cache benchmark not run", {"available": shutil.which("dragonfly") is not None}))
            elif name == "garnet":
                results.append(_skipped("garnet", "GarnetServer binary not detected; external cache benchmark not run", {"available": shutil.which("GarnetServer") is not None}))
            else:
                results.append(_skipped(name, "unknown candidate"))
        return self._receipt("chimera.cache-benchmark.v1", results, "cache")

    def gateway(self, *, candidates: Iterable[str] = ("direct-mock", "litellm", "agentgateway", "agentify-gateway", "bifrost", "aisix"), operations: int = 1000, endpoint: str | None = None, model: str = "mock") -> dict[str, Any]:
        results: list[BenchResult] = []
        for candidate in candidates:
            name = candidate.strip().lower()
            if name in {"direct", "direct-mock", "mock"}:
                results.append(self._bench_direct_mock_gateway(max(1, int(operations))))
            elif name in {"http", "openai-http"}:
                results.append(self._bench_http_gateway(max(1, int(operations)), endpoint=endpoint, model=model))
            elif name == "litellm":
                results.append(_skipped("litellm", "LiteLLM endpoint not supplied; live/proxy benchmark not run", {"python_module": self._has_module("litellm")}))
            elif name == "agentgateway":
                results.append(_skipped("agentgateway", "agentgateway endpoint/binary not supplied", {"available": shutil.which("agentgateway") is not None}))
            elif name in {"agentify", "agentify-gateway", "tensorzero", "tensorzero-gateway"}:
                results.append(_skipped("agentify-gateway", "Agentify Gateway endpoint/binary not supplied; candidate recorded from agentify-sh/gateway without cloning", {"agentify_gateway": shutil.which("agentify-gateway") is not None, "tensorzero_gateway": shutil.which("tensorzero-gateway") is not None, "generic_gateway_binary": shutil.which("gateway") is not None, "derived_from": "TensorZero", "maintenance_status": "conservative maintenance; no release observed in search result"}))
            elif name == "bifrost":
                results.append(_skipped("bifrost", "bifrost endpoint/binary not supplied", {"available": shutil.which("bifrost") is not None}))
            elif name == "aisix":
                results.append(_skipped("aisix", "aisix endpoint/binary not supplied", {"available": shutil.which("aisix") is not None}))
            else:
                results.append(_skipped(name, "unknown candidate"))
        return self._receipt("chimera.gateway-benchmark.v1", results, "gateway")

    def durable(self, *, candidates: Iterable[str] = ("local-step", "restate", "dbos", "obelisk", "go-workflows", "pg-durable", "honker", "rivet-actors", "orch8", "durable-workflow-server", "durabletask-go", "wippy"), operations: int = 1000) -> dict[str, Any]:
        results: list[BenchResult] = []
        for candidate in candidates:
            name = candidate.strip().lower()
            if name in {"local", "local-step", "sqlite-step"}:
                results.append(self._bench_local_durable_step(max(1, int(operations))))
            elif name == "restate":
                results.append(_skipped("restate", "Restate endpoint/binary not configured for benchmark", {"available": shutil.which("restate-server") is not None}))
            elif name == "dbos":
                results.append(_skipped("dbos", "DBOS benchmark requires explicit SQLite/Postgres workflow setup", {"python_module": self._has_module("dbos")}))
            elif name == "obelisk":
                results.append(_skipped("obelisk", "Obelisk binary/component not supplied; semantic candidate only", {"available": shutil.which("obelisk") is not None}))
            elif name in {"go-workflows", "goworkflows"}:
                results.append(_skipped("go-workflows", "Go adapter not implemented in Chimera; candidate recorded", {"go": shutil.which("go") is not None}))
            elif name in {"pg-durable", "pg_durable"}:
                results.append(_skipped("pg-durable", "Postgres extension benchmark requires configured database", {"psql": shutil.which("psql") is not None}))
            elif name == "honker":
                results.append(_skipped("honker", "Honker is queue/stream only; extension not supplied", {"semantic_warning": "not a full durable workflow replacement"}))
            elif name in {"rivet", "rivet-actors"}:
                results.append(_skipped("rivet-actors", "Rivet engine/client not supplied; TypeScript-first actor candidate", {"available": shutil.which("rivet") is not None, "semantic_warning": "actor/keyed-state tier, not plain workflow"}))
            elif name == "orch8":
                results.append(_skipped("orch8", "Orch8 engine not supplied; early/BUSL candidate", {"available": shutil.which("orch8") is not None}))
            elif name in {"durable-workflow", "durable-workflow-server"}:
                results.append(_skipped("durable-workflow-server", "Durable Workflow Server not supplied; beta/watchlist", {"available": shutil.which("durable-workflow") is not None}))
            elif name in {"durabletask-go", "durable-task-go"}:
                results.append(_skipped("durabletask-go", "Durable Task Go sidecar not wired; work-in-progress", {"go": shutil.which("go") is not None}))
            elif name == "wippy":
                results.append(_skipped("wippy", "Wippy runtime not supplied; verify self-contained durability first", {"available": shutil.which("wippy") is not None}))
            else:
                results.append(_skipped(name, "unknown candidate"))
        return self._receipt("chimera.durable-benchmark.v1", results, "durable-execution")

    def sandbox(self, *, candidates: Iterable[str] = ("local-process", "wasmtime", "crun", "youki", "cubesandbox", "hyperlight-wasm", "sandlock", "agentjail", "kata-cloud-hypervisor", "matchlock", "boxlite", "cocoon", "openshell", "ai-jail-greywall"), operations: int = 100) -> dict[str, Any]:
        results: list[BenchResult] = []
        for candidate in candidates:
            name = candidate.strip().lower()
            if name in {"local", "local-process", "process"}:
                results.append(self._bench_local_process_spawn(max(1, min(1000, int(operations)))))
            elif name == "wasmtime":
                results.append(_skipped("wasmtime", "wasmtime binary/WIT tool component not supplied", {"available": shutil.which("wasmtime") is not None}))
            elif name in {"crun", "youki"}:
                results.append(_skipped(name, "fast OCI runtime candidate only; not gVisor-equivalent for hostile code", {"available": shutil.which(name) is not None, "semantic_warning": "shared host kernel"}))
            elif name == "cubesandbox":
                results.append(_skipped("cubesandbox", "CubeSandbox service not installed/configured", {"available": shutil.which("cubesandbox") is not None}))
            elif name in {"hyperlight", "hyperlight-wasm"}:
                results.append(_skipped("hyperlight-wasm", "Hyperlight guest/function not supplied", {"available": shutil.which("hyperlight") is not None}))
            elif name in {"sandlock", "agentjail", "sandlock-agentjail"}:
                results.append(_skipped(name, "process sandbox not installed or escape suite not configured", {"sandlock": shutil.which("sandlock") is not None, "agentjail": shutil.which("agentjail") is not None, "semantic_warning": "Landlock/seccomp layer, not full microVM"}))
            elif name in {"kata-cloud-hypervisor", "kata", "cloud-hypervisor"}:
                results.append(_skipped("kata-cloud-hypervisor", "Kata/Cloud Hypervisor not configured", {"kata_runtime": shutil.which("kata-runtime") is not None, "cloud_hypervisor": shutil.which("cloud-hypervisor") is not None, "semantic_warning": "hostile OCI baseline if KVM available"}))
            elif name == "matchlock":
                results.append(_skipped("matchlock", "Matchlock not installed/configured", {"available": shutil.which("matchlock") is not None, "semantic_warning": "experimental local Firecracker wrapper"}))
            elif name == "boxlite":
                results.append(_skipped("boxlite", "BoxLite not installed/configured", {"available": shutil.which("boxlite") is not None, "semantic_warning": "embedded microVM; verify host jailer"}))
            elif name == "cocoon":
                results.append(_skipped("cocoon", "Cocoon microVM engine not installed/configured", {"available": shutil.which("cocoon") is not None}))
            elif name == "openshell":
                results.append(_skipped("openshell", "OpenShell not installed/configured", {"available": shutil.which("openshell") is not None, "semantic_warning": "policy layer, shared kernel"}))
            elif name in {"ai-jail", "greywall", "ai-jail-greywall"}:
                results.append(_skipped("ai-jail-greywall", "ai-jail/Greywall not installed/configured", {"ai_jail": shutil.which("ai-jail") is not None, "greywall": shutil.which("greywall") is not None, "semantic_warning": "bwrap/Landlock/seccomp composition, not VM"}))
            else:
                results.append(_skipped(name, "unknown candidate"))
        return self._receipt("chimera.sandbox-benchmark.v1", results, "sandbox")

    def _bench_local_durable_step(self, operations: int) -> BenchResult:
        state: dict[str, int] = {}
        timings: list[float] = []
        for i in range(operations):
            start = time.perf_counter()
            key = f"step-{i}"
            if key not in state:
                state[key] = i
            _ = state[key]
            timings.append((time.perf_counter() - start) * 1000)
        return _summary("local-step", timings, {"semantic_level": "idempotent in-memory baseline only", "durable": False})

    def _bench_local_process_spawn(self, operations: int) -> BenchResult:
        import subprocess, sys
        timings: list[float] = []
        for _ in range(operations):
            start = time.perf_counter()
            proc = subprocess.run([sys.executable, "-c", "pass"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
            if proc.returncode != 0:
                return BenchResult("local-process", "failed", "subprocess failed", len(timings), None, None, None, None, None, {})
            timings.append((time.perf_counter() - start) * 1000)
        return _summary("local-process", timings, {"isolation": "none", "semantic_level": "spawn overhead baseline only"})

    def _bench_jsonl_event_bus(self, operations: int) -> BenchResult:
        timings: list[float] = []
        with tempfile.TemporaryDirectory(prefix="chimera-event-bench-") as td:
            path = pathlib.Path(td) / "events.jsonl"
            for i in range(operations):
                payload = json.dumps({"seq": i, "kind": "bench", "data": {"value": i}}, separators=(",", ":")) + "\n"
                start = time.perf_counter()
                with path.open("a", encoding="utf-8") as handle:
                    handle.write(payload)
                timings.append((time.perf_counter() - start) * 1000)
            replay_start = time.perf_counter()
            rows = path.read_text(encoding="utf-8").splitlines()
            replay_ms = (time.perf_counter() - replay_start) * 1000
        result = _summary("jsonl", timings, {"replay_rows": len(rows), "replay_ms": round(replay_ms, 6), "fsync": False})
        return result

    def _bench_memory_cache(self, operations: int) -> BenchResult:
        store: dict[str, str] = {}
        timings: list[float] = []
        for i in range(operations):
            key = f"k{i}"
            start = time.perf_counter()
            store[key] = str(i)
            _ = store[key]
            timings.append((time.perf_counter() - start) * 1000)
        return _summary("memory", timings, {"items": len(store), "kind": "python-dict-baseline"})


    def _bench_http_gateway(self, operations: int, *, endpoint: str | None, model: str) -> BenchResult:
        if not endpoint:
            return _skipped("http", "--endpoint is required for HTTP gateway benchmark")
        import urllib.request, urllib.error
        timings: list[float] = []
        errors = 0
        for i in range(operations):
            payload = json.dumps({"model": model, "messages": [{"role": "user", "content": "ping"}], "max_tokens": 1}).encode()
            req = urllib.request.Request(endpoint, data=payload, headers={"Content-Type": "application/json"}, method="POST")
            start = time.perf_counter()
            try:
                with urllib.request.urlopen(req, timeout=10) as response:  # noqa: S310 - operator-supplied benchmark endpoint
                    response.read(4096)
                    if response.status >= 400:
                        errors += 1
            except Exception:
                errors += 1
            timings.append((time.perf_counter() - start) * 1000)
        status = _summary("http", timings, {"endpoint_recorded": False, "model": model, "errors": errors})
        return BenchResult(status.candidate, "failed" if errors == operations else status.status, "all requests failed" if errors == operations else status.reason, status.operations, status.elapsed_ms, status.p50_ms, status.p95_ms, status.p99_ms, status.ops_per_second, status.details)

    def _bench_direct_mock_gateway(self, operations: int) -> BenchResult:
        def mock_provider(payload: dict[str, Any]) -> dict[str, Any]:
            return {"id": payload.get("id"), "model": payload.get("model", "mock"), "choices": [{"message": {"content": "ok"}}], "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2}}
        timings: list[float] = []
        usage_total = 0
        for i in range(operations):
            start = time.perf_counter()
            response = mock_provider({"id": i, "model": "mock"})
            usage_total += int(response["usage"]["total_tokens"])
            timings.append((time.perf_counter() - start) * 1000)
        return _summary("direct-mock", timings, {"usage_total_tokens": usage_total, "trace_propagation": "not-applicable-local-call"})

    def _receipt(self, schema: str, results: list[BenchResult], category: str) -> dict[str, Any]:
        return {
            "schema_version": schema,
            "category": category,
            "root": str(self.root),
            "results": [asdict(result) for result in results],
            "promotion_allowed": False,
            "promotion_rule": "candidate promotion requires same-workload benchmark, tenant/trace/cost propagation tests, rollback path, and full suite pass",
        }

    @staticmethod
    def _has_module(name: str) -> bool:
        try:
            import importlib.util
            return importlib.util.find_spec(name) is not None
        except Exception:
            return False
