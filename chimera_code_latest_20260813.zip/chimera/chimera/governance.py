"""Typed execution contracts, consequence scoring, deterministic quorum and gate."""
from __future__ import annotations
import base64,hashlib,json,pathlib,time
from typing import Any,Callable,Iterable,Literal,Mapping,Optional
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from pydantic import BaseModel,ConfigDict,Field,model_validator
from .context_evidence import ContextSigner
from .wal import WAL
class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
def _canonical(value:Any)->bytes:return json.dumps(value,sort_keys=True,separators=(",",":"),default=str).encode()
def _hash(value:Any)->str:return "sha256:"+hashlib.sha256(_canonical(value)).hexdigest()
class ConsequenceDimensions(FrozenModel):
    blast_radius:float=Field(ge=0,le=1);privilege:float=Field(ge=0,le=1);irreversibility:float=Field(ge=0,le=1);data_sensitivity:float=Field(ge=0,le=1);uncertainty:float=Field(ge=0,le=1)
class ExecutionContract(FrozenModel):
    id:str;target:str;action:str;invariants:tuple[str,...];base_root:str;epoch:int=Field(ge=0);dimensions:ConsequenceDimensions;required_archetypes:tuple[str,...]=();data_purpose:Optional[str]=None;consent_basis:Optional[str]=None
    @property
    def digest(self):return _hash(self.model_dump(mode="json"))
class ConsequenceScore(FrozenModel):score:float;dimensions:ConsequenceDimensions;formula:str

def score_contract(contract:ExecutionContract,gamma:float=.9,lamb:float=.85,eta:float=.6)->ConsequenceScore:
    d=contract.dimensions;base=max(d.blast_radius*d.privilege,gamma*d.irreversibility,lamb*d.data_sensitivity);score=1-(1-base)*(1-eta*d.uncertainty);return ConsequenceScore(score=min(1.,max(0.,score)),dimensions=d,formula="1-(1-max(blast*privilege,gamma*irreversibility,lambda*sensitivity))*(1-eta*uncertainty)")
class ValidatorSpec(FrozenModel):
    id:str;family:str;archetype:str;public_key:str;key_id:str;weight:float=Field(default=1.,gt=0);active:bool=True
class ValidatorVote(FrozenModel):
    validator_id:str;contract_hash:str;epoch:int;decision:Literal["approve","reject"];confidence:float=Field(ge=0,le=1);evidence_refs:tuple[str,...];rationale_ref:Optional[str]=None;signature:str
    def unsigned(self):return self.model_dump(mode="json",exclude={"signature"})
class QuorumProof(FrozenModel):contract_hash:str;epoch:int;validator_ids:tuple[str,...];votes:tuple[ValidatorVote,...];registry_root:str
class QuorumDecision(FrozenModel):authorized:bool;score:float;required_threshold:float;expected_validators:tuple[str,...];reasons:tuple[str,...]
class BreakGlassRequest(FrozenModel):
    id:str;reason:str;target:str;epoch:int;created_at:float;expires_at:float
    @property
    def digest(self):return _hash(self.model_dump(mode="json"))
class BreakGlassApproval(FrozenModel):approver_id:str;request_hash:str;signature:str
class BreakGlassReceipt(FrozenModel):request_hash:str;approvers:tuple[str,...];authorized:bool;reason:str
class BreakGlassLedger:
    """Multiparty, expiring, rate-limited authorization receipt; never auto-applies an action."""
    def __init__(self,root:pathlib.Path,trusted_approvers:Mapping[str,str],minimum_approvers:int=2,max_per_window:int=3,window_seconds:float=30*86400):self.wal=WAL(pathlib.Path(root));self.trusted=dict(trusted_approvers);self.minimum=max(2,int(minimum_approvers));self.maximum=max(1,int(max_per_window));self.window=max(1.,float(window_seconds))
    @staticmethod
    def approve(request:BreakGlassRequest,approver_id:str,signer:ContextSigner)->BreakGlassApproval:return BreakGlassApproval(approver_id=approver_id,request_hash=request.digest,signature=signer.sign(request.digest.encode()))
    def authorize(self,request:BreakGlassRequest,approvals:Iterable[BreakGlassApproval],*,now:Optional[float]=None)->BreakGlassReceipt:
        current=time.time() if now is None else float(now);valid=[]
        if current>request.expires_at:return BreakGlassReceipt(request_hash=request.digest,approvers=(),authorized=False,reason="request expired")
        recent=sum(entry["data"].get("authorized") is True and float(entry["data"].get("authorized_at",0))>=current-self.window for entry in self.wal.replay(kind="break_glass"))
        if recent>=self.maximum:return BreakGlassReceipt(request_hash=request.digest,approvers=(),authorized=False,reason="rolling break-glass limit exhausted")
        for approval in approvals:
            if approval.request_hash!=request.digest or approval.approver_id in valid:continue
            encoded=self.trusted.get(approval.approver_id)
            try:
                public=base64.b64decode(encoded,validate=True);Ed25519PublicKey.from_public_bytes(public).verify(base64.b64decode(approval.signature,validate=True),request.digest.encode());valid.append(approval.approver_id)
            except (ValueError,InvalidSignature,TypeError):continue
        authorized=len(valid)>=self.minimum;reason="multiparty approval verified" if authorized else "insufficient valid distinct approvers";self.wal.append("break_glass",{"request_hash":request.digest,"target":request.target,"epoch":request.epoch,"approvers":sorted(valid),"authorized":authorized,"authorized_at":current,"reason":reason});return BreakGlassReceipt(request_hash=request.digest,approvers=tuple(sorted(valid)),authorized=authorized,reason=reason)

class ValidatorIdentity:
    def __init__(self,validator_id:str,signer:ContextSigner):self.validator_id=validator_id;self.signer=signer
    def vote(self,contract:ExecutionContract,decision:Literal["approve","reject"],confidence:float,evidence_refs:Iterable[str],rationale_ref:Optional[str]=None)->ValidatorVote:
        refs=tuple(evidence_refs)
        if not refs:raise ValueError("vote requires evidence refs")
        unsigned={"validator_id":self.validator_id,"contract_hash":contract.digest,"epoch":contract.epoch,"decision":decision,"confidence":min(1.,max(0.,confidence)),"evidence_refs":refs,"rationale_ref":rationale_ref}
        return ValidatorVote(**unsigned,signature=self.signer.sign(_canonical(unsigned)))
class DeterministicQuorum:
    def __init__(self,validators:Iterable[ValidatorSpec],correlations:Optional[Mapping[tuple[str,str],float]]=None):
        self.validators=tuple(validators);self.correlations={tuple(sorted(key)):float(value) for key,value in (correlations or {}).items()}
        if len({item.id for item in self.validators})!=len(self.validators):raise ValueError("validator ids must be unique")
    @property
    def registry_root(self):return _hash([item.model_dump(mode="json") for item in sorted(self.validators,key=lambda item:item.id)])
    def _correlation(self,left:ValidatorSpec,right:ValidatorSpec)->float:
        if left.family==right.family:return 1.0
        return self.correlations.get(tuple(sorted((left.id,right.id))),1.0)
    def select(self,contract:ExecutionContract)->tuple[ValidatorSpec,...]:
        risk=score_contract(contract).score;target=2 if risk<.3 else 4 if risk<.7 else 7;limit=.7 if risk<.3 else .5 if risk<.7 else .3;eligible=[item for item in self.validators if item.active];required=set(contract.required_archetypes)
        if contract.dimensions.irreversibility>=.7:required.add("recovery")
        if len(eligible)<target:raise RuntimeError("validator pool smaller than risk-required quorum")
        selected=[]
        def rank(item):return (item.archetype in required,item.weight,hashlib.sha256(f"{contract.digest}:{item.id}".encode()).hexdigest())
        for candidate in sorted(eligible,key=rank,reverse=True):
            if any(self._correlation(candidate,prior)>limit for prior in selected):continue
            selected.append(candidate)
            if len(selected)>=target and required<={item.archetype for item in selected}:break
        if required-{item.archetype for item in selected}:raise RuntimeError("required validator archetype unavailable under diversity bound")
        if len(selected)<target:raise RuntimeError("insufficient decorrelated validators")
        return tuple(selected)
class SovereignGate:
    def __init__(self,root:pathlib.Path,quorum:DeterministicQuorum):self.root=pathlib.Path(root).resolve();self.quorum=quorum;self.wal=WAL(self.root)
    @staticmethod
    def _verify_vote(vote:ValidatorVote,spec:ValidatorSpec)->bool:
        try:
            public=base64.b64decode(spec.public_key,validate=True)
            if "ed25519:"+hashlib.sha256(public).hexdigest()!=spec.key_id:return False
            Ed25519PublicKey.from_public_bytes(public).verify(base64.b64decode(vote.signature,validate=True),_canonical(vote.unsigned()));return True
        except (ValueError,InvalidSignature):return False
    def decide(self,contract:ExecutionContract,proof:QuorumProof,current_epoch:int)->QuorumDecision:
        reasons=[];expected=self.quorum.select(contract);expected_ids=tuple(item.id for item in expected);specs={item.id:item for item in expected};risk=score_contract(contract).score;threshold=.5 if risk<.3 else .67 if risk<.7 else .8
        if proof.contract_hash!=contract.digest:reasons.append("contract hash mismatch")
        if proof.epoch!=contract.epoch or current_epoch!=contract.epoch:reasons.append("epoch mismatch")
        if proof.registry_root!=self.quorum.registry_root:reasons.append("registry root mismatch")
        if tuple(proof.validator_ids)!=expected_ids:reasons.append("quorum differs from deterministic selection")
        if {item.validator_id for item in proof.votes}!=set(expected_ids):reasons.append("missing or extra validator votes")
        valid=[]
        for vote in proof.votes:
            spec=specs.get(vote.validator_id)
            if spec is None or vote.contract_hash!=contract.digest or vote.epoch!=contract.epoch or not vote.evidence_refs or not self._verify_vote(vote,spec):reasons.append(f"invalid vote {vote.validator_id}")
            else:valid.append((vote,spec))
        total=sum(spec.weight for _,spec in valid);approved=sum(spec.weight*vote.confidence for vote,spec in valid if vote.decision=="approve");score=approved/max(total,1e-12)
        critical=set(contract.required_archetypes)|({"recovery"} if contract.dimensions.irreversibility>=.7 else set())
        if any(vote.decision=="reject" and vote.confidence>=.8 and spec.archetype in critical for vote,spec in valid):reasons.append("critical archetype veto")
        if score<threshold:reasons.append("weighted approval below risk-adaptive threshold")
        return QuorumDecision(authorized=not reasons,score=score,required_threshold=threshold,expected_validators=expected_ids,reasons=tuple(dict.fromkeys(reasons)))
    def execute(self,contract:ExecutionContract,proof:QuorumProof,current_epoch:int,apply:Callable[[],Any])->Any:
        decision=self.decide(contract,proof,current_epoch);self.wal.append("execution_contract_decision",{"contract_hash":contract.digest,"epoch":contract.epoch,"authorized":decision.authorized,"score":decision.score,"threshold":decision.required_threshold,"reasons":list(decision.reasons),"registry_root":self.quorum.registry_root})
        if not decision.authorized:raise PermissionError("execution contract rejected: "+"; ".join(decision.reasons))
        result=apply();self.wal.append("execution_contract_applied",{"contract_hash":contract.digest,"epoch":contract.epoch,"result_hash":_hash(result)});return result
    def proof(self,contract:ExecutionContract,votes:Iterable[ValidatorVote])->QuorumProof:
        expected=self.quorum.select(contract);return QuorumProof(contract_hash=contract.digest,epoch=contract.epoch,validator_ids=tuple(item.id for item in expected),votes=tuple(votes),registry_root=self.quorum.registry_root)
