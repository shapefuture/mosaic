"""Calibrated mission triage without misrepresenting compression as Kolmogorov complexity."""
from __future__ import annotations
import hashlib,json,pathlib,zlib
from typing import Any,Iterable,Literal,Mapping,Optional
from pydantic import BaseModel,ConfigDict,Field
from .wal import WAL, wal_write
class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
class ComplexityObservation(FrozenModel):value_bytes:int;label:Literal["tractable","hard"]
class ComplexityCalibration(FrozenModel):threshold_bytes:int;true_positive_rate:float;false_positive_rate:float;samples:int;status:Literal["calibrated","insufficient_data"]
class MissionTriage(FrozenModel):
    mission_id:str;proxy_method:Literal["zlib-compressed-description-length"];compressed_bytes:int;threshold_bytes:Optional[int];exceeds_threshold:bool;stakes:str;external_review_required:bool;reason:str;formal_claim:Literal["none"]="none"
class CertificationComplexityCalibrator:
    @staticmethod
    def fit(observations:Iterable[ComplexityObservation],max_false_positive_rate:float=.05,min_samples:int=20)->ComplexityCalibration:
        rows=list(observations)
        if len(rows)<min_samples:return ComplexityCalibration(threshold_bytes=0,true_positive_rate=0,false_positive_rate=0,samples=len(rows),status="insufficient_data")
        hard=[row.value_bytes for row in rows if row.label=="hard"];easy=[row.value_bytes for row in rows if row.label=="tractable"]
        if not hard or not easy:return ComplexityCalibration(threshold_bytes=0,true_positive_rate=0,false_positive_rate=0,samples=len(rows),status="insufficient_data")
        best=None
        for threshold in sorted({row.value_bytes for row in rows}):
            tpr=sum(value>threshold for value in hard)/len(hard);fpr=sum(value>threshold for value in easy)/len(easy)
            if fpr<=max_false_positive_rate:
                score=tpr-fpr
                if best is None or (score,tpr,-threshold)>best[0]:best=((score,tpr,-threshold),threshold,tpr,fpr)
        if best is None:return ComplexityCalibration(threshold_bytes=max(row.value_bytes for row in rows),true_positive_rate=0,false_positive_rate=0,samples=len(rows),status="insufficient_data")
        return ComplexityCalibration(threshold_bytes=best[1],true_positive_rate=best[2],false_positive_rate=best[3],samples=len(rows),status="calibrated")
class MissionTriageEngine:
    HIGH_STAKES={"financial","medical","irreversible_action","regulated"}
    @staticmethod
    def measure(task:str,touched_content:Mapping[str,bytes|str])->int:
        rows=[]
        for path,value in sorted(touched_content.items()):
            raw=value.encode() if isinstance(value,str) else value;rows.append((path,hashlib.sha256(raw).hexdigest(),raw.decode("utf-8",errors="replace")))
        payload=json.dumps({"task":task,"touched":rows},sort_keys=True,separators=(",",":")).encode();return len(zlib.compress(payload,level=9))
    def triage(self,task:str,touched_content:Mapping[str,bytes|str],stakes:str,calibration:Optional[ComplexityCalibration])->MissionTriage:
        value=self.measure(task,touched_content);threshold=calibration.threshold_bytes if calibration and calibration.status=="calibrated" else None;exceeds=threshold is not None and value>threshold;high=stakes in self.HIGH_STAKES;required=high or exceeds;reason="high-stakes policy requires external review" if high else "calibrated description-length proxy exceeded" if exceeds else "internal verification permitted; completeness is never implied"
        mission_id="mission-"+hashlib.sha256(json.dumps({"task":task,"stakes":stakes,"value":value},sort_keys=True).encode()).hexdigest()[:16]
        return MissionTriage(mission_id=mission_id,proxy_method="zlib-compressed-description-length",compressed_bytes=value,threshold_bytes=threshold,exceeds_threshold=exceeds,stakes=stakes,external_review_required=required,reason=reason)

class HumanOutcomeLedger:
    """North-star outcome projection; never participates in safety admission."""
    OVERRIDES={"overridden","rejected","manual_redo"}
    def __init__(self,root:pathlib.Path):self.wal=WAL(pathlib.Path(root))
    def record(self,session_id:str,outcome:Literal["resolved","overridden","rejected","manual_redo"],evidence_refs:Iterable[str]):
        refs=tuple(evidence_refs)
        if not refs:raise ValueError("human outcome requires evidence refs")
        wal_write(self.wal, "human_task_outcome",{"session_id":session_id,"outcome":outcome,"evidence_root":"sha256:"+hashlib.sha256(json.dumps(sorted(refs)).encode()).hexdigest()})
    def metrics(self)->dict[str,float|int]:
        latest={entry["data"]["session_id"]:entry["data"]["outcome"] for entry in self.wal.replay(kind="human_task_outcome")};total=len(latest);overrides=sum(item in self.OVERRIDES for item in latest.values());return {"sessions":total,"overrides":overrides,"override_frequency":overrides/max(1,total),"task_resolution_without_override":(total-overrides)/max(1,total)}
