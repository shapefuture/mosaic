"""Signed Merkle transparency projection over Chimera's canonical WAL.

The WAL remains authority. This module adds independently verifiable O(log n)
inclusion proofs and signed heads; it never replaces or rewrites the hash chain.
"""
from __future__ import annotations
import base64,hashlib,json,pathlib,time
from typing import Any,Optional
from pydantic import BaseModel,ConfigDict,Field
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from .context_evidence import ContextSigner
from .wal import WAL
class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
def _canonical(value:Any)->bytes:return json.dumps(value,sort_keys=True,separators=(",",":"),default=str).encode()
def _leaf(data:bytes)->bytes:return hashlib.sha256(b"\x00"+data).digest()
def _node(left:bytes,right:bytes)->bytes:return hashlib.sha256(b"\x01"+left+right).digest()
def _largest_power_less_than(n:int)->int:return 1<<((n-1).bit_length()-1)
def _root(leaves:list[bytes])->bytes:
    if not leaves:return hashlib.sha256(b"").digest()
    if len(leaves)==1:return leaves[0]
    k=_largest_power_less_than(len(leaves));return _node(_root(leaves[:k]),_root(leaves[k:]))
def _proof(index:int,leaves:list[bytes])->list[bytes]:
    if len(leaves)==1:return []
    k=_largest_power_less_than(len(leaves))
    if index<k:return [*_proof(index,leaves[:k]),_root(leaves[k:])]
    return [*_proof(index-k,leaves[k:]),_root(leaves[:k])]
def _consistency_subproof(old_size:int,leaves:list[bytes],complete_subtree:bool)->list[bytes]:
    size=len(leaves)
    if old_size==size:return [] if complete_subtree else [_root(leaves)]
    k=_largest_power_less_than(size)
    if old_size<=k:return [*_consistency_subproof(old_size,leaves[:k],complete_subtree),_root(leaves[k:])]
    return [*_consistency_subproof(old_size-k,leaves[k:],False),_root(leaves[:k])]
def _consistency_proof(old_size:int,leaves:list[bytes])->list[bytes]:
    if old_size<=0 or old_size>len(leaves):raise ValueError("invalid consistency sizes")
    if old_size==len(leaves):return []
    return _consistency_subproof(old_size,leaves,True)
class SignedTreeHead(FrozenModel):
    tree_size:int;root_hash:str;wal_head:str;created_at:str;key_id:str;public_key:str;signing_scope:str;signature:str
    def unsigned(self):return self.model_dump(mode="json",exclude={"signature"})
    def verify(self)->bool:
        try:
            public=base64.b64decode(self.public_key,validate=True)
            if "ed25519:"+hashlib.sha256(public).hexdigest()!=self.key_id:return False
            Ed25519PublicKey.from_public_bytes(public).verify(base64.b64decode(self.signature,validate=True),_canonical(self.unsigned()));return True
        except (ValueError,InvalidSignature):return False
class InclusionProof(FrozenModel):
    sequence:int;leaf_hash:str;tree_size:int;path:tuple[str,...];head:SignedTreeHead
class ConsistencyProof(FrozenModel):
    old_head:SignedTreeHead;new_head:SignedTreeHead;path:tuple[str,...]
class PrefixConsistency(FrozenModel):
    old_size:int;old_root:str;new_size:int;new_root:str;consistent:bool
class MerkleTransparencyLog:
    def __init__(self,root:pathlib.Path,signer:Optional[ContextSigner]=None):self.root=pathlib.Path(root).resolve();self.wal=WAL(self.root);self.signer=signer or ContextSigner.from_environment_or_ephemeral()
    def _entries(self):
        entries=self.wal.replay();return entries,[_leaf(_canonical(item)) for item in entries]
    def head(self,tree_size:Optional[int]=None)->SignedTreeHead:
        entries,leaves=self._entries();size=len(leaves) if tree_size is None else int(tree_size)
        if size<0 or size>len(leaves):raise ValueError("tree size outside WAL")
        unsigned={"tree_size":size,"root_hash":"sha256:"+_root(leaves[:size]).hex(),"wal_head":entries[size-1]["hash"] if size else "genesis","created_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"key_id":self.signer.key_id,"public_key":self.signer.public_key,"signing_scope":self.signer.scope}
        return SignedTreeHead(**unsigned,signature=self.signer.sign(_canonical(unsigned)))
    def inclusion(self,sequence:int,tree_size:Optional[int]=None)->InclusionProof:
        entries,leaves=self._entries();size=len(leaves) if tree_size is None else int(tree_size)
        if sequence<0 or sequence>=size or size>len(leaves):raise ValueError("sequence outside requested tree")
        return InclusionProof(sequence=sequence,leaf_hash="sha256:"+leaves[sequence].hex(),tree_size=size,path=tuple("sha256:"+item.hex() for item in _proof(sequence,leaves[:size])),head=self.head(size))
    @staticmethod
    def verify_inclusion(proof:InclusionProof)->bool:
        if not proof.head.verify() or proof.tree_size!=proof.head.tree_size:return False
        try:r=bytes.fromhex(proof.leaf_hash.removeprefix("sha256:"));fn=proof.sequence;sn=proof.tree_size-1
        except ValueError:return False
        for raw in proof.path:
            try:p=bytes.fromhex(raw.removeprefix("sha256:"))
            except ValueError:return False
            if fn&1 or fn==sn:
                r=_node(p,r)
                while not (fn&1) and fn!=0:fn>>=1;sn>>=1
            else:r=_node(r,p)
            fn>>=1;sn>>=1
        return sn==0 and "sha256:"+r.hex()==proof.head.root_hash
    def consistency(self,old_size:int,new_size:Optional[int]=None)->ConsistencyProof:
        _,leaves=self._entries();new_size=len(leaves) if new_size is None else int(new_size)
        if old_size<=0 or old_size>new_size or new_size>len(leaves):raise ValueError("invalid consistency sizes")
        return ConsistencyProof(old_head=self.head(old_size),new_head=self.head(new_size),path=tuple("sha256:"+item.hex() for item in _consistency_proof(old_size,leaves[:new_size])))
    @staticmethod
    def verify_consistency(proof:ConsistencyProof)->bool:
        old,new=proof.old_head,proof.new_head
        if not old.verify() or not new.verify() or old.tree_size<=0 or old.tree_size>new.tree_size:return False
        if old.tree_size==new.tree_size:return old.root_hash==new.root_hash and not proof.path
        try:path=[bytes.fromhex(item.removeprefix("sha256:")) for item in proof.path];old_root=bytes.fromhex(old.root_hash.removeprefix("sha256:"));new_root=bytes.fromhex(new.root_hash.removeprefix("sha256:"))
        except ValueError:return False
        fn=old.tree_size-1;sn=new.tree_size-1
        while fn&1:fn>>=1;sn>>=1
        if fn==0:fr=old_root;sr=old_root
        else:
            if not path:return False
            fr=path[0];sr=path[0];path=path[1:]
        for item in path:
            if sn==0:return False
            if fn&1 or fn==sn:
                fr=_node(item,fr);sr=_node(item,sr)
                while not (fn&1) and fn!=0:fn>>=1;sn>>=1
            else:sr=_node(sr,item)
            fn>>=1;sn>>=1
        return sn==0 and fr==old_root and sr==new_root
    def verify_prefix_consistency(self,old:SignedTreeHead,new:SignedTreeHead)->PrefixConsistency:
        entries,leaves=self._entries();valid=old.verify() and new.verify() and 0<=old.tree_size<=new.tree_size<=len(leaves) and old.root_hash=="sha256:"+_root(leaves[:old.tree_size]).hex() and new.root_hash=="sha256:"+_root(leaves[:new.tree_size]).hex() and (old.tree_size==0 or old.wal_head==entries[old.tree_size-1]["hash"])
        return PrefixConsistency(old_size=old.tree_size,old_root=old.root_hash,new_size=new.tree_size,new_root=new.root_hash,consistent=valid)
