"""Redacted durable trajectory recorder for replay/debugging.

Decision metadata is useful for reliability work; raw prompts, payloads, and
credentials are not.  Redaction is recursive and happens before the JSONL write
so a later reader never has to "remember" not to expose a raw secret.
"""
from __future__ import annotations
import hashlib,json,pathlib,time
from typing import Any

_SECRET_MARKERS=("key","token","secret","password","passwd","authorization","cookie","credential")
_TEXT_MARKERS=("prompt","content","answer","stdout","stderr","output","payload","text","query")


def _text_receipt(value: str) -> dict[str, Any]:
    raw=value.encode("utf-8",errors="replace")
    return {"redacted_text_hash":"sha256:"+hashlib.sha256(raw).hexdigest(),"chars":len(value)}


def _redact(value: Any, key: str="") -> Any:
    lowered=key.lower()
    if any(marker in lowered for marker in _SECRET_MARKERS):
        return "<redacted>"
    if isinstance(value,dict):
        return {str(name):_redact(item,str(name)) for name,item in value.items()}
    if isinstance(value,(list,tuple)):
        return [_redact(item,key) for item in value]
    if isinstance(value,str) and any(marker in lowered for marker in _TEXT_MARKERS):
        return _text_receipt(value)
    return value


class TrajectoryRecorder:
 def __init__(self,root:pathlib.Path,session:str):
  self.path=pathlib.Path(root)/'.chimera'/'trajectories'/f'{hashlib.sha256(session.encode()).hexdigest()[:24]}.jsonl';self.path.parent.mkdir(parents=True,exist_ok=True)
 def append(self,kind:str,data:dict):
  safe=_redact(json.loads(json.dumps(data,default=str)))
  row={'ts':time.time(),'kind':kind,'data':safe}
  with self.path.open('a') as f:f.write(json.dumps(row,sort_keys=True)+'\n')
  return row
