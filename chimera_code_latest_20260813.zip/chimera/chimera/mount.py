
"""
VFS Mount — Mirage #138 + Nexus unified VFS

Implements per PRD §6.1/7.1:
- Mount abstraction over any backend: local FS, S3 (s3://), GDrive (gdrive://), memory (mem://)
- Mirage #138 overlay spec verbatim: lower, upper, workdir, merged
- Mount.revisions pinning for snapshot isolation (base pinned)
- Nexus CAS + ReBAC (capability-gated access) + embedded→daemon→federation modes
- Works over any mount via Mirage SDK semantics

For Python harness: mounts are simulated as path prefixes with local FS backing,
but API matches Mirage SDK so real Mirage/Nexus can replace without redesign.
"""
from __future__ import annotations
import pathlib, json, time, hashlib, fnmatch
from typing import Dict, List, Optional, Literal
from dataclasses import dataclass, field

def _hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

@dataclass
class Mount:
    """Mirage Mount — lower is live FS, upper is branch overlay, work is temp"""
    name: str
    uri: str  # e.g., "s3://bucket/app", "gdrive://drive/app", "file://./src", "mem://tmp"
    local_path: pathlib.Path
    kind: Literal["local","s3","gdrive","mem"] = "local"
    revisions: List[str] = field(default_factory=list)  # pinned base hashes for snapshot isolation
    cas: Dict[str, bytes] = field(default_factory=dict)  # content-addressed storage: hash -> bytes

    def resolve(self, rel: str) -> pathlib.Path:
        # Resolve rel path against mount's local_path (or simulated s3/gdrive)
        # For s3/gdrive, we map to .chimera/mounts/<name>/...
        return (self.local_path / rel.lstrip("/")).resolve()

    def pin_revision(self, rev_hash: str):
        self.revisions.append(rev_hash)

    def current_revision(self) -> Optional[str]:
        return self.revisions[-1] if self.revisions else None

class MountRegistry:
    """
    Nexus-style registry: embedded (single-process) -> daemon (shared) -> federation (Raft)
    Currently embedded preset (nexus.connect() single-process) per PRD Phase 0-1.
    """
    def __init__(self, root: pathlib.Path = pathlib.Path(".")):
        self.root = pathlib.Path(root).resolve()
        self.mounts: Dict[str, Mount] = {}
        self._load()

    def _mount_file(self) -> pathlib.Path:
        return self.root / ".chimera" / "mounts.json"

    def _load(self):
        p = self._mount_file()
        if p.exists():
            try:
                data = json.loads(p.read_text())
                for m in data.get("mounts", []):
                    self.mounts[m["name"]] = Mount(
                        name=m["name"], uri=m["uri"],
                        local_path=pathlib.Path(m["local_path"]),
                        kind=m.get("kind","local"),
                        revisions=m.get("revisions",[])
                    )
            except Exception:
                pass

    def _save(self):
        p = self._mount_file()
        p.parent.mkdir(parents=True, exist_ok=True)
        data = {"mounts": [
            {"name": m.name, "uri": m.uri, "local_path": str(m.local_path), "kind": m.kind, "revisions": m.revisions}
            for m in self.mounts.values()
        ]}
        p.write_text(json.dumps(data, indent=2))

    def register(self, name: str, uri: str, local_path: Optional[pathlib.Path]=None) -> Mount:
        kind = "local"
        if uri.startswith("s3://"): kind="s3"
        elif uri.startswith("gdrive://"): kind="gdrive"
        elif uri.startswith("mem://"): kind="mem"
        if local_path is None:
            if kind=="local":
                # file://./src -> local path
                local_path = pathlib.Path(uri.replace("file://","")).resolve() if uri.startswith("file://") else self.root
            else:
                # simulated remote: .chimera/mounts/<name>
                local_path = self.root / ".chimera" / "mounts" / name
                local_path.mkdir(parents=True, exist_ok=True)
        m = Mount(name=name, uri=uri, local_path=pathlib.Path(local_path), kind=kind)
        self.mounts[name]=m
        self._save()
        return m

    def get(self, name: str) -> Optional[Mount]:
        return self.mounts.get(name)

    def list(self) -> List[Mount]:
        return list(self.mounts.values())

    def resolve_path(self, uri_or_path: str) -> pathlib.Path:
        # Handle /s3/app or s3://bucket/path or ./local — find any matching mount by prefix
        if uri_or_path.startswith("/s3/"):
            # Find any s3 mount (e.g., demo with s3://bucket/app)
            for m in self.mounts.values():
                if m.kind=="s3":
                    return m.resolve(uri_or_path[len("/s3/"):])
            mount = self.get("s3")
            if mount: return mount.resolve(uri_or_path[len("/s3/"):])
        if uri_or_path.startswith("s3://"):
            # s3://bucket/key -> find mount whose uri bucket matches or any s3 mount
            # bucket = uri_or_path[5:].split("/",1)[0]
            for m in self.mounts.values():
                if m.kind=="s3":
                    # If uri shares bucket prefix, resolve relative key
                    # s3://bucket/key -> key is after bucket
                    parts = uri_or_path[5:].split("/",1)
                    key = parts[1] if len(parts)>1 else ""
                    return m.resolve(key)
            # Fallback: try named s3
            parts = uri_or_path[5:].split("/",1)
            key = parts[1] if len(parts)>1 else ""
            mount = self.get("s3")
            if mount: return mount.resolve(key)
        if uri_or_path.startswith("gdrive://") or uri_or_path.startswith("/gdrive/"):
            for m in self.mounts.values():
                if m.kind=="gdrive":
                    return m.resolve(uri_or_path.split("/",2)[-1] if "/" in uri_or_path else "")
            mount = self.get("gdrive")
            if mount: return mount.resolve(uri_or_path.split("/",2)[-1])
        # local
        return (self.root / uri_or_path.lstrip("/")).resolve()

    def cas_put(self, data: bytes) -> str:
        h = "sha256:" + _hash(data)
        # store in first mount's cas or global
        for m in self.mounts.values():
            m.cas[h]=data
        # also persist to .chimera/cas/<hash>
        cas_dir = self.root / ".chimera" / "cas"
        cas_dir.mkdir(parents=True, exist_ok=True)
        (cas_dir / h.replace("sha256:","")).write_bytes(data)
        return h

    def cas_get(self, h: str) -> Optional[bytes]:
        p = self.root / ".chimera" / "cas" / h.replace("sha256:","")
        if p.exists():
            return p.read_bytes()
        for m in self.mounts.values():
            if h in m.cas:
                return m.cas[h]
        return None
