"""Signed cross-machine federation envelopes with pinned-node trust and quarantine-only intake."""
from __future__ import annotations

import base64
import hashlib
import json
import os
import pathlib
import time
import uuid
from typing import Any, Literal, Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from pydantic import BaseModel, ConfigDict

from .context_evidence import ContextSigner
from .wal import WAL


class FederationError(RuntimeError): pass


class FederationEnvelope(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    schema_version: str = "chimera.federation.v1"
    sender: str
    sequence: int
    issued_at: str
    kind: Literal["branch-offer", "goal-update", "evidence"]
    payload: dict[str, Any]
    payload_hash: str
    key_id: str
    signature: str

    def unsigned_payload(self) -> dict[str, Any]:
        return self.model_dump(mode="json", exclude={"signature"})


class FederationTrustStore:
    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root).resolve()
        self.path = self.root / ".chimera" / "federation" / "trusted_nodes.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.wal = WAL(self.root)

    def _load(self): return json.loads(self.path.read_text()) if self.path.exists() else {}
    def _write(self, value):
        temp = self.path.with_suffix(".tmp"); temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n"); os.replace(temp, self.path)

    def add(self, node_id: str, key_id: str, public_key: str, *, actor: str) -> None:
        raw = base64.b64decode(public_key, validate=True)
        if "ed25519:" + hashlib.sha256(raw).hexdigest() != key_id:
            raise FederationError("federation public key does not match key id")
        rows = self._load(); rows[node_id] = {"key_id": key_id, "public_key": public_key, "revoked": False, "actor": actor}; self._write(rows)
        self.wal.append("federation_trust", {"node": node_id, "key_id": key_id, "actor": actor})

    def revoke(self, node_id: str, *, reason: str, actor: str) -> None:
        rows = self._load()
        if node_id not in rows: raise KeyError(node_id)
        rows[node_id]["revoked"] = True; rows[node_id]["reason"] = reason; self._write(rows)
        self.wal.append("federation_revoke", {"node": node_id, "reason": reason, "actor": actor})

    def get(self, node_id: str) -> dict[str, Any]:
        row = self._load().get(node_id)
        if not row or row.get("revoked"): raise FederationError("federation sender is untrusted or revoked")
        return row


class FederationNode:
    """Produces/accepts signed proposals. Inbound data never auto-commits."""

    def __init__(self, root: pathlib.Path, node_id: str, signer: ContextSigner,
                 trust: Optional[FederationTrustStore] = None) -> None:
        self.root = pathlib.Path(root).resolve(); self.node_id = node_id; self.signer = signer
        self.trust = trust or FederationTrustStore(self.root); self.wal = WAL(self.root)
        self.dir = self.root / ".chimera" / "federation"; self.dir.mkdir(parents=True, exist_ok=True)
        self.sequence_path = self.dir / f"{node_id}.sequence"
        self.inbox = self.dir / "inbox.jsonl"
        self.peer_state = self.dir / "peer_sequences.json"

    def _next_sequence(self) -> int:
        current = int(self.sequence_path.read_text()) if self.sequence_path.exists() else 0
        value = current + 1; temp = self.sequence_path.with_suffix(".tmp"); temp.write_text(str(value)); os.replace(temp, self.sequence_path); return value

    def emit(self, kind: Literal["branch-offer", "goal-update", "evidence"], payload: dict[str, Any]) -> FederationEnvelope:
        unsigned = {
            "schema_version": "chimera.federation.v1", "sender": self.node_id,
            "sequence": self._next_sequence(), "issued_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "kind": kind, "payload": payload, "payload_hash": _hash(payload), "key_id": self.signer.key_id,
        }
        envelope = FederationEnvelope(**unsigned, signature=self.signer.sign(_canonical(unsigned)))
        self.wal.append("federation_emit", {"sender": self.node_id, "sequence": envelope.sequence, "kind": kind, "payload_hash": envelope.payload_hash})
        return envelope

    def receive(self, envelope: FederationEnvelope) -> dict[str, Any]:
        trusted = self.trust.get(envelope.sender)
        if trusted["key_id"] != envelope.key_id: raise FederationError("sender key id differs from pinned trust record")
        if _hash(envelope.payload) != envelope.payload_hash: raise FederationError("federation payload hash mismatch")
        public = Ed25519PublicKey.from_public_bytes(base64.b64decode(trusted["public_key"]))
        try: public.verify(base64.b64decode(envelope.signature), _canonical(envelope.unsigned_payload()))
        except (InvalidSignature, ValueError) as exc: raise FederationError("federation signature invalid") from exc
        sequences = json.loads(self.peer_state.read_text()) if self.peer_state.exists() else {}
        previous = int(sequences.get(envelope.sender, 0))
        if envelope.sequence <= previous: raise FederationError("replayed or out-of-order federation envelope")
        sequences[envelope.sender] = envelope.sequence
        temp = self.peer_state.with_suffix(".tmp"); temp.write_text(json.dumps(sequences, sort_keys=True)); os.replace(temp, self.peer_state)
        receipt = {
            "id": "federated-" + uuid.uuid4().hex[:12], "sender": envelope.sender,
            "sequence": envelope.sequence, "kind": envelope.kind, "payload_hash": envelope.payload_hash,
            "status": "quarantined-proposal", "auto_applied": False,
        }
        with self.inbox.open("a") as handle: handle.write(json.dumps({"receipt": receipt, "envelope": envelope.model_dump(mode="json")}, sort_keys=True) + "\n")
        self.wal.append("federation_receive", receipt)
        return receipt


class FederationHTTPTransport:
    """HTTPS transport; trust/signature verification remains FederationNode's job."""

    def __init__(self, allowed_hosts: set[str], timeout: float = 30.0, *, egress) -> None:
        if egress is None:
            raise ValueError("a common egress policy is required for federation transport")
        self.allowed_hosts = {host.lower().rstrip(".") for host in allowed_hosts}
        self.timeout = timeout
        self.egress = egress

    def send(self, url: str, envelope: FederationEnvelope) -> dict[str, Any]:
        from urllib.parse import urlparse
        self.egress.authorize(url)
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower().rstrip(".")
        if parsed.scheme != "https" or host not in self.allowed_hosts:
            raise FederationError("federation transport requires HTTPS and an explicitly allowed host")
        import ipaddress
        try:
            ip = ipaddress.ip_address(host)
            if ip.is_private or ip.is_loopback or ip.is_link_local:
                raise FederationError("federation transport denies private/loopback destinations")
        except ValueError:
            pass
        import httpx
        response = httpx.post(
            url, json=envelope.model_dump(mode="json"), timeout=self.timeout,
            headers={"Content-Type": "application/json", "User-Agent": "Chimera-Federation/1"},
        )
        if not response.is_success:
            raise FederationError(f"federation peer returned HTTP {response.status_code}")
        value = response.json()
        if not isinstance(value, dict): raise FederationError("federation peer response must be an object")
        return value


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()


def _hash(value: Any) -> str:
    return "sha256:" + hashlib.sha256(_canonical(value)).hexdigest()
