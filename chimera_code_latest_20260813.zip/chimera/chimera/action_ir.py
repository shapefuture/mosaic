"""Closed, effect-typed IR and compiler for model-requested tool operations.

The model states intent as tool calls.  This compiler resolves aliases into a
closed operation algebra, checks argument types and capabilities, performs
common-subexpression elimination for pure reads, derives data hazards, and
emits a deterministic parallel schedule.  Unknown tools/arguments fail closed.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import re
import shlex
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Iterable, Mapping

from .effects import CapabilitySet, EffectRequest, check_effect


class OperationKind(StrEnum):
    READ_FILE = "read_file"
    LIST_FILES = "list_files"
    GRAPH_QUERY = "graph_query"
    SHELL_READ = "shell_read"
    WRITE_FILE = "write_file"
    EDIT_FILE = "edit_file"
    ARTIFACT_READ = "artifact_read"
    ARTIFACT_SEARCH = "artifact_search"


class Reversibility(StrEnum):
    READ_ONLY = "read_only"
    REVERSIBLE = "reversible"
    IRREVERSIBLE = "irreversible"


@dataclass(frozen=True)
class OperationSpec:
    kind: OperationKind
    aliases: frozenset[str]
    required: Mapping[str, type]
    optional: Mapping[str, type]
    output_type: str
    effect_row: frozenset[str]
    reversibility: Reversibility
    pure: bool


@dataclass(frozen=True)
class CompilerDiagnostic:
    source_index: int
    code: str
    message: str
    tool: str


@dataclass(frozen=True)
class ActionIR:
    action_id: str
    source_indices: tuple[int, ...]
    labels: tuple[str, ...]
    kind: OperationKind
    arguments: Mapping[str, Any] = field(repr=False)
    argument_digest: str = ""
    output_type: str = "Any"
    effect_row: frozenset[str] = frozenset()
    reversibility: Reversibility = Reversibility.READ_ONLY
    read_set: frozenset[str] = frozenset()
    write_set: frozenset[str] = frozenset()
    dependencies: tuple[str, ...] = ()
    pure: bool = False

    def as_call(self) -> dict[str, Any]:
        return {"name": self.kind.value, "arguments": dict(self.arguments)}

    def evidence(self) -> dict[str, Any]:
        return {
            "action_id": self.action_id,
            "source_indices": list(self.source_indices),
            "labels": list(self.labels),
            "kind": self.kind.value,
            "argument_digest": self.argument_digest,
            "output_type": self.output_type,
            "effect_row": sorted(self.effect_row),
            "reversibility": self.reversibility.value,
            "read_set": sorted(self.read_set),
            "write_set": sorted(self.write_set),
            "dependencies": list(self.dependencies),
            "pure": self.pure,
        }


@dataclass(frozen=True)
class CompiledToolPlan:
    actions: tuple[ActionIR, ...]
    levels: tuple[tuple[str, ...], ...]
    diagnostics: tuple[CompilerDiagnostic, ...]
    source_calls: int
    plan_hash: str

    def evidence(self) -> dict[str, Any]:
        return {
            "plan_hash": self.plan_hash,
            "source_calls": self.source_calls,
            "compiled_actions": len(self.actions),
            "levels": [list(level) for level in self.levels],
            "actions": [action.evidence() for action in self.actions],
            "diagnostics": [item.__dict__ for item in self.diagnostics],
        }


class ToolSurfaceError(ValueError):
    """The model did not use the single declarative tool protocol."""


@dataclass(frozen=True)
class ToolProgram:
    outer_tool: str
    calls: tuple[dict[str, Any], ...]
    program_hash: str
    requested_outputs: tuple[str, ...] = ()
    eliminated: tuple[str, ...] = ()


class SingleToolSurface:
    """Decode the one model-visible ``chimera.run`` tool into typed IR inputs.

    The outer tool accepts a bounded declarative action list.  It never accepts
    Python, shell scripts, loops, conditionals, or dynamic dispatch.  Individual
    operation authority remains visible to :class:`ToolPlanCompiler`.
    """

    _OPS = {
        "R": "read_file",
        "L": "list_files",
        "G": "graph_query",
        "S": "shell_read",
        "W": "write_file",
        "E": "edit_file",
        "A": "artifact_read",
        "Q": "artifact_search",
        "read_file": "read_file",
        "list_files": "list_files",
        "graph_query": "graph_query",
        "shell_read": "shell_read",
        "write_file": "write_file",
        "edit_file": "edit_file",
        "artifact_read": "artifact_read",
        "artifact_search": "artifact_search",
    }

    def __init__(self, max_actions: int = 16) -> None:
        if max_actions < 1 or max_actions > 64:
            raise ValueError("max_actions must be between 1 and 64")
        self.max_actions = max_actions

    @staticmethod
    def _hash(value: Any) -> str:
        encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
        return "sha256:" + hashlib.sha256(encoded).hexdigest()

    def decode(self, outer_calls: Iterable[Mapping[str, Any]]) -> ToolProgram:
        calls = list(outer_calls)
        if len(calls) != 1:
            raise ToolSurfaceError("single-tool mode requires exactly one chimera.run call per model turn")
        outer = calls[0]
        if str(outer.get("name", "")).strip().lower() != "chimera.run":
            raise ToolSurfaceError("chimera.run is the only model-visible tool in single-tool mode")
        unknown_outer = set(outer) - {"name", "arguments"}
        if unknown_outer:
            raise ToolSurfaceError(f"unknown chimera.run envelope field(s): {sorted(unknown_outer)}")
        arguments = outer.get("arguments")
        if not isinstance(arguments, Mapping):
            raise ToolSurfaceError("chimera.run arguments must be an object")
        unknown_arguments = set(arguments) - {"actions", "outputs"}
        if unknown_arguments:
            raise ToolSurfaceError(f"unknown chimera.run argument(s): {sorted(unknown_arguments)}")
        actions = arguments.get("actions")
        if not isinstance(actions, list) or not actions:
            raise ToolSurfaceError("chimera.run actions must be a non-empty list")
        if len(actions) > self.max_actions:
            raise ToolSurfaceError(
                f"chimera.run action count {len(actions)} exceeds bounded maximum {self.max_actions}"
            )

        decoded: list[dict[str, Any]] = []
        seen: set[str] = set()
        for index, raw in enumerate(actions):
            if not isinstance(raw, Mapping):
                raise ToolSurfaceError(f"action {index} must be an object")
            unknown = set(raw) - {"id", "op", "args", "after"}
            if unknown:
                raise ToolSurfaceError(f"action {index} has unknown field(s): {sorted(unknown)}")
            label = raw.get("id")
            if not isinstance(label, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,31}", label):
                raise ToolSurfaceError(f"action {index} id must match [A-Za-z][A-Za-z0-9_-]{{0,31}}")
            if label in seen:
                raise ToolSurfaceError(f"duplicate action id: {label}")
            op = raw.get("op")
            if not isinstance(op, str) or op not in self._OPS:
                raise ToolSurfaceError(f"action {label!r} has unknown operation {op!r}")
            args = raw.get("args", {})
            if not isinstance(args, Mapping):
                raise ToolSurfaceError(f"action {label!r} args must be an object")
            after = raw.get("after", [])
            if isinstance(after, str):
                after = [after]
            if not isinstance(after, list) or any(not isinstance(item, str) for item in after):
                raise ToolSurfaceError(f"action {label!r} after must be a list of prior action ids")
            missing = [item for item in after if item not in seen]
            if missing:
                raise ToolSurfaceError(
                    f"action {label!r} depends on unknown or forward action id(s): {missing}"
                )
            decoded.append(
                {
                    "id": label,
                    "name": self._OPS[op],
                    "arguments": dict(args),
                    "depends_on": list(dict.fromkeys(after)),
                }
            )
            seen.add(label)
        requested_outputs = arguments.get("outputs", [])
        if isinstance(requested_outputs, str):
            requested_outputs = [requested_outputs]
        if not isinstance(requested_outputs, list) or any(not isinstance(item, str) for item in requested_outputs):
            raise ToolSurfaceError("chimera.run outputs must be a list of action ids")
        missing_outputs = [item for item in requested_outputs if item not in seen]
        if missing_outputs:
            raise ToolSurfaceError(f"chimera.run outputs reference unknown action ids: {missing_outputs}")
        eliminated: list[str] = []
        if requested_outputs:
            by_id = {item["id"]: item for item in decoded}
            live = set(requested_outputs)
            frontier = list(requested_outputs)
            while frontier:
                current = frontier.pop()
                for dependency in by_id[current].get("depends_on", []):
                    if dependency not in live:
                        live.add(dependency); frontier.append(dependency)
            eliminated = [item["id"] for item in decoded if item["id"] not in live]
            decoded = [item for item in decoded if item["id"] in live]
        return ToolProgram(
            outer_tool="chimera.run", calls=tuple(decoded),
            program_hash=self._hash({"calls": decoded, "outputs": requested_outputs}),
            requested_outputs=tuple(requested_outputs), eliminated=tuple(eliminated),
        )


_SPECS = (
    OperationSpec(
        OperationKind.READ_FILE,
        frozenset({"read", "read_file", "fs.read"}),
        {"path": str}, {"start": int, "end": int, "mode": str}, "TextSlice",
        frozenset({"fs.read"}), Reversibility.READ_ONLY, True,
    ),
    OperationSpec(
        OperationKind.LIST_FILES,
        frozenset({"list", "list_files", "glob"}),
        {}, {"pattern": str}, "PathList",
        frozenset({"fs.read"}), Reversibility.READ_ONLY, True,
    ),
    OperationSpec(
        OperationKind.GRAPH_QUERY,
        frozenset({"graph", "graph_search", "search", "graph_query"}),
        {"query": str}, {}, "GraphHits",
        frozenset({"index.read"}), Reversibility.READ_ONLY, True,
    ),
    OperationSpec(
        OperationKind.SHELL_READ,
        frozenset({"shell", "bash", "exec", "shell_read"}),
        {"command": str}, {}, "ProcessOutput",
        frozenset({"compute", "fs.read"}), Reversibility.READ_ONLY, False,
    ),
    OperationSpec(
        OperationKind.WRITE_FILE,
        frozenset({"write", "write_file", "fs.write"}),
        {"path": str, "content": str}, {}, "WriteReceipt",
        frozenset({"fs.write"}), Reversibility.REVERSIBLE, False,
    ),
    OperationSpec(
        OperationKind.EDIT_FILE,
        frozenset({"edit", "edit_file", "fs.edit"}),
        {"path": str, "old_text": str, "new_text": str}, {}, "EditReceipt",
        frozenset({"fs.read", "fs.write"}), Reversibility.REVERSIBLE, False,
    ),
    OperationSpec(
        OperationKind.ARTIFACT_READ,
        frozenset({"artifact", "artifact_read", "cas.read"}),
        {"digest": str}, {"start": int, "end": int}, "ArtifactSlice",
        frozenset({"artifact.read"}), Reversibility.READ_ONLY, True,
    ),
    OperationSpec(
        OperationKind.ARTIFACT_SEARCH,
        frozenset({"artifact_search", "cas.search"}),
        {"digest": str, "query": str}, {"max_lines": int}, "ArtifactMatches",
        frozenset({"artifact.read"}), Reversibility.READ_ONLY, True,
    ),
)

_ALIAS_TO_SPEC = {alias: spec for spec in _SPECS for alias in spec.aliases}


class ToolPlanCompiler:
    """Compile untrusted model tool envelopes into a checked deterministic IR."""

    def __init__(self, root: pathlib.Path = pathlib.Path(".")) -> None:
        self.root = pathlib.Path(root).resolve()

    @staticmethod
    def _canonical(value: Any) -> bytes:
        return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()

    @classmethod
    def _hash(cls, value: Any) -> str:
        return "sha256:" + hashlib.sha256(cls._canonical(value)).hexdigest()

    def _normalise_path(self, raw: str) -> str:
        if not isinstance(raw, str) or not raw or "\x00" in raw:
            raise ValueError("path must be a non-empty string without NUL bytes")
        path = pathlib.Path(raw)
        if path.is_absolute():
            resolved = path.resolve()
            if not resolved.is_relative_to(self.root):
                raise ValueError("absolute path is outside workspace")
            return resolved.relative_to(self.root).as_posix()
        candidate = (self.root / path).resolve()
        if not candidate.is_relative_to(self.root):
            raise ValueError("path traversal")
        rel = candidate.relative_to(self.root).as_posix()
        if rel == "." or rel.startswith(".chimera/branches/"):
            raise ValueError("path targets protected branch metadata")
        return rel

    @staticmethod
    def _normalise_alias_arguments(spec: OperationSpec, raw: Mapping[str, Any]) -> dict[str, Any]:
        args = dict(raw)
        if spec.kind is OperationKind.LIST_FILES and "pattern" not in args and "path" in args:
            args["pattern"] = args.pop("path")
        if spec.kind is OperationKind.GRAPH_QUERY:
            # Coding models often express a graph lookup as ``symbol=...`` or
            # ``path=...``.  These are query aliases, not additional authority:
            # the graph operation remains read-only and the closed compiler
            # still validates the resulting single string argument.  Drop the
            # redundant alias fields after choosing the most specific query so
            # an otherwise harmless model hint cannot become an unknown arg.
            if "query" not in args:
                for alias in ("q", "symbol", "name", "path"):
                    if alias in args:
                        args["query"] = args[alias]
                        break
            for alias in ("q", "symbol", "name", "path"):
                args.pop(alias, None)
        if spec.kind is OperationKind.SHELL_READ and "command" not in args and "cmd" in args:
            args["command"] = args.pop("cmd")
        if spec.kind is OperationKind.EDIT_FILE:
            if "old_text" not in args and "find" in args:
                args["old_text"] = args.pop("find")
            if "new_text" not in args and "replace" in args:
                args["new_text"] = args.pop("replace")
        return args

    @staticmethod
    def _coerce(name: str, value: Any, expected: type) -> Any:
        if expected is int and isinstance(value, str):
            try:
                return int(value)
            except ValueError as exc:
                raise TypeError(f"argument {name!r} must be an integer") from exc
        if expected is str and isinstance(value, str):
            return value
        if expected is int and isinstance(value, int) and not isinstance(value, bool):
            return value
        raise TypeError(f"argument {name!r} must be {expected.__name__}")

    def _arguments(self, spec: OperationSpec, raw: Mapping[str, Any]) -> dict[str, Any]:
        args = self._normalise_alias_arguments(spec, raw)
        allowed = set(spec.required) | set(spec.optional)
        unknown = set(args) - allowed
        if unknown:
            raise TypeError(f"unknown argument(s): {sorted(unknown)}")
        missing = set(spec.required) - set(args)
        if missing:
            raise TypeError(f"missing argument(s): {sorted(missing)}")
        output: dict[str, Any] = {}
        for name, expected in {**spec.required, **spec.optional}.items():
            if name in args:
                output[name] = self._coerce(name, args[name], expected)
        if spec.kind in {OperationKind.READ_FILE, OperationKind.WRITE_FILE, OperationKind.EDIT_FILE}:
            output["path"] = self._normalise_path(output["path"])
        if spec.kind is OperationKind.READ_FILE and output.get("mode", "auto") not in {"auto", "source", "structure"}:
            raise ValueError("read_file mode must be auto, source, or structure")
        if spec.kind is OperationKind.LIST_FILES:
            output.setdefault("pattern", "**/*")
        if spec.kind is OperationKind.SHELL_READ:
            command = output["command"]
            if "\x00" in command or "\n" in command or any(token in command for token in (">", "|", ";", "&&", "`", "$(")):
                raise ValueError("shell_read permits one non-composed read-only command")
            try: parts = shlex.split(command)
            except ValueError as exc: raise ValueError(f"invalid shell syntax: {exc}") from exc
            executable = pathlib.PurePosixPath(parts[0]).name if parts else ""
            if executable not in {"cat", "sed", "grep", "rg", "head", "tail", "find", "ls", "pwd", "wc"}:
                raise ValueError(f"shell_read executable is not allowed: {executable}")
        if spec.kind in {OperationKind.ARTIFACT_READ, OperationKind.ARTIFACT_SEARCH}:
            digest = output["digest"]
            value = digest.removeprefix("sha256:")
            if not digest.startswith("sha256:") or len(value) != 64 or any(c not in "0123456789abcdef" for c in value.lower()):
                raise ValueError("digest must be sha256:<64 hex>")
        for bound in ("start", "end"):
            if bound in output and output[bound] < 0:
                raise ValueError(f"argument {bound!r} must be non-negative")
        if "start" in output and "end" in output and output["end"] < output["start"]:
            raise ValueError("end must be greater than or equal to start")
        return output

    @staticmethod
    def _resources(spec: OperationSpec, args: Mapping[str, Any]) -> tuple[frozenset[str], frozenset[str]]:
        if spec.kind is OperationKind.READ_FILE:
            return frozenset({str(args["path"])}), frozenset()
        if spec.kind is OperationKind.LIST_FILES:
            return frozenset({"<workspace>"}), frozenset()
        if spec.kind is OperationKind.GRAPH_QUERY:
            return frozenset({"<graph>"}), frozenset()
        if spec.kind is OperationKind.SHELL_READ:
            return frozenset({"<workspace>"}), frozenset()
        if spec.kind is OperationKind.WRITE_FILE:
            return frozenset(), frozenset({str(args["path"])})
        if spec.kind is OperationKind.EDIT_FILE:
            path = str(args["path"])
            return frozenset({path}), frozenset({path})
        if spec.kind in {OperationKind.ARTIFACT_READ, OperationKind.ARTIFACT_SEARCH}:
            return frozenset({f"<artifact:{args['digest']}>"}), frozenset()
        return frozenset(), frozenset()

    @staticmethod
    def _conflicts(
        left_reads: frozenset[str], left_writes: frozenset[str],
        right_reads: frozenset[str], right_writes: frozenset[str],
    ) -> bool:
        broad_left = "<workspace>" in left_reads | left_writes
        broad_right = "<workspace>" in right_reads | right_writes
        if broad_left and right_writes:
            return True
        if broad_right and left_writes:
            return True
        return bool(
            left_writes & right_writes
            or left_writes & right_reads
            or right_writes & left_reads
        )

    @staticmethod
    def _capability_error(spec: OperationSpec, args: Mapping[str, Any], capability: CapabilitySet) -> str | None:
        if spec.kind in {OperationKind.READ_FILE, OperationKind.EDIT_FILE}:
            verdict = check_effect(EffectRequest(effect="fs.read", needs={"fs": [str(args["path"])]}), capability)
            if not verdict.allowed or verdict.residual_obligations:
                return verdict.denied_reason or "; ".join(verdict.residual_obligations)
        if spec.kind in {OperationKind.WRITE_FILE, OperationKind.EDIT_FILE}:
            verdict = check_effect(EffectRequest(effect="fs.write", needs={"fs": [str(args["path"])]}), capability)
            if not verdict.allowed or verdict.residual_obligations:
                return verdict.denied_reason or "; ".join(verdict.residual_obligations)
        if spec.kind is OperationKind.LIST_FILES and not capability.fs_allow:
            return "filesystem enumeration has no fs.read grant"
        return None

    @staticmethod
    def _levels(actions: Iterable[ActionIR]) -> tuple[tuple[str, ...], ...]:
        by_id = {action.action_id: action for action in actions}
        remaining = set(by_id)
        complete: set[str] = set()
        levels: list[tuple[str, ...]] = []
        while remaining:
            ready = sorted(
                action_id for action_id in remaining
                if set(by_id[action_id].dependencies) <= complete
            )
            if not ready:
                raise ValueError("compiled tool plan contains a dependency cycle")
            levels.append(tuple(ready))
            remaining -= set(ready)
            complete.update(ready)
        return tuple(levels)

    def compile(
        self,
        calls: Iterable[Mapping[str, Any]],
        *,
        capability: CapabilitySet,
        allow_write: bool,
    ) -> CompiledToolPlan:
        source = list(calls)
        diagnostics: list[CompilerDiagnostic] = []
        actions: list[ActionIR] = []
        cse: dict[str, int] = {}
        label_to_action: dict[str, str] = {}

        for index, call in enumerate(source):
            tool = str(call.get("name", "")).strip().lower()
            unknown_envelope = set(call) - {"id", "name", "arguments", "depends_on"}
            if unknown_envelope:
                diagnostics.append(CompilerDiagnostic(
                    index, "invalid_envelope",
                    f"unknown call envelope field(s): {sorted(unknown_envelope)}", tool,
                ))
                continue
            label = call.get("id", f"step-{index + 1}")
            if not isinstance(label, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,31}", label):
                diagnostics.append(CompilerDiagnostic(
                    index, "invalid_envelope", "invalid or overlong action id", tool,
                ))
                continue
            if label in label_to_action:
                diagnostics.append(CompilerDiagnostic(index, "invalid_envelope", f"duplicate action id: {label}", tool))
                continue
            raw_dependencies = call.get("depends_on", [])
            if isinstance(raw_dependencies, str):
                raw_dependencies = [raw_dependencies]
            if not isinstance(raw_dependencies, (list, tuple)) or any(
                not isinstance(item, str) for item in raw_dependencies
            ):
                diagnostics.append(CompilerDiagnostic(
                    index, "invalid_dependencies", "depends_on must be a list of prior action ids", tool,
                ))
                continue
            missing_dependencies = [item for item in raw_dependencies if item not in label_to_action]
            if missing_dependencies:
                diagnostics.append(CompilerDiagnostic(
                    index, "invalid_dependencies",
                    f"unknown or forward dependency id(s): {missing_dependencies}", tool,
                ))
                continue
            explicit_dependencies = [label_to_action[item] for item in raw_dependencies]

            spec = _ALIAS_TO_SPEC.get(tool)
            if spec is None:
                diagnostics.append(CompilerDiagnostic(index, "unknown_operation", "unknown or disallowed tool", tool))
                continue
            if spec.reversibility is not Reversibility.READ_ONLY and not allow_write:
                diagnostics.append(CompilerDiagnostic(index, "role_denied", "writes are disabled for this role", tool))
                continue
            raw_arguments = call.get("arguments", {})
            if not isinstance(raw_arguments, Mapping):
                diagnostics.append(CompilerDiagnostic(index, "invalid_arguments", "arguments must be an object", tool))
                continue
            try:
                arguments = self._arguments(spec, raw_arguments)
            except (TypeError, ValueError) as exc:
                diagnostics.append(CompilerDiagnostic(index, "invalid_arguments", str(exc), tool))
                continue
            denied = self._capability_error(spec, arguments, capability)
            if denied:
                diagnostics.append(CompilerDiagnostic(index, "capability_denied", denied, tool))
                continue

            argument_digest = self._hash({"kind": spec.kind.value, "arguments": arguments})
            if spec.pure and argument_digest in cse:
                position = cse[argument_digest]
                prior = actions[position]
                actions[position] = ActionIR(
                    **{
                        **prior.__dict__,
                        "source_indices": (*prior.source_indices, index),
                        "labels": (*prior.labels, label),
                    }
                )
                label_to_action[label] = prior.action_id
                continue

            reads, writes = self._resources(spec, arguments)
            dependencies: list[str] = list(explicit_dependencies)
            for prior in actions:
                if self._conflicts(prior.read_set, prior.write_set, reads, writes):
                    dependencies.append(prior.action_id)
            action_id = "act-" + hashlib.sha256(
                self._canonical({"index": index, "label": label, "digest": argument_digest})
            ).hexdigest()[:16]
            action = ActionIR(
                action_id=action_id,
                source_indices=(index,),
                labels=(label,),
                kind=spec.kind,
                arguments=arguments,
                argument_digest=argument_digest,
                output_type=spec.output_type,
                effect_row=spec.effect_row,
                reversibility=spec.reversibility,
                read_set=reads,
                write_set=writes,
                dependencies=tuple(dict.fromkeys(dependencies)),
                pure=spec.pure,
            )
            actions.append(action)
            label_to_action[label] = action_id

            # A read is a common subexpression only within a stable state.
            # Invalidate cached reads whose resources this write may change.
            if writes:
                for digest, position in list(cse.items()):
                    cached = actions[position]
                    if self._conflicts(
                        cached.read_set, cached.write_set, frozenset(), writes
                    ):
                        del cse[digest]
            if spec.pure:
                cse[argument_digest] = len(actions) - 1

        levels = self._levels(actions) if actions else ()
        evidence_payload = {
            "source_calls": len(source),
            "actions": [action.evidence() for action in actions],
            "levels": levels,
            "diagnostics": [item.__dict__ for item in diagnostics],
        }
        return CompiledToolPlan(
            actions=tuple(actions), levels=levels, diagnostics=tuple(diagnostics),
            source_calls=len(source), plan_hash=self._hash(evidence_payload),
        )
