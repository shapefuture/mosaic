"""Provider-client facade for the RLM strangler-fig split."""
from __future__ import annotations

from typing import Any


class ProviderClient:
    def __init__(self, runtime: Any) -> None:
        self.runtime = runtime

    def complete(self, prompt: str, model: str = "mock-echo") -> dict[str, Any]:
        return self.runtime.model_provider(prompt, model)

    def count_tokens(self, model: str, text: str) -> int:
        return self.runtime._count_tokens(model, text)
