"""Small W3C trace-context propagation helpers.

The helpers are deliberately optional-dependency friendly: if OpenTelemetry is
installed and an active span exists, use its propagator.  Otherwise fall back to
explicit environment variables that are safe to name in receipts without
recording endpoint or credential values.
"""
from __future__ import annotations

import os
import re
from typing import Any, Mapping

_TRACEPARENT_RE = re.compile(r"^[\da-f]{2}-[\da-f]{32}-[\da-f]{16}-[\da-f]{2}$", re.IGNORECASE)


def _valid_traceparent(value: str) -> bool:
    return bool(_TRACEPARENT_RE.match(value.strip()))


def current_trace_context() -> dict[str, str]:
    """Return current W3C trace context carrier, or ``{}``.

    Secret values are not read.  ``traceparent``/``tracestate``/``baggage`` are
    correlation metadata and may be propagated across MCP boundaries.
    """
    carrier: dict[str, str] = {}
    try:  # OpenTelemetry is optional in local installs.
        from opentelemetry.propagate import inject  # type: ignore

        injected: dict[str, str] = {}
        inject(injected)
        for key in ("traceparent", "tracestate", "baggage"):
            value = injected.get(key)
            if isinstance(value, str) and value:
                carrier[key] = value
    except Exception:
        pass

    # Explicit env override is useful for CLI/integration tests and for hosts
    # that already received a traceparent but do not install OpenTelemetry.
    env_map = {
        "traceparent": ("CHIMERA_TRACEPARENT", "TRACEPARENT"),
        "tracestate": ("CHIMERA_TRACESTATE", "TRACESTATE"),
        "baggage": ("CHIMERA_BAGGAGE", "BAGGAGE"),
    }
    for key, names in env_map.items():
        for name in names:
            value = os.environ.get(name)
            if value:
                carrier[key] = value.strip()
                break
    if "traceparent" in carrier and not _valid_traceparent(carrier["traceparent"]):
        carrier.pop("traceparent", None)
    return {key: value for key, value in carrier.items() if value}


def inject_trace_context_into_meta(meta: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Return a copy of MCP ``_meta`` with W3C trace keys injected.

    Existing explicit values win when valid; Chimera never overwrites a caller's
    already-attached trace context.
    """
    out = dict(meta or {})
    context = current_trace_context()
    for key, value in context.items():
        if key not in out:
            out[key] = value
    return out


def trace_context_headers() -> dict[str, str]:
    """Return HTTP headers for transports/gateways that honor W3C context."""
    return current_trace_context()
