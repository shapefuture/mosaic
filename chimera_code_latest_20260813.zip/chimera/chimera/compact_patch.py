"""Compact, closed patch wire format for one-shot coding transactions.

The format reduces repeated envelope vocabulary without introducing a scripting
language. It is decoded into Chimera's existing ``files``/``edits`` patch data
and traverses the same static, scope, transaction, and test gates.

    {"f": {"pkg/a.py": "complete source"},
     "e": [{"p": "pkg/b.py", "o": "old", "n": "new"}]}

Insertions intentionally remain on the verbose protocol: compact mode is for
small create/exact-edit transactions, not a second general patch language.
"""
from __future__ import annotations

from typing import Any, Mapping


class CompactPatchError(ValueError):
    pass


def is_compact_patch(value: Any) -> bool:
    return isinstance(value, Mapping) and bool(set(value).intersection({"f", "e"}))


def decode_compact_patch(value: Mapping[str, Any]) -> dict[str, Any]:
    if set(value) - {"f", "e"}:
        raise CompactPatchError("compact patch accepts only f and e")
    files = value.get("f", {})
    edits = value.get("e", [])
    if not isinstance(files, Mapping) or not isinstance(edits, list):
        raise CompactPatchError("compact patch f must be an object and e must be a list")
    decoded_files = []
    for path, content in files.items():
        if not isinstance(path, str) or not isinstance(content, str):
            raise CompactPatchError("compact patch f entries must map string paths to string source")
        decoded_files.append({"path": path, "content": content})
    decoded_edits = []
    for item in edits:
        if not isinstance(item, Mapping) or set(item) != {"p", "o", "n"}:
            raise CompactPatchError("compact patch e entries must contain exactly p, o, n")
        path, old, new = item.get("p"), item.get("o"), item.get("n")
        if not all(isinstance(part, str) for part in (path, old, new)):
            raise CompactPatchError("compact patch edit values must be strings")
        decoded_edits.append({"path": path, "find": old, "replace": new})
    if not decoded_files and not decoded_edits:
        raise CompactPatchError("compact patch requires at least one file or edit")
    return {
        "summary": "compact patch",
        "files": decoded_files,
        "edits": decoded_edits,
        "insertions": [],
    }
