"""Provider token/cache/cost usage ledger aggregated by agent role."""
from __future__ import annotations
import pathlib
from .wal import WAL, wal_write
class UsageLedger:
 def __init__(self,root:pathlib.Path):self.wal=WAL(pathlib.Path(root))
 @staticmethod
 def _num(usage,*names):
  for name in names:
   value=usage.get(name)
   if isinstance(value,(int,float)):return value
  details=usage.get("prompt_tokens_details") if isinstance(usage.get("prompt_tokens_details"),dict) else {}
  for name in names:
   value=details.get(name)
   if isinstance(value,(int,float)):return value
  return 0
 def record(self,role,model,provider,usage):
  requests=max(1,int(self._num(usage,"request_count","requests") or 1))
  row={"role":role or "unknown","model":model,"provider":provider or "unknown","input_tokens":self._num(usage,"prompt_tokens","input_tokens"),"output_tokens":self._num(usage,"completion_tokens","output_tokens"),"cache_read_tokens":self._num(usage,"cache_read_input_tokens","cached_tokens"),"cache_creation_tokens":self._num(usage,"cache_creation_input_tokens"),"billed_cost":usage.get("cost") if isinstance(usage.get("cost"),(int,float)) else None,"request_count":requests,"retry_count":max(0,requests-1)}
  wal_write(self.wal, "provider_usage",row);return row
 def by_role(self):
  result={}
  for e in self.wal.replay(kind="provider_usage"):
   d=e["data"];row=result.setdefault(d["role"],{"input_tokens":0,"output_tokens":0,"cache_read_tokens":0,"cache_creation_tokens":0,"billed_cost":0.,"billed_cost_samples":0,"calls":0,"requests":0,"retries":0})
   for k in ("input_tokens","output_tokens","cache_read_tokens","cache_creation_tokens"):row[k]+=d[k]
   if d["billed_cost"] is not None:row["billed_cost"]+=d["billed_cost"];row["billed_cost_samples"]+=1
   row["calls"]+=1;row["requests"]+=int(d.get("request_count",1));row["retries"]+=int(d.get("retry_count",0))
  return result
