"""AST-level public-interface and syntax guard for candidate Python edits."""
from __future__ import annotations

import ast
from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class SemanticDelta:
    path: str
    removed_public: tuple[str, ...]
    changed_signatures: tuple[str, ...]
    syntax_error: str | None


class SemanticDeltaGuard:
    """Reject accidental public API removal before expensive test execution.

    It is deliberately conservative: it does not infer behavioral correctness.
    Explicit removal/rename tasks can opt out at the caller.
    """

    @staticmethod
    def _interfaces(source: str, path: str) -> dict[str, tuple[str, int, int]]:
        tree = ast.parse(source, filename=path)
        result = {}
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and not node.name.startswith("_"):
                if isinstance(node, ast.ClassDef):
                    result[node.name] = ("class", 0, 0)
                else:
                    positional = len(node.args.posonlyargs) + len(node.args.args)
                    required = max(0, positional - len(node.args.defaults))
                    result[node.name] = ("function", positional, required)
        return result

    def analyze(self, path: str, before: str, after: str) -> SemanticDelta:
        try:
            old = self._interfaces(before, path)
            new = self._interfaces(after, path)
        except SyntaxError as exc:
            return SemanticDelta(path, (), (), f"{path}: Python syntax error line {exc.lineno}: {exc.msg}")
        removed = tuple(sorted(set(old) - set(new)))
        changed = tuple(sorted(
            name for name in set(old) & set(new)
            if old[name] != new[name]
        ))
        return SemanticDelta(path, removed, changed, None)

    def validate(self, path: str, before: str, after: str, task: str = "") -> list[str]:
        delta = self.analyze(path, before, after)
        if delta.syntax_error:
            return [delta.syntax_error]
        lower = task.lower()
        explicit_api_change = any(word in lower for word in ("remove", "delete", "rename", "breaking change"))
        errors = []
        if delta.removed_public and not explicit_api_change:
            errors.append(f"{path}: public API removal requires explicit task intent: {', '.join(delta.removed_public)}")
        # Signature changes are not forbidden: tests/contracts are the source
        # of truth, but recordable through callers that want stronger policy.
        return errors
