"""Equal-config, held-out comparison frame for coding-agent conditions.

The harness records supplied condition outcomes; it does not call providers,
select a winner, or convert unknown outcomes into failures.  It exists to make
future performance claims falsifiable rather than benchmark-shaped.
"""
from __future__ import annotations

import statistics
import time
from typing import Callable, Literal, Mapping

from pydantic import BaseModel, ConfigDict, Field


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class EqualConfigFrame(_FrozenModel):
    model: str
    route: str
    max_output_tokens: int = Field(gt=0)
    request_deadline_seconds: float = Field(gt=0)
    parent_deadline_seconds: float = Field(gt=0)
    corpus_hash: str
    protected_test_manifest_hash: str
    evaluator_epoch: str
    repetitions: int = Field(ge=1, le=100)


class CampaignObservation(_FrozenModel):
    condition: str
    repetition: int = Field(ge=0)
    outcome: Literal["pass", "fail", "cancelled", "unknown"]
    provider_ttft_ms: float | None = Field(default=None, ge=0)
    duration_ms: float | None = Field(default=None, ge=0)
    prompt_tokens: int | None = Field(default=None, ge=0)
    completion_tokens: int | None = Field(default=None, ge=0)
    cached_tokens: int | None = Field(default=None, ge=0)
    repair_count: int | None = Field(default=None, ge=0)
    focused_tests_passed: bool | None = None
    full_tests_passed: bool | None = None
    protected_tests_unchanged: bool | None = None
    unknown_effects: int | None = Field(default=None, ge=0)
    cost_usd: float | None = Field(default=None, ge=0)
    frame: EqualConfigFrame


class EqualConfigCampaignReport(_FrozenModel):
    frame: EqualConfigFrame
    observations: tuple[CampaignObservation, ...]
    comparable: bool
    reasons: tuple[str, ...]
    summaries: dict[str, dict[str, float | int | None]]
    winner: None = None


class EqualConfigCampaign:
    """Execute supplied offline/live condition runners under one frozen frame."""

    def __init__(self, frame: EqualConfigFrame):
        self.frame = frame

    def run(self, runners: Mapping[str, Callable[[int, EqualConfigFrame], CampaignObservation]]) -> EqualConfigCampaignReport:
        observations: list[CampaignObservation] = []
        for condition, runner in sorted(runners.items()):
            for repetition in range(self.frame.repetitions):
                row = runner(repetition, self.frame)
                if row.condition != condition or row.repetition != repetition:
                    raise ValueError("campaign runner returned a mismatched condition/repetition")
                observations.append(row)
        return self.assess(observations)

    def assess(self, observations: list[CampaignObservation] | tuple[CampaignObservation, ...]) -> EqualConfigCampaignReport:
        reasons: list[str] = []
        rows = tuple(observations)
        if not rows:
            reasons.append("no observations")
        for row in rows:
            if row.frame != self.frame:
                reasons.append(f"frame mismatch in {row.condition}/{row.repetition}")
            if row.full_tests_passed is not True or row.protected_tests_unchanged is not True:
                reasons.append(f"missing full/protected deterministic verification in {row.condition}/{row.repetition}")
            if row.outcome == "unknown":
                reasons.append(f"unknown outcome in {row.condition}/{row.repetition}")
        conditions = {row.condition for row in rows}
        if len(conditions) < 2:
            reasons.append("at least two conditions are required")
        for condition in conditions:
            count = sum(1 for row in rows if row.condition == condition)
            if count != self.frame.repetitions:
                reasons.append(f"condition {condition} has {count}/{self.frame.repetitions} repetitions")
        summaries = {condition: self._summary([row for row in rows if row.condition == condition]) for condition in sorted(conditions)}
        return EqualConfigCampaignReport(
            frame=self.frame,
            observations=rows,
            comparable=not reasons,
            reasons=tuple(dict.fromkeys(reasons)),
            summaries=summaries,
        )

    @staticmethod
    def _summary(rows: list[CampaignObservation]) -> dict[str, float | int | None]:
        def median(name: str) -> float | None:
            values = [getattr(row, name) for row in rows if getattr(row, name) is not None]
            return float(statistics.median(values)) if values else None
        return {
            "runs": len(rows),
            "passes": sum(row.outcome == "pass" for row in rows),
            "fails": sum(row.outcome == "fail" for row in rows),
            "unknown": sum(row.outcome == "unknown" for row in rows),
            "median_ttft_ms": median("provider_ttft_ms"),
            "median_duration_ms": median("duration_ms"),
            "median_prompt_tokens": median("prompt_tokens"),
            "median_completion_tokens": median("completion_tokens"),
            "median_cached_tokens": median("cached_tokens"),
            "median_repairs": median("repair_count"),
            "median_cost_usd": median("cost_usd"),
        }
