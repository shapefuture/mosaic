"""Reproducible release manifest, CycloneDX SBOM, and signed in-toto provenance.

The producer is intentionally offline: it hashes source bytes and installed
metadata without contacting a registry. Shared consumption requires an explicit
trusted Ed25519 key id and expected builder id. Missing files, source drift,
wrong builders, malformed statements, and signature tampering fail closed.
"""
from __future__ import annotations

import base64
import hashlib
import importlib.metadata
import json
import os
import pathlib
import re
import shutil
import tomllib
import uuid
from typing import Any, Literal

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from pydantic import BaseModel, ConfigDict, Field, field_validator


_SHA = re.compile(r"^sha256:[0-9a-f]{64}$")


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


def _sha(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _digest(value: str) -> str:
    if not _SHA.fullmatch(str(value)):
        raise ValueError("digest must use sha256:<64 lowercase hex>")
    return str(value)


def _canonical(value: Any) -> bytes:
    if isinstance(value, BaseModel):
        value = value.model_dump(mode="json")
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


class ReleaseFile(_FrozenModel):
    path: str
    size: int = Field(ge=0)
    digest: str

    _file_digest = field_validator("digest")(_digest)

    @field_validator("path")
    @classmethod
    def _path(cls, value: str) -> str:
        path = pathlib.PurePosixPath(str(value).replace("\\", "/"))
        if not value or path.is_absolute() or ".." in path.parts:
            raise ValueError("release files must be workspace-relative")
        return path.as_posix()


class ReproducibleReleaseManifest(_FrozenModel):
    schema_version: Literal["chimera.release-manifest.v1"] = "chimera.release-manifest.v1"
    project_name: str
    project_version: str
    files: tuple[ReleaseFile, ...] = Field(min_length=1)

    @property
    def digest(self) -> str:
        return _sha(_canonical(self))


class ReleaseProvenanceStatement(_FrozenModel):
    type: Literal["https://in-toto.io/Statement/v1"] = Field(
        default="https://in-toto.io/Statement/v1", alias="_type"
    )
    subject: tuple[dict[str, Any], ...] = Field(min_length=2)
    predicateType: Literal["https://slsa.dev/provenance/v1"] = "https://slsa.dev/provenance/v1"
    predicate: dict[str, Any]

    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)

    @property
    def digest(self) -> str:
        return _sha(_canonical(self.model_dump(mode="json", by_alias=True)))


class SignedReleaseProvenance(_FrozenModel):
    schema_version: Literal["chimera.signed-release-provenance.v1"] = "chimera.signed-release-provenance.v1"
    statement_digest: str
    algorithm: Literal["ed25519"] = "ed25519"
    key_id: str
    public_key: str
    signing_scope: str
    signature: str

    _statement_digest = field_validator("statement_digest")(_digest)

    def signed_payload(self) -> dict[str, Any]:
        return self.model_dump(exclude={"signature"}, mode="json")

    def verify(self, trusted_key_ids: set[str] | frozenset[str]) -> bool:
        try:
            public_bytes = base64.b64decode(self.public_key, validate=True)
            key_id = "ed25519:" + hashlib.sha256(public_bytes).hexdigest()
            if key_id != self.key_id or key_id not in trusted_key_ids:
                return False
            Ed25519PublicKey.from_public_bytes(public_bytes).verify(
                base64.b64decode(self.signature, validate=True),
                _canonical(self.signed_payload()),
            )
            return True
        except (ValueError, InvalidSignature):
            return False


class ReleaseBundleReceipt(_FrozenModel):
    bundle_path: str
    manifest_digest: str
    sbom_digest: str
    statement_digest: str
    signature_key_id: str
    builder_id: str
    source_files: int

    _manifest = field_validator("manifest_digest")(_digest)
    _sbom = field_validator("sbom_digest")(_digest)
    _statement = field_validator("statement_digest")(_digest)


class ReleaseVerificationReceipt(_FrozenModel):
    verified: bool
    manifest_valid: bool
    source_bytes_valid: bool
    sbom_valid: bool
    statement_valid: bool
    signature_valid: bool
    builder_valid: bool
    errors: tuple[str, ...]


class ReleaseProvenanceBuilder:
    """Create an immutable four-file release provenance bundle."""

    _IGNORED = {
        ".git", ".chimera", ".pytest_cache", ".hypothesis", ".mypy_cache",
        ".ruff_cache", "__pycache__", "node_modules", "build", "dist",
        "coverage", "target", "out", ".venv", "release-provenance",
    }

    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root).resolve()
        if not self.root.is_dir():
            raise ValueError("release source root must be a directory")

    def build(
        self,
        *,
        output: pathlib.Path | str,
        signer,
        builder_id: str,
        source_uri: str,
        source_revision: str,
    ) -> ReleaseBundleReceipt:
        if getattr(signer, "scope", "") in {"", "ephemeral-process"}:
            raise ValueError("release provenance requires a non-ephemeral signing scope")
        if not builder_id or not source_uri or not source_revision:
            raise ValueError("builder id, source URI, and source revision are required")
        output_path = pathlib.Path(output)
        output_path = (self.root / output_path).resolve() if not output_path.is_absolute() else output_path.resolve()
        if not output_path.is_relative_to(self.root) or output_path == self.root:
            raise ValueError("release bundle must remain below the workspace")
        if output_path.exists():
            raise FileExistsError(output_path)
        output_relative = output_path.relative_to(self.root).as_posix()

        project = tomllib.loads((self.root / "pyproject.toml").read_text(encoding="utf-8"))["project"]
        manifest = ReproducibleReleaseManifest(
            project_name=str(project["name"]),
            project_version=str(project["version"]),
            files=self._source_files(excluded_prefix=output_relative),
        )
        manifest_bytes = (_canonical(manifest) + b"\n")
        sbom = self._sbom(project, manifest)
        sbom_bytes = _canonical(sbom) + b"\n"
        manifest_file_digest = _sha(manifest_bytes)
        sbom_digest = _sha(sbom_bytes)
        statement = ReleaseProvenanceStatement(
            subject=(
                {"name": "source-manifest.json", "digest": {"sha256": manifest_file_digest.removeprefix("sha256:")}},
                {"name": "sbom.cdx.json", "digest": {"sha256": sbom_digest.removeprefix("sha256:")}},
            ),
            predicate={
                "buildDefinition": {
                    "buildType": "https://arena.ai/chimera/release-provenance/v1",
                    "externalParameters": {
                        "project": manifest.project_name,
                        "version": manifest.project_version,
                    },
                    "internalParameters": {"networkRequired": False},
                    "resolvedDependencies": [{
                        "uri": source_uri,
                        "digest": {"sha256": source_revision.removeprefix("sha256:") if source_revision.startswith("sha256:") else source_revision},
                    }],
                },
                "runDetails": {
                    "builder": {"id": builder_id},
                    "metadata": {"invocationId": manifest.digest, "reproducible": True},
                    "byproducts": [{"name": "sbom.cdx.json", "digest": {"sha256": sbom_digest.removeprefix("sha256:")}}],
                },
            },
        )
        statement_bytes = _canonical(statement.model_dump(mode="json", by_alias=True)) + b"\n"
        unsigned = {
            "schema_version": "chimera.signed-release-provenance.v1",
            "statement_digest": statement.digest,
            "algorithm": "ed25519",
            "key_id": str(signer.key_id),
            "public_key": str(signer.public_key),
            "signing_scope": str(signer.scope),
        }
        signed = SignedReleaseProvenance(**unsigned, signature=signer.sign(_canonical(unsigned)))
        signature_bytes = _canonical(signed) + b"\n"

        output_path.parent.mkdir(parents=True, exist_ok=True)
        staging = output_path.with_name(f".{output_path.name}.{uuid.uuid4().hex}.tmp")
        try:
            staging.mkdir(mode=0o700)
            for name, data in (
                ("source-manifest.json", manifest_bytes),
                ("sbom.cdx.json", sbom_bytes),
                ("provenance.intoto.json", statement_bytes),
                ("provenance.sig.json", signature_bytes),
            ):
                self._write(staging / name, data)
            directory_fd = os.open(staging, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
            os.replace(staging, output_path)
        finally:
            if staging.exists():
                shutil.rmtree(staging)
        return ReleaseBundleReceipt(
            bundle_path=output_relative,
            manifest_digest=manifest.digest,
            sbom_digest=sbom_digest,
            statement_digest=statement.digest,
            signature_key_id=signed.key_id,
            builder_id=builder_id,
            source_files=len(manifest.files),
        )

    def _source_files(self, *, excluded_prefix: str) -> tuple[ReleaseFile, ...]:
        rows: list[ReleaseFile] = []
        for path in sorted(self.root.rglob("*")):
            relative = path.relative_to(self.root)
            rel = relative.as_posix()
            if rel == excluded_prefix or rel.startswith(excluded_prefix + "/"):
                continue
            if any(part in self._IGNORED for part in relative.parts):
                continue
            if not path.is_file() or path.is_symlink():
                continue
            data = path.read_bytes()
            rows.append(ReleaseFile(path=rel, size=len(data), digest=_sha(data)))
        if not rows:
            raise ValueError("release source manifest is empty")
        return tuple(rows)

    @staticmethod
    def _sbom(project: dict[str, Any], manifest: ReproducibleReleaseManifest) -> dict[str, Any]:
        components = []
        for requirement in project.get("dependencies", []):
            name = re.split(r"[<>=!~\[; ]", str(requirement), maxsplit=1)[0]
            try:
                version = importlib.metadata.version(name)
            except importlib.metadata.PackageNotFoundError:
                version = "unresolved"
            components.append({
                "type": "library", "name": name, "version": version,
                "purl": f"pkg:pypi/{name.lower()}@{version}",
            })
        components.sort(key=lambda item: (item["name"].lower(), item["version"]))
        return {
            "bomFormat": "CycloneDX",
            "specVersion": "1.6",
            "serialNumber": "urn:uuid:" + str(uuid.UUID(manifest.digest.removeprefix("sha256:")[:32])),
            "version": 1,
            "metadata": {
                "component": {
                    "type": "application",
                    "name": manifest.project_name,
                    "version": manifest.project_version,
                    "bom-ref": manifest.digest,
                },
                "properties": [{"name": "chimera:source-manifest", "value": manifest.digest}],
            },
            "components": components,
        }

    @staticmethod
    def _write(path: pathlib.Path, data: bytes) -> None:
        with path.open("xb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())


class ReleaseProvenanceVerifier:
    def __init__(
        self,
        root: pathlib.Path,
        *,
        trusted_key_ids: set[str] | frozenset[str],
        expected_builder_ids: set[str] | frozenset[str],
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.trusted_key_ids = frozenset(trusted_key_ids)
        self.expected_builder_ids = frozenset(expected_builder_ids)

    def verify(self, bundle: pathlib.Path | str, *, verify_source_bytes: bool = True) -> ReleaseVerificationReceipt:
        errors: list[str] = []
        path = pathlib.Path(bundle)
        path = (self.root / path).resolve() if not path.is_absolute() else path.resolve()
        required = {
            "manifest": path / "source-manifest.json",
            "sbom": path / "sbom.cdx.json",
            "statement": path / "provenance.intoto.json",
            "signature": path / "provenance.sig.json",
        }
        for name, candidate in required.items():
            if not candidate.is_file():
                errors.append(f"missing required release provenance file: {name}")
        if errors:
            return ReleaseVerificationReceipt(
                verified=False, manifest_valid=False, source_bytes_valid=False,
                sbom_valid=False, statement_valid=False, signature_valid=False,
                builder_valid=False, errors=tuple(errors),
            )
        try:
            manifest = ReproducibleReleaseManifest.model_validate_json(required["manifest"].read_bytes())
            sbom = json.loads(required["sbom"].read_bytes())
            statement = ReleaseProvenanceStatement.model_validate_json(required["statement"].read_bytes())
            signed = SignedReleaseProvenance.model_validate_json(required["signature"].read_bytes())
        except Exception as exc:
            errors.append(f"release provenance JSON is invalid: {type(exc).__name__}: {exc}")
            return ReleaseVerificationReceipt(
                verified=False, manifest_valid=False, source_bytes_valid=False,
                sbom_valid=False, statement_valid=False, signature_valid=False,
                builder_valid=False, errors=tuple(errors),
            )
        manifest_valid = manifest.digest == _sha(_canonical(manifest))
        source_valid = True
        if verify_source_bytes:
            for item in manifest.files:
                candidate = (self.root / item.path).resolve()
                if not candidate.is_relative_to(self.root) or not candidate.is_file():
                    source_valid = False; errors.append(f"release source file missing: {item.path}"); continue
                data = candidate.read_bytes()
                if len(data) != item.size or _sha(data) != item.digest:
                    source_valid = False; errors.append(f"release source file drifted: {item.path}")
        sbom_valid = (
            sbom.get("bomFormat") == "CycloneDX"
            and sbom.get("specVersion") == "1.6"
            and any(
                item.get("name") == "chimera:source-manifest" and item.get("value") == manifest.digest
                for item in sbom.get("metadata", {}).get("properties", [])
            )
        )
        manifest_file_digest = _sha(required["manifest"].read_bytes())
        sbom_digest = _sha(required["sbom"].read_bytes())
        subjects = {item.get("name"): item.get("digest", {}).get("sha256") for item in statement.subject}
        statement_valid = (
            subjects.get("source-manifest.json") == manifest_file_digest.removeprefix("sha256:")
            and subjects.get("sbom.cdx.json") == sbom_digest.removeprefix("sha256:")
            and signed.statement_digest == statement.digest
        )
        builder_id = str(statement.predicate.get("runDetails", {}).get("builder", {}).get("id", ""))
        builder_valid = builder_id in self.expected_builder_ids
        signature_valid = signed.verify(self.trusted_key_ids)
        if not manifest_valid: errors.append("release manifest digest is invalid")
        if not sbom_valid: errors.append("SBOM does not bind the source manifest")
        if not statement_valid: errors.append("in-toto subjects or signed statement digest are invalid")
        if not builder_valid: errors.append("release provenance builder is not trusted")
        if not signature_valid: errors.append("release provenance signature is invalid or untrusted")
        return ReleaseVerificationReceipt(
            verified=not errors,
            manifest_valid=manifest_valid,
            source_bytes_valid=source_valid,
            sbom_valid=sbom_valid,
            statement_valid=statement_valid,
            signature_valid=signature_valid,
            builder_valid=builder_valid,
            errors=tuple(dict.fromkeys(errors)),
        )
