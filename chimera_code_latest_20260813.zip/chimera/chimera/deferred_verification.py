"""Durable checks for claims that are only verifiable later.

A deferred check is not a pass.  It records a currently unverified claim with a
specific observable predicate and either a date or an external trigger.  Closure
requires an evidence artifact describing what was observed, so an agent cannot
convert a forecast into a verified fact merely by revisiting its own prose.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date, datetime, timezone, timedelta
import hashlib
import pathlib
from typing import Iterable, Literal

from .artifacts import ContentAddressedArtifactStore
from .wal import WAL


FutureStatus = Literal["open", "confirmed", "falsified", "expired"]


@dataclass(frozen=True)
class DeferredVerification:
    id: str
    claim: str
    predicate: str
    due_on: str | None
    trigger: str | None
    status: FutureStatus
    created_at: str
    evidence_refs: tuple[str, ...] = ()
    outcome_note: str | None = None
    resolved_at: str | None = None

    def as_dict(self) -> dict:
        return asdict(self)


class DeferredVerificationLedger:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.wal = WAL(self.root)
        self.artifacts = ContentAddressedArtifactStore(self.root)

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).replace(microsecond=0).isoformat()

    @staticmethod
    def _date(value: str) -> str:
        return date.fromisoformat(value).isoformat()

    @staticmethod
    def _id(claim: str, predicate: str, due_on: str | None, trigger: str | None) -> str:
        raw = "\x1f".join((claim, predicate, due_on or "", trigger or "")).encode()
        return "future:" + hashlib.sha256(raw).hexdigest()[:20]

    def _artifact_exists(self, ref: str) -> bool:
        return isinstance(ref, str) and ref.startswith("artifact:sha256:") and self.artifacts.has(ref.removeprefix("artifact:"))

    def _records(self) -> dict[str, DeferredVerification]:
        rows: dict[str, DeferredVerification] = {}
        for entry in self.wal.replay(kind="deferred_verification"):
            data = entry["data"]
            try:
                item = DeferredVerification(
                    id=str(data["id"]), claim=str(data["claim"]), predicate=str(data["predicate"]),
                    due_on=str(data["due_on"]) if data.get("due_on") else None,
                    trigger=str(data["trigger"]) if data.get("trigger") else None,
                    status=str(data["status"]), created_at=str(data["created_at"]),
                    evidence_refs=tuple(str(ref) for ref in data.get("evidence_refs", ())),
                    outcome_note=str(data["outcome_note"]) if data.get("outcome_note") else None,
                    resolved_at=str(data["resolved_at"]) if data.get("resolved_at") else None,
                )
            except (KeyError, TypeError, ValueError):
                continue
            rows[item.id] = item
        return rows

    def add(self, claim: str, predicate: str, *, due_on: str | None = None, trigger: str | None = None) -> DeferredVerification:
        claim, predicate = claim.strip(), predicate.strip()
        if not claim or not predicate:
            raise ValueError("deferred verification requires a non-empty claim and observable predicate")
        if bool(due_on) == bool(trigger):
            raise ValueError("deferred verification requires exactly one of due_on or trigger")
        due = self._date(due_on) if due_on else None
        item = DeferredVerification(self._id(claim, predicate, due, trigger), claim, predicate, due, trigger, "open", self._now())
        current = self._records().get(item.id)
        if current is not None:
            return current
        self.wal.append("deferred_verification", item.as_dict())
        return item

    def close(
        self, item_id: str, outcome: Literal["confirmed", "falsified"], outcome_note: str, evidence_refs: Iterable[str],
    ) -> DeferredVerification:
        current = self._records().get(item_id)
        if current is None:
            raise KeyError(item_id)
        if current.status != "open":
            raise ValueError(f"deferred verification is already {current.status}")
        note = outcome_note.strip()
        refs = tuple(dict.fromkeys(str(ref) for ref in evidence_refs))
        if not note or not refs or not all(self._artifact_exists(ref) for ref in refs):
            raise ValueError("closing a deferred verification requires an observed note and resolvable evidence artifacts")
        item = DeferredVerification(
            **{**current.as_dict(), "status": outcome, "outcome_note": note, "evidence_refs": refs, "resolved_at": self._now()},
        )
        self.wal.append("deferred_verification", item.as_dict())
        return item

    def due(self, *, today: str | None = None, grace_days: int = 0) -> tuple[DeferredVerification, ...]:
        now = date.fromisoformat(today) if today else date.today()
        grace = timedelta(days=max(0, int(grace_days)))
        return tuple(
            item for item in self._records().values()
            if item.status == "open" and item.due_on and date.fromisoformat(item.due_on) + grace <= now
        )

    def expire(self, *, today: str | None = None, grace_days: int = 30) -> tuple[DeferredVerification, ...]:
        stale = self.due(today=today, grace_days=grace_days)
        result: list[DeferredVerification] = []
        for current in stale:
            item = DeferredVerification(
                **{**current.as_dict(), "status": "expired", "outcome_note": "expired without observed outcome", "resolved_at": self._now()},
            )
            self.wal.append("deferred_verification", item.as_dict())
            result.append(item)
        return tuple(result)

    def list(self, status: FutureStatus | None = None) -> tuple[DeferredVerification, ...]:
        values = tuple(self._records().values())
        return tuple(item for item in values if status is None or item.status == status)
