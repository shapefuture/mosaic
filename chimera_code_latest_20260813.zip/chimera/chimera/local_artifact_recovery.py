"""Explicit, local-only recovery of one hash-addressed Chimera artifact.

Recovery copies bytes only between two local ``ContentAddressedArtifactStore``
instances.  It accepts no URL, transport, shell command, glob, or directory
scan.  An unexpired operator authorization binds the expected digest, source
store root, and byte ceiling before a read occurs.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import time
import uuid
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .artifacts import ArtifactIntegrityError, ArtifactRef, ContentAddressedArtifactStore
from .wal import WAL, WALIntegrityError


class ArtifactRecoveryError(RuntimeError):
    pass


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class LocalArtifactRecoveryAuthorization(_FrozenModel):
    schema_version: str = "chimera.local-artifact-recovery.v1"
    id: str
    expected_digest: str
    source_root_hash: str
    max_bytes: int = Field(gt=0)
    expires_at: float
    approved_by_hash: str
    evidence_ref: str
    approved_at: float

    @property
    def receipt_hash(self) -> str:
        return _hash(self.model_dump(mode="json"))


class LocalArtifactRecoveryReceipt(_FrozenModel):
    authorization_id: str
    expected_digest: str
    source_root_hash: str
    recovered_ref: ArtifactRef
    status: str
    bytes_copied: int = Field(ge=0)


class LocalArtifactRecovery:
    """Recover an explicitly authorized artifact without network fallback."""

    def __init__(self, root: pathlib.Path, store: ContentAddressedArtifactStore | None = None):
        self.root = pathlib.Path(root).resolve()
        self.store = store or ContentAddressedArtifactStore(self.root)
        self.wal = WAL(self.root)

    @staticmethod
    def _root_hash(store: ContentAddressedArtifactStore) -> str:
        return "sha256:" + hashlib.sha256(str(store.root.resolve()).encode("utf-8")).hexdigest()

    @staticmethod
    def _operator_hash(value: str) -> str:
        return "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()

    def authorize(
        self,
        *,
        expected_digest: str,
        source: ContentAddressedArtifactStore,
        max_bytes: int,
        approved_by: str,
        evidence_ref: str,
        ttl_seconds: float,
        now: float | None = None,
    ) -> LocalArtifactRecoveryAuthorization:
        """Grant recovery of one present local CAS artifact, never a namespace."""
        self.store._hex(expected_digest)
        if max_bytes <= 0:
            raise ValueError("artifact recovery max_bytes must be positive")
        if ttl_seconds <= 0:
            raise ValueError("artifact recovery TTL must be positive")
        if not approved_by.strip() or not evidence_ref.strip():
            raise ValueError("artifact recovery requires operator and evidence reference")
        # Do not read the source bytes at authorization time: the explicit byte
        # ceiling is enforced before the recovery path reads any blob.
        if not source.path_for(expected_digest).is_file():
            raise FileNotFoundError(f"authorized source artifact is absent: {expected_digest}")
        current = time.time() if now is None else float(now)
        authorization = LocalArtifactRecoveryAuthorization(
            id="artifact-recovery:" + uuid.uuid4().hex,
            expected_digest=expected_digest,
            source_root_hash=self._root_hash(source),
            max_bytes=int(max_bytes),
            expires_at=current + float(ttl_seconds),
            approved_by_hash=self._operator_hash(approved_by),
            evidence_ref=evidence_ref,
            approved_at=current,
        )
        self.wal.append("local_artifact_recovery", {
            "event": "authorized",
            "authorization_id": authorization.id,
            "authorization_hash": authorization.receipt_hash,
            "expected_digest": authorization.expected_digest,
            "source_root_hash": authorization.source_root_hash,
            "max_bytes": authorization.max_bytes,
            "expires_at": authorization.expires_at,
        })
        return authorization

    def _authorization_is_anchored(self, authorization: LocalArtifactRecoveryAuthorization) -> bool:
        try:
            valid, _bad = self.wal.verify_chain()
            if not valid:
                return False
            rows = self.wal.replay(kind="local_artifact_recovery")
        except WALIntegrityError:
            return False
        for row in rows:
            data = row.get("data", {})
            if not isinstance(data, dict) or data.get("authorization_id") != authorization.id:
                continue
            if data.get("event") == "authorized" and data.get("authorization_hash") == authorization.receipt_hash:
                return True
        return False

    def recover(
        self,
        authorization: LocalArtifactRecoveryAuthorization,
        *,
        source: ContentAddressedArtifactStore,
        now: float | None = None,
    ) -> LocalArtifactRecoveryReceipt:
        """Copy exactly one local CAS blob after cap and hash verification."""
        current = time.time() if now is None else float(now)
        self.store._hex(authorization.expected_digest)
        if current >= authorization.expires_at:
            raise ArtifactRecoveryError("artifact recovery authorization expired")
        if not self._authorization_is_anchored(authorization):
            raise ArtifactRecoveryError("artifact recovery authorization lacks a valid WAL anchor")
        source_root_hash = self._root_hash(source)
        if source_root_hash != authorization.source_root_hash:
            raise ArtifactRecoveryError("artifact recovery source store does not match authorization")
        source_path = source.path_for(authorization.expected_digest)
        try:
            declared_size = source_path.stat().st_size
        except FileNotFoundError as exc:
            raise ArtifactRecoveryError("authorized source artifact is missing") from exc
        if declared_size > authorization.max_bytes:
            raise ArtifactRecoveryError("authorized source artifact exceeds byte ceiling before read")
        if self.store.has(authorization.expected_digest):
            ref = self.store.metadata(authorization.expected_digest)
            existing = ArtifactRef(
                digest=str(ref["digest"]), size=int(ref["size"]),
                media_type=str(ref["media_type"]), provenance_digest=str(ref["provenance_digest"]),
            )
            return LocalArtifactRecoveryReceipt(
                authorization_id=authorization.id,
                expected_digest=authorization.expected_digest,
                source_root_hash=source_root_hash,
                recovered_ref=existing,
                status="already-present",
                bytes_copied=0,
            )
        try:
            raw = source.get(authorization.expected_digest)
        except (FileNotFoundError, ArtifactIntegrityError) as exc:
            raise ArtifactRecoveryError(f"source artifact cannot be verified: {type(exc).__name__}") from exc
        if len(raw) > authorization.max_bytes:
            raise ArtifactRecoveryError("authorized source artifact exceeded byte ceiling during read")
        actual = "sha256:" + hashlib.sha256(raw).hexdigest()
        if actual != authorization.expected_digest:
            raise ArtifactRecoveryError("source bytes do not match expected artifact digest")
        # Do not re-read the source blob through ``metadata()`` after copying:
        # a concurrent source mutation must not bypass the already-enforced cap.
        # The recovered bytes remain content-addressed; media type is deliberately
        # conservative rather than trusting a mutable source-side metadata file.
        ref = self.store.put(raw, media_type="application/octet-stream", provenance={
            "recovery": "local-cas-only",
            "authorization_id": authorization.id,
            "source_root_hash": source_root_hash,
            "expected_digest": authorization.expected_digest,
        })
        if ref.digest != authorization.expected_digest:
            raise ArtifactRecoveryError("target CAS returned an unexpected artifact digest")
        receipt = LocalArtifactRecoveryReceipt(
            authorization_id=authorization.id,
            expected_digest=authorization.expected_digest,
            source_root_hash=source_root_hash,
            recovered_ref=ref,
            status="recovered",
            bytes_copied=len(raw),
        )
        self.wal.append("local_artifact_recovery", {
            "event": "recovered",
            "authorization_id": authorization.id,
            "authorization_hash": authorization.receipt_hash,
            "expected_digest": authorization.expected_digest,
            "receipt_hash": _hash(receipt.model_dump(mode="json")),
            "bytes_copied": len(raw),
        })
        return receipt


def _hash(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()
