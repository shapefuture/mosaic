"""Dry-run provider canary planning without provider calls or secrets."""
from __future__ import annotations

import os
from typing import Iterable

from pydantic import BaseModel, ConfigDict

from .provider_canary import KNOWN_CAPABILITIES, PROMOTABLE_CAPABILITIES
from .providers import ProviderCatalog


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ProviderCanaryPlan(_Frozen):
    schema_version: str = "chimera.provider-canary-plan.v1"
    model: str
    provider: str
    protocol: str | None
    implemented: bool
    configured_env_names: tuple[str, ...]
    credential_slots: int
    requested_capabilities: tuple[str, ...]
    promotable_requested: tuple[str, ...]
    observability_only_requested: tuple[str, ...]
    requires_authorize_live_call: bool = True
    would_consume_quota: bool = True
    live_command: tuple[str, ...]
    notes: tuple[str, ...] = (
        "This is a dry-run plan only; no network call was made and no credential value was read into the report.",
        "Only native_tools, strict_json, streaming, and prompt_cache can promote routing capabilities in the current canary path.",
        "sticky_session and response_chain require dedicated endpoint adapters before they can be promoted.",
    )


class ProviderCanaryPlanner:
    def __init__(self) -> None:
        self.catalog = ProviderCatalog()

    @staticmethod
    def _configured_env_names(provider_id: str) -> tuple[str, ...]:
        from .providers import PROVIDERS
        return tuple(key for key in PROVIDERS[provider_id].env_keys if os.environ.get(key))

    def plan(self, model: str, capabilities: Iterable[str]) -> ProviderCanaryPlan:
        requested = tuple(dict.fromkeys(str(item) for item in capabilities))
        unknown = set(requested) - KNOWN_CAPABILITIES
        if unknown:
            raise ValueError(f"unknown canary capabilities: {sorted(unknown)}")
        provider = self.catalog.resolve(model)
        names = self._configured_env_names(provider.id)
        promotable = tuple(item for item in requested if item in PROMOTABLE_CAPABILITIES)
        observability = tuple(item for item in requested if item not in PROMOTABLE_CAPABILITIES)
        command = (
            "chimera",
            "provider-canary",
            model,
            *(part for capability in requested for part in ("--capability", capability)),
            "--authorize-live-call",
        )
        return ProviderCanaryPlan(
            model=model,
            provider=provider.id,
            protocol=provider.protocol,
            implemented=provider.implemented,
            configured_env_names=names,
            credential_slots=len(self.catalog.credentials(provider.id)),
            requested_capabilities=requested,
            promotable_requested=promotable,
            observability_only_requested=observability,
            live_command=command,
        )
