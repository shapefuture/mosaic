"""OpenAI-compatible gateway fidelity benchmark.

Checks the properties Chimera needs before trusting a gateway profile: request
shape, trace/session propagation, streaming TTFT, content receipt, and usage
preservation.  Endpoint and credentials are never recorded in the receipt.
"""
from __future__ import annotations

import json
import os
import pathlib
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass
from typing import Any

from .trace_context import trace_context_headers


@dataclass(frozen=True)
class GatewayFidelityResult:
    schema_version: str
    status: str
    endpoint_host: str | None
    endpoint_recorded: bool
    model: str
    stream: bool
    auth_env_name: str | None
    auth_present: bool
    traceparent_sent: bool
    session_id_sent: bool
    prompt_cache_key_sent: bool
    status_code: int | None
    elapsed_ms: float | None
    ttft_ms: float | None
    content_chars: int
    usage_seen: bool
    chunks: int
    error: str | None
    raw_key_recorded: bool
    promotion_allowed: bool

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class OpenAIGatewayFidelityBenchmark:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def run(
        self,
        *,
        endpoint: str | None,
        model: str,
        auth_env: str | None = None,
        stream: bool = False,
        prompt: str = "ping",
        timeout_seconds: float = 30.0,
    ) -> dict[str, Any]:
        if not endpoint:
            return self._result("skipped", None, model, stream, auth_env, False, False, False, False, None, None, None, 0, False, 0, "endpoint not supplied").as_dict()
        parsed = urllib.parse.urlparse(endpoint)
        host = parsed.hostname
        token = os.environ.get(auth_env) if auth_env else None
        if auth_env and not token:
            return self._result("skipped", host, model, stream, auth_env, False, False, False, False, None, None, None, 0, False, 0, f"auth env {auth_env} not present").as_dict()
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 32,
            "stream": bool(stream),
            "prompt_cache_key": "chimera-gateway-fidelity",
            "session_id": "chimera-gateway-fidelity",
        }
        if stream:
            payload["stream_options"] = {"include_usage": True}
        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = "Bearer " + token
        headers.update(trace_context_headers())
        traceparent_sent = "traceparent" in {k.lower(): v for k, v in headers.items()}
        started = time.perf_counter()
        status_code = None
        ttft = None
        content: list[str] = []
        usage_seen = False
        chunks = 0
        try:
            req = urllib.request.Request(endpoint, data=json.dumps(payload, separators=(",", ":")).encode(), headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=max(1.0, timeout_seconds)) as response:  # noqa: S310 operator-supplied endpoint
                status_code = int(response.status)
                if stream:
                    for raw in response:
                        line = raw.decode("utf-8", errors="replace").strip()
                        if not line:
                            continue
                        if line.startswith("data:"):
                            value = line[5:].strip()
                            if value == "[DONE]":
                                break
                            chunks += 1
                            if ttft is None:
                                ttft = (time.perf_counter() - started) * 1000
                            try:
                                obj = json.loads(value)
                            except json.JSONDecodeError:
                                continue
                            if isinstance(obj.get("usage"), dict):
                                usage_seen = True
                            for choice in obj.get("choices", []) if isinstance(obj.get("choices"), list) else []:
                                delta = choice.get("delta") if isinstance(choice, dict) else None
                                if isinstance(delta, dict) and delta.get("content"):
                                    content.append(str(delta["content"]))
                else:
                    raw_body = response.read()
                    ttft = (time.perf_counter() - started) * 1000
                    obj = json.loads(raw_body.decode("utf-8", errors="replace")) if raw_body else {}
                    usage_seen = isinstance(obj.get("usage"), dict)
                    chunks = 1
                    choices = obj.get("choices") if isinstance(obj, dict) else None
                    if isinstance(choices, list) and choices:
                        msg = choices[0].get("message") if isinstance(choices[0], dict) else None
                        if isinstance(msg, dict):
                            content.append(str(msg.get("content") or ""))
            elapsed = (time.perf_counter() - started) * 1000
            ok = status_code is not None and 200 <= status_code < 300
            return self._result("passed" if ok else "failed", host, model, stream, auth_env, bool(token), traceparent_sent, True, True, status_code, elapsed, ttft, len("".join(content)), usage_seen, chunks, None).as_dict()
        except urllib.error.HTTPError as exc:
            body = ""
            try:
                body = exc.read().decode("utf-8", errors="replace")[:300]
            except Exception:
                pass
            return self._result("failed", host, model, stream, auth_env, bool(token), traceparent_sent, True, True, exc.code, (time.perf_counter() - started) * 1000, ttft, len("".join(content)), usage_seen, chunks, f"HTTPError {exc.code}: {body}").as_dict()
        except Exception as exc:
            return self._result("failed", host, model, stream, auth_env, bool(token), traceparent_sent, True, True, status_code, (time.perf_counter() - started) * 1000, ttft, len("".join(content)), usage_seen, chunks, f"{type(exc).__name__}: {str(exc)[:300]}").as_dict()

    @staticmethod
    def _result(status: str, host: str | None, model: str, stream: bool, auth_env: str | None, auth_present: bool, traceparent_sent: bool, session_id_sent: bool, prompt_cache_key_sent: bool, status_code: int | None, elapsed_ms: float | None, ttft_ms: float | None, content_chars: int, usage_seen: bool, chunks: int, error: str | None) -> GatewayFidelityResult:
        return GatewayFidelityResult(
            schema_version="chimera.openai-gateway-fidelity-benchmark.v1",
            status=status,
            endpoint_host=host,
            endpoint_recorded=False,
            model=model,
            stream=stream,
            auth_env_name=auth_env,
            auth_present=auth_present,
            traceparent_sent=traceparent_sent,
            session_id_sent=session_id_sent,
            prompt_cache_key_sent=prompt_cache_key_sent,
            status_code=status_code,
            elapsed_ms=round(elapsed_ms, 3) if elapsed_ms is not None else None,
            ttft_ms=round(ttft_ms, 3) if ttft_ms is not None else None,
            content_chars=content_chars,
            usage_seen=usage_seen,
            chunks=chunks,
            error=error,
            raw_key_recorded=False,
            promotion_allowed=False,
        )
