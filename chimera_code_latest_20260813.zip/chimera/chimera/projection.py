"""Optional SQLite read projection over the canonical hash-chained WAL."""
from __future__ import annotations

import hashlib
import json
import pathlib
import sqlite3
import time
from typing import Any, Optional

from .wal import WAL, WALIntegrityError


_SCHEMA = """
CREATE TABLE IF NOT EXISTS wal_events (
  seq INTEGER PRIMARY KEY,
  ts TEXT NOT NULL,
  kind TEXT NOT NULL,
  data_json TEXT NOT NULL,
  entry_hash TEXT NOT NULL,
  prev_hash TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_wal_events_kind_seq ON wal_events(kind, seq);
CREATE TABLE IF NOT EXISTS projection_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""


class WALProjection:
    def __init__(self, root: pathlib.Path, path: Optional[pathlib.Path] = None) -> None:
        self.root = pathlib.Path(root).resolve()
        self.wal = WAL(self.root)
        self.path = pathlib.Path(path or (self.root / ".chimera" / "projection.sqlite"))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.path)
        self.connection.executescript(_SCHEMA)

    def close(self) -> None: self.connection.close()

    def refresh(self) -> dict[str, Any]:
        valid, bad = self.wal.verify_chain()
        if not valid: raise WALIntegrityError(f"cannot project corrupt WAL at {bad}")
        row = self.connection.execute("SELECT COALESCE(MAX(seq), -1) FROM wal_events").fetchone()
        after = int(row[0]) if row else -1
        entries = self.wal.replay(after_seq=after)
        started = time.perf_counter()
        with self.connection:
            for entry in entries:
                self.connection.execute(
                    "INSERT INTO wal_events(seq,ts,kind,data_json,entry_hash,prev_hash) VALUES(?,?,?,?,?,?)",
                    (entry["seq"], entry["ts"], entry["kind"],
                     json.dumps(entry["data"], sort_keys=True, separators=(",", ":")),
                     entry["hash"], entry["prev_hash"]),
                )
            head = self.wal._prev_hash
            self.connection.execute(
                "INSERT INTO projection_meta(key,value) VALUES('wal_head',?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (head,),
            )
        elapsed = time.perf_counter() - started
        return {
            "projected": len(entries), "after_seq": after,
            "duration_ms": elapsed * 1000,
            "events_per_second": len(entries) / elapsed if elapsed and entries else 0.0,
            "wal_head": self.wal._prev_hash,
            "canonical_source": str(self.wal.path),
        }

    def query(self, *, kind: Optional[str] = None, after_seq: int = -1, limit: int = 100) -> list[dict[str, Any]]:
        limit = min(10_000, max(1, int(limit)))
        if kind:
            rows = self.connection.execute(
                "SELECT seq,ts,kind,data_json,entry_hash,prev_hash FROM wal_events "
                "WHERE seq>? AND kind=? ORDER BY seq LIMIT ?", (after_seq, kind, limit),
            ).fetchall()
        else:
            rows = self.connection.execute(
                "SELECT seq,ts,kind,data_json,entry_hash,prev_hash FROM wal_events "
                "WHERE seq>? ORDER BY seq LIMIT ?", (after_seq, limit),
            ).fetchall()
        return [
            {"seq": row[0], "ts": row[1], "kind": row[2], "data": json.loads(row[3]),
             "hash": row[4], "prev_hash": row[5]}
            for row in rows
        ]

    def verify(self) -> dict[str, Any]:
        rows = self.query(limit=10_000)
        wal_rows = self.wal.replay()
        valid = len(rows) == len(wal_rows) and all(
            left["seq"] == right["seq"] and left["hash"] == right["hash"]
            for left, right in zip(rows, wal_rows)
        )
        return {"valid": valid, "projection_rows": len(rows), "wal_rows": len(wal_rows)}
