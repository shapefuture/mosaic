"""Hidden post-hoc verification that is never fed back into self-heal details."""
from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib, json, os, pathlib
from typing import Any, Mapping, Iterable
from .artifacts import ContentAddressedArtifactStore

@dataclass(frozen=True)
class HeldOutResult:
    passed: bool
    score: float
    evidence_ref: str
    reasons: tuple[str, ...]
    semantic_review: dict[str, Any] | None = None
    def as_dict(self): return asdict(self)

class HeldOutVerifier:
    def __init__(self, root: pathlib.Path):
        self.root=pathlib.Path(root).resolve(); self.store=ContentAddressedArtifactStore(self.root)
    @staticmethod
    def _should_semantic_review(task:str, paths:list[str], score:float)->bool:
        lower=task.lower()
        if os.environ.get("CHIMERA_HELDOUT_SEMANTIC") == "1": return True
        if score < .9: return True
        return any(w in lower for w in ("auth","security","payment","credential","permission","migration")) or any("auth" in p or "security" in p for p in paths)
    @staticmethod
    def _semantic_review(task:str, paths:list[str], answer:str)->dict[str,Any]:
        findings=[]; score=1.0; lower=task.lower(); text=answer.lower()
        if any(w in lower for w in ("fix","implement","add")) and not paths:
            findings.append("task asks for implementation but no user-visible changed path exists"); score-=.3
        if any(w in lower for w in ("auth","security","permission","credential")) and not any(w in text for w in ("test","verify","coverage","risk","rollback")):
            findings.append("security-sensitive answer lacks verification/risk discussion"); score-=.3
        if len(paths)>10:
            findings.append("patch touches many paths; maintainer review likely required"); score-=.15
        return {"score":max(0.0,score),"findings":findings,"reviewer":"deterministic-maintainer-rubric"}
    def evaluate(self, *, task: str, diff: Mapping[str,Any]|None, traces: Iterable[Mapping[str,Any]], answer: str="") -> HeldOutResult:
        reasons=[]; score=1.0
        ops=(diff or {}).get("ops",[]) if isinstance(diff,Mapping) else []
        paths=[str(op.get("path","")) for op in ops if isinstance(op,Mapping) and op.get("path") and not str(op.get("path","")).startswith(".chimera/")]
        lower=task.lower()
        if any(w in lower for w in ("explain","inspect","investigate","why")) and paths:
            reasons.append("assessment/investigation task produced workspace writes"); score-=0.5
        if any(token in answer for token in ("TODO: implement","YOUR CODE HERE","<complete content>")):
            reasons.append("answer contains placeholder completion text"); score-=0.25
        statuses=[]
        for row in traces:
            data=row.get("data",{}) if isinstance(row,Mapping) else {}
            if row.get("kind")=="test_result" and isinstance(data,Mapping) and isinstance(data.get("status"),int): statuses.append(data["status"])
        if not paths and any(w in lower for w in ("fix", "implement", "add", "create")):
            reasons.append("mutation-shaped task produced no user-visible changed path"); score-=0.45
        if paths and statuses and all(s!=0 for s in statuses):
            reasons.append("changed files but no passing held-out/test evidence"); score-=0.25
        semantic=None
        if self._should_semantic_review(task,paths,score):
            semantic=self._semantic_review(task,paths,answer)
            score=min(score,float(semantic["score"]))
            reasons.extend(semantic.get("findings",[]))
        score=max(0.0,score); passed=score>=0.75
        payload={"task_hash":"sha256:"+hashlib.sha256(task.encode()).hexdigest(),"paths":paths,"score":score,"reasons":reasons,"semantic_review":semantic}
        ref=self.store.put(json.dumps(payload,sort_keys=True),media_type="application/vnd.chimera.heldout+json",provenance={"kind":"heldout-verification"})
        return HeldOutResult(passed,score,"artifact:"+ref.digest,tuple(reasons),semantic)
