"""Dedicated durable tool-call trace stream and conservative local miners.

The canonical WAL remains the authority for accepted state transitions. This
separate stream is deliberately privacy-minimal, high-volume operational data
for tool reliability and scheduling analysis. It never promotes a policy or
executes a synthesized improvement.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import pathlib
import re
import time
from typing import Any, Iterable, Mapping

from .action_ir import ActionIR, Reversibility
from .wal import WAL


@dataclass(frozen=True)
class ToolTrace:
    run_id: str
    request_id: str
    action_id: str
    tool: str
    state: str
    argument_hash: str
    effect_row: tuple[str, ...]
    elapsed_ms: float | None = None
    outcome_hash: str | None = None
    error_signature: str | None = None


@dataclass(frozen=True)
class FailureCluster:
    tool: str
    error_signature: str
    samples: int
    action_ids: tuple[str, ...]
    status: str  # insufficient-data | hypothesis
    recommendation: str


@dataclass(frozen=True)
class ParallelizationCandidate:
    before: str
    after: str
    reason: str


class ToolTraceLedger:
    def __init__(self, root: pathlib.Path) -> None:
        self.wal = WAL(pathlib.Path(root))

    @staticmethod
    def _hash(value: Any) -> str:
        raw = repr(value).encode("utf-8", errors="replace")
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    @staticmethod
    def _error_signature(value: Any) -> str | None:
        if not value:
            return None
        text = str(value).lower()
        text = re.sub(r"[0-9a-f]{8,}", "<hex>", text)
        text = re.sub(r"\d+", "<n>", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text[:160] or None

    def record_action(self, *, run_id: str, request_id: str, action: ActionIR, state: str, elapsed_ms: float | None = None, outcome: Mapping[str, Any] | None = None) -> ToolTrace:
        result = dict(outcome or {})
        row = ToolTrace(
            run_id=str(run_id), request_id=str(request_id), action_id=action.action_id,
            tool=action.kind.value, state=str(state), argument_hash=action.argument_digest,
            effect_row=tuple(sorted(action.effect_row)), elapsed_ms=round(float(elapsed_ms), 3) if elapsed_ms is not None else None,
            outcome_hash=self._hash(result) if outcome is not None else None,
            error_signature=self._error_signature(result.get("error")),
        )
        self.wal.append("tool_trace", asdict(row))
        return row

    def failure_clusters(self, *, minimum_samples: int = 3) -> tuple[FailureCluster, ...]:
        groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
        for entry in self.wal.replay(kind="tool_trace"):
            row = entry.get("data", {})
            signature = row.get("error_signature")
            if isinstance(signature, str) and signature:
                groups.setdefault((str(row.get("tool", "unknown")), signature), []).append(row)
        output: list[FailureCluster] = []
        for (tool, signature), rows in sorted(groups.items()):
            samples = len(rows)
            output.append(FailureCluster(
                tool, signature, samples, tuple(sorted({str(row.get("action_id", "")) for row in rows})),
                "hypothesis" if samples >= minimum_samples else "insufficient-data",
                "create a held-out precondition/contract hypothesis; never auto-promote" if samples >= minimum_samples else f"need {minimum_samples} matching failures before proposing a hypothesis",
            ))
        return tuple(output)


def parallelization_candidates(actions: Iterable[ActionIR]) -> tuple[ParallelizationCandidate, ...]:
    """Find only *candidate* removable read dependencies; never rewrite them."""
    by_id = {action.action_id: action for action in actions}
    output: list[ParallelizationCandidate] = []
    for action in by_id.values():
        if action.reversibility is not Reversibility.READ_ONLY:
            continue
        for dep_id in action.dependencies:
            dep = by_id.get(dep_id)
            if dep is None or dep.reversibility is not Reversibility.READ_ONLY:
                continue
            conflict = bool((action.read_set | action.write_set) & (dep.write_set) or (dep.read_set | dep.write_set) & action.write_set)
            if not conflict:
                output.append(ParallelizationCandidate(dep_id, action.action_id, "declared read-only dependency has no static read/write hazard; review semantic dependency before removal"))
    return tuple(output)
