"""Deterministic local shard controller for cloud-scale smoke tests."""
from __future__ import annotations

import hashlib
import math
import pathlib
import time
from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class AgentLease:
    run_id: str
    tenant_id: str
    shard_id: str
    tier: str
    status: str = "leased"
    leased_at: float = field(default_factory=time.time)


class LocalAgentShardController:
    def __init__(self, *, agents: int, tenants: int, max_agents_per_shard: int = 250):
        self.agents = max(1, int(agents))
        self.tenants = max(1, min(int(tenants), self.agents))
        self.max_agents_per_shard = max(1, int(max_agents_per_shard))
        self.shards = max(1, math.ceil(self.agents / self.max_agents_per_shard) * 2, math.ceil(self.tenants / 50))
        self.leases: dict[str, AgentLease] = {}
        self.drained: set[str] = set()

    def assign_run(self, run_id: str, tenant_id: str) -> str:
        key = f"{tenant_id}:{run_id}".encode()
        base = int(hashlib.sha256(key).hexdigest(), 16) % self.shards
        for offset in range(self.shards):
            shard = f"shard-{(base + offset) % self.shards:04d}"
            if shard not in self.drained:
                return shard
        return f"shard-{base:04d}"

    def lease_agent(self, run_id: str, tenant_id: str, tier: str) -> AgentLease:
        if tier not in {"hot", "warm", "cold"}:
            raise ValueError("tier must be hot, warm, or cold")
        lease = AgentLease(run_id, tenant_id, self.assign_run(run_id, tenant_id), tier)
        self.leases[run_id] = lease
        return lease

    def hibernate(self, run_id: str) -> None:
        self.leases[run_id].status = "hibernated"
        self.leases[run_id].tier = "cold"

    def wake(self, run_id: str) -> None:
        self.leases[run_id].status = "leased"
        self.leases[run_id].tier = "hot"

    def drain_shard(self, shard_id: str) -> int:
        self.drained.add(shard_id)
        moved = 0
        for lease in self.leases.values():
            if lease.shard_id == shard_id:
                lease.shard_id = self.assign_run(lease.run_id + ":rebalance", lease.tenant_id)
                moved += 1
        return moved

    def status(self) -> dict[str, Any]:
        counts: dict[str, int] = {}
        tiers = {"hot": 0, "warm": 0, "cold": 0}
        for lease in self.leases.values():
            counts[lease.shard_id] = counts.get(lease.shard_id, 0) + 1
            tiers[lease.tier] = tiers.get(lease.tier, 0) + 1
        return {"shards": self.shards, "leases": len(self.leases), "drained": sorted(self.drained), "shard_counts": counts, "tiers": tiers}


def cloud_scale_smoke(root: pathlib.Path, *, agents: int = 1000, tenants: int = 100) -> dict[str, Any]:
    controller = LocalAgentShardController(agents=agents, tenants=tenants)
    hot = max(1, math.ceil(agents * 0.05))
    warm = max(0, math.ceil(agents * 0.20))
    for i in range(agents):
        tier = "hot" if i < hot else "warm" if i < hot + warm else "cold"
        controller.lease_agent(f"run-{i}", f"tenant-{i % tenants}", tier)
    for i in range(min(10, agents)):
        controller.hibernate(f"run-{i}")
        controller.wake(f"run-{i}")
    first_shard = "shard-0000"
    moved = controller.drain_shard(first_shard)
    status = controller.status()
    overloaded = {k: v for k, v in status["shard_counts"].items() if v > controller.max_agents_per_shard}
    return {
        "schema_version": "chimera.cloud-scale-smoke.v1",
        "root": str(pathlib.Path(root).resolve()),
        "agents": agents,
        "tenants": tenants,
        "suggested_shards": controller.shards,
        "moved_from_drained_shard": moved,
        "status": status,
        "overloaded_shards": overloaded,
        "all_leases_unique": len(controller.leases) == agents,
        "drain_successful": first_shard in status["drained"] and first_shard not in status["shard_counts"],
        "promotion_allowed": False,
    }
