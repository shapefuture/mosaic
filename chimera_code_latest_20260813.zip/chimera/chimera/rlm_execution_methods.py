"""Action execution methods for RLMRuntime."""
from __future__ import annotations

import concurrent.futures
import hashlib
import json
import pathlib
import re
import shlex
import time
from typing import Any, Dict, List, Mapping

from .action_ir import OperationKind, ToolSurfaceError
from .kernel import KernelPolicyError, PersistentReadOnlyKernel
from .sandbox import Sandbox


class RLMExecutionMixin:
    @staticmethod
    def _state_digest(value: bytes) -> str:
        return "sha256:" + hashlib.sha256(value).hexdigest()

    def _workspace_view_precondition(self, branch: str) -> str:
        """Hash the locally visible, capability-filtered workspace view.

        This is deliberately used only for broad read operations (list/shell).
        Direct file operations bind the exact file digest instead.  The value is
        a local adapter observation; no source bytes or path contents are put
        in certificates/WAL receipts.
        """
        capability = self.config.to_capability_set()
        rows: list[tuple[str, str]] = []
        for path in sorted(self.root.rglob("*")):
            if not path.is_file() or ".chimera" in path.parts:
                continue
            try:
                rel = path.relative_to(self.root).as_posix()
            except ValueError:
                continue
            if not capability.is_fs_allowed(rel):
                continue
            try:
                rows.append((rel, self._state_digest(path.read_bytes())))
            except OSError:
                rows.append((rel, "unreadable"))
        # Overlay bytes take precedence over the base workspace in a branch.
        # The branch diff includes bytes hashes, delete markers, and paths.
        return "sha256:" + hashlib.sha256(
            json.dumps({"base": rows, "branch": self.workspace.diff(branch)}, sort_keys=True, separators=(",", ":"), default=str).encode()
        ).hexdigest()

    def _action_precondition_observation(self, branch: str, action) -> Dict[str, Any]:
        """Observe only state the local ActionIR adapter actually consumes."""
        observed: Dict[str, Any] = {
            "branch": str(branch),
            "operation": action.kind.value,
            "action_digest": action.argument_digest,
        }
        for resource in sorted(action.read_set | action.write_set):
            if resource == "<workspace>":
                observed["workspace_view"] = self._workspace_view_precondition(branch)
                continue
            if resource == "<graph>":
                graph_path = self.root / ".chimera" / "graph.json"
                observed["graph_state"] = self._state_digest(graph_path.read_bytes()) if graph_path.is_file() else "absent"
                continue
            if resource.startswith("<artifact:") and resource.endswith(">"):
                digest = resource[len("<artifact:"):-1]
                observed[f"artifact:{digest}"] = bool(self.artifacts.has(digest))
                continue
            try:
                content = self.workspace.read(branch, resource)
                observed[f"path:{resource}"] = {"state": "file", "digest": self._state_digest(content)}
            except FileNotFoundError:
                observed[f"path:{resource}"] = {"state": "absent", "digest": None}
        return observed

    def _validate_thread_action_admission(self, branch: str) -> Dict[str, Any] | None:
        """Run certificate + freshness validation at the actual executor boundary."""
        admission = getattr(self._thread_local, "action_dispatch", None)
        if admission is None:
            return None
        from .action_admission import validate_local_admission
        current = self._action_precondition_observation(branch, admission.action)
        check = validate_local_admission(self.action_certificates, admission, current)
        self.action_execution_receipts.record(
            admission, phase="point_of_use", allowed=check.allowed, reason=check.reason, stale=check.stale,
        )
        if check.allowed:
            return None
        return {
            "ok": False, "tool": admission.action.kind.value,
            "error": f"action admission blocked: {check.reason}",
            "stale_preconditions": list(check.stale),
            "action_certificate": admission.certificate.id,
        }

    def _execute_model_tool(self, branch: str, call: Dict[str, Any], allow_write: bool) -> Dict[str, Any]:
        from .effects import EffectRequest, check_effect

        admission_failure = self._validate_thread_action_admission(branch)
        if admission_failure is not None:
            return admission_failure
        name = str(call.get("name", "")).lower()
        arguments = call.get("arguments") if isinstance(call.get("arguments"), dict) else {}
        exposure_session = getattr(self._thread_local, "exposure_session", branch)
        try:
            if name in {"read", "read_file", "fs.read"}:
                rel = self._normalise_tool_path(str(arguments.get("path", "")))
                verdict = check_effect(
                    EffectRequest(effect="fs.read", needs={"fs": [rel]}),
                    self.config.to_capability_set(),
                )
                if not verdict.allowed or verdict.residual_obligations:
                    return {"ok": False, "tool": name, "error": verdict.denied_reason or str(verdict.residual_obligations)}
                raw_content = self.workspace.read(branch, rel)
                read_digest = self.awareness.read(branch, rel, raw_content)
                content, cache_hit = self.branch_read_cache.get(branch, rel, raw_content)
                lines = content.splitlines(keepends=True)
                mode = str(arguments.get("mode", "auto"))
                explicit_span = "start" in arguments or "end" in arguments
                state_root = self.workspace.diff(branch).get("id", "")
                if mode == "structure" or (mode == "auto" and len(lines) > 400 and not explicit_span):
                    from .context_memory import structural_page
                    page = structural_page(rel, content)
                    if mode == "auto" and not self.exposure.first(exposure_session, state_root, f"structure:{rel}:{page.content_hash}"):
                        return {"ok": True, "tool": name, "path": rel, "mode": "exposure-summary",
                                "content": f"[unchanged structure already exposed: {rel} {page.content_hash}]",
                                "suppressed_seen": True, "content_hash": page.content_hash, "truncated": True}
                    ref = self.artifacts.put(
                        content, media_type="text/plain",
                        provenance={"tool": "read_file", "path": rel, "mode": "structure", "branch": branch},
                    )
                    return {
                        "ok": True, "tool": name, "path": rel, "mode": "structure",
                        "content": page.text, "line_count": page.line_count,
                        "symbols": len(page.symbols), "content_hash": page.content_hash,
                        "artifact_ref": ref.to_dict(), "truncated": True, "branch_cache_hit": cache_hit,
                        "hint": "use artifact_read with the digest for exact source spans",
                    }
                try:
                    start = max(1, int(arguments.get("start", 1)))
                except (TypeError, ValueError):
                    start = 1
                try:
                    end = int(arguments.get("end", min(len(lines), start + 249)))
                except (TypeError, ValueError):
                    end = min(len(lines), start + 249)
                end = max(start, min(len(lines), end))
                raw_excerpt = "".join(lines[start - 1:end])
                span_hash = "sha256:" + hashlib.sha256(raw_excerpt.encode()).hexdigest()
                if mode == "auto" and not self.exposure.first(exposure_session, state_root, f"source:{rel}:{start}:{end}:{span_hash}"):
                    return {"ok": True, "tool": name, "path": rel, "start": start, "end": end,
                            "mode": "exposure-summary", "content": f"[unchanged source span already exposed: {rel} L{start}-{end} {span_hash}]",
                            "suppressed_seen": True, "content_hash": span_hash, "truncated": True}
                excerpt, clipped, artifact_ref = self._budget_tool_text(
                    raw_excerpt, max_chars=20_000,
                    provenance={"tool": "read_file", "path": rel, "start": start, "end": end, "branch": branch},
                )
                result = {
                    "ok": True, "tool": name, "path": rel, "start": start, "end": end,
                    "content": excerpt,
                    "truncated": end < len(lines) or clipped,
                    "branch_cache_hit": cache_hit,
                }
                if artifact_ref:
                    result["artifact_ref"] = artifact_ref
                return result
            if name in {"list", "list_files", "glob"}:
                pattern = str(arguments.get("pattern") or arguments.get("path") or "**/*")
                capability = self.config.to_capability_set()
                files = sorted(
                    str(path.relative_to(self.root)).replace("\\", "/")
                    for path in self.root.glob(pattern)
                    if path.is_file()
                    and ".chimera" not in path.parts
                    and capability.is_fs_allowed(str(path.relative_to(self.root)).replace("\\", "/"))
                )
                result: Dict[str, Any] = {"ok": True, "tool": name, "files": files[:200], "truncated": len(files) > 200}
                if len(files) > 200:
                    ref = self.artifacts.put(
                        json.dumps(files, separators=(",", ":")), media_type="application/json",
                        provenance={"tool": "list_files", "pattern": pattern, "branch": branch},
                    )
                    result["artifact_ref"] = ref.to_dict()
                return result
            if name in {"graph", "graph_search", "search", "graph_query"}:
                query = str(arguments.get("query") or arguments.get("q") or "")
                hits = self.graph.search(query, limit=10)
                state_root = self.workspace.diff(branch).get("id", "")
                ids = [str(hit.get("id") or index) for index, hit in enumerate(hits)]
                fresh_ids, seen_ids = self.exposure.filter_ids(exposure_session, state_root, ids)
                fresh = [hit for hit, identity in zip(hits, ids) if identity in set(fresh_ids)]
                return {"ok": True, "tool": name, "hits": fresh,
                        "suppressed_seen": len(seen_ids), "total_hits": len(hits),
                        "exposure_state": self.exposure.report(exposure_session)}
            if name in {"shell", "bash", "exec", "shell_read"}:
                command = str(arguments.get("command") or arguments.get("cmd") or "")
                command = command.replace(str(self.root), ".")
                try:
                    parts = shlex.split(command)
                except ValueError as exc:
                    return {"ok": False, "tool": name, "error": f"invalid shell syntax: {exc}"}
                executable = pathlib.PurePosixPath(parts[0]).name if parts else ""
                readonly = {"cat", "sed", "grep", "rg", "head", "tail", "find", "ls", "pwd", "wc"}
                if executable not in readonly or any(token in command for token in (">", "|", ";", "&&", "`", "$(")):
                    return {"ok": False, "tool": name, "error": "shell tool permits one read-only command only; use write_file/edit_file for writes"}
                sandbox = Sandbox(self.root, self.config.to_capability_set(), branch=branch, workspace=self.workspace)
                process = sandbox.exec(command, timeout=20)
                full_output = process.stdout + process.stderr
                bounded, clipped, artifact_ref = self._budget_tool_text(
                    full_output, max_chars=20_000,
                    provenance={"tool": "shell_read", "command_digest": hashlib.sha256(command.encode()).hexdigest(), "branch": branch},
                )
                result = {
                    "ok": process.status == 0, "tool": name,
                    "command_digest": hashlib.sha256(command.encode()).hexdigest(),
                    "status": process.status, "content": bounded, "truncated": clipped,
                    "error": None if process.status == 0 else process.stderr[-1000:],
                }
                if artifact_ref:
                    result["artifact_ref"] = artifact_ref
                return result
            if name in {"artifact_search", "cas.search"}:
                digest = str(arguments.get("digest") or "")
                query = str(arguments.get("query") or "").strip()
                if not query:
                    return {"ok": False, "tool": name, "error": "artifact search query must be non-empty"}
                try:
                    limit = min(50, max(1, int(arguments.get("max_lines", 12))))
                except (TypeError, ValueError):
                    return {"ok": False, "tool": name, "error": "max_lines must be an integer"}
                raw = self.artifacts.get(digest).decode("utf-8", errors="replace")
                terms = [term.lower() for term in re.findall(r"[A-Za-z0-9_./:-]{2,}", query)]
                ranked = []
                for line_number, line in enumerate(raw.splitlines(), 1):
                    lowered = line.lower()
                    score = sum(term in lowered for term in terms)
                    if score:
                        excerpt = line if len(line) <= 600 else line[:440] + " … " + line[-140:]
                        ranked.append((score, line_number, excerpt))
                ranked.sort(key=lambda item: (-item[0], item[1]))
                return {
                    "ok": True, "tool": name, "digest": digest, "query": query,
                    "matches": [{"line": line, "text": text} for _, line, text in ranked[:limit]],
                    "match_count": len(ranked),
                    "artifact_ref": self.artifacts.metadata(digest) | {"digest": digest},
                }
            if name in {"artifact", "artifact_read", "cas.read"}:
                digest = str(arguments.get("digest") or "")
                raw = self.artifacts.get(digest).decode("utf-8", errors="replace")
                try:
                    start = max(0, int(arguments.get("start", 0)))
                    end = min(len(raw), int(arguments.get("end", min(len(raw), start + 20_000))))
                except (TypeError, ValueError):
                    return {"ok": False, "tool": name, "error": "start/end must be integers"}
                if end < start:
                    return {"ok": False, "tool": name, "error": "end must be >= start"}
                selected = raw[start:end]
                bounded, clipped, _ = self._budget_tool_text(
                    selected, max_chars=20_000,
                    provenance={"tool": "artifact_read", "source_digest": digest, "start": start, "end": end},
                )
                return {
                    "ok": True, "tool": name, "digest": digest, "start": start, "end": end,
                    "content": bounded, "truncated": clipped or end < len(raw),
                    "artifact_ref": self.artifacts.metadata(digest) | {"digest": digest},
                }
            if name in {"write", "write_file", "fs.write"}:
                if not allow_write:
                    return {"ok": False, "tool": name, "error": "writes are disabled for this role"}
                rel = self._normalise_tool_path(str(arguments.get("path", "")))
                scope_error = self._task_write_scope_error(rel)
                if scope_error:
                    return {"ok": False, "tool": name, "error": scope_error}
                content = arguments.get("content")
                if not isinstance(content, str):
                    return {"ok": False, "tool": name, "error": "content must be a string"}
                verdict = check_effect(EffectRequest(effect="fs.write", needs={"fs": [rel]}), self.config.to_capability_set())
                if not verdict.allowed or verdict.residual_obligations:
                    return {"ok": False, "tool": name, "error": verdict.denied_reason or str(verdict.residual_obligations)}
                self.workspace.write(branch, rel, content)
                awareness = self.awareness.write(branch, rel, content.encode())
                return {"ok": True, "tool": name, "path": rel, "bytes": len(content.encode()),
                        "conflict_notifications": awareness["notified"], "digest": awareness["digest"]}
            if name in {"edit", "edit_file", "fs.edit"}:
                if not allow_write:
                    return {"ok": False, "tool": name, "error": "writes are disabled for this role"}
                rel = self._normalise_tool_path(str(arguments.get("path", "")))
                scope_error = self._task_write_scope_error(rel)
                if scope_error:
                    return {"ok": False, "tool": name, "error": scope_error}
                old = arguments.get("old_text") or arguments.get("find")
                new = arguments.get("new_text") or arguments.get("replace")
                if not isinstance(old, str) or not isinstance(new, str):
                    return {"ok": False, "tool": name, "error": "old_text/new_text must be strings"}
                current_bytes = self.workspace.read(branch, rel)
                self.awareness.read(branch, rel, current_bytes)
                current = current_bytes.decode("utf-8", errors="replace")
                if current.count(old) != 1:
                    return {"ok": False, "tool": name, "error": f"old block matched {current.count(old)} times"}
                verdict = check_effect(EffectRequest(effect="fs.write", needs={"fs": [rel]}), self.config.to_capability_set())
                if not verdict.allowed or verdict.residual_obligations:
                    return {"ok": False, "tool": name, "error": verdict.denied_reason or str(verdict.residual_obligations)}
                updated = current.replace(old, new, 1)
                self.workspace.write(branch, rel, updated)
                awareness = self.awareness.write(branch, rel, updated.encode())
                return {"ok": True, "tool": name, "path": rel,
                        "conflict_notifications": awareness["notified"], "digest": awareness["digest"]}
            return {"ok": False, "tool": name, "error": "unknown or disallowed tool"}
        except Exception as exc:
            return {"ok": False, "tool": name, "error": f"{type(exc).__name__}: {exc}"}

    @staticmethod
    def _literal_kernel_batch_calls(code: str) -> List[Dict[str, Any]]:
        """Extract independent literal host reads from a kernel program.

        This is an optimization only. Any dynamic/unsupported call remains on
        the normal one-at-a-time path, preserving the kernel's semantics.
        Because the kernel exposes no writes, prefetching literal reads cannot
        observe a different workspace state.
        """
        import ast
        try:
            tree = ast.parse(code, mode="exec")
        except SyntaxError:
            return []
        calls: List[Dict[str, Any]] = []
        for statement in tree.body:
            value = statement.value if isinstance(statement, ast.Expr) else statement.value if isinstance(statement, ast.Assign) else None
            if not isinstance(value, ast.Call) or not isinstance(value.func, ast.Name):
                continue
            name = value.func.id
            if name not in {"read", "list_files", "graph", "artifact"}:
                continue
            try:
                args = [ast.literal_eval(node) for node in value.args]
                kwargs = {keyword.arg: ast.literal_eval(keyword.value) for keyword in value.keywords if keyword.arg is not None}
            except (ValueError, TypeError):
                continue
            if len(kwargs) != len(value.keywords):
                continue
            if name == "read" and 1 <= len(args) <= 3:
                arguments: Dict[str, Any] = {"path": args[0]}
                if len(args) > 1: arguments["start"] = args[1]
                if len(args) > 2: arguments["end"] = args[2]
                arguments.update(kwargs); internal = "read_file"
            elif name == "list_files" and len(args) <= 1:
                arguments = ({"pattern": args[0]} if args else {}) | kwargs; internal = "list_files"
            elif name == "graph" and len(args) == 1 and not kwargs:
                arguments = {"query": args[0]}; internal = "graph_query"
            elif name == "artifact" and 1 <= len(args) <= 3:
                arguments = {"digest": args[0]}
                if len(args) > 1: arguments["start"] = args[1]
                if len(args) > 2: arguments["end"] = args[2]
                arguments.update(kwargs); internal = "artifact_read"
            else:
                continue
            if not all(isinstance(item, (str, int, float, bool, type(None))) for item in arguments.values()):
                continue
            calls.append({"id": f"kernel-batch-{len(calls)}", "name": internal, "arguments": arguments})
        return calls

    def _execute_kernel_call(
        self, branch: str, outer_calls: List[Dict[str, Any]]
    ) -> tuple[Dict[str, Any], List[Dict[str, Any]]]:
        evidence: List[Dict[str, Any]] = []
        if len(outer_calls) != 1:
            return ({
                "ok": False, "tool": "chimera.py",
                "error": "kernel mode requires exactly one chimera.py call per turn",
            }, evidence)
        outer = outer_calls[0]
        if str(outer.get("name", "")).strip().lower() != "chimera.py":
            return ({
                "ok": False, "tool": "chimera.py",
                "error": "chimera.py is the only model-visible tool in kernel mode",
            }, evidence)
        if set(outer) - {"name", "arguments"}:
            return ({"ok": False, "tool": "chimera.py", "error": "unknown kernel envelope field"}, evidence)
        arguments = outer.get("arguments")
        if not isinstance(arguments, dict) or set(arguments) - {"code"} or not isinstance(arguments.get("code"), str):
            return ({
                "ok": False, "tool": "chimera.py",
                "error": "chimera.py requires exactly one string argument: code",
            }, evidence)
        host_counter = 0
        # Prefetch only literal read-only host calls. The kernel still executes
        # its bounded AST program in order; it simply receives already-checked
        # results for independent calls instead of recompiling each one.
        cached_host_results: Dict[str, Dict[str, Any]] = {}
        batch_calls = self._literal_kernel_batch_calls(arguments["code"])
        if batch_calls:
            batch_plan = self.tool_compiler.compile(
                batch_calls, capability=self.config.to_capability_set(), allow_write=False,
            )
            evidence.append({
                "tool": "kernel_action_compiler", "ok": not batch_plan.diagnostics,
                "batched_prefetch": True, **batch_plan.evidence(),
            })
            if not batch_plan.diagnostics and batch_plan.actions:
                action_results, schedule = self._execute_compiled_actions(branch, batch_plan, allow_write=False)
                evidence.append({"tool": "kernel_action_scheduler", "ok": True, "batched_prefetch": True, **schedule})
                for action in batch_plan.actions:
                    result = action_results[action.action_id]
                    for source_index in action.source_indices:
                        original = batch_calls[source_index]
                        signature = json.dumps(
                            {"name": original["name"], "arguments": original["arguments"]}, sort_keys=True,
                        )
                        cached_host_results[signature] = result
                        evidence.append({key: value for key, value in result.items() if key != "content"})

        def host_call(call: Dict[str, Any]) -> Dict[str, Any]:
            nonlocal host_counter
            signature = json.dumps(
                {"name": call.get("name"), "arguments": call.get("arguments", {})}, sort_keys=True,
            )
            if signature in cached_host_results:
                return dict(cached_host_results[signature])
            host_counter += 1
            checked = {"id": f"host-{host_counter}", **call}
            plan = self.tool_compiler.compile(
                [checked], capability=self.config.to_capability_set(), allow_write=False
            )
            evidence.append({
                "tool": "kernel_action_compiler", "ok": not plan.diagnostics,
                **plan.evidence(),
            })
            if plan.diagnostics or not plan.actions:
                diagnostic = plan.diagnostics[0] if plan.diagnostics else None
                return {
                    "ok": False, "tool": str(call.get("name", "")),
                    "error": (
                        f"{diagnostic.code}: {diagnostic.message}" if diagnostic
                        else "kernel host call produced no action"
                    ),
                }
            # Route even one-off kernel host reads through the same local
            # certificate/precondition/outcome path as the declarative surface.
            action_results, schedule = self._execute_compiled_actions(branch, plan, allow_write=False)
            result = action_results[plan.actions[0].action_id]
            evidence.append({"tool": "kernel_action_scheduler", "ok": True, **schedule})
            evidence.append({key: value for key, value in result.items() if key != "content"})
            return result

        kernel = self._kernels.setdefault(branch, PersistentReadOnlyKernel())
        try:
            result = kernel.execute(arguments["code"], host_call)
            rendered = json.dumps(result.output, ensure_ascii=False, default=str)
            bounded, truncated, artifact_ref = self._budget_tool_text(
                rendered, max_chars=20_000,
                provenance={"tool": "chimera.py", "branch": branch, "statements": result.statements},
                media_type="application/json",
            )
            response: Dict[str, Any] = {
                "ok": True, "tool": "chimera.py", "output": bounded,
                "output_truncated": truncated, "variables": result.variables,
                "statements": result.statements, "host_calls": len(result.host_results),
            }
            if artifact_ref:
                response["artifact_ref"] = artifact_ref
            return response, evidence
        except KernelPolicyError as exc:
            return ({"ok": False, "tool": "chimera.py", "error": str(exc)}, evidence)

    def _bind_wire_evidence(self, envelope, *, purpose: str, model: str, branch: str) -> Dict[str, Any]:
        receipt = self.context_evidence.bind_envelope(
            envelope, purpose=purpose, model=model, session=branch
        )
        return {
            "tool": "context_evidence", "ok": True, "purpose": purpose,
            "receipt_hash": receipt.receipt_hash, "pack_root": receipt.pack_root,
            "wire_hash": receipt.wire_hash, "key_id": receipt.key_id,
            "signing_scope": receipt.signing_scope,
        }

    def _execute_compiled_actions(self, branch: str, plan, allow_write: bool, *, lifecycle_request=None, certificate_context_hash: str = "") -> tuple[Dict[str, Dict[str, Any]], Dict[str, Any]]:
        """Stream ready read actions; serialize writes without level barriers."""
        from .run_lifecycle import ActionState

        def lifecycle(action, state, *, outcome=None, reason=None):
            if lifecycle_request is None:
                return
            try:
                self.run_lifecycle.action(
                    lifecycle_request, action_id=action.action_id, kind=action.kind.value,
                    state=state, arguments=action.arguments if state is ActionState.PROPOSED else None,
                    outcome=outcome, reason=reason,
                )
            except Exception:
                # A telemetry receipt must never create authority or make a
                # deterministic tool outcome disappear. The action result is
                # still returned to the normal validator/transaction path.
                return

        action_started: Dict[str, float] = {}

        def tool_trace(action, state, *, outcome=None):
            if lifecycle_request is None:
                return
            try:
                elapsed = (time.perf_counter() - action_started[action.action_id]) * 1000 if state in {ActionState.COMPLETED, ActionState.FAILED} and action.action_id in action_started else None
                self.tool_traces.record_action(
                    run_id=lifecycle_request.run_id, request_id=lifecycle_request.request_id,
                    action=action, state=state.value, elapsed_ms=elapsed, outcome=outcome,
                )
            except Exception:
                return

        certificate_ids: Dict[str, str] = {}
        admissions: Dict[str, Any] = {}

        def certify(action):
            # This is the deterministic admission point before an executor is
            # started. It binds compiler output, policy, and the concrete state
            # the local adapter will consume. Point-of-use validation below
            # repeats the observation; this avoids treating issuance as use.
            from .action_admission import prepare_local_admission, validate_local_admission
            run_id = lifecycle_request.run_id if lifecycle_request is not None else f"local:{branch}"
            request_id = lifecycle_request.request_id if lifecycle_request is not None else "local"
            context_hash = certificate_context_hash or ("sha256:" + hashlib.sha256(branch.encode()).hexdigest())
            from .path_policy import PathPolicyResolver
            path_policy = PathPolicyResolver()
            direct_paths = sorted(
                resource for resource in (action.read_set | action.write_set)
                if not resource.startswith("<")
            )
            policy = {
                "allow_write": allow_write,
                "capability": self.config.to_capability_set().model_dump(mode="json"),
                # Bind fixed, deterministic path-risk/evidence requirements to
                # the admission decision. This is provenance against local
                # policy drift, not a grant beyond TaskContract/capabilities.
                "path_policy": [path_policy.resolve(path).as_dict() for path in direct_paths],
                "path_policy_version": path_policy.VERSION,
            }
            observed = self._action_precondition_observation(branch, action)
            admission = prepare_local_admission(
                self.action_certificates, action=action, run_id=run_id, request_id=request_id,
                policy=policy, context_hash=context_hash, observed=observed,
            )
            initial = validate_local_admission(self.action_certificates, admission, observed)
            if not initial.allowed:
                self.action_execution_receipts.record(
                    admission, phase="issuance", allowed=False, reason=initial.reason, stale=initial.stale,
                )
                raise RuntimeError("new action certificate failed local validation")
            self.action_execution_receipts.record(admission, phase="issuance", allowed=True, reason="issued")
            admissions[action.action_id] = admission
            certificate_ids[action.action_id] = admission.certificate.id

        def execute_admitted(action):
            # Keep the public _execute_model_tool signature stable for adapters
            # and tests. The dispatch envelope is thread-local so concurrent
            # read actions cannot borrow one another's certificate.
            previous = getattr(self._thread_local, "action_dispatch", None)
            self._thread_local.action_dispatch = admissions[action.action_id]
            try:
                return self._execute_model_tool(branch, action.as_call(), allow_write)
            finally:
                self._thread_local.action_dispatch = previous

        def record_outcome(action, outcome: Mapping[str, Any]) -> None:
            admission = admissions.get(action.action_id)
            if admission is not None:
                self.action_execution_receipts.record(
                    admission, phase="outcome", allowed=bool(outcome.get("ok")),
                    reason="completed" if outcome.get("ok") else "executor_failed",
                    outcome=outcome,
                )

        by_id = {action.action_id: action for action in plan.actions}
        order = {action.action_id: index for index, action in enumerate(plan.actions)}
        pending = set(by_id)
        complete: set[str] = set()
        results: Dict[str, Dict[str, Any]] = {}
        running: Dict[concurrent.futures.Future, Any] = {}
        dispatches = 0
        pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=min(4, max(1, len(plan.actions))),
            thread_name_prefix="chimera-tools",
        )
        try:
            while pending or running:
                ready = sorted(
                    (
                        by_id[action_id] for action_id in pending
                        if set(by_id[action_id].dependencies) <= complete
                    ),
                    key=lambda action: order[action.action_id],
                )
                read_ready = [
                    action for action in ready
                    if action.reversibility.value == "read_only"
                ]
                while read_ready and len(running) < 4:
                    action = read_ready.pop(0)
                    pending.remove(action.action_id)
                    certify(action)
                    lifecycle(action, ActionState.PROPOSED)
                    tool_trace(action, ActionState.PROPOSED)
                    lifecycle(action, ActionState.ACCEPTED)
                    tool_trace(action, ActionState.ACCEPTED)
                    action_started[action.action_id] = time.perf_counter()
                    lifecycle(action, ActionState.STARTED)
                    tool_trace(action, ActionState.STARTED)
                    running[pool.submit(execute_admitted, action)] = action
                    dispatches += 1
                if not running:
                    write_ready = [
                        action for action in ready
                        if action.reversibility.value != "read_only"
                    ]
                    if write_ready:
                        action = write_ready[0]
                        pending.remove(action.action_id)
                        certify(action)
                        lifecycle(action, ActionState.PROPOSED)
                        tool_trace(action, ActionState.PROPOSED)
                        lifecycle(action, ActionState.ACCEPTED)
                        tool_trace(action, ActionState.ACCEPTED)
                        action_started[action.action_id] = time.perf_counter()
                        lifecycle(action, ActionState.STARTED)
                        tool_trace(action, ActionState.STARTED)
                        results[action.action_id] = execute_admitted(action)
                        results[action.action_id]["action_certificate"] = certificate_ids.get(action.action_id)
                        record_outcome(action, results[action.action_id])
                        terminal_state = ActionState.COMPLETED if results[action.action_id].get("ok") else ActionState.FAILED
                        lifecycle(
                            action, terminal_state,
                            outcome=results[action.action_id],
                            reason=None if results[action.action_id].get("ok") else "tool_result_failed",
                        )
                        tool_trace(action, terminal_state, outcome=results[action.action_id])
                        complete.add(action.action_id)
                        dispatches += 1
                        continue
                    if pending:
                        raise RuntimeError("compiled action DAG became unschedulable")
                    break
                done, _ = concurrent.futures.wait(
                    running, return_when=concurrent.futures.FIRST_COMPLETED
                )
                for future in done:
                    action = running.pop(future)
                    try:
                        results[action.action_id] = future.result()
                    except Exception as exc:
                        results[action.action_id] = {
                            "ok": False, "tool": action.kind.value,
                            "error": f"{type(exc).__name__}: {exc}",
                        }
                    results[action.action_id]["action_certificate"] = certificate_ids.get(action.action_id)
                    record_outcome(action, results[action.action_id])
                    terminal_state = ActionState.COMPLETED if results[action.action_id].get("ok") else ActionState.FAILED
                    lifecycle(
                        action, terminal_state,
                        outcome=results[action.action_id],
                        reason=None if results[action.action_id].get("ok") else "tool_result_failed",
                    )
                    tool_trace(action, terminal_state, outcome=results[action.action_id])
                    complete.add(action.action_id)
        finally:
            pool.shutdown(wait=True, cancel_futures=True)
        return results, {
            "mode": "dependency-streaming", "dispatches": dispatches,
            "actions": len(plan.actions), "static_levels": len(plan.levels),
        }


