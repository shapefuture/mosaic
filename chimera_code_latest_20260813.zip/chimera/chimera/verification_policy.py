"""Risk-gated verification, judge calibration, semantic-loop detection, and self-error labels."""
from __future__ import annotations

import hashlib
import json
import math
import pathlib
from collections import Counter, deque
from enum import IntEnum
from statistics import pstdev
from typing import Any, Callable, Iterable, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from .action_ir import ActionIR, Reversibility
from .wal import WAL


class RiskBand(IntEnum):
    DETERMINISTIC = 0
    SINGLE_JUDGE = 1
    PANEL = 2
    HUMAN = 3


class VerificationStack(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    band: RiskBand
    deterministic_checks: bool = True
    judges: int
    human_required: bool
    reason: str


_HIGH_BLAST = {
    "net.write", "mcp.write", "credential.change", "financial.transfer",
    "fs.irreversible_delete", "external.bulk_communication",
}


def risk_band_for(action: ActionIR) -> RiskBand:
    effects = set(action.effect_row)
    external = any(effect.startswith(("net.", "mcp.", "env.")) for effect in effects)
    high_blast = bool(effects & _HIGH_BLAST)
    if action.reversibility is Reversibility.READ_ONLY and not action.write_set and not external:
        return RiskBand.DETERMINISTIC
    if action.reversibility is Reversibility.IRREVERSIBLE and (high_blast or external):
        return RiskBand.HUMAN
    if external or action.reversibility is Reversibility.IRREVERSIBLE:
        return RiskBand.PANEL
    return RiskBand.SINGLE_JUDGE


def verification_stack(action: ActionIR) -> VerificationStack:
    band = risk_band_for(action)
    return {
        RiskBand.DETERMINISTIC: VerificationStack(
            band=band, judges=0, human_required=False, reason="read-only action with no external effect"
        ),
        RiskBand.SINGLE_JUDGE: VerificationStack(
            band=band, judges=1, human_required=False, reason="reversible local mutation"
        ),
        RiskBand.PANEL: VerificationStack(
            band=band, judges=3, human_required=False, reason="external or irreversible effect"
        ),
        RiskBand.HUMAN: VerificationStack(
            band=band, judges=3, human_required=True, reason="high-blast irreversible external effect"
        ),
    }[band]


class JudgeVerdict(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    judge_id: str
    passed: bool
    confidence: float = Field(ge=0.0, le=1.0)
    evidence_refs: tuple[str, ...]


class PanelDecision(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    accepted: bool
    band: RiskBand
    escalated_to: RiskBand
    disagreement: float
    aggregate_confidence: Optional[float]
    reason: str


def evaluate_panel(
    band: RiskBand,
    verdicts: Iterable[JudgeVerdict],
    *,
    evidence_resolver: Callable[[str], bool],
    human_approved: bool = False,
    disagreement_threshold: float = 0.25,
) -> PanelDecision:
    rows = list(verdicts)
    required = {RiskBand.DETERMINISTIC: 0, RiskBand.SINGLE_JUDGE: 1, RiskBand.PANEL: 3, RiskBand.HUMAN: 3}[band]
    if len(rows) < required:
        return PanelDecision(
            accepted=False, band=band, escalated_to=band, disagreement=0.0,
            aggregate_confidence=None, reason=f"requires {required} judge verdicts",
        )
    if any(not row.evidence_refs or not all(evidence_resolver(ref) for ref in row.evidence_refs) for row in rows):
        return PanelDecision(
            accepted=False, band=band, escalated_to=band, disagreement=0.0,
            aggregate_confidence=None, reason="judge evidence is missing or unresolvable",
        )
    disagreement = pstdev([row.confidence for row in rows]) if len(rows) > 1 else 0.0
    if disagreement > disagreement_threshold:
        escalated = RiskBand(min(int(RiskBand.HUMAN), int(band) + 1))
        return PanelDecision(
            accepted=False, band=band, escalated_to=escalated, disagreement=disagreement,
            aggregate_confidence=None, reason="judge disagreement requires escalation; dissent was not averaged away",
        )
    if band is RiskBand.HUMAN and not human_approved:
        return PanelDecision(
            accepted=False, band=band, escalated_to=band, disagreement=disagreement,
            aggregate_confidence=None, reason="human approval required",
        )
    accepted = all(row.passed for row in rows) if rows else True
    return PanelDecision(
        accepted=accepted, band=band, escalated_to=band, disagreement=disagreement,
        aggregate_confidence=(sum(row.confidence for row in rows) / len(rows)) if rows else 1.0,
        reason="all required evidence-backed verdicts pass" if accepted else "at least one judge found a failure",
    )


class SharedTaskOutcome(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    task_id: str
    verifier_a_correct: bool
    verifier_b_correct: bool
    evidence_refs: tuple[str, ...]


class CorrelationResult(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    status: Literal["measured", "insufficient-data"]
    samples: int
    correlation: Optional[float]
    independent: Optional[bool]
    reason: str


def verifier_error_correlation(
    outcomes: Iterable[SharedTaskOutcome],
    *,
    evidence_resolver: Callable[[str], bool],
    minimum_samples: int = 20,
    maximum_correlation: float = 0.8,
) -> CorrelationResult:
    rows = [row for row in outcomes if row.evidence_refs and all(evidence_resolver(ref) for ref in row.evidence_refs)]
    if len(rows) < minimum_samples:
        return CorrelationResult(
            status="insufficient-data", samples=len(rows), correlation=None, independent=None,
            reason=f"need at least {minimum_samples} labeled shared tasks",
        )
    xs = [0.0 if row.verifier_a_correct else 1.0 for row in rows]
    ys = [0.0 if row.verifier_b_correct else 1.0 for row in rows]
    mean_x, mean_y = sum(xs) / len(xs), sum(ys) / len(ys)
    var_x = sum((x - mean_x) ** 2 for x in xs)
    var_y = sum((y - mean_y) ** 2 for y in ys)
    if var_x == 0 or var_y == 0:
        correlation = 1.0
    else:
        correlation = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys)) / math.sqrt(var_x * var_y)
    return CorrelationResult(
        status="measured", samples=len(rows), correlation=correlation,
        independent=correlation <= maximum_correlation,
        reason="empirical shared-task error correlation",
    )


class LoopObservation(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    fingerprint: str
    occurrences: int
    total_attempts: int
    rotation_required: bool
    halt: bool
    reason: str


class SemanticLoopDetector:
    def __init__(self, repeat_limit: int = 3, max_attempts: int = 8, window: int = 12) -> None:
        self.repeat_limit = max(2, repeat_limit)
        self.max_attempts = max(self.repeat_limit, max_attempts)
        self._recent: deque[tuple[str, str]] = deque(maxlen=max(window, self.repeat_limit))
        self._attempts = 0

    @staticmethod
    def fingerprint(actions: Iterable[ActionIR], state_root: str) -> str:
        payload = {
            "state_root": state_root,
            "actions": [
                {"kind": action.kind.value, "arguments": action.argument_digest,
                 "reads": sorted(action.read_set), "writes": sorted(action.write_set)}
                for action in actions
            ],
        }
        return "sha256:" + hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

    def observe(self, actions: Iterable[ActionIR], *, state_root: str, method: str) -> LoopObservation:
        self._attempts += 1
        fp = self.fingerprint(actions, state_root)
        self._recent.append((fp, method))
        occurrences = sum(1 for prior, _ in self._recent if prior == fp)
        methods = {candidate for prior, candidate in self._recent if prior == fp}
        rotation = occurrences >= self.repeat_limit and len(methods) <= 1
        halt = self._attempts >= self.max_attempts
        reason = (
            "attempt budget exhausted" if halt else
            "same semantic action repeated against unchanged state; method rotation required" if rotation else
            "progress fingerprint accepted"
        )
        return LoopObservation(
            fingerprint=fp, occurrences=occurrences, total_attempts=self._attempts,
            rotation_required=rotation, halt=halt, reason=reason,
        )


class SelfErrorLedger:
    """Ground-truth labels only; absence of labels is unavailable, never zero error."""

    def __init__(self, root: pathlib.Path) -> None:
        self.wal = WAL(pathlib.Path(root))

    def label(
        self,
        *,
        decision_id: str,
        harness_blocked: bool,
        should_block: bool,
        source: Literal["human", "delayed-outcome"],
        evidence_refs: tuple[str, ...],
    ) -> None:
        if not evidence_refs:
            raise ValueError("self-error labels require evidence refs")
        self.wal.append("harness_decision_label", {
            "decision_id": decision_id, "harness_blocked": harness_blocked,
            "should_block": should_block, "source": source,
            "evidence_refs": list(evidence_refs),
        })

    def metrics(self) -> dict[str, Any]:
        rows = [entry["data"] for entry in self.wal.replay(kind="harness_decision_label")]
        if not rows:
            return {
                "status": "unavailable", "samples": 0,
                "false_positive_block_rate": None, "false_negative_pass_rate": None,
            }
        fp = sum(1 for row in rows if row["harness_blocked"] and not row["should_block"])
        tp = sum(1 for row in rows if row["harness_blocked"] and row["should_block"])
        fn = sum(1 for row in rows if not row["harness_blocked"] and row["should_block"])
        tn = sum(1 for row in rows if not row["harness_blocked"] and not row["should_block"])
        return {
            "status": "measured", "samples": len(rows),
            "false_positive_blocks": fp, "true_positive_blocks": tp,
            "false_negative_passes": fn, "true_negative_passes": tn,
            "false_positive_block_rate": fp / (fp + tn) if fp + tn else None,
            "false_negative_pass_rate": fn / (fn + tp) if fn + tp else None,
        }
