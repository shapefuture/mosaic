
"""
Processor delegation — AEGIS typed substitution algebra patch
Generated from adaptation plan: general -> general tune (better-harness)
Surface: module_attr | Variant: variant-654378 | Parent: default
CPE-protected: False
"""
EFFECT_ROW = {"fs": ["./src/**", "./tests/**"], "net": []}
VERIFICATION = "general tune (better-harness)"

def handle(trace):
    return {"processor": "delegation", "variant": "variant-654378"}
