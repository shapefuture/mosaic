"""Structural context pages and a bounded citation-based working set."""
from __future__ import annotations
import ast,hashlib,pathlib,re
from collections import OrderedDict
from dataclasses import dataclass
from typing import Callable

@dataclass(frozen=True)
class StructuralPage:
    path:str; text:str; line_count:int; symbols:tuple[str,...]; content_hash:str

def structural_page(path:str,content:str,max_symbols:int=240,max_chars:int=12000)->StructuralPage:
    lines=content.splitlines();symbols=[];out=[f"# structure {path} lines={len(lines)}"]
    if path.endswith(".py"):
        try:
            tree=ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and len(symbols)<max_symbols:
                    kind="class" if isinstance(node,ast.ClassDef) else "async def" if isinstance(node,ast.AsyncFunctionDef) else "def"
                    end=getattr(node,"end_lineno",node.lineno);sig=f"{kind} {node.name} L{node.lineno}-L{end}";symbols.append(sig);out.append(sig)
                elif isinstance(node,(ast.Import,ast.ImportFrom)) and len(out)<120:
                    out.append(f"import L{node.lineno}: {ast.unparse(node)}")
        except SyntaxError as exc:out.append(f"syntax-error L{exc.lineno}: {exc.msg}")
    elif path.endswith((".md",".rst")):
        for i,line in enumerate(lines,1):
            if re.match(r"^#{1,6}\s",line):symbols.append(f"heading L{i}: {line.strip()}");out.append(symbols[-1])
    else:
        for i,line in enumerate(lines,1):
            if re.match(r"^\s*(?:export\s+)?(?:class|function|interface|type|const)\s+",line):symbols.append(f"symbol L{i}: {line.strip()[:160]}");out.append(symbols[-1])
    if not symbols:out.append("(no structural symbols; use artifact page for source)")
    elif len(symbols)>=max_symbols:out.append(f"... symbol outline capped at {max_symbols}; use graph search or artifact pages ...")
    digest="sha256:"+hashlib.sha256(content.encode()).hexdigest()
    text="\n".join(out)
    if len(text)>max_chars:text=text[:max_chars]+"\n... structural page character cap reached ..."
    return StructuralPage(path,text,len(lines),tuple(symbols),digest)

class ContextAddressSpace:
    """Demand-pages cited artifacts with an explicit LRU working-set ceiling."""
    def __init__(self,loader:Callable[[str],bytes],max_bytes:int=100000):self.loader=loader;self.max=max(1024,max_bytes);self.pages=OrderedDict();self.used=0
    def dereference(self,digest:str,start:int=0,end:int|None=None)->str:
        data=self.loader(digest);end=min(len(data),end if end is not None else start+20000);chunk=data[max(0,start):max(start,end)].decode("utf-8",errors="replace")
        key=f"{digest}:{start}:{end}";size=len(chunk.encode())
        if key in self.pages:self.used-=len(self.pages.pop(key).encode())
        while self.pages and self.used+size>self.max:
            _,old=self.pages.popitem(last=False);self.used-=len(old.encode())
        if size<=self.max:self.pages[key]=chunk;self.used+=size
        return f"[citation {key}]\n{chunk}"
    def status(self):return {"pages":len(self.pages),"used_bytes":self.used,"max_bytes":self.max,"citations":list(self.pages)}
