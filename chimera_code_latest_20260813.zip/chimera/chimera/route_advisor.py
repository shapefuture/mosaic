"""Transparent model-route advice that never overrides user selection."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Iterable

from .routing import ModelRoute


@dataclass(frozen=True)
class RouteAdvice:
    requested_model: str | None
    recommendation: str | None
    candidates: tuple[dict[str, Any], ...]
    reason: str
    automatic_selection_permitted: bool

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class RouteAdvisor:
    def __init__(self, routes: Iterable[ModelRoute]) -> None:
        self.routes = tuple(routes)

    def advise(
        self,
        *,
        requested_model: str | None,
        required_capabilities: frozenset[str],
        input_tokens: int,
        output_tokens: int,
        latency_sensitive: bool = False,
    ) -> RouteAdvice:
        candidates = [route for route in self.routes if required_capabilities <= route.capabilities]
        candidates.sort(key=lambda route: (route.estimated_cost(input_tokens, output_tokens), route.latency_class, route.model))
        rows = tuple({
            "model": route.model,
            "estimated_cost": round(route.estimated_cost(input_tokens, output_tokens), 8),
            "latency_class": route.latency_class,
            "capabilities": sorted(route.capabilities),
        } for route in candidates)
        recommended = candidates[0].model if candidates else None
        if requested_model and requested_model != "auto":
            return RouteAdvice(
                requested_model=requested_model, recommendation=recommended, candidates=rows,
                reason="explicit user model preserved; recommendation is advisory only",
                automatic_selection_permitted=False,
            )
        if not candidates:
            return RouteAdvice(requested_model, None, rows, "no configured route satisfies required capabilities", requested_model == "auto")
        if latency_sensitive:
            recommended = min(candidates, key=lambda route: (route.latency_class, route.estimated_cost(input_tokens, output_tokens), route.model)).model
        return RouteAdvice(
            requested_model=requested_model, recommendation=recommended, candidates=rows,
            reason="automatic selection is permitted only because requested_model is auto" if requested_model == "auto" else "no explicit model supplied; recommendation remains advisory",
            automatic_selection_permitted=requested_model == "auto",
        )
