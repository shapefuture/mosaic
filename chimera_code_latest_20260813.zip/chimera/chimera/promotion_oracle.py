"""Layered anti-reward-hack oracle for self-evolving code candidates.

Transferred narrowly from Tripwire's target/oracle design: visible canonical
checks, metamorphic properties, fresh withheld checks, then measurement. The
oracle does not execute model code itself; callers provide already-sandboxed
checks and only receive a promotion-shaped receipt.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import random
from typing import Callable, Iterable


@dataclass(frozen=True)
class OracleLayer:
    name: str
    passed: bool
    reason: str


@dataclass(frozen=True)
class PromotionOracleResult:
    candidate_id: str
    accepted: bool
    layers: tuple[OracleLayer, ...]
    measurement: float | None
    seed_commitment: str

    def as_dict(self) -> dict:
        return {
            **asdict(self),
            "layers": [asdict(layer) for layer in self.layers],
        }


class PromotionOracle:
    """Require correctness before timing/utility is even inspected."""

    def __init__(self, *, fresh_draws: int = 3, seed: int | None = None) -> None:
        if fresh_draws < 1:
            raise ValueError("fresh_draws must be positive")
        self.fresh_draws = fresh_draws
        self.seed = seed if seed is not None else random.SystemRandom().randrange(2**63)

    def evaluate(
        self,
        *,
        candidate_id: str,
        canonical: Callable[[], bool],
        properties: Iterable[tuple[str, Callable[[], bool]]] = (),
        withheld: Callable[[random.Random], Iterable[tuple[str, bool]]],
        measure: Callable[[], float] | None = None,
    ) -> PromotionOracleResult:
        if not candidate_id:
            raise ValueError("candidate_id is required")
        seed_material = f"{candidate_id}:{self.seed}:{self.fresh_draws}".encode()
        commitment = "sha256:" + hashlib.sha256(seed_material).hexdigest()
        layers: list[OracleLayer] = []
        try:
            canonical_ok = bool(canonical())
        except Exception as exc:
            canonical_ok = False
            layers.append(OracleLayer("canonical", False, f"{type(exc).__name__}"))
        else:
            layers.append(OracleLayer("canonical", canonical_ok, "passed" if canonical_ok else "failed"))
        if not canonical_ok:
            return PromotionOracleResult(candidate_id, False, tuple(layers), None, commitment)

        for name, check in properties:
            try:
                passed = bool(check())
                reason = "passed" if passed else "failed"
            except Exception as exc:
                passed = False
                reason = type(exc).__name__
            layers.append(OracleLayer(f"property:{name}", passed, reason))
            if not passed:
                return PromotionOracleResult(candidate_id, False, tuple(layers), None, commitment)

        for draw in range(self.fresh_draws):
            rng = random.Random(f"{self.seed}:{candidate_id}:{draw}")
            try:
                checks = list(withheld(rng))
            except Exception as exc:
                layers.append(OracleLayer(f"withheld:{draw}", False, type(exc).__name__))
                return PromotionOracleResult(candidate_id, False, tuple(layers), None, commitment)
            if not checks:
                layers.append(OracleLayer(f"withheld:{draw}", False, "empty withheld check set"))
                return PromotionOracleResult(candidate_id, False, tuple(layers), None, commitment)
            for name, passed in checks:
                ok = bool(passed)
                layers.append(OracleLayer(f"withheld:{draw}:{name}", ok, "passed" if ok else "failed"))
                if not ok:
                    return PromotionOracleResult(candidate_id, False, tuple(layers), None, commitment)

        measurement = None
        if measure is not None:
            try:
                measurement = float(measure())
                layers.append(OracleLayer("measurement", True, "measured"))
            except Exception as exc:
                layers.append(OracleLayer("measurement", False, type(exc).__name__))
                return PromotionOracleResult(candidate_id, False, tuple(layers), None, commitment)
        return PromotionOracleResult(candidate_id, True, tuple(layers), measurement, commitment)
