
"""
Chimera CLI — 5 commands <1min like InfiGraph

chimera graph build .
chimera branch exp-001
chimera rlm "task" --branch exp-001 --model kimi-k2.5
chimera diff exp-001
chimera commit exp-001 -m "fix(auth): ..."
chimera abort exp-001
chimera verify --plan plan.json
chimera check --trace trace.json
chimera evolve --iterations 3
chimera mcp serve
chimera run "echo hi" --branch exp-001
chimera health
"""
from __future__ import annotations
import json, pathlib, time, sys
import click
from rich.console import Console
from rich.table import Table
from rich.json import JSON

console = Console()

@click.group(invoke_without_command=True)
@click.option("--workspace", type=click.Path(path_type=pathlib.Path), default=pathlib.Path("."), show_default=True)
@click.option("--profile", type=click.Choice([
    "LOCAL_OFFLINE", "LOCAL_DETERMINISTIC", "DEV_EXTERNAL", "SHADOW_PRODUCTION",
    "SINGLE_TENANT_PRODUCTION", "MULTI_TENANT_PRODUCTION", "HIGH_AUTONOMY", "REGULATED",
]), default=None)
@click.option("--output", "output_mode", type=click.Choice(["human", "json"]), default="human")
@click.option("--deadline", "deadline_seconds", type=click.FloatRange(min=0.1, max=86_400), default=1_800.0)
@click.option("--trace-id", default=None)
@click.pass_context
def main(ctx, workspace, profile, output_mode, deadline_seconds, trace_id):
    """Evidence-gated coding-agent harness; every command uses one explicit workspace/profile."""
    ctx.ensure_object(dict)
    ctx.obj.update({
        "workspace": pathlib.Path(workspace).resolve(),
        "profile": profile,
        "output": output_mode,
        "deadline_seconds": float(deadline_seconds),
        "trace_id": trace_id,
    })
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _cli_state() -> dict:
    context = click.get_current_context(silent=True)
    return dict(context.obj or {}) if context is not None else {}


def _cli_root() -> pathlib.Path:
    return pathlib.Path(_cli_state().get("workspace", pathlib.Path("."))).resolve()


def _cli_config():
    from .config import ChimeraConfig, DeploymentProfile
    root = _cli_root()
    config = ChimeraConfig.load(root / "chimera.toml")
    selected = _cli_state().get("profile")
    if selected:
        config = config.model_copy(update={"deployment_profile": DeploymentProfile(selected)})
    return config


def _cli_context(*, tenant_context=None):
    from .bootstrap import new_run_context
    config = _cli_config()
    values = tenant_context.model_dump(mode="json") if tenant_context is not None else {}
    return new_run_context(
        profile=config.deployment_profile,
        deadline_seconds=_cli_state().get("deadline_seconds", 1_800.0),
        trace_id=_cli_state().get("trace_id"),
        tenant_key=values.get("tenant_key"),
        principal_hash=values.get("principal_hash"),
        grant_digest=values.get("grant_digest"),
        max_input_tokens=config.planner.context_max_tokens,
    )


def _emit(value, *, failure: bool = False) -> None:
    data = value.model_dump(mode="json") if hasattr(value, "model_dump") else value
    if _cli_state().get("output") == "json":
        click.echo(json.dumps(data, separators=(",", ":"), default=str))
    else:
        console.print(JSON(json.dumps(data, indent=2, default=str)))
    if failure:
        raise click.exceptions.Exit(1)


def _application():
    context = click.get_current_context()
    root_context = context.find_root()
    root_context.ensure_object(dict)
    if "application" not in root_context.obj:
        from .bootstrap import build_local_application
        application, composition = build_local_application(_cli_root(), config=_cli_config())
        root_context.obj["application"] = application
        root_context.obj["composition"] = composition
    return root_context.obj["application"]


from .cli_doctor import register as _register_doctor_command
from .cli_graph import register as _register_graph_commands

_register_doctor_command(main, console=console, cli_root=_cli_root, cli_state=_cli_state)
_register_graph_commands(main, console=console, cli_root=_cli_root)

from .cli_run import register as _register_run_commands

_register_run_commands(
    main,
    console=console,
    application=_application,
    cli_context=_cli_context,
    cli_root=_cli_root,
    emit=_emit,
)

@main.group(hidden=True)
def nixo():
    """Quarantined historical local emulation; not a Nix/rootfs capability."""
    import os
    if os.environ.get("CHIMERA_ENABLE_LOCAL_EMULATION") != "1":
        raise click.UsageError(
            "nixo was a local emulation, not a certified Nix rootfs; "
            "set CHIMERA_ENABLE_LOCAL_EMULATION=1 only for legacy tests"
        )

@nixo.command("catalog")
@click.option("--filter", "flt", default=None)
@click.option("--grouped", is_flag=True)
@click.option("--json", "as_json", is_flag=True)
def nixo_catalog(flt, grouped, as_json):
    from .nixo import NixoManager
    m=NixoManager(_cli_root())
    cat=m.catalog(filter=flt, grouped=grouped)
    if as_json:
        console.print(JSON(json.dumps(cat, indent=2)))
    else:
        table=Table(title="Nixo Catalog (88 agents + 24 tools)")
        table.add_column("name"); table.add_column("desc"); table.add_column("category")
        for k,v in cat.get("agents", {}).items():
            table.add_row(k, v["desc"][:60], v["category"])
        for k,v in cat.get("tools", {}).items():
            table.add_row(k, v["nix"], v["category"])
        console.print(table)
        console.print(f"[dim]Profiles: {', '.join(cat.get('profiles', []))} — try: nixo create --with chimera,infigraph --profile chimera[/dim]")

@nixo.command("create")
@click.option("--with", "with_str", default="chimera,infigraph")
@click.option("--network", default="off")
@click.option("--workspace", default=None)
@click.option("--profile", default=None)
@click.option("--name", default=None)
@click.option("--json", "as_json", is_flag=True)
def nixo_create(with_str, network, workspace, profile, name, as_json):
    from .nixo import NixoManager
    m=NixoManager(_cli_root())
    sess=m.create(with_str, network, workspace, profile, name)
    if as_json:
        console.print(JSON(json.dumps(sess, indent=2)))
    else:
        console.print(f"[green]Nixo session {sess['session_id']} created[/green] with [{sess['with']}] network={sess['network']} rootfs={sess['rootfs']}")
        console.print(f"[dim]Bubblewrap mount/pid/net isolated, flake.lock pinned[/dim]")

@nixo.command("exec")
@click.argument("session_id")
@click.argument("cmd")
def nixo_exec(session_id, cmd):
    from .nixo import NixoManager
    m=NixoManager(_cli_root())
    res=m.exec(session_id, cmd)
    console.print(JSON(json.dumps(res, indent=2)))

@main.command("bench")
@click.argument("benchmark", required=False, default="terminal-bench2")
@click.option("--model", default="mock-echo")
def bench_cmd(benchmark, model):
    from .bench import BenchHarness
    import pathlib
    b=BenchHarness(_cli_root())
    if benchmark=="leaderboard":
        res=b.leaderboard()
        console.print(JSON(json.dumps(res, indent=2)))
    else:
        res=b.run(benchmark, model=model)
        console.print(JSON(json.dumps(res, indent=2)))
        if res.get("status")=="pass":
            console.print(f"[green]11/10 BENCH PASS {benchmark}: {res['score']}% >= {res['target']}%[/green] {res['evidence']}")
        else:
            console.print(f"[yellow]BENCH {benchmark}: {res['score']}% vs target {res['target']}%[/yellow]")

@main.command("cost")
@click.option("--budget", default=10.0, type=float)
def cost_cmd(budget):
    from .cost_governor import CostGovernor
    g=CostGovernor(budget_usd=budget)
    console.print(JSON(json.dumps(g.report(), indent=2)))
    console.print(JSON(json.dumps(g.evolve_cost_split(), indent=2)))

@main.command("heal")
@click.argument("branch")
@click.option("--violation", default="LTL violation")
def heal_cmd(branch, violation):
    from .self_heal import SelfHealer
    h=SelfHealer(_cli_root())
    res=h.heal_branch(branch, violation, [])
    console.print(JSON(json.dumps(res, indent=2)))
    hb=h.heartbeat(branch)
    console.print(JSON(json.dumps(hb, indent=2)))
    st=h.adversarial_self_test()
    console.print(JSON(json.dumps(st, indent=2)))

from .cli_harness import register as _register_harness_commands

_register_harness_commands(main, console=console, cli_root=_cli_root)

from .cli_goal import register as _register_goal_commands

_register_goal_commands(main, console=console, cli_root=_cli_root)

from .cli_agent import register as _register_agent_commands

_register_agent_commands(main, console=console, cli_root=_cli_root)

@main.command("tui")
@click.option("--workspace", default=".")
def tui_cmd(workspace):
    """Interactive goals/workers/DAG/refinement dashboard."""
    from .tui import run_tui
    run_tui(pathlib.Path(workspace))

from .cli_extension import register as _register_extension_commands

_register_extension_commands(main, console=console, cli_root=_cli_root)

from .cli_observability import register as _register_observability_commands
from .cli_wire import register as _register_wire_commands

_register_observability_commands(main, console=console, cli_root=_cli_root)
from .cli_wire import register as _register_wire_commands
from .cli_platform import register as _register_platform_commands

_register_wire_commands(main, console=console)
_register_platform_commands(main, console=console, cli_root=_cli_root, emit=_emit)

from .cli_impact import register as _register_impact_commands
from .cli_mapping import register as _register_mapping_commands

_register_impact_commands(main, console=console)
from .cli_mapping import register as _register_mapping_commands

_register_mapping_commands(main, console=console)

from .cli_release import register as _register_release_commands

_register_release_commands(main, console=console)

from .cli_tenant import register as _register_tenant_commands
from .cli_mcp import register as _register_mcp_commands

_tenant_transport_root = _register_tenant_commands(main, console=console, cli_root=_cli_root)

from .cli_mcp import register as _register_mcp_commands

_register_mcp_commands(
    main,
    console=console,
    cli_context=_cli_context,
    cli_state=_cli_state,
    cli_config=_cli_config,
    tenant_transport_root=_tenant_transport_root,
)

from .cli_rpc import register as _register_rpc_commands

_register_rpc_commands(main, console=console, cli_state=_cli_state, tenant_transport_root=_tenant_transport_root)

@main.command("audit")
@click.option("--branch", "branch_filter", default=None, help="audit single branch")
def audit_cmd(branch_filter):
    """chimera audit — LTL + Etas + graph audit trail + WAL hash chain"""
    from .audit import audit_all_branches
    import pathlib
    try:
        report = audit_all_branches(_cli_root(), branch_filter=branch_filter)
        console.print(JSON(json.dumps(report, indent=2)))
        if report.get("ltl", {}).get("holds") and report.get("wal", {}).get("chain_ok"):
            console.print("[green]AUDIT PASS — LTL holds, WAL chain OK, capability clean[/green]")
        else:
            console.print(f"[red]AUDIT FAIL[/red] LTL:{report.get('ltl')} WAL:{report.get('wal')}")
    except Exception as e:
        # fallback to generated audit if module missing — use orchestrator audit via evolution
        console.print(f"[yellow]audit module not yet committed, generating via harness... {e}[/yellow]")
        from .branch import TransactionalWorkspace
        from .wal import WAL
        from .graph import CodeGraph
        from .verifier import LTLMonitor
        from .effects import CapabilitySet, EffectRequest, check_effect
        ws = TransactionalWorkspace(_cli_root())
        wal = WAL(_cli_root())
        g = CodeGraph(_cli_root())
        try: g.load()
        except: g.build()
        cap = CapabilitySet(fs_allow=["./src/**", "./tests/**", ".chimera/**"], fs_deny=["/etc/**"])
        report = {"branches": [], "ltl": {}, "wal": {}}
        for br in ws.list_branches():
            d = ws.diff(br)
            report["branches"].append({"branch": br, "ops": len(d.get("ops",[]))})
        mon = LTLMonitor("G(!writeOutsideAllow)")
        ok, msg = mon.check([{"kind": e["kind"]} for e in wal.replay()])
        report["ltl"] = {"holds": ok, "msg": msg}
        ok2,_ = wal.verify_chain()
        report["wal"] = {"chain_ok": ok2, "entries": len(wal.replay())}
        report["graph_hits"] = [h["id"] for h in g.search("audit", limit=3)]
        console.print(JSON(json.dumps(report, indent=2)))

@main.command("exec")
@click.argument("branch_name")
@click.argument("cmd")
@click.option("--workspace", default=".")
@click.option("--tenant-id", default=None)
@click.option("--principal", default=None)
@click.option("--authorization-file", type=click.Path(path_type=pathlib.Path), default=None)
@click.option("--trusted-key-id", "trusted_key_ids", multiple=True)
def exec_cmd(branch_name, cmd, workspace, tenant_id, principal, authorization_file, trusted_key_ids):
    from .branch import TransactionalWorkspace
    from .sandbox import Sandbox
    from .config import ChimeraConfig
    root, _tenant_context = _tenant_transport_root(
        workspace, tenant_id, principal, authorization_file, trusted_key_ids, "sandbox",
    )
    cfg=ChimeraConfig.load(root / "chimera.toml")
    ws=TransactionalWorkspace(root)
    sb=Sandbox(workDir=root, capability=cfg.to_capability_set(), branch=branch_name, workspace=ws)
    res=sb.exec(cmd)
    console.print(f"status={res.status} stdout={res.stdout[:2000]} stderr={res.stderr[:2000]}")

if __name__ == "__main__":
    main()
