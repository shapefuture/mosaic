"""Priority/token-budget context pack selection with explicit budget satisfaction."""
from __future__ import annotations

import hashlib
import threading
from collections import OrderedDict
from dataclasses import dataclass
from typing import Optional

from .tokenizer import TokenizerMeasurer


PRIORITY = {"required": 0, "high": 1, "medium": 2, "low": 3}


@dataclass(frozen=True)
class ContextPack:
    id: str
    full: str
    compact: str = ""
    priority: str = "medium"
    required: bool = False
    preserve: bool = False
    order: int = 0


@dataclass(frozen=True)
class PackDecision:
    id: str
    status: str
    variant: str | None
    tokens: int
    chars: int
    reason: str | None


@dataclass(frozen=True)
class ContextSelection:
    text: str
    decisions: tuple[PackDecision, ...]
    tokens: int
    chars: int
    token_kind: str
    budget_satisfied: bool = True
    max_tokens: int = 0
    max_chars: int = 0
    overrun_tokens: int = 0
    overrun_chars: int = 0


class ContextPackBuilder:
    def __init__(
        self,
        model: str,
        measurer: Optional[TokenizerMeasurer] = None,
        cache_size: int = 2_048,
    ) -> None:
        self.model = model
        self.measurer = measurer or TokenizerMeasurer()
        self.cache: OrderedDict[tuple[int, bytes], tuple[int, str]] = OrderedDict()
        self.cache_size = max(16, int(cache_size))
        self.lock = threading.RLock()

    def _tokens(self, text: str) -> tuple[int, str]:
        raw = text.encode()
        key = (len(raw), hashlib.sha256(raw).digest())
        with self.lock:
            if key in self.cache:
                value = self.cache.pop(key)
                self.cache[key] = value
                return value
        measured = self.measurer.measure(self.model, text)
        value = (
            (measured.tokens, "measured")
            if measured.status == "measured" and measured.tokens is not None
            else ((len(raw) + 3) // 4, "estimate")
        )
        with self.lock:
            self.cache[key] = value
            while len(self.cache) > self.cache_size:
                self.cache.popitem(last=False)
        return value

    def _fit_tokens(self, text: str, limit: int) -> tuple[str, int, str]:
        if limit <= 0:
            return "", 0, "measured"
        tokens, kind = self._tokens(text)
        if tokens <= limit:
            return text, tokens, kind
        low, high = 0, len(text)
        while low < high:
            middle = (low + high + 1) // 2
            candidate_tokens, _ = self._tokens(text[:middle])
            if candidate_tokens <= limit:
                low = middle
            else:
                high = middle - 1
        fitted = text[:low]
        fitted_tokens, fitted_kind = self._tokens(fitted)
        return fitted, fitted_tokens, fitted_kind

    def build(self, packs, max_tokens: int, max_chars: int) -> ContextSelection:
        token_limit = max(0, int(max_tokens))
        char_limit = max(0, int(max_chars))
        rows = []
        for index, pack in enumerate(packs):
            rows.append(ContextPack(**{
                **pack.__dict__,
                "required": pack.required or pack.priority == "required",
                "order": pack.order if pack.order else index,
            }))
        selected: dict[str, tuple[str, ContextPack]] = {}
        decisions: dict[str, PackDecision] = {}
        remaining = token_limit
        token_kind = "measured"

        for pack in sorted(rows, key=lambda item: (PRIORITY.get(item.priority, 2), item.order)):
            full_tokens, full_kind = self._tokens(pack.full)
            compact_tokens, compact_kind = (
                self._tokens(pack.compact) if pack.compact else (0, full_kind)
            )
            if "estimate" in {token_kind, full_kind, compact_kind}:
                token_kind = "estimate"
            if pack.required:
                text = pack.full
                variant = "full"
                tokens = full_tokens
                reason = None
                if pack.compact and full_tokens > remaining and compact_tokens < full_tokens:
                    text = pack.compact
                    variant = "compact"
                    tokens = compact_tokens
                    reason = "budget"
                if tokens > remaining and not pack.preserve:
                    text, tokens, fitted_kind = self._fit_tokens(text, remaining)
                    if fitted_kind == "estimate":
                        token_kind = "estimate"
                    variant = "truncated"
                    reason = "token_budget"
                selected[pack.id] = (text, pack)
                remaining = max(0, remaining - tokens)
                decisions[pack.id] = PackDecision(
                    pack.id, "included", variant, tokens, len(text), reason
                )
            elif full_tokens <= remaining:
                selected[pack.id] = (pack.full, pack)
                remaining -= full_tokens
                decisions[pack.id] = PackDecision(
                    pack.id, "included", "full", full_tokens, len(pack.full), None
                )
            elif pack.compact and compact_tokens <= remaining:
                selected[pack.id] = (pack.compact, pack)
                remaining -= compact_tokens
                decisions[pack.id] = PackDecision(
                    pack.id, "included", "compact", compact_tokens,
                    len(pack.compact), "budget",
                )
            else:
                decisions[pack.id] = PackDecision(
                    pack.id, "skipped", None, 0, 0, "budget"
                )

        def render() -> str:
            return "".join(
                selected[pack.id][0]
                for pack in sorted(rows, key=lambda item: item.order)
                if pack.id in selected
            )

        text = render()
        if len(text) > char_limit:
            removable = sorted(
                (
                    item for item in rows
                    if item.id in selected and not item.required
                ),
                key=lambda item: (-PRIORITY.get(item.priority, 2), -item.order),
            )
            for pack in removable:
                if len(text) <= char_limit:
                    break
                current, _ = selected[pack.id]
                if pack.compact and len(pack.compact) < len(current):
                    selected[pack.id] = (pack.compact, pack)
                    tokens, _ = self._tokens(pack.compact)
                    decisions[pack.id] = PackDecision(
                        pack.id, "included", "compact", tokens,
                        len(pack.compact), "max_chars",
                    )
                else:
                    selected.pop(pack.id)
                    decisions[pack.id] = PackDecision(
                        pack.id, "skipped", None, 0, 0, "max_chars"
                    )
                text = render()
            if len(text) > char_limit:
                overflow = len(text) - char_limit
                truncatable = reversed(sorted(
                    (
                        item for item in rows
                        if item.id in selected and item.required and not item.preserve
                    ),
                    key=lambda item: item.order,
                ))
                for pack in truncatable:
                    if overflow <= 0:
                        break
                    current, _ = selected[pack.id]
                    cut = min(len(current), overflow)
                    current = current[:-cut] if cut < len(current) else ""
                    selected[pack.id] = (current, pack)
                    overflow -= cut
                    tokens, kind = self._tokens(current)
                    if kind == "estimate":
                        token_kind = "estimate"
                    decisions[pack.id] = PackDecision(
                        pack.id, "included", "truncated", tokens,
                        len(current), "max_chars",
                    )
                text = render()

        total, final_kind = self._tokens(text)
        if final_kind == "estimate":
            token_kind = "estimate"
        token_overrun = max(0, total - token_limit)
        char_overrun = max(0, len(text) - char_limit)
        return ContextSelection(
            text=text,
            decisions=tuple(
                decisions[pack.id] for pack in sorted(rows, key=lambda item: item.order)
            ),
            tokens=total,
            chars=len(text),
            token_kind=token_kind,
            budget_satisfied=token_overrun == 0 and char_overrun == 0,
            max_tokens=token_limit,
            max_chars=char_limit,
            overrun_tokens=token_overrun,
            overrun_chars=char_overrun,
        )
