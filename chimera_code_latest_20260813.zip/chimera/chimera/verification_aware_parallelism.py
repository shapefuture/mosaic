"""Plan concurrency from conflict and verification capacity, not enthusiasm.

The planner has no execution authority.  Existing task-slice/capability/quality
admission remains responsible for whether a planned item may actually run.
"""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ParallelWorkItem(_FrozenModel):
    id: str
    reads: tuple[str, ...] = ()
    writes: tuple[str, ...] = ()
    provider_token_estimate: int = Field(default=0, ge=0)
    irreversible: bool = False
    kind: Literal["discovery", "implementation", "verification"] = "implementation"


class ParallelismBudget(_FrozenModel):
    max_workers: int = Field(ge=1)
    max_provider_tokens_per_batch: int = Field(ge=0)
    reserved_verification_slots: int = Field(default=1, ge=0)


class ParallelBatch(_FrozenModel):
    item_ids: tuple[str, ...]
    mode: Literal["parallel", "serial"]
    reason: str


class VerificationAwareParallelismPlanner:
    """Conservative deterministic batching with no overlap/irreversible races."""

    def plan(self, items: list[ParallelWorkItem] | tuple[ParallelWorkItem, ...], budget: ParallelismBudget) -> tuple[ParallelBatch, ...]:
        pending = list(items)
        seen: set[str] = set()
        if any(item.id in seen or seen.add(item.id) for item in pending):
            raise ValueError("parallel work item ids must be unique")
        output: list[ParallelBatch] = []
        generation_slots = max(1, budget.max_workers - budget.reserved_verification_slots)
        while pending:
            first = pending.pop(0)
            if first.irreversible:
                output.append(ParallelBatch(item_ids=(first.id,), mode="serial", reason="irreversible item is serialized"))
                continue
            batch = [first]
            token_total = first.provider_token_estimate
            survivors: list[ParallelWorkItem] = []
            for candidate in pending:
                if len(batch) >= generation_slots:
                    survivors.append(candidate); continue
                if candidate.irreversible:
                    survivors.append(candidate); continue
                if budget.max_provider_tokens_per_batch and token_total + candidate.provider_token_estimate > budget.max_provider_tokens_per_batch:
                    survivors.append(candidate); continue
                if any(self._conflicts(candidate, existing) for existing in batch):
                    survivors.append(candidate); continue
                batch.append(candidate)
                token_total += candidate.provider_token_estimate
            pending = survivors
            mode: Literal["parallel", "serial"] = "parallel" if len(batch) > 1 else "serial"
            reason = (
                "non-overlapping items fit generation/provider budget while verification capacity is reserved"
                if mode == "parallel" else
                "conflict, capacity, or provider-token budget requires serialization"
            )
            output.append(ParallelBatch(item_ids=tuple(item.id for item in batch), mode=mode, reason=reason))
        return tuple(output)

    @staticmethod
    def _conflicts(left: ParallelWorkItem, right: ParallelWorkItem) -> bool:
        left_reads, left_writes = set(left.reads), set(left.writes)
        right_reads, right_writes = set(right.reads), set(right.writes)
        return bool(
            left_writes & (right_reads | right_writes)
            or right_writes & (left_reads | left_writes)
        )
