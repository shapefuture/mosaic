"""GitNexus-inspired command observation augmentation.

GitNexus' eval agent augments grep/ripgrep observations with graph context when
a search pattern is detected.  Chimera keeps this opt-in and bounded: command
outputs are augmented only when CHIMERA_GRAPH_AUGMENT_SEARCH=1, the pattern is
safe, and CodeGraph search succeeds within tight limits.
"""
from __future__ import annotations

import json
import pathlib
import re
import time
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class AugmentationReceipt:
    applied: bool
    pattern: str | None
    hits: int
    duration_ms: float
    reason: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


_SEARCH_RE = re.compile(r"(?:^|\s)(?:grep|rg|ag)\s+(?:-[A-Za-z0-9_=-]+\s+)*(?:['\"]([^'\"]+)['\"]|(\S+))")


def extract_search_pattern(command: str, *, min_length: int = 3) -> str | None:
    match = _SEARCH_RE.search(command or "")
    if not match:
        return None
    value = (match.group(1) or match.group(2) or "").strip()
    if not value or len(value) < min_length:
        return None
    if value.startswith(("-", "/", ".")) or "\x00" in value:
        return None
    if any(token in value for token in (";", "&&", "||", "`", "$", "..")):
        return None
    return value[:120]


def augment_command_observation(root: pathlib.Path, command: str, output: str, *, max_hits: int = 5, max_chars: int = 1800) -> tuple[str, AugmentationReceipt]:
    pattern = extract_search_pattern(command)
    if not pattern:
        return output, AugmentationReceipt(False, None, 0, 0.0, "not-a-safe-search-command")
    started = time.perf_counter()
    try:
        from .graph import CodeGraph
        graph = CodeGraph(pathlib.Path(root))
        try:
            graph.load()
        except Exception:
            graph.build(persist=False)
        hits = graph.search(pattern, limit=max_hits)
        bounded = [
            {key: hit.get(key) for key in ("kind", "file", "name", "qualified_name", "line") if key in hit}
            for hit in hits[:max_hits]
        ]
        if not bounded:
            return output, AugmentationReceipt(False, pattern, 0, round((time.perf_counter() - started) * 1000, 3), "no-graph-hits")
        suffix = "\n\n[Chimera graph augmentation]\n" + json.dumps(bounded, sort_keys=True, separators=(",", ":"))[:max_chars]
        return output + suffix, AugmentationReceipt(True, pattern, len(bounded), round((time.perf_counter() - started) * 1000, 3), "graph-context-appended")
    except Exception as exc:
        return output, AugmentationReceipt(False, pattern, 0, round((time.perf_counter() - started) * 1000, 3), f"augmentation-error:{type(exc).__name__}")
