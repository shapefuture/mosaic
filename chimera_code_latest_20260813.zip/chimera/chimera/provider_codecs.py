"""Pure provider wire codecs for mock-tested endpoint adapters.

These codecs intentionally perform no HTTP, credential lookup, routing, or
provider capability promotion. They provide canonical payload/usage parsing so
future adapters can be tested before an explicitly authorized endpoint canary.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from .request_stability import canonicalize_tool_schema


@dataclass(frozen=True)
class ProviderUsage:
    input_tokens: int | None
    output_tokens: int | None
    cache_read_tokens: int | None
    cache_creation_tokens: int | None


class AnthropicMessagesCodec:
    @staticmethod
    def request(*, model: str, system: str, messages: Iterable[Mapping[str, Any]], tools: Iterable[Mapping[str, Any]], max_tokens: int) -> dict[str, Any]:
        return {
            "model": model, "max_tokens": int(max_tokens),
            "system": [{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            "messages": [dict(message) for message in messages],
            "tools": [{"name": str(tool["name"]), "description": str(tool.get("description", "")), "input_schema": canonicalize_tool_schema(tool.get("parameters"))} for tool in tools],
        }

    @staticmethod
    def usage(response: Mapping[str, Any]) -> ProviderUsage:
        usage = response.get("usage", {}) if isinstance(response.get("usage"), Mapping) else {}
        return ProviderUsage(usage.get("input_tokens"), usage.get("output_tokens"), usage.get("cache_read_input_tokens"), usage.get("cache_creation_input_tokens"))


class OpenAIResponsesCodec:
    @staticmethod
    def request(*, model: str, input_items: Iterable[Mapping[str, Any]], tools: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
        return {
            "model": model,
            "input": [dict(item) for item in input_items],
            "tools": [{"type": "function", "name": str(tool["name"]), "description": str(tool.get("description", "")), "parameters": canonicalize_tool_schema(tool.get("parameters")), "strict": True} for tool in tools],
        }

    @staticmethod
    def usage(response: Mapping[str, Any]) -> ProviderUsage:
        usage = response.get("usage", {}) if isinstance(response.get("usage"), Mapping) else {}
        details = usage.get("input_tokens_details", {}) if isinstance(usage.get("input_tokens_details"), Mapping) else {}
        return ProviderUsage(usage.get("input_tokens"), usage.get("output_tokens"), details.get("cached_tokens"), None)
