"""Trusted evaluator key registry for signed waivers and promotion gates."""
from __future__ import annotations

import json
import pathlib
from dataclasses import dataclass, asdict
from typing import Any, Iterable


@dataclass(frozen=True)
class TrustedEvaluator:
    key_id: str
    name: str
    scopes: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class TrustedEvaluatorRegistry:
    DEFAULT_NAME = ".chimera/trusted-evaluators.json"

    def __init__(self, evaluators: Iterable[TrustedEvaluator] = ()) -> None:
        self.evaluators = tuple(evaluators)
        self.key_ids = frozenset(e.key_id for e in self.evaluators)

    @classmethod
    def load(cls, path: pathlib.Path | None) -> "TrustedEvaluatorRegistry":
        if path is None:
            return cls(())
        path = pathlib.Path(path)
        if not path.exists():
            return cls(())
        data = json.loads(path.read_text(encoding="utf-8"))
        rows = data.get("evaluators", []) if isinstance(data, dict) else data
        evaluators = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            scopes = row.get("scopes", ["waiver"])
            evaluators.append(TrustedEvaluator(
                key_id=str(row["key_id"]),
                name=str(row.get("name") or row["key_id"]),
                scopes=tuple(str(item) for item in scopes),
            ))
        return cls(evaluators)

    @classmethod
    def write_template(cls, path: pathlib.Path, *, key_id: str = "ed25519:<fill>", name: str = "evaluator") -> dict[str, Any]:
        payload = {"schema_version": "chimera.trusted-evaluators.v1", "evaluators": [{"key_id": key_id, "name": name, "scopes": ["waiver", "promotion"]}]}
        path = pathlib.Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return payload

    def allows(self, key_id: str | None, *, scope: str = "waiver") -> bool:
        if not key_id:
            return False
        return any(e.key_id == key_id and scope in e.scopes for e in self.evaluators)

    def as_dict(self) -> dict[str, Any]:
        return {"schema_version": "chimera.trusted-evaluators.v1", "trusted_key_ids": sorted(self.key_ids), "evaluators": [e.as_dict() for e in self.evaluators]}
