"""Default GUI application facade over Chimera hexagonal use cases."""
from __future__ import annotations

import pathlib
from typing import Any, Mapping

from .application import ChimeraApplication, QueryCodeCommand, RunContext, VerifyBranchCommand, RunTaskCommand, OpenSessionCommand, CancelSessionCommand
from .gui_ports import GuiAction, GuiActionResult, GuiNavigationItem, GuiTenantSession, GuiViewModel
from .telemetry_snapshot import TelemetrySnapshotBuilder


class DefaultGuiApplication:
    def __init__(self, root: pathlib.Path, application: ChimeraApplication, context_factory):
        self.root = pathlib.Path(root).resolve()
        self.application = application
        self.context_factory = context_factory

    def _context(self, session: GuiTenantSession) -> RunContext:
        context = self.context_factory()
        return context.model_copy(update={
            "tenant_key": session.tenant_key or context.tenant_key,
            "principal_hash": session.principal_hash or context.principal_hash,
            "trace_id": session.trace_id or context.trace_id,
        })

    def dashboard(self, session: GuiTenantSession) -> GuiViewModel:
        telemetry = self.telemetry(session, recent=50)
        return GuiViewModel(
            schema_version="chimera.gui-view-model.v1",
            title="Chimera",
            navigation=(
                GuiNavigationItem("runs", "Runs", "run"),
                GuiNavigationItem("graph", "Code Graph", "graph"),
                GuiNavigationItem("telemetry", "Telemetry", "telemetry"),
                GuiNavigationItem("settings", "Settings", "settings"),
            ),
            panels={"telemetry": telemetry},
            redactions=("provider keys", "raw prompts", "endpoint URLs"),
        )

    def telemetry(self, session: GuiTenantSession, *, recent: int = 200) -> Mapping[str, Any]:
        return TelemetrySnapshotBuilder(self.root).build(recent=recent).model_dump(mode="json")

    def graph_query(self, session: GuiTenantSession, query: str, *, limit: int = 20) -> Mapping[str, Any]:
        return self.application.query_code(QueryCodeCommand(query=query, limit=limit, context=self._context(session))).model_dump(mode="json")

    def dispatch(self, session: GuiTenantSession, action: GuiAction) -> GuiActionResult:
        try:
            context = self._context(session)
            payload = dict(action.payload)
            if action.kind == "read_telemetry":
                return GuiActionResult(True, "ok", self.telemetry(session, recent=int(payload.get("recent", 200))))
            if action.kind == "query_graph":
                return GuiActionResult(True, "ok", self.graph_query(session, str(payload.get("query", "")), limit=int(payload.get("limit", 20))))
            if action.kind == "verify_branch":
                value = self.application.verify(VerifyBranchCommand(branch=str(payload.get("branch", "main")), command=str(payload.get("command", "pytest -q")), context=context))
                return GuiActionResult(True, "ok", value.model_dump(mode="json"))
            if action.kind == "run_task":
                value = self.application.run(RunTaskCommand(task=str(payload["task"]), branch=str(payload.get("branch", "gui-run")), model=str(payload.get("model", "mock-echo")), context=context))
                return GuiActionResult(True, "ok", value.model_dump(mode="json"))
            if action.kind == "open_session":
                value = self.application.open_session(OpenSessionCommand(objective=str(payload["objective"]), model=str(payload.get("model", "mock-echo")), base_branch=str(payload.get("base_branch", "main")), protocol="gui", context=context))
                return GuiActionResult(True, "ok", value.model_dump(mode="json"))
            if action.kind == "cancel_session":
                value = self.application.cancel_session(CancelSessionCommand(session_id=str(payload["session_id"]), context=context))
                return GuiActionResult(True, "ok", value.model_dump(mode="json"))
            return GuiActionResult(False, "unsupported", error=f"unsupported GUI action: {action.kind}")
        except Exception as exc:
            return GuiActionResult(False, "error", error=f"{type(exc).__name__}: {exc}"[:500])
