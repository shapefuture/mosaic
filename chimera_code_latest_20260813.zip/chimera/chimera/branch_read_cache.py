"""Branch-content read cache keyed by exact bytes, never path alone."""
from __future__ import annotations

import hashlib
import threading
from collections import OrderedDict
from typing import OrderedDict as OrderedDictType


class BranchReadCache:
    def __init__(self, max_entries: int = 256):
        self.max = max_entries
        self.rows: OrderedDictType[tuple[str, str, str], str] = OrderedDict()
        self.lock = threading.RLock()

    def get(self, branch: str, path: str, data: bytes):
        key = (branch, path, hashlib.sha256(data).hexdigest())
        with self.lock:
            value = self.rows.get(key)
            if value is not None:
                self.rows.move_to_end(key)
                return value, True
            text = data.decode("utf-8", errors="replace")
            self.rows[key] = text
            if len(self.rows) > self.max:
                self.rows.popitem(last=False)
            return text, False

    def invalidate_path(self, branch: str, path: str):
        with self.lock:
            for key in [k for k in self.rows if k[0] == branch and k[1] == path]:
                self.rows.pop(key, None)
