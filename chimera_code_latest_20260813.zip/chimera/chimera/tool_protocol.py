"""Tool protocol helpers extracted from the RLM runtime boundary."""
from __future__ import annotations

import json
from typing import Any


class ToolProtocol:
    @staticmethod
    def json_object(text: str) -> dict[str, Any] | None:
        decoder = json.JSONDecoder()
        candidates = [text.strip()]
        if "```" in text:
            import re
            candidates = re.findall(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.S | re.I) + candidates
        for candidate in candidates:
            starts = [0] if candidate.startswith("{") else [i for i, ch in enumerate(candidate) if ch == "{"]
            for start in starts:
                try:
                    value, _ = decoder.raw_decode(candidate[start:])
                    return value if isinstance(value, dict) else None
                except json.JSONDecodeError:
                    continue
        return None

    @staticmethod
    def patch_payload(files: dict[str, str]) -> dict[str, Any]:
        return {"files": [{"path": path, "content": content} for path, content in files.items()]}
