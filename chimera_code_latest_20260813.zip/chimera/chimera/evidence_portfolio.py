"""Privacy-minimal local flight recorder for coding-agent runs.

The recorder separates three retention classes:

* an always-on, hash-only effect ledger;
* a bounded recent-receipt ring; and
* redacted full CAS captures for failure/policy/novelty triggers plus a small
  healthy baseline sample.

It is local observability, not a remote telemetry backend, an audit guarantee,
or behavioural attestation of third-party tools.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import os
import pathlib
import random
import re
import threading
import time
from typing import Any, Iterable, Mapping

from .artifacts import ContentAddressedArtifactStore
from .wal import WAL


_SECRET_KEY = re.compile(r"(?:token|secret|password|credential|authorization|api[_-]?key|cookie|private[_-]?key)", re.I)
_SECRET_VALUE = re.compile(
    r"(?i)(?:bearer\s+|(?:api[_-]?key|token|secret|password)\s*[:=]\s*)([A-Za-z0-9_\-./+=]{8,})"
)
_HIGH_SIGNAL = ("error", "failed", "denied", "violation", "conflict", "timeout", "quarantine", "expired", "stale")
_POLICY_SIGNAL = ("policy", "capability", "approval", "certificate", "precondition", "scope")


@dataclass(frozen=True)
class EvidenceSamplingPolicy:
    version: str = "local-flight-recorder/v1"
    healthy_sample_rate: float = 0.05
    ring_capacity: int = 128
    max_full_events: int = 512

    def __post_init__(self) -> None:
        if not self.version.strip():
            raise ValueError("sampling policy version is required")
        if not 0.0 <= self.healthy_sample_rate <= 1.0:
            raise ValueError("healthy_sample_rate must be between 0 and 1")
        if self.ring_capacity < 1 or self.max_full_events < 1:
            raise ValueError("ring_capacity and max_full_events must be positive")

    def digest(self) -> str:
        raw = json.dumps(asdict(self), sort_keys=True, separators=(",", ":")).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True)
class EvidencePortfolioReceipt:
    run_id: str
    policy_version: str
    policy_hash: str
    event_count: int
    triggers: tuple[str, ...]
    healthy_sampled: bool
    full_capture_ref: str | None
    ring_size: int
    fingerprint: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class LocalEvidencePortfolio:
    """Versioned local retention policy with redaction before persistence."""

    _lock_guard = threading.Lock()
    _locks: dict[str, threading.RLock] = {}

    def __init__(
        self,
        root: pathlib.Path,
        policy: EvidenceSamplingPolicy | None = None,
        *,
        random_source: random.Random | None = None,
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.policy = policy or EvidenceSamplingPolicy()
        self.wal = WAL(self.root)
        self.store = ContentAddressedArtifactStore(self.root)
        self.ring_path = self.root / ".chimera" / "evidence-portfolio-ring.json"
        self._random = random_source or random.SystemRandom()
        with self._lock_guard:
            self._lock = self._locks.setdefault(str(self.ring_path), threading.RLock())

    @staticmethod
    def _hash(value: Any) -> str:
        raw = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    @classmethod
    def _redact(cls, value: Any, *, depth: int = 0) -> Any:
        if depth > 12:
            return "[depth-limited]"
        if isinstance(value, Mapping):
            output: dict[str, Any] = {}
            for key, item in value.items():
                name = str(key)
                output[name] = "[redacted]" if _SECRET_KEY.search(name) else cls._redact(item, depth=depth + 1)
            return output
        if isinstance(value, (list, tuple)):
            return [cls._redact(item, depth=depth + 1) for item in value]
        if isinstance(value, str):
            return _SECRET_VALUE.sub(lambda match: match.group(0).replace(match.group(1), "[redacted]"), value)
        if isinstance(value, (int, float, bool)) or value is None:
            return value
        return f"[{type(value).__name__}]"

    @staticmethod
    def _event_kind(row: Mapping[str, Any]) -> str:
        return str(row.get("kind") or row.get("tool") or row.get("event") or "unknown").lower()

    def _signals(self, rows: list[dict[str, Any]], fingerprint: str) -> tuple[str, ...]:
        kinds = [self._event_kind(row) for row in rows]
        payload = " ".join(kinds)
        def failed_row(row: Mapping[str, Any]) -> bool:
            if row.get("ok") is False or str(row.get("state", "")).lower() in {"failed", "cancelled", "rejected"}:
                return True
            status = row.get("status")
            if status is None or str(status).lower() in {"pass", "ok", "success"}:
                return False
            try:
                return int(status) not in {0, 200}
            except (TypeError, ValueError):
                return False

        failed = any(failed_row(row) for row in rows)
        policy_breach = any(
            any(token in self._event_kind(row) for token in _POLICY_SIGNAL)
            and (row.get("ok") is False or row.get("allowed") is False)
            for row in rows
        )
        triggers: list[str] = []
        if failed or any(token in payload for token in _HIGH_SIGNAL):
            triggers.append("failure")
        if policy_breach:
            triggers.append("policy")
        if fingerprint not in {row.get("fingerprint") for row in self._ring_rows()}:
            triggers.append("novelty")
        return tuple(triggers)

    def _ring_rows(self) -> list[dict[str, Any]]:
        if not self.ring_path.exists():
            return []
        try:
            parsed = json.loads(self.ring_path.read_text())
        except (OSError, json.JSONDecodeError):
            # A corrupt observability ring must never block task authority;
            # retain no trust in it and let this capture replace it atomically.
            return []
        return [dict(row) for row in parsed if isinstance(row, Mapping)] if isinstance(parsed, list) else []

    def _write_ring(self, rows: list[dict[str, Any]]) -> None:
        self.ring_path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(rows[-self.policy.ring_capacity:], sort_keys=True, separators=(",", ":")) + "\n"
        temporary = self.ring_path.with_name(f".{self.ring_path.name}.{os.getpid()}.{time.time_ns()}.tmp")
        try:
            with temporary.open("w", encoding="utf-8") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.ring_path)
        finally:
            if temporary.exists():
                temporary.unlink()

    def capture(self, *, run_id: str, events: Iterable[Mapping[str, Any]]) -> EvidencePortfolioReceipt:
        """Persist a metadata ledger for every run and a redacted full capture selectively."""
        safe_rows = [self._redact(dict(event)) for event in events if isinstance(event, Mapping)]
        # Fingerprint only coarse observable shape; it deliberately avoids raw
        # messages, command arguments, and tool output.
        shape = [{"kind": self._event_kind(row), "keys": sorted(map(str, row.keys()))} for row in safe_rows]
        fingerprint = self._hash(shape)
        with self._lock:
            triggers = self._signals(safe_rows, fingerprint)
            healthy = not triggers and self._random.random() < self.policy.healthy_sample_rate
            full_ref = None
            if triggers or healthy:
                bounded = safe_rows[:self.policy.max_full_events]
                ref = self.store.put(
                    json.dumps(bounded, sort_keys=True, separators=(",", ":"), default=str),
                    media_type="application/vnd.chimera.redacted-flight+json",
                    provenance={
                        "kind": "local-evidence-portfolio",
                        "run_id_hash": self._hash(str(run_id)),
                        "policy_hash": self.policy.digest(),
                        "triggers": list(triggers),
                        "healthy_sampled": healthy,
                        "events_total": len(safe_rows),
                        "events_captured": len(bounded),
                    },
                )
                full_ref = f"artifact:{ref.digest}"
            ring = self._ring_rows()
            ring.append({
                "run_id_hash": self._hash(str(run_id)), "fingerprint": fingerprint,
                "policy_hash": self.policy.digest(), "triggers": list(triggers),
                "healthy_sampled": healthy, "full_capture_ref": full_ref, "at": time.time(),
            })
            self._write_ring(ring)
            receipt = EvidencePortfolioReceipt(
                run_id=str(run_id), policy_version=self.policy.version, policy_hash=self.policy.digest(),
                event_count=len(safe_rows), triggers=triggers, healthy_sampled=healthy,
                full_capture_ref=full_ref, ring_size=min(len(ring), self.policy.ring_capacity), fingerprint=fingerprint,
            )
            # Always-on ledger: only event shape, hashes and policy decision.
            self.wal.append("evidence_effect_ledger", receipt.as_dict())
            return receipt
