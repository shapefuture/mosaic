"""Bounded stable-prefix prompt-cache hints and telemetry."""
from __future__ import annotations

import hashlib
import re
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass


@dataclass(frozen=True)
class PromptPartition:
    prefix: str
    suffix: str
    prefix_hash: str
    stable: bool
    turn: int
    lint: tuple[str, ...]
    history: str = ""
    live: str = ""

    def content_blocks(self):
        blocks = [{
            "type": "text",
            "text": self.prefix,
            "cache_control": {"type": "ephemeral"},
        }]
        if self.history:
            blocks.append({
                "type": "text",
                "text": self.history,
                "cache_control": {"type": "ephemeral"},
            })
        if self.live:
            blocks.append({"type": "text", "text": self.live})
        elif self.suffix and not self.history:
            blocks.append({"type": "text", "text": self.suffix})
        return blocks


@dataclass(frozen=True)
class CacheHealth:
    status: str
    cache_read_tokens: int | None
    cache_creation_tokens: int | None
    age_seconds: float | None
    warning: str | None


class PromptCacheTracker:
    PROVIDER_TTLS = {
        "anthropic": 300.0,
        "claude": 300.0,
        "dashscope": 300.0,
        "qwen": 300.0,
        "deepseek": 86_400.0,
    }
    DYNAMIC = (
        (re.compile(r"\b20\d\d-\d\d-\d\dT\d\d:\d\d"), "timestamp in stable prefix"),
        (
            re.compile(
                r"\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b",
                re.I,
            ),
            "UUID in stable prefix",
        ),
        (
            re.compile(r"\b(?:nonce|request[_ -]?id)\s*[:=]", re.I),
            "request nonce/id in stable prefix",
        ),
    )

    def __init__(self, *, max_sessions: int = 1_024, ttl_seconds: float = 86_400.0):
        self.sessions: OrderedDict[str, dict] = OrderedDict()
        self.lock = threading.RLock()
        self.max_sessions = max(1, int(max_sessions))
        self.ttl_seconds = max(1.0, float(ttl_seconds))

    def _state(self, session: str) -> dict:
        now = time.monotonic()
        expired = [
            key for key, value in self.sessions.items()
            if now - float(value.get("touched", now)) > self.ttl_seconds
        ]
        for key in expired:
            self.sessions.pop(key, None)
        state = self.sessions.pop(session, {"turn": 0, "hash": None})
        state["touched"] = now
        self.sessions[session] = state
        while len(self.sessions) > self.max_sessions:
            self.sessions.popitem(last=False)
        return state

    def partition(
        self,
        session: str,
        prefix: str,
        suffix: str,
        *,
        history: str = "",
        live: str = "",
    ) -> PromptPartition:
        digest = "sha256:" + hashlib.sha256(prefix.encode()).hexdigest()
        lint = tuple(
            message for pattern, message in self.DYNAMIC
            if pattern.search(prefix[:12_000])
        )
        with self.lock:
            state = self._state(session)
            prior_hash = state.get("hash")
            turn = int(state.get("turn", 0)) + 1
            stable = prior_hash is None or prior_hash == digest
            state.update({
                "hash": digest,
                "turn": turn,
                "history_hash": (
                    "sha256:" + hashlib.sha256(history.encode()).hexdigest()
                    if history else None
                ),
            })
        return PromptPartition(prefix, suffix, digest, stable, turn, lint, history, live)

    @staticmethod
    def _counter(usage, names):
        for name in names:
            value = usage.get(name)
            if isinstance(value, (int, float)):
                return int(value)
        details = (
            usage.get("prompt_tokens_details")
            if isinstance(usage.get("prompt_tokens_details"), dict)
            else {}
        )
        for name in names:
            value = details.get(name)
            if isinstance(value, (int, float)):
                return int(value)
        return None

    @classmethod
    def provider_ttl(cls, provider: str | None) -> float | None:
        if not provider:
            return None
        value = provider.lower()
        for key, ttl in cls.PROVIDER_TTLS.items():
            if key in value:
                return ttl
        return None

    def attribute_break(
        self,
        session: str,
        fields: dict[str, object],
    ) -> tuple[str, ...]:
        fingerprints = {
            key: "sha256:" + hashlib.sha256(repr(value).encode()).hexdigest()
            for key, value in fields.items()
        }
        with self.lock:
            state = self._state(session)
            prior = state.get("field_fingerprints", {})
            state["field_fingerprints"] = fingerprints
        return tuple(sorted(
            key for key, value in fingerprints.items()
            if key in prior and prior[key] != value
        ))

    def observe_usage(
        self,
        session: str,
        usage: dict,
        ttl_seconds: float | None = None,
        provider: str | None = None,
    ) -> CacheHealth:
        effective_ttl = (
            ttl_seconds if ttl_seconds is not None else self.provider_ttl(provider)
        )
        now = time.time()
        read = self._counter(
            usage,
            ("cache_read_input_tokens", "cached_tokens", "cache_read_tokens"),
        )
        creation = self._counter(
            usage,
            ("cache_creation_input_tokens", "cache_creation_tokens"),
        )
        warning = None
        with self.lock:
            state = self._state(session)
            last = state.get("usage_at")
            age = now - last if last else None
            turn = int(state.get("turn", 0))
            if read is None and creation is None:
                status = "unreported"
            elif read and read > 0:
                status = "warm"
            elif effective_ttl is not None and age is not None and age > effective_ttl:
                status = "cold"
                warning = (
                    f"provider cache age {age:.0f}s exceeded {effective_ttl:.0f}s"
                )
            elif turn > 1 and (read or 0) == 0:
                status = "unexpected-miss"
                warning = "stable repeated prefix reported zero cache-read tokens"
            else:
                status = "created"
            state.update({
                "usage_at": now,
                "last_read": read,
                "last_creation": creation,
                "cache_status": status,
            })
        return CacheHealth(status, read, creation, age, warning)

    def close(self) -> None:
        with self.lock:
            self.sessions.clear()
