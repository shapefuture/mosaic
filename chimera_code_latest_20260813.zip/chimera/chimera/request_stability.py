"""Canonical provider requests and explainable prompt-cache shape telemetry.

Provider retries must replay identical bytes.  This module strips host-only
metadata, canonicalizes tool schemas, orders tools deterministically, freezes the
wire payload as canonical JSON, and attributes cache-shape changes by surface.
"""
from __future__ import annotations

import hashlib
import json
import threading
from typing import Any, Iterable, Mapping, Optional

from pydantic import BaseModel, ConfigDict


class FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


_LOCAL_MESSAGE_FIELDS = frozenset({
    "created_at", "createdAt", "edited", "original", "workDurationMs",
    "memoryCitations", "decision_receipt", "decision_receipts",
    "toolExecution", "tool_execution", "local_only",
})


class ToolContract(FrozenModel):
    name: str
    description: str = ""
    parameters: dict[str, Any]


class FrozenProviderRequest(FrozenModel):
    canonical_json: str
    request_hash: str
    system_hash: str
    messages_hash: str
    tools_hash: str
    params_hash: str
    wire_bytes: int
    tool_schema_bytes: int

    def payload(self) -> dict[str, Any]:
        return json.loads(self.canonical_json)


class RequestShapeObservation(FrozenModel):
    session: str
    request_hash: str
    stable: bool
    changed: tuple[str, ...]
    explicit_rewrite_reasons: tuple[str, ...]
    wire_bytes: int
    tool_schema_bytes: int


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def _hash(value: Any) -> str:
    return "sha256:" + hashlib.sha256(_canonical(value).encode()).hexdigest()


def _strip_local_message(value: Mapping[str, Any]) -> Optional[dict[str, Any]]:
    if value.get("local_only") is True:
        return None
    output: dict[str, Any] = {}
    for key, item in value.items():
        if key in _LOCAL_MESSAGE_FIELDS:
            continue
        if isinstance(item, Mapping):
            output[str(key)] = _strip_nested(item)
        elif isinstance(item, list):
            output[str(key)] = [_strip_nested(entry) for entry in item]
        else:
            output[str(key)] = item
    return output


def _strip_nested(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {
            str(key): _strip_nested(item)
            for key, item in value.items()
            if key not in _LOCAL_MESSAGE_FIELDS
        }
    if isinstance(value, list):
        return [_strip_nested(item) for item in value]
    return value


def _normalize_schema(value: Any, *, root: bool = False) -> Any:
    if isinstance(value, list):
        return [_normalize_schema(item) for item in value]
    if not isinstance(value, Mapping):
        return value
    result = {str(key): _normalize_schema(item) for key, item in value.items()}
    required = result.get("required")
    if required is not None:
        if not isinstance(required, list) or any(not isinstance(item, str) for item in required):
            raise ValueError("JSON Schema required must be an array of strings")
        result["required"] = sorted(dict.fromkeys(required))
    if root:
        if not result:
            result = {"type": "object", "properties": {}}
        if "type" not in result:
            result["type"] = "object"
        if result.get("type") == "object" and "properties" not in result:
            result["properties"] = {}
    return result


def canonicalize_tool_schema(schema: str | bytes | Mapping[str, Any] | None) -> dict[str, Any]:
    if schema is None or schema == "" or schema == b"":
        return {"type": "object", "properties": {}}
    if isinstance(schema, (str, bytes)):
        try:
            value = json.loads(schema)
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ValueError(f"invalid tool JSON Schema: {exc}") from exc
    else:
        value = dict(schema)
    if value is None:
        return {"type": "object", "properties": {}}
    if not isinstance(value, Mapping):
        raise ValueError("tool JSON Schema root must be an object")
    normalized = _normalize_schema(value, root=True)
    # Round-trip through canonical JSON to detach caller-owned mutable objects.
    return json.loads(_canonical(normalized))


class StableRequestBuilder:
    @staticmethod
    def freeze(
        *,
        system: Iterable[str],
        messages: Iterable[Mapping[str, Any]],
        tools: Iterable[Mapping[str, Any]],
        params: Optional[Mapping[str, Any]] = None,
    ) -> FrozenProviderRequest:
        system_rows = tuple(str(item) for item in system)
        message_rows = tuple(
            row for value in messages if (row := _strip_local_message(value)) is not None
        )
        tool_rows = []
        for value in tools:
            name = str(value.get("name", "")).strip()
            if not name:
                raise ValueError("tool name is required")
            tool_rows.append(ToolContract(
                name=name,
                description=str(value.get("description", "")),
                parameters=canonicalize_tool_schema(value.get("parameters")),
            ).model_dump(mode="json"))
        tool_rows.sort(key=lambda item: (item["name"], item["description"], _canonical(item["parameters"])))
        params_value = _strip_nested(dict(params or {}))
        payload = {
            "system": system_rows,
            "messages": message_rows,
            "tools": tuple(tool_rows),
            "params": params_value,
        }
        wire = _canonical(payload)
        tools_wire = _canonical(tool_rows)
        return FrozenProviderRequest(
            canonical_json=wire,
            request_hash=_hash(payload),
            system_hash=_hash(system_rows),
            messages_hash=_hash(message_rows),
            tools_hash=_hash(tool_rows),
            params_hash=_hash(params_value),
            wire_bytes=len(wire.encode()),
            tool_schema_bytes=len(tools_wire.encode()),
        )


class RequestShapeTracker:
    def __init__(self) -> None:
        self._state: dict[str, FrozenProviderRequest] = {}
        self._lock = threading.RLock()

    def observe(
        self,
        session: str,
        request: FrozenProviderRequest,
        *,
        rewrite_reasons: Iterable[str] = (),
    ) -> RequestShapeObservation:
        explicit = tuple(dict.fromkeys(str(item) for item in rewrite_reasons if str(item)))
        changed: list[str] = []
        with self._lock:
            prior = self._state.get(session)
            if prior is not None:
                for name in ("system", "messages", "tools", "params"):
                    if getattr(prior, f"{name}_hash") != getattr(request, f"{name}_hash"):
                        changed.append(name)
            changed.extend(reason for reason in explicit if reason not in changed)
            self._state[session] = request
        return RequestShapeObservation(
            session=session,
            request_hash=request.request_hash,
            stable=prior is None or not changed,
            changed=tuple(changed),
            explicit_rewrite_reasons=explicit,
            wire_bytes=request.wire_bytes,
            tool_schema_bytes=request.tool_schema_bytes,
        )
