"""Evidence-gated provider endpoint capabilities.

A provider name, a model card, or a successful ordinary completion is not proof
that a *specific endpoint* supports function tools, strict JSON, cache reuse,
or session chaining.  This registry starts fail-closed and only exposes a
capability after a redacted, content-addressed canary report has proved that
capability for the exact provider/model pair.

It deliberately does not infer Responses-API session semantics from a Chat
Completions adapter.  Those capabilities remain false until Chimera has an
adapter and an endpoint-level canary for them.
"""
from __future__ import annotations

from dataclasses import dataclass, fields
import pathlib
import time
from typing import Any, Iterable

from .artifacts import ContentAddressedArtifactStore
from .wal import WAL, wal_write


@dataclass(frozen=True)
class ProviderCapabilities:
    native_tools: bool = False
    streaming: bool = False
    strict_json: bool = False
    prompt_cache: bool = False
    sticky_session: bool = False
    response_chain: bool = False

    @classmethod
    def names(cls) -> tuple[str, ...]:
        return tuple(item.name for item in fields(cls))

    def enabled(self) -> tuple[str, ...]:
        return tuple(name for name in self.names() if getattr(self, name))

    def with_capability(self, capability: str, value: bool = True) -> "ProviderCapabilities":
        if capability not in self.names():
            raise ValueError(f"unknown provider capability: {capability}")
        values = {name: getattr(self, name) for name in self.names()}
        values[capability] = bool(value)
        return ProviderCapabilities(**values)


class ProviderCapabilityRegistry:
    """Durable, artifact-backed capability proofs scoped to provider + model.

    ``get`` returns only currently proved capabilities.  Unknown or expired
    claims return the all-false profile.  A proof is valid only if its evidence
    reference resolves to a locally verified CAS artifact; this prevents a
    README, a social post, or a model self-report from becoming routing policy.
    """

    # A short default keeps a transient gateway/model behaviour from becoming a
    # permanent assumption.  Callers can request a different maximum age when
    # reporting status, but cannot make an unproven value true.
    DEFAULT_MAX_AGE_SECONDS = 7 * 24 * 60 * 60

    def __init__(self, root: pathlib.Path | None = None, *, max_age_seconds: float = DEFAULT_MAX_AGE_SECONDS) -> None:
        self.root = pathlib.Path(root).resolve() if root is not None else None
        self.max_age_seconds = max(1.0, float(max_age_seconds))
        self._memory: dict[tuple[str, str], ProviderCapabilities] = {}
        self._wal = WAL(self.root) if self.root is not None else None
        self._artifacts = ContentAddressedArtifactStore(self.root) if self.root is not None else None

    @staticmethod
    def _key(provider: str, model: str | None = None) -> tuple[str, str]:
        return (str(provider or "").strip().lower(), str(model or "*").strip().lower() or "*")

    @staticmethod
    def _artifact_digest(evidence_ref: str) -> str | None:
        prefix = "artifact:"
        if not isinstance(evidence_ref, str) or not evidence_ref.startswith(prefix):
            return None
        digest = evidence_ref[len(prefix):]
        return digest if digest.startswith("sha256:") else None

    def _evidence_exists(self, evidence_ref: str) -> bool:
        digest = self._artifact_digest(evidence_ref)
        return bool(digest and self._artifacts is not None and self._artifacts.has(digest))

    def _load(self) -> dict[tuple[str, str], ProviderCapabilities]:
        if self._wal is None or self._artifacts is None:
            return dict(self._memory)
        # Root-backed registries are reconstructed from durable evidence on
        # every read so an in-memory success cannot outlive its canary TTL.
        resolved: dict[tuple[str, str], ProviderCapabilities] = {}
        # Replay is ordered.  Later observations can revoke a prior proof.
        for entry in self._wal.replay(kind="provider_capability_proof"):
            row = entry.get("data", {})
            provider = row.get("provider")
            model = row.get("model", "*")
            capability = row.get("capability")
            verified = row.get("verified")
            evidence_ref = row.get("evidence_ref", "")
            observed_at = row.get("observed_at")
            if not isinstance(provider, str) or not isinstance(model, str) or capability not in ProviderCapabilities.names():
                continue
            try:
                fresh = time.time() - float(observed_at) <= self.max_age_seconds
            except (TypeError, ValueError):
                fresh = False
            if not fresh or not self._evidence_exists(str(evidence_ref)):
                continue
            key = self._key(provider, model)
            resolved[key] = resolved.get(key, ProviderCapabilities()).with_capability(capability, bool(verified))
        return resolved

    def get(self, provider: str, model: str | None = None) -> ProviderCapabilities:
        rows = self._load()
        exact = rows.get(self._key(provider, model))
        if exact is not None:
            return exact
        # A model-agnostic proof may be used only when explicitly recorded as
        # such; we never fan a model-specific proof out to a whole gateway.
        return rows.get(self._key(provider, "*"), ProviderCapabilities())

    def record(
        self,
        provider: str,
        capability: str,
        verified: bool,
        evidence_ref: str,
        *,
        model: str = "*",
    ) -> ProviderCapabilities:
        if capability not in ProviderCapabilities.names():
            raise ValueError(f"unknown provider capability: {capability}")
        if verified and capability in {"sticky_session", "response_chain"}:
            raise ValueError("session/response-chain capabilities require a dedicated endpoint adapter and cannot be promoted here")
        if not self._evidence_exists(evidence_ref):
            raise ValueError("provider capability proof requires a resolvable artifact:<sha256> reference")
        key = self._key(provider, model)
        current = self.get(provider, model)
        updated = current.with_capability(capability, bool(verified))
        self._memory[key] = updated
        if self._wal is not None:
            wal_write(self._wal, "provider_capability_proof", {
                "provider": key[0], "model": key[1], "capability": capability,
                "verified": bool(verified), "evidence_ref": evidence_ref,
                "observed_at": time.time(),
            })
        return updated

    def record_report(
        self,
        provider: str,
        model: str,
        evidence_ref: str,
        outcomes: Iterable[dict[str, Any]],
    ) -> ProviderCapabilities:
        """Promote only positive, explicitly promotable canary outcomes.

        Negative observations are also durable and revoke the capability.  A
        result without the ``promotable`` bit is logged by the caller's report
        but never changes routing policy (for example, a refusal-shape
        observation or an unsupported sticky-session probe).
        """
        current = self.get(provider, model)
        for outcome in outcomes:
            capability = outcome.get("capability")
            if capability not in ProviderCapabilities.names() or not outcome.get("promotable"):
                continue
            current = self.record(provider, capability, bool(outcome.get("passed")), evidence_ref, model=model)
        return current
