"""Deterministic completion-claim/evidence gate.

Cheap Tier-0 guard before probabilistic held-out/meta-critic checks. It rejects
"verified" completion claims whose evidence does not match the claim class.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Mapping, Iterable
import re


@dataclass(frozen=True)
class CompletionGateResult:
    allowed: bool
    status: str
    claim_class: str
    reasons: tuple[str, ...]
    challenge_limit_reached: bool = False
    def as_dict(self) -> dict[str, Any]: return asdict(self)


class CompletionGate:
    ARTIFACT = re.compile(r"\b(created|wrote|saved|generated|file|\.py|\.md|\.json)\b", re.I)
    SERVICE = re.compile(r"\b(listening|server|daemon|port|endpoint|service)\b", re.I)
    IMPLEMENTATION = re.compile(r"\b(implemented|fixed|changed|patched|tests? pass|verified)\b", re.I)

    @classmethod
    def classify(cls, answer: str, diff: Mapping[str, Any] | None) -> str:
        if (diff or {}).get("ops") or cls.ARTIFACT.search(answer or ""):
            return "artifact"
        if cls.SERVICE.search(answer or ""):
            return "service"
        if cls.IMPLEMENTATION.search(answer or ""):
            return "implementation"
        return "statement"

    @staticmethod
    def _test_statuses(traces: Iterable[Mapping[str, Any]]) -> tuple[int, ...]:
        out=[]
        for item in traces or []:
            if isinstance(item, Mapping) and item.get("kind") == "test_result":
                data=item.get("data", {})
                if isinstance(data, Mapping) and isinstance(data.get("status"), int): out.append(data["status"])
        return tuple(out)

    def check(self, *, answer: str, diff: Mapping[str, Any] | None, traces: Iterable[Mapping[str, Any]], verification: Mapping[str, Any] | None) -> CompletionGateResult:
        status=str((verification or {}).get("status", "not_verified"))
        claim=self.classify(answer, diff)
        reasons=[]
        ops=(diff or {}).get("ops", []) if isinstance(diff, Mapping) else []
        tests=self._test_statuses(traces)
        if status in {"pass", "verified"}:
            if claim == "artifact" and not ops:
                reasons.append("artifact/file claim requires a diff or existence evidence")
            if claim == "implementation" and not any(s == 0 for s in tests) and not ops:
                reasons.append("implementation claim requires passing behavior evidence or a patch diff")
            if claim == "service":
                # Chimera currently has no service-liveness evidence class in run traces.
                reasons.append("service/liveness claim requires curl/nc/lsof-style liveness evidence")
        if status in {"partial", "partially_verified"} and not (verification or {}).get("known_risks"):
            # Do not fail existing partial verifier rows hard, but surface the honest-risk requirement.
            reasons.append("partial verification should list known_risks")
        return CompletionGateResult(not reasons, status, claim, tuple(reasons), challenge_limit_reached=bool(reasons))
