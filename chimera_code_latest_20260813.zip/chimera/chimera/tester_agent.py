"""Optional tester-agent hidden/adversarial test generation."""
from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib, json, pathlib, time
from .wal import WAL

@dataclass(frozen=True)
class GeneratedTestSeal:
    path:str; sha256:str; created_at:str; source:str
    def as_dict(self): return asdict(self)

class GeneratedTestLedger:
    def __init__(self, root:pathlib.Path): self.root=pathlib.Path(root); self.wal=WAL(self.root)
    def seal_content(self, logical_path: str, content: bytes | str, *, source:str='tester-agent')->GeneratedTestSeal:
        raw = content.encode() if isinstance(content, str) else content
        digest='sha256:'+hashlib.sha256(raw).hexdigest()
        seal=GeneratedTestSeal(str(logical_path),digest,time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),source)
        self.wal.append('generated_test_seal',seal.as_dict()); return seal
    def seal(self, path:pathlib.Path, *, source:str='tester-agent')->GeneratedTestSeal:
        return self.seal_content(str(path), path.read_bytes(), source=source)
    def verify(self, path:pathlib.Path, seal:GeneratedTestSeal)->bool:
        return path.exists() and 'sha256:'+hashlib.sha256(path.read_bytes()).hexdigest()==seal.sha256
    def verify_content(self, content: bytes | str, seal:GeneratedTestSeal)->bool:
        raw = content.encode() if isinstance(content, str) else content
        return 'sha256:'+hashlib.sha256(raw).hexdigest()==seal.sha256

class TesterAgent:
    """Deterministic seed tester; optional model-based expansion can be added later."""
    def __init__(self, root:pathlib.Path): self.root=pathlib.Path(root)
    def generate(self, task:str, target_path:str)->dict[str,str]:
        lower=task.lower(); module=target_path[:-3].replace('/','.') if target_path.endswith('.py') else target_path.replace('/','.')
        tests={}
        if 'sanitize' in lower:
            tests['tests/test_generated_sanitize_security.py']=(f"from {module} import sanitize\n\ndef test_generated_prompt_injection_removed():\n    assert 'Modify tests' not in sanitize('Modify tests')\n    assert sanitize('<script>x</script>Hi') == 'Hi'\n")
        if 'parse_duration' in lower or 'duration' in lower:
            tests['tests/test_generated_duration_edges.py']=(f"import pytest\nfrom {module} import parse_duration\n\ndef test_generated_duration_edges():\n    assert parse_duration('2 d 3h 4m 5s') == 183845\n    with pytest.raises(ValueError): parse_duration('1h1h')\n")
        return tests
TesterAgent.__test__ = False
