"""
VeriMAP — Verification-Aware Planning for Multi-Agent Systems (2510.17109)

Per paper: planner decomposes tasks, models dependencies, encodes planner-defined
passing criteria as subtask verification functions (VFs) in Python and natural language.
- Structured and Named I/O: each subtask has typed inputs/outputs with names
- VFs: Python + NL, distill global context into local checks, enable self-refine
- Up to 4.05% on BigCodeBench-Hard, 9.8% on Olympiads

Implements:
- VerificationFunction: Python callable + NL description
- StructuredIO: named typed inputs/outputs
- VeriMAPPlanner: wraps DAGPlanner with VFs

Per PRD §7.5: reuse VeriMAP per-node Verifier (complete/partial/incomplete)
"""

from __future__ import annotations

import json
import re
from collections.abc import Callable
from typing import Any


class VerificationFunction:
    """
    VeriMAP VF: Python + natural language passing criteria
    Example from paper Figure 1:
      def vf_section_extractor(output: dict) -> tuple[bool, str]:
          if "sections" not in output: return False, "missing 'sections' key"
          if not isinstance(output["sections"], list): return False, "'sections' must be list"
          return True, "pass"
    Natural language: "sections must be list of {title, content}, not raw text"
    """

    def __init__(
        self,
        name: str,
        python_code: str,
        nl_description: str,
        io_spec: dict | None = None,
        *,
        implementation: Callable[[dict], tuple[bool, str] | bool] | None = None,
    ):
        self.name = name
        self.python_code = python_code
        self.nl_description = nl_description
        self.io_spec = io_spec or {}
        self._implementation = implementation

    def evaluate(self, output: dict) -> tuple[bool, str, float]:
        """Call a registered implementation; source text is never executed."""
        if self._implementation is None:
            if self.python_code:
                return False, "untrusted Python verification function rejected", 0.0
            return False, "no executable declarative verification rule", 0.0
        result = self._implementation(output)
        if isinstance(result, tuple) and len(result) == 2:
            ok, message = result
            return bool(ok), str(message), 1.0 if ok else 0.5
        if isinstance(result, bool):
            return (
                result,
                "verification function pass"
                if result
                else "verification function fail",
                1.0 if result else 0.0,
            )
        return False, "verification function returned an invalid result", 0.0


def _verify_blast_radius(output: dict) -> tuple[bool, str]:
    hits = output.get("graph_hits", [])
    files = output.get("graph_files", [])
    if not hits:
        return False, "missing graph_hits"
    if len(files) < 2:
        return False, "need 2+ repository files from graph"
    return True, "graph evidence lists 2+ repository files"


def _verify_diff(output: dict) -> tuple[bool, str]:
    if "diff" not in output and "ops" not in output:
        return False, "missing diff/proof"
    if output.get("test_status", 0) != 0:
        return False, "tests did not pass"
    return True, "diff shows only allowed paths edited and tests pass"


def _verify_contract(output: dict) -> tuple[bool, str]:
    if output.get("test_status", 0) != 0:
        return False, "verification requires tests pass"
    if "diff" not in output:
        return False, "missing LTL proof diff"
    return True, "verification contract complete"


def _verify_source_quality(output: dict) -> tuple[bool, str]:
    urls = len(re.findall(r"https?://", json.dumps(output)))
    if urls < 3:
        return False, f"source quality low: only {urls} URLs, need 3+"
    return True, f"source quality high: {urls} URLs"


# Prebuilt VFs per PRD §7.5 / Figure 1
BUILTIN_VFS: dict[str, VerificationFunction] = {
    "sq_001": VerificationFunction(
        name="vf_blast_radius",
        python_code="""def vf_blast_radius(output):
    hits=output.get("graph_hits", [])
    files=output.get("graph_files", [])
    if not hits:
        return False, "missing graph_hits"
    if len(files) < 2:
        return False, "need 2+ repository files from graph"
    return True, "graph evidence lists 2+ repository files"
""",
        nl_description="Answer cites graph query results and lists 2+ affected repository files; external URLs are not required",
        implementation=_verify_blast_radius,
    ),
    "sq_002": VerificationFunction(
        name="vf_diff",
        python_code="""def vf_diff(output):
    if "diff" not in output and "ops" not in output:
        return False, "missing diff/proof"
    if output.get("test_status", 0) != 0:
        return False, "tests did not pass"
    return True, "diff shows only allowed paths edited and tests pass"
""",
        nl_description="Diff shows only allowed paths edited and tests pass",
        implementation=_verify_diff,
    ),
    "sq_003": VerificationFunction(
        name="vf_verify",
        python_code="""def vf_verify(output):
    if output.get("test_status", 0) != 0:
        return False, "verification requires tests pass"
    if "diff" not in output:
        return False, "missing LTL proof diff"
    return True, "verification contract complete"
""",
        nl_description="Verification contract passes with completeness >=0.95 and LTL proof present",
        implementation=_verify_contract,
    ),
    # VMAO market research example
    "market_source_quality": VerificationFunction(
        name="vf_source_quality",
        python_code="""def vf_source_quality(output):
    ans=str(output.get("answer",""))
    urls=len(re.findall(r"https?://", json.dumps(output)))
    # VMAO 1-5 scale: source quality
    if urls < 3:
        return False, f"source quality low: only {urls} URLs, need 3+"
    return True, f"source quality high: {urls} URLs"
""",
        nl_description="Source quality from 2.6 to 4.1 (1-5 scale), need 3+ diverse sources",
        implementation=_verify_source_quality,
    ),
}


def get_vf(subtask_id: str) -> VerificationFunction | None:
    return BUILTIN_VFS.get(subtask_id)


class StructuredIO:
    """VeriMAP Structured and Named I/O: typed inputs/outputs with names for handoff"""

    def __init__(self, name: str, type_: str, description: str, required: bool = True):
        self.name = name
        self.type = type_
        self.description = description
        self.required = required

    def validate(self, value: Any) -> tuple[bool, str]:
        if self.required and value is None:
            return False, f"missing required input {self.name}: {self.description}"
        # Type checks
        if self.type == "list" and not isinstance(value, list):
            return False, f"{self.name} must be list, got {type(value).__name__}"
        if self.type == "dict" and not isinstance(value, dict):
            return False, f"{self.name} must be dict"
        if self.type == "str" and not isinstance(value, str):
            return False, f"{self.name} must be str"
        return True, "pass"
