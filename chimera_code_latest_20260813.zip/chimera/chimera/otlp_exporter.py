"""OTLP exporter using Chimera's explicit telemetry outbox and egress policy."""
from __future__ import annotations

import json
import os
import pathlib
from urllib.parse import urlparse
from typing import Any

from .bootstrap import ProfileEgressPolicy, profile_policy
from .config import DeploymentProfile
from .event_sink import EventSink, TelemetryOutboxExporter
from .otel_mapping import telemetry_snapshot_to_otel_resource


class OTLPTelemetryExporter:
    def __init__(self, root: pathlib.Path, endpoint: str):
        self.root = pathlib.Path(root).resolve()
        self.endpoint = endpoint

    def _egress(self):
        parsed = urlparse(self.endpoint)
        host = (parsed.hostname or "").lower().rstrip(".")
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        # The endpoint was explicitly named by the operator for this exporter.
        # Permit its loopback port for local collector tests while retaining the
        # common egress host/IP policy for non-loopback targets.
        return ProfileEgressPolicy(
            profile_policy(DeploymentProfile.DEV_EXTERNAL),
            allowed_hosts={host},
            offline_loopback_ports={port},
        )

    def queue(self) -> dict[str, Any]:
        payload = telemetry_snapshot_to_otel_resource(self.root)
        outbox = self.root / ".chimera" / "telemetry-outbox.jsonl"
        outbox.parent.mkdir(parents=True, exist_ok=True)
        row = {
            "id": "otlp:" + os.urandom(8).hex(),
            "kind": "otlp.export",
            "target": self.endpoint,
            "attempts": 0,
            "data": payload,
        }
        EventSink._append(outbox, row, max_bytes=10_000_000)
        return {"queued": True, "target_host": urlparse(self.endpoint).hostname, "spans": len(payload.get("scopeSpans", [{}])[0].get("spans", [])), "raw_endpoint_returned": False}

    def drain(self, *, limit: int = 100) -> dict[str, int]:
        return TelemetryOutboxExporter(self.root, egress=self._egress()).drain(limit=limit)
