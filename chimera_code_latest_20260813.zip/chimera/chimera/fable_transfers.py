"""High-confidence transfers from analyzed Fable-style harnesses."""
from __future__ import annotations
import hashlib,json,re
from dataclasses import dataclass,field
from typing import Iterable

@dataclass
class EvidenceCard:
 id:str;intent:str;acceptance:str;status:str='open';evidence:tuple[str,...]=()
class EvidenceLedger:
 def __init__(self,cards:Iterable[EvidenceCard]=()):self.cards={c.id:c for c in cards}
 def close(self,card_id:str,evidence:Iterable[str]):
  card=self.cards[card_id];refs=tuple(evidence)
  if not refs:raise ValueError('cannot close a card without concrete evidence')
  card.status='done';card.evidence=refs
 def open(self):return [c for c in self.cards.values() if c.status=='open']

@dataclass(frozen=True)
class FailureEscalation:
 signature:str;streak:int;action:str
class FailureStreakEscalator:
 def __init__(self,limit:int=3):self.limit=max(2,limit);self.last='';self.streak=0
 def observe(self,error:str)->FailureEscalation|None:
  sig='sha256:'+hashlib.sha256(error[:2000].encode()).hexdigest()
  self.streak=self.streak+1 if sig==self.last else 1;self.last=sig
  if self.streak>=self.limit:return FailureEscalation(sig,self.streak,'stop retrying this layer; inspect assumptions, state, or route')
  return None

class TestIntegrityGuard:
 @staticmethod
 def snapshot(paths:dict[str,str])->dict[str,str]:return {p:'sha256:'+hashlib.sha256(v.encode()).hexdigest() for p,v in paths.items()}
 @staticmethod
 def unchanged(before:dict[str,str],after:dict[str,str])->bool:return before==TestIntegrityGuard.snapshot(after)

class TestAntiGamingGuard:
 """Block only high-confidence test weakening, not legitimate new coverage."""
 SKIP_MARKERS=("pytest.mark.skip", "pytest.skip(", "unittest.skip(", "@skip")
 HARNESS_FILES=("conftest.py", "pytest.ini", "tox.ini", ".mocharc.js", ".mocharc.json", "jest.config.js", "jest.config.ts")
 @classmethod
 def is_harness_file(cls,path:str)->bool:
  normal=path.replace('\\','/').lower();name=normal.rsplit('/',1)[-1]
  return name in cls.HARNESS_FILES or name=="pyproject.toml"
 @classmethod
 def validate(cls,path:str,before:str,after:str)->list[str]:
  if not path.replace('\\','/').startswith('tests/') or not before:return []
  errors=[];lower_before=before.lower();lower_after=after.lower()
  for marker in cls.SKIP_MARKERS:
   if marker in lower_after and marker not in lower_before:errors.append(f"{path}: new test skip marker is forbidden without explicit human review")
  if re.search(r"^\s*assert\s+true\s*(?:#.*)?$",after,re.I|re.M) and not re.search(r"^\s*assert\s+true\s*(?:#.*)?$",before,re.I|re.M):errors.append(f"{path}: new unconditional assert True weakens test evidence")
  before_asserts=len(re.findall(r"^\s*assert\s+",before,re.M));after_asserts=len(re.findall(r"^\s*assert\s+",after,re.M))
  if before_asserts and after_asserts==0:errors.append(f"{path}: removed all assertions from an existing test module")
  return errors

@dataclass(frozen=True)
class ReviewFinding:
 title:str;failure_scenario:str;invariant:str;evidence:tuple[str,...]
 def valid(self)->bool:return bool(self.title and self.failure_scenario and self.invariant and self.evidence)
