"""Local attenuating capability tokens for delegated agent/harness work."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import time
import uuid
from typing import Iterable


@dataclass(frozen=True)
class CapabilityToken:
    id: str
    parent_id: str | None
    principal: str
    task_hash: str
    operations: tuple[str, ...]
    path_scope: tuple[str, ...]
    network_scope: tuple[str, ...]
    max_cost: float
    expires_at: float
    delegation_depth: int
    nonce: str

    def digest(self) -> str:
        raw = json.dumps(asdict(self), sort_keys=True, separators=(",", ":")).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()


def mint_capability(*, principal: str, task_hash: str, operations: Iterable[str], path_scope: Iterable[str] = (), network_scope: Iterable[str] = (), max_cost: float = 0.0, ttl_seconds: float = 300.0, delegation_depth: int = 0) -> CapabilityToken:
    if not principal or not task_hash or ttl_seconds <= 0 or max_cost < 0 or delegation_depth < 0:
        raise ValueError("invalid capability token fields")
    return CapabilityToken(
        "cap:" + uuid.uuid4().hex, None, principal, task_hash,
        tuple(sorted(dict.fromkeys(map(str, operations)))), tuple(sorted(dict.fromkeys(map(str, path_scope)))),
        tuple(sorted(dict.fromkeys(map(str, network_scope)))), float(max_cost), time.time() + ttl_seconds,
        int(delegation_depth), uuid.uuid4().hex,
    )


def attenuate(parent: CapabilityToken, *, principal: str, operations: Iterable[str], path_scope: Iterable[str], network_scope: Iterable[str], max_cost: float, ttl_seconds: float) -> CapabilityToken:
    ops, paths, network = tuple(sorted(set(map(str, operations)))), tuple(sorted(set(map(str, path_scope)))), tuple(sorted(set(map(str, network_scope))))
    if not set(ops) <= set(parent.operations) or not set(paths) <= set(parent.path_scope) or not set(network) <= set(parent.network_scope):
        raise PermissionError("delegated capability may attenuate but never broaden scope")
    if max_cost > parent.max_cost or ttl_seconds <= 0 or time.time() + ttl_seconds > parent.expires_at or parent.delegation_depth <= 0:
        raise PermissionError("delegated capability exceeds parent cost, lifetime, or delegation depth")
    return CapabilityToken(
        "cap:" + uuid.uuid4().hex, parent.id, principal, parent.task_hash, ops, paths, network,
        float(max_cost), time.time() + ttl_seconds, parent.delegation_depth - 1, uuid.uuid4().hex,
    )


def valid(token: CapabilityToken, *, now: float | None = None) -> bool:
    return bool(token.operations) and (now or time.time()) < token.expires_at
