"""Unified local telemetry/observability snapshot for users and agents."""
from __future__ import annotations

import json
import pathlib
import time
from collections import Counter, defaultdict
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .provider_report import ProviderSystemReporter
from .wal import WAL


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class TelemetrySnapshot(_Frozen):
    schema_version: str = "chimera.telemetry-snapshot.v1"
    root: str
    generated_at: float = Field(default_factory=time.time)
    redaction: str = "No raw prompts, provider keys, endpoint URLs, or large payload bodies are included. Use artifact refs for payload drill-down."
    wal: dict[str, Any]
    events: dict[str, Any]
    providers: dict[str, Any]
    latency_ms_by_kind: dict[str, dict[str, float | int | None]]
    token_usage: dict[str, int]
    wire_codec: dict[str, Any]
    sandbox: dict[str, Any]
    self_improvement: dict[str, Any]
    cloud_runtime: dict[str, Any]
    recommendations: tuple[str, ...]


def _percentile(values: list[float], p: float) -> float | None:
    if not values:
        return None
    values = sorted(values)
    index = min(len(values) - 1, max(0, int(len(values) * p) - 1))
    return round(values[index], 3)


def _load_jsonl(path: pathlib.Path, *, limit: int = 10000) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines()[-limit:]:
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            rows.append({"kind": "invalid-json", "data": {}})
    return rows


def _artifact(root: pathlib.Path, name: str) -> dict[str, Any]:
    path = root / "artifacts" / name
    if not path.exists():
        return {"present": False}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return {"present": True, **{key: value.get(key) for key in ("schema_version", "all_passed", "certified", "mirror_only", "production_replacement_authorized", "live_calls_attempted", "any_live_capability_proved", "doctor_certified")}}
    except Exception as exc:
        return {"present": True, "error": type(exc).__name__}


class TelemetrySnapshotBuilder:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def build(self, *, model: str = "*", recent: int = 200) -> TelemetrySnapshot:
        wal_entries = WAL(self.root).replay()
        kinds = Counter(str(row.get("kind")) for row in wal_entries)
        recent_rows = wal_entries[-max(1, int(recent)):]
        latencies: dict[str, list[float]] = defaultdict(list)
        token_usage = Counter()
        sandbox_total = Counter()
        for row in wal_entries:
            data = row.get("data", {}) if isinstance(row.get("data"), dict) else {}
            kind = str(row.get("kind"))
            for key in ("duration_ms", "latency_ms", "model_ms", "tool_ms", "client_overhead_ms"):
                value = data.get(key)
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    latencies[f"{kind}.{key}"].append(float(value))
            usage_sources = [data]
            if isinstance(data.get("usage"), dict):
                usage_sources.append(data["usage"])
            for usage in usage_sources:
                for key in ("tokens", "total_tokens", "input_tokens", "output_tokens", "prompt_tokens", "completion_tokens", "cache_read_tokens"):
                    value = usage.get(key) if isinstance(usage, dict) else None
                    if isinstance(value, (int, float)) and not isinstance(value, bool):
                        token_usage[key] += int(value)
            evidence = data.get("evidence") if isinstance(data.get("evidence"), dict) else {}
            if evidence:
                sandbox_total["executions"] += int(bool(evidence.get("executed")))
                sandbox_total["bubblewrap"] += int(evidence.get("backend") == "bubblewrap")
                sandbox_total["timeouts"] += int(bool(evidence.get("timeout")))
        latency_summary = {
            key: {
                "count": len(values),
                "p50": _percentile(values, 0.50),
                "p95": _percentile(values, 0.95),
                "max": round(max(values), 3) if values else None,
            }
            for key, values in sorted(latencies.items())
        }
        events = _load_jsonl(self.root / ".chimera" / "events.jsonl")
        event_kinds = Counter(str(row.get("kind")) for row in events)
        provider_report = ProviderSystemReporter(self.root).build(model=model).model_dump(mode="json")
        wire_rows = [row.get("data", {}) for row in wal_entries if row.get("kind") in {"wire_codec", "wire_codec_graph"}]
        wire_reductions = [float(row.get("reduction")) for row in wire_rows if isinstance(row.get("reduction"), (int, float))]
        recommendations = []
        if provider_report["summary"].get("configured", 0) == 0:
            recommendations.append("No provider credentials configured; live capability canaries cannot run.")
        if not (_artifact(self.root, "cloud_runtime_smoke_campaign_2026-08-11.json").get("all_passed")):
            recommendations.append("Run cloud_runtime_smoke_campaign.py or configure persistent cloud-runtime endpoints.")
        if not wire_reductions:
            recommendations.append("No wire-codec WAL rows yet; use graph/MCP/CLI wire surfaces to observe token reductions during agent runs.")
        return TelemetrySnapshot(
            root=str(self.root),
            wal={
                "entries": len(wal_entries),
                "kinds": dict(kinds),
                "recent": recent_rows,
            },
            events={"entries": len(events), "kinds": dict(event_kinds)},
            providers=provider_report["summary"],
            latency_ms_by_kind=latency_summary,
            token_usage=dict(token_usage),
            wire_codec={
                "observations": len(wire_rows),
                "average_reduction": round(sum(wire_reductions) / len(wire_reductions), 4) if wire_reductions else None,
                "gcf_campaign": _artifact(self.root, "gcf_wire_campaign_2026-08-11.json"),
            },
            sandbox=dict(sandbox_total),
            self_improvement=_artifact(self.root, "self_improvement_gauntlet_plan_2026-08-11.json"),
            cloud_runtime=_artifact(self.root, "cloud_runtime_smoke_campaign_2026-08-11.json"),
            recommendations=tuple(recommendations),
        )
