"""Evidence-backed contextual capability calibration for agent/model routing."""
from __future__ import annotations
import hashlib,json,math,pathlib,sqlite3,threading,time
from typing import Any,Iterable,Mapping,Optional
from pydantic import BaseModel,ConfigDict,Field
from .wal import WAL, wal_write

class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
class CapabilityPosterior(FrozenModel):
    agent_id:str;skill:str;context_bucket:str;alpha:float;beta:float;samples:int;mean:float;stddev:float;lcb:float;mean_latency_ms:float;mean_cost:float
class CapabilityChoice(FrozenModel):
    agent_id:str;score:float;posterior:CapabilityPosterior;reason:str

_SCHEMA="""
CREATE TABLE IF NOT EXISTS capability_posterior(agent_id TEXT NOT NULL,skill TEXT NOT NULL,context_bucket TEXT NOT NULL,alpha REAL NOT NULL,beta REAL NOT NULL,successes INTEGER NOT NULL,failures INTEGER NOT NULL,latency_sum REAL NOT NULL,cost_sum REAL NOT NULL,updated_at TEXT NOT NULL,PRIMARY KEY(agent_id,skill,context_bucket));
"""
class ContextualCapabilityRegistry:
    """Hierarchical Beta posteriors; updates require external evidence references."""
    def __init__(self,root:pathlib.Path,prior_alpha:float=1.0,prior_beta:float=1.0):
        self.root=pathlib.Path(root).resolve();self.path=self.root/".chimera"/"capability.sqlite";self.path.parent.mkdir(parents=True,exist_ok=True);self.db=sqlite3.connect(self.path,check_same_thread=False);self.db.executescript(_SCHEMA);self.prior_alpha=max(.01,float(prior_alpha));self.prior_beta=max(.01,float(prior_beta));self.lock=threading.RLock();self.wal=WAL(self.root)
    def close(self):self.db.close()
    @staticmethod
    def bucket(features:Mapping[str,Any])->str:
        canonical=json.dumps(dict(features),sort_keys=True,separators=(",",":"),default=str)
        return "ctx:"+hashlib.sha256(canonical.encode()).hexdigest()[:16]
    def _row(self,agent:str,skill:str,bucket:str):
        return self.db.execute("SELECT alpha,beta,successes,failures,latency_sum,cost_sum FROM capability_posterior WHERE agent_id=? AND skill=? AND context_bucket=?",(agent,skill,bucket)).fetchone()
    def _upsert(self,agent,skill,bucket,success,latency,cost):
        row=self._row(agent,skill,bucket)
        if row:a,b,s,f,ls,cs=row
        else:a,b,s,f,ls,cs=self.prior_alpha,self.prior_beta,0,0,0.,0.
        a+=1 if success else 0;b+=0 if success else 1;s+=1 if success else 0;f+=0 if success else 1;ls+=max(0.,latency);cs+=max(0.,cost)
        self.db.execute("INSERT INTO capability_posterior VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(agent_id,skill,context_bucket) DO UPDATE SET alpha=excluded.alpha,beta=excluded.beta,successes=excluded.successes,failures=excluded.failures,latency_sum=excluded.latency_sum,cost_sum=excluded.cost_sum,updated_at=excluded.updated_at",(agent,skill,bucket,a,b,s,f,ls,cs,time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())))
    def update(self,agent_id:str,skill:str,features:Mapping[str,Any],*,success:bool,latency_ms:float=0.,cost:float=0.,evidence_refs:Iterable[str]):
        evidence=tuple(evidence_refs)
        if not evidence:raise ValueError("capability update requires evidence refs")
        bucket=self.bucket(features)
        with self.lock,self.db:
            for agent,sk,ctx in ((agent_id,skill,bucket),(agent_id,skill,"*"),(agent_id,"*","*")):
                self._upsert(agent,sk,ctx,success,float(latency_ms),float(cost))
        wal_write(self.wal, "capability_observation",{"agent_id":agent_id,"skill":skill,"context_bucket":bucket,"success":bool(success),"latency_ms":max(0.,float(latency_ms)),"cost":max(0.,float(cost)),"evidence_root":"sha256:"+hashlib.sha256(json.dumps(sorted(evidence)).encode()).hexdigest()})
    def update_verification_calibration(self, branch:str, *, grader_pass:bool, held_out_pass:bool|None, downstream_accepted:bool, evidence_refs:Iterable[str])->None:
        """Meta-critic feedback bucket for verification confidence calibration.

        The posterior is keyed as skill='verification_calibration'.  Callers can
        wait for >=30 samples before trusting it for routing; this method only
        records the evidence-backed observation.
        """
        features={"branch":branch,"grader_pass":bool(grader_pass),"held_out_known":held_out_pass is not None}
        self.update(agent_id="verification_tier",skill="verification_calibration",features=features,success=bool(downstream_accepted),evidence_refs=evidence_refs)

    def posterior(self,agent_id:str,skill:str,features:Mapping[str,Any],z:float=1.0)->CapabilityPosterior:
        bucket=self.bucket(features);row=None;used=bucket
        for sk,ctx in ((skill,bucket),(skill,"*"),("*","*")):
            row=self._row(agent_id,sk,ctx)
            if row:used=ctx;break
        if row:a,b,s,f,ls,cs=row
        else:a,b,s,f,ls,cs=self.prior_alpha,self.prior_beta,0,0,0.,0.
        n=s+f;mean=a/(a+b);variance=(a*b)/(((a+b)**2)*(a+b+1));std=math.sqrt(variance);lcb=max(0.,mean-max(0.,z)*std)
        return CapabilityPosterior(agent_id=agent_id,skill=skill,context_bucket=used,alpha=a,beta=b,samples=n,mean=mean,stddev=std,lcb=lcb,mean_latency_ms=ls/max(1,n),mean_cost=cs/max(1,n))
    def choose(self,agent_ids:Iterable[str],skill:str,features:Mapping[str,Any],*,task_value:float=1.,latency_weight:float=0.,cost_weight:float=0.,uncertainty_z:float=1.)->CapabilityChoice:
        choices=[]
        for agent in agent_ids:
            post=self.posterior(agent,skill,features,z=uncertainty_z);score=post.lcb*float(task_value)-float(latency_weight)*post.mean_latency_ms-float(cost_weight)*post.mean_cost
            choices.append((score,agent,post))
        if not choices:raise ValueError("agent pool is empty")
        score,agent,post=max(choices,key=lambda item:(item[0],item[1]))
        return CapabilityChoice(agent_id=agent,score=score,posterior=post,reason="risk-adjusted contextual Beta lower confidence bound minus measured latency/cost")
