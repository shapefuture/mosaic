"""Continual Harness state: reviewable supplemental refinements with rollback.

The immutable base system prompt is never rewritten. Refinements are scoped to
supplemental prompts, curated memories, skill descriptors, and subagent specs.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import time
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

from .drift import CuratorGate
from .memory_hygiene import PersistentLessonGate
from .wal import WAL


Surface = Literal["prompt", "memory", "skill", "subagent"]


class Refinement(BaseModel):
    surface: Surface
    key: str
    content: Any
    reason: str
    evidence_refs: List[str] = Field(default_factory=list)
    confidence: float = 0.5


class HarnessRevision(BaseModel):
    id: str
    parent: Optional[str] = None
    namespace: str
    created_at: str
    base_prompt_hash: str
    supplemental_prompts: Dict[str, str] = Field(default_factory=dict)
    memories: Dict[str, Dict[str, Any]] = Field(default_factory=dict)
    skills: Dict[str, Dict[str, Any]] = Field(default_factory=dict)
    subagents: Dict[str, Dict[str, Any]] = Field(default_factory=dict)
    evidence: Dict[str, Any] = Field(default_factory=dict)


class ContinualHarness:
    """Session-local by default, evidence-backed, snapshot-addressed state."""

    def __init__(self, root: pathlib.Path, namespace: str = "default", base_prompt: str = "chimera-base-v1"):
        self.root = pathlib.Path(root).resolve()
        self.namespace = namespace
        self.base_prompt_hash = hashlib.sha256(base_prompt.encode()).hexdigest()
        self.dir = self.root / ".chimera" / "continual" / namespace
        self.revisions_dir = self.dir / "revisions"
        self.head_path = self.dir / "HEAD"
        self.revisions_dir.mkdir(parents=True, exist_ok=True)
        self.curator = CuratorGate(self.root)
        self.lesson_gate = PersistentLessonGate()
        self.wal = WAL(self.root)
        if not self.head_path.exists():
            initial = HarnessRevision(
                id="", namespace=namespace,
                created_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                base_prompt_hash=self.base_prompt_hash,
                evidence={"kind": "genesis"},
            )
            self._persist(initial, parent=None, event="continual_genesis")

    @staticmethod
    def _revision_id(payload: Dict[str, Any]) -> str:
        return "harness:" + hashlib.sha256(
            json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()

    def _persist(self, revision: HarnessRevision, parent: Optional[str], event: str) -> HarnessRevision:
        data = revision.model_dump(exclude={"id"})
        data["parent"] = parent
        revision.id = self._revision_id(data)
        revision.parent = parent
        path = self.revisions_dir / f"{revision.id.replace(':', '-')}.json"
        path.write_text(revision.model_dump_json(indent=2))
        temp = self.head_path.with_suffix(".tmp")
        temp.write_text(revision.id)
        temp.replace(self.head_path)
        self.wal.append(event, {
            "namespace": self.namespace, "revision": revision.id,
            "parent": parent, "base_prompt_hash": revision.base_prompt_hash,
        })
        return revision

    def get(self, revision_id: Optional[str] = None) -> HarnessRevision:
        revision_id = revision_id or self.head_path.read_text().strip()
        path = self.revisions_dir / f"{revision_id.replace(':', '-')}.json"
        if not path.exists():
            raise KeyError(f"unknown harness revision {revision_id}")
        revision = HarnessRevision.model_validate_json(path.read_text())
        if revision.base_prompt_hash != self.base_prompt_hash:
            raise RuntimeError("base prompt hash mismatch: immutable base changed")
        return revision

    def history(self) -> List[HarnessRevision]:
        output = []
        current = self.get()
        while current:
            output.append(current)
            if not current.parent:
                break
            current = self.get(current.parent)
        return output

    def refine(self, proposals: List[Refinement], evidence: Dict[str, Any],
               require_evidence: bool = True) -> Dict[str, Any]:
        current = self.get()
        next_revision = current.model_copy(deep=True)
        next_revision.created_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        next_revision.evidence = evidence
        accepted, rejected = [], []

        if require_evidence and not evidence:
            return {"accepted": [], "rejected": [{"reason": "evidence required"}], "revision": current.id}

        existing_memories = [str(item.get("content", "")) for item in current.memories.values()]
        for proposal in proposals:
            if not proposal.key or proposal.confidence < 0.5:
                rejected.append({"key": proposal.key, "reason": "invalid key or confidence below 0.5"})
                continue
            if require_evidence and not proposal.evidence_refs:
                rejected.append({"key": proposal.key, "reason": "proposal has no evidence refs"})
                continue
            if proposal.surface == "prompt":
                next_revision.supplemental_prompts[proposal.key] = str(proposal.content)
            elif proposal.surface == "memory":
                lesson = self.lesson_gate.assess(str(proposal.content))
                if not lesson.allowed:
                    rejected.append({"key": proposal.key, "reason": lesson.reason})
                    continue
                allowed, reason = self.curator.filter_insertion(str(proposal.content), existing_memories)
                if not allowed:
                    rejected.append({"key": proposal.key, "reason": reason})
                    continue
                next_revision.memories[proposal.key] = {
                    "content": proposal.content, "reason": proposal.reason,
                    "evidence_refs": proposal.evidence_refs, "confidence": proposal.confidence,
                }
                existing_memories.append(str(proposal.content))
            elif proposal.surface == "skill":
                if not isinstance(proposal.content, dict) or "description" not in proposal.content:
                    rejected.append({"key": proposal.key, "reason": "skill requires a descriptor object"})
                    continue
                next_revision.skills[proposal.key] = proposal.content
            elif proposal.surface == "subagent":
                if not isinstance(proposal.content, dict) or "task" not in proposal.content:
                    rejected.append({"key": proposal.key, "reason": "subagent spec requires task"})
                    continue
                next_revision.subagents[proposal.key] = proposal.content
            accepted.append(proposal.model_dump())

        if not accepted:
            return {"accepted": [], "rejected": rejected, "revision": current.id}
        saved = self._persist(next_revision, parent=current.id, event="continual_refine")
        return {"accepted": accepted, "rejected": rejected, "revision": saved.id, "parent": current.id}

    def rollback(self, revision_id: Optional[str] = None, steps: int = 1) -> HarnessRevision:
        current = self.get()
        target = self.get(revision_id) if revision_id else current
        if revision_id is None:
            for _ in range(max(1, steps)):
                if not target.parent:
                    break
                target = self.get(target.parent)
        temp = self.head_path.with_suffix(".tmp")
        temp.write_text(target.id)
        temp.replace(self.head_path)
        self.wal.append("continual_rollback", {
            "namespace": self.namespace, "from": current.id, "to": target.id,
        })
        return target

    def diff(self, left: Optional[str] = None, right: Optional[str] = None) -> Dict[str, Any]:
        right_revision = self.get(right)
        left_revision = self.get(left or right_revision.parent) if (left or right_revision.parent) else right_revision
        fields = ("supplemental_prompts", "memories", "skills", "subagents")
        changes = {}
        for field in fields:
            before = getattr(left_revision, field)
            after = getattr(right_revision, field)
            changes[field] = {
                "added": sorted(set(after) - set(before)),
                "removed": sorted(set(before) - set(after)),
                "changed": sorted(key for key in set(before) & set(after) if before[key] != after[key]),
            }
        return {"from": left_revision.id, "to": right_revision.id, "changes": changes}

    def render_context(self) -> str:
        state = self.get()
        prompts = "\n".join(f"[{key}] {value}" for key, value in state.supplemental_prompts.items())
        memories = "\n".join(f"[{key}] {value.get('content')}" for key, value in state.memories.items())
        return f"# Supplemental harness prompts\n{prompts}\n# Curated memories\n{memories}".strip()
