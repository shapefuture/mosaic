"""One-call, multi-file transaction helper for tightly coupled low-risk changes.

This is intentionally narrower than the DAG: at most four standard-risk targets
must share directly linked acceptance evidence.  It is not a general parallel
planner and it does not commit a branch.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class CohesiveTransactionPolicy:
    max_targets: int = 4
    max_repairs: int = 1

    def validate_targets(self, count: int) -> None:
        if count < 1 or count > self.max_targets:
            raise ValueError(f"cohesive transaction requires 1..{self.max_targets} targets")
