"""Evidence-preserving, tool-aware output projection.

Full bytes always remain in CAS when a prompt preview is shortened.  Read/search
outputs preserve a long head, shell/errors preserve a long tail, and mutation
receipts preserve both ends.  Projection changes context, never evidence.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from typing import Literal, Optional

from .artifacts import ContentAddressedArtifactStore


@dataclass(frozen=True)
class OutputPolicy:
    head_ratio: float
    tail_ratio: float
    direction: Literal["head_tail", "head", "tail"] = "head_tail"


@dataclass(frozen=True)
class ProjectedToolOutput:
    tool: str
    content: str
    truncated: bool
    original_bytes: int
    preview_bytes: int
    omitted_bytes: int
    full_digest: str
    artifact_ref: Optional[dict]
    policy: str
    critical_lines_total: int = 0
    critical_lines_retained: int = 0


class ToolOutputProjector:
    READ_TOOLS = frozenset({"read", "read_file", "grep", "glob", "list_files", "graph_query", "artifact_read"})
    SHELL_TOOLS = frozenset({"bash", "shell", "shell_read", "exec"})
    WRITE_TOOLS = frozenset({"write", "write_file", "edit", "edit_file", "apply_patch"})

    def __init__(self, store: ContentAddressedArtifactStore):
        self.store = store

    @staticmethod
    def policy_for(tool: str, ok: bool) -> OutputPolicy:
        name = (tool or "unknown").lower()
        if not ok:
            return OutputPolicy(0.25, 0.75)
        if name in ToolOutputProjector.READ_TOOLS:
            return OutputPolicy(0.85, 0.15)
        if name in ToolOutputProjector.SHELL_TOOLS:
            return OutputPolicy(0.20, 0.80)
        if name in ToolOutputProjector.WRITE_TOOLS:
            return OutputPolicy(0.50, 0.50)
        return OutputPolicy(0.60, 0.40)

    @staticmethod
    def _prefix_boundary(raw: bytes, end: int) -> int:
        end = min(max(0, end), len(raw))
        while end > 0 and end < len(raw) and (raw[end] & 0xC0) == 0x80:
            end -= 1
        return end

    @staticmethod
    def _suffix_boundary(raw: bytes, start: int) -> int:
        start = min(max(0, start), len(raw))
        while start < len(raw) and (raw[start] & 0xC0) == 0x80:
            start += 1
        return start

    @staticmethod
    def _critical_lines(content: str) -> list[str]:
        """Extract source-visible recovery sentinels before truncation.

        A token preview that loses an error, test result, artifact digest, or
        explicit denial can trigger an expensive incorrect retry.  These lines
        are compact enough to keep verbatim and are more useful than generic
        middle prose.
        """
        pattern = re.compile(r"(?:error|exception|failed|failure|denied|forbidden|assertion|traceback|\b[0-9]+\s+passed\b|artifact:|sha256:)", re.I)
        rows: list[str] = []
        for line in content.splitlines():
            if pattern.search(line):
                # Cap an individual pathological trace line while keeping its
                # beginning and ending identifiers readable.
                value = line if len(line) <= 480 else line[:300] + " … " + line[-160:]
                if value not in rows:
                    rows.append(value)
        return rows[:24]

    def project(
        self,
        *,
        tool: str,
        content: str,
        ok: bool,
        max_bytes: int,
        existing_artifact_ref: Optional[dict] = None,
    ) -> ProjectedToolOutput:
        raw = content.encode()
        digest = "sha256:" + hashlib.sha256(raw).hexdigest()
        budget = max(256, int(max_bytes))
        if len(raw) <= budget:
            return ProjectedToolOutput(
                tool=tool, content=content, truncated=False,
                original_bytes=len(raw), preview_bytes=len(raw), omitted_bytes=0,
                full_digest=digest, artifact_ref=existing_artifact_ref,
                policy="unchanged",
            )
        policy = self.policy_for(tool, ok)
        artifact = existing_artifact_ref
        if artifact is None:
            artifact = self.store.put(
                raw, media_type="text/plain",
                provenance={"kind": "tool-output", "tool": tool, "ok": ok},
            ).to_dict()
        marker = f"\n...[{len(raw)} bytes total; full output artifact:{artifact['digest']}]...\n".encode()
        critical = self._critical_lines(content)
        critical_block = ("\n[critical recovery lines]\n" + "\n".join(critical) + "\n").encode() if critical else b""
        # If essential recovery facts alone cannot fit, preserving a bounded
        # preview would create a false impression that compression was safe.
        # Keep the original result for this turn; quality wins over the budget.
        if critical_block and len(marker) + len(critical_block) >= budget:
            return ProjectedToolOutput(
                tool=tool, content=content, truncated=False,
                original_bytes=len(raw), preview_bytes=len(raw), omitted_bytes=0,
                full_digest=digest, artifact_ref=artifact,
                policy="survival-fallback-uncompressed",
                critical_lines_total=len(critical), critical_lines_retained=len(critical),
            )
        available = max(0, budget - len(marker) - len(critical_block))
        if policy.direction == "head":
            head_bytes, tail_bytes = available, 0
        elif policy.direction == "tail":
            head_bytes, tail_bytes = 0, available
        else:
            total = max(policy.head_ratio + policy.tail_ratio, 1e-9)
            head_bytes = int(available * policy.head_ratio / total)
            tail_bytes = available - head_bytes
        head_end = self._prefix_boundary(raw, head_bytes)
        tail_start = self._suffix_boundary(raw, len(raw) - tail_bytes)
        preview_raw = raw[:head_end] + marker + critical_block + raw[tail_start:]
        preview = preview_raw.decode("utf-8", errors="strict")
        omitted = max(0, tail_start - head_end)
        return ProjectedToolOutput(
            tool=tool, content=preview, truncated=True,
            original_bytes=len(raw), preview_bytes=len(preview_raw), omitted_bytes=omitted,
            full_digest=digest, artifact_ref=artifact,
            policy=f"head={policy.head_ratio:.2f},tail={policy.tail_ratio:.2f},survival={len(critical)}",
            critical_lines_total=len(critical), critical_lines_retained=len(critical),
        )
