"""Ed25519-signed model-context pack roots bound into Chimera's WAL.

Only hashes, sizes, purpose, and public verification material are persisted;
model context and signing private keys never enter the WAL.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import pathlib
import time
from typing import Any, Literal, Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import Encoding, NoEncryption, PrivateFormat, PublicFormat
from pydantic import BaseModel, ConfigDict

from .wal import WAL


class ContextEvidenceError(RuntimeError):
    pass


class ContextSigner:
    def __init__(self, private_key: Ed25519PrivateKey, *, scope: str) -> None:
        self._private_key = private_key
        self.scope = scope
        public = private_key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
        self.public_key = base64.b64encode(public).decode()
        self.key_id = "ed25519:" + hashlib.sha256(public).hexdigest()

    @classmethod
    def generate_ephemeral(cls) -> "ContextSigner":
        return cls(Ed25519PrivateKey.generate(), scope="ephemeral-process")

    @classmethod
    def from_base64_private_key(cls, encoded: str, *, scope: str = "environment-pinned") -> "ContextSigner":
        try:
            raw = base64.b64decode(encoded, validate=True)
            if len(raw) != 32:
                raise ValueError("Ed25519 raw private key must be 32 bytes")
            return cls(Ed25519PrivateKey.from_private_bytes(raw), scope=scope)
        except Exception as exc:
            raise ContextEvidenceError(f"invalid Ed25519 context signing key: {exc}") from exc

    @classmethod
    def from_environment_or_ephemeral(cls) -> "ContextSigner":
        encoded = os.environ.get("CHIMERA_CONTEXT_SIGNING_KEY")
        if encoded:
            return cls.from_base64_private_key(encoded)
        return cls.generate_ephemeral()

    def sign(self, payload: bytes) -> str:
        return base64.b64encode(self._private_key.sign(payload)).decode()

    def private_key_base64_for_test_only(self) -> str:
        raw = self._private_key.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
        return base64.b64encode(raw).decode()


class ContextPackReceipt(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["chimera.context-pack.v1"] = "chimera.context-pack.v1"
    pack_root: str
    content_hash: str
    wire_hash: str
    wire_format: str
    source_bytes: int
    wire_bytes: int
    purpose: str
    model: str
    session: str
    created_at: str
    algorithm: Literal["ed25519"] = "ed25519"
    key_id: str
    public_key: str
    signing_scope: str
    signature: str

    def signed_payload(self) -> dict[str, Any]:
        return self.model_dump(exclude={"signature"})

    @property
    def receipt_hash(self) -> str:
        return _hash(self.model_dump(mode="json"))

    def verify(self) -> bool:
        try:
            public = Ed25519PublicKey.from_public_bytes(base64.b64decode(self.public_key, validate=True))
            key_id = "ed25519:" + hashlib.sha256(base64.b64decode(self.public_key)).hexdigest()
            if key_id != self.key_id:
                return False
            public.verify(
                base64.b64decode(self.signature, validate=True),
                _canonical(self.signed_payload()),
            )
            return True
        except (ValueError, InvalidSignature):
            return False


class ContextEvidenceBinder:
    def __init__(self, root: pathlib.Path, signer: Optional[ContextSigner] = None) -> None:
        self.root = pathlib.Path(root).resolve()
        self.signer = signer or ContextSigner.from_environment_or_ephemeral()
        self.wal = WAL(self.root)

    def _bind(
        self,
        *,
        pack_root: str,
        content_hash: str,
        wire_hash: str,
        wire_format: str,
        source_bytes: int,
        wire_bytes: int,
        purpose: str,
        model: str,
        session: str,
    ) -> ContextPackReceipt:
        unsigned = {
            "schema_version": "chimera.context-pack.v1",
            "pack_root": pack_root,
            "content_hash": content_hash,
            "wire_hash": wire_hash,
            "wire_format": wire_format,
            "source_bytes": source_bytes,
            "wire_bytes": wire_bytes,
            "purpose": purpose,
            "model": model,
            "session": session,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "algorithm": "ed25519",
            "key_id": self.signer.key_id,
            "public_key": self.signer.public_key,
            "signing_scope": self.signer.scope,
        }
        receipt = ContextPackReceipt(**unsigned, signature=self.signer.sign(_canonical(unsigned)))
        if not receipt.verify():
            raise ContextEvidenceError("newly created context receipt failed signature verification")
        self.wal.append("model_context_pack", {
            **receipt.model_dump(mode="json"),
            "receipt_hash": receipt.receipt_hash,
        })
        return receipt

    def bind_text(self, text: str, *, purpose: str, model: str, session: str) -> ContextPackReceipt:
        raw = text.encode()
        digest = "sha256:" + hashlib.sha256(raw).hexdigest()
        return self._bind(
            pack_root=digest,
            content_hash=digest,
            wire_hash=digest,
            wire_format="text",
            source_bytes=len(raw),
            wire_bytes=len(raw),
            purpose=purpose,
            model=model,
            session=session,
        )

    def bind_envelope(self, envelope: Any, *, purpose: str, model: str, session: str) -> ContextPackReceipt:
        wire_text = envelope.model_text()
        wire_hash = "sha256:" + hashlib.sha256(wire_text.encode()).hexdigest()
        pack_root = str(envelope.metadata.get("pack_root") or envelope.content_hash)
        if not pack_root.startswith("sha256:"):
            pack_root = "sha256:" + pack_root
        return self._bind(
            pack_root=pack_root,
            content_hash=str(envelope.content_hash),
            wire_hash=wire_hash,
            wire_format=str(envelope.format),
            source_bytes=int(envelope.source_bytes),
            wire_bytes=int(envelope.wire_bytes),
            purpose=purpose,
            model=model,
            session=session,
        )

    def verify_wal_receipts(self) -> dict[str, Any]:
        rows = self.wal.replay(kind="model_context_pack")
        invalid: list[int] = []
        for entry in rows:
            data = dict(entry.get("data", {}))
            receipt_hash = data.pop("receipt_hash", None)
            try:
                receipt = ContextPackReceipt.model_validate(data)
                if not receipt.verify() or receipt.receipt_hash != receipt_hash:
                    invalid.append(entry["seq"])
            except Exception:
                invalid.append(entry.get("seq", -1))
        return {"valid": not invalid, "receipts": len(rows), "invalid_sequences": invalid}


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()


def _hash(value: Any) -> str:
    return "sha256:" + hashlib.sha256(_canonical(value)).hexdigest()
