"""Cloud/self-hosted deployment blueprints with no embedded secrets."""
from __future__ import annotations

import json
import pathlib
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class DeploymentFile:
    path: str
    content: str
    mode: str = "0644"


class DeploymentBlueprintBuilder:
    """Generate operator-editable deployment skeletons.

    These are blueprints, not a claim that the local host is cloud-certified.
    They intentionally reference environment variable *names* and secret object
    names only; no secret values or provider keys are written.
    """

    def build(self, *, profile: str = "self-hosted-dense") -> dict[str, Any]:
        if profile not in {"self-hosted-dense", "k8s", "edge-notes"}:
            raise ValueError("profile must be self-hosted-dense, k8s, or edge-notes")
        files = self._self_hosted_files() if profile == "self-hosted-dense" else self._k8s_files() if profile == "k8s" else self._edge_notes()
        return {
            "schema_version": "chimera.deployment-blueprint.v1",
            "profile": profile,
            "files": [asdict(f) for f in files],
            "secret_values_recorded": False,
            "required_secret_names": self.required_secret_names(profile),
            "local_mode_preserved": True,
            "promotion_allowed": False,
            "promotion_rule": "Blueprints require operator review, real endpoint smoke tests, and supreme-gate receipts before production certification.",
        }

    def write(self, directory: pathlib.Path, *, profile: str = "self-hosted-dense") -> dict[str, Any]:
        directory = pathlib.Path(directory).resolve()
        plan = self.build(profile=profile)
        written = []
        for item in plan["files"]:
            path = directory / item["path"]
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(item["content"], encoding="utf-8")
            written.append(str(path))
        return {**plan, "written": written}

    @staticmethod
    def required_secret_names(profile: str) -> list[str]:
        common = [
            "CHIMERA_TENANT_SIGNING_KEY",
            "CHIMERA_GUI_TENANT_SIGNING_KEY",
            "TOKENROUTER_API_KEY_or_provider_keys_optional",
        ]
        if profile == "k8s":
            return [*common, "CHIMERA_POSTGRES_URL", "CHIMERA_RESTATE_INGRESS", "OTLP_AUTH_HEADER_optional"]
        if profile == "self-hosted-dense":
            return [*common, "POSTGRES_PASSWORD", "OTLP_AUTH_HEADER_optional"]
        return common

    @staticmethod
    def _self_hosted_files() -> list[DeploymentFile]:
        compose = """services:
  postgres:
    image: postgres:17
    environment:
      POSTGRES_DB: chimera
      POSTGRES_USER: chimera
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:?set in .env, never commit}
    volumes: ["postgres-data:/var/lib/postgresql/data"]
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U chimera"]
      interval: 5s
      timeout: 3s
      retries: 20
  restate:
    image: docker.io/restatedev/restate:latest
    ports: ["8080:8080", "9070:9070"]
  nats:
    image: nats:2-alpine
    command: ["-js", "-sd", "/data"]
    volumes: ["nats-data:/data"]
    ports: ["4222:4222", "8222:8222"]
  chimera:
    image: ${CHIMERA_IMAGE:-chimera:local}
    depends_on:
      postgres: { condition: service_healthy }
      restate: { condition: service_started }
      nats: { condition: service_started }
    environment:
      CHIMERA_POSTGRES_URL: postgresql://chimera:${POSTGRES_PASSWORD}@postgres:5432/chimera
      CHIMERA_RESTATE_INGRESS: http://restate:8080
      CHIMERA_NATS_URL: nats://nats:4222
      CHIMERA_TENANT_SIGNING_KEY: ${CHIMERA_TENANT_SIGNING_KEY:?set in .env, never commit}
      CHIMERA_GUI_TENANT_SIGNING_KEY: ${CHIMERA_GUI_TENANT_SIGNING_KEY:?set in .env, never commit}
      OTEL_EXPORTER_OTLP_ENDPOINT: ${OTEL_EXPORTER_OTLP_ENDPOINT:-}
    ports: ["8766:8766"]
    command: ["python", "-m", "chimera.cli", "gui-serve", "--host", "0.0.0.0", "--port", "8766", "--server", "auto"]
volumes:
  postgres-data: {}
  nats-data: {}
"""
        env = """# Copy to .env and fill locally. Never commit secret values.
POSTGRES_PASSWORD=
CHIMERA_TENANT_SIGNING_KEY=
CHIMERA_GUI_TENANT_SIGNING_KEY=
CHIMERA_IMAGE=chimera:local
OTEL_EXPORTER_OTLP_ENDPOINT=
TOKENROUTER_API_KEY=
"""
        runbook = """# Chimera self-hosted dense runbook

1. Build or pull `CHIMERA_IMAGE`.
2. Fill `.env` locally; do not commit it.
3. Start: `docker compose up -d`.
4. Smoke:
   - `chimera doctor --profile cloud-runtime` inside the Chimera container.
   - `chimera platform cloud-scale-smoke --agents 1000 --tenants 100`.
   - `chimera platform supreme-gate --scan-path /tmp/clean-candidate`.
5. Only enable NATS/gateways/cache profiles after benchmark receipts.
"""
        return [DeploymentFile("docker-compose.yml", compose), DeploymentFile(".env.example", env), DeploymentFile("RUNBOOK.md", runbook)]

    @staticmethod
    def _k8s_files() -> list[DeploymentFile]:
        namespace = """apiVersion: v1
kind: Namespace
metadata:
  name: chimera
"""
        config = """apiVersion: v1
kind: ConfigMap
metadata:
  name: chimera-config
  namespace: chimera
data:
  CHIMERA_RESTATE_INGRESS: "http://restate.chimera.svc.cluster.local:8080"
  CHIMERA_NATS_URL: "nats://nats.chimera.svc.cluster.local:4222"
  OTEL_EXPORTER_OTLP_ENDPOINT: ""
"""
        secret = """apiVersion: v1
kind: Secret
metadata:
  name: chimera-secrets
  namespace: chimera
stringData:
  # Fill with sealed-secrets/external-secrets in production. Do not commit values.
  CHIMERA_POSTGRES_URL: ""
  CHIMERA_TENANT_SIGNING_KEY: ""
  CHIMERA_GUI_TENANT_SIGNING_KEY: ""
  TOKENROUTER_API_KEY: ""
"""
        deploy = """apiVersion: apps/v1
kind: Deployment
metadata:
  name: chimera-api
  namespace: chimera
spec:
  replicas: 3
  selector:
    matchLabels: { app: chimera-api }
  template:
    metadata:
      labels: { app: chimera-api }
    spec:
      containers:
        - name: chimera
          image: ${CHIMERA_IMAGE}
          imagePullPolicy: IfNotPresent
          command: ["python", "-m", "chimera.cli", "gui-serve", "--host", "0.0.0.0", "--port", "8766", "--server", "auto"]
          ports: [{ containerPort: 8766 }]
          envFrom:
            - configMapRef: { name: chimera-config }
            - secretRef: { name: chimera-secrets }
          readinessProbe:
            httpGet: { path: /api/gui/health, port: 8766 }
            periodSeconds: 10
          resources:
            requests: { cpu: "500m", memory: "512Mi" }
            limits: { cpu: "2", memory: "2Gi" }
---
apiVersion: v1
kind: Service
metadata:
  name: chimera-api
  namespace: chimera
spec:
  selector: { app: chimera-api }
  ports: [{ name: http, port: 80, targetPort: 8766 }]
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: chimera-api
  namespace: chimera
spec:
  scaleTargetRef: { apiVersion: apps/v1, kind: Deployment, name: chimera-api }
  minReplicas: 3
  maxReplicas: 50
  metrics:
    - type: Resource
      resource:
        name: cpu
        target: { type: Utilization, averageUtilization: 65 }
"""
        netpol = """apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: chimera-default-deny-egress
  namespace: chimera
spec:
  podSelector: { matchLabels: { app: chimera-api } }
  policyTypes: [Egress]
  egress:
    # Add explicit provider/DB/OTLP/NATS egress rules for your cluster.
    - to:
        - namespaceSelector: {}
      ports:
        - { protocol: TCP, port: 5432 }
        - { protocol: TCP, port: 4222 }
        - { protocol: TCP, port: 8080 }
"""
        runbook = """# Chimera Kubernetes runbook

1. Replace `${CHIMERA_IMAGE}` via Kustomize/Helm/CI.
2. Use ExternalSecrets/SealedSecrets for `chimera-secrets`.
3. Configure NetworkPolicy for only DB, durable runtime, event bus, OTLP, and selected providers.
4. Run inside a pod:
   - `python -m chimera.cli platform cloud-scale-readiness --agents 5000 --tenants 500 --mode k8s`
   - `python -m chimera.cli platform cloud-scale-smoke --agents 5000 --tenants 500`
   - `python -m chimera.cli platform supreme-gate --scan-path /tmp/clean-candidate`
5. Do not mark production certified until host sandbox/gateway/event/cache receipts exist.
"""
        return [DeploymentFile("namespace.yaml", namespace), DeploymentFile("configmap.yaml", config), DeploymentFile("secret.template.yaml", secret), DeploymentFile("deployment.yaml", deploy), DeploymentFile("networkpolicy.yaml", netpol), DeploymentFile("RUNBOOK.md", runbook)]

    @staticmethod
    def _edge_notes() -> list[DeploymentFile]:
        notes = """# Chimera edge actor notes

This profile is advisory only. Use Cloudflare/Rivet style actors when global
low-latency stateful sessions matter more than full local control.

Required invariants:
- Core Chimera logic remains portable Python/Rust ports, not platform-only code.
- Agent state contains no raw provider keys.
- Long-running work uses Workflows/durable runtime, not a single edge request.
- Browser/rendering tools run with explicit egress and credential policy.
- Local mode remains the fallback.
"""
        return [DeploymentFile("EDGE-ACTOR-NOTES.md", notes)]
