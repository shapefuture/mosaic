
"""
Transactional Workspace — Mirage/Nexus/AgentState inspired

Law of Immutability: branch -> write* -> diff -> commit|abort
- Snapshot isolation (base pinned via revisions)
- Overlay over any mount (local FS modeled; S3/GDrive abstraction via path prefix)
- CAS + WAL + hash-chain
- Read-your-own-writes
- Atomic commit via overlay merge + hash

On-disk layout:
.chimera/
  branches/<name>/meta.json      {id, parent, branch, created, hash}
  branches/<name>/overlay/**     upper layer (writes)
  wal.jsonl                      hash-chain
  graph.json                     code graph cache
"""
from __future__ import annotations
import copy
import json, hashlib, pathlib, shutil, time, os, fnmatch
from typing import Any, List, Dict, Optional, Tuple
from dataclasses import dataclass
from .file_mutation_queue import FileMutationQueue

def _hash_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

@dataclass
class BranchHandle:
    name: str
    path: pathlib.Path
    meta: Dict

class TransactionalWorkspace:
    def __init__(self, root: pathlib.Path = pathlib.Path(".")):
        self.root = pathlib.Path(root).resolve()
        self.chimera_dir = self.root / ".chimera"
        self.branches_dir = self.chimera_dir / "branches"
        self.chimera_dir.mkdir(parents=True, exist_ok=True)
        self.branches_dir.mkdir(parents=True, exist_ok=True)
        from .wal import WAL
        self.wal = WAL(self.root)
        self._diff_cache: Dict[str, Dict[str, Any]] = {}
        self._mutation_queue = FileMutationQueue()
        self._ensure_main()

    def _ensure_main(self):
        main_meta = self.branches_dir / "main" / "meta.json"
        if not main_meta.exists():
            (self.branches_dir / "main" / "overlay").mkdir(parents=True, exist_ok=True)
            meta = {"id": _hash_bytes(b"main-genesis"), "parent": None, "branch": "main", "created": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "base_hash": _hash_bytes(b"empty")}
            main_meta.parent.mkdir(parents=True, exist_ok=True)
            main_meta.write_text(json.dumps(meta, indent=2))

    def branch(self, name: str, from_branch: str = "main") -> BranchHandle:
        if not name or not name.strip() or "/" in name or "\\" in name or name.startswith("."):
            raise ValueError(f"Invalid branch name: {name!r}")
        dest = self.branches_dir / name
        if dest.exists():
            raise FileExistsError(f"Branch {name} already exists")
        # base is either branch overlay or main
        src = self.branches_dir / from_branch
        if not src.exists():
            raise FileNotFoundError(f"Base branch {from_branch} not found")
        # create overlay dir
        (dest / "overlay").mkdir(parents=True, exist_ok=True)
        # compute parent hash
        parent_meta = json.loads((src / "meta.json").read_text())
        meta = {
            "id": _hash_bytes(f"{name}-{time.time()}".encode()),
            "parent": parent_meta["id"],
            "branch": name,
            "from": from_branch,
            "created": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "base_hash": parent_meta["id"],
        }
        (dest / "meta.json").write_text(json.dumps(meta, indent=2))
        self.wal.append("branch", {"branch": name, "from": from_branch, "id": meta["id"]})
        return BranchHandle(name, dest, meta)

    def fork(self, name: str, from_branch: str) -> BranchHandle:
        """Fork a branch with a frozen copy of the parent's overlay.

        ``branch()`` preserves Git-like ancestry metadata; ``fork()`` also
        snapshots uncommitted parent state so an atom can test against all
        verified dependencies without publishing them to the real workspace.
        """
        handle = self.branch(name, from_branch=from_branch)
        parent = self.branches_dir / from_branch
        child = self.branches_dir / name
        parent_overlay = parent / "overlay"
        child_overlay = child / "overlay"
        inherited: Dict[str, Dict[str, Any]] = {}
        if parent_overlay.exists():
            for source in parent_overlay.rglob("*"):
                if source.is_file():
                    rel = str(source.relative_to(parent_overlay))
                    destination = child_overlay / rel
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, destination)
                    inherited[rel] = {"state": "file", "hash": _hash_bytes(source.read_bytes())}
        parent_deletions = parent / "deletions.json"
        inherited_deletions: List[str] = []
        if parent_deletions.exists():
            inherited_deletions = json.loads(parent_deletions.read_text())
            (child / "deletions.json").write_text(json.dumps(inherited_deletions))
            for rel in inherited_deletions:
                inherited[rel] = {"state": "deleted", "hash": None}
        (child / "inherited.json").write_text(json.dumps({
            "from": from_branch, "files": inherited,
        }, indent=2, sort_keys=True))
        self.wal.append("fork", {"branch": name, "from": from_branch, "inherited": len(inherited)})
        return handle

    def _normalise_rel(self, rel_path: str) -> str:
        """Return a safe workspace-relative POSIX path or raise."""
        if not isinstance(rel_path, str) or not rel_path or "\x00" in rel_path:
            raise ValueError("Path must be a non-empty string without NUL bytes")
        raw = rel_path.replace("\\", "/")
        if raw.startswith("/") or pathlib.PurePosixPath(raw).is_absolute():
            raise ValueError("Absolute paths are not allowed in transactional branches")
        parts = pathlib.PurePosixPath(raw).parts
        if any(part in {"..", ""} for part in parts):
            raise ValueError("Path traversal not allowed")
        rel = pathlib.PurePosixPath(*[p for p in parts if p != "."]).as_posix()
        if rel == ".chimera" or rel.startswith(".chimera/branches/"):
            raise ValueError("Branch metadata is not a writable workspace target")
        return rel

    def _overlay_path(self, branch: str, rel: str) -> pathlib.Path:
        safe = self._normalise_rel(rel)
        return self.branches_dir / branch / "overlay" / safe

    def _record_preimage(self, branch: str, rel: str) -> None:
        """Pin the first-seen destination hash for per-file optimistic CAS."""
        pre_path = self.branches_dir / branch / "preimages.json"
        try:
            pre = json.loads(pre_path.read_text()) if pre_path.exists() else {}
        except (OSError, json.JSONDecodeError):
            pre = {}
        if rel in pre:
            return
        base = self.root / rel
        if base.exists() and base.is_file():
            pre[rel] = {"exists": True, "hash": _hash_bytes(base.read_bytes())}
        else:
            pre[rel] = {"exists": False, "hash": None}
        pre_path.write_text(json.dumps(pre, indent=2, sort_keys=True))

    def _is_deleted_marker(self, p: pathlib.Path) -> bool:
        return p.name == ".chimera-deleted"

    def write(self, branch: str, rel_path: str, content: bytes | str):
        br = self.branches_dir / branch
        if not br.exists():
            raise FileNotFoundError(f"Branch {branch} not found")
        rel = self._normalise_rel(rel_path)
        self._record_preimage(branch, rel)
        target = self._overlay_path(branch, rel)
        target.parent.mkdir(parents=True, exist_ok=True)
        # remove delete marker if present
        delete_marker = target.parent / ".chimera-deleted"
        # content write
        data = content.encode() if isinstance(content, str) else content
        with self._mutation_queue.locked(target):
            target.write_bytes(data)
        # clean up delete marker sibling file if exists for this file
        # delete markers are per-file: <file>.deleted ; simpler: store in .chimera/deleted list
        # For now, if we had deleted, remove entry from deletions.json
        del_file = self.branches_dir / branch / "deletions.json"
        if del_file.exists():
            try:
                dels = json.loads(del_file.read_text())
                if rel in dels:
                    dels.remove(rel)
                    del_file.write_text(json.dumps(dels))
            except Exception:
                pass
        self._diff_cache.pop(branch, None)
        self.wal.append("write", {"branch": branch, "path": rel, "bytes": len(data)})

    def read(self, branch: str, rel_path: str) -> bytes:
        # read-your-own-writes: overlay first, then base.
        rel = self._normalise_rel(rel_path)
        # check deletions
        del_file = self.branches_dir / branch / "deletions.json"
        if del_file.exists():
            dels = json.loads(del_file.read_text())
            if rel in dels:
                raise FileNotFoundError(f"{rel} deleted in branch {branch}")
        overlay = self._overlay_path(branch, rel)
        if overlay.exists():
            return overlay.read_bytes()
        # fallback to base FS (workspace root) — but respect branch lineage
        # For simplicity, read from actual file system root excluding .chimera
        base = self.root / rel
        if base.exists() and base.is_file():
            return base.read_bytes()
        raise FileNotFoundError(f"{rel} not found in branch {branch} or base")

    def unlink(self, branch: str, rel_path: str):
        br = self.branches_dir / branch
        if not br.exists():
            raise FileNotFoundError(branch)
        rel = self._normalise_rel(rel_path)
        self._record_preimage(branch, rel)
        overlay = self._overlay_path(branch, rel)
        if overlay.exists():
            with self._mutation_queue.locked(overlay):
                overlay.unlink()
        # mark deleted
        del_file = br / "deletions.json"
        dels = []
        if del_file.exists():
            dels = json.loads(del_file.read_text())
        if rel not in dels:
            dels.append(rel)
        del_file.write_text(json.dumps(dels))
        self._diff_cache.pop(branch, None)
        self.wal.append("unlink", {"branch": branch, "path": rel})

    def list_overlay(self, branch: str) -> List[str]:
        ov = self.branches_dir / branch / "overlay"
        if not ov.exists():
            return []
        out=[]
        for p in ov.rglob("*"):
            if p.is_file():
                out.append(str(p.relative_to(ov)))
        return out

    def _branch_signature(self, branch: str) -> tuple[Any, ...]:
        branch_dir = self.branches_dir / branch
        paths = [path for path in (branch_dir / "overlay").rglob("*") if path.is_file()]
        rows = []
        for path in sorted(paths):
            value = path.stat()
            rows.append((path.relative_to(branch_dir).as_posix(), value.st_size, value.st_mtime_ns, value.st_ctime_ns))
        deletion = branch_dir / "deletions.json"
        if deletion.exists():
            value = deletion.stat()
            rows.append(("deletions.json", value.st_size, value.st_mtime_ns, value.st_ctime_ns))
        return tuple(rows)

    def diff(self, branch: str) -> Dict:
        """Returns Patch-like dict: ops list with write/unlink + proof stub"""
        if branch == "main":
            return {"branch": "main", "ops": [], "hash": _hash_bytes(b"main-empty")}
        signature = self._branch_signature(branch)
        cached = self._diff_cache.get(branch)
        if cached is not None and cached.get("signature") == signature:
            return copy.deepcopy(cached["value"])
        ov_files = self.list_overlay(branch)
        ops=[]
        for rel in ov_files:
            data = (self.branches_dir / branch / "overlay" / rel).read_bytes()
            ops.append({"op": "write", "path": rel, "bytes": len(data), "hash": _hash_bytes(data)})
        del_file = self.branches_dir / branch / "deletions.json"
        if del_file.exists():
            dels = json.loads(del_file.read_text())
            for rel in dels:
                ops.append({"op": "unlink", "path": rel})
        # hash of ops
        patch_bytes = json.dumps(ops, sort_keys=True).encode()
        patch_hash = "sha256:" + _hash_bytes(patch_bytes)
        meta = json.loads((self.branches_dir / branch / "meta.json").read_text())
        value = {"id": patch_hash, "parent": meta["parent"], "branch": branch, "ops": ops, "author": "chimera@local"}
        self._diff_cache[branch] = {"signature": signature, "value": copy.deepcopy(value)}
        return value

    def commit(self, branch: str, message: str) -> str:
        """Serialize compare-and-publish across local processes with a fencing lock."""
        lock_path = self.chimera_dir / "workspace-commit.lock"
        handle = lock_path.open("a+b")
        try:
            try:
                import fcntl
            except ImportError as exc:  # pragma: no cover - capability-negative platform
                raise RuntimeError(
                    "multi-process transactional commit requires fcntl on this platform"
                ) from exc
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            return self._commit_locked(branch, message)
        finally:
            try:
                if "fcntl" in locals():
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            finally:
                handle.close()

    def _commit_locked(self, branch: str, message: str) -> str:
        """CAS-check and atomically publish a branch patch.

        The first observation of every touched file is pinned in
        ``preimages.json``.  A commit is rejected if another actor changed a
        destination after that observation.  Files are staged before any
        destination is replaced; on a mid-commit error, prior bytes are
        restored from backups.
        """
        if branch == "main":
            raise ValueError("Cannot commit main directly; create branch")
        branch_dir = self.branches_dir / branch
        if not branch_dir.exists():
            raise FileNotFoundError(branch)
        d = self.diff(branch)
        if not d["ops"]:
            self.wal.append("commit", {"branch": branch, "message": message, "hash": d["id"], "ops": 0})
            return d["id"]

        pre_path = branch_dir / "preimages.json"
        preimages = json.loads(pre_path.read_text()) if pre_path.exists() else {}
        conflicts: List[str] = []
        for op in d["ops"]:
            rel = self._normalise_rel(op["path"])
            expected = preimages.get(rel)
            dst = self.root / rel
            exists = dst.exists() and dst.is_file()
            current_hash = _hash_bytes(dst.read_bytes()) if exists else None
            if expected is None or bool(expected.get("exists")) != exists or expected.get("hash") != current_hash:
                conflicts.append(rel)
        if conflicts:
            self.wal.append("commit_conflict", {"branch": branch, "paths": conflicts, "hash": d["id"]})
            raise RuntimeError(f"CAS conflict on {', '.join(conflicts)}")

        transaction_dir = self.chimera_dir / "transactions" / d["id"].replace(":", "-")
        stage_dir, backup_dir = transaction_dir / "stage", transaction_dir / "backup"
        if transaction_dir.exists():
            shutil.rmtree(transaction_dir)
        stage_dir.mkdir(parents=True)
        backup_dir.mkdir(parents=True)
        touched: List[Tuple[pathlib.Path, bool]] = []
        try:
            # Stage all new bytes before changing the visible workspace.
            for op in d["ops"]:
                rel = self._normalise_rel(op["path"])
                dst = self.root / rel
                if dst.exists() and dst.is_symlink():
                    raise PermissionError(f"Refusing to commit through symlink: {rel}")
                if dst.exists() and dst.is_file():
                    backup = backup_dir / rel
                    backup.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(dst, backup)
                if op["op"] == "write":
                    staged = stage_dir / rel
                    staged.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(self._overlay_path(branch, rel), staged)

            for op in d["ops"]:
                rel = self._normalise_rel(op["path"])
                dst = self.root / rel
                existed = dst.exists()
                dst.parent.mkdir(parents=True, exist_ok=True)
                # Resolved parent must remain under the workspace root.
                if not dst.parent.resolve().is_relative_to(self.root):
                    raise PermissionError(f"Symlink escape in parent of {rel}")
                touched.append((dst, existed))
                if op["op"] == "write":
                    staged = stage_dir / rel
                    tmp = dst.parent / f".{dst.name}.{d['id'][-12:]}.tmp"
                    shutil.copy2(staged, tmp)
                    tmp.replace(dst)
                elif op["op"] == "unlink" and dst.exists():
                    if dst.is_dir():
                        raise IsADirectoryError(rel)
                    dst.unlink()
        except Exception:
            # Best-effort transaction rollback from complete preimages.
            for dst, existed in reversed(touched):
                rel = dst.relative_to(self.root)
                backup = backup_dir / rel
                if backup.exists():
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(backup, dst)
                elif not existed and dst.exists():
                    dst.unlink()
            self.wal.append("commit_rollback", {"branch": branch, "hash": d["id"]})
            raise

        self.wal.append("commit", {"branch": branch, "message": message, "hash": d["id"], "ops": len(d["ops"])})
        graph_status = "updated"
        try:
            from .graph import CodeGraph
            graph = CodeGraph(self.root)
            graph.load()
            graph.update(d)
        except Exception as exc:
            # Publishing code succeeded, but stale graph state is explicit in
            # both the WAL and the raised evidence—not silently swallowed.
            graph_status = f"stale: {exc}"
            self.wal.append("graph_update_failed", {"branch": branch, "hash": d["id"], "error": str(exc)})

        history = branch_dir / "commits.jsonl"
        with history.open("a") as handle:
            handle.write(json.dumps({"hash": d["id"], "message": message, "ops": d["ops"], "graph": graph_status}) + "\n")
        # A commit closes this transaction.  Keep history, but start with an
        # empty overlay so a second commit cannot replay the same effects.
        overlay = branch_dir / "overlay"
        shutil.rmtree(overlay)
        overlay.mkdir(parents=True)
        for state_file in (branch_dir / "deletions.json", pre_path):
            if state_file.exists():
                state_file.unlink()
        shutil.rmtree(transaction_dir, ignore_errors=True)
        self._diff_cache.pop(branch, None)
        return d["id"]

    def abort(self, branch: str):
        if branch == "main":
            raise ValueError("Cannot abort main")
        br = self.branches_dir / branch
        if not br.exists():
            raise FileNotFoundError(branch)
        shutil.rmtree(br)
        self._diff_cache.pop(branch, None)
        self.wal.append("abort", {"branch": branch})

    def list_branches(self) -> List[str]:
        return [p.name for p in self.branches_dir.iterdir() if p.is_dir()]

    def _effective_state(self, branch: str, rel: str) -> Dict[str, Any]:
        rel = self._normalise_rel(rel)
        deletions_path = self.branches_dir / branch / "deletions.json"
        deletions = json.loads(deletions_path.read_text()) if deletions_path.exists() else []
        if rel in deletions:
            return {"state": "deleted", "hash": None}
        overlay = self._overlay_path(branch, rel)
        if overlay.exists() and overlay.is_file():
            return {"state": "file", "hash": _hash_bytes(overlay.read_bytes())}
        base = self.root / rel
        if base.exists() and base.is_file():
            return {"state": "file", "hash": _hash_bytes(base.read_bytes())}
        return {"state": "absent", "hash": None}

    def delta(self, branch: str) -> Dict[str, Any]:
        """Return only changes made after ``fork()``, excluding inherited state."""
        branch_dir = self.branches_dir / branch
        inherited_path = branch_dir / "inherited.json"
        if not inherited_path.exists():
            return self.diff(branch)
        inherited = json.loads(inherited_path.read_text()).get("files", {})
        current_files = set(self.list_overlay(branch))
        deletions_path = branch_dir / "deletions.json"
        deletions = set(json.loads(deletions_path.read_text())) if deletions_path.exists() else set()
        paths = current_files | deletions | set(inherited)
        ops: List[Dict[str, Any]] = []
        for rel in sorted(paths):
            current = self._effective_state(branch, rel)
            before = inherited.get(rel)
            if before is None:
                # Parent had no overlay entry at fork. A child overlay/deletion
                # is therefore a delta; untouched base files are not in paths.
                if rel in current_files:
                    data = self._overlay_path(branch, rel).read_bytes()
                    ops.append({"op": "write", "path": rel, "bytes": len(data), "hash": _hash_bytes(data)})
                elif rel in deletions:
                    ops.append({"op": "unlink", "path": rel})
            elif current != before:
                if current["state"] == "file":
                    data = self._overlay_path(branch, rel).read_bytes()
                    ops.append({"op": "write", "path": rel, "bytes": len(data), "hash": _hash_bytes(data)})
                else:
                    ops.append({"op": "unlink", "path": rel})
        patch_id = "sha256:" + _hash_bytes(json.dumps(ops, sort_keys=True).encode())
        meta = json.loads((branch_dir / "meta.json").read_text())
        return {"id": patch_id, "parent": meta.get("parent"), "branch": branch, "ops": ops, "author": "chimera@atom"}

    def merge_into(self, source_branch: str, target_branch: str) -> Dict[str, Any]:
        """Merge a verified atom delta into its integration branch with CAS."""
        source_dir = self.branches_dir / source_branch
        target_dir = self.branches_dir / target_branch
        if not source_dir.exists() or not target_dir.exists():
            raise FileNotFoundError(f"source or target branch missing: {source_branch}, {target_branch}")
        delta = self.delta(source_branch)
        inherited_path = source_dir / "inherited.json"
        inherited = json.loads(inherited_path.read_text()).get("files", {}) if inherited_path.exists() else {}
        preimages_path = source_dir / "preimages.json"
        preimages = json.loads(preimages_path.read_text()) if preimages_path.exists() else {}
        conflicts: List[str] = []
        for op in delta.get("ops", []):
            rel = op["path"]
            expected = inherited.get(rel)
            if expected is None:
                pinned = preimages.get(rel, {"exists": False, "hash": None})
                expected = {"state": "file" if pinned.get("exists") else "absent", "hash": pinned.get("hash")}
            actual = self._effective_state(target_branch, rel)
            if actual != expected:
                conflicts.append(rel)
        if conflicts:
            self.wal.append("merge_conflict", {"source": source_branch, "target": target_branch, "paths": conflicts})
            raise RuntimeError(f"Atom merge conflict on {', '.join(conflicts)}")
        for op in delta.get("ops", []):
            if op["op"] == "write":
                self.write(target_branch, op["path"], self.read(source_branch, op["path"]))
            else:
                self.unlink(target_branch, op["path"])
        self.wal.append("merge", {
            "source": source_branch, "target": target_branch,
            "delta": delta["id"], "ops": len(delta.get("ops", [])),
        })
        return {"source": source_branch, "target": target_branch, "delta": delta,
                "target_diff": self.diff(target_branch)}

    def materialize(self, branch: str, target: Optional[pathlib.Path] = None) -> pathlib.Path:
        """Create an isolated, read-your-own-writes view for tests/sandboxes."""
        started = time.perf_counter()
        if branch not in self.list_branches():
            raise FileNotFoundError(branch)
        if target is None:
            target = self.chimera_dir / "runs" / f"{branch}-{int(time.time() * 1000)}"
        target = pathlib.Path(target).resolve()
        if not target.is_relative_to(self.chimera_dir.resolve()):
            raise ValueError("Materialized branch views must live under .chimera")
        if target.exists():
            shutil.rmtree(target)
        matcher = shutil.ignore_patterns(
            ".chimera", ".git", ".venv", "node_modules", "__pycache__",
            ".pytest_cache", ".env", ".env.*", "*.pem", "*.key", "auth.json",
            "dist", "build", "target", "out",
        )
        copied_files = 0
        def secure_ignore(directory: str, names: List[str]) -> set[str]:
            nonlocal copied_files
            ignored = set(matcher(directory, names))
            for name in names:
                if name in ignored:
                    continue
                source = pathlib.Path(directory) / name
                if source.is_symlink() and not source.resolve(strict=True).is_relative_to(self.root):
                    raise PermissionError(f"materialization symlink escapes workspace: {source}")
                if source.is_file():
                    copied_files += 1
            return ignored
        # shutil.copytree's C-optimized traversal wins on the common tiny-file
        # repository shape; independent task/test execution is parallelized at
        # the DAG layer rather than oversubscribing small disk copies.
        shutil.copytree(self.root, target, ignore=secure_ignore, symlinks=False)
        copy_strategy = "secure-copytree"
        overlay = self.branches_dir / branch / "overlay"
        for src in overlay.rglob("*") if overlay.exists() else []:
            if src.is_file():
                rel = src.relative_to(overlay)
                dst = target / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
        deletions = self.branches_dir / branch / "deletions.json"
        if deletions.exists():
            for rel in json.loads(deletions.read_text()):
                dst = target / self._normalise_rel(rel)
                if dst.exists() and dst.is_file():
                    dst.unlink()
        manifest = {
            "branch": branch,
            "diff": self.diff(branch),
            "created": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "copy_strategy": copy_strategy,
            "source_files": copied_files,
            "materialize_ms": round((time.perf_counter() - started) * 1000, 3),
        }
        (target / ".chimera-view.json").write_text(json.dumps(manifest, indent=2))
        return target

    def status(self, branch: str) -> Dict:
        d = self.diff(branch)
        return {"branch": branch, "ops": len(d["ops"]), "diff": d}

    # --- Mirage #138 overlay verbatim + AgentState snapshot + Nexus CAS + ?at time-travel ---

    def overlay_info(self, branch: str) -> Dict:
        """Mirage #138: lower, upper, workdir, merged view"""
        br = self.branches_dir / branch
        meta = json.loads((br / "meta.json").read_text()) if (br / "meta.json").exists() else {}
        return {
            "lower": str(self.root),  # live mount
            "upper": str(br / "overlay"),
            "work": str(br / "work"),  # Mirage workdir (created on demand)
            "merged": f"overlay:{branch} over {meta.get('from','main')} @ {meta.get('base_hash','')[:12]}",
            "branch": branch,
            "snapshot_isolation": f"pinned {meta.get('base_hash','')[:12]}",
        }

    def snapshot(self, branch: str) -> str:
        """AgentState snapshot: dump overlay + mount revisions, hash-chained via WAL"""
        from .agentstate import SnapshotStore
        store = SnapshotStore(self.root)
        ops = self.list_overlay(branch)
        meta = json.loads((self.branches_dir / branch / "meta.json").read_text())
        h = store.create(branch, meta, ops)
        self.wal.snapshot(branch, h)
        return h

    def query_at(self, at: str) -> List[Dict]:
        """?at=RFC3339 time-travel via WAL"""
        return self.wal.query_at(at)

    def mount(self, name: str, uri: str) -> Dict:
        """Nexus unified VFS: chimera branch --mount s3://bucket/app"""
        from .mount import MountRegistry
        reg = MountRegistry(self.root)
        m = reg.register(name, uri)
        self.wal.append("mount", {"name": name, "uri": uri})
        return {"name": m.name, "uri": m.uri, "local_path": str(m.local_path), "kind": m.kind}
