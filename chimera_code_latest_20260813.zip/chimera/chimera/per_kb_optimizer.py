"""Capability-per-kilobyte optimization plan inspired by uploaded Claw/far-transfer materials."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class PerKbMove:
    id: str
    principle: str
    transfer_source: str
    chimera_application: str
    expected_gain: str
    risk: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class CapabilityPerKbPlanner:
    def plan(self) -> dict[str, Any]:
        moves = [
            PerKbMove("capillary-core", "Capillary architecture", "claw64/PlanckClaw tiny resident loops", "Split Chimera into 20KB resident kernel + on-demand cold skill packs; keep only scheduler, ports, WAL tail, telemetry counters hot.", "Thousands of agents share one code image; per-agent state becomes bytes not MB.", "Requires strict lazy import and state serialization discipline."),
            PerKbMove("zygote-fork", "Copy-on-write swarm", "browser/process zygote models", "Preload graph/config/provider code once in a zygote; fork worker agents with copy-on-write memory and per-agent WAL/session dirs.", "Massive RSS reduction for parallel agents.", "Python refcount writes can dirty pages; needs measurement and possibly multiprocessing/forkserver tuning."),
            PerKbMove("artifact-neurons", "External memory neurons", "content-addressed CAS / biological sparse recall", "All large context, graph hits, transcripts, prompts, and tests become artifact refs; agents pass digests and GCF snippets only.", "Context and memory footprint scale by touched evidence, not repository size.", "Requires excellent UX for artifact drill-down."),
            PerKbMove("microkernel-tools", "One central tool, many internal adapters", "MCP minimalism + user's centralized-tool constraint", "Expose one run/session/telemetry tool surface; internal adapters fan out to Exa/browser/GCF/Rust without public tool proliferation.", "Better model tool choice, lower prompt size, fewer mistakes.", "Debugging adapters needs telemetry."),
            PerKbMove("probabilistic-presence", "Bloom/filter first, payload later", "network routers / CPU caches", "Agents first exchange Bloom filters of symbols/files/capabilities, fetching full content only on confirmed need.", "Near-zero context for negative queries.", "False positives acceptable; false negatives forbidden."),
            PerKbMove("fitness-islands", "Island evolution", "genetic algorithms / DGM", "Run many tiny Chimera copies on adversarial tasks; promote only shared improvements with hidden-test/metacritic evidence.", "Self-improvement without one monolithic agent loop.", "Needs budget caps and anti-Goodhart hidden tests."),
            PerKbMove("wire-diet", "Declare fields once", "GCF/TOON/table compression", "Use GCF at all model/tool boundaries for graph/search/telemetry arrays; JSON only for durable receipts.", "40-70% token reduction on structured payloads.", "Payload dependent; must measure reduction and fallback."),
            PerKbMove("tenant-shards", "Tenant as scheduler primitive", "multi-tenant RLS / Erlang supervision", "Every queue, telemetry row, graph index, and provider budget is tenant-keyed; idle tenants have no resident worker.", "Cloud-first density with isolation.", "Requires strict context propagation."),
            PerKbMove("entropy-routing", "Spend compute only on hard bits", "System1/System2, early exit, speculative decoding", "Use InferenceComputePlanner to route simple tasks to fast mode, coding/math to GSA+external tests, and stop once evidence is sufficient.", "Quality preserved with lower average cost.", "Provider-specific reasoning params still need adapter mapping."),
            PerKbMove("physiology-observability", "Every nerve reports, but only summaries persist", "body homeostasis", "Hot path increments counters/spans; cold path exports OTLP snapshots/outbox; raw payloads stay in CAS or are redacted.", "Maximum observability without log-memory explosion.", "Sampling/retention must be tenant-aware."),
        ]
        return {
            "schema_version": "chimera.capability-per-kb-plan.v1",
            "goal": "maximize useful verified capability per resident KB while preserving quality, token efficiency, cloud multitenancy, and local fallback",
            "first_principles": [
                "Resident memory should contain control, not content.",
                "Large evidence should be content-addressed, not copied into every agent.",
                "Tool surfaces should be few; internal adapters can be many.",
                "Cloud workers should be ephemeral; state lives in durable ports.",
                "Quality verdicts come from tests/receipts, not resident reasoning text.",
            ],
            "moves": [move.as_dict() for move in moves],
            "experimental_next_steps": [
                "Measure import/RSS per module and move heavy imports behind lazy ports.",
                "Prototype forkserver/zygote worker pool for 1000 no-op agents and 100 coding agents.",
                "Add Bloom-filter symbol index to Rust graph persisted index.",
                "Add OTLP + Prometheus counters for per-agent resident bytes and context bytes per successful test.",
                "Implement remote ephemeral worker mode backed by Postgres/Restate and CAS-only artifacts.",
            ],
            "non_negotiables": [
                "Do not drop external verification.",
                "Do not weaken tenant isolation.",
                "Do not promote Rust graph beyond evidence gates.",
                "Do not persist secrets in telemetry or reports.",
            ],
        }
