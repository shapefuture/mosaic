"""Explicit live-provider smoke probes with redacted output.

No prompts, responses, or credentials are persisted. Missing credentials are
reported as skipped. Intended for operator-authorized quota checks only.
"""
from __future__ import annotations

import json
import os
import pathlib
import time
from dataclasses import dataclass, asdict
from typing import Iterable

from .config import ChimeraConfig
from .rlm import RLMRuntime


@dataclass(frozen=True)
class LiveProbeResult:
    provider: str
    model: str
    status: str  # pass | skip | fail
    reason: str
    duration_ms: float = 0.0
    tokens: int | None = None
    answer_chars: int | None = None

    def as_dict(self):
        return asdict(self)


DEFAULT_PROBES = {
    "tokenrouter-kimi": (("TOKENROUTER_API_KEY", "TOKENROUTER_KEY"), "tokenrouter/moonshotai/kimi-k3-free"),
    "cerebras-oss": ("CEREBRAS_API_KEY", "cerebras/gpt-oss-120b"),
    "gemini": (("GEMINI_API_KEY", "GOOGLE_API_KEY", "GEMINI_API_KEYS", "GOOGLE_API_KEYS"), "gemini/gemini-3.5-flash-lite"),
}


def _has_env(names: str | tuple[str, ...]) -> bool:
    if isinstance(names, str):
        return bool(os.environ.get(names))
    return any(os.environ.get(name) for name in names)


def probe(model: str, provider_name: str, *, root: pathlib.Path | str = ".") -> LiveProbeResult:
    started = time.perf_counter()
    runtime = RLMRuntime(pathlib.Path(root), config=ChimeraConfig())
    try:
        response = runtime.model_provider(
            "Reply with exactly the word pong. This is a live provider connectivity smoke test.",
            model=model,
        )
        answer = str(response.get("answer", ""))
        ok = "pong" in answer.lower() or bool(answer.strip())
        return LiveProbeResult(
            provider_name, model, "pass" if ok else "fail",
            "live call returned non-empty answer" if ok else "empty answer",
            round((time.perf_counter() - started) * 1000, 3),
            int(response.get("tokens", 0) or 0), len(answer),
        )
    except Exception as exc:
        return LiveProbeResult(
            provider_name, model, "fail", f"{type(exc).__name__}: {str(exc)[:240]}",
            round((time.perf_counter() - started) * 1000, 3), None, None,
        )
    finally:
        runtime.close()


def run_default_probes(selected: Iterable[str] | None = None) -> list[LiveProbeResult]:
    wanted = set(selected or DEFAULT_PROBES)
    rows: list[LiveProbeResult] = []
    for name, (env_names, model) in DEFAULT_PROBES.items():
        if name not in wanted:
            continue
        if not _has_env(env_names):
            rows.append(LiveProbeResult(name, model, "skip", f"missing credential env {env_names}"))
            continue
        rows.append(probe(model, name))
    return rows


if __name__ == "__main__":
    print(json.dumps([row.as_dict() for row in run_default_probes()], indent=2))
