"""JSON-RPC/ACP branch-per-session control protocol."""

from __future__ import annotations

import json
import os
import pathlib
import time
import uuid
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict

from .branch import TransactionalWorkspace
from .config import ChimeraConfig
from .sandbox import Sandbox
from .wal import WAL


class RemoteSession(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str
    protocol: Literal["rpc", "acp", "mcp"]
    objective: str
    branch: str
    base_branch: str
    model: str
    status: Literal["open", "verified", "committed", "aborted", "failed"]
    created_at: str
    updated_at: str
    verification: Optional[dict[str, Any]] = None


class SessionProtocol:
    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root).resolve()
        self.dir = self.root / ".chimera" / "rpc" / "sessions"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.workspace = TransactionalWorkspace(self.root)
        self.wal = WAL(self.root)
        self.config = ChimeraConfig.load(self.root / "chimera.toml")

    def _path(self, session_id: str) -> pathlib.Path:
        if not session_id.startswith("session-") or any(
            char not in "abcdefghijklmnopqrstuvwxyz0123456789-" for char in session_id
        ):
            raise ValueError("invalid session id")
        return self.dir / f"{session_id}.json"

    def _save(self, session: RemoteSession) -> None:
        session.updated_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        path = self._path(session.id)
        temporary = path.with_suffix(".tmp")
        temporary.write_text(session.model_dump_json(indent=2))
        os.replace(temporary, path)

    def get(self, session_id: str) -> RemoteSession:
        path = self._path(session_id)
        if not path.exists():
            raise KeyError(session_id)
        return RemoteSession.model_validate_json(path.read_text())

    def open(
        self,
        objective: str,
        *,
        model: str = "mock-echo",
        base_branch: str = "main",
        protocol: Literal["rpc", "acp", "mcp"] = "rpc",
    ) -> RemoteSession:
        if not objective.strip():
            raise ValueError("objective is required")
        session_id = f"session-{uuid.uuid4().hex[:16]}"
        branch = f"rpc-{session_id.removeprefix('session-')}"
        self.workspace.branch(branch, from_branch=base_branch)
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        session = RemoteSession(
            id=session_id,
            protocol=protocol,
            objective=objective,
            branch=branch,
            base_branch=base_branch,
            model=model,
            status="open",
            created_at=now,
            updated_at=now,
        )
        self._save(session)
        self.wal.append(
            "rpc_session_open",
            {
                "session": session_id,
                "protocol": protocol,
                "branch": branch,
                "base_branch": base_branch,
                "objective_hash": __import__("hashlib")
                .sha256(objective.encode())
                .hexdigest(),
            },
        )
        return session

    def list(self) -> list[RemoteSession]:
        return sorted(
            (
                RemoteSession.model_validate_json(path.read_text())
                for path in self.dir.glob("session-*.json")
            ),
            key=lambda item: item.created_at,
        )

    def send(self, session_id: str, message: str) -> dict[str, Any]:
        session = self.get(session_id)
        if session.status not in {"open", "verified"}:
            raise RuntimeError("session is terminal")
        digest = "sha256:" + __import__("hashlib").sha256(message.encode()).hexdigest()
        entry = self.wal.append(
            "rpc_session_message",
            {
                "session": session_id,
                "branch": session.branch,
                "message_hash": digest,
            },
        )
        return {"session": session_id, "message_hash": digest, "wal_seq": entry.seq}

    def diff(self, session_id: str) -> dict[str, Any]:
        session = self.get(session_id)
        return self.workspace.diff(session.branch)

    def verify(self, session_id: str, command: str = "pytest -q") -> RemoteSession:
        session = self.get(session_id)
        if session.status != "open":
            raise RuntimeError("only open sessions can be verified")
        sandbox = Sandbox(
            self.root,
            self.config.to_capability_set(),
            branch=session.branch,
            workspace=self.workspace,
        )
        result = sandbox.exec(command, timeout=120)
        diff = self.workspace.diff(session.branch)
        receipt = {
            "status": result.status,
            "command_hash": "sha256:"
            + __import__("hashlib").sha256(command.encode()).hexdigest(),
            "diff_id": diff.get("id"),
            "ops": len(diff.get("ops", [])),
            "backend": result.evidence.get("backend"),
        }
        session.verification = receipt
        session.status = (
            "verified" if result.status == 0 and diff.get("ops") else "failed"
        )
        self._save(session)
        self.wal.append(
            "rpc_session_verify",
            {"session": session_id, "branch": session.branch, **receipt},
        )
        return session

    def commit(self, session_id: str, message: str) -> RemoteSession:
        """Compatibility local commit; transport adapters use application-owned approval."""
        session = self.get(session_id)
        if (
            session.status != "verified"
            or not session.verification
            or session.verification.get("status") != 0
        ):
            raise PermissionError(
                "remote session commit requires passing verification receipt"
            )
        commit_hash = self.workspace.commit(session.branch, message)
        return self.record_commit(session_id, commit_hash)

    def record_commit(self, session_id: str, commit_hash: str) -> RemoteSession:
        session = self.get(session_id)
        if (
            session.status != "verified"
            or not session.verification
            or session.verification.get("status") != 0
        ):
            raise PermissionError(
                "remote session commit requires passing verification receipt"
            )
        session.status = "committed"
        session.verification = {**session.verification, "commit": str(commit_hash)}
        self._save(session)
        self.wal.append(
            "rpc_session_commit",
            {
                "session": session_id,
                "branch": session.branch,
                "commit": str(commit_hash),
            },
        )
        return session

    def abort(self, session_id: str) -> RemoteSession:
        session = self.get(session_id)
        if session.status in {"committed", "aborted"}:
            raise RuntimeError("session is terminal")
        if session.branch in self.workspace.list_branches():
            self.workspace.abort(session.branch)
        session.status = "aborted"
        self._save(session)
        self.wal.append(
            "rpc_session_abort", {"session": session_id, "branch": session.branch}
        )
        return session

    def handle(self, request: dict[str, Any]) -> dict[str, Any]:
        request_id = request.get("id")
        method = str(request.get("method", ""))
        params = (
            request.get("params") if isinstance(request.get("params"), dict) else {}
        )
        aliases = {
            "agent/session/new": "session/open",
            "agent/session/get": "session/get",
            "agent/prompt": "session/send",
            "agent/cancel": "session/abort",
        }
        method = aliases.get(method, method)
        try:
            if method == "session/open":
                value = self.open(
                    params.get("objective", ""),
                    model=params.get("model", "mock-echo"),
                    base_branch=params.get("base_branch", "main"),
                    protocol=params.get("protocol", "rpc"),
                ).model_dump(mode="json")
            elif method == "session/get":
                value = self.get(params["session_id"]).model_dump(mode="json")
            elif method == "session/list":
                value = [item.model_dump(mode="json") for item in self.list()]
            elif method == "session/send":
                value = self.send(params["session_id"], params.get("message", ""))
            elif method == "session/diff":
                value = self.diff(params["session_id"])
            elif method == "session/verify":
                value = self.verify(
                    params["session_id"], params.get("command", "pytest -q")
                ).model_dump(mode="json")
            elif method == "session/commit":
                value = self.commit(
                    params["session_id"], params.get("message", "rpc commit")
                ).model_dump(mode="json")
            elif method == "session/abort":
                value = self.abort(params["session_id"]).model_dump(mode="json")
            else:
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {"code": -32601, "message": f"unknown method {method}"},
                }
            return {"jsonrpc": "2.0", "id": request_id, "result": value}
        except Exception as exc:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {"code": -32603, "message": f"{type(exc).__name__}: {exc}"},
            }


class ApplicationSessionProtocol:
    """JSON-RPC transport decoder over the shared application use cases."""

    def __init__(self, context_factory) -> None:
        self.context_factory = context_factory

    @staticmethod
    def _mapping(value):
        return (
            value.model_dump(mode="json")
            if hasattr(value, "model_dump")
            else dict(value)
        )

    def handle(self, request: dict[str, Any]) -> dict[str, Any]:
        from .application import (
            AbortBranchCommand,
            ApplicationError,
            CommitBranchCommand,
            GetDiffCommand,
            OpenSessionCommand,
            ResumeSessionCommand,
            SendSessionInputCommand,
        )

        request_id = request.get("id")
        method = str(request.get("method", ""))
        params = (
            request.get("params") if isinstance(request.get("params"), dict) else {}
        )
        aliases = {
            "agent/session/new": "session/open",
            "agent/session/get": "session/get",
            "agent/prompt": "session/send",
            "agent/cancel": "session/abort",
        }
        method = aliases.get(method, method)
        try:
            application, context = self.context_factory()
            sessions = application.sessions
            if sessions is None:
                raise ApplicationError(
                    "session_unavailable", "session adapter is unavailable"
                )
            if method == "session/open":
                value = application.open_session(
                    OpenSessionCommand(
                        objective=params.get("objective", ""),
                        model=params.get("model", "mock-echo"),
                        base_branch=params.get("base_branch", "main"),
                        protocol=params.get("protocol", "rpc"),
                        context=context,
                    )
                ).model_dump(mode="json")
            elif method == "session/get":
                value = self._mapping(sessions.get(params["session_id"]))
            elif method == "session/list":
                value = [self._mapping(item) for item in sessions.list()]
            elif method == "session/send":
                value = application.send_session_input(
                    SendSessionInputCommand(
                        session_id=params["session_id"],
                        message=params.get("message", ""),
                        context=context,
                    )
                ).model_dump(mode="json")
            elif method == "session/diff":
                session = sessions.get(params["session_id"])
                value = application.get_diff(
                    GetDiffCommand(
                        branch=session.branch,
                        context=context,
                    )
                ).model_dump(mode="json")
            elif method == "session/verify":
                value = application.resume_session(
                    ResumeSessionCommand(
                        session_id=params["session_id"],
                        command=params.get("command", "pytest -q"),
                        context=context,
                    )
                ).model_dump(mode="json")
            elif method == "session/commit":
                session = sessions.get(params["session_id"])
                committed = application.commit(
                    CommitBranchCommand(
                        branch=session.branch,
                        task=session.objective,
                        message=params.get("message", "rpc commit"),
                        context=context,
                    )
                )
                commit_hash = str(committed.value["commit"])
                value = self._mapping(
                    sessions.record_commit(params["session_id"], commit_hash)
                )
            elif method == "session/abort":
                from .application import CancelSessionCommand

                value = application.cancel_session(
                    CancelSessionCommand(
                        session_id=params["session_id"],
                        context=context,
                    )
                ).model_dump(mode="json")
            else:
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {"code": -32601, "message": "unknown method"},
                }
            return {"jsonrpc": "2.0", "id": request_id, "result": value}
        except ApplicationError as exc:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32001,
                    "message": exc.public_message,
                    "data": exc.public_dict(),
                },
            }
        except Exception as exc:
            error_id = "error:" + uuid.uuid4().hex
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32603,
                    "message": "internal application error",
                    "data": {"error_id": error_id, "error_class": type(exc).__name__},
                },
            }


def serve_stdio(
    root: pathlib.Path = pathlib.Path("."), *, context_factory=None
) -> None:
    import sys

    if context_factory is None:
        from .bootstrap import build_local_application, new_run_context

        application, composition = build_local_application(root)
        context_factory = lambda: (
            application,
            new_run_context(profile=composition.config.deployment_profile),
        )
    protocol = ApplicationSessionProtocol(context_factory)
    for line in sys.stdin:
        if not line.strip():
            continue
        try:
            request = json.loads(line)
            if not isinstance(request, dict):
                raise ValueError
            response = protocol.handle(request)
        except (json.JSONDecodeError, ValueError):
            response = {
                "jsonrpc": "2.0",
                "error": {"code": -32700, "message": "invalid JSON request"},
            }
        sys.stdout.write(json.dumps(response, separators=(",", ":")) + "\n")
        sys.stdout.flush()
