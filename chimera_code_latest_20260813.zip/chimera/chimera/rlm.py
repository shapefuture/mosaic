
"""
RLM Runtime — Recursive Language Model + Recursive Agent Harnesses (RAH) + Chained RLM

Per PRD §6.3/7.7 + PrimeIntellect/rlm-harness + RAH paper + Chained RLM:

- RLM depth=1 only (Think But Don't Overthink: depth=2 3.6s->344s collapse)
- Context as Variable in REPL, not prompt: `ctx = Variable("task history", value=...)`
- Recursive unit = full harness (RAH), not bare model call: Parent generates executable Task() script
  that spawns sub-harnesses in parallel, each with fresh context + tools, communicates via agent_message
- agent_message: parent/sibling/child messaging (Prime Agent's daemon)
- Chained RLM: fresh roots sharing blackboard + artifacts, not conversational history
- Swarm support: Kimi K2.5 100-agent swarm, DeepSeek, Qwen etc via model param

Implements:
- Variable: REPL variable store, lineage-preserving
- AgentMessageBus: send/recv between branches
- TaskScript: generates Task() executable script for RAH
- RLMRuntime.rlm(task, branch, model, depth=1) -> {answer, usage, turns, session_dir, diff, verification}
"""
from __future__ import annotations
import pathlib, time, json, concurrent.futures, re, shlex, threading, hashlib, os
from typing import Dict, Any, List, Optional, Callable, Mapping, Iterable
from .branch import TransactionalWorkspace
from .dag import DAGPlanner
from .graph import CodeGraph
from .verifier import Verifier
from .sandbox import Sandbox
from .config import ChimeraConfig
from .quality import TaskContract, PatchQualityGate, ChangeTarget
from .preflight import HarnessPreflight
from .wire import WireCodec
from .wal import WALBatchScope
from .action_ir import OperationKind, SingleToolSurface, ToolPlanCompiler, ToolSurfaceError
from .artifacts import ContentAddressedArtifactStore
from .impact import ImpactAnalyzer
from .kernel import KernelPolicyError, PersistentReadOnlyKernel
from .context_evidence import ContextEvidenceBinder
from .capsule import VerifiedCapsuleCache, build_capsule_spec
from .prompt_cache import PromptCacheTracker
from .runtime_ports import CallableModelCompletionAdapter, CompletionRequest, ModelCompletionPort
from .aci import AgentComputerInterface
from .speculative_tools import SpeculativeToolExecutor
from .action_executor import ActionExecutor
from .provider_client import ProviderClient
from .prompt_assembler import PromptAssembler
from .tool_protocol import ToolProtocol
from .tokenizer import TokenizerMeasurer
from .route_authority import RouteAuthority

from .tokenizer import TokenizerMeasurer
from .rlm_primitives import Variable, AgentMessageBus, AuthStorage, TaskScript, Blackboard
from .rlm_provider import RLMProviderMixin
from .rlm_action_methods import RLMActionMixin
from .rlm_tool_methods import RLMToolMixin
from .rlm_coder_focused import RLMFocusedCoderMixin
from .rlm_coder_cohesive import RLMCohesiveCoderMixin
from .rlm_execution_methods import RLMExecutionMixin
from .rlm_loop import RLMLoopMixin
from .rlm_dag_solver import RLMDAGSolverMixin
from .rlm_orchestration_methods import RLMOrchestrationMixin

class RLMRuntime(RLMProviderMixin, RLMActionMixin, RLMToolMixin, RLMFocusedCoderMixin, RLMCohesiveCoderMixin, RLMExecutionMixin, RLMLoopMixin, RLMDAGSolverMixin, RLMOrchestrationMixin):
    def __init__(self, root: pathlib.Path = pathlib.Path("."), workspace: Optional[TransactionalWorkspace]=None, config: Optional[ChimeraConfig]=None, model_provider: Optional[Callable]=None, stream_callback: Optional[Callable[[str], None]]=None, model_completion_port: Optional[ModelCompletionPort]=None, injected_provider_mode: str = "fixture"):
        self.root = pathlib.Path(root).resolve()
        self.workspace = workspace or TransactionalWorkspace(root)
        self.config = config or ChimeraConfig.load()
        self.route_authority = RouteAuthority(self.config.models)
        self.graph = CodeGraph(root)
        self.blackboard = Blackboard()
        self.message_bus = AgentMessageBus(root)
        self.auth_storage = AuthStorage(root)
        if injected_provider_mode not in {"fixture", "external"}:
            raise ValueError("injected_provider_mode must be fixture or external")
        self._provider_injected = model_provider is not None or model_completion_port is not None
        # Test fixtures retain the lightweight compatibility path by default.
        # An explicit external injected port (for example an OpenAI-compatible
        # enterprise gateway) receives the same focused coding gates as the
        # built-in provider without granting it extra commit authority.
        self._injected_provider_mode = injected_provider_mode
        self._uses_production_provider = (
            model_provider is None and model_completion_port is None
        ) or (self._provider_injected and injected_provider_mode == "external")
        # Provider transport is a port: it has no branch/commit authority and
        # returns only untrusted completion data for the existing admission
        # pipeline. Keep ``model_provider`` as a callable shim so current
        # provider tests and external integrations remain source-compatible.
        self.model_completion_port = model_completion_port or CallableModelCompletionAdapter(
            model_provider or self._production_provider
        )
        self.model_provider = self._complete_model
        self.stream_callback = stream_callback
        self._openrouter_key_cursor = 0
        self._gemini_key_cursor = 0
        self._key_lock = threading.Lock()
        self._active_task = ""
        self._task_contract: Optional[TaskContract] = None
        self._workspace_lock = threading.RLock()
        self._thread_local = threading.local()
        self.wire = WireCodec(default="auto")
        self.artifacts = ContentAddressedArtifactStore(self.root)
        from .audited_task_state import AuditedTaskStateLedger
        self.audited_task_states = AuditedTaskStateLedger(self.root)
        from .compaction import TranscriptCompactor
        from .tool_output import ToolOutputProjector
        self.compactor = TranscriptCompactor(self.artifacts)
        self.tool_output_projector = ToolOutputProjector(self.artifacts)
        from .context_quarantine import RetrievedContentGuard
        self.retrieved_content_guard = RetrievedContentGuard()
        self.tool_compiler = ToolPlanCompiler(self.root)
        self.single_tool_surface = SingleToolSurface(self.config.planner.max_actions_per_run)
        from .adaptive_tools import AdaptiveActionCap
        self.adaptive_action_cap = AdaptiveActionCap(self.config.planner.max_actions_per_run)
        self._kernels: Dict[str, PersistentReadOnlyKernel] = {}
        self._loop_detectors: Dict[str, Any] = {}
        from .loop_graph import ProgressLoopGuard
        self._progress_loop_detectors: Dict[str, ProgressLoopGuard] = {}
        from .fable_transfers import FailureStreakEscalator
        self._failure_escalators: Dict[str, FailureStreakEscalator] = {}
        self.impact_analyzer = ImpactAnalyzer(self.root)
        from .decision_memory import DecisionMemory
        self.decisions = DecisionMemory(self.root)
        from .async_memory import AsyncMemoryRecall
        self.async_memory = AsyncMemoryRecall(self.decisions)
        self.context_evidence = ContextEvidenceBinder(self.root)
        from .usage import UsageLedger
        self.usage_ledger = UsageLedger(self.root)
        self.capsule_cache = VerifiedCapsuleCache(self.root, artifact_store=self.artifacts)
        from .command_proof import CommandProofCache
        self.command_proofs = CommandProofCache(self.root, store=self.artifacts)
        self.prompt_cache = PromptCacheTracker()
        self._context_pack_builders: Dict[str, Any] = {}
        self._hybrid_observations: Dict[str, Dict[str, Any]] = {}
        from .branch_read_cache import BranchReadCache
        self.branch_read_cache = BranchReadCache()
        self.aci = AgentComputerInterface(self.root, self.workspace)
        self.speculative_tools = SpeculativeToolExecutor(self.root)
        self.action_executor = ActionExecutor(self)
        self.provider_client = ProviderClient(self)
        self.prompt_assembler = PromptAssembler(self.prompt_cache)
        self.tool_protocol = ToolProtocol()
        from .latency_attribution import LatencyAttributionLedger
        self.latency_attribution = LatencyAttributionLedger(self.root)
        from .run_lifecycle import RunLifecycleLedger
        self.run_lifecycle = RunLifecycleLedger(self.root)
        from .tool_trace import ToolTraceLedger
        self.tool_traces = ToolTraceLedger(self.root)
        from .action_certificate import ActionCertificateAuthority
        from .action_admission import ActionExecutionReceiptLedger
        self.action_certificates = ActionCertificateAuthority(self.root)
        self.action_execution_receipts = ActionExecutionReceiptLedger(self.root)
        from .evidence_portfolio import LocalEvidencePortfolio
        self.evidence_portfolio = LocalEvidencePortfolio(self.root)
        from .context_segments import ContextSegmentLedger
        self.context_segments = ContextSegmentLedger(self.root)
        from .context_plan import ContextPlanCompiler
        self.context_plan_compiler = ContextPlanCompiler()
        from .observational_memory import ObservationalMemory
        self.observations = ObservationalMemory(self.root)
        from .soft_interrupt import SoftInterruptQueue
        self.soft_interrupts = SoftInterruptQueue(self.root)
        from .exposure import ExposureTracker
        self.exposure = ExposureTracker()
        from .workspace_awareness import WorkspaceAwareness
        self.awareness = WorkspaceAwareness(self.root)
        self._http_client = None
        self._http_client_lock = threading.Lock()
        self._self_hosted_adapter = None
        from .antifragile import CircuitBreaker
        self.provider_breaker = CircuitBreaker(threshold=3, timeout=30.0)
        from .provider_cooldown import ProviderCooldownLedger
        self.provider_cooldowns = ProviderCooldownLedger(self.root)
        from .provider_capabilities import ProviderCapabilityRegistry
        from .provider_qos import ProviderQoSLedger
        from .regression_ledger import RegressionLedger
        self.provider_capabilities = ProviderCapabilityRegistry(self.root)
        self.provider_qos = ProviderQoSLedger(self.root)
        from .empirical_policy import CapabilityProofLedger, AfterActionReview
        self.capability_proofs = CapabilityProofLedger(self.root)
        self.after_action_reviews = AfterActionReview(self.root)
        self.regression_ledger = RegressionLedger(self.root)
        from .continual import ContinualHarness
        self.continual = ContinualHarness(self.root, namespace="default", base_prompt="chimera-base-v1")
        from .cost_governor import CostGovernor
        self.cost_governor = CostGovernor()
        self.tokenizer_measurer = TokenizerMeasurer()
        self.dag_planner = DAGPlanner(
            max_parallel=self.config.planner.max_parallel,
            token_budget=self.config.planner.token_budget,
            agent_timeout=self.config.planner.agent_timeout,
            root=self.root,
            graph=self.graph,
            cost_governor=self.cost_governor,
        )

    def _count_tokens(self, model: str, text: str) -> int:
        """Prefer exact tokenizer measurement; explicitly fall back to len//4 when unavailable."""
        measurement = self.tokenizer_measurer.measure(model, text)
        if measurement.status == "measured" and measurement.tokens is not None:
            return measurement.tokens
        return max(0, len(text) // 4)

    @staticmethod
    def _json_from_model(text: str) -> Optional[Dict[str, Any]]:
        """Extract one JSON object without evaluating model text as code."""
        candidates = re.findall(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL | re.IGNORECASE)
        candidates.append(text.strip())
        decoder = json.JSONDecoder()
        for candidate in candidates:
            starts = [0] if candidate.startswith("{") else [m.start() for m in re.finditer(r"\{", candidate)]
            for start in starts:
                try:
                    value, _ = decoder.raw_decode(candidate[start:])
                    if isinstance(value, dict):
                        return value
                except (json.JSONDecodeError, TypeError):
                    continue
        return None

    def _repository_context(self, query: str, max_files: int = 8, max_chars: int = 48_000) -> tuple[str, List[Dict]]:
        terms = list(dict.fromkeys(re.findall(r"[A-Za-z_][A-Za-z0-9_]{2,}", query.lower())))
        hints = [term for term in terms if term in {"audit", "cli", "verifier", "verification", "wal", "etas", "sandbox", "graph", "branch", "evolution", "replay"}]
        hits: List[Dict] = []
        seen_ids: set[str] = set()
        for term in [*hints, query[:120]]:
            try:
                found = self.graph.ranger_search(term, limit=6)
            except Exception:
                found = self.graph.search(term, limit=6)
            for hit in found:
                if hit.get("id") not in seen_ids:
                    hits.append(hit); seen_ids.add(hit.get("id"))
        files = list(dict.fromkeys(hit.get("file") for hit in hits if hit.get("file")))
        # CLI entry points are high-value context for command tasks even if a
        # lexical query ranked a lower-level symbol first.
        if "command" in query.lower():
            for candidate in ("chimera/cli.py", "pyproject.toml", "chimera/__main__.py"):
                if (self.root / candidate).exists() and candidate not in files:
                    files.insert(0, candidate)
        if "audit" in query.lower():
            for test_path in sorted((self.root / "tests").glob("*audit*.py")) if (self.root / "tests").exists() else []:
                candidate = str(test_path.relative_to(self.root))
                if candidate not in files:
                    files.insert(0, candidate)
        graph_wire = self.wire.encode_graph(
            hits[:20], tool="repository_context", token_budget=max_chars // 4,
            mode="auto",
        )
        parts: List[str] = [
            f"\n--- STRUCTURED CODE GRAPH ({graph_wire.format}, reduction={graph_wire.reduction:.1%}) ---\n"
            + graph_wire.model_text()
        ]
        used = len(parts[0])
        for rel in files[:max_files]:
            path = (self.root / rel).resolve()
            if not path.is_relative_to(self.root) or not path.is_file():
                continue
            content = path.read_text(encoding="utf-8", errors="ignore")
            remaining = max_chars - used
            if remaining <= 0:
                break
            excerpt = content[:min(len(content), remaining)]
            parts.append(f"\n--- FILE {rel} ---\n{excerpt}")
            used += len(excerpt)
        return "".join(parts), hits

    def _interface_context(self, query: str, max_chars: int = 18_000) -> str:
        """Return signatures and narrow source windows, not whole repository files."""
        try:
            hits = self.graph.ranger_search(query, limit=20)
        except Exception:
            hits = self.graph.search(query, limit=20)
        by_file: Dict[str, List[Dict[str, Any]]] = {}
        for hit in hits:
            path = hit.get("file")
            if path and path not in {"tests/test_hard_audit.py"}:
                by_file.setdefault(path, []).append(hit)
        chunks: List[str] = []
        used = 0
        for rel, file_hits in list(by_file.items())[:10]:
            path = (self.root / rel).resolve()
            if not path.is_relative_to(self.root) or not path.is_file():
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
            lines = text.splitlines()
            excerpts: List[str] = []
            if path.suffix == ".py":
                try:
                    import ast
                    tree = ast.parse(text)
                    signatures = []
                    for node in ast.walk(tree):
                        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                            if isinstance(node, ast.ClassDef):
                                signature = f"class {node.name}"
                            else:
                                args = [arg.arg for arg in node.args.args]
                                signature = f"def {node.name}({', '.join(args)})"
                            signatures.append(f"L{getattr(node, 'lineno', '?')}: {signature}")
                    excerpts.append("INTERFACES:\n" + "\n".join(signatures[:80]))
                except SyntaxError:
                    pass
            for hit in file_hits[:4]:
                line = hit.get("line")
                if isinstance(line, int) and lines:
                    start, end = max(0, line - 12), min(len(lines), line + 24)
                    excerpts.append(f"SOURCE L{start + 1}-L{end}:\n" + "\n".join(lines[start:end]))
            if not excerpts:
                excerpts.append("SOURCE HEAD:\n" + "\n".join(lines[:80]))
            chunk = f"\n--- {rel} ---\n" + "\n".join(excerpts)
            if used + len(chunk) > max_chars:
                chunk = chunk[:max(0, max_chars - used)]
            if chunk:
                chunks.append(chunk)
                used += len(chunk)
            if used >= max_chars:
                break
        return "".join(chunks)

    @staticmethod
    def _python_fences(text: str) -> List[str]:
        return [match.group(1).strip() + "\n" for match in re.finditer(r"```(?:python|py)\s*(.*?)```", text, re.DOTALL | re.IGNORECASE)]

    @staticmethod
    def _parse_python_safely(source: str, filename: str):
        import ast
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", SyntaxWarning)
            return ast.parse(source, filename=filename)

    def _extract_python_source(self, text: str, target_path: str) -> Optional[str]:
        """Recover a complete parseable module from fenced or prose-wrapped text."""
        import ast
        active_contract = getattr(self._thread_local, "contract", None) or self._task_contract
        required = set((active_contract.required_symbols.get(target_path, []) if active_contract else []))
        candidates = self._python_fences(text)
        lines = text.replace("\r\n", "\n").splitlines()
        starts = [
            index for index, line in enumerate(lines)
            if re.match(r'^\s*(?:[rubf]*[\"\']{3}|from\s+__future__|from\s+[.\w]+\s+import|import\s+\w+|def\s+\w+|class\s+\w+)', line)
        ]
        # Try bounded contiguous spans so prose before/after code is discarded.
        for start in starts[:20]:
            for end in range(len(lines), start, -1):
                candidate = "\n".join(lines[start:end]).strip() + "\n"
                if len(candidate) < 20:
                    continue
                try:
                    tree = self._parse_python_safely(candidate, target_path)
                except SyntaxError:
                    continue
                exported = {
                    node.name for node in tree.body
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                }
                if required.issubset(exported):
                    candidates.append(candidate)
                    break
        scored: List[tuple[int, str]] = []
        for candidate in candidates:
            try:
                tree = self._parse_python_safely(candidate, target_path)
            except SyntaxError:
                continue
            exported = {
                node.name for node in tree.body
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
            }
            score = (1_000_000 if required.issubset(exported) else 0) + len(candidate)
            scored.append((score, candidate))
        return max(scored, default=(0, None), key=lambda item: item[0])[1]

    @staticmethod
    def _normalise_patch_envelope(payload: Any) -> Any:
        """Normalize common provider patch dialects without inventing content.

        The closed patch/admission gates remain authoritative. This only maps
        direct syntactic aliases such as ``old`` → ``find`` and a mapping of
        file paths to file content into Chimera's typed list envelope.
        """
        if not isinstance(payload, dict):
            return payload
        from .compact_patch import CompactPatchError, decode_compact_patch, is_compact_patch
        if is_compact_patch(payload):
            try:
                return decode_compact_patch(payload)
            except CompactPatchError:
                # Preserve malformed compact data for the normal static gate to
                # reject; never guess paths/content from an invalid envelope.
                return payload
        normalized = dict(payload)
        normalized.setdefault("summary", "model patch")
        for key in ("files", "edits", "insertions"):
            value = normalized.get(key, [])
            if isinstance(value, dict):
                rows = []
                for path, item in value.items():
                    if isinstance(item, str):
                        rows.append({"path": str(path), "content": item})
                    elif isinstance(item, dict):
                        rows.append({"path": str(path), **item})
                value = rows
            normalized[key] = value if isinstance(value, list) else []
        cleaned_edits = []
        for item in normalized["edits"]:
            if not isinstance(item, dict):
                cleaned_edits.append(item); continue
            row = dict(item)
            if "find" not in row:
                row["find"] = row.pop("old", row.pop("old_text", row.pop("oldText", None)))
            if "replace" not in row:
                row["replace"] = row.pop("new", row.pop("new_text", row.pop("newText", None)))
            cleaned_edits.append(row)
        normalized["edits"] = cleaned_edits
        return normalized

    def _patch_submission_tool(self) -> List[Dict[str, Any]]:
        """A provider-native patch function used by focused code synthesis."""
        patch = {
            "type": "object", "properties": {
                "summary": {"type": "string"},
                "files": {"type": "array", "items": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"], "additionalProperties": False}},
                "edits": {"type": "array", "items": {"type": "object", "properties": {"path": {"type": "string"}, "find": {"type": "string"}, "replace": {"type": "string"}}, "required": ["path", "find", "replace"], "additionalProperties": False}},
                "insertions": {"type": "array", "items": {"type": "object", "properties": {"path": {"type": "string"}, "anchor": {"type": "string"}, "position": {"type": "string", "enum": ["before", "after"]}, "content": {"type": "string"}}, "required": ["path", "anchor", "content"], "additionalProperties": False}},
            },
            "required": ["summary", "files", "edits", "insertions"], "additionalProperties": False,
        }
        return [{"type": "function", "function": {
            "name": "chimera_submit_patch", "description": "Submit exactly one transactional candidate patch.",
            "parameters": patch,
        }}]
