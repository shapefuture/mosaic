
"""
AgentState — WAL+snapshots, watch streams, idempotency, leases, capability tokens

Per PRD §6.1/7.1/7.5: AgentState provides durable state via WAL+snapshot+hash-chain,
watch streams, and LTL verification hook.

Implements for Python harness:
- Snapshot: periodic dump of branch overlay + mount revisions, hash-chained
- Watch: subscribe to WAL kind, receive stream (like AgentState watch streams)
- Idempotency: dedup via idempotency key (seq+hash)
- Leases: simple advisory lease for branch commit (prevents concurrent commit)
- Capability tokens: scoped token for mount access (ReBAC from Nexus)
- LTL verify hook: agentstate-cli verify --property props/liveness.ltl.json
"""
from __future__ import annotations
import pathlib, json, time, hashlib, threading
from typing import Dict, List, Optional, Callable, Any

def _hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

class SnapshotStore:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.dir = self.root / ".chimera" / "snapshots"
        self.dir.mkdir(parents=True, exist_ok=True)

    def create(self, branch: str, meta: Dict, overlay_files: List[str]) -> str:
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        snap = {"branch": branch, "ts": ts, "meta": meta, "files": overlay_files, "hash": _hash(json.dumps(meta, sort_keys=True).encode())}
        path = self.dir / f"{branch}-{ts.replace(':','-')}.json"
        path.write_text(json.dumps(snap, indent=2))
        # also update latest pointer
        (self.dir / f"{branch}-latest.json").write_text(json.dumps(snap, indent=2))
        return snap["hash"]

    def latest(self, branch: str) -> Optional[Dict]:
        p = self.dir / f"{branch}-latest.json"
        if p.exists():
            return json.loads(p.read_text())
        return None

    def list(self, branch: Optional[str]=None) -> List[Dict]:
        out=[]
        for p in self.dir.glob("*.json"):
            if branch and not p.name.startswith(branch): continue
            if p.name.endswith("-latest.json"): continue
            out.append(json.loads(p.read_text()))
        return sorted(out, key=lambda x: x["ts"])

class WatchStream:
    """
    AgentState watch streams: subscribe to WAL kind, get live tail.
    Simulated via polling WAL file + callback.
    """
    def __init__(self, wal_path: pathlib.Path):
        self.wal_path = pathlib.Path(wal_path)
        self.subscribers: Dict[str, List[Callable]] = {}
        self._running = False
        self._thread: Optional[threading.Thread]=None
        # Watch callbacks are observers, never workflow authority. Preserve a
        # bounded diagnostic rather than silently swallowing observer faults.
        self.callback_errors: List[Dict[str, str]] = []

    def subscribe(self, kind: str, callback: Callable[[Dict], None]):
        self.subscribers.setdefault(kind, []).append(callback)
        self.subscribers.setdefault("*", [])

    def _poll(self):
        last_size=0
        while self._running:
            if self.wal_path.exists():
                size=self.wal_path.stat().st_size
                if size>last_size:
                    with open(self.wal_path) as f:
                        f.seek(last_size)
                        for line in f:
                            if not line.strip(): continue
                            e=json.loads(line)
                            for cb in self.subscribers.get(e.get("kind"), []):
                                try:
                                    cb(e)
                                except Exception as exc:
                                    self.callback_errors.append({"scope": str(e.get("kind")), "error": type(exc).__name__})
                            for cb in self.subscribers.get("*", []):
                                try:
                                    cb(e)
                                except Exception as exc:
                                    self.callback_errors.append({"scope": "*", "error": type(exc).__name__})
                            if len(self.callback_errors) > 128:
                                del self.callback_errors[:-128]
                    last_size=size
            time.sleep(0.5)

    def start(self):
        if self._running: return
        self._running=True
        self._thread=threading.Thread(target=self._poll, daemon=True)
        self._thread.start()

    def stop(self):
        self._running=False
        if self._thread:
            self._thread.join(timeout=1)

class LeaseManager:
    """Simple advisory lease for branch commit — prevents concurrent CAS"""
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.dir = self.root / ".chimera" / "leases"
        self.dir.mkdir(parents=True, exist_ok=True)

    def acquire(self, branch: str, holder: str, ttl_sec: int=30) -> bool:
        p = self.dir / f"{branch}.lease"
        now=time.time()
        if p.exists():
            try:
                data=json.loads(p.read_text())
                if now < data["expires"]:
                    return False  # held
            except Exception:
                pass
        p.write_text(json.dumps({"holder": holder, "acquired": now, "expires": now+ttl_sec}))
        return True

    def release(self, branch: str, holder: str) -> bool:
        p = self.dir / f"{branch}.lease"
        if p.exists():
            data=json.loads(p.read_text())
            if data.get("holder")==holder:
                p.unlink()
                return True
        return False

    def verify(self, branch: str) -> Optional[Dict]:
        p = self.dir / f"{branch}.lease"
        if p.exists():
            return json.loads(p.read_text())
        return None
