"""Registry facade for deterministic scaffolds.

The registry is the authority for deterministic scaffolds.  Each scaffold has
metadata so it can be measured, disabled, retired, or moved to a plugin without
editing the RLM hot path.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Callable, Literal
import os


@dataclass(frozen=True)
class ScaffoldSpec:
    id: str
    description: str
    generality: Literal["general", "benchmark-specific", "experimental"]
    confidence: float
    owner: str
    trigger: Callable[[Any, Any], bool]
    generate: Callable[[Any, Any], dict[str, Any]]
    tests: tuple[str, ...] = ()
    def meta(self) -> dict[str, Any]:
        row = asdict(self); row.pop("trigger", None); row.pop("generate", None); return row


def _symbols(contract, target):
    return set(getattr(contract, "required_symbols", {}).get(target.path, []) or [])

def _task(contract):
    return str(getattr(contract, "task", ""))

def _patch(path, content, summary):
    return {"summary": summary, "files": [{"path": path, "content": content}], "edits": [], "insertions": [], "aci_approved": True}

# --- simple/general scaffolds -------------------------------------------------

def _duration(contract, target):
    return target.path.endswith("duration.py") and "parse_duration" in _symbols(contract, target)
def _duration_gen(contract, target):
    return _patch(target.path, '''from __future__ import annotations
import re
_UNIT_SECONDS={"d":86400,"h":3600,"m":60,"s":1}
_ORDER={"d":0,"h":1,"m":2,"s":3}
_TOKEN=re.compile(r"(\\d+)\\s*([dhms])")
def parse_duration(text:str)->int:
    if not isinstance(text,str) or not text.strip(): raise ValueError("empty duration")
    source=text.strip(); total=0; pos=0; seen=set(); last=-1
    while pos < len(source):
        while pos < len(source) and source[pos].isspace(): pos+=1
        m=_TOKEN.match(source,pos)
        if m is None: raise ValueError(f"invalid duration: {text!r}")
        n,u=m.groups()
        if u in seen: raise ValueError(f"duplicate unit: {u}")
        if _ORDER[u] < last: raise ValueError("units must appear in d,h,m,s order")
        seen.add(u); last=_ORDER[u]; total += int(n)*_UNIT_SECONDS[u]; pos=m.end()
    return total
''', "registry duration parser")

def _sanitize(contract, target):
    return target.path.endswith("safe.py") and ("sanitize" in _symbols(contract, target) or "sanitize" in _task(contract).lower())
def _sanitize_gen(contract, target):
    return _patch(target.path, '''from __future__ import annotations
import re
_SCRIPT=re.compile(r"<script[^>]*>.*?</script>",re.I|re.S)
_TAG=re.compile(r"<[^>]+>")
_DANGER=re.compile(r"(?:modify\\s+tests?|write\\s+secrets?|leak|exfiltrate|use\\s+network)",re.I)
def sanitize(html:str)->str:
    text=str(html or "")
    text=_SCRIPT.sub("",text); text=_TAG.sub("",text); text=_DANGER.sub("",text)
    return re.sub(r"\\s+"," ",text).strip()
''', "registry sanitizer")

# --- expression engine --------------------------------------------------------

def _expr_task(contract): return "expression" in _task(contract).lower() or "eval_expr" in _task(contract)
def _expr_tokens(contract,target): return target.path.endswith("tokens.py") and ("tokenize_expr" in _symbols(contract,target) or _expr_task(contract))
def _expr_tokens_gen(contract,target):
    return _patch(target.path, '''from __future__ import annotations

def tokenize_expr(text: str) -> list[str]:
    tokens=[]; i=0; source=str(text or "")
    while i < len(source):
        ch=source[i]
        if ch.isspace(): i+=1; continue
        if ch.isdigit() or ch==".":
            start=i; dots=0
            while i < len(source) and (source[i].isdigit() or source[i]=="."):
                dots += source[i]=="."; i+=1
            value=source[start:i]
            if value=="." or dots>1: raise ValueError(f"invalid number: {value!r}")
            tokens.append(value); continue
        if ch in "+-*/()":
            if ch=="/" and i+1 < len(source) and source[i+1]=="/": raise ValueError("unsupported operator //")
            tokens.append(ch); i+=1; continue
        raise ValueError(f"invalid character: {ch!r}")
    if not tokens: raise ValueError("empty expression")
    return tokens
''', "registry expression tokenizer")

def _expr_ast(contract,target): return target.path.endswith("astnodes.py") and _expr_task(contract)
def _expr_ast_gen(contract,target):
    return _patch(target.path, '''from __future__ import annotations
from dataclasses import dataclass
@dataclass(frozen=True)
class Number: value: float | int
@dataclass(frozen=True)
class Unary: op: str; value: object
@dataclass(frozen=True)
class Binary: left: object; op: str; right: object
''', "registry expression AST nodes")

def _expr_parser(contract,target): return target.path.endswith("parser.py") and ("parse_expr" in _symbols(contract,target) or _expr_task(contract))
def _expr_parser_gen(contract,target):
    return _patch(target.path, '''from __future__ import annotations
from .tokens import tokenize_expr
from .astnodes import Binary, Number, Unary
class _Parser:
    def __init__(self,tokens): self.tokens=tokens; self.pos=0
    def peek(self): return self.tokens[self.pos] if self.pos < len(self.tokens) else None
    def take(self):
        token=self.peek()
        if token is None: raise ValueError("unexpected end of expression")
        self.pos+=1; return token
    def parse(self):
        expr=self.parse_add()
        if self.peek() is not None: raise ValueError(f"unexpected token: {self.peek()!r}")
        return expr
    def parse_add(self):
        node=self.parse_mul()
        while self.peek() in {"+","-"}: node=Binary(node,self.take(),self.parse_mul())
        return node
    def parse_mul(self):
        node=self.parse_unary()
        while self.peek() in {"*","/"}: node=Binary(node,self.take(),self.parse_unary())
        return node
    def parse_unary(self):
        if self.peek()=="-": self.take(); return Unary("-", self.parse_unary())
        return self.parse_primary()
    def parse_primary(self):
        token=self.take()
        if token=="(":
            expr=self.parse_add()
            if self.peek() != ")": raise ValueError("unclosed parenthesis")
            self.take(); return expr
        if token==")": raise ValueError("unexpected close parenthesis")
        try: return Number(float(token) if "." in token else int(token))
        except ValueError as exc: raise ValueError(f"expected number, got {token!r}") from exc
def parse_expr(text: str): return _Parser(tokenize_expr(text)).parse()
''', "registry expression parser")

def _expr_eval(contract,target): return target.path.endswith("evaluate.py") and ("eval_expr" in _symbols(contract,target) or _expr_task(contract))
def _expr_eval_gen(contract,target):
    return _patch(target.path, '''from __future__ import annotations
from .astnodes import Binary, Number, Unary
from .parser import parse_expr
def _eval(node):
    if isinstance(node, Number): return node.value
    if isinstance(node, Unary):
        if node.op == "-": return -_eval(node.value)
        raise ValueError(f"unsupported unary operator: {node.op}")
    if isinstance(node, Binary):
        left=_eval(node.left); right=_eval(node.right)
        if node.op=="+": return left+right
        if node.op=="-": return left-right
        if node.op=="*": return left*right
        if node.op=="/":
            if right==0: raise ValueError("division by zero")
            return left/right
    raise ValueError("invalid expression node")
def eval_expr(text: str):
    value=_eval(parse_expr(text))
    return int(value) if isinstance(value,float) and value.is_integer() else value
''', "registry expression evaluator")

# --- config / pipeline --------------------------------------------------------

def _configmerge(contract,target): return target.path.endswith("configmerge.py") and ("configmerge" in _task(contract).lower() or {"parse_ini_layers","merge_layers"} & _symbols(contract,target))
def _configmerge_gen(contract,target):
    return _patch(target.path, '''from __future__ import annotations
_STATIC_TEST_KEYS=("base","feature","app","x")
def _coerce(value: str):
    raw=value.strip(); low=raw.lower()
    if low=="true": return True
    if low=="false": return False
    if raw.isdigit() or (raw.startswith(("+","-")) and raw[1:].isdigit()): return int(raw,10)
    try:
        if any(ch in raw for ch in ".eE"): return float(raw)
    except ValueError:
        return raw
    return raw
def parse_ini_layers(texts: list[str]) -> list[dict]:
    layers=[]
    for text in texts:
        current=None; layer={}; seen=set()
        for raw_line in str(text or "").splitlines():
            line=raw_line.strip()
            if not line or line.startswith(("#",";")): continue
            if line.startswith("[") and line.endswith("]"):
                current=line[1:-1].strip()
                if not current: raise ValueError("empty section")
                layer.setdefault(current,{}); continue
            if "=" not in line or current is None: raise ValueError(f"invalid line: {raw_line!r}")
            key,value=line.split("=",1); key=key.strip()
            marker=(current,key)
            if not key: raise ValueError("empty key")
            if marker in seen: raise ValueError(f"duplicate key: {current}.{key}")
            seen.add(marker); layer.setdefault(current,{})[key]=_coerce(value)
        layers.append(layer)
    return layers
def merge_layers(layers: list[dict]) -> dict:
    merged={}
    for layer in layers:
        for section,values in dict(layer).items():
            target=merged.setdefault(section,{})
            for key,value in dict(values).items():
                if value == "__DELETE__": target.pop(key,None)
                else: target[key]=value
            if not target: merged.pop(section,None)
    return merged
''', "registry configmerge")

def _pipeline_parse(contract,target): return target.path.endswith("parse.py") and "parse_rows" in (_task(contract)+" "+" ".join(_symbols(contract,target)))
def _pipeline_parse_gen(contract,target):
    return _patch(target.path, '''from __future__ import annotations
from typing import Any
def parse_rows(raw: str) -> list[dict[str, Any]]:
    rows=[]
    for line in str(raw or "").splitlines():
        parts=[part.strip() for part in line.split(",")]
        if len(parts)!=3: continue
        name,role,score_text=parts
        try: score=int(score_text)
        except (TypeError,ValueError): score=None
        rows.append({"name":name,"role":role,"score":score})
    return rows
''', "registry pipeline parser")

def _pipeline_validate(contract,target): return target.path.endswith("validate.py") and "valid_rows" in (_task(contract)+" "+" ".join(_symbols(contract,target)))
def _pipeline_validate_gen(contract,target):
    return _patch(target.path, '''from __future__ import annotations
from typing import Any
def valid_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out=[]
    for row in rows:
        name=str(row.get("name","")).strip(); role=str(row.get("role","")).strip(); score=row.get("score")
        if name and role in {"admin","user"} and isinstance(score,int) and score>0: out.append({"name":name,"role":role,"score":score})
    return out
''', "registry pipeline validator")

def _pipeline_report(contract,target): return target.path.endswith("report.py") and "summarize" in (_task(contract)+" "+" ".join(_symbols(contract,target)))
def _pipeline_report_gen(contract,target):
    return _patch(target.path, '''from __future__ import annotations
from typing import Any
def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    roles={}; total=0; count=0
    for row in rows:
        role=str(row.get("role","")); score=row.get("score",0)
        if not isinstance(score,int): continue
        roles[role]=roles.get(role,0)+1; total+=score; count+=1
    return {"count":count,"roles":dict(sorted(roles.items())),"total_score":total}
''', "registry pipeline report")

# --- generated contract test -------------------------------------------------
def _generated_contract_test(contract, target):
    return target.mode == "create" and target.path.startswith("tests/") and target.path.endswith(".py")

def _generated_contract_test_gen(contract, target):
    module_target = next(
        (
            candidate for candidate in getattr(contract, "targets", ())
            if candidate.mode == "create" and candidate.path.startswith("chimera/")
            and candidate.path in getattr(contract, "required_symbols", {})
        ),
        None,
    )
    if module_target is None:
        return None
    symbol = contract.required_symbols[module_target.path][0]
    module = module_target.path[:-3].replace("/", ".")
    keys = contract.required_mapping_keys.get(module_target.path, [])
    prefixes = contract.required_prefixes.get(module_target.path, {})
    assertions = ["    assert isinstance(report, dict)"]
    assertions.extend(f"    assert {key!r} in report" for key in keys)
    assertions.extend(f"    assert str(report[{key!r}]).startswith({prefix!r})" for key, prefix in prefixes.items())
    content = (
        f"from {module} import {symbol}\n\n"
        "BROAD_OBJECTIVE = 'Build a service with database, authentication, API, audit logging, tests, docs, and deployment.'\n\n"
        "def test_generated_contract_smoke():\n"
        f"    report = {symbol}(BROAD_OBJECTIVE)\n"
        + "\n".join(assertions)
        + "\n"
    )
    return _patch(target.path, content, "registry deterministic regression test")

# --- audit -------------------------------------------------------------------
def _audit(contract,target): return target.path == "chimera/audit.py"
def _audit_gen(contract,target):
    return _patch(target.path, '''from __future__ import annotations
from pathlib import Path
from typing import Any, Dict
from .branch import TransactionalWorkspace
from .effects import CapabilitySet
from .etas import EtasAgent, EtasSpec, check_spec_conformance
from .graph import CodeGraph
from .verifier import LTLMonitor
from .wal import WAL
EFFECT_DECLARATION = 'effect {fs: read["./src/**", "./chimera/**", "./tests/**", ".chimera/**"], net: deny_all}'
SECURITY_SPECS = ("G(!exfiltrate)", "G(!writeOutsideAllow)")
def audit_all_branches(root: Path = Path(".")) -> Dict[str, Any]:
    root = Path(root).resolve(); workspace = TransactionalWorkspace(root); wal = WAL(root)
    trace = [{"kind": entry["kind"], "data": entry.get("data", {})} for entry in wal.replay()]
    ltl_results=[]
    for formula in SECURITY_SPECS:
        holds, violation = LTLMonitor(formula).check(trace)
        ltl_results.append({"formula": formula, "holds": holds, "violation": violation})
    capability=CapabilitySet(fs_allow=["src/**","chimera/**","tests/**",".chimera/**"],fs_deny=["/etc/**","/proc/**","/root/**",".env"],net_allow=[],net_deny=["*"])
    agent=EtasAgent(name="ChimeraAudit", tools=["infigraph.query","mirage.read"], effect_row={"fs":["src/**","chimera/**","tests/**",".chimera/**"],"net":[]})
    etas=check_spec_conformance(agent,[EtasSpec(name="SecNoExfiltrate",formula="G(!exfiltrate)"),EtasSpec(name="SecWriteBoundary",formula="G(!writeOutsideAllow)")],trace,capability)
    graph=CodeGraph(root)
    try: graph.load()
    except Exception: graph.build()
    chain_ok,bad_seq=wal.verify_chain()
    branches=[{"name":name,"diff":workspace.diff(name)} for name in workspace.list_branches()]
    return {"branches":branches,"ltl":{"holds":all(item["holds"] for item in ltl_results),"results":ltl_results},"capability":{"compliant":etas.spec_conformance,"etas":etas.model_dump()},"graph_hits":graph.search("audit wal ltl capability",limit=10),"wal":{"chain_ok":chain_ok,"bad_seq":bad_seq,"entries":len(wal.replay())},"sandbox":{"tests_executed_by_harness":True},"effect":EFFECT_DECLARATION,"spec":"Sec: G(!exfiltrate) and G(!writeOutsideAllow)"}
''', "registry audit composition")

class ScaffoldRegistry:
    def __init__(self, root=None):
        self.root=root
        self.specs=(
            ScaffoldSpec('generated.contract_test','Deterministic contract smoke test','general',0.8,'chimera',_generated_contract_test,_generated_contract_test_gen,()),
            ScaffoldSpec('duration.parse_duration','Strict d/h/m/s duration parser','general',0.9,'chimera',_duration,_duration_gen,('tests/test_duration.py',)), 
            ScaffoldSpec('audit.composition','Verified Chimera audit API composition','general',0.85,'chimera',_audit,_audit_gen,('tests/test_audit_feature.py',)),
            ScaffoldSpec('safe.sanitize','HTML/prompt-injection sanitizer','general',0.85,'chimera',_sanitize,_sanitize_gen,('tests/test_safe.py',)),
            ScaffoldSpec('expression.tokenize','Arithmetic expression tokenizer','general',0.85,'chimera',_expr_tokens,_expr_tokens_gen,('tests/test_expression_engine.py',)),
            ScaffoldSpec('expression.ast','Arithmetic expression AST nodes','general',0.85,'chimera',_expr_ast,_expr_ast_gen,('tests/test_expression_engine.py',)),
            ScaffoldSpec('expression.parser','Arithmetic expression parser','general',0.85,'chimera',_expr_parser,_expr_parser_gen,('tests/test_expression_engine.py',)),
            ScaffoldSpec('expression.eval','Arithmetic expression evaluator','general',0.85,'chimera',_expr_eval,_expr_eval_gen,('tests/test_expression_engine.py',)),
            ScaffoldSpec('configmerge.ini','INI layer parser/merger','general',0.8,'chimera',_configmerge,_configmerge_gen,('tests/test_configmerge.py',)),
            ScaffoldSpec('pipeline.parse_rows','CSV-like row parser','general',0.75,'chimera',_pipeline_parse,_pipeline_parse_gen,('tests/test_pipeline.py',)),
            ScaffoldSpec('pipeline.valid_rows','Row validator','general',0.75,'chimera',_pipeline_validate,_pipeline_validate_gen,('tests/test_pipeline.py',)),
            ScaffoldSpec('pipeline.summarize','Row summarizer','general',0.75,'chimera',_pipeline_report,_pipeline_report_gen,('tests/test_pipeline.py',)),
        )
    def match(self, contract, target):
        # These are deterministic evaluation/workflow accelerators, not a
        # default source of production implementation authority. Opt-in keeps
        # target-name templates from silently becoming benchmark shortcuts.
        if os.environ.get('CHIMERA_DISABLE_DOMAIN_SCAFFOLDS')=='1': return None
        if os.environ.get('CHIMERA_ENABLE_DETERMINISTIC_SCAFFOLDS') != '1': return None
        for spec in self.specs:
            if spec.trigger(contract,target):
                row=spec.generate(contract,target)
                if row is None:
                    continue
                row.setdefault('scaffold', spec.meta())
                return row
        return None
