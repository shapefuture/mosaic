"""Durable goals, bounded execution, structured verification, and revocable autonomy."""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
import os
import pathlib
import shlex
import signal
import subprocess
import sys
import threading
import time
import uuid
from typing import Any, Callable, Dict, Iterator, List, Literal, Optional

from pydantic import BaseModel, Field, field_validator

from .autonomy_execution import ManagedGoalStepPort, ManagedStepResult
from .autonomy_lease import AutonomyLeaseLedger
from .host_admission import HostAdmissionGate
from .wal import WAL


class GoalBudget(BaseModel):
    max_turns: int = Field(default=12, ge=1)
    max_tokens: int = Field(default=80_000, ge=0)
    max_seconds: int = Field(default=1_800, ge=1)


class GoalGate(BaseModel):
    """A deliberately small verification command grammar.

    Goal records are durable data, not a shell-script execution surface.  The
    only supported legacy forms are ``test -[efd] RELATIVE_PATH`` and a bounded
    ``pytest`` invocation.  This keeps a model-modified goal record from turning
    a shell execution path into host-command authority.
    """

    argv: tuple[str, ...]
    timeout_seconds: int = Field(default=300, ge=1, le=600)

    @field_validator("argv")
    @classmethod
    def _argv_is_verification_only(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        argv = tuple(str(item) for item in value)
        if not argv or any(not item or "\x00" in item for item in argv):
            raise ValueError("goal gate requires a non-empty argv")
        command = pathlib.PurePosixPath(argv[0]).name
        if command == "test":
            if len(argv) != 3 or argv[1] not in {"-e", "-f", "-d"} or not _safe_relative(argv[2]):
                raise ValueError("test gates must be exactly: test -e|-f|-d RELATIVE_PATH")
            return argv
        if command in {"pytest", "py.test"}:
            for item in argv[1:]:
                if item in {"-q", "-x"}:
                    continue
                if item.startswith("-") or not _safe_relative(item):
                    raise ValueError("pytest gates permit only -q, -x, and relative test paths")
            return argv
        raise ValueError("goal gates support only test and pytest verification")

    @classmethod
    def from_legacy_command(cls, command: str) -> "GoalGate":
        text = str(command)
        if not text.strip() or any(token in text for token in (";", "|", "&", "$", "`", "\n", "\r", "<", ">")):
            raise ValueError("shell syntax is not permitted in a goal gate")
        try:
            argv = tuple(shlex.split(text, posix=True))
        except ValueError as exc:
            raise ValueError(f"invalid goal gate syntax: {exc}") from exc
        return cls(argv=argv)


class GoalRecord(BaseModel):
    id: str
    objective: str
    branch: str
    model: str
    status: Literal["active", "paused", "complete", "failed", "cancelled"] = "active"
    created_at: str
    updated_at: str
    budget: GoalBudget = Field(default_factory=GoalBudget)
    used_turns: int = 0
    used_tokens: int = 0
    elapsed_seconds: float = 0.0
    progress: List[Dict[str, Any]] = Field(default_factory=list)
    gates: List[GoalGate] = Field(default_factory=list)
    last_heartbeat: Optional[str] = None
    result_ref: Optional[str] = None

    @field_validator("gates", mode="before")
    @classmethod
    def _migrate_legacy_gates(cls, value: Any) -> list[Any]:
        if value is None:
            return []
        if not isinstance(value, list):
            raise ValueError("goal gates must be a list")
        output: list[Any] = []
        for item in value:
            if isinstance(item, str):
                output.append(GoalGate.from_legacy_command(item).model_dump(mode="json"))
            else:
                output.append(item)
        return output


class ScheduleRecord(BaseModel):
    id: str
    goal_id: str
    run_at: float
    interval_seconds: Optional[int] = Field(default=None, ge=1)
    enabled: bool = True
    last_run: Optional[float] = None
    # A claim is durable before a worker receives the callback.  If a process
    # dies while it owns a claim, Chimera records an unknown outcome rather than
    # silently issuing the effectful callback a second time.
    claim_id: Optional[str] = None
    claim_expires_at: Optional[float] = None
    recovery_state: Literal["ready", "claimed", "unknown"] = "ready"


class ScheduleClaim(BaseModel):
    schedule_id: str
    goal_id: str
    claim_id: str
    claimed_at: float
    expires_at: float


class GoalStore:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.dir = self.root / ".chimera" / "goals"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.schedules_path = self.dir / "schedules.json"
        self.schedules_lock_path = self.dir / "schedules.lock"
        self._schedule_guard = threading.RLock()
        self.wal = WAL(self.root)

    @contextmanager
    def _schedules_locked(self) -> Iterator[None]:
        """Serialize durable schedule claims across processes where supported."""
        with self._schedule_guard:
            handle = self.schedules_lock_path.open("a+b")
            try:
                try:
                    import fcntl
                except ImportError:  # pragma: no cover - non-POSIX fallback
                    fcntl = None
                if fcntl is not None:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
                yield
            finally:
                try:
                    if fcntl is not None:
                        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
                finally:
                    handle.close()

    @staticmethod
    def _id(objective: str, branch: str) -> str:
        return "goal-" + hashlib.sha256(f"{objective}:{branch}:{time.time_ns()}".encode()).hexdigest()[:12]

    def _path(self, goal_id: str) -> pathlib.Path:
        return self.dir / f"{goal_id}.json"

    def create(self, objective: str, branch: str, model: str, budget: Optional[GoalBudget] = None,
               gates: Optional[List[GoalGate | str]] = None) -> GoalRecord:
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        goal = GoalRecord(
            id=self._id(objective, branch), objective=objective, branch=branch, model=model,
            created_at=now, updated_at=now, budget=budget or GoalBudget(), gates=gates or [],
        )
        self.save(goal)
        self.wal.append("goal_create", {
            "goal": goal.id,
            "branch": branch,
            "model": model,
            "subject_hash": goal_subject_hash(goal),
        })
        return goal

    def save(self, goal: GoalRecord) -> None:
        goal.updated_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        temp = self._path(goal.id).with_suffix(".tmp")
        temp.write_text(goal.model_dump_json(indent=2), encoding="utf-8")
        temp.replace(self._path(goal.id))

    def get(self, goal_id: str) -> GoalRecord:
        path = self._path(goal_id)
        if not path.exists():
            raise KeyError(goal_id)
        return GoalRecord.model_validate_json(path.read_text(encoding="utf-8"))

    def list(self, status: Optional[str] = None) -> List[GoalRecord]:
        goals = [GoalRecord.model_validate_json(path.read_text(encoding="utf-8")) for path in self.dir.glob("goal-*.json")]
        if status:
            goals = [goal for goal in goals if goal.status == status]
        return sorted(goals, key=lambda goal: goal.updated_at, reverse=True)

    def heartbeat(self, goal_id: str, detail: str = "") -> GoalRecord:
        goal = self.get(goal_id)
        goal.last_heartbeat = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        if detail:
            goal.progress.append({"ts": goal.last_heartbeat, "kind": "heartbeat", "detail": detail})
        self.save(goal)
        self.wal.append("goal_heartbeat", {"goal": goal.id, "detail": detail[:200]})
        return goal

    def update(self, goal_id: str, *, turns: int = 0, tokens: int = 0, elapsed: float = 0,
               detail: str = "") -> GoalRecord:
        goal = self.get(goal_id)
        goal.used_turns += max(0, turns)
        goal.used_tokens += max(0, tokens)
        goal.elapsed_seconds += max(0, elapsed)
        if detail:
            goal.progress.append({
                "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "kind": "progress", "detail": detail,
            })
        if self.exhausted(goal):
            goal.status = "paused"
            goal.progress.append({
                "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "kind": "budget", "detail": "budget exhausted; not marked complete",
            })
        self.save(goal)
        return goal

    @staticmethod
    def exhausted(goal: GoalRecord) -> bool:
        return (
            goal.used_turns >= goal.budget.max_turns
            or goal.used_tokens >= goal.budget.max_tokens
            or goal.elapsed_seconds >= goal.budget.max_seconds
        )

    def transition(self, goal_id: str, status: Literal["active", "paused", "complete", "failed", "cancelled"], result_ref: Optional[str] = None) -> GoalRecord:
        goal = self.get(goal_id)
        goal.status = status
        goal.result_ref = result_ref or goal.result_ref
        self.save(goal)
        self.wal.append("goal_transition", {"goal": goal.id, "status": status, "result_ref": result_ref})
        return goal

    def pause_for_policy(self, goal_id: str, reason: str) -> GoalRecord:
        """Record an authority/budget stop without pretending the goal completed."""
        goal = self.get(goal_id)
        goal.status = "paused"
        goal.progress.append({
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "kind": "policy",
            "detail": str(reason)[:500],
        })
        self.save(goal)
        self.wal.append("goal_policy_pause", {"goal": goal.id, "reason": str(reason)[:300]})
        return goal

    def _load_schedules(self) -> List[ScheduleRecord]:
        if not self.schedules_path.exists():
            return []
        try:
            raw = json.loads(self.schedules_path.read_text(encoding="utf-8"))
            return [ScheduleRecord.model_validate(item) for item in raw]
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"schedule projection is unreadable or invalid: {type(exc).__name__}: {exc}") from exc

    def _save_schedules(self, schedules: List[ScheduleRecord]) -> None:
        payload = (json.dumps([item.model_dump(mode="json") for item in schedules], indent=2, sort_keys=True) + "\n").encode("utf-8")
        temporary = self.schedules_path.with_name(f".{self.schedules_path.name}.{uuid.uuid4().hex}.tmp")
        try:
            with temporary.open("wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.schedules_path)
        finally:
            if temporary.exists():
                temporary.unlink()

    def schedule(self, goal_id: str, run_at: float, interval_seconds: Optional[int] = None) -> ScheduleRecord:
        self.get(goal_id)
        schedule = ScheduleRecord(
            id="schedule-" + hashlib.sha256(f"{goal_id}:{run_at}".encode()).hexdigest()[:10],
            goal_id=goal_id, run_at=run_at, interval_seconds=interval_seconds,
        )
        with self._schedules_locked():
            schedules = [item for item in self._load_schedules() if item.id != schedule.id]
            schedules.append(schedule)
            self._save_schedules(schedules)
        self.wal.append("schedule_create", schedule.model_dump(mode="json"))
        return schedule

    def due(self, now: Optional[float] = None) -> List[ScheduleRecord]:
        current = time.time() if now is None else float(now)
        with self._schedules_locked():
            return [
                item for item in self._load_schedules()
                if item.enabled and item.run_at <= current and item.claim_id is None and item.recovery_state == "ready"
            ]

    def claim_due(self, *, now: float | None = None, lease_seconds: float = 300.0) -> list[ScheduleClaim]:
        """Durably claim due work before it reaches a background callback.

        An expired old claim is terminally marked ``unknown`` and disabled.  The
        scheduler may not assume that a process crash happened before the
        callback's effects, so it never auto-replays the item.
        """
        if lease_seconds <= 0:
            raise ValueError("schedule claim lease must be positive")
        current = time.time() if now is None else float(now)
        claims: list[ScheduleClaim] = []
        unknown: list[dict[str, Any]] = []
        with self._schedules_locked():
            schedules = self._load_schedules()
            changed = False
            for item in schedules:
                if not item.enabled:
                    continue
                if item.claim_id is not None:
                    if item.claim_expires_at is not None and item.claim_expires_at <= current:
                        unknown.append({"schedule_id": item.id, "goal_id": item.goal_id, "claim_id": item.claim_id})
                        item.enabled = False
                        item.recovery_state = "unknown"
                        item.claim_id = None
                        item.claim_expires_at = None
                        changed = True
                    continue
                if item.recovery_state != "ready" or item.run_at > current:
                    continue
                claim_id = "schedule-claim:" + uuid.uuid4().hex
                expires_at = current + float(lease_seconds)
                item.claim_id = claim_id
                item.claim_expires_at = expires_at
                item.recovery_state = "claimed"
                claims.append(ScheduleClaim(
                    schedule_id=item.id, goal_id=item.goal_id, claim_id=claim_id,
                    claimed_at=current, expires_at=expires_at,
                ))
                changed = True
            if changed:
                self._save_schedules(schedules)
        for row in unknown:
            self.wal.append("goal_schedule", {"event": "unknown_after_expired_claim", **row})
        for claim in claims:
            self.wal.append("goal_schedule", {"event": "claimed", **claim.model_dump(mode="json")})
        return claims

    def complete_schedule_claim(self, claim: ScheduleClaim, *, now: float | None = None, outcome: str = "known") -> bool:
        """Complete exactly the durable claim that dispatched the callback."""
        current = time.time() if now is None else float(now)
        completed = False
        with self._schedules_locked():
            schedules = self._load_schedules()
            for item in schedules:
                if item.id != claim.schedule_id:
                    continue
                if item.goal_id != claim.goal_id or item.claim_id != claim.claim_id or item.recovery_state != "claimed":
                    return False
                item.last_run = current
                item.claim_id = None
                item.claim_expires_at = None
                item.recovery_state = "ready"
                if item.interval_seconds:
                    item.run_at = current + item.interval_seconds
                else:
                    item.enabled = False
                self._save_schedules(schedules)
                completed = True
                break
        if completed:
            self.wal.append("goal_schedule", {
                "event": "completed", "schedule_id": claim.schedule_id, "goal_id": claim.goal_id,
                "claim_id": claim.claim_id, "outcome": str(outcome)[:80],
            })
        return completed

    def mark_schedule_run(self, schedule_id: str, now: Optional[float] = None) -> None:
        """Legacy direct completion helper; claimed schedules require their exact claim."""
        current = time.time() if now is None else float(now)
        with self._schedules_locked():
            schedules = self._load_schedules()
            for item in schedules:
                if item.id == schedule_id:
                    if item.claim_id is not None:
                        raise RuntimeError("claimed schedules must be completed with complete_schedule_claim")
                    item.last_run = current
                    if item.interval_seconds:
                        item.run_at = current + item.interval_seconds
                    else:
                        item.enabled = False
            self._save_schedules(schedules)


class AutonomousController:
    """Continue within deterministic budgets; autonomous dispatch also needs a lease.

    ``run`` is a foreground, caller-owned loop retained for the existing Python
    API.  Callable ``run_background`` remains a cooperative compatibility path.
    A scheduler/daemon must call ``run_background_managed`` with a managed local
    process port: it checks a fresh exact-subject lease before dispatch and while
    the child runs, then terminates its process group on revocation/timeout.  The
    receipt proves local process-group termination only, never remote-provider
    cancellation or billing termination.
    """

    def __init__(
        self,
        store: GoalStore,
        autonomy_leases: AutonomyLeaseLedger | None = None,
        host_admission: HostAdmissionGate | None = None,
    ):
        self.store = store
        self.autonomy_leases = autonomy_leases
        # No OS/presence probe is constructed implicitly.  A caller must opt in
        # by supplying a gate whose policy itself is enabled.
        self.host_admission = host_admission

    @staticmethod
    def run_gate(gate: GoalGate | str, cwd: pathlib.Path, timeout: int | None = None) -> Dict[str, Any]:
        """Run only a structured verification gate, never a shell string."""
        try:
            spec = GoalGate.from_legacy_command(gate) if isinstance(gate, str) else gate
        except (TypeError, ValueError) as exc:
            return {"command": str(gate), "status": 126, "stdout": "", "stderr": f"gate rejected: {exc}", "executed": False}
        root = pathlib.Path(cwd).resolve()
        seconds = min(spec.timeout_seconds, int(timeout)) if timeout is not None else spec.timeout_seconds
        command = pathlib.PurePosixPath(spec.argv[0]).name
        if command == "test":
            target = _resolve_gate_path(root, spec.argv[2])
            if target is None:
                return {"command": list(spec.argv), "status": 126, "stdout": "", "stderr": "gate path escapes workspace", "executed": False}
            flag = spec.argv[1]
            passed = target.exists() if flag == "-e" else target.is_file() if flag == "-f" else target.is_dir()
            return {"command": list(spec.argv), "status": 0 if passed else 1, "stdout": "", "stderr": "", "executed": False, "backend": "builtin-path-check"}

        argv = [sys.executable, "-m", "pytest", *spec.argv[1:]]
        started = time.time()
        process: subprocess.Popen[str] | None = None
        try:
            process = subprocess.Popen(
                argv, shell=False, cwd=str(root), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, start_new_session=True,
            )
            try:
                stdout, stderr = process.communicate(timeout=max(1, seconds))
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    process.kill()
                stdout, stderr = process.communicate(timeout=5)
                return {
                    "command": argv, "status": 124, "stdout": (stdout or "")[-4000:],
                    "stderr": ("gate timeout\n" + (stderr or ""))[-4000:], "executed": True,
                    "duration_ms": int((time.time() - started) * 1000), "process_group_killed": True,
                }
            return {
                "command": argv, "status": int(process.returncode), "stdout": (stdout or "")[-4000:],
                "stderr": (stderr or "")[-4000:], "executed": True,
                "duration_ms": int((time.time() - started) * 1000),
            }
        except OSError as exc:
            return {"command": argv, "status": 1, "stdout": "", "stderr": f"gate launch failed: {type(exc).__name__}: {exc}", "executed": False}

    def run(self, goal_id: str, step: Callable[[GoalRecord], Dict[str, Any]]) -> Dict[str, Any]:
        """Foreground execution; the caller itself owns the start decision."""
        return self._run(goal_id, step, background=False)

    def run_background(self, goal_id: str, step: Callable[[GoalRecord], Dict[str, Any]]) -> Dict[str, Any]:
        """Cooperative compatibility path; use managed execution for schedulers."""
        return self._run(goal_id, step, background=True)

    def run_background_managed(
        self,
        goal_id: str,
        step_port: ManagedGoalStepPort,
        *,
        poll_interval_seconds: float = 0.10,
    ) -> Dict[str, Any]:
        """Run a scheduled step in a cancellable local process group.

        The method owns the observation loop.  A lease/host-policy loss or
        deadline sends termination through the port, waits for its terminal
        process-group receipt, and treats an unconfirmed termination as an
        unknown outcome rather than a successful cancellation.
        """
        if poll_interval_seconds <= 0:
            raise ValueError("poll_interval_seconds must be positive")
        started = time.monotonic()
        iterations: list[Dict[str, Any]] = []
        while True:
            goal = self.store.get(goal_id)
            if goal.status != "active" or self.store.exhausted(goal):
                break
            blocked = self._admit_background(goal)
            if blocked is not None:
                blocked.update({"iterations": iterations, "elapsed": time.monotonic() - started, "execution_outcome": "not-dispatched"})
                return blocked
            try:
                handle = step_port.start(goal)
            except Exception as exc:
                failed = self.store.transition(goal_id, "failed")
                self.store.wal.append("goal_managed_step", {
                    "event": "start_failed", "goal": goal_id, "port": type(step_port).__name__,
                    "error_type": type(exc).__name__,
                })
                return {
                    "status": failed.status, "iterations": iterations,
                    "reason": f"managed step failed to start: {type(exc).__name__}",
                    "execution_outcome": "failed", "elapsed": time.monotonic() - started,
                }
            self.store.wal.append("goal_managed_step", {
                "event": "started", "goal": goal_id, "port": type(step_port).__name__,
                "max_runtime_seconds": float(step_port.max_runtime_seconds),
            })
            remaining_goal_seconds = max(0.1, goal.budget.max_seconds - goal.elapsed_seconds)
            deadline = time.monotonic() + min(float(step_port.max_runtime_seconds), remaining_goal_seconds)
            result: ManagedStepResult | None = None
            cancellation: Dict[str, Any] | None = None
            while result is None:
                current_goal = self.store.get(goal_id)
                blocked = self._admit_background(current_goal)
                if blocked is not None:
                    receipt = handle.cancel(blocked["reason"])
                    cancellation = receipt.as_dict()
                    self.store.wal.append("goal_managed_step", {
                        "event": "cancel_requested", "goal": goal_id, "reason": blocked["reason"],
                        "receipt": cancellation,
                    })
                    if receipt.terminal:
                        blocked.update({
                            "iterations": iterations,
                            "elapsed": time.monotonic() - started,
                            "execution_outcome": "cancelled",
                            "cancellation": cancellation,
                        })
                    else:
                        blocked.update({
                            "iterations": iterations,
                            "elapsed": time.monotonic() - started,
                            "execution_outcome": "unknown",
                            "cancellation": cancellation,
                            "reason": f"{blocked['reason']}; local process-group termination was not confirmed",
                        })
                    return blocked
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    reason = "managed step deadline exceeded"
                    paused = self.store.pause_for_policy(goal_id, reason)
                    receipt = handle.cancel(reason)
                    cancellation = receipt.as_dict()
                    self.store.wal.append("goal_managed_step", {
                        "event": "deadline_cancel_requested", "goal": goal_id, "receipt": cancellation,
                    })
                    return {
                        "status": paused.status,
                        "iterations": iterations,
                        "reason": reason if receipt.terminal else reason + "; local process-group termination was not confirmed",
                        "execution_outcome": "cancelled" if receipt.terminal else "unknown",
                        "cancellation": cancellation,
                        "elapsed": time.monotonic() - started,
                    }
                result = handle.wait(min(float(poll_interval_seconds), remaining))

            self.store.wal.append("goal_managed_step", {
                "event": "terminal", "goal": goal_id, "state": result.state,
                "returncode": result.returncode, "duration_seconds": result.duration_seconds,
                "stdout_path": result.stdout_path, "stderr_path": result.stderr_path,
            })
            # A process may have exited in the interval between the last poll and
            # this observation.  Check authority once more before accepting its
            # payload or dispatching any verifier.
            after = self._admit_background(self.store.get(goal_id))
            if after is not None:
                after.update({
                    "iterations": iterations,
                    "elapsed": time.monotonic() - started,
                    "execution_outcome": "unknown",
                    "reason": f"{after['reason']}; managed step reached terminal state after policy loss",
                })
                return after
            if result.state != "completed":
                failed = self.store.transition(goal_id, "failed")
                return {
                    "status": failed.status, "iterations": iterations,
                    "reason": f"managed step terminal state: {result.state}",
                    "execution_outcome": "failed" if result.state == "failed" else "unknown",
                    "managed_result": result.__dict__, "elapsed": time.monotonic() - started,
                }
            payload = dict(result.payload)
            try:
                reported_turns = int(payload.get("turns", 1))
            except (TypeError, ValueError):
                reported_turns = 1
            try:
                tokens = max(0, int(payload.get("tokens", 0)))
            except (TypeError, ValueError):
                tokens = 0
            self.store.update(
                goal_id, turns=max(1, reported_turns), tokens=tokens,
                elapsed=result.duration_seconds,
                detail=str(payload.get("detail", "managed step completed"))[:500],
            )
            iterations.append(payload)
            goal = self.store.get(goal_id)
            after = self._admit_background(goal) if goal.status == "active" else None
            if after is not None:
                after.update({
                    "iterations": iterations,
                    "elapsed": time.monotonic() - started,
                    "execution_outcome": "unknown",
                    "reason": f"{after['reason']}; verifier dispatch was withheld",
                })
                return after
            gate_results = [self.run_gate(gate, self.store.root) for gate in goal.gates]
            if goal.gates and all(item["status"] == 0 for item in gate_results):
                self.store.transition(goal_id, "complete", result_ref=payload.get("result_ref"))
                return {
                    "status": "complete", "iterations": iterations, "gates": gate_results,
                    "execution_outcome": "completed", "elapsed": time.monotonic() - started,
                }
            if payload.get("stop"):
                final = self.store.pause_for_policy(goal_id, "managed step requested stop; completion was not inferred")
                return {
                    "status": final.status, "iterations": iterations, "gates": gate_results,
                    "reason": "managed step requested stop; completion not inferred",
                    "execution_outcome": "completed", "elapsed": time.monotonic() - started,
                }
        final = self.store.get(goal_id)
        return {
            "status": final.status, "iterations": iterations,
            "reason": "budget/status reached; completion not inferred",
            "execution_outcome": "completed" if final.status == "complete" else "not-dispatched",
            "elapsed": time.monotonic() - started,
        }

    def _admit_background(self, goal: GoalRecord) -> Dict[str, Any] | None:
        if self.autonomy_leases is None:
            paused = self.store.pause_for_policy(goal.id, "background execution requires an autonomy lease ledger")
            return {"status": paused.status, "reason": "background execution requires an autonomy lease ledger", "policy": {"allowed": False}}
        decision = self.autonomy_leases.check(goal_id=goal.id, subject_hash=goal_subject_hash(goal))
        if not decision.allowed:
            paused = self.store.pause_for_policy(goal.id, decision.reason)
            return {"status": paused.status, "reason": decision.reason, "policy": decision.model_dump(mode="json")}
        if self.host_admission is not None:
            host = self.host_admission.check()
            if not host.allowed:
                paused = self.store.pause_for_policy(goal.id, host.reason)
                return {
                    "status": paused.status,
                    "reason": host.reason,
                    "policy": {"lease": decision.model_dump(mode="json"), "host_admission": host.model_dump(mode="json")},
                }
        return None

    def _run(self, goal_id: str, step: Callable[[GoalRecord], Dict[str, Any]], *, background: bool) -> Dict[str, Any]:
        started = time.time()
        iterations: list[Dict[str, Any]] = []
        while True:
            goal = self.store.get(goal_id)
            if goal.status != "active" or self.store.exhausted(goal):
                break
            if background:
                blocked = self._admit_background(goal)
                if blocked is not None:
                    blocked.update({"iterations": iterations, "elapsed": time.time() - started})
                    return blocked
            step_started = time.time()
            result = step(goal)
            if not isinstance(result, dict):
                result = {"detail": "step returned a non-mapping result", "stop": True}
            elapsed = time.time() - step_started
            # A callback cannot bypass the turn limit by reporting 0 turns.  The
            # controller owns dispatch accounting; model-reported token numbers
            # remain advisory but can only consume more budget, never less.
            try:
                reported_turns = int(result.get("turns", 1))
            except (TypeError, ValueError):
                reported_turns = 1
            try:
                tokens = max(0, int(result.get("tokens", 0)))
            except (TypeError, ValueError):
                tokens = 0
            self.store.update(
                goal_id,
                turns=max(1, reported_turns),
                tokens=tokens,
                elapsed=elapsed,
                detail=str(result.get("detail", "step completed"))[:500],
            )
            iterations.append(result)
            goal = self.store.get(goal_id)
            if background and goal.status == "active":
                # Re-check after the callback: a callback may have taken long
                # enough for expiry/revocation, and verification is another host
                # dispatch boundary.
                blocked = self._admit_background(goal)
                if blocked is not None:
                    blocked.update({"iterations": iterations, "elapsed": time.time() - started})
                    return blocked
            gate_results = [self.run_gate(gate, self.store.root) for gate in goal.gates]
            if goal.gates and all(item["status"] == 0 for item in gate_results):
                self.store.transition(goal_id, "complete", result_ref=result.get("result_ref"))
                return {"status": "complete", "iterations": iterations, "gates": gate_results,
                        "elapsed": time.time() - started}
            if result.get("stop"):
                final = self.store.pause_for_policy(goal_id, "step requested stop; completion was not inferred")
                return {"status": final.status, "iterations": iterations, "gates": gate_results,
                        "reason": "step requested stop; completion not inferred", "elapsed": time.time() - started}
        final = self.store.get(goal_id)
        return {"status": final.status, "iterations": iterations,
                "reason": "budget/status reached; completion not inferred",
                "elapsed": time.time() - started}


def goal_subject_hash(goal: GoalRecord) -> str:
    """Stable authority subject; excludes mutable status/progress/usage counters."""
    payload = {
        "goal_id": goal.id,
        "objective": goal.objective,
        "branch": goal.branch,
        "model": goal.model,
        "budget": goal.budget.model_dump(mode="json"),
        "gates": [gate.model_dump(mode="json") for gate in goal.gates],
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _safe_relative(value: str) -> bool:
    path = pathlib.PurePosixPath(str(value).replace("\\", "/"))
    return bool(str(path)) and not path.is_absolute() and ".." not in path.parts and "\x00" not in str(path)


def _resolve_gate_path(root: pathlib.Path, relative: str) -> pathlib.Path | None:
    if not _safe_relative(relative):
        return None
    try:
        target = (root / relative).resolve()
        target.relative_to(root)
    except (OSError, ValueError):
        return None
    return target
