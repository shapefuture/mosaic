"""Narrow, evidence-backed approval grants for irreversible host actions.

A global auto-approve switch is an unsafe substitute for authority.  This
ledger grants a single action against an exact task, snapshot, and target hash
for a bounded period.  The model cannot create grants; host code must call
``grant`` with an operator identity and a resolvable evidence artifact.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import pathlib
import time
import uuid
from typing import Any, Callable
import datetime

from .artifacts import ContentAddressedArtifactStore
from .wal import WAL


@dataclass(frozen=True)
class ApprovalGrant:
    id: str
    action: str
    task_hash: str
    target_hash: str
    snapshot_id: str
    expires_at: float
    approved_by_hash: str
    evidence_ref: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ApprovalDecision:
    allowed: bool
    grant_id: str | None
    reason: str


@dataclass(frozen=True)
class ApprovalPressure:
    """Read-only operator-load telemetry for a future approval interface.

    It intentionally makes no approval decision. There is no trustworthy
    pending-human queue or service-level capacity target in the local runtime,
    so auto-throttling/auto-approval here would be theatre.
    """

    window_seconds: float
    grants: int
    uses: int
    denials: int
    expired_unconsumed: int
    median_grant_spacing_seconds: float | None
    evidence_ref_missing: int


class ScopedApprovalLedger:
    def __init__(self, root: pathlib.Path, *, evidence_resolver: Callable[[str], bool] | None = None) -> None:
        self.root = pathlib.Path(root).resolve()
        self.wal = WAL(self.root)
        self.artifacts = ContentAddressedArtifactStore(self.root)
        self.evidence_resolver = evidence_resolver or self._resolve_artifact

    @staticmethod
    def _hash(value: Any) -> str:
        rendered = value if isinstance(value, str) else json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)
        return "sha256:" + hashlib.sha256(rendered.encode()).hexdigest()

    def _resolve_artifact(self, ref: str) -> bool:
        return isinstance(ref, str) and ref.startswith("artifact:sha256:") and self.artifacts.has(ref.removeprefix("artifact:"))

    def grant(
        self,
        *,
        action: str,
        task: str,
        target: Any,
        snapshot_id: str,
        approved_by: str,
        evidence_ref: str,
        ttl_seconds: float = 300.0,
    ) -> ApprovalGrant:
        if not action or not task or not snapshot_id or not approved_by:
            raise ValueError("approval grant requires action, task, snapshot identity, and approving operator")
        if ttl_seconds <= 0:
            raise ValueError("approval TTL must be positive")
        if not self.evidence_resolver(evidence_ref):
            raise ValueError("approval grant requires a resolvable evidence artifact")
        target_hash = self._hash(target)
        grant = ApprovalGrant(
            id="approval:" + uuid.uuid4().hex,
            action=str(action), task_hash=self._hash(task), target_hash=target_hash,
            snapshot_id=str(snapshot_id), expires_at=time.time() + float(ttl_seconds),
            approved_by_hash=self._hash(approved_by), evidence_ref=evidence_ref,
        )
        self.wal.append("scoped_approval", {"event": "granted", **grant.as_dict()})
        return grant

    def authorize(self, *, action: str, task: str, target: Any, snapshot_id: str) -> ApprovalDecision:
        expected_task = self._hash(task)
        expected_target = self._hash(target)
        now = time.time()
        candidates = [
            entry["data"] for entry in self.wal.replay(kind="scoped_approval")
            if entry.get("data", {}).get("event") == "granted"
        ]
        for row in reversed(candidates):
            if (
                row.get("action") == action and row.get("task_hash") == expected_task
                and row.get("target_hash") == expected_target and row.get("snapshot_id") == snapshot_id
                and float(row.get("expires_at", 0)) > now and self.evidence_resolver(str(row.get("evidence_ref", "")))
            ):
                decision = ApprovalDecision(True, str(row.get("id")), "exact scoped grant is valid")
                self.wal.append("scoped_approval", {"event": "used", "grant_id": decision.grant_id, "action": action})
                return decision
        decision = ApprovalDecision(False, None, "no valid exact scoped approval grant")
        self.wal.append("scoped_approval", {"event": "denied", "action": action, "task_hash": expected_task, "target_hash": expected_target, "snapshot_id": snapshot_id})
        return decision

    def pressure(self, *, window_seconds: float = 3600.0, now: float | None = None) -> ApprovalPressure:
        """Measure approval demand without exposing operator identity or task text."""
        if window_seconds <= 0:
            raise ValueError("approval pressure window must be positive")
        current = time.time() if now is None else float(now)
        start = current - float(window_seconds)
        rows: list[tuple[float, dict[str, Any]]] = []
        for entry in self.wal.replay(kind="scoped_approval"):
            data = entry.get("data", {})
            if not isinstance(data, dict):
                continue
            try:
                stamp = datetime.datetime.fromisoformat(str(entry.get("ts", "")).replace("Z", "+00:00")).timestamp()
            except (TypeError, ValueError):
                continue
            if stamp >= start:
                rows.append((stamp, data))
        grants = [(stamp, row) for stamp, row in rows if row.get("event") == "granted"]
        uses = [row for _stamp, row in rows if row.get("event") == "used"]
        denials = [row for _stamp, row in rows if row.get("event") == "denied"]
        used_ids = {str(row.get("grant_id")) for row in uses if row.get("grant_id")}
        expired_unconsumed = sum(
            1 for _stamp, row in grants
            if str(row.get("id")) not in used_ids and float(row.get("expires_at", 0) or 0) <= current
        )
        spacing = [later[0] - earlier[0] for earlier, later in zip(grants, grants[1:])]
        median = None
        if spacing:
            ordered = sorted(spacing)
            middle = len(ordered) // 2
            median = ordered[middle] if len(ordered) % 2 else (ordered[middle - 1] + ordered[middle]) / 2
        missing = sum(1 for _stamp, row in grants if not self.evidence_resolver(str(row.get("evidence_ref", ""))))
        return ApprovalPressure(
            window_seconds=float(window_seconds), grants=len(grants), uses=len(uses), denials=len(denials),
            expired_unconsumed=expired_unconsumed, median_grant_spacing_seconds=median,
            evidence_ref_missing=missing,
        )
