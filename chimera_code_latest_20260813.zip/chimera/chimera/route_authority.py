"""Central, fail-closed model-selection authority.

Routing telemetry may recommend alternatives, but an explicitly requested model
is part of the task contract and must never be silently replaced.  Automatic
selection exists only for the literal ``auto`` request and resolves through the
configured default; higher-level route pipelines remain advisory until a
separate, evidence-backed automatic-routing policy is introduced.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class RouteAuthorityReceipt:
    requested_model: str
    selected_model: str
    mode: str  # explicit | auto-default
    advisory: Mapping[str, Any] | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class RouteAuthority:
    def __init__(self, models: Mapping[str, Any]) -> None:
        self.models = models

    def resolve(self, requested_model: str, *, advisory: Mapping[str, Any] | None = None) -> RouteAuthorityReceipt:
        requested = str(requested_model or "").strip()
        if not requested:
            raise ValueError("model selection requires a non-empty requested model")
        if requested != "auto":
            return RouteAuthorityReceipt(requested, requested, "explicit", advisory)
        default = str(self.models.get("default", "")).strip()
        if not default or default == "auto":
            raise ValueError("auto model selection requires a concrete configured default model")
        return RouteAuthorityReceipt(requested, default, "auto-default", advisory)
