"""Point-of-use admission for locally executed ActionIR operations.

Certificates answer *what was approved*.  This module adds the missing local
executor check: capture an adapter-visible state observation, bind its digest to
the certificate, then compare the same observation immediately before the
executor uses it.  It deliberately does not claim to attest a remote service or
to close a race with an actor that bypasses the local transactional workspace.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import pathlib
import time
from typing import Any, Callable, Mapping

from .action_certificate import ActionCertificate, ActionCertificateAuthority
from .action_ir import ActionIR
from .action_preconditions import StatePrecondition, capture_preconditions, validate_preconditions
from .wal import WAL


@dataclass(frozen=True)
class LocalActionAdmission:
    """In-memory dispatch envelope; raw observations are never WAL-persisted."""

    certificate: ActionCertificate
    action: ActionIR
    policy: Mapping[str, Any]
    context_hash: str
    expected: tuple[StatePrecondition, ...]

    @property
    def preconditions_hash(self) -> str:
        raw = [(item.name, item.digest) for item in self.expected]
        return "sha256:" + hashlib.sha256(
            json.dumps(raw, separators=(",", ":"), sort_keys=True).encode()
        ).hexdigest()


@dataclass(frozen=True)
class AdmissionCheck:
    allowed: bool
    reason: str
    stale: tuple[str, ...]


@dataclass(frozen=True)
class ActionExecutionReceipt:
    certificate_id: str
    action_id: str
    phase: str
    allowed: bool
    reason: str
    preconditions_hash: str
    stale: tuple[str, ...]
    outcome_hash: str | None
    recorded_at: float

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class ActionExecutionReceiptLedger:
    """Hash-only, append-only local execution receipts.

    The receipt proves only that Chimera's local adapter compared its declared
    observation at the point of dispatch.  It cannot prove a remote tool's
    behaviour, sandbox isolation, or that an out-of-band writer obeyed the
    same lock/protocol.
    """

    def __init__(self, root: pathlib.Path) -> None:
        self.wal = WAL(pathlib.Path(root))

    @staticmethod
    def _hash(value: Any) -> str:
        encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()
        return "sha256:" + hashlib.sha256(encoded).hexdigest()

    def record(
        self,
        admission: LocalActionAdmission,
        *,
        phase: str,
        allowed: bool,
        reason: str,
        stale: tuple[str, ...] = (),
        outcome: Mapping[str, Any] | None = None,
    ) -> ActionExecutionReceipt:
        receipt = ActionExecutionReceipt(
            certificate_id=admission.certificate.id,
            action_id=admission.action.action_id,
            phase=str(phase),
            allowed=bool(allowed),
            reason=str(reason),
            preconditions_hash=admission.certificate.preconditions_hash,
            stale=tuple(sorted(map(str, stale))),
            outcome_hash=self._hash(dict(outcome)) if outcome is not None else None,
            recorded_at=time.time(),
        )
        self.wal.append("action_execution_receipt", receipt.as_dict())
        return receipt


def prepare_local_admission(
    authority: ActionCertificateAuthority,
    *,
    action: ActionIR,
    run_id: str,
    request_id: str,
    policy: Mapping[str, Any],
    context_hash: str,
    observed: Mapping[str, Any],
    approval_grant_id: str | None = None,
) -> LocalActionAdmission:
    """Issue a certificate bound to a concrete adapter observation."""
    expected = capture_preconditions(observed)
    canonical_observation = {item.name: item.digest for item in expected}
    certificate = authority.issue(
        action=action,
        run_id=run_id,
        request_id=request_id,
        policy=policy,
        context_hash=context_hash,
        # Bind the digest of each value, not raw workspace data, into the
        # existing certificate field. This gives the same canonical result as
        # retaining the raw observation while avoiding secret-bearing WAL data.
        preconditions=canonical_observation,
        approval_grant_id=approval_grant_id,
    )
    return LocalActionAdmission(certificate, action, dict(policy), str(context_hash), expected)


def validate_local_admission(
    authority: ActionCertificateAuthority,
    admission: LocalActionAdmission,
    current_observed: Mapping[str, Any],
) -> AdmissionCheck:
    """Validate certificate + exact adapter-visible state at point of use."""
    expected_mapping = {item.name: item.digest for item in admission.expected}
    certificate_ok = authority.valid_for(
        admission.certificate,
        action=admission.action,
        policy=admission.policy,
        context_hash=admission.context_hash,
        preconditions=expected_mapping,
        run_id=admission.certificate.run_id,
        request_id=admission.certificate.request_id,
    )
    if not certificate_ok:
        return AdmissionCheck(False, "certificate_invalid_or_expired", ())
    freshness = validate_preconditions(admission.expected, current_observed)
    if not freshness.valid:
        return AdmissionCheck(False, "state_precondition_stale", freshness.stale)
    return AdmissionCheck(True, "admitted", ())
