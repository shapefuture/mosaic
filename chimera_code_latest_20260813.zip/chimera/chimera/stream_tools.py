"""Stream-time textual tool-call extraction.

No speculation: dispatch can begin as soon as a complete tool block appears in
the stream, before final provider stop_reason.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, asdict

@dataclass(frozen=True)
class StreamToolEvent:
    block: str
    end_offset: int
    def as_dict(self): return asdict(self)

class StreamToolExtractor:
    OPEN=re.compile(r"<tool_call>", re.I); CLOSE=re.compile(r"</tool_call>", re.I)
    def __init__(self): self.buffer=""; self.offset=0
    def feed(self, chunk:str)->list[StreamToolEvent]:
        self.buffer += chunk or ""; events=[]
        while True:
            open_m=self.OPEN.search(self.buffer)
            if not open_m:
                # Keep small suffix in case tag is split across chunks.
                self.offset += max(0, len(self.buffer)-32); self.buffer=self.buffer[-32:]; break
            close_m=self.CLOSE.search(self.buffer, open_m.end())
            if not close_m: break
            block=self.buffer[open_m.end():close_m.start()].strip()
            events.append(StreamToolEvent(block, self.offset+close_m.end()))
            self.buffer=self.buffer[close_m.end():]; self.offset += close_m.end()
        return events
