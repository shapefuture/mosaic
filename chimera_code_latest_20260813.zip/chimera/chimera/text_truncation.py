"""UTF-8 safe truncation with explicit notices."""
from __future__ import annotations
from dataclasses import dataclass, asdict

@dataclass(frozen=True)
class TruncationResult:
    text:str; original_bytes:int; emitted_bytes:int; truncated:bool; notice:str
    def as_dict(self): return asdict(self)

def utf8_safe_truncate(text:str, max_bytes:int, *, label:str="output")->TruncationResult:
    raw=str(text or "").encode('utf-8')
    if len(raw)<=max_bytes:
        return TruncationResult(str(text or ""),len(raw),len(raw),False,"")
    head=max(0,max_bytes//2); tail=max(0,max_bytes-head)
    h=raw[:head]
    while h:
        try: hs=h.decode('utf-8'); break
        except UnicodeDecodeError: h=h[:-1]
    else: hs=""
    t=raw[-tail:]
    while t:
        try: ts=t.decode('utf-8'); break
        except UnicodeDecodeError: t=t[1:]
    else: ts=""
    notice=f"[Showing head/tail of {label}; original_bytes={len(raw)}, limit_bytes={max_bytes}]"
    out=hs+"\n..."+notice+"...\n"+ts
    return TruncationResult(out,len(raw),len(out.encode('utf-8')),True,notice)
