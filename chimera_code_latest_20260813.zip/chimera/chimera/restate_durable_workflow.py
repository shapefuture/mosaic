"""Optional Restate durable adapter backed by a pinned Virtual Object service.

The adapter talks only to a configured Restate ingress. The packaged service
implementation lives in ``chimera.adapters.restate_service`` and provides exclusive,
keyed start/checkpoint/finish transitions with durable state. Checkpoint bytes
remain in Chimera CAS. External effects remain outside this adapter and retain
Chimera outbox unknown-outcome semantics.
"""
from __future__ import annotations

import asyncio
import json
import pathlib
import time
import uuid
from typing import Any, Mapping

from pydantic import BaseModel, ConfigDict, Field

from .artifacts import ContentAddressedArtifactStore
from .durable_workflow import WorkflowRecord
from .wait_registry import WaitKind, WaitRecord, WaitRegistry


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class RestateAdapterConfig(_FrozenModel):
    ingress_url: str = Field(default="http://127.0.0.1:8080", pattern=r"^https?://")
    server_version: str = Field(default="1.7.3", min_length=1)
    sdk_version: str = Field(default="1.0.3", min_length=1)
    application_version: str = Field(default="chimera-restate-adapter-v1", min_length=1)


class RestateDurableWorkflowError(RuntimeError):
    pass


class RestateVersionDriftError(RestateDurableWorkflowError):
    pass


class RestateTenantMismatchError(RestateDurableWorkflowError):
    pass


class RestateDurableWorkflowPort:
    adapter_id = "restate-virtual-object-durable-workflow-v1"

    def __init__(self, root: pathlib.Path, config: RestateAdapterConfig, *, artifact_store=None) -> None:
        self.root = pathlib.Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.config = config
        self.artifacts = artifact_store or ContentAddressedArtifactStore(self.root)
        self.waits = WaitRegistry(self.root)
        try:
            import restate  # noqa: F401
            from .adapters import restate_service  # noqa: F401
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RestateDurableWorkflowError("install the restate-adapter extra and deploy the pinned fixture service") from exc

    @staticmethod
    def _run(coroutine):
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(coroutine)
        raise RestateDurableWorkflowError("synchronous Restate adapter cannot run inside an active event loop")

    async def _object_call(self, handler, key: str, arg: Any, *, idempotency_key: str | None = None) -> Any:
        import restate
        async with restate.create_client(self.config.ingress_url) as client:
            return await client.object_call(
                handler, key, arg, idempotency_key=idempotency_key,
            )

    @staticmethod
    def _registry_key(tenant_key: str | None) -> str:
        return tenant_key or "unscoped"

    def _remember(self, workflow_id: str, tenant_key: str | None) -> None:
        from .adapters.restate_service import remember
        result = self._run(self._object_call(
            remember,
            self._registry_key(tenant_key),
            workflow_id,
            idempotency_key="remember:" + workflow_id,
        ))
        if not isinstance(result, dict) or not result.get("remembered"):
            raise RestateDurableWorkflowError("Restate workflow registry rejected the workflow")

    def start(
        self,
        *,
        workflow_type: str,
        input_identity: str,
        workflow_id: str | None = None,
        tenant_key: str | None = None,
    ) -> WorkflowRecord:
        from .adapters.restate_service import start

        identifier = workflow_id or "workflow:" + uuid.uuid4().hex
        created = time.time()
        request = {
            "workflow_type": str(workflow_type),
            "input_identity": str(input_identity),
            "tenant_key": tenant_key,
            "created_at": created,
            "adapter_version": self.config.application_version,
            "server_version": self.config.server_version,
            "sdk_version": self.config.sdk_version,
        }
        result = self._run(self._object_call(
            start, identifier, request,
            idempotency_key="start:" + identifier,
        ))
        immutable_keys = (
            "workflow_type", "input_identity", "tenant_key", "adapter_version",
            "server_version", "sdk_version",
        )
        if not isinstance(result, dict) or any(result.get(key) != request[key] for key in immutable_keys):
            raise RestateDurableWorkflowError("duplicate workflow id is bound to different immutable input")
        self._remember(identifier, tenant_key)
        return WorkflowRecord(identifier, str(result["state"]), float(result["created_at"]), result.get("checkpoint_ref"), tenant_key)

    def checkpoint(
        self,
        workflow: WorkflowRecord,
        state: Mapping[str, Any],
        *,
        idempotency_key: str | None = None,
        tenant_key: str | None = None,
    ) -> WorkflowRecord:
        from .adapters.restate_service import checkpoint

        current = self.recover(workflow.id, tenant_key=tenant_key)
        if current is None or current.state != "running":
            raise RestateDurableWorkflowError("cannot checkpoint a missing or terminal workflow")
        ref = self.artifacts.put(
            json.dumps(dict(state), sort_keys=True, separators=(",", ":"), default=str),
            media_type="application/vnd.chimera.workflow-checkpoint+json",
            provenance={"workflow": workflow.id, "adapter": self.adapter_id},
        )
        checkpoint_ref = "artifact:" + ref.digest
        key = idempotency_key or f"checkpoint:{workflow.id}:{ref.digest}"
        result = self._run(self._object_call(
            checkpoint, workflow.id,
            {"checkpoint_ref": checkpoint_ref, "tenant_key": tenant_key},
            idempotency_key=key,
        ))
        if not isinstance(result, dict) or not result.get("accepted"):
            if isinstance(result, dict) and result.get("reason") == "tenant mismatch":
                raise RestateTenantMismatchError("workflow tenant context does not match the caller")
            raise RestateDurableWorkflowError(f"Restate checkpoint rejected: {result}")
        if result.get("checkpoint_ref") != checkpoint_ref:
            raise RestateDurableWorkflowError("checkpoint idempotency key was bound to different bytes")
        return WorkflowRecord(workflow.id, "running", current.created_at, checkpoint_ref, tenant_key)

    def wait(
        self,
        workflow: WorkflowRecord,
        *,
        kind: WaitKind,
        target: Any,
        owner: str,
        timeout_seconds: float,
        tenant_key: str | None = None,
    ) -> WaitRecord:
        current = self.recover(workflow.id, tenant_key=tenant_key)
        if current is None or current.state != "running":
            raise RestateDurableWorkflowError("cannot wait on a missing or terminal workflow")
        return self.waits.register(
            run_id=workflow.id, kind=kind, target=target,
            owner=owner, timeout_seconds=timeout_seconds,
        )

    def finish(
        self,
        workflow: WorkflowRecord,
        *,
        state: str,
        idempotency_key: str | None = None,
        tenant_key: str | None = None,
    ) -> WorkflowRecord:
        if state not in {"completed", "failed", "cancelled"}:
            raise ValueError("workflow terminal state must be completed, failed, or cancelled")
        from .adapters.restate_service import finish

        current = self.recover(workflow.id, tenant_key=tenant_key)
        if current is None:
            raise RestateDurableWorkflowError("cannot finish a missing workflow")
        key = idempotency_key or f"finish:{workflow.id}:{state}"
        result = self._run(self._object_call(
            finish, workflow.id,
            {"state": state, "tenant_key": tenant_key},
            idempotency_key=key,
        ))
        if not isinstance(result, dict) or not result.get("accepted"):
            reason = result.get("reason") if isinstance(result, dict) else "invalid receipt"
            if reason == "tenant mismatch":
                raise RestateTenantMismatchError("workflow tenant context does not match the caller")
            raise RestateDurableWorkflowError(f"Restate terminal transition rejected: {reason}")
        if result.get("state") != state:
            raise RestateDurableWorkflowError("terminal idempotency key was bound to a different state")
        return WorkflowRecord(workflow.id, state, current.created_at, result.get("checkpoint_ref"), tenant_key)

    def cancel(self, workflow: WorkflowRecord, *, tenant_key: str | None = None) -> WorkflowRecord:
        return self.finish(workflow, state="cancelled", idempotency_key=f"cancel:{workflow.id}", tenant_key=tenant_key)

    def recover(self, workflow_id: str, *, tenant_key: str | None = None) -> WorkflowRecord | None:
        from .adapters.restate_service import status
        try:
            result = self._run(self._object_call(status, str(workflow_id), None))
        except Exception as exc:
            # Restate returns a not-found HTTP error for an object with no state.
            if "404" in str(exc):
                return None
            raise
        if result is None:
            return None
        if not isinstance(result, dict):
            raise RestateDurableWorkflowError("Restate status receipt is malformed")
        if result.get("adapter_version") != self.config.application_version:
            raise RestateVersionDriftError("Restate workflow application version differs from adapter")
        if result.get("server_version") != self.config.server_version or result.get("sdk_version") != self.config.sdk_version:
            raise RestateVersionDriftError("Restate server/SDK pin differs from workflow receipt")
        if result.get("tenant_key") != tenant_key:
            raise RestateTenantMismatchError("workflow tenant context does not match the caller")
        checkpoint_ref = result.get("checkpoint_ref")
        if checkpoint_ref:
            if not isinstance(checkpoint_ref, str) or not checkpoint_ref.startswith("artifact:sha256:"):
                raise RestateDurableWorkflowError("Restate checkpoint reference is malformed")
            self.artifacts.get(checkpoint_ref.removeprefix("artifact:"))
        return WorkflowRecord(
            str(workflow_id), str(result["state"]),
            float(result["created_at"]), checkpoint_ref, tenant_key,
        )

    def recover_incomplete(self, *, tenant_key: str | None = None) -> tuple[WorkflowRecord, ...]:
        from .adapters.restate_service import known_workflows
        values = self._run(self._object_call(
            known_workflows,
            self._registry_key(tenant_key),
            None,
        ))
        if not isinstance(values, list) or not all(isinstance(item, str) for item in values):
            raise RestateDurableWorkflowError("Restate workflow registry response is malformed")
        recovered = [self.recover(identifier, tenant_key=tenant_key) for identifier in values]
        return tuple(item for item in recovered if item is not None and item.state == "running")
