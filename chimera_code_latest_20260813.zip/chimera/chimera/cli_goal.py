"""Long-running goal and autonomy lease CLI commands."""
from __future__ import annotations

import json
import time

import click
from rich.json import JSON


def register(main: click.Group, *, console, cli_root) -> None:
    _cli_root = cli_root

    @main.group("goal")
    def goal_group():
        """Persistent goals, heartbeats, and schedules."""
        pass

    @goal_group.command("set")
    @click.argument("objective")
    @click.option("--branch", default="goal-work")
    @click.option("--model", default="mock-echo")
    @click.option("--max-turns", default=12)
    @click.option("--max-tokens", default=80000)
    @click.option("--max-seconds", default=1800)
    @click.option("--gate", multiple=True)
    def goal_set(objective, branch, model, max_turns, max_tokens, max_seconds, gate):
        from .long_running import GoalBudget, GoalStore
        goal = GoalStore(_cli_root()).create(
            objective, branch, model,
            GoalBudget(max_turns=max_turns, max_tokens=max_tokens, max_seconds=max_seconds),
            list(gate),
        )
        console.print(JSON(goal.model_dump_json(indent=2)))

    @goal_group.command("list")
    @click.option("--status", default=None)
    def goal_list(status):
        from .long_running import GoalStore
        console.print(JSON(json.dumps([goal.model_dump() for goal in GoalStore(_cli_root()).list(status)], indent=2)))

    @goal_group.command("heartbeat")
    @click.argument("goal_id")
    @click.option("--detail", default="")
    def goal_heartbeat(goal_id, detail):
        from .long_running import GoalStore
        console.print(JSON(GoalStore(_cli_root()).heartbeat(goal_id, detail).model_dump_json(indent=2)))

    @goal_group.command("pause")
    @click.argument("goal_id")
    def goal_pause(goal_id):
        from .long_running import GoalStore
        console.print(JSON(GoalStore(_cli_root()).transition(goal_id, "paused").model_dump_json(indent=2)))

    @goal_group.command("resume")
    @click.argument("goal_id")
    def goal_resume(goal_id):
        from .long_running import GoalStore
        console.print(JSON(GoalStore(_cli_root()).transition(goal_id, "active").model_dump_json(indent=2)))

    @goal_group.command("schedule")
    @click.argument("goal_id")
    @click.option("--after", "after_seconds", required=True, type=int)
    @click.option("--every", "interval_seconds", default=None, type=int)
    def goal_schedule(goal_id, after_seconds, interval_seconds):
        from .long_running import GoalStore
        item = GoalStore(_cli_root()).schedule(goal_id, time.time() + after_seconds, interval_seconds)
        console.print(JSON(item.model_dump_json(indent=2)))


    @goal_group.group("autonomy")
    def goal_autonomy_group():
        """Explicit, expiring leases for a future scheduler/daemon dispatch."""
        pass


    @goal_autonomy_group.command("grant")
    @click.argument("goal_id")
    @click.option("--approved-by", required=True, help="Operator label; only its hash is recorded.")
    @click.option("--evidence-ref", required=True, help="Resolvable operator-intent or approval evidence reference.")
    @click.option("--ttl-seconds", default=3600.0, type=float, show_default=True)
    def goal_autonomy_grant(goal_id, approved_by, evidence_ref, ttl_seconds):
        from .autonomy_lease import AutonomyLeaseLedger
        from .long_running import GoalStore, goal_subject_hash
        store = GoalStore(_cli_root())
        goal = store.get(goal_id)
        lease = AutonomyLeaseLedger(_cli_root()).grant(
            goal_id=goal.id,
            subject_hash=goal_subject_hash(goal),
            approved_by=approved_by,
            evidence_ref=evidence_ref,
            ttl_seconds=ttl_seconds,
        )
        console.print(JSON(lease.model_dump_json(indent=2)))


    @goal_autonomy_group.command("revoke")
    @click.argument("goal_id")
    @click.option("--revoked-by", required=True, help="Operator label; only its hash is recorded.")
    @click.option("--reason", default="operator revoked autonomy", show_default=True)
    def goal_autonomy_revoke(goal_id, revoked_by, reason):
        from .autonomy_lease import AutonomyLeaseLedger
        revoked = AutonomyLeaseLedger(_cli_root()).revoke(
            goal_id=goal_id, revoked_by=revoked_by, reason=reason,
        )
        console.print(JSON(json.dumps({"goal_id": goal_id, "revoked": revoked}, indent=2)))


    @goal_autonomy_group.command("status")
    @click.argument("goal_id")
    def goal_autonomy_status(goal_id):
        from .autonomy_lease import AutonomyLeaseLedger
        from .long_running import GoalStore, goal_subject_hash
        goal = GoalStore(_cli_root()).get(goal_id)
        decision = AutonomyLeaseLedger(_cli_root()).check(
            goal_id=goal.id, subject_hash=goal_subject_hash(goal),
        )
        console.print(JSON(decision.model_dump_json(indent=2)))


