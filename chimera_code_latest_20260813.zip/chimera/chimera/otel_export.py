"""Dependency-free OTLP-shaped export for Chimera WAL/trajectory records."""
from __future__ import annotations
import json,pathlib,time
from typing import Iterable

def span(name:str,attributes:dict,start_ns:int|None=None,end_ns:int|None=None,status:str='OK'):
 now=time.time_ns();return {'name':name,'startTimeUnixNano':str(start_ns or now),'endTimeUnixNano':str(end_ns or now),'status':{'code':status},'attributes':[{'key':k,'value':{'stringValue':str(v)}} for k,v in attributes.items() if v is not None]}
def export_turn_latency(rows:Iterable[dict])->dict:
 spans=[]
 for row in rows:
  data=row.get('data',row);attrs={'gen_ai.operation.name':'chat','gen_ai.client.operation.duration':data.get('model_ms'),'chimera.tool_ms':data.get('tool_ms'),'chimera.client_overhead_ms':data.get('client_overhead_ms'),'session.id':data.get('session'),'turn':data.get('turn')};spans.append(span('gen_ai.chat',attrs))
 return {'resourceSpans':[{'scopeSpans':[{'spans':spans}]}]}
def write_export(path:pathlib.Path,rows:Iterable[dict])->pathlib.Path:
 path=pathlib.Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(export_turn_latency(rows),indent=2));return path
