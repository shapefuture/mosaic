"""Revocable, exact-subject leases for scheduled autonomous goal dispatch.

This is deliberately a small control-plane primitive, not a general permission
system.  A background runner has to present an unexpired lease bound to the
canonical goal subject before *each* dispatch.  The owner can revoke the lease;
revocation prevents the next dispatch even when the daemon that granted it is a
different process.

The ledger is default-deny.  Its JSON projection is convenient state, while the
hash-chained Chimera WAL anchors grants and revocations.  A malformed projection,
a missing anchor, a changed subject, or an expired/revoked lease denies work.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
import os
import pathlib
import threading
import time
import uuid
from typing import Any, Iterator

from pydantic import BaseModel, ConfigDict, Field

from .wal import WAL, WALIntegrityError


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class AutonomyLease(_FrozenModel):
    """An operator-issued grant for one immutable autonomous-goal subject."""

    schema_version: str = "chimera.autonomy-lease.v1"
    id: str
    goal_id: str
    subject_hash: str
    expires_at: float
    approved_by_hash: str
    evidence_ref: str
    granted_at: float
    revision: int = Field(ge=1)

    @property
    def receipt_hash(self) -> str:
        return _hash(self.model_dump(mode="json"))


class AutonomyDecision(_FrozenModel):
    allowed: bool
    reason: str
    lease_id: str | None = None
    expires_at: float | None = None
    revision: int | None = None


class _LeaseProjection(BaseModel):
    """The local projection contains only the latest lease per goal."""

    schema_version: str = "chimera.autonomy-lease-projection.v1"
    leases: dict[str, AutonomyLease] = Field(default_factory=dict)


class AutonomyLeaseLedger:
    """Persistent default-deny authorization for background goal dispatch.

    ``grant`` and ``revoke`` are host/operator APIs.  They require an explicit
    operator label and a nonempty evidence reference.  The label is hashed before
    it is written, so status views do not expose an operator identifier.

    A lease is scoped to an exact goal subject hash.  Altering a goal's objective,
    branch, model, budget, or verification gates invalidates its old lease.
    """

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.dir = self.root / ".chimera" / "autonomy"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.path = self.dir / "leases.json"
        self.lock_path = self.dir / "leases.lock"
        self.wal = WAL(self.root)
        self._thread_lock = threading.RLock()

    @staticmethod
    def _operator_hash(value: str) -> str:
        return "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()

    @contextmanager
    def _locked(self) -> Iterator[None]:
        """Serialize the projection across threads and, where available, processes."""
        with self._thread_lock:
            handle = self.lock_path.open("a+b")
            try:
                try:
                    import fcntl
                except ImportError:  # pragma: no cover - non-POSIX fallback
                    fcntl = None
                if fcntl is not None:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
                yield
            finally:
                try:
                    if fcntl is not None:
                        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
                finally:
                    handle.close()

    def _read_projection(self, *, strict: bool) -> _LeaseProjection | None:
        if not self.path.exists():
            return _LeaseProjection()
        try:
            return _LeaseProjection.model_validate_json(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            if strict:
                raise ValueError("autonomy lease projection is unreadable or invalid")
            return None

    def _write_projection(self, projection: _LeaseProjection) -> None:
        encoded = (projection.model_dump_json(indent=2) + "\n").encode("utf-8")
        temp = self.path.with_name(f".{self.path.name}.{uuid.uuid4().hex}.tmp")
        try:
            with temp.open("wb") as handle:
                handle.write(encoded)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp, self.path)
        finally:
            if temp.exists():
                temp.unlink()

    def _latest_event(self, goal_id: str) -> dict[str, Any] | None:
        """Return the newest hash-chain-verified lease event, or fail closed."""
        try:
            valid, _bad = self.wal.verify_chain()
            if not valid:
                return None
            rows = self.wal.replay(kind="autonomy_lease")
        except WALIntegrityError:
            return None
        latest: dict[str, Any] | None = None
        for row in rows:
            data = row.get("data", {})
            if isinstance(data, dict) and data.get("goal_id") == goal_id:
                latest = data
        return latest

    def grant(
        self,
        *,
        goal_id: str,
        subject_hash: str,
        approved_by: str,
        evidence_ref: str,
        ttl_seconds: float,
        now: float | None = None,
    ) -> AutonomyLease:
        """Create a short-lived exact-subject lease; never broadens an old one."""
        if not goal_id or not subject_hash.startswith("sha256:"):
            raise ValueError("goal_id and sha256 subject_hash are required")
        if not approved_by.strip():
            raise ValueError("autonomy lease requires an explicit approving operator")
        if not evidence_ref.strip():
            raise ValueError("autonomy lease requires an evidence reference")
        if ttl_seconds <= 0:
            raise ValueError("autonomy lease TTL must be positive")
        current = time.time() if now is None else float(now)
        with self._locked():
            projection = self._read_projection(strict=True)
            assert projection is not None
            prior = projection.leases.get(goal_id)
            lease = AutonomyLease(
                id="autonomy:" + uuid.uuid4().hex,
                goal_id=goal_id,
                subject_hash=subject_hash,
                expires_at=current + float(ttl_seconds),
                approved_by_hash=self._operator_hash(approved_by),
                evidence_ref=evidence_ref,
                granted_at=current,
                revision=(prior.revision + 1) if prior is not None else 1,
            )
            # Anchor before publishing the mutable projection.  If the projection
            # write fails, checks see no lease and deny rather than assuming grant.
            self.wal.append("autonomy_lease", {
                "event": "granted",
                "goal_id": goal_id,
                "lease_id": lease.id,
                "lease_hash": lease.receipt_hash,
                "subject_hash": lease.subject_hash,
                "expires_at": lease.expires_at,
                "revision": lease.revision,
            })
            leases = dict(projection.leases)
            leases[goal_id] = lease
            self._write_projection(_LeaseProjection(leases=leases))
            return lease

    def revoke(self, *, goal_id: str, revoked_by: str, reason: str = "operator revoked autonomy") -> bool:
        """Withdraw a grant.  The next background dispatch observes the revocation."""
        if not goal_id or not revoked_by.strip():
            raise ValueError("goal_id and revoking operator are required")
        with self._locked():
            projection = self._read_projection(strict=True)
            assert projection is not None
            lease = projection.leases.get(goal_id)
            if lease is None:
                return False
            self.wal.append("autonomy_lease", {
                "event": "revoked",
                "goal_id": goal_id,
                "lease_id": lease.id,
                "lease_hash": lease.receipt_hash,
                "revoked_by_hash": self._operator_hash(revoked_by),
                "reason": str(reason)[:300],
            })
            leases = dict(projection.leases)
            del leases[goal_id]
            self._write_projection(_LeaseProjection(leases=leases))
            return True

    def check(self, *, goal_id: str, subject_hash: str, now: float | None = None) -> AutonomyDecision:
        """Fail-closed authorization check used immediately before every dispatch."""
        current = time.time() if now is None else float(now)
        with self._locked():
            projection = self._read_projection(strict=False)
            if projection is None:
                return AutonomyDecision(allowed=False, reason="autonomy lease projection is invalid")
            lease = projection.leases.get(goal_id)
            latest = self._latest_event(goal_id)
            if lease is None:
                if latest is not None and latest.get("event") == "revoked":
                    return AutonomyDecision(allowed=False, reason="autonomy lease was revoked")
                return AutonomyDecision(allowed=False, reason="no active autonomy lease for goal")
            if latest is None:
                return AutonomyDecision(allowed=False, reason="autonomy lease lacks a valid WAL anchor")
            if latest.get("event") != "granted" or latest.get("lease_id") != lease.id or latest.get("lease_hash") != lease.receipt_hash:
                return AutonomyDecision(allowed=False, reason="autonomy lease was superseded or revoked")
            if lease.subject_hash != subject_hash:
                return AutonomyDecision(allowed=False, reason="goal subject changed since autonomy was granted")
            if current >= lease.expires_at:
                return AutonomyDecision(
                    allowed=False,
                    reason="autonomy lease expired",
                    lease_id=lease.id,
                    expires_at=lease.expires_at,
                    revision=lease.revision,
                )
            return AutonomyDecision(
                allowed=True,
                reason="active exact-subject autonomy lease",
                lease_id=lease.id,
                expires_at=lease.expires_at,
                revision=lease.revision,
            )


def _hash(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()
