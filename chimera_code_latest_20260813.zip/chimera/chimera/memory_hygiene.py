"""Admission policy for persistent lessons injected into later agent contexts.

A lesson should describe an observed fact and cite its evidence.  Imperative
instructions embedded in persistent memory can become a cross-run prompt
injection channel, so they are rejected before a continual-harness revision is
created.  This gate is deliberately narrow: it does not decide whether a fact
is true; provenance/evidence policy remains responsible for that.
"""
from __future__ import annotations

from dataclasses import dataclass
import re


@dataclass(frozen=True)
class MemoryAdmission:
    allowed: bool
    reason: str


class PersistentLessonGate:
    _LEADING_IMPERATIVE = re.compile(
        r"^\s*(?:always|never|must|should|do\s+not|don't|ignore|disregard|override|use|run|execute|send|upload|delete)\b",
        re.I,
    )
    _OVERRIDE = re.compile(
        r"\b(?:ignore|disregard|override)\b.{0,80}\b(?:previous|system|developer)\b.{0,80}\b(?:instruction|rule|message)s?\b",
        re.I | re.S,
    )

    def assess(self, content: str) -> MemoryAdmission:
        text = str(content).strip()
        if not text:
            return MemoryAdmission(False, "memory lesson is empty")
        if self._OVERRIDE.search(text):
            return MemoryAdmission(False, "memory lesson contains instruction-override language")
        if self._LEADING_IMPERATIVE.search(text):
            return MemoryAdmission(False, "persistent lesson must describe evidence, not command a future agent")
        return MemoryAdmission(True, "descriptive lesson admitted")
