"""Transport-neutral Chimera application commands, results, and use cases."""

from __future__ import annotations

import base64
import hashlib
import json
import time
from collections.abc import Callable, Mapping
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .runtime_ports import (
    ArtifactPort,
    CodeIntelligencePort,
    QuotaPort,
    SessionPort,
    WorkspaceTransactionPort,
)


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ApplicationStatus(StrEnum):
    VERIFIED = "verified"
    PARTIALLY_VERIFIED = "partially_verified"
    UNAVAILABLE = "unavailable"
    UNKNOWN_OUTCOME = "unknown_outcome"


class RunContext(_FrozenModel):
    profile: str = "LOCAL_DETERMINISTIC"
    tenant_key: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    principal_hash: str | None = Field(default=None, pattern=r"^sha256:[0-9a-f]{64}$")
    grant_digest: str | None = Field(default=None, pattern=r"^sha256:[0-9a-f]{64}$")
    run_id: str
    request_id: str
    trace_id: str
    deadline_unix_ms: int
    max_input_tokens: int = Field(default=25_000, ge=1)
    max_output_tokens: int = Field(default=4_096, ge=1)
    max_cost_usd: float = Field(default=10.0, ge=0.0)
    max_active_runs: int = Field(default=1, ge=1, le=10_000)
    max_workers: int = Field(default=1, ge=1, le=10_000)
    cancellation_token: str | None = None

    @model_validator(mode="after")
    def _tenant_context_is_complete(self) -> RunContext:
        values = (self.tenant_key, self.principal_hash, self.grant_digest)
        if any(values) and not all(values):
            raise ValueError(
                "tenant, principal, and grant identity must be propagated together"
            )
        return self

    @property
    def deadline_expired(self) -> bool:
        return int(time.time() * 1_000) >= self.deadline_unix_ms


class RunTaskCommand(_FrozenModel):
    task: str = Field(min_length=1, max_length=200_000)
    branch: str = Field(default="exp-001", min_length=1, max_length=128)
    model: str = Field(default="mock-echo", min_length=1, max_length=300)
    auto_commit: bool = False
    high_risk_review: bool = False
    context: RunContext


class RunResult(_FrozenModel):
    schema_version: str = "chimera.run-result.v1"
    status: ApplicationStatus
    task_hash: str
    branch: str
    answer: str
    changed_paths: tuple[str, ...] = ()
    verification: Mapping[str, Any] = Field(default_factory=dict)
    evidence_refs: tuple[str, ...] = ()
    command_receipts: tuple[Mapping[str, Any], ...] = ()
    limitations: tuple[str, ...] = ()
    usage: Mapping[str, Any] = Field(default_factory=dict)
    latency_ms: Mapping[str, float] = Field(default_factory=dict)
    committed: str | None = None
    result_artifact: str | None = None
    checker_review: Mapping[str, Any] | None = None
    budget_satisfied: bool


class QueryCodeCommand(_FrozenModel):
    query: str = Field(min_length=1, max_length=20_000)
    limit: int = Field(default=10, ge=1, le=200)
    kind: str | None = Field(default=None, max_length=100)
    cursor: int = Field(default=0, ge=0)
    context: RunContext


class QueryPage(_FrozenModel):
    schema_version: str = "chimera.query-page.v1"
    items: tuple[Mapping[str, Any], ...]
    cursor: int
    next_cursor: int | None
    snapshot_id: str | None = None


class CreateBranchCommand(_FrozenModel):
    name: str = Field(min_length=1, max_length=128)
    from_branch: str = Field(default="main", min_length=1, max_length=128)
    context: RunContext


class GetDiffCommand(_FrozenModel):
    branch: str = Field(min_length=1, max_length=128)
    context: RunContext


class VerifyBranchCommand(_FrozenModel):
    branch: str = Field(min_length=1, max_length=128)
    command: str = Field(default="pytest -q", min_length=1, max_length=10_000)
    context: RunContext


class CommitBranchCommand(_FrozenModel):
    branch: str = Field(min_length=1, max_length=128)
    task: str = Field(min_length=1, max_length=200_000)
    message: str = Field(min_length=1, max_length=10_000)
    context: RunContext


class AbortBranchCommand(_FrozenModel):
    branch: str = Field(min_length=1, max_length=128)
    context: RunContext


class BranchResult(_FrozenModel):
    schema_version: str = "chimera.branch-result.v1"
    action: str
    branch: str
    value: Mapping[str, Any] = Field(default_factory=dict)


class OpenSessionCommand(_FrozenModel):
    objective: str = Field(min_length=1, max_length=200_000)
    model: str = Field(default="mock-echo", min_length=1, max_length=300)
    base_branch: str = Field(default="main", min_length=1, max_length=128)
    protocol: Literal["rpc", "acp", "mcp"] = "rpc"
    context: RunContext


class SendSessionInputCommand(_FrozenModel):
    session_id: str = Field(min_length=1, max_length=200)
    message: str = Field(min_length=1, max_length=200_000)
    context: RunContext


class ResumeSessionCommand(_FrozenModel):
    session_id: str = Field(min_length=1, max_length=200)
    command: str = Field(default="pytest -q", min_length=1, max_length=10_000)
    context: RunContext


class CancelSessionCommand(_FrozenModel):
    session_id: str = Field(min_length=1, max_length=200)
    context: RunContext


class SessionResult(_FrozenModel):
    schema_version: str = "chimera.session-result.v1"
    action: str
    session: Mapping[str, Any]


class ArtifactPage(_FrozenModel):
    schema_version: str = "chimera.artifact-page.v1"
    digest: str
    offset: int
    next_offset: int | None
    total_bytes: int
    encoding: str
    content: str


class ApplicationError(RuntimeError):
    def __init__(self, code: str, public_message: str, *, retryable: bool = False):
        super().__init__(public_message)
        self.code = code
        self.public_message = public_message
        self.retryable = retryable
        self.error_id = (
            "error:"
            + hashlib.sha256(f"{code}:{time.time_ns()}".encode()).hexdigest()[:20]
        )

    def public_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.public_message,
            "error_id": self.error_id,
            "retryable": self.retryable,
        }


RunTaskCallable = Callable[[RunTaskCommand], Mapping[str, Any]]
VerifyCallable = Callable[[VerifyBranchCommand], Mapping[str, Any]]
CommitCallable = Callable[[CommitBranchCommand], str]
ReviewCallable = Callable[[RunTaskCommand, Mapping[str, Any]], Mapping[str, Any] | None]


class ChimeraApplication:
    """One policy-owning application surface for CLI, MCP, RPC, and schedulers."""

    def __init__(
        self,
        *,
        workspace: WorkspaceTransactionPort,
        code: CodeIntelligencePort,
        artifacts: ArtifactPort,
        run_task: RunTaskCallable,
        verify_branch: VerifyCallable,
        commit_branch: CommitCallable,
        sessions: SessionPort | None = None,
        quota: QuotaPort | None = None,
        independent_review: ReviewCallable | None = None,
        max_inline_result_bytes: int = 64_000,
    ) -> None:
        self.workspace = workspace
        self.code = code
        self.artifacts = artifacts
        self._run_task = run_task
        self._verify_branch = verify_branch
        self._commit_branch = commit_branch
        self.sessions = sessions
        self.quota = quota
        self._independent_review = independent_review
        self.max_inline_result_bytes = max(4_096, int(max_inline_result_bytes))

    @staticmethod
    def _require_live(context: RunContext) -> None:
        if context.deadline_expired:
            raise ApplicationError("deadline_exceeded", "request deadline has expired")

    def run(self, command: RunTaskCommand) -> RunResult:
        self._require_live(command.context)
        started = time.perf_counter()
        quota_admitted = False
        if command.context.tenant_key is not None:
            if self.quota is None:
                raise ApplicationError(
                    "tenant_quota_unavailable",
                    "tenant run requires a bound quota adapter",
                )
            decision = self.quota.admit(
                tenant_key=command.context.tenant_key,
                run_id=command.context.run_id,
                max_active_runs=command.context.max_active_runs,
                expires_at=command.context.deadline_unix_ms / 1_000,
            )
            allowed = (
                decision.get("allowed")
                if isinstance(decision, Mapping)
                else getattr(decision, "allowed", False)
            )
            if not allowed:
                raise ApplicationError(
                    "tenant_quota_exhausted", "tenant run quota is exhausted"
                )
            quota_admitted = True
        try:
            raw = dict(self._run_task(command))
        finally:
            if quota_admitted and self.quota is not None and command.context.tenant_key:
                self.quota.release(
                    tenant_key=command.context.tenant_key,
                    run_id=command.context.run_id,
                )
        elapsed = (time.perf_counter() - started) * 1_000
        verification_value = raw.get("verification")
        verification: dict[str, Any] = (
            {str(key): value for key, value in verification_value.items()}
            if isinstance(verification_value, Mapping)
            else {}
        )
        verification_status = str(verification.get("status", "unavailable"))
        outcome = str(raw.get("outcome", ""))
        if outcome == "unknown_outcome":
            status = ApplicationStatus.UNKNOWN_OUTCOME
        elif verification_status in {"pass", "verified"} and raw.get("ltl_ok") is True:
            status = ApplicationStatus.VERIFIED
        elif verification_status in {"partial", "partially_verified", "incomplete"}:
            status = ApplicationStatus.PARTIALLY_VERIFIED
        else:
            status = ApplicationStatus.UNAVAILABLE
        diff_value = raw.get("diff")
        diff: dict[str, Any] = (
            {str(key): value for key, value in diff_value.items()}
            if isinstance(diff_value, Mapping)
            else {}
        )
        paths = tuple(
            dict.fromkeys(
                str(item.get("path"))
                for item in diff.get("ops", ())
                if isinstance(item, Mapping) and item.get("path")
            )
        )
        refs: list[str] = []
        for candidate in (
            raw.get("session_dir"),
            (raw.get("heldout") or {}).get("evidence_ref")
            if isinstance(raw.get("heldout"), Mapping)
            else None,
        ):
            if isinstance(candidate, str) and candidate.startswith(
                ("artifact:", "sha256:")
            ):
                refs.append(candidate)
        limitations = []
        if raw.get("ltl_msg"):
            limitations.append(str(raw["ltl_msg"]))
        if status is not ApplicationStatus.VERIFIED:
            limitations.append(
                "run did not produce complete deterministic verification"
            )
        usage_value = raw.get("usage")
        usage: dict[str, Any] = (
            {str(key): value for key, value in usage_value.items()}
            if isinstance(usage_value, Mapping)
            else {}
        )
        used_tokens = int(usage.get("tokens", usage.get("total_tokens", 0)) or 0)
        budget_satisfied = used_tokens <= (
            command.context.max_input_tokens + command.context.max_output_tokens
        )
        if not budget_satisfied:
            limitations.append("observed token usage exceeded the run budget")
        checker = None
        if command.high_risk_review:
            if self._independent_review is None:
                checker = {"status": "unavailable", "advisory_only": True}
                limitations.append(
                    "independent checker was requested but no checker adapter is bound"
                )
            else:
                try:
                    checker = self._independent_review(command, raw)
                except Exception as exc:  # noqa: BLE001 - advisory adapter failures cannot change authority
                    checker = {
                        "status": "unavailable",
                        "advisory_only": True,
                        "error_class": type(exc).__name__,
                    }
                    limitations.append(
                        "independent checker failed; deterministic result is unchanged"
                    )

        result_artifact = None
        encoded = json.dumps(raw, sort_keys=True, default=str).encode()
        answer = str(raw.get("answer", ""))
        if len(encoded) > self.max_inline_result_bytes:
            ref = self.artifacts.put(
                encoded,
                media_type="application/vnd.chimera.raw-run+json",
                provenance={
                    "run_id": command.context.run_id,
                    "request_id": command.context.request_id,
                    "tenant_key": command.context.tenant_key,
                },
            )
            result_artifact = "artifact:" + str(ref.digest)
            refs.append(result_artifact)
        return RunResult(
            status=status,
            task_hash="sha256:" + hashlib.sha256(command.task.encode()).hexdigest(),
            branch=command.branch,
            answer=answer,
            changed_paths=paths,
            verification=dict(verification),
            evidence_refs=tuple(dict.fromkeys(refs)),
            command_receipts=(),
            limitations=tuple(dict.fromkeys(limitations)),
            usage=dict(usage),
            latency_ms={"application_total": elapsed},
            committed=str(raw["committed"]) if raw.get("committed") else None,
            result_artifact=result_artifact,
            checker_review=checker,
            budget_satisfied=budget_satisfied,
        )

    def query_code(self, command: QueryCodeCommand) -> QueryPage:
        self._require_live(command.context)
        rows = list(
            self.code.query(
                command.query,
                limit=min(200, command.cursor + command.limit + 1),
                kind=command.kind,
            )
        )
        page = tuple(
            dict(item) for item in rows[command.cursor : command.cursor + command.limit]
        )
        next_cursor = (
            command.cursor + len(page)
            if len(rows) > command.cursor + len(page)
            else None
        )
        return QueryPage(items=page, cursor=command.cursor, next_cursor=next_cursor)

    def create_branch(self, command: CreateBranchCommand) -> BranchResult:
        self._require_live(command.context)
        handle = self.workspace.branch(command.name, from_branch=command.from_branch)
        value = getattr(handle, "meta", {})
        return BranchResult(action="created", branch=command.name, value=dict(value))

    def get_diff(self, command: GetDiffCommand) -> BranchResult:
        self._require_live(command.context)
        return BranchResult(
            action="diff",
            branch=command.branch,
            value=dict(self.workspace.diff(command.branch)),
        )

    def verify(self, command: VerifyBranchCommand) -> BranchResult:
        self._require_live(command.context)
        result = dict(self._verify_branch(command))
        if int(result.get("status", 1)) != 0:
            result.setdefault("allowed", False)
        return BranchResult(action="verified", branch=command.branch, value=result)

    def commit(self, command: CommitBranchCommand) -> BranchResult:
        self._require_live(command.context)
        # The injected use case must enforce exact scoped approval.  Direct
        # workspace.commit is intentionally unavailable from this method.
        digest = self._commit_branch(command)
        return BranchResult(
            action="committed",
            branch=command.branch,
            value={"commit": digest},
        )

    def abort(self, command: AbortBranchCommand) -> BranchResult:
        self._require_live(command.context)
        self.workspace.abort(command.branch)
        return BranchResult(action="aborted", branch=command.branch)

    def artifact_page(
        self,
        digest: str,
        *,
        offset: int = 0,
        limit: int = 32_768,
    ) -> ArtifactPage:
        raw = self.artifacts.get(digest.removeprefix("artifact:"))
        start = max(0, int(offset))
        size = min(65_536, max(256, int(limit)))
        chunk = raw[start : start + size]
        try:
            content = chunk.decode("utf-8")
            encoding = "utf-8"
        except UnicodeDecodeError:
            content = base64.b64encode(chunk).decode("ascii")
            encoding = "base64"
        next_offset = start + len(chunk) if start + len(chunk) < len(raw) else None
        return ArtifactPage(
            digest=digest,
            offset=start,
            next_offset=next_offset,
            total_bytes=len(raw),
            encoding=encoding,
            content=content,
        )

    def open_session(self, command: OpenSessionCommand) -> SessionResult:
        self._require_live(command.context)
        if self.sessions is None:
            raise ApplicationError(
                "session_unavailable", "session adapter is unavailable"
            )
        value = self.sessions.open(
            command.objective,
            model=command.model,
            base_branch=command.base_branch,
            protocol=command.protocol,
        )
        return SessionResult(action="opened", session=_model_mapping(value))

    def send_session_input(self, command: SendSessionInputCommand) -> SessionResult:
        self._require_live(command.context)
        if self.sessions is None:
            raise ApplicationError(
                "session_unavailable", "session adapter is unavailable"
            )
        return SessionResult(
            action="input_recorded",
            session=dict(self.sessions.send(command.session_id, command.message)),
        )

    def resume_session(self, command: ResumeSessionCommand) -> SessionResult:
        self._require_live(command.context)
        if self.sessions is None:
            raise ApplicationError(
                "session_unavailable", "session adapter is unavailable"
            )
        return SessionResult(
            action="resumed",
            session=_model_mapping(
                self.sessions.verify(command.session_id, command.command)
            ),
        )

    def cancel_session(self, command: CancelSessionCommand) -> SessionResult:
        self._require_live(command.context)
        if self.sessions is None:
            raise ApplicationError(
                "session_unavailable", "session adapter is unavailable"
            )
        return SessionResult(
            action="cancelled",
            session=_model_mapping(self.sessions.abort(command.session_id)),
        )


def _model_mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return dict(value)
    if hasattr(value, "model_dump"):
        return dict(value.model_dump(mode="json"))
    raise TypeError("application adapter returned an unsupported result")
