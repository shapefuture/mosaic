"""Managed, cancellable local step port for scheduled autonomous work.

The regular callable-based controller remains useful for foreground code, but a
scheduler that needs terminal local cancellation must use this port.  The port
launches an explicit argv in a new process group, sends the goal record only on
stdin, and requires a bounded JSON result on stdout.  It never invokes a shell.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import os
import pathlib
import subprocess
import sys
import time
import uuid
from typing import Any, Mapping, Protocol, TYPE_CHECKING

from .process_control import ProcessGroupCancellationReceipt, terminate_process_group

if TYPE_CHECKING:  # pragma: no cover
    from .long_running import GoalRecord


@dataclass(frozen=True)
class ManagedStepResult:
    state: str  # completed | failed | cancelled
    payload: dict[str, Any]
    returncode: int | None
    stdout_path: str
    stderr_path: str
    duration_seconds: float


class ManagedStepHandle(Protocol):
    def wait(self, timeout_seconds: float) -> ManagedStepResult | None: ...
    def cancel(self, reason: str) -> ProcessGroupCancellationReceipt: ...


class ManagedGoalStepPort(Protocol):
    max_runtime_seconds: float
    def start(self, goal: "GoalRecord") -> ManagedStepHandle: ...


class SubprocessGoalStep:
    """Explicit local argv step with a verifiable process-group cancellation path.

    The child receives one JSON goal record on standard input and must emit one
    JSON object to standard output on successful completion.  Output is bounded
    before parsing.  The caller, not a model, constructs this port.
    """

    def __init__(
        self,
        argv: list[str] | tuple[str, ...],
        *,
        cwd: pathlib.Path,
        max_runtime_seconds: float = 300.0,
        cancellation_grace_seconds: float = 2.0,
        max_output_bytes: int = 65_536,
        env: Mapping[str, str] | None = None,
    ) -> None:
        command = tuple(str(part) for part in argv)
        if not command or any(not part or "\x00" in part for part in command):
            raise ValueError("managed step requires a non-empty NUL-free argv")
        if max_runtime_seconds <= 0 or cancellation_grace_seconds < 0 or max_output_bytes <= 0:
            raise ValueError("managed step limits must be positive (grace may be zero)")
        self.argv = command
        self.cwd = pathlib.Path(cwd).resolve()
        self.max_runtime_seconds = float(max_runtime_seconds)
        self.cancellation_grace_seconds = float(cancellation_grace_seconds)
        self.max_output_bytes = int(max_output_bytes)
        self.env = dict(env or {})
        if not self.cwd.is_dir():
            raise ValueError("managed step cwd must exist and be a directory")

    def start(self, goal: "GoalRecord") -> "SubprocessGoalStepHandle":
        work = self.cwd / ".chimera" / "managed_steps"
        work.mkdir(parents=True, exist_ok=True)
        run_id = uuid.uuid4().hex
        stdout_path = work / f"{run_id}.stdout"
        stderr_path = work / f"{run_id}.stderr"
        safe_env = {key: value for key, value in os.environ.items() if key in {"PATH", "LANG", "LC_ALL"}}
        safe_env.update({str(key): str(value) for key, value in self.env.items() if str(key) in {"PATH", "LANG", "LC_ALL", "PYTHONPATH"}})
        stdout = stdout_path.open("wb")
        stderr = stderr_path.open("wb")
        try:
            process = subprocess.Popen(
                list(self.argv),
                cwd=str(self.cwd),
                stdin=subprocess.PIPE,
                stdout=stdout,
                stderr=stderr,
                env=safe_env or None,
                shell=False,
                start_new_session=True,
            )
            payload = json.dumps(goal.model_dump(mode="json"), sort_keys=True, separators=(",", ":")) + "\n"
            assert process.stdin is not None
            try:
                process.stdin.write(payload.encode("utf-8"))
                process.stdin.flush()
            finally:
                process.stdin.close()
        except Exception:
            stdout.close()
            stderr.close()
            raise
        stdout.close()
        stderr.close()
        return SubprocessGoalStepHandle(
            process,
            stdout_path=stdout_path,
            stderr_path=stderr_path,
            started_at=time.monotonic(),
            cancellation_grace_seconds=self.cancellation_grace_seconds,
            max_output_bytes=self.max_output_bytes,
        )


class SubprocessGoalStepHandle:
    def __init__(
        self,
        process: subprocess.Popen[bytes],
        *,
        stdout_path: pathlib.Path,
        stderr_path: pathlib.Path,
        started_at: float,
        cancellation_grace_seconds: float,
        max_output_bytes: int,
    ) -> None:
        self.process = process
        self.stdout_path = stdout_path
        self.stderr_path = stderr_path
        self.started_at = started_at
        self.cancellation_grace_seconds = cancellation_grace_seconds
        self.max_output_bytes = max_output_bytes
        self._result: ManagedStepResult | None = None

    def wait(self, timeout_seconds: float) -> ManagedStepResult | None:
        if self._result is not None:
            return self._result
        try:
            returncode = self.process.wait(timeout=max(0.0, float(timeout_seconds)))
        except subprocess.TimeoutExpired:
            return None
        self._result = self._terminal_result(returncode)
        return self._result

    def cancel(self, reason: str) -> ProcessGroupCancellationReceipt:
        receipt = terminate_process_group(
            self.process, reason=reason, grace_seconds=self.cancellation_grace_seconds,
        )
        if receipt.terminal:
            self._result = ManagedStepResult(
                state="cancelled",
                payload={},
                returncode=receipt.returncode,
                stdout_path=str(self.stdout_path),
                stderr_path=str(self.stderr_path),
                duration_seconds=max(0.0, time.monotonic() - self.started_at),
            )
        return receipt

    def _terminal_result(self, returncode: int) -> ManagedStepResult:
        duration = max(0.0, time.monotonic() - self.started_at)
        if returncode != 0:
            return ManagedStepResult(
                state="failed",
                payload={"detail": f"managed subprocess exited with status {returncode}"},
                returncode=returncode,
                stdout_path=str(self.stdout_path),
                stderr_path=str(self.stderr_path),
                duration_seconds=duration,
            )
        try:
            if self.stdout_path.stat().st_size > self.max_output_bytes:
                raise ValueError("managed subprocess stdout exceeds configured bound")
            raw = self.stdout_path.read_bytes()
            value = json.loads(raw.decode("utf-8"))
            if not isinstance(value, dict):
                raise ValueError("managed subprocess result must be a JSON object")
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            return ManagedStepResult(
                state="failed",
                payload={"detail": f"managed subprocess emitted invalid result: {type(exc).__name__}"},
                returncode=returncode,
                stdout_path=str(self.stdout_path),
                stderr_path=str(self.stderr_path),
                duration_seconds=duration,
            )
        return ManagedStepResult(
            state="completed",
            payload=dict(value),
            returncode=returncode,
            stdout_path=str(self.stdout_path),
            stderr_path=str(self.stderr_path),
            duration_seconds=duration,
        )
