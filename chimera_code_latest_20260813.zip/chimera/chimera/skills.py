"""Signed executable skill packages with typed effects, isolated admission tests, revocation, and rollback."""
from __future__ import annotations

import ast
import base64
import hashlib
import json
import os
import pathlib
import re
import shutil
import time
import uuid
from typing import Any, Callable, Iterable, Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from pydantic import BaseModel, ConfigDict, field_validator, model_validator

from .context_evidence import ContextSigner
from .effects import CapabilitySet, EffectRequest, check_effect
from .sandbox import Sandbox
from .wal import WAL


class SkillError(RuntimeError): pass
class SkillSignatureError(SkillError): pass
class SkillPolicyError(SkillError): pass


class FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class SkillFile(FrozenModel):
    path: str
    digest: str

    @field_validator("path")
    @classmethod
    def _path(cls, value: str) -> str:
        path = pathlib.PurePosixPath(value.replace("\\", "/"))
        if path.is_absolute() or not path.parts or any(part in {"..", ".", ""} for part in path.parts):
            raise ValueError("skill file path must be safe and relative")
        if path.parts[0].startswith("."):
            raise ValueError("skill files may not target hidden control directories")
        return path.as_posix()

    @field_validator("digest")
    @classmethod
    def _digest(cls, value: str) -> str:
        raw = value.removeprefix("sha256:")
        if not value.startswith("sha256:") or len(raw) != 64 or any(c not in "0123456789abcdef" for c in raw.lower()):
            raise ValueError("skill file digest must use sha256:<64 hex>")
        return value.lower()


class SkillEffect(FrozenModel):
    operation: str
    resources: tuple[str, ...] = ()


class SkillManifest(FrozenModel):
    schema_version: str = "chimera.skill.v1"
    name: str
    version: str
    entrypoint: str
    files: tuple[SkillFile, ...]
    effects: tuple[SkillEffect, ...]
    test_command: tuple[str, ...]
    signer_key_id: str = ""
    signature: str = ""

    @model_validator(mode="after")
    def _shape(self) -> "SkillManifest":
        if not re.fullmatch(r"[a-z][a-z0-9-]{1,63}", self.name):
            raise ValueError("skill name must be a lowercase slug")
        if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+(?:-[A-Za-z0-9.-]+)?", self.version):
            raise ValueError("skill version must be semantic version syntax")
        paths = [item.path for item in self.files]
        if not paths or len(paths) != len(set(paths)):
            raise ValueError("skill files must be non-empty and unique")
        entry_file = self.entrypoint.split(":", 1)[0]
        if entry_file not in paths or ":" not in self.entrypoint:
            raise ValueError("entrypoint must be listed-file.py:function")
        if not self.test_command:
            raise ValueError("skill package requires an admission test command")
        return self

    def unsigned_payload(self) -> dict[str, Any]:
        return self.model_dump(mode="json", exclude={"signature"})

    @property
    def manifest_hash(self) -> str:
        return _hash(self.model_dump(mode="json"))


def sign_skill_manifest(manifest: SkillManifest, signer: ContextSigner) -> SkillManifest:
    unsigned = manifest.model_copy(update={"signer_key_id": signer.key_id, "signature": ""})
    signature = signer.sign(_canonical(unsigned.unsigned_payload()))
    return unsigned.model_copy(update={"signature": signature})


class SkillTrustStore:
    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root).resolve()
        self.path = self.root / ".chimera" / "trust" / "skill_keys.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.wal = WAL(self.root)

    def _load(self) -> dict[str, Any]:
        return json.loads(self.path.read_text()) if self.path.exists() else {}

    def _write(self, value: dict[str, Any]) -> None:
        temporary = self.path.with_name(f".{self.path.name}.{uuid.uuid4().hex}.tmp")
        try:
            temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
            os.replace(temporary, self.path)
        finally:
            if temporary.exists(): temporary.unlink()

    def add_key(self, key_id: str, public_key: str, *, actor: str) -> None:
        raw = base64.b64decode(public_key, validate=True)
        actual = "ed25519:" + hashlib.sha256(raw).hexdigest()
        if actual != key_id:
            raise SkillSignatureError("public key does not match key_id")
        rows = self._load()
        rows[key_id] = {"public_key": public_key, "revoked": False, "actor": actor}
        self._write(rows)
        self.wal.append("skill_trust_key", {"key_id": key_id, "actor": actor})

    def revoke_key(self, key_id: str, *, reason: str, actor: str) -> None:
        rows = self._load()
        if key_id not in rows:
            raise KeyError(key_id)
        rows[key_id]["revoked"] = True
        rows[key_id]["revocation_reason"] = reason
        self._write(rows)
        self.wal.append("skill_trust_revoke", {"key_id": key_id, "actor": actor, "reason": reason})

    def public_key(self, key_id: str) -> str:
        row = self._load().get(key_id)
        if not row or row.get("revoked"):
            raise SkillSignatureError("skill signer is unknown or revoked")
        return str(row["public_key"])


TestRunner = Callable[[pathlib.Path, tuple[str, ...]], dict[str, Any]]


class SkillInstaller:
    def __init__(self, root: pathlib.Path, trust_store: Optional[SkillTrustStore] = None) -> None:
        self.root = pathlib.Path(root).resolve()
        self.trust = trust_store or SkillTrustStore(self.root)
        self.installed = self.root / ".chimera" / "skills" / "installed"
        self.installed.mkdir(parents=True, exist_ok=True)
        self.wal = WAL(self.root)

    @staticmethod
    def load_manifest(package: pathlib.Path) -> SkillManifest:
        path = package / "skill.json"
        if not path.exists(): raise SkillError("skill.json missing")
        return SkillManifest.model_validate_json(path.read_text())

    def _verify_signature(self, manifest: SkillManifest) -> None:
        if not manifest.signer_key_id or not manifest.signature:
            raise SkillSignatureError("skill manifest is unsigned")
        public = Ed25519PublicKey.from_public_bytes(base64.b64decode(self.trust.public_key(manifest.signer_key_id)))
        try:
            public.verify(base64.b64decode(manifest.signature, validate=True), _canonical(manifest.unsigned_payload()))
        except (InvalidSignature, ValueError) as exc:
            raise SkillSignatureError("skill manifest signature verification failed") from exc

    @staticmethod
    def _verify_files(package: pathlib.Path, manifest: SkillManifest) -> None:
        actual: set[str] = set()
        for path in package.rglob("*"):
            if path.is_symlink(): raise SkillPolicyError("skill packages may not contain symlinks")
            if path.is_file() and path.name != "skill.json":
                actual.add(path.relative_to(package).as_posix())
        expected = {item.path for item in manifest.files}
        if actual != expected:
            raise SkillPolicyError(f"skill package file set mismatch: missing={sorted(expected-actual)} extra={sorted(actual-expected)}")
        for item in manifest.files:
            digest = "sha256:" + hashlib.sha256((package / item.path).read_bytes()).hexdigest()
            if digest != item.digest:
                raise SkillPolicyError(f"skill file digest mismatch: {item.path}")
            if item.path.endswith(".py"):
                try: ast.parse((package / item.path).read_text(), filename=item.path)
                except SyntaxError as exc: raise SkillPolicyError(f"skill Python syntax invalid: {item.path}: {exc}") from exc

    @staticmethod
    def _verify_effects(manifest: SkillManifest, capability: CapabilitySet) -> None:
        for effect in manifest.effects:
            category = effect.operation.split(".", 1)[0]
            needs = {category: list(effect.resources)} if effect.resources else {}
            verdict = check_effect(EffectRequest(effect=effect.operation, needs=needs), capability)
            if not verdict.allowed or verdict.residual_obligations:
                raise SkillPolicyError(verdict.denied_reason or str(verdict.residual_obligations))

    @staticmethod
    def _default_runner(package: pathlib.Path, command: tuple[str, ...], capability: CapabilitySet) -> dict[str, Any]:
        result = Sandbox(package, capability).exec(list(command), timeout=120)
        return {"status": result.status, "stdout": result.stdout[-2000:], "stderr": result.stderr[-2000:], **result.evidence}

    def install(self, package: pathlib.Path, *, capability: CapabilitySet,
                test_runner: Optional[TestRunner] = None) -> dict[str, Any]:
        package = pathlib.Path(package).resolve()
        manifest = self.load_manifest(package)
        self._verify_signature(manifest)
        self._verify_files(package, manifest)
        self._verify_effects(manifest, capability)
        test = (test_runner(package, manifest.test_command) if test_runner
                else self._default_runner(package, manifest.test_command, capability))
        if test.get("status") != 0:
            raise SkillPolicyError("skill admission tests failed")
        if test.get("os_isolation") is not True:
            raise SkillPolicyError("skill admission tests require a real OS isolation backend")

        destination = self.installed / manifest.name / manifest.version
        if destination.exists():
            raise SkillPolicyError(f"skill version already installed: {manifest.name}@{manifest.version}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        staging = destination.parent / f".{manifest.version}.{uuid.uuid4().hex}.tmp"
        staging.mkdir()
        try:
            for item in manifest.files:
                target = staging / item.path
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(package / item.path, target)
            shutil.copy2(package / "skill.json", staging / "skill.json")
            receipt = {
                "name": manifest.name, "version": manifest.version,
                "manifest_hash": manifest.manifest_hash,
                "signer_key_id": manifest.signer_key_id,
                "test_evidence_hash": _hash(test),
                "installed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            }
            (staging / "receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
            os.replace(staging, destination)
        finally:
            if staging.exists(): shutil.rmtree(staging)
        head = destination.parent / "HEAD"
        previous = head.read_text().strip() if head.exists() else None
        temporary = head.with_suffix(".tmp")
        temporary.write_text(manifest.version)
        os.replace(temporary, head)
        self.wal.append("skill_install", {
            **receipt, "previous": previous,
            "effects_root": _hash([effect.model_dump(mode="json") for effect in manifest.effects]),
        })
        return {**receipt, "previous": previous, "active": True}

    def rollback(self, name: str, *, to_version: Optional[str] = None) -> dict[str, Any]:
        directory = self.installed / name
        head = directory / "HEAD"
        if not head.exists(): raise KeyError(name)
        current = head.read_text().strip()
        versions = sorted(
            (path.name for path in directory.iterdir() if path.is_dir()),
            key=lambda version: (directory / version / "receipt.json").stat().st_mtime,
        )
        if to_version is None:
            prior = [version for version in versions if version != current]
            if not prior: raise SkillPolicyError("no previous skill version to roll back to")
            target = prior[-1]
        else:
            target = to_version
            if target not in versions: raise KeyError(f"unknown installed version {name}@{target}")
        temporary = head.with_suffix(".tmp")
        temporary.write_text(target)
        os.replace(temporary, head)
        self.wal.append("skill_rollback", {"name": name, "from": current, "to": target})
        return {"name": name, "from": current, "to": target}


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()


def _hash(value: Any) -> str:
    return "sha256:" + hashlib.sha256(_canonical(value)).hexdigest()
