"""Durable fail-closed billing reservations for ambiguous provider cancellation."""

from __future__ import annotations

import pathlib
import time
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from .wal import WAL


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ProviderBillingReceipt(_Frozen):
    provider: str = Field(min_length=1, max_length=100)
    provider_request_id: str = Field(min_length=1, max_length=300)
    billable_tokens: int = Field(ge=0)
    cost_microusd: int = Field(ge=0)
    terminal_status: Literal["cancelled", "completed", "failed", "unknown"]
    authoritative: bool
    observed_at: float = Field(default_factory=time.time, gt=0)


class ProviderBillingState(_Frozen):
    request_id: str
    tenant_key: str
    provider: str
    max_tokens: int
    max_cost_microusd: int
    state: Literal["reserved", "locally_cancelled", "reconciled"]
    reconciliation_required: bool
    actual_tokens: int | None = None
    actual_cost_microusd: int | None = None
    provider_request_id: str | None = None
    terminal_status: str | None = None
    budget_breached: bool = False


class ProviderBillingLedger:
    """Hold worst-case budget until an authoritative provider receipt arrives.

    Closing a socket or cancelling a local task never releases the reservation.
    This limits exposure but deliberately does not claim provider-side billing stop.
    """

    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root).resolve()
        self.wal = WAL(self.root)

    def _states(self) -> dict[str, ProviderBillingState]:
        states: dict[str, ProviderBillingState] = {}
        for row in self.wal.replay(kind="provider_billing"):
            data = row["data"]
            action = data.get("action")
            request_id = str(data.get("request_id", ""))
            if action == "reserve":
                states[request_id] = ProviderBillingState(
                    request_id=request_id,
                    tenant_key=str(data["tenant_key"]),
                    provider=str(data["provider"]),
                    max_tokens=int(data["max_tokens"]),
                    max_cost_microusd=int(data["max_cost_microusd"]),
                    state="reserved",
                    reconciliation_required=True,
                )
            elif action == "local_cancel" and request_id in states:
                states[request_id] = states[request_id].model_copy(
                    update={
                        "state": "locally_cancelled",
                        "reconciliation_required": True,
                    }
                )
            elif action == "reconcile" and request_id in states:
                current = states[request_id]
                states[request_id] = current.model_copy(
                    update={
                        "state": "reconciled",
                        "reconciliation_required": False,
                        "actual_tokens": int(data["actual_tokens"]),
                        "actual_cost_microusd": int(data["actual_cost_microusd"]),
                        "provider_request_id": str(data["provider_request_id"]),
                        "terminal_status": str(data["terminal_status"]),
                        "budget_breached": bool(data["budget_breached"]),
                    }
                )
        return states

    def reserve(
        self,
        *,
        request_id: str,
        tenant_key: str,
        provider: str,
        max_tokens: int,
        max_cost_microusd: int,
    ) -> ProviderBillingState:
        if not request_id or not tenant_key or not provider:
            raise ValueError(
                "billing reservation requires request, tenant, and provider"
            )
        if max_tokens <= 0 or max_cost_microusd < 0:
            raise ValueError("billing reservation bounds are invalid")
        existing = self._states().get(request_id)
        expected = {
            "tenant_key": tenant_key,
            "provider": provider,
            "max_tokens": int(max_tokens),
            "max_cost_microusd": int(max_cost_microusd),
        }
        if existing is not None:
            if any(getattr(existing, key) != value for key, value in expected.items()):
                raise RuntimeError(
                    "billing request id is bound to different immutable limits"
                )
            return existing
        self.wal.append(
            "provider_billing",
            {"action": "reserve", "request_id": request_id, **expected},
        )
        return self._states()[request_id]

    def local_cancel(self, request_id: str, *, tenant_key: str) -> ProviderBillingState:
        current = self.get(request_id, tenant_key=tenant_key)
        if current.state == "reconciled":
            return current
        self.wal.append(
            "provider_billing",
            {
                "action": "local_cancel",
                "request_id": request_id,
                "tenant_key": tenant_key,
            },
        )
        return self.get(request_id, tenant_key=tenant_key)

    def reconcile(
        self,
        request_id: str,
        receipt: ProviderBillingReceipt,
        *,
        tenant_key: str,
    ) -> ProviderBillingState:
        current = self.get(request_id, tenant_key=tenant_key)
        if receipt.provider != current.provider:
            raise RuntimeError("billing receipt provider does not match reservation")
        if not receipt.authoritative:
            raise RuntimeError(
                "non-authoritative usage observation cannot release billing reservation"
            )
        if current.state == "reconciled":
            if (
                current.provider_request_id != receipt.provider_request_id
                or current.actual_tokens != receipt.billable_tokens
                or current.actual_cost_microusd != receipt.cost_microusd
                or current.terminal_status != receipt.terminal_status
            ):
                raise RuntimeError(
                    "billing reconciliation conflicts with prior receipt"
                )
            return current
        self.wal.append(
            "provider_billing",
            {
                "action": "reconcile",
                "request_id": request_id,
                "tenant_key": tenant_key,
                "provider_request_id": receipt.provider_request_id,
                "actual_tokens": receipt.billable_tokens,
                "actual_cost_microusd": receipt.cost_microusd,
                "terminal_status": receipt.terminal_status,
                "budget_breached": (
                    receipt.billable_tokens > current.max_tokens
                    or receipt.cost_microusd > current.max_cost_microusd
                ),
            },
        )
        return self.get(request_id, tenant_key=tenant_key)

    def get(self, request_id: str, *, tenant_key: str) -> ProviderBillingState:
        try:
            state = self._states()[request_id]
        except KeyError as exc:
            raise KeyError(request_id) from exc
        if state.tenant_key != tenant_key:
            raise PermissionError("billing reservation tenant mismatch")
        return state

    def unresolved_exposure_microusd(self, *, tenant_key: str) -> int:
        return sum(
            state.max_cost_microusd
            for state in self._states().values()
            if state.tenant_key == tenant_key and state.reconciliation_required
        )
