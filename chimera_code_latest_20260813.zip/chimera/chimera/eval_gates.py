"""Release/stress eval gate thresholds."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any

@dataclass(frozen=True)
class EvalGateResult:
    passed: bool; reasons: tuple[str,...]; metrics: dict[str,Any]
    def as_dict(self): return asdict(self)

class StrictStressGate:
    def __init__(self, *, min_pass_rate:float=1.0, max_median_wall:float=10.0, max_median_tokens:int=2500):
        self.min_pass_rate=min_pass_rate; self.max_median_wall=max_median_wall; self.max_median_tokens=max_median_tokens
    def evaluate(self, rows:list[dict[str,Any]])->EvalGateResult:
        reasons=[]; n=len(rows) or 1
        pass_rate=sum(1 for r in rows if r.get('chimera',{}).get('ok'))/n
        walls=sorted(r.get('chimera',{}).get('wall') for r in rows if isinstance(r.get('chimera',{}).get('wall'),(int,float)))
        toks=sorted(r.get('chimera',{}).get('tokens') for r in rows if isinstance(r.get('chimera',{}).get('tokens'),(int,float)))
        med_wall=walls[len(walls)//2] if walls else None; med_tokens=toks[len(toks)//2] if toks else None
        if pass_rate < self.min_pass_rate: reasons.append(f'pass_rate {pass_rate:.2f} < {self.min_pass_rate:.2f}')
        if med_wall is not None and med_wall > self.max_median_wall: reasons.append(f'median_wall {med_wall} > {self.max_median_wall}')
        if med_tokens is not None and med_tokens > self.max_median_tokens: reasons.append(f'median_tokens {med_tokens} > {self.max_median_tokens}')
        return EvalGateResult(not reasons, tuple(reasons), {'pass_rate':pass_rate,'median_wall':med_wall,'median_tokens':med_tokens})
