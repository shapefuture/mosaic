"""WAL-backed typed waits for durable agent workflows.

A wait is not a model turn.  This registry records the predicate, owner,
deadline, and opaque target reference so controllers can pause/resume without
polling or preserving raw user/MCP input in the transcript.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import StrEnum
import hashlib
import json
import pathlib
import time
import uuid
from typing import Any

from .wal import WAL


class WaitKind(StrEnum):
    APPROVAL = "approval"
    CHILD_RESULT = "child_result"
    PROCESS_EXIT = "process_exit"
    MCP_INPUT = "mcp_input"
    FILE_CHANGE = "file_change"
    EXTERNAL_EVENT = "external_event"


class WaitState(StrEnum):
    WAITING = "waiting"
    RESOLVED = "resolved"
    EXPIRED = "expired"
    CANCELLED = "cancelled"


@dataclass(frozen=True)
class WaitRecord:
    id: str
    run_id: str
    kind: str
    target_hash: str
    owner: str
    deadline: float
    state: str
    evidence_ref: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class WaitRegistry:
    def __init__(self, root: pathlib.Path) -> None:
        self.wal = WAL(pathlib.Path(root))

    @staticmethod
    def _hash(value: Any) -> str:
        return "sha256:" + hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()

    def register(self, *, run_id: str, kind: WaitKind, target: Any, owner: str, timeout_seconds: float, evidence_ref: str | None = None) -> WaitRecord:
        if not run_id or not owner or timeout_seconds <= 0:
            raise ValueError("wait requires run ID, owner, and positive timeout")
        record = WaitRecord(
            id="wait:" + uuid.uuid4().hex, run_id=str(run_id), kind=kind.value,
            target_hash=self._hash(target), owner=str(owner), deadline=time.time() + float(timeout_seconds),
            state=WaitState.WAITING.value, evidence_ref=evidence_ref,
        )
        self.wal.append("wait_registry", {"event": "registered", **record.as_dict()})
        return record

    def resolve(self, wait: WaitRecord, *, evidence_ref: str | None = None) -> WaitRecord:
        if wait.state != WaitState.WAITING.value:
            raise ValueError("only waiting record can resolve")
        if time.time() >= wait.deadline:
            return self.expire(wait)
        resolved = WaitRecord(**{**wait.as_dict(), "state": WaitState.RESOLVED.value, "evidence_ref": evidence_ref or wait.evidence_ref})
        self.wal.append("wait_registry", {"event": "resolved", **resolved.as_dict()})
        return resolved

    def expire(self, wait: WaitRecord) -> WaitRecord:
        expired = WaitRecord(**{**wait.as_dict(), "state": WaitState.EXPIRED.value})
        self.wal.append("wait_registry", {"event": "expired", **expired.as_dict()})
        return expired

    def cancel(self, wait: WaitRecord) -> WaitRecord:
        cancelled = WaitRecord(**{**wait.as_dict(), "state": WaitState.CANCELLED.value})
        self.wal.append("wait_registry", {"event": "cancelled", **cancelled.as_dict()})
        return cancelled

    def pending(self, run_id: str) -> tuple[WaitRecord, ...]:
        latest: dict[str, WaitRecord] = {}
        for row in self.wal.replay(kind="wait_registry"):
            data = row.get("data", {})
            if data.get("run_id") != run_id:
                continue
            try:
                latest[str(data["id"])] = WaitRecord(
                    id=str(data["id"]), run_id=str(data["run_id"]), kind=str(data["kind"]),
                    target_hash=str(data["target_hash"]), owner=str(data["owner"]), deadline=float(data["deadline"]),
                    state=str(data["state"]), evidence_ref=data.get("evidence_ref"),
                )
            except (KeyError, TypeError, ValueError):
                continue
        now = time.time()
        return tuple(record for record in latest.values() if record.state == WaitState.WAITING.value and record.deadline > now)
