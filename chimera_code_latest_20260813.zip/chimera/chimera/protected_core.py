"""Multiparty cooldown-gated protected-core manifest for self-modification boundaries."""
from __future__ import annotations
import base64,hashlib,json,os,pathlib,time
from typing import Iterable,Mapping,Optional
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from pydantic import BaseModel,ConfigDict,Field
from .context_evidence import ContextSigner
from .wal import WAL
class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
def _canonical(value):return json.dumps(value,sort_keys=True,separators=(",",":"),default=str).encode()
def _file(root,path):
    target=(root/path).resolve()
    if not target.is_relative_to(root) or not target.is_file():raise ValueError(f"protected path unavailable: {path}")
    return "sha256:"+hashlib.sha256(target.read_bytes()).hexdigest()
class ProtectedManifest(FrozenModel):version:int;entries:dict[str,str];created_at:float;previous_hash:Optional[str]=None
class ManifestAmendment(FrozenModel):version:int;entries:dict[str,str];created_at:float;effective_after:float;previous_hash:str
class ManifestApproval(FrozenModel):approver_id:str;amendment_hash:str;signature:str
class ProtectedCore:
    def __init__(self,root:pathlib.Path,trusted_approvers:Mapping[str,str],minimum_approvers:int=2,cooldown_seconds:float=48*3600):self.root=pathlib.Path(root).resolve();self.path=self.root/".chimera"/"governance"/"protected_manifest.json";self.path.parent.mkdir(parents=True,exist_ok=True);self.trusted=dict(trusted_approvers);self.minimum=max(2,int(minimum_approvers));self.cooldown=max(0.,float(cooldown_seconds));self.wal=WAL(self.root)
    @staticmethod
    def digest(value)->str:return "sha256:"+hashlib.sha256(_canonical(value.model_dump(mode="json"))).hexdigest()
    def initialize(self,paths:Iterable[str])->ProtectedManifest:
        if self.path.exists():return self.load()
        entries={str(path):_file(self.root,str(path)) for path in sorted(set(paths))};value=ProtectedManifest(version=1,entries=entries,created_at=time.time());self._write(value);self.wal.append("protected_manifest_initialized",{"manifest_hash":self.digest(value),"entries":len(entries)});return value
    def _write(self,value:ProtectedManifest):
        payload={**value.model_dump(mode="json"),"manifest_hash":self.digest(value)};temp=self.path.with_suffix(".tmp");temp.write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n");os.replace(temp,self.path)
    def load(self)->ProtectedManifest:
        payload=json.loads(self.path.read_text());expected=payload.pop("manifest_hash");value=ProtectedManifest.model_validate(payload)
        if self.digest(value)!=expected:raise ValueError("protected manifest hash mismatch")
        return value
    def verify(self)->dict:
        value=self.load();mismatches={path:{"expected":expected,"actual":(_file(self.root,path) if (self.root/path).exists() else None)} for path,expected in value.entries.items() if not (self.root/path).exists() or _file(self.root,path)!=expected};return {"valid":not mismatches,"manifest_hash":self.digest(value),"mismatches":mismatches}
    def propose(self,entries:Mapping[str,str],now:Optional[float]=None)->ManifestAmendment:
        current=time.time() if now is None else float(now);manifest=self.load();return ManifestAmendment(version=manifest.version+1,entries=dict(entries),created_at=current,effective_after=current+self.cooldown,previous_hash=self.digest(manifest))
    @staticmethod
    def approve(amendment:ManifestAmendment,approver_id:str,signer:ContextSigner)->ManifestApproval:
        digest="sha256:"+hashlib.sha256(_canonical(amendment.model_dump(mode="json"))).hexdigest();return ManifestApproval(approver_id=approver_id,amendment_hash=digest,signature=signer.sign(digest.encode()))
    def apply(self,amendment:ManifestAmendment,approvals:Iterable[ManifestApproval],now:Optional[float]=None)->ProtectedManifest:
        current=time.time() if now is None else float(now);manifest=self.load();digest="sha256:"+hashlib.sha256(_canonical(amendment.model_dump(mode="json"))).hexdigest()
        if amendment.previous_hash!=self.digest(manifest) or amendment.version!=manifest.version+1:raise ValueError("amendment does not extend current manifest")
        if current<amendment.effective_after:raise PermissionError("manifest amendment cooldown not elapsed")
        valid=set()
        for approval in approvals:
            if approval.amendment_hash!=digest:continue
            encoded=self.trusted.get(approval.approver_id)
            try:public=base64.b64decode(encoded,validate=True);Ed25519PublicKey.from_public_bytes(public).verify(base64.b64decode(approval.signature,validate=True),digest.encode());valid.add(approval.approver_id)
            except (ValueError,InvalidSignature,TypeError):continue
        if len(valid)<self.minimum:raise PermissionError("insufficient manifest approvers")
        for path,expected in amendment.entries.items():
            if _file(self.root,path)!=expected:raise ValueError(f"amendment digest is not current for {path}")
        value=ProtectedManifest(version=amendment.version,entries=amendment.entries,created_at=current,previous_hash=amendment.previous_hash);self._write(value);self.wal.append("protected_manifest_amended",{"manifest_hash":self.digest(value),"previous_hash":amendment.previous_hash,"approvers":sorted(valid),"entries":len(value.entries)});return value
