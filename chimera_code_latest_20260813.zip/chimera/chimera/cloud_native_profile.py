"""Cloud-native deployment profile guidance with local option preserved."""
from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class CloudNativeProfile(_Frozen):
    schema_version: str = "chimera.cloud-native-profile.v1"
    mode: str
    cloud_priority: bool
    local_supported: bool
    required_runtime_envs: tuple[str, ...]
    optional_provider_envs: tuple[str, ...]
    memory_minimization: tuple[str, ...]
    quality_preservation: tuple[str, ...]
    speed_efficiency: tuple[str, ...]
    notes: tuple[str, ...] = ()


class CloudNativeProfilePlanner:
    def build(self, *, mode: str = "selfhosted-cloud") -> CloudNativeProfile:
        if mode not in {"selfhosted-cloud", "local"}:
            raise ValueError("mode must be selfhosted-cloud or local")
        if mode == "local":
            return CloudNativeProfile(
                mode="local",
                cloud_priority=False,
                local_supported=True,
                required_runtime_envs=(),
                optional_provider_envs=("CEREBRAS_API_KEY", "GEMINI_API_KEY", "TOKENROUTER_API_KEY", "OPENROUTER_API_KEY"),
                memory_minimization=(
                    "use local certification bundles only when needed",
                    "keep Rust graph mirror optional and fail back to Python",
                    "avoid long-lived Restate/Postgres processes unless testing cloud paths",
                ),
                quality_preservation=(
                    "run local doctor bundle gates",
                    "run pytest and focused mutation gates",
                ),
                speed_efficiency=(
                    "use prompt-cache-safe stable prefixes",
                    "use focused coder micro mode for bounded targets",
                ),
            )
        return CloudNativeProfile(
            mode="selfhosted-cloud",
            cloud_priority=True,
            local_supported=True,
            required_runtime_envs=(
                "CHIMERA_POSTGRES_URL or DATABASE_URL",
                "CHIMERA_RESTATE_INGRESS or CHIMERA_RESTATE_ENDPOINT or RESTATE_ENDPOINT",
            ),
            optional_provider_envs=(
                "CEREBRAS_API_KEY",
                "GEMINI_API_KEY or GOOGLE_API_KEY",
                "TOKENROUTER_API_KEY or TOKENROUTER_KEY",
                "OPENROUTER_API_KEY or OPENROUTER_API_KEYS",
            ),
            memory_minimization=(
                "externalize durable state to PostgreSQL and Restate instead of local resident processes",
                "store large artifacts content-addressed and pass references through workflows",
                "keep Rust graph as mirror/fallback until broader runtime promotion gates pass",
                "use persisted graph/search indexes only with source-digest binding and fail-closed load",
                "prefer bounded workers and explicit concurrency over unbounded in-process fanout",
            ),
            quality_preservation=(
                "do not bypass local certification bundles: local, cloud-postgres, durable-restate, sandbox-linux",
                "cloud-runtime gate must require persistent endpoint envs",
                "provider capabilities require artifact-backed live canaries before route promotion",
                "local cancellation holds worst-case billing exposure until authoritative receipts arrive",
            ),
            speed_efficiency=(
                "use direct provider adapters where available instead of gateway indirection",
                "preserve prompt-cache stable prefixes and typed context manifests",
                "use Rust graph mirror/search where explicitly requested while retaining Python fallback",
                "use Restate/Postgres durable continuations for long-horizon cloud workers",
            ),
            notes=(
                "This profile is deployment guidance and gate wiring; it does not store secrets.",
                "Pure cloud runtime remains compatible with local certification/development profiles.",
            ),
        )
