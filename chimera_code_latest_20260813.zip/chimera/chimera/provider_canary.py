"""Small, explicit provider capability canaries.

This module transfers the useful part of Fable-style provider scanners: a fixed
probe set and a comparison-friendly receipt.  It is deliberately stricter than
those scanners:

* a response is reduced to observed protocol facts, never model prose;
* a passing ordinary completion cannot prove a tool/cache/session capability;
* the report is stored in Chimera's CAS before it can promote routing policy;
* session/sticky and response-chain claims are not probed by the current Chat
  Completions adapter and are therefore never promoted here.

Calling a live canary spends provider quota.  ``RLMRuntime.run_provider_canary``
is exposed only through an explicit CLI confirmation and is never run as part of
a coding task.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from typing import Any, Callable, Iterable, Mapping

from .artifacts import ContentAddressedArtifactStore
from .provider_capabilities import ProviderCapabilityRegistry


PROMOTABLE_CAPABILITIES = frozenset({"native_tools", "strict_json", "streaming", "prompt_cache"})
KNOWN_CAPABILITIES = PROMOTABLE_CAPABILITIES | {"sticky_session", "response_chain", "refusal_shape"}


@dataclass(frozen=True)
class CanaryOutcome:
    capability: str
    passed: bool
    promotable: bool
    reason: str
    observed: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ProviderCanaryReport:
    provider: str
    model: str
    protocol: str
    outcomes: tuple[CanaryOutcome, ...]

    @property
    def promoted(self) -> tuple[str, ...]:
        return tuple(item.capability for item in self.outcomes if item.promotable and item.passed)

    def as_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "model": self.model,
            "protocol": self.protocol,
            "outcomes": [item.as_dict() for item in self.outcomes],
            "promoted": list(self.promoted),
        }


class ProviderCanary:
    """Interpret fixed safe probes without retaining response content."""

    @staticmethod
    def _usage_snapshot(value: Any) -> dict[str, int]:
        usage = value if isinstance(value, Mapping) else {}
        nested = usage.get("prompt_tokens_details") if isinstance(usage.get("prompt_tokens_details"), Mapping) else {}
        keys = (
            "input_tokens", "output_tokens", "total_tokens",
            "cache_read_input_tokens", "cache_creation_input_tokens",
            "cached_tokens", "cache_read_tokens", "cache_creation_tokens",
        )
        result: dict[str, int] = {}
        for key in keys:
            raw = usage.get(key, nested.get(key))
            if isinstance(raw, (int, float)) and not isinstance(raw, bool):
                result[key] = int(raw)
        return result

    @staticmethod
    def native_tools(response: Mapping[str, Any], *, expected_name: str = "chimera_canary") -> CanaryOutcome:
        calls = response.get("tool_calls") if isinstance(response.get("tool_calls"), list) else []
        names: list[str] = []
        for raw in calls:
            if isinstance(raw, Mapping):
                function = raw.get("function") if isinstance(raw.get("function"), Mapping) else raw
                name = function.get("name") if isinstance(function, Mapping) else None
                if isinstance(name, str):
                    names.append(name)
        # RLMRuntime normalizes transport tool calls to {name, arguments}; the
        # evaluator accepts that shape as well so adapters can be tested in
        # isolation.
        names.extend(
            str(raw.get("name")) for raw in calls
            if isinstance(raw, Mapping) and isinstance(raw.get("name"), str)
        )
        names = list(dict.fromkeys(names))
        ok = bool(response.get("native_tool_transport")) and expected_name in names
        return CanaryOutcome(
            "native_tools", ok, True,
            "observed required native function call" if ok else "missing required native function-call envelope",
            {"native_tool_transport": bool(response.get("native_tool_transport")), "tool_names": names},
        )

    @staticmethod
    def strict_json(response: Mapping[str, Any], *, required_key: str = "chimera_canary") -> CanaryOutcome:
        text = response.get("answer")
        payload: Any = None
        parse_error = None
        if isinstance(text, str):
            try:
                payload = json.loads(text)
            except json.JSONDecodeError as exc:
                parse_error = type(exc).__name__
        ok = isinstance(payload, Mapping) and payload.get(required_key) == "strict-json-v1"
        return CanaryOutcome(
            "strict_json", ok, True,
            "exact JSON object returned" if ok else "response was not the required strict JSON object",
            {
                "response_was_string": isinstance(text, str),
                "parsed_object": isinstance(payload, Mapping),
                "required_key": required_key in payload if isinstance(payload, Mapping) else False,
                "parse_error": parse_error,
            },
        )

    @staticmethod
    def streaming(response: Mapping[str, Any]) -> CanaryOutcome:
        first = response.get("first_text_ms")
        ok = bool(response.get("streamed")) and isinstance(first, (int, float)) and not isinstance(first, bool) and first >= 0
        return CanaryOutcome(
            "streaming", ok, True,
            "stream delivered text timing" if ok else "adapter did not observe a streaming text event",
            {"streamed": bool(response.get("streamed")), "first_text_ms": float(first) if ok else None},
        )

    @staticmethod
    def prompt_cache(first: Mapping[str, Any], second: Mapping[str, Any]) -> CanaryOutcome:
        first_usage = ProviderCanary._usage_snapshot(first.get("usage"))
        second_usage = ProviderCanary._usage_snapshot(second.get("usage"))
        cache_read = max((value for key, value in second_usage.items() if key in {
            "cache_read_input_tokens", "cached_tokens", "cache_read_tokens",
        }), default=0)
        # Request-side cache_control only shows that the adapter asked.  A
        # positive usage counter on the repeated prefix is the minimal proof of
        # reuse; otherwise this remains unproved even if it may be supported.
        ok = cache_read > 0
        return CanaryOutcome(
            "prompt_cache", ok, True,
            "repeated prefix reported cache-read tokens" if ok else "no cache-read usage was reported on repeated prefix",
            {"first_usage": first_usage, "second_usage": second_usage, "second_cache_read_tokens": cache_read},
        )

    @staticmethod
    def unsupported(capability: str, reason: str) -> CanaryOutcome:
        if capability not in KNOWN_CAPABILITIES:
            raise ValueError(f"unknown canary capability: {capability}")
        return CanaryOutcome(capability, False, False, reason, {})

    @staticmethod
    def refusal_shape(response: Mapping[str, Any]) -> CanaryOutcome:
        # This is an observability receipt, not a capability promotion.  It is
        # intentionally based on the adapter's normalized signal rather than a
        # risky prompt designed to induce a refusal.
        return CanaryOutcome(
            "refusal_shape", True, False,
            "normalized refusal/finish fields recorded; not a routing capability",
            {
                "refusal": bool(response.get("refusal")),
                "finish_reason_present": response.get("finish_reason") is not None,
                "provider_present": bool(response.get("provider")),
            },
        )

    @classmethod
    def report(cls, provider: str, model: str, outcomes: Iterable[CanaryOutcome]) -> ProviderCanaryReport:
        return ProviderCanaryReport(
            provider=str(provider or "").lower(), model=str(model),
            protocol="chimera-provider-canary-v1", outcomes=tuple(outcomes),
        )

    @staticmethod
    def persist(
        report: ProviderCanaryReport,
        artifacts: ContentAddressedArtifactStore,
        registry: ProviderCapabilityRegistry,
    ) -> tuple[str, dict[str, bool]]:
        ref = artifacts.put(
            json.dumps(report.as_dict(), sort_keys=True, separators=(",", ":")),
            media_type="application/vnd.chimera.provider-canary+json",
            provenance={"provider": report.provider, "model": report.model, "protocol": report.protocol},
        )
        evidence_ref = f"artifact:{ref.digest}"
        profile = registry.record_report(
            report.provider, report.model, evidence_ref,
            (item.as_dict() for item in report.outcomes),
        )
        return evidence_ref, {name: getattr(profile, name) for name in profile.names()}


def run_fixed_probes(
    provider: str,
    model: str,
    capabilities: Iterable[str],
    invoke: Callable[[str, str], Mapping[str, Any]],
) -> ProviderCanaryReport:
    """Run adapter-provided fixed probes.

    ``invoke`` receives a probe kind and a fixed non-sensitive prompt.  It is
    intentionally supplied by the adapter so this evaluator never handles API
    keys, headers, raw HTTP bodies, or arbitrary user prompts.
    """
    requested = tuple(dict.fromkeys(str(value) for value in capabilities))
    unknown = set(requested) - KNOWN_CAPABILITIES
    if unknown:
        raise ValueError(f"unknown canary capabilities: {sorted(unknown)}")
    outcomes: list[CanaryOutcome] = []
    for capability in requested:
        if capability == "native_tools":
            outcomes.append(ProviderCanary.native_tools(invoke("native_tools", "Call the required canary function.")))
        elif capability == "strict_json":
            outcomes.append(ProviderCanary.strict_json(invoke("strict_json", "Return the required strict JSON object.")))
        elif capability == "streaming":
            outcomes.append(ProviderCanary.streaming(invoke("streaming", "Reply with STREAM_CANARY_V1 only.")))
        elif capability == "prompt_cache":
            first = invoke("prompt_cache_prime", "Repeatable provider cache canary prefix v1.")
            second = invoke("prompt_cache_reuse", "Repeatable provider cache canary prefix v1.")
            outcomes.append(ProviderCanary.prompt_cache(first, second))
        elif capability == "refusal_shape":
            outcomes.append(ProviderCanary.refusal_shape(invoke("refusal_shape", "Reply with REFUSAL_SHAPE_CANARY_V1 only.")))
        else:
            # There is no Responses endpoint adapter in Chimera yet.  Never
            # infer this from a Chat Completions request or gateway marketing.
            outcomes.append(ProviderCanary.unsupported(
                capability,
                "current adapter has no endpoint-level session/response-chain probe",
            ))
    return ProviderCanary.report(provider, model, outcomes)
