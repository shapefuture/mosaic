"""Cheap task-readiness gate before expensive agent generation."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class TaskReadiness:
 observable:bool;scoped:bool;judge_independent:bool;irreversible:bool;reasons:tuple[str,...]
 def evidence(self)->dict[str,Any]:return self.__dict__
class TaskReadinessAudit:
 IRREVERSIBLE=('deploy production','purchase','payment','supplier','delete production','send email','external api')
 def audit(self,task:str,contract)->TaskReadiness:
  lower=task.lower();targets=getattr(contract,'targets',());tests=getattr(contract,'tests',{})
  reasons=[];observable=bool(tests)
  if not observable:reasons.append('no executable acceptance test was identified')
  scoped=bool(targets)
  if not scoped:reasons.append('no bounded target path was identified')
  judge=bool(tests)
  if not judge:reasons.append('success judge is model/self-reported rather than independent')
  irreversible=any(term in lower for term in self.IRREVERSIBLE)
  if irreversible:reasons.append('task mentions potentially irreversible external commitment')
  return TaskReadiness(observable,scoped,judge,irreversible,tuple(reasons))
