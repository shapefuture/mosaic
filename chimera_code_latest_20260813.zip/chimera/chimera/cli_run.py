"""Core branch/run/verification CLI commands."""
from __future__ import annotations

import json
import pathlib

import click
from rich.json import JSON
from rich.table import Table


def register(main: click.Group, *, console, application, cli_context, cli_root, emit) -> None:
    _application = application
    _cli_context = cli_context
    _cli_root = cli_root
    _emit = emit

    @main.command()
    @click.argument("name")
    @click.option("--from", "from_branch", default="main", help="base branch")
    @click.option("--mount", default=None, help="mount URI e.g., s3://bucket/app")
    def branch(name, from_branch, mount):
        if mount:
            raise click.UsageError(
                "remote mount emulation is not a production capability; use an explicit verified storage adapter"
            )
        from .application import CreateBranchCommand
        value = _application().create_branch(CreateBranchCommand(
            name=name,
            from_branch=from_branch,
            context=_cli_context(),
        ))
        _emit(value)

    @main.command("mount")
    @click.argument("name")
    @click.argument("uri")
    def mount_cmd(name, uri):
        raise click.UsageError(
            "the historical S3/GDrive mount surface was local emulation and is quarantined; "
            "bind a verified ObjectStorageArtifactAdapter instead"
        )

    @main.command("snapshot")
    @click.argument("branch_name")
    def snapshot(branch_name):
        from .branch import TransactionalWorkspace
        ws=TransactionalWorkspace(_cli_root())
        h=ws.snapshot(branch_name)
        console.print(f"[green]Snapshot {branch_name}: {h[:16]}[/green]")
        console.print(f"[dim]AgentState snapshot stored, WAL appended[/dim]")

    @main.command("at")
    @click.argument("timestamp")
    def at_cmd(timestamp):
        from .branch import TransactionalWorkspace
        ws=TransactionalWorkspace(_cli_root())
        entries=ws.query_at(timestamp)
        console.print(f"[cyan]?at={timestamp} -> {len(entries)} WAL entries[/cyan]")
        console.print(JSON(json.dumps(entries[-3:], indent=2)))

    @main.command()
    @click.argument("branch_name")
    def diff(branch_name):
        from .application import GetDiffCommand
        _emit(_application().get_diff(GetDiffCommand(
            branch=branch_name,
            context=_cli_context(),
        )))

    @main.command()
    @click.argument("branch_name")
    @click.option("--task", required=True, help="Exact task bound to the scoped commit approval")
    @click.option("-m", "--message", required=True)
    def commit(branch_name, task, message):
        from .application import CommitBranchCommand
        _emit(_application().commit(CommitBranchCommand(
            branch=branch_name,
            task=task,
            message=message,
            context=_cli_context(),
        )))

    @main.command()
    @click.argument("branch_name")
    def abort(branch_name):
        from .application import AbortBranchCommand
        _emit(_application().abort(AbortBranchCommand(
            branch=branch_name,
            context=_cli_context(),
        )))

    @main.command("plan")
    @click.argument("task")
    @click.option("--max-atoms", default=14, type=int, show_default=True)
    @click.option("--json-output", is_flag=True, help="print the complete typed hierarchy")
    def plan_cmd(task, max_atoms, json_output):
        """Compile a broad objective into milestones and executable atoms."""
        from .graph import CodeGraph
        from .hierarchical import HierarchicalTaskCompiler
        root = _cli_root()
        graph = CodeGraph(root)
        try:
            graph.load()
        except Exception:
            graph.build()
        compiler = HierarchicalTaskCompiler(root, graph=graph, max_atoms=max_atoms)
        hierarchy = compiler.compile(task)
        if json_output:
            console.print(JSON(hierarchy.model_dump_json(indent=2)))
            return
        console.print(f"[bold cyan]Hierarchical plan[/bold cyan] {hierarchy.id}")
        console.print(f"complexity={hierarchy.metadata['complexity']['score']} atoms={len(hierarchy.atoms)} depth={hierarchy.metadata['recursive_plan_depth']}")
        for level_index, level in enumerate(hierarchy.levels):
            console.print(f"[bold]Level {level_index}[/bold]")
            for atom_id in level:
                atom = hierarchy.units[atom_id]
                console.print(f"  [green]{atom.id}[/green] {atom.title}: {atom.goal}")
                console.print(f"    targets={atom.targets} depends={atom.dependencies} test={atom.test_command}")

    @main.command()
    @click.argument("task")
    @click.option("--branch", "branch_name", default="exp-001")
    @click.option("--model", default="mock-echo")
    @click.option("--auto-commit", is_flag=True)
    @click.option("--high-risk-review", is_flag=True)
    @click.option("--json-output", is_flag=True, help="compatibility alias for global --output json")
    def rlm(task, branch_name, model, auto_commit, high_risk_review, json_output):
        from .application import ApplicationStatus, RunTaskCommand
        if json_output:
            click.get_current_context().find_root().obj["output"] = "json"
        result = _application().run(RunTaskCommand(
            task=task,
            branch=branch_name,
            model=model,
            auto_commit=auto_commit,
            high_risk_review=high_risk_review,
            context=_cli_context(),
        ))
        _emit(
            result,
            failure=result.status in {ApplicationStatus.UNAVAILABLE, ApplicationStatus.UNKNOWN_OUTCOME},
        )

    @main.command("provider-canary-plan")
    @click.argument("model")
    @click.option(
        "--capability", "capabilities", multiple=True, required=True,
        type=click.Choice(["native_tools", "strict_json", "streaming", "prompt_cache", "refusal_shape", "sticky_session", "response_chain"]),
        help="One fixed protocol capability to plan. Repeat to request more than one.",
    )
    def provider_canary_plan_cmd(model, capabilities):
        """Dry-run a provider canary command without network, quota, or secret disclosure."""
        from .provider_canary_plan import ProviderCanaryPlanner
        click.echo(ProviderCanaryPlanner().plan(model, capabilities).model_dump_json(indent=2))

    @main.command("provider-canary")
    @click.argument("model")
    @click.option(
        "--capability", "capabilities", multiple=True, required=True,
        type=click.Choice(["native_tools", "strict_json", "streaming", "prompt_cache", "refusal_shape", "sticky_session", "response_chain"]),
        help="One fixed protocol capability to probe. Repeat to request more than one.",
    )
    @click.option("--authorize-live-call", is_flag=True, help="required: canaries consume provider quota")
    def provider_canary_cmd(model, capabilities, authorize_live_call):
        """Run opt-in, fixed provider protocol probes and persist a redacted CAS receipt."""
        if not authorize_live_call:
            raise click.UsageError(
                "provider canaries can consume quota; re-run with --authorize-live-call after choosing the exact capability"
            )
        from .rlm import RLMRuntime
        runtime = RLMRuntime(_cli_root())
        try:
            result = runtime.run_provider_canary(model, capabilities)
        finally:
            runtime.close()
        console.print(JSON(json.dumps(result, indent=2)))
        enabled = [name for name, value in result["capabilities"].items() if value]
        console.print(
            "[green]Promoted only artifact-backed passing probes:[/green] "
            + (", ".join(enabled) if enabled else "none")
        )

    @main.command()
    @click.argument("cmd")
    @click.option("--branch", "branch_name", default=None, help="run in branch overlay")
    def run(cmd, branch_name):
        from .branch import TransactionalWorkspace
        from .sandbox import Sandbox
        from .config import ChimeraConfig
        cfg=ChimeraConfig.load()
        ws=TransactionalWorkspace(_cli_root()) if branch_name else None
        cap=cfg.to_capability_set()
        sb=Sandbox(workDir=_cli_root(), capability=cap, branch=branch_name, workspace=ws)
        console.print(f"[cyan]Sandbox exec:[/cyan] {cmd}")
        res=sb.exec(cmd)
        console.print(f"status={res.status} duration={res.duration_ms}ms")
        if res.stdout: console.print(f"[green]stdout:[/green]\n{res.stdout[:3000]}")
        if res.stderr: console.print(f"[yellow]stderr:[/yellow]\n{res.stderr[:3000]}")

    @main.command()
    @click.option("--trace", "trace_path", default=None)
    @click.option("--ltl", "ltl_prop", default="G(!writeOutsideAllow)")
    @click.option("--etas", "etas_path", default=None, help="Etas file .etas or .json with agent/spec")
    def check(trace_path, ltl_prop, etas_path):
        from .verifier import LTLMonitor
        from .effects import check_effect, CapabilitySet, EffectRequest
        from .etas import check_file
        from .config import ChimeraConfig
        if etas_path:
            cap=ChimeraConfig.load().to_capability_set()
            trace_p=pathlib.Path(trace_path) if trace_path else None
            res=check_file(pathlib.Path(etas_path), trace_p, cap)
            console.print(JSON(json.dumps(res, indent=2)))
            if res.get("spec_conformance"):
                console.print(f"[green]Etas HIR PASS[/green] {etas_path}")
            else:
                console.print(f"[red]Etas HIR FAIL[/red] violations: {res.get('violations')}")
            return
        if trace_path:
            trace=json.loads(pathlib.Path(trace_path).read_text())
            mon=LTLMonitor(ltl_prop)
            ok,msg=mon.check(trace)
            if ok:
                console.print(f"[green]LTL PASS[/green] {ltl_prop}")
            else:
                console.print(f"[red]LTL FAIL[/red] {ltl_prop}: {msg}")
            # Also show compositional AgentVerify
            from .verifier import CompositionalVerifier
            comp=CompositionalVerifier()
            comp_res=comp.check(trace)
            console.print(JSON(json.dumps({k: v[0] for k,v in comp_res.items()}, indent=2)))
        else:
            cap=CapabilitySet(fs_allow=["./src/**"], fs_deny=["/etc/**"])
            req=EffectRequest(effect="fs.write", needs={"fs": ["/tmp/pwn"]})
            v=check_effect(req, cap)
            console.print(JSON(json.dumps(v.model_dump(), indent=2)))
            console.print("[green]Etas check done — try --etas agent.etas --trace trace.json or --ltl \"G(request -> F response)\"[/green]")

    @main.command("verify")
    @click.option("--property", "prop_file", default=None, help="LTL property JSON e.g., props/liveness.ltl.json")
    def verify_cmd(prop_file):
        from .wal import WAL
        wal=WAL(_cli_root())
        if prop_file:
            res=wal.verify_with_ltl(pathlib.Path(prop_file))
            console.print(JSON(json.dumps(res, indent=2)))
            if res["holds"]:
                console.print(f"[green]agentstate-cli verify PASS[/green] {res['formula']}")
            else:
                console.print(f"[red]agentstate-cli verify FAIL[/red] {res['violation']}")
        else:
            ok,bad=wal.verify_chain()
            console.print(f"[{'green' if ok else 'red'}]WAL chain {'OK' if ok else f'FAIL at {bad}'}[/]")
            # Show VMAO verify
            from .verifier import Verifier
            v=Verifier()
            # Example plan verify
            console.print("[dim]Use --property props/liveness.ltl.json for LTL (AgentVerify)[/dim]")

    @main.command()
    @click.option("--iterations", default=3)
    @click.option("--benchmark", default="terminal-bench2")
    def evolve(iterations, benchmark):
        from .evolution import EvolutionEngine
        eng=EvolutionEngine(_cli_root())
        console.print(f"[cyan]Evolving harness for {benchmark} {iterations} iters... (AEGIS+HarnessX+SIA+VeRO)[/cyan]")
        results=eng.evolve_loop(iterations=iterations)
        table=Table(title="Evolution (AEGIS Digester→Planner→Evolver→Critic + SIA GRPO)")
        table.add_column("iter"); table.add_column("variant"); table.add_column("accepted"); table.add_column("msg"); table.add_column("sia")
        for i,r in enumerate(results):
            table.add_row(str(i), r["new_variant"][:16], str(r["accepted"]), r["msg"][:40], f"{r.get('sia',{}).get('weight_delta',0):.3f}")
        console.print(table)
        # Show VeRO versions
        from .evolution import VeROOuter
        vero=VeROOuter(_cli_root())
        vers=vero.list_versions()
        if vers:
            console.print(f"[dim]VeRO versions: {len(vers)} latest {vers[-1]['version'][:16]} reward {vers[-1]['reward']:.2f}[/dim]")

    @main.command()
    def health():
        from .orchestrator import ChimeraHarness
        h=ChimeraHarness(_cli_root())
        click.echo(json.dumps(h.health(), indent=2, default=str))

