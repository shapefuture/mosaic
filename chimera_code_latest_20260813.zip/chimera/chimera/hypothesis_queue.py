"""Unified evidence-backed hypothesis queue and bounded warm trace miner."""
from __future__ import annotations
import hashlib,json,os,pathlib,time,uuid
from typing import Any,Literal,Iterable
from pydantic import BaseModel,ConfigDict,Field
from .wal import WAL
class Hypothesis(BaseModel):
 model_config=ConfigDict(extra="forbid")
 id:str;source:Literal["internal-miner","external-scout","fleet-gossip","population-mutation"];target_key:str;description:str;proposal_ref:str;evidence_refs:tuple[str,...];expected_value:float;confidence:float=Field(ge=0,le=1);cost:float=Field(ge=0);risk:float=Field(ge=0);status:Literal["queued","claimed","accepted","rejected"]="queued";created_at:str
 @property
 def score(self):return self.expected_value*self.confidence-self.cost-self.risk
class HypothesisQueue:
 def __init__(self,root:pathlib.Path):self.root=pathlib.Path(root);self.path=self.root/".chimera"/"hypotheses.json";self.path.parent.mkdir(parents=True,exist_ok=True);self.wal=WAL(self.root)
 def _load(self):return {k:Hypothesis.model_validate(v) for k,v in json.loads(self.path.read_text()).items()} if self.path.exists() else {}
 def _save(self,rows):
  t=self.path.with_suffix(".tmp");t.write_text(json.dumps({k:v.model_dump(mode="json") for k,v in rows.items()},indent=2,sort_keys=True)+"\n");os.replace(t,self.path)
 def submit(self,*,source,target_key,description,proposal_ref,evidence_refs,expected_value,confidence,cost,risk):
  if not evidence_refs or not proposal_ref:raise ValueError("hypothesis requires proposal and evidence refs")
  payload=f"{source}:{target_key}:{description}:{proposal_ref}";hid="hypothesis-"+hashlib.sha256(payload.encode()).hexdigest()[:16];rows=self._load()
  if hid in rows:return rows[hid]
  h=Hypothesis(id=hid,source=source,target_key=target_key,description=description,proposal_ref=proposal_ref,evidence_refs=tuple(evidence_refs),expected_value=expected_value,confidence=confidence,cost=cost,risk=risk,created_at=time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()));rows[hid]=h;self._save(rows);self.wal.append("hypothesis_submit",{"id":hid,"source":source,"target_key":target_key,"score":h.score});return h
 def ranked(self):return sorted((h for h in self._load().values() if h.status=="queued"),key=lambda h:(-h.score,h.id))
 def claim(self,hid):
  rows=self._load();h=rows[hid]
  if any(x.target_key==h.target_key and x.status in {"claimed","accepted"} for x in rows.values() if x.id!=hid):raise RuntimeError("conflicting hypothesis target already claimed/promoted")
  h.status="claimed";self._save(rows);self.wal.append("hypothesis_claim",{"id":hid,"target_key":h.target_key});return h
 def resolve(self,hid,accepted:bool,evidence_ref:str):
  if not evidence_ref:raise ValueError("resolution evidence required")
  rows=self._load();h=rows[hid];h.status="accepted" if accepted else "rejected";self._save(rows);self.wal.append("hypothesis_resolve",{"id":hid,"accepted":accepted,"evidence_ref":evidence_ref});return h
class WarmTraceMiner:
 def __init__(self,queue:HypothesisQueue,max_per_trace:int=3):self.queue=queue;self.max=max_per_trace
 def mine(self,trace:Iterable[dict[str,Any]]):
  failures=[]
  for e in trace:
   kind=str(e.get("kind","")).lower()
   if any(x in kind for x in ("timeout","error","denied","failed","conflict")):failures.append((kind,e.get("data",{})))
  output=[]
  for kind,data in failures[:self.max]:
   fp="sha256:"+hashlib.sha256(json.dumps({"kind":kind,"data":data},sort_keys=True,default=str).encode()).hexdigest()
   output.append(self.queue.submit(source="internal-miner",target_key=f"failure:{kind}",description=f"Reduce recurring {kind}",proposal_ref=fp,evidence_refs=(fp,),expected_value=.5,confidence=.5,cost=.1,risk=.1))
  return output
