"""State-observation freshness tokens for consequential action planning."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Any, Mapping


@dataclass(frozen=True)
class StatePrecondition:
    name: str
    digest: str


@dataclass(frozen=True)
class PreconditionCheck:
    valid: bool
    stale: tuple[str, ...]


def capture_preconditions(observed: Mapping[str, Any]) -> tuple[StatePrecondition, ...]:
    rows = []
    for name, value in sorted(observed.items()):
        raw = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()
        rows.append(StatePrecondition(str(name), "sha256:" + hashlib.sha256(raw).hexdigest()))
    return tuple(rows)


def validate_preconditions(expected: tuple[StatePrecondition, ...], current: Mapping[str, Any]) -> PreconditionCheck:
    actual = {row.name: row.digest for row in capture_preconditions(current)}
    stale = tuple(item.name for item in expected if actual.get(item.name) != item.digest)
    return PreconditionCheck(not stale, stale)
