"""Deterministic, conservative edit-atom fusion for candidate patch pools.

Fusion is an optimisation proposal only. The caller must still pass the fused
payload through PatchQualityGate, path policy, branch transaction and tests.
When atom locations cannot be proven disjoint from their exact old text, this
module abstains rather than composing potentially overlapping edits.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
from typing import Any, Mapping

from .patch_consensus import consensus


@dataclass(frozen=True)
class PatchFusionResult:
    payload: dict[str, Any] | None
    fused: bool
    reason: str
    support: int
    conflicts: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EditAtom:
    path: str
    old_hash: str
    old_text: str
    new_text: str
    support: int

    def as_patch(self) -> dict[str, str]:
        return {"path": self.path, "find": self.old_text, "replace": self.new_text}


def _value(row: Mapping[str, Any], *names: str) -> str:
    for name in names:
        value = row.get(name)
        if isinstance(value, str):
            return value
    return ""


def _edit_atoms(payloads: list[Mapping[str, Any]]) -> list[EditAtom]:
    counts: dict[tuple[str, str, str], int] = {}
    old_texts: dict[tuple[str, str, str], str] = {}
    # One candidate only votes once for an exact atom; duplicate rows in one
    # response must not manufacture consensus.
    for payload in payloads:
        seen: set[tuple[str, str, str]] = set()
        for row in payload.get("edits", []) or []:
            if not isinstance(row, Mapping):
                continue
            path = _value(row, "path", "p")
            old = _value(row, "find", "old", "old_text", "oldText", "o")
            new = _value(row, "replace", "new", "new_text", "newText", "n")
            if not path or not old or not new:
                continue
            key = (path, hashlib.sha256(old.encode()).hexdigest(), new)
            if key in seen:
                continue
            seen.add(key)
            counts[key] = counts.get(key, 0) + 1
            old_texts[key] = old
    return [
        EditAtom(path, old_hash, old_texts[(path, old_hash, new_text)], new_text, support)
        for (path, old_hash, new_text), support in counts.items()
    ]


def _atom_conflicts(atoms: list[EditAtom]) -> tuple[list[EditAtom], tuple[str, ...]]:
    """Reject same-span disagreement and conservatively reject text overlap."""
    by_path: dict[str, list[EditAtom]] = {}
    for atom in atoms:
        by_path.setdefault(atom.path, []).append(atom)
    accepted: list[EditAtom] = []
    conflicts: list[str] = []
    for path, rows in sorted(by_path.items()):
        by_old: dict[str, list[EditAtom]] = {}
        for atom in rows:
            by_old.setdefault(atom.old_hash, []).append(atom)
        candidates: list[EditAtom] = []
        for old_hash, group in by_old.items():
            new_values = {atom.new_text for atom in group}
            if len(new_values) != 1:
                conflicts.append(f"{path}: competing replacements for old:{old_hash[:12]}")
                continue
            candidates.append(group[0])
        safe: list[EditAtom] = []
        for atom in sorted(candidates, key=lambda item: (-item.support, item.old_hash, item.new_text)):
            if any(atom.old_text in prior.old_text or prior.old_text in atom.old_text for prior in safe):
                conflicts.append(f"{path}: overlapping edit atoms")
                continue
            safe.append(atom)
        accepted.extend(safe)
    return accepted, tuple(sorted(dict.fromkeys(conflicts)))


def fuse_patch_pool(payloads: list[Mapping[str, Any]], *, min_support: int = 2) -> PatchFusionResult:
    if min_support < 2:
        raise ValueError("edit-atom fusion requires at least two independent candidates")
    whole = consensus(payloads, min_votes=min_support)
    vote_counts = sorted(whole.votes.values(), reverse=True)
    unique_whole_winner = len(vote_counts) <= 1 or vote_counts[0] > vote_counts[1]
    if not whole.abstained and whole.selected is not None and unique_whole_winner:
        return PatchFusionResult(whole.selected, False, "whole-patch consensus", max(whole.votes.values() or [0]))

    atoms = [atom for atom in _edit_atoms(payloads) if atom.support >= min_support]
    safe_atoms, conflicts = _atom_conflicts(atoms)
    if safe_atoms:
        return PatchFusionResult(
            {
                "summary": "fused repeated non-overlapping edit atoms",
                "files": [],
                "edits": [atom.as_patch() for atom in safe_atoms],
                "insertions": [],
            },
            True,
            "edit-atom fusion",
            sum(atom.support for atom in safe_atoms),
            conflicts,
        )
    if conflicts:
        return PatchFusionResult(None, False, "edit-atom fusion abstained on conflict", 0, conflicts)

    # File-content atom fallback is only safe when a path receives one repeated
    # complete-file content. It never combines file atoms with edit atoms.
    by_path: dict[str, dict[str, int]] = {}
    for payload in payloads:
        rows = list(payload.get("files", []) or [])
        if isinstance(payload.get("f"), Mapping):
            rows.extend({"path": path, "content": content} for path, content in payload["f"].items())
        seen_files: set[tuple[str, str]] = set()
        for row in rows:
            if not isinstance(row, Mapping):
                continue
            path, content = row.get("path"), row.get("content")
            if not isinstance(path, str) or not isinstance(content, str) or (path, content) in seen_files:
                continue
            seen_files.add((path, content))
            by_path.setdefault(path, {})[content] = by_path.setdefault(path, {}).get(content, 0) + 1
    files: list[dict[str, str]] = []
    support = 0
    for path, contents in sorted(by_path.items()):
        content, votes = max(contents.items(), key=lambda item: (item[1], item[0]))
        if votes >= min_support:
            files.append({"path": path, "content": content})
            support += votes
    if files:
        return PatchFusionResult(
            {"summary": "fused repeated file atoms", "files": files, "edits": [], "insertions": []},
            True,
            "per-file repeated atom fusion",
            support,
        )
    return PatchFusionResult(None, False, "no repeated atoms", 0)
