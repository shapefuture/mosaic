"""Project Forge agent: find-before-build and lean-by-default advisory gates.

Ported/adapted from the user-supplied project-forge skill.  This is a separate
planning agent for stack/dependency/build-vs-reuse decisions; it never installs
or executes third-party project code.  It produces a compact, auditable gate
plan that can be embedded in Chimera self-improvement so the *next* iteration
must search for existing solutions and justify dependencies before building.
"""
from __future__ import annotations

import pathlib
from dataclasses import asdict, dataclass
from typing import Any, Iterable


@dataclass(frozen=True)
class ForgeGate:
    id: str
    name: str
    status: str  # run | skipped | ask | resolved
    evidence: str
    action: str


@dataclass(frozen=True)
class ForgeDecision:
    decision: str
    default_preference: str
    override_signals: tuple[str, ...]
    promotion_rule: str


class ProjectForgeAgent:
    """Separate agent for stack/architecture/tooling decisions.

    It is intentionally deterministic: live web/package-registry probing remains
    a later adapter because this agent's main value is enforcing the gates in
    order and preventing premature build/rewrite recommendations.
    """

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def plan(self, prompt: str, *, paths: Iterable[str] = ()) -> dict[str, Any]:
        prompt = str(prompt)
        path_list = tuple(str(p) for p in paths)
        mode = self.detect_mode(prompt, path_list)
        gates = self._gates(prompt, mode, path_list)
        decisions = self._decisions(prompt)
        return {
            "schema_version": "chimera.project-forge-agent-plan.v1",
            "mode": mode,
            "prompt_summary": prompt[:300],
            "paths": list(path_list),
            "gates": [asdict(gate) for gate in gates],
            "decisions": [asdict(decision) for decision in decisions],
            "permission_boundary": {
                "default": "read-only",
                "must_ask_before": ["install dependencies", "run scripts/tests/builds", "modify files", "commit/push", "open PR", "delete files", "change config"],
                "secret_policy": "detect but never print .env/*.pem/*.key/id_rsa/credentials/tokens",
            },
            "evidence_discipline": [
                "Do not invent star counts, prices, release dates, or maintenance status.",
                "Mark unverified claims explicitly.",
                "Chinese/non-English ecosystem sources are in scope for fast-moving infra categories.",
            ],
            "output_contract": "state Gates Run, evidence reviewed, comparable projects, cost/vendor reality, alternatives, final recommendation, and when it becomes wrong",
            "promotion_allowed": False,
            "promotion_rule": "Project Forge planning is advisory; implementation requires explicit user/task authorization and benchmark/evidence receipts.",
        }

    @staticmethod
    def detect_mode(prompt: str, paths: tuple[str, ...]) -> str:
        lower = prompt.lower()
        if any(word in lower for word in ("finished", "deployed", "production", "review this completed")):
            return "post-build-review"
        if paths or any(word in lower for word in ("repo", "github.com", "already using", "half-built", "i am building", "review my architecture")):
            return "mid-build-course-correction"
        return "pre-build-strategy"

    def _gates(self, prompt: str, mode: str, paths: tuple[str, ...]) -> tuple[ForgeGate, ...]:
        lower = prompt.lower()
        repo_context = bool(paths) or mode != "pre-build-strategy"
        maybe_dependency = any(word in lower for word in ("library", "dependency", "framework", "stack", "alternative", "scanner", "wrapper", "queue", "sandbox", "gateway", "database", "workflow"))
        trivial = any(word in lower for word in ("syntax", "null pointer", "translate", "grammar"))
        gates = [
            ForgeGate(
                "gate-0",
                "already-resolved-locally",
                "run" if repo_context else "skipped",
                "repo/path context present; inspect existing implementation before reopening decisions" if repo_context else "no repo/path context",
                "treat existing choices as standing unless explicitly questioned",
            ),
            ForgeGate(
                "gate-1",
                "find-before-build",
                "run" if maybe_dependency and not trivial else "skipped",
                "open stack/tooling decision detected" if maybe_dependency and not trivial else "no independent reusable component implied",
                "search package registries and GitHub before writing wrappers/scanners/libraries",
            ),
            ForgeGate(
                "gate-2",
                "lean-by-default",
                "run" if maybe_dependency and not trivial else "skipped",
                "dependency choice requires stdlib/port/dependency comparison" if maybe_dependency and not trivial else "not a dependency decision",
                "prefer self-contained, then small internal port, then maintained dependency only when superior",
            ),
            ForgeGate(
                "gate-3",
                "intake-if-too-vague",
                "ask" if mode == "pre-build-strategy" and self._too_vague(lower) else "skipped",
                "pre-build prompt lacks multiple decision-critical facts" if mode == "pre-build-strategy" and self._too_vague(lower) else "enough context or repo inspection should proceed",
                "ask at most seven concise questions only when materially needed",
            ),
            ForgeGate(
                "gate-4",
                "prior-art-for-novel-mechanism",
                "run" if self._novel_mechanism(lower) else "skipped",
                "non-trivial mechanism may break at scale" if self._novel_mechanism(lower) else "known implementation/CRUD/glue level decision",
                "fetch real prior art before designing from scratch; converge to one path, not a shortlist",
            ),
        ]
        return tuple(gates)

    @staticmethod
    def _too_vague(lower: str) -> bool:
        facts = [
            any(w in lower for w in ("user", "customer", "team", "solo")),
            any(w in lower for w in ("workflow", "use case", "task", "agent")),
            any(w in lower for w in ("budget", "$", "cheap", "free", "vps")),
            any(w in lower for w in ("cloud", "self-host", "k8s", "edge", "local")),
            any(w in lower for w in ("fast", "latency", "memory", "secure", "cost", "quality")),
        ]
        return sum(facts) < 3

    @staticmethod
    def _novel_mechanism(lower: str) -> bool:
        return any(w in lower for w in ("consensus", "ranking", "retrieval", "cache invalidation", "scheduler", "sandbox", "isolation", "workflow engine", "vector", "graph memory", "novel"))

    @staticmethod
    def _decisions(prompt: str) -> tuple[ForgeDecision, ...]:
        lower = prompt.lower()
        decisions: list[ForgeDecision] = []
        if any(w in lower for w in ("dependency", "library", "package", "framework", "stack", "alternative")):
            decisions.append(ForgeDecision(
                "build-vs-reuse",
                "self-contained stdlib if small and well-understood; otherwise small internal port; dependency only with evidence",
                ("complex protocol", "security-sensitive code already audited upstream", "large maintenance surface", "ecosystem standard with active support"),
                "must include Gate 1 findings and Gate 2 lean-vs-dependency rationale",
            ))
        if any(w in lower for w in ("cloud", "self-host", "k8s", "edge", "cost", "vps")):
            decisions.append(ForgeDecision(
                "cost-and-vendor-reality",
                "self-host/local-first until managed service provides measurable operational win",
                ("SLA/compliance requirement", "global edge latency", "team cannot operate infra", "managed cost lower than engineer time"),
                "must list prototype/launch/growth costs or mark them unverified",
            ))
        if any(w in lower for w in ("sandbox", "security", "isolation", "agent-generated", "hostile")):
            decisions.append(ForgeDecision(
                "threat-tier-fit",
                "match sandbox to trusted/semi-trusted/hostile workload rather than picking smallest RSS",
                ("hostile code", "KVM available", "WASI-compatible task", "needs full OS/package manager"),
                "must state what security guarantee is lost when choosing a lighter runtime",
            ))
        return tuple(decisions)
