"""Patch application and branch test execution methods for RLMRuntime."""
from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
from typing import Any, Dict, List

from .action_executor import ActionExecutor
from .sandbox import Sandbox


class RLMActionMixin:
    @staticmethod
    def _unique_text_replacement(current: str, needle: str, replacement: str):
        """Return updated text if needle has exactly one match, with tab-normalized fallback.

        Exact bytes are preferred.  If exact matching fails, compare expandtabs()
        forms and map the normalized span back to the original text.  This catches
        common model tab/space drift without fuzzy-rewriting untouched bytes.
        """
        count = current.count(needle)
        if count == 1:
            return current.replace(needle, replacement, 1), 1, "exact"
        expanded_current = current.expandtabs()
        expanded_needle = needle.expandtabs()
        expanded_replacement = replacement.expandtabs()
        expanded_count = expanded_current.count(expanded_needle)
        if expanded_count != 1:
            return None, count, "exact"
        # Build normalized-index -> original-index map.
        norm_chars = []
        norm_to_orig = []
        for oi, ch in enumerate(current):
            if ch == "\t":
                spaces = 8 - (len(norm_chars) % 8)
                for _ in range(spaces):
                    norm_chars.append(" "); norm_to_orig.append(oi)
            else:
                norm_chars.append(ch); norm_to_orig.append(oi)
        norm = "".join(norm_chars)
        start = norm.index(expanded_needle); end = start + len(expanded_needle)
        orig_start = norm_to_orig[start]
        orig_end = norm_to_orig[end-1] + 1
        return current[:orig_start] + expanded_replacement + current[orig_end:], 1, "expandtabs"

    def _lint_before_apply(self, path: str, source: str) -> list[str]:
        """Compatibility wrapper around the extracted ActionExecutor lint step."""
        return ActionExecutor.lint_before_apply(path, source)

    def _apply_patch_payload(self, branch: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        from .effects import EffectRequest, check_effect
        payload = self._normalise_patch_envelope(payload)
        if not isinstance(payload, dict):
            return {"applied": [], "rejected": ["patch payload must be an object"]}
        files = payload.get("files", [])
        edits = payload.get("edits", [])
        insertions = payload.get("insertions", [])
        if not isinstance(files, list) or not isinstance(edits, list) or not isinstance(insertions, list):
            return {"applied": [], "rejected": ["'files', 'edits', and 'insertions' must be lists"]}
        applied: List[str] = []
        rejected: List[str] = []
        high_risk_task = any(word in str(getattr(self, "_active_task", "")).lower() for word in ("auth", "security", "credential", "payment", "permission", "delete", "migration"))
        aci_only = os.environ.get("CHIMERA_ACI_ONLY") == "1" or (os.environ.get("CHIMERA_AUTO_ACI_HIGH_RISK", "1") == "1" and high_risk_task)
        if aci_only and files and not payload.get("aci_approved"):
            return {"applied": [], "rejected": ["raw file payload rejected: CHIMERA_ACI_ONLY requires ACI line edits or aci_approved payload"]}
        capability = self.config.to_capability_set()
        for item in files[:20]:
            if not isinstance(item, dict) or not isinstance(item.get("path"), str) or not isinstance(item.get("content"), str):
                rejected.append("malformed file entry")
                continue
            path = item["path"]
            verdict = check_effect(EffectRequest(effect="fs.write", needs={"fs": [path]}), capability)
            if not verdict.allowed or verdict.residual_obligations:
                rejected.append(f"{path}: {verdict.denied_reason or verdict.residual_obligations}")
                continue
            lint_problems = self._lint_before_apply(path, item["content"])
            if lint_problems:
                rejected.append(f"{path}: lint_failed: {'; '.join(lint_problems)}")
                continue
            try:
                self.workspace.write(branch, path, item["content"])
                self.branch_read_cache.invalidate_path(branch, path)
                self.awareness.write(branch, path, item["content"].encode())
                applied.append(path)
            except Exception as exc:
                rejected.append(f"{path}: {exc}")
        for edit in edits[:20]:
            if not isinstance(edit, dict) or not all(isinstance(edit.get(key), str) for key in ("path", "find", "replace")):
                rejected.append("malformed edit entry")
                continue
            path, needle, replacement = edit["path"], edit["find"], edit["replace"]
            verdict = check_effect(EffectRequest(effect="fs.write", needs={"fs": [path]}), capability)
            if not verdict.allowed or verdict.residual_obligations:
                rejected.append(f"{path}: {verdict.denied_reason or verdict.residual_obligations}")
                continue
            try:
                current_bytes = self.workspace.read(branch, path)
                self.awareness.read(branch, path, current_bytes)
                current = current_bytes.decode("utf-8")
                if any(key in edit for key in ("line_start", "line_end", "before_hash", "after_hash")):
                    from .line_anchor import verify
                    anchor_value = {"start": edit.get("line_start", 1), "end": edit.get("line_end", 1),
                                    "before_hash": edit.get("before_hash"), "after_hash": edit.get("after_hash")}
                    if not verify(current, anchor_value):
                        rejected.append(f"{path}: line anchor no longer matches current content")
                        continue
                updated, count, match_mode = self._unique_text_replacement(current, needle, replacement)
                if updated is None:
                    rejected.append(f"{path}: find block matched {count} times (must be exactly 1)")
                    continue
                lint_problems = self._lint_before_apply(path, updated)
                if lint_problems:
                    rejected.append(f"{path}: lint_failed: {'; '.join(lint_problems)}")
                    continue
                self.workspace.write(branch, path, updated)
                self.branch_read_cache.invalidate_path(branch, path)
                self.awareness.write(branch, path, updated.encode())
                applied.append(path)
            except Exception as exc:
                rejected.append(f"{path}: {exc}")
        for insertion in insertions[:20]:
            if not isinstance(insertion, dict) or not all(isinstance(insertion.get(key), str) for key in ("path", "anchor", "content")):
                rejected.append("malformed insertion entry")
                continue
            path = insertion["path"]
            anchor = insertion["anchor"]
            content = insertion["content"]
            position = insertion.get("position", "before")
            verdict = check_effect(EffectRequest(effect="fs.write", needs={"fs": [path]}), capability)
            if not verdict.allowed or verdict.residual_obligations:
                rejected.append(f"{path}: {verdict.denied_reason or verdict.residual_obligations}")
                continue
            try:
                current_bytes = self.workspace.read(branch, path)
                self.awareness.read(branch, path, current_bytes)
                current = current_bytes.decode("utf-8")
                if content.strip() and content.strip() in current:
                    applied.append(path)  # idempotent replay, no second insertion
                    continue
                command_match = re.search(r"@main\.command\(\s*[\"']([^\"']+)[\"']\s*\)", content)
                if command_match and re.search(
                    rf"@main\.command\(\s*[\"']{re.escape(command_match.group(1))}[\"']\s*\)", current
                ):
                    applied.append(path)
                    continue
                count = current.count(anchor)
                if count != 1:
                    rejected.append(f"{path}: insertion anchor matched {count} times (must be exactly 1)")
                    continue
                replacement = content + anchor if position == "before" else anchor + content
                updated = current.replace(anchor, replacement, 1)
                lint_problems = self._lint_before_apply(path, updated)
                if lint_problems:
                    rejected.append(f"{path}: lint_failed: {'; '.join(lint_problems)}")
                    continue
                self.workspace.write(branch, path, updated)
                self.branch_read_cache.invalidate_path(branch, path)
                self.awareness.write(branch, path, updated.encode())
                applied.append(path)
            except Exception as exc:
                rejected.append(f"{path}: {exc}")
        return {"applied": list(dict.fromkeys(applied)), "rejected": rejected}

    def _run_branch_tests(
        self, branch: str, command: str = "pytest -q", *, impact_scope: bool = True
    ) -> Dict[str, Any]:
        requested_command = command
        scope = None
        if impact_scope and command.strip() == "pytest -q":
            changed_paths = [operation.get("path", "") for operation in self.workspace.diff(branch).get("ops", [])]
            scope = self.impact_analyzer.analyze(path for path in changed_paths if path)
            command = scope.command
        from .test_acceleration import TestAccelerationPolicy
        acceleration = TestAccelerationPolicy.plan(command)
        command = acceleration.command
        capability = self.config.to_capability_set()
        from .capsule import workspace_input_root
        from .command_proof import CommandProofSpec
        import importlib.metadata, sys
        try: pytest_version = importlib.metadata.version("pytest")
        except importlib.metadata.PackageNotFoundError: pytest_version = "unavailable"
        from .command_proof import file_hashes, environment_hash
        changed_inputs = tuple(
            str(operation.get("path", "")) for operation in self.workspace.diff(branch).get("ops", [])
            if operation.get("path")
        )
        command_inputs = tuple(
            part for part in shlex.split(command)
            if (part.endswith(".py") or part.startswith("tests/")) and not part.startswith("-")
        )
        def branch_view_hashes(paths: tuple[str, ...]) -> tuple[str, ...]:
            rows = []
            for rel in sorted(set(path for path in paths if path)):
                try:
                    data = self.workspace.read(branch, rel)
                    rows.append(f"{rel}=sha256:{hashlib.sha256(data).hexdigest()}")
                except Exception:
                    rows.append(f"{rel}=<missing>")
            return tuple(rows)
        dependency_inputs = tuple(
            path for path in ("pyproject.toml", "requirements.txt", "poetry.lock", "uv.lock")
            if (self.root / path).exists()
        )
        proof_spec = CommandProofSpec(
            profile="test-gate",
            command=command,
            workspace_root=workspace_input_root(self.root, self.workspace, branch),
            runtime_versions=(f"python={sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}", f"pytest={pytest_version}"),
            policy_hash="sha256:" + hashlib.sha256(json.dumps(self.config.model_dump(mode="json"), sort_keys=True).encode()).hexdigest(),
            env_hash=environment_hash(),
            dependency_hashes=file_hashes(self.root, dependency_inputs),
            selected_input_hashes=branch_view_hashes(changed_inputs + command_inputs),
        )
        def execute_command():
            sandbox = Sandbox(workDir=self.root, capability=capability, branch=branch, workspace=self.workspace)
            result = sandbox.exec(command, timeout=120)
            return {"status": result.status, "stdout": result.stdout, "stderr": result.stderr,
                    "duration_ms": result.duration_ms, "evidence": result.evidence}
        proof = self.command_proofs.prove(proof_spec, execute_command)
        raw = proof.output
        status = int(raw.get("status", 1))
        execution_evidence = dict(raw.get("evidence", {}))
        execution_evidence["command_proof"] = {
            "reused": proof.reused, "spec_key": proof_spec.key,
            "receipt_hash": proof.receipt.receipt_hash,
            "completed_at": proof.receipt.completed_at,
            "signing_scope": proof.receipt.signing_scope,
        }
        execution_evidence["verification_scope"] = (
            scope.evidence() if scope else {
                "mode": "explicit", "command": command,
                "reason": "caller supplied a focused command" if requested_command != "pytest -q" else "full integration requested",
            }
        )
        execution_evidence["test_acceleration"] = acceleration.model_dump(mode="json")
        from .output_filter import filter_observation
        filtered = filter_observation("pytest", str(raw.get("stdout", "")), str(raw.get("stderr", "")), status, max_chars=6000)
        full_ref = self.artifacts.put(
            json.dumps({"stdout": raw.get("stdout", ""), "stderr": raw.get("stderr", ""), "status": status}, sort_keys=True),
            media_type="application/vnd.chimera.test-output+json",
            provenance={"branch": branch, "command_digest": hashlib.sha256(command.encode()).hexdigest()},
        )
        execution_evidence["output_filter"] = {
            "domain": filtered.domain, "original_chars": filtered.original_chars,
            "filtered_chars": filtered.filtered_chars, "anchors": list(filtered.anchors),
            "full_ref": full_ref.digest,
        }
        return {
            "status": status, "stdout": filtered.text, "stderr": "",
            "duration_ms": raw.get("duration_ms", 0), "command": command,
            "requested_command": requested_command, "full_output_ref": f"artifact:{full_ref.digest}",
            "evidence": execution_evidence,
        }


