"""Exact sealed-plan memoization keyed by task, graph root, compiler, and policy."""
from __future__ import annotations
import hashlib, json, os, pathlib, time, uuid
from typing import Any, Optional, Type
from .wal import WAL, wal_write

class PlanCache:
    def __init__(self, root: pathlib.Path):
        self.root=pathlib.Path(root).resolve(); self.dir=self.root/".chimera"/"plan_cache"; self.dir.mkdir(parents=True,exist_ok=True); self.wal=WAL(self.root)
    @staticmethod
    def graph_root(graph: Any) -> str:
        value=graph.graph if hasattr(graph,"graph") else graph
        payload={"nodes":value.get("nodes",[]),"edges":value.get("edges",[])} if isinstance(value,dict) else value
        return "sha256:"+hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":"),default=str).encode()).hexdigest()
    @staticmethod
    def key(*,task:str,graph_root:str,compiler_version:str,policy:dict[str,Any],hints:list[str]) -> str:
        payload={"task":task,"graph_root":graph_root,"compiler_version":compiler_version,"policy":policy,"hints":hints}
        return "sha256:"+hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":"),default=str).encode()).hexdigest()
    def _path(self,key:str)->pathlib.Path:return self.dir/f"{key.removeprefix('sha256:')}.json"
    def get(self,key:str,plan_type:Type[Any])->Optional[Any]:
        path=self._path(key)
        if not path.exists():wal_write(self.wal, "plan_cache_miss",{"key":key});return None
        try:
            value=json.loads(path.read_text()); digest=value.pop("record_hash")
            actual="sha256:"+hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":"),default=str).encode()).hexdigest()
            if digest!=actual or value.get("key")!=key:raise ValueError("plan cache record hash mismatch")
            plan=plan_type.model_validate(value["plan"])
        except Exception as exc:
            wal_write(self.wal, "plan_cache_corrupt",{"key":key,"error":f"{type(exc).__name__}: {exc}"[:300]});return None
        wal_write(self.wal, "plan_cache_hit",{"key":key,"plan":plan.id});return plan
    def put(self,key:str,plan:Any)->str:
        value={"key":key,"plan":plan.model_dump(mode="json"),"created_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())}
        digest="sha256:"+hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":"),default=str).encode()).hexdigest()
        payload={**value,"record_hash":digest};path=self._path(key);temp=path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        try:temp.write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n");os.replace(temp,path)
        finally:
            if temp.exists():temp.unlink()
        wal_write(self.wal, "plan_cache_store",{"key":key,"plan":plan.id,"record_hash":digest});return digest
