"""Focused-coder response coercion and patch generation calls."""
from __future__ import annotations

import hashlib
import os
from typing import Any, Dict, List, Mapping, Optional

from .generative_self_aggregation import build_gsa_patch_prompt
from .patch_consensus import consensus
from .patch_fusion import fuse_patch_pool
from .quality import ChangeTarget


class FocusedGenerationMixin:
        def _coerce_target_response(self, text: str, target: ChangeTarget) -> Optional[Dict[str, Any]]:
            """Compile common coding-model prose/fences into a typed patch envelope."""
            payload = self._normalise_patch_envelope(self._json_from_model(text))
            if isinstance(payload, dict) and any(payload.get(key) for key in ("files", "edits", "insertions")):
                # Some models obey the JSON envelope but put a Markdown fence in
                # the content string. Compile that fence before static admission.
                for item in payload.get("files", []):
                    if isinstance(item, dict) and item.get("path") == target.path and isinstance(item.get("content"), str):
                        extracted = self._extract_python_source(item["content"], target.path)
                        if extracted:
                            item["content"] = extracted
                return payload
            fences = self._python_fences(text)
            parseable: List[tuple[str, set[str]]] = []
            if target.path.endswith(".py"):
                import ast
                for code in fences:
                    try:
                        tree = self._parse_python_safely(code, target.path)
                        exported = {
                            node.name for node in tree.body
                            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                        }
                        parseable.append((code, exported))
                    except SyntaxError:
                        continue
            if target.mode == "create" and parseable:
                required = set((self._task_contract.required_symbols.get(target.path, []) if self._task_contract else []))
                eligible = [item for item in parseable if required.issubset(item[1])]
                # Prefer a file that exports the symbols required by tests; only
                # then use size to reject tiny echoed examples/assertions.
                code = max(eligible or parseable, key=lambda item: len(item[0]))[0]
                return {"summary": f"compiled fenced source for {target.path}",
                        "files": [{"path": target.path, "content": code}], "edits": [], "insertions": []}
            if target.mode == "edit" and parseable:
                candidates = [code for code, _ in parseable if "@main.command" in code or "@click.command" in code]
                if candidates:
                    code = max(candidates, key=len)
                    current = self.workspace.read("main", target.path).decode("utf-8", errors="ignore") if "main" in self.workspace.list_branches() else (self.root / target.path).read_text()
                    anchor = '\nif __name__ == "__main__":\n'
                    if anchor not in current:
                        anchor = "\nif __name__ == '__main__':\n"
                    if anchor in current:
                        return {"summary": f"compiled CLI insertion for {target.path}", "files": [], "edits": [],
                                "insertions": [{"path": target.path, "anchor": anchor, "position": "before", "content": "\n" + code + "\n"}]}
            return None
        def _strict_patch_call(self, prompt: str, model: str, target: ChangeTarget,
                               attempts: int = 2) -> tuple[Optional[Dict[str, Any]], Dict[str, Any], int]:
            total_tokens = 0
            diagnostics: List[Dict[str, Any]] = []
            response: Dict[str, Any] = {}
            current_prompt = prompt
            cache_session = "strict:" + target.path + ":" + hashlib.sha256(prompt.encode()).hexdigest()[:16]
            for attempt in range(attempts):
                live_suffix = current_prompt[len(prompt):] if current_prompt.startswith(prompt) else ""
                self._thread_local.prompt_cache_partition = self.prompt_cache.partition(
                    cache_session, prompt, live_suffix, live=live_suffix,
                )
                try:
                    candidate_count = max(1, min(5, int(os.environ.get("CHIMERA_MULTI_CANDIDATE_PATCHES", "1"))))
                except ValueError:
                    candidate_count = 1
                try:
                    max_candidate_tokens = int(os.environ.get("CHIMERA_MULTI_CANDIDATE_TOKEN_BUDGET", "6000"))
                except ValueError:
                    max_candidate_tokens = 6000
                if attempt == 0 and candidate_count > 1:
                    candidate_payloads = []
                    first_response: Dict[str, Any] = {}
                    for _candidate_index in range(candidate_count):
                        response = self.model_provider(current_prompt, model=model)
                        first_response = first_response or dict(response)
                        total_tokens += int(response.get("tokens", 0) or 0)
                        if total_tokens > max_candidate_tokens:
                            break
                        native_payload = None
                        for call in self._native_tool_calls(response.get("tool_calls")):
                            if call.get("name") == "chimera_submit_patch" and isinstance(call.get("arguments"), Mapping):
                                native_payload = self._normalise_patch_envelope(dict(call["arguments"]))
                                break
                        payload = native_payload or self._coerce_target_response(response.get("answer", "") or "", target)
                        if isinstance(payload, dict):
                            candidate_payloads.append(payload)
                    if os.environ.get("CHIMERA_GSA_SYNTHESIS", "0") == "1" and len(candidate_payloads) >= 2:
                        synthesis_prompt = build_gsa_patch_prompt(prompt, target, candidate_payloads)
                        previous_tools = getattr(self._thread_local, "provider_tools", None)
                        previous_choice = getattr(self._thread_local, "provider_tool_choice", None)
                        previous_json = getattr(self._thread_local, "provider_json_object", None)
                        self._thread_local.provider_tools = self._patch_submission_tool()
                        self._thread_local.provider_tool_choice = "required"
                        self._thread_local.provider_json_object = False
                        try:
                            synthesis_response = self.model_provider(synthesis_prompt, model=model)
                        finally:
                            self._thread_local.provider_tools = previous_tools
                            self._thread_local.provider_tool_choice = previous_choice
                            self._thread_local.provider_json_object = previous_json
                        total_tokens += int(synthesis_response.get("tokens", 0) or 0)
                        native_payload = None
                        for call in self._native_tool_calls(synthesis_response.get("tool_calls")):
                            if call.get("name") == "chimera_submit_patch" and isinstance(call.get("arguments"), Mapping):
                                native_payload = self._normalise_patch_envelope(dict(call["arguments"]))
                                break
                        synthesized = native_payload or self._coerce_target_response(synthesis_response.get("answer", "") or "", target)
                        if isinstance(synthesized, dict):
                            first_response["_quality_attempts"] = len(candidate_payloads) + 1
                            first_response["_gsa_synthesis"] = {
                                "candidate_count": len(candidate_payloads),
                                "synthesized": True,
                                "judged_or_ranked": False,
                            }
                            return synthesized, first_response, total_tokens
                        diagnostics.append({
                            "attempt": attempt + 1,
                            "gsa_synthesis": "invalid-or-empty",
                            "candidate_count": len(candidate_payloads),
                        })
                    min_votes=max(2, min(candidate_count, int(os.environ.get("CHIMERA_MULTI_CANDIDATE_MIN_VOTES", "2"))))
                    fusion = fuse_patch_pool(candidate_payloads, min_support=min_votes)
                    if fusion.payload is not None:
                        first_response["_quality_attempts"] = len(candidate_payloads)
                        first_response["_patch_fusion"] = fusion.as_dict()
                        return fusion.payload, first_response, total_tokens
                    decision = consensus(candidate_payloads, min_votes=min_votes, never_abstain=os.environ.get("CHIMERA_MULTI_CANDIDATE_NEVER_ABSTAIN") == "1")
                    if not decision.abstained and decision.selected is not None:
                        first_response["_quality_attempts"] = len(candidate_payloads)
                        first_response["_patch_consensus"] = decision.as_dict()
                        return decision.selected, first_response, total_tokens
                    diagnostics.append({"attempt": attempt + 1, "multi_candidate": decision.as_dict(), "patch_fusion": fusion.as_dict()})
                previous_tools = getattr(self._thread_local, "provider_tools", None)
                previous_choice = getattr(self._thread_local, "provider_tool_choice", None)
                previous_json = getattr(self._thread_local, "provider_json_object", None)
                self._thread_local.provider_tools = self._patch_submission_tool()
                self._thread_local.provider_tool_choice = "required"
                self._thread_local.provider_json_object = False
                try:
                    response = self.model_provider(current_prompt, model=model)
                finally:
                    self._thread_local.provider_tools = previous_tools
                    self._thread_local.provider_tool_choice = previous_choice
                    self._thread_local.provider_json_object = previous_json
                total_tokens += int(response.get("tokens", 0) or 0)
                native_payload = None
                for call in self._native_tool_calls(response.get("tool_calls")):
                    if call.get("name") == "chimera_submit_patch" and isinstance(call.get("arguments"), Mapping):
                        native_payload = self._normalise_patch_envelope(dict(call["arguments"]))
                        break
                payload = native_payload or self._coerce_target_response(response.get("answer", "") or "", target)
                if payload:
                    response["_quality_attempts"] = attempt + 1
                    return payload, response, total_tokens
                diagnostics.append({"attempt": attempt + 1, "chars": len(response.get("answer", "") or ""),
                                    "prefix": (response.get("answer", "") or "")[:160], "key_slot": response.get("key_slot")})
                # Keep the original instruction prefix byte-identical so provider
                # prompt caching can reuse it; append only the live repair directive.
                current_prompt = prompt + (
                    "\n\nFORMAT REPAIR: the previous output was not an actionable patch. "
                    "Return exactly one JSON object; first character {, last character }. Do not explain."
                )
            response["_quality_attempts"] = attempts
            response["_quality_diagnostics"] = diagnostics
            return None, response, total_tokens
