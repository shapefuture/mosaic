"""Hash-pinned tool-manifest attestations for third-party tool registries.

A precondition check cannot defend against a malicious tool description that
lies about its own effects.  For externally supplied MCP tools, an operator can
pin the canonical name/description/schema hash and fail closed when the
registry changes.  First-seen manifests are intentionally *not* trusted or
persisted as pins: trust-on-first-use would convert a poisoning event into a
baseline.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Iterable, Mapping


@dataclass(frozen=True)
class ToolAttestation:
    manifest_hash: str
    tool_hashes: dict[str, str]
    count: int


@dataclass(frozen=True)
class ToolAttestationVerdict:
    allowed: bool
    actual: ToolAttestation
    mismatched_tools: tuple[str, ...]
    unexpected_tools: tuple[str, ...]
    missing_tools: tuple[str, ...]
    reason: str


@dataclass(frozen=True)
class ToolManifestObservation:
    """A non-authoritative content-change observation for a tool registry."""

    state: str  # first_seen | unchanged | changed
    actual: ToolAttestation
    previous_manifest_hash: str | None


class ToolManifestChangeDetector:
    """Report genuine tool-manifest changes without creating a trust baseline.

    This mirrors the useful part of source-audited MCP registry callbacks: a
    rediscovery that is byte-identical should not trigger persistence or an
    operator alert.  The detector only observes hashes; it never promotes a
    first-seen or changed manifest to an allow-list pin.
    """

    def __init__(self, previous_manifest_hash: str | None = None) -> None:
        self._previous_manifest_hash = previous_manifest_hash

    @property
    def previous_manifest_hash(self) -> str | None:
        return self._previous_manifest_hash

    def observe(self, tools: Iterable[Mapping[str, Any]]) -> ToolManifestObservation:
        actual = ToolManifestAttestor.attest(tools)
        previous = self._previous_manifest_hash
        state = "first_seen" if previous is None else "unchanged" if previous == actual.manifest_hash else "changed"
        self._previous_manifest_hash = actual.manifest_hash
        return ToolManifestObservation(state, actual, previous)


class ToolManifestAttestor:
    @staticmethod
    def _hash(value: Any) -> str:
        raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    @classmethod
    def canonical_tool(cls, tool: Mapping[str, Any]) -> dict[str, Any]:
        name = tool.get("name")
        if not isinstance(name, str) or not name.strip():
            raise ValueError("tool manifest entry requires a non-empty name")
        schema = tool.get("inputSchema", tool.get("parameters", {}))
        if not isinstance(schema, Mapping):
            raise ValueError(f"tool {name!r} schema must be an object")
        return {
            "name": name.strip(),
            "description": str(tool.get("description", "")),
            "schema": dict(schema),
        }

    @classmethod
    def attest(cls, tools: Iterable[Mapping[str, Any]]) -> ToolAttestation:
        canonical = [cls.canonical_tool(item) for item in tools]
        names = [item["name"] for item in canonical]
        if len(names) != len(set(names)):
            raise ValueError("tool manifest has duplicate names")
        canonical.sort(key=lambda item: item["name"])
        hashes = {item["name"]: cls._hash(item) for item in canonical}
        return ToolAttestation(cls._hash(canonical), hashes, len(canonical))

    @classmethod
    def verify(
        cls,
        tools: Iterable[Mapping[str, Any]],
        *,
        expected_manifest_hash: str | None = None,
        expected_tool_hashes: Mapping[str, str] | None = None,
    ) -> ToolAttestationVerdict:
        actual = cls.attest(tools)
        expected = dict(expected_tool_hashes or {})
        mismatched = tuple(sorted(
            name for name, digest in expected.items()
            if name in actual.tool_hashes and actual.tool_hashes[name] != digest
        ))
        unexpected = tuple(sorted(set(actual.tool_hashes) - set(expected))) if expected else ()
        missing = tuple(sorted(set(expected) - set(actual.tool_hashes))) if expected else ()
        manifest_bad = bool(expected_manifest_hash and actual.manifest_hash != expected_manifest_hash)
        allowed = not (mismatched or unexpected or missing or manifest_bad)
        reason = (
            "manifest matches pinned digest" if allowed and (expected_manifest_hash or expected) else
            "no pin configured; attestation observed but not trusted" if allowed else
            "tool manifest diverged from operator pin"
        )
        return ToolAttestationVerdict(allowed, actual, mismatched, unexpected, missing, reason)
