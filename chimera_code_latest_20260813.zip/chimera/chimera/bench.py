"""Benchmark adapters.

Published benchmark scores are never synthesized from replay rewards.  A result
is either produced by a configured external harness and accompanied by command
and output evidence, or is reported as unavailable.
"""
from __future__ import annotations

import json
import os
import pathlib
import re
import shlex
import shutil
import subprocess
import time
from typing import Dict


BENCHMARKS = {
    "terminal-bench2": {"target": 84.0, "env": "CHIMERA_TB2_CMD"},
    "oolong-synthetic-4m": {"target": 81.36, "env": "CHIMERA_OOLONG_CMD"},
    "swe-bench-verified": {"target": 74.0, "env": "CHIMERA_SWEBENCH_CMD"},
    "gaia": {"target": 87.4, "env": "CHIMERA_GAIA_CMD"},
    "agentverify-15": {"target": 100.0, "env": "CHIMERA_AGENTVERIFY_CMD"},
    "mcp-sandboxscan-100": {"target": 0.0, "env": "CHIMERA_SANDBOXSCAN_CMD", "lower_is_better": True},
}


class BenchHarness:
    def __init__(self, root: pathlib.Path = pathlib.Path(".")):
        self.root = pathlib.Path(root).resolve()
        self.evidence_dir = self.root / ".chimera" / "bench"
        self.evidence_dir.mkdir(parents=True, exist_ok=True)

    def run(self, bench: str, model: str = "mock-echo", harness_variant: str = "default") -> Dict:
        if bench not in BENCHMARKS:
            return {"status": "error", "error": f"unknown benchmark {bench}", "known": list(BENCHMARKS)}
        spec = BENCHMARKS[bench]
        command = os.environ.get(spec["env"])
        if not command:
            return {
                "benchmark": bench, "model": model, "harness": harness_variant,
                "status": "unavailable", "score": None, "target": spec["target"],
                "evidence": f"Set {spec['env']} to the real benchmark command. No score was simulated.",
                "docker_available": shutil.which("docker") is not None,
            }
        started = time.time()
        try:
            result = subprocess.run(
                shlex.split(command), cwd=self.root, capture_output=True, text=True,
                timeout=int(os.environ.get("CHIMERA_BENCH_TIMEOUT", "1800")),
                env={**os.environ, "CHIMERA_MODEL": model, "CHIMERA_VARIANT": harness_variant},
            )
        except Exception as exc:
            return {"benchmark": bench, "status": "error", "score": None, "error": str(exc)}
        output = result.stdout + "\n" + result.stderr
        match = re.search(r"(?:score|pass(?:_rate| rate)?)\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)", output, re.IGNORECASE)
        score = float(match.group(1)) if match else None
        if score is not None and score <= 1 and spec["target"] > 1:
            score *= 100
        passed = score is not None and (
            score <= spec["target"] if spec.get("lower_is_better") else score >= spec["target"]
        ) and result.returncode == 0
        evidence_path = self.evidence_dir / f"{bench}-{int(started)}.json"
        evidence = {
            "benchmark": bench, "model": model, "variant": harness_variant,
            "command": shlex.split(command), "returncode": result.returncode,
            "duration_s": round(time.time() - started, 3), "score": score,
            "stdout": result.stdout[-20_000:], "stderr": result.stderr[-20_000:],
        }
        evidence_path.write_text(json.dumps(evidence, indent=2))
        return {
            "benchmark": bench, "model": model, "harness": harness_variant,
            "score": score, "target": spec["target"],
            "status": "pass" if passed else "fail" if score is not None else "error",
            "evidence": str(evidence_path), "returncode": result.returncode,
        }

    def diagnostic_proxy(self) -> Dict:
        """Local health diagnostics, explicitly not a benchmark score."""
        from .replay import ReplayBuffer
        from .wal import WAL
        from .graph import CodeGraph
        replay = ReplayBuffer(self.root).stats()
        wal_ok, bad = WAL(self.root).verify_chain()
        graph = CodeGraph(self.root)
        try:
            graph.load()
        except Exception:
            graph.build()
        return {"kind": "diagnostic-not-benchmark", "wal_ok": wal_ok, "wal_bad": bad,
                "graph": graph.stats(), "replay": replay}

    def leaderboard(self) -> Dict:
        return {name: self.run(name) for name in ("terminal-bench2", "oolong-synthetic-4m", "swe-bench-verified")}
