"""Provider-native compaction capability and measurement hooks.

Current certified providers in this workspace (Cerebras/Gemini/TokenRouter) do
not expose a verified native compaction API. This module makes that explicit and
keeps local compaction as fallback until a provider canary proves support.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any


@dataclass(frozen=True)
class NativeCompactionDecision:
    provider: str
    model: str
    supported: bool
    action: str
    reason: str
    def as_dict(self) -> dict[str, Any]: return asdict(self)


class NativeCompactionRegistry:
    # Conservative: only enable after a dedicated endpoint-level adapter/canary exists.
    KNOWN_NATIVE = {
        "openai-responses": False,
        "anthropic": False,
        "cerebras": False,
        "gemini": False,
        "tokenrouter": False,
        "openrouter": False,
    }
    def decide(self, provider: str, model: str) -> NativeCompactionDecision:
        supported = bool(self.KNOWN_NATIVE.get(str(provider), False))
        return NativeCompactionDecision(
            str(provider), str(model), supported,
            "native_compaction" if supported else "local_compaction_fallback",
            "native compaction not canary-proved for this provider/model" if not supported else "provider-native compaction canary-proved",
        )


class NativeCompactionCanary:
    """Capability canary placeholder: proves unsupported unless adapter exists."""
    def run(self, provider: str, model: str) -> NativeCompactionDecision:
        return NativeCompactionRegistry().decide(provider, model)


def ab_recall_test(local_text: str, compacted_text: str, required_terms: tuple[str, ...]) -> dict[str, object]:
    """Tiny recall comparator for native-vs-local compaction experiments."""
    local_hits = sum(1 for term in required_terms if term in local_text)
    compacted_hits = sum(1 for term in required_terms if term in compacted_text)
    return {
        "required_terms": list(required_terms),
        "local_hits": local_hits,
        "compacted_hits": compacted_hits,
        "recall_delta": compacted_hits - local_hits,
        "native_or_candidate_acceptable": compacted_hits >= local_hits,
    }
