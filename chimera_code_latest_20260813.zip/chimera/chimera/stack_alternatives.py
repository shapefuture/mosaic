"""Evidence-first optional stack alternatives for Chimera deployments."""
from __future__ import annotations

import importlib.util
import json
import pathlib
import shutil
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class StackAlternative:
    category: str
    name: str
    role: str
    default: bool
    fit: str
    local_mode_impact: str
    install_probe: str
    available: bool
    benchmark_command: str
    promotion_rule: str
    kill_criterion: str
    notes: tuple[str, ...]


def _cmd(name: str) -> bool:
    return shutil.which(name) is not None


def _mod(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


class StackAlternativesPlanner:
    """Return a machine-readable alternatives matrix, not a migration decree."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def plan(self) -> dict[str, Any]:
        alts = self._alternatives()
        return {
            "schema_version": "chimera.stack-alternatives-plan.v1",
            "root": str(self.root),
            "principle": "ports/adapters only; local JSONL/Postgres profile remains default until receipts prove a replacement",
            "alternatives": [asdict(item) for item in alts],
            "immediate_next_benchmarks": [
                "chimera platform runtime-density-benchmark --counts 1,10,100",
                "chimera platform gateway-benchmark --candidate agentgateway,agentify-gateway,bifrost,aisix,litellm --mock",
                "chimera platform event-bus-benchmark --candidate jsonl,nats,redpanda",
                "chimera platform cache-benchmark --candidate valkey,dragonfly,garnet",
                "chimera telemetry-duckdb --dry-run",
            ],
            "promotion_forbidden_without": [
                "same-workload benchmark receipt",
                "tenant isolation proof",
                "trace/cost propagation proof",
                "fallback/rollback path",
                "full test suite pass",
            ],
        }

    def _alternatives(self) -> list[StackAlternative]:
        return [
            self._alt("gateway", "direct-provider", "minimum-latency provider path", True, "single provider/model or latency critical", "preserves local/provider adapters", "builtin", True, "provider-canary direct route", "direct path stays available even when gateway profile is enabled", "direct route fails or lacks required provider feature", ("zero gateway hop", "best latency when broad routing is unnecessary")),
            self._alt("gateway", "agentgateway", "ultra-low-overhead gateway candidate", False, "high RPS and low memory gateway profile", "optional cloud/self-hosted only", "agentgateway", _cmd("agentgateway"), "chimera platform gateway-benchmark --candidate agentgateway --mock", "P95/P99 and RSS beat LiteLLM on Chimera workload and preserve streaming/tool/usage fields", "protocol parity failure or opaque governance", ("research showed strongest LiteLLM memory/latency delta",)),
            self._alt("gateway", "agentify-gateway", "Rust TensorZero-derived LLM gateway/eval/observability candidate", False, "self-hosted Rust gateway with OpenAI-compatible API plus eval/optimization primitives", "optional cloud/self-hosted only", "agentify-gateway/tensorzero-gateway/gateway", _cmd("agentify-gateway") or _cmd("tensorzero-gateway") or _cmd("gateway"), "chimera platform gateway-benchmark --candidate agentify-gateway --mock", "must beat LiteLLM or add unique eval/optimization value while preserving streaming/tool/usage fields", "no releases/maintenance-only status blocks production use", ("derived from archived TensorZero", "Apache-2.0", "conservative-maintenance candidate; benchmark before adoption")),
            self._alt("gateway", "bifrost", "Go low-latency LLM gateway", False, "self-hosted gateway with semantic cache/governance", "optional", "bifrost", _cmd("bifrost"), "chimera platform gateway-benchmark --candidate bifrost --mock", "must beat LiteLLM and pass provider canaries", "provider coverage mismatch", ("candidate for compiled low-latency routing",)),
            self._alt("gateway", "aisix", "Rust-native AI gateway", False, "Apache-2 Rust data plane with OpenAI/Anthropic routes", "optional", "aisix", _cmd("aisix"), "chimera platform gateway-benchmark --candidate aisix --mock", "must prove provider parity plus lower resident memory", "immature adapter blocks required routes", ("aligns with Rust hot-path strategy",)),
            self._alt("event-bus", "jsonl-wal", "local durable event log", True, "local/offline and tests", "default", "builtin", True, "pytest tests/test_final_runtime_protocol_upgrade.py", "default until cloud bus wins with receipts", "hash chain or replay law failure", ("simple", "auditable", "zero dependencies")),
            self._alt("event-bus", "nats-jetstream", "cloud fanout/backpressure/replay", False, "many parallel agents, subscribers, low operational footprint", "optional", "nats-server", _cmd("nats-server"), "chimera platform event-bus-benchmark --candidate nats", "beats JSONL polling for fanout while preserving replay cursors", "requires NATS for local mode or loses events", ("single binary", "good fit for agent fanout")),
            self._alt("event-bus", "redpanda", "Kafka-compatible stream", False, "Kafka migration / enterprise stream ecosystem", "optional cloud", "redpanda", _cmd("redpanda"), "chimera platform event-bus-benchmark --candidate redpanda", "only promote when Kafka compatibility is mandatory", "ops footprint exceeds value", ("heavier than NATS",)),
            self._alt("cache", "valkey", "open Redis-compatible baseline", False, "safe Redis replacement", "optional", "valkey-server", _cmd("valkey-server"), "chimera platform cache-benchmark --candidate valkey", "passes session/cache laws and cost test", "latency/memory worse than builtin/local store", ("safe baseline",)),
            self._alt("cache", "dragonfly", "high-throughput Redis-compatible cache", False, "high concurrency session/prompt-cache layer", "optional", "dragonfly", _cmd("dragonfly"), "chimera platform cache-benchmark --candidate dragonfly", "materially fewer nodes/RSS than Valkey on Chimera session workload", "Redis feature incompatibility", ("strong memory/throughput claims",)),
            self._alt("cache", "garnet", "RESP cache-store", False, "experimental high-throughput cache", "optional", "GarnetServer", _cmd("GarnetServer"), "chimera platform cache-benchmark --candidate garnet", "beats Valkey/Dragonfly and passes compatibility", "immaturity or client incompatibility", ("watch/research lane",)),
            self._alt("state", "postgres-rls", "enterprise durable tenant state", True, "cloud/self-hosted multi-tenant", "optional but certified profile exists", "psql", _cmd("psql"), "chimera doctor --profile cloud-postgres", "default enterprise state until alternatives prove tenant isolation", "RLS/SET LOCAL isolation failure", ("current strongest enterprise truth store",)),
            self._alt("state", "turso-libsql", "SQLite-per-agent/edge/local-first state", False, "edge/local-first/database-per-agent", "optional", "sqld/libsql", _cmd("sqld") or _mod("libsql"), "chimera platform state-store-benchmark --candidate libsql", "wins per-agent local latency and sync tests without replacing Postgres enterprise profile", "SQL compatibility or sync correctness failure", ("excellent for edge/per-agent isolation",)),
            self._alt("state", "neon", "serverless Postgres branching", False, "preview/eval databases and serverless PG", "cloud only", "NEON_DATABASE_URL", False, "chimera doctor --profile cloud-runtime", "use for ephemeral eval branches only after endpoint smoke", "tail latency or data residency mismatch", ("not a local default",)),
            self._alt("vector", "qdrant", "low-latency OSS vector memory", False, "filtered vector memory / hybrid retrieval", "optional", "qdrant", _cmd("qdrant"), "chimera platform memory-backend-benchmark --candidate qdrant", "beats pgvector/local search on recall/latency/cost", "extra service cost exceeds recall win", ("Rust implementation", "strong OSS speed profile")),
            self._alt("graph", "kuzu", "embedded graph/code-memory backend", False, "local graph memory and code graph traversals", "optional local", "kuzu python module", _mod("kuzu"), "chimera platform graph-backend-benchmark --candidate kuzu", "path queries materially beat current graph and preserve updates", "fork/maturity or concurrent-write failure", ("embedded", "zero infra", "Neo4j alternative")),
            self._alt("graph", "cozodb", "embedded relational-graph-vector Datalog", False, "Datalog rules over memory/code graph", "optional local", "cozo python module", _mod("cozo_embedded") or _mod("pycozo"), "chimera platform graph-backend-benchmark --candidate cozo", "improves explainable retrieval with bounded memory", "query complexity or package maturity blocks use", ("underexplored", "Rust core")),
            self._alt("telemetry", "duckdb", "local/offline analytics over WAL/JSONL", False, "developer/local telemetry and cost analysis", "optional local", "duckdb python module", _mod("duckdb"), "chimera telemetry-duckdb --dry-run", "fast local queries without changing WAL truth", "import loses rows or requires network", ("zero server", "excellent local reports")),
            self._alt("telemetry", "clickhouse", "high-cardinality AI telemetry backend", False, "enterprise/full-fidelity traces/logs", "optional cloud/self-hosted", "clickhouse-client", _cmd("clickhouse-client"), "chimera telemetry-otlp --endpoint clickhouse-collector", "wins cost/query at full fidelity", "ops burden too high", ("best for large AI logs",)),
            self._alt("telemetry", "openobserve/signoz", "self-hosted OTel backend", False, "low-cost observability stack", "optional", "openobserve/signoz", _cmd("openobserve") or _cmd("signoz"), "chimera telemetry-otlp --endpoint <collector>", "retains OTel semantics and lower TCO", "vendor lock-in or schema loss", ("ClickHouse/object-storage economics",)),
            self._alt("metrics", "victoriametrics", "Prometheus-compatible efficient metrics", False, "high-cardinality metrics", "optional", "victoria-metrics", _cmd("victoria-metrics"), "chimera platform metrics-backend-benchmark --candidate victoriametrics", "beats Prometheus memory/disk at same queries", "PromQL incompatibility for dashboards", ("metrics only",)),
            self._alt("api-server", "granian", "Rust ASGI server", False, "hosted GUI/API where ASGI server overhead matters", "optional", "granian", _cmd("granian") or _mod("granian"), "chimera gui-serve --server granian --host 0.0.0.0 --port 8766", "beats uvicorn on Chimera GUI smoke without WS/SSE regressions", "ASGI/WebSocket incompatibility", ("low-risk: does not change app code",)),
            self._alt("durable-execution", "restate", "single-binary durable services/workflows", True, "durable RPC, virtual objects, long waits", "optional profile already exists", "restate-server", _cmd("restate-server"), "chimera doctor --profile durable-restate", "keep as durable cloud candidate until lighter engines prove semantic parity", "BUSL/license or endpoint operations unacceptable", ("already unusually lightweight", "not replaced by plain queue")),
            self._alt("durable-execution", "dbos", "Postgres/SQLite-backed durable application code", False, "Python/Postgres-first workflows", "optional", "dbos python package", _mod("dbos"), "chimera platform durable-benchmark --candidate dbos", "must pass idempotent step replay and tenant storage laws", "requires unwanted Postgres or lacks needed workflow primitive", ("library model", "SQLite mode useful for local")),
            self._alt("durable-execution", "obelisk", "WASM Component deterministic durable workflows", False, "durable workflow engine with sandboxed workflow code", "optional", "obelisk", _cmd("obelisk"), "chimera platform durable-benchmark --candidate obelisk", "must prove deterministic replay, timers, signals, and lower overhead than Restate on Chimera workload", "pre-release or component packaging cost too high", ("underexplored", "real semantic alternative, not a queue")),
            self._alt("durable-execution", "go-workflows", "embedded Go Temporal-like engine", False, "Go sidecar/adapter where no separate control plane is wanted", "optional", "go library", False, "chimera platform durable-benchmark --candidate go-workflows", "only as adapter if Go control-plane is introduced", "language/runtime mismatch", ("SQLite/MySQL/Postgres/Redis backends",)),
            self._alt("durable-execution", "pg-durable", "Postgres extension durable SQL workflows", False, "SQL-centric jobs inside existing Postgres", "optional Postgres profile", "pg_durable extension", False, "chimera platform durable-benchmark --candidate pg-durable", "must preserve DB performance and avoid unsafe in-DB side effects", "preview extension risk", ("interesting when Postgres is already mandatory",)),
            self._alt("durable-execution", "honker", "SQLite queue/stream/scheduler extension", False, "queue-only local workflows, transactional outbox", "optional local", "honker extension", False, "chimera platform durable-benchmark --candidate honker", "use only when requirement is queue/stream, not replayed workflow", "mistaken for durable execution", ("queue only", "very small local option")),
            self._alt("sandbox", "crun-youki", "fast OCI runtime for trusted containers", False, "trusted first-party containers where speed matters", "optional Linux", "crun/youki", _cmd("crun") or _cmd("youki"), "chimera platform sandbox-alternatives-plan", "never promote as gVisor-equivalent for hostile code", "shared-kernel risk violates threat model", ("not security-equivalent to gVisor", "speed optimization only")),
            self._alt("sandbox", "cubesandbox", "KVM microVM sandbox service", False, "self-hosted high-density hardware isolation", "optional KVM Linux", "cubesandbox", _cmd("cubesandbox"), "chimera platform sandbox-benchmark --candidate cubesandbox", "must independently reproduce boot/RSS/isolation claims", "KVM unavailable or isolation review fails", ("Tencent RustVMM/KVM candidate", "do not trust vendor numbers blindly")),
            self._alt("sandbox", "hyperlight-wasm", "hardware-isolated function/WASM microVM", False, "function-level sandbox for WASM/Rust/C guests", "optional", "hyperlight", _cmd("hyperlight"), "chimera platform sandbox-benchmark --candidate hyperlight-wasm", "must beat Wasmtime while adding meaningful hardware boundary", "not compatible with full tool workload", ("not OCI/full Linux", "good for tiny tools")),
            self._alt("sandbox", "sandlock-agentjail", "Landlock/seccomp namespace process sandboxes", False, "low-overhead Linux process confinement", "optional local Linux", "sandlock/agentjail", _cmd("sandlock") or _cmd("agentjail"), "chimera platform sandbox-benchmark --candidate sandlock-agentjail", "must pass escape suite and document kernel ABI limits", "mistaken as full bwrap/gVisor replacement", ("Landlock is a layer, not full namespace replacement",)),
            self._alt("durable-execution", "rivet-actors-runtime", "durable actor/keyed state alternative to Restate", False, "TypeScript-first actor/session/user state with hibernation", "optional cloud/self-host", "rivet", _cmd("rivet"), "chimera platform durable-benchmark --candidate rivet-actors", "must prove keyed state recovery, workflow replay, and language fit", "TypeScript-first model blocks Chimera Python/Rust core", ("closest newly credible durable actor alternative", "not a queue")),
            self._alt("durable-execution", "orch8", "language-neutral REST-worker workflow engine", False, "polyglot native services without WASM packaging", "optional", "orch8", _cmd("orch8"), "chimera platform durable-benchmark --candidate orch8", "must prove retry/signal/snapshot semantics and acceptable license", "BUSL/early-stage risk unacceptable", ("ordinary-process worker model", "early/BUSL candidate")),
            self._alt("durable-execution", "durable-workflow-server", "HTTP/JSON external-worker durable workflow protocol", False, "extremely small protocol-first workflow experiments", "optional", "durable-workflow", _cmd("durable-workflow"), "chimera platform durable-benchmark --candidate durable-workflow-server", "must mature and pass Python query/update routing tests", "beta immaturity", ("watchlist only",)),
            self._alt("durable-execution", "durabletask-go", "SQLite-backed Durable Task sidecar", False, "Go/.NET/Java sidecar workflows", "optional", "durabletask-go", False, "chimera platform durable-benchmark --candidate durabletask-go", "must reach production readiness and useful SDK coverage", "work-in-progress status", ("architecturally appealing", "not production default")),
            self._alt("durable-execution", "wippy", "Go actor runtime with Lua/WASM and clustering", False, "underexplored all-in-one actor runtime", "optional", "wippy", _cmd("wippy"), "chimera platform durable-benchmark --candidate wippy", "must prove self-contained crash recovery independent of Temporal", "durability depends on external Temporal or unclear semantics", ("watchlist", "low-star but active")),
            self._alt("queue", "forq", "small HTTP/OpenAPI SQLite queue", False, "minimal HTTP-addressable queue with admin UI", "optional", "forq", _cmd("forq"), "chimera platform event-bus-benchmark --candidate forq", "queue only; must pass at-least-once/idempotency laws", "mistaken as workflow engine", ("queue tier only",)),
            self._alt("queue", "smoothmq", "self-hosted SQS-compatible SQLite queue", False, "standard AWS SDK clients with private endpoint", "optional", "smoothmq", _cmd("smoothmq"), "chimera platform event-bus-benchmark --candidate smoothmq", "must pass SQS compatibility and recovery tests", "young SQS edge-case failures", ("queue tier only",)),
            self._alt("queue", "pgmq", "Postgres queue extension", False, "Postgres-mandatory deployments needing SQL queue", "optional Postgres", "pgmq", False, "chimera platform event-bus-benchmark --candidate pgmq", "must not degrade Postgres tenant workloads", "keeps Postgres when trying to avoid it", ("queue tier only",)),
            self._alt("queue", "honker", "SQLite queue/stream/scheduler extension", False, "single-host transactional outbox and queue", "optional local", "honker", False, "chimera platform event-bus-benchmark --candidate honker", "queue only; use when SQLite locality matters", "single-writer/host constraints", ("queue tier only", "not durable workflow")),
            self._alt("sandbox", "wasmtime-wasi", "capability-isolated tool ABI", False, "small tools/validators/plugins", "optional", "wasmtime", _cmd("wasmtime"), "chimera platform wasi-tool-smoke --runtime wasmtime", "tool ABI passes receipt and is lower overhead than process sandbox", "WASI capability escape or missing language support", ("fastest safe plugin lane",)),
            self._alt("sandbox", "kata-cloud-hypervisor", "mature OCI/K8s microVM isolation", False, "hostile OCI workloads on KVM/Kubernetes", "optional Linux/K8s", "kata-runtime/cloud-hypervisor", _cmd("kata-runtime") or _cmd("cloud-hypervisor"), "chimera platform sandbox-benchmark --candidate kata-cloud-hypervisor", "must pass OCI compatibility and threat-model smoke", "ops footprint too high", ("conservative hostile-code baseline",)),
            self._alt("sandbox", "matchlock", "Firecracker wrapper for local agent sessions", False, "local CLI agents needing disposable VMs and credential proxy", "optional KVM Linux", "matchlock", _cmd("matchlock"), "chimera platform sandbox-benchmark --candidate matchlock", "must pass secret-injection and egress allowlist tests", "experimental local-agent runtime", ("emerging local Firecracker UX",)),
            self._alt("sandbox", "boxlite", "embedded microVM sandbox SDK", False, "application-embedded OCI-in-microVM sandbox", "optional KVM/HVF", "boxlite", _cmd("boxlite"), "chimera platform sandbox-benchmark --candidate boxlite", "must prove host jailer, snapshot safety, and workload compatibility", "libkrun threat-model caveat unresolved", ("embedded microVM candidate",)),
            self._alt("sandbox", "cocoon", "Cloud-Hypervisor/Firecracker microVM engine", False, "private VM fleet / Docker-like microVM CLI", "optional KVM", "cocoon", _cmd("cocoon"), "chimera platform sandbox-benchmark --candidate cocoon", "must prove snapshot/network/container-image semantics", "too young for hostile default", ("active underexplored microVM engine",)),
            self._alt("sandbox", "openshell", "agent policy runtime with Landlock/seccomp/netns", False, "semi-trusted agents needing policy and credential mediation", "optional Linux", "openshell", _cmd("openshell"), "chimera platform sandbox-benchmark --candidate openshell", "must pass policy enforcement/escape suite", "shared-kernel and policy-bypass risk", ("not microVM", "policy layer")),
            self._alt("sandbox", "ai-jail-greywall", "bwrap/Landlock/seccomp composition", False, "semi-trusted local coding agents", "optional Linux", "ai-jail/greywall", _cmd("ai-jail") or _cmd("greywall"), "chimera platform sandbox-benchmark --candidate ai-jail-greywall", "must document bwrap dependency and pass local escape suite", "not a VM boundary", ("composition not replacement",)),
            self._alt("sandbox", "firecracker-kata", "full-OS hardware isolation", False, "untrusted code needing shell/packages", "optional cloud/linux", "firecracker/kata", _cmd("firecracker") or _cmd("kata-runtime"), "chimera doctor --profile sandbox-linux", "required for hostile full OS multi-tenant workloads", "boot/memory cost exceeds threat model", ("do not replace WASI for small tools",)),
            self._alt("edge", "cloudflare-agents", "edge stateful actor profile", False, "global low-latency stateful agents", "cloud profile only", "wrangler", _cmd("wrangler"), "chimera platform edge-profile --target cloudflare", "only when user explicitly selects Cloudflare profile", "platform lock-in or DO locality latency", ("Durable Objects", "Workflows", "AI Gateway")),
            self._alt("edge", "rivet-actors", "stateful actors/agentOS", False, "one actor per session/user with hibernation", "optional cloud/self-host", "rivet", _cmd("rivet"), "chimera platform edge-profile --target rivet", "beats BEAM/Python resident shell on density benchmark", "immature semantics or sandbox mismatch", ("interesting alternative to BEAM/DO",)),
        ]

    @staticmethod
    def _alt(category: str, name: str, role: str, default: bool, fit: str, local_mode_impact: str, install_probe: str, available: bool, benchmark_command: str, promotion_rule: str, kill_criterion: str, notes: tuple[str, ...]) -> StackAlternative:
        return StackAlternative(category, name, role, default, fit, local_mode_impact, install_probe, available, benchmark_command, promotion_rule, kill_criterion, notes)


def main() -> None:  # pragma: no cover
    print(json.dumps(StackAlternativesPlanner(pathlib.Path.cwd()).plan(), indent=2, sort_keys=True))


if __name__ == "__main__":  # pragma: no cover
    main()
