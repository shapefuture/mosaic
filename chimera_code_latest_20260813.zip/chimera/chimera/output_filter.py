"""Deterministic domain-aware observation filtering with anchor preservation."""
from __future__ import annotations
import re
from dataclasses import dataclass
from .secret_scanner import redact_secrets, redact_encoded_secrets
from .control_sanitizer import sanitize_controls
from .text_truncation import utf8_safe_truncate

@dataclass(frozen=True)
class FilteredObservation:
    text:str
    original_chars:int
    filtered_chars:int
    anchors:tuple[str,...]
    domain:str

def filter_pytest(stdout:str,stderr:str,status:int,max_chars:int=6000)->FilteredObservation:
    combined=(stdout+"\n"+stderr).strip();lines=combined.splitlines();keep=set()
    patterns=(r"FAILED",r"ERROR",r"E\s+",r"ImportError|ModuleNotFoundError|cannot import name|No module named",r"\.(?:py|ts|js):\d+",r"short test summary",r"passed|failed|errors? in")
    for i,line in enumerate(lines):
        if any(re.search(p,line,re.I) for p in patterns):
            keep.update(range(max(0,i-2),min(len(lines),i+3)))
    if status==0:
        keep.update(range(max(0,len(lines)-8),len(lines)))
    if not keep:keep.update(range(max(0,len(lines)-30),len(lines)))
    selected="\n".join(lines[i] for i in sorted(keep))
    if len(selected)>max_chars:
        selected=utf8_safe_truncate(selected, max_chars, label="pytest").text
    redacted=redact_secrets(selected)
    encoded=redact_encoded_secrets(redacted.text)
    selected=sanitize_controls(encoded.text).text
    anchors=tuple(dict.fromkeys(re.findall(r"(?:[A-Za-z0-9_./-]+\.(?:py|ts|js)):\d+",selected)))
    text=f"exit_code={status}\n{selected}".strip()
    return FilteredObservation(text=text,original_chars=len(combined),filtered_chars=len(text),anchors=anchors,domain="pytest")

def filter_git(text:str,max_chars:int=4000)->FilteredObservation:
    lines=text.splitlines();selected=[]
    for line in lines:
        if re.match(r"^(commit |Author:|Date:| [^|]+\| |\s*\d+ files? changed|[+\-]{3} |@@)",line):selected.append(line)
    if not selected:selected=lines[:20]+lines[-20:]
    value="\n".join(selected)[:max_chars]
    return FilteredObservation(value,len(text),len(value),(),"git")

def filter_observation(domain:str,stdout:str,stderr:str="",status:int=0,max_chars:int=6000)->FilteredObservation:
    if domain=="pytest":return filter_pytest(stdout,stderr,status,max_chars)
    if domain=="git":return filter_git(stdout+stderr,max_chars)
    full=(stdout+stderr)
    original=len(full)
    redacted=redact_secrets(full).text
    redacted=redact_encoded_secrets(redacted).text
    redacted=sanitize_controls(redacted).text
    value=redacted if len(redacted.encode('utf-8'))<=max_chars else utf8_safe_truncate(redacted,max_chars,label=domain).text
    return FilteredObservation(value,original,len(value),(),domain)
