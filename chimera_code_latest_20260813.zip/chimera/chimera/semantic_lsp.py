"""Contained stdio-LSP adapter for the semantic code-intelligence port.

The adapter starts a fresh server for each snapshot-bound query.  That costs
startup time but prevents warm-session state from crossing source snapshots.
The subprocess receives no shell, no stdin inherited from the operator, a
minimal environment, and—by default—a Bubblewrap read-only workspace with an
unshared network namespace.  ``caller-contained`` mode exists for a test runner
or an outer sandbox that already supplies an equivalent boundary; it is never
selected implicitly.
"""
from __future__ import annotations

from collections import deque
import json
import os
import pathlib
import re
import select
import shutil
import signal
import subprocess
import threading
import time
from typing import Any, Literal
from urllib.parse import unquote, urlparse

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .semantic_code_intelligence import (
    CodeGraphSemanticAdapter,
    SemanticAdapterTimeout,
    SemanticAdapterUnavailable,
    SemanticCodeIntelligenceError,
    SemanticContextProjector,
    SemanticLocation,
    SemanticPosition,
    SemanticQueryReceipt,
    SemanticQueryRequest,
    SemanticRange,
    WorkspaceSnapshotter,
)
from .graph import CodeGraph
from .tokenizer import TokenizerMeasurer


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class LSPLaunchSpec(_FrozenModel):
    """Pinned process declaration supplied by an operator or sealed evaluator."""

    adapter_id: str = Field(min_length=1, max_length=200)
    argv: tuple[str, ...] = Field(min_length=1)
    isolation: Literal["bubblewrap", "caller-contained"] = "bubblewrap"
    # Pinned server code outside the workspace can be exposed explicitly as a
    # read-only same-path bind. No path is inferred from argv.
    readonly_bind_paths: tuple[str, ...] = ()
    initialization_options: dict[str, Any] = Field(default_factory=dict)
    max_message_bytes: int = Field(default=8 * 1024 * 1024, ge=1_024, le=64 * 1024 * 1024)

    @field_validator("argv")
    @classmethod
    def _argv(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        if any(not str(item) or "\x00" in str(item) for item in value):
            raise ValueError("LSP argv entries must be non-empty and contain no NUL")
        return tuple(str(item) for item in value)

    @field_validator("readonly_bind_paths")
    @classmethod
    def _binds(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        normalized: list[str] = []
        for item in value:
            path = pathlib.Path(item)
            if not path.is_absolute() or "\x00" in str(item):
                raise ValueError("LSP read-only bind paths must be absolute and NUL-free")
            normalized.append(str(path.resolve()))
        if len(normalized) != len(set(normalized)):
            raise ValueError("LSP read-only bind paths must be unique")
        return tuple(normalized)


class _FramedJSONRPC:
    def __init__(self, process: subprocess.Popen[bytes], *, max_message_bytes: int) -> None:
        assert process.stdin is not None and process.stdout is not None
        self.process = process
        self.stdin = process.stdin
        self.stdout = process.stdout
        self.max_message_bytes = max_message_bytes
        self.buffer = bytearray()
        self.next_id = 1
        self.notifications: deque[dict[str, Any]] = deque(maxlen=200)

    def send(self, message: dict[str, Any]) -> None:
        raw = json.dumps(message, separators=(",", ":")).encode("utf-8")
        if len(raw) > self.max_message_bytes:
            raise SemanticCodeIntelligenceError("outbound LSP message exceeds configured cap")
        try:
            self.stdin.write(f"Content-Length: {len(raw)}\r\n\r\n".encode("ascii") + raw)
            self.stdin.flush()
        except (BrokenPipeError, OSError) as exc:
            raise SemanticCodeIntelligenceError("language server transport closed") from exc

    def notify(self, method: str, params: dict[str, Any]) -> None:
        self.send({"jsonrpc": "2.0", "method": method, "params": params})

    def request(self, method: str, params: dict[str, Any], *, deadline: float) -> Any:
        request_id = self.next_id
        self.next_id += 1
        self.send({"jsonrpc": "2.0", "id": request_id, "method": method, "params": params})
        try:
            while True:
                message = self.read(deadline=deadline)
                if message.get("id") == request_id:
                    if "error" in message:
                        error = message.get("error") or {}
                        raise SemanticCodeIntelligenceError(
                            f"LSP {method} error {error.get('code')}: {error.get('message')}"
                        )
                    return message.get("result")
                if "method" in message and "id" in message:
                    # Language servers commonly ask for configuration during
                    # initialization.  Return empty, authority-free values.
                    result: Any = [] if message.get("method") == "workspace/configuration" else None
                    self.send({"jsonrpc": "2.0", "id": message["id"], "result": result})
                else:
                    self.notifications.append(message)
        except SemanticAdapterTimeout:
            try:
                self.notify("$/cancelRequest", {"id": request_id})
            except SemanticCodeIntelligenceError:
                pass
            raise

    def read(self, *, deadline: float) -> dict[str, Any]:
        marker = b"\r\n\r\n"
        while marker not in self.buffer:
            self._read_more(deadline)
            if len(self.buffer) > 65_536:
                raise SemanticCodeIntelligenceError("LSP header exceeds 64 KiB")
        header, _, remainder = self.buffer.partition(marker)
        self.buffer = bytearray(remainder)
        headers: dict[str, str] = {}
        for raw_line in header.split(b"\r\n"):
            try:
                key, value = raw_line.decode("ascii").split(":", 1)
            except (UnicodeDecodeError, ValueError) as exc:
                raise SemanticCodeIntelligenceError("malformed LSP header") from exc
            headers[key.lower().strip()] = value.strip()
        try:
            length = int(headers["content-length"])
        except (KeyError, ValueError) as exc:
            raise SemanticCodeIntelligenceError("LSP message has invalid content length") from exc
        if not 0 <= length <= self.max_message_bytes:
            raise SemanticCodeIntelligenceError("LSP message exceeds configured cap")
        while len(self.buffer) < length:
            self._read_more(deadline)
        body = bytes(self.buffer[:length])
        del self.buffer[:length]
        try:
            value = json.loads(body)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise SemanticCodeIntelligenceError("LSP body is not valid JSON") from exc
        if not isinstance(value, dict):
            raise SemanticCodeIntelligenceError("LSP body must be a JSON object")
        return value

    def _read_more(self, deadline: float) -> None:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise SemanticAdapterTimeout("LSP response deadline exceeded")
        if self.process.poll() is not None:
            raise SemanticCodeIntelligenceError(
                f"language server exited with status {self.process.returncode}"
            )
        readable, _, _ = select.select([self.stdout.fileno()], [], [], remaining)
        if not readable:
            raise SemanticAdapterTimeout("LSP response deadline exceeded")
        chunk = os.read(self.stdout.fileno(), 65_536)
        if not chunk:
            raise SemanticCodeIntelligenceError("language server closed stdout")
        self.buffer.extend(chunk)


class LSPSubprocessLifecycle:
    """One bounded process group and JSON-RPC transport."""

    def __init__(self, root: pathlib.Path, spec: LSPLaunchSpec) -> None:
        self.root = pathlib.Path(root).resolve()
        self.spec = spec
        self.process: subprocess.Popen[bytes] | None = None
        self.rpc: _FramedJSONRPC | None = None
        self._stderr_tail = bytearray()
        self._stderr_thread: threading.Thread | None = None

    def __enter__(self) -> "LSPSubprocessLifecycle":
        argv = self._argv()
        env = {
            "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
            "HOME": "/tmp",
            "LANG": os.environ.get("LANG", "C.UTF-8"),
            "LC_ALL": os.environ.get("LC_ALL", "C.UTF-8"),
        }
        try:
            self.process = subprocess.Popen(
                argv,
                cwd=str(self.root),
                env=env,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                shell=False,
                start_new_session=True,
            )
        except OSError as exc:
            raise SemanticAdapterUnavailable(f"cannot start language server: {exc}") from exc
        self.rpc = _FramedJSONRPC(self.process, max_message_bytes=self.spec.max_message_bytes)
        self._stderr_thread = threading.Thread(target=self._drain_stderr, daemon=True)
        self._stderr_thread.start()
        return self

    def _argv(self) -> list[str]:
        if self.spec.isolation == "caller-contained":
            return list(self.spec.argv)
        bwrap = shutil.which("bwrap")
        if not bwrap:
            raise SemanticAdapterUnavailable(
                "Bubblewrap is required for this LSP adapter; use caller-contained only inside an equivalent outer sandbox"
            )
        prefix = [
            bwrap,
            "--die-with-parent",
            "--new-session",
            "--unshare-net",
            "--proc", "/proc",
            "--dev", "/dev",
        ]
        for runtime in ("/usr", "/usr/local", "/bin", "/lib", "/lib64"):
            if pathlib.Path(runtime).exists():
                prefix += ["--ro-bind", runtime, runtime]
        # Create private /tmp before explicit candidate binds so a pinned
        # candidate located below /tmp remains visible rather than being hidden.
        prefix += ["--tmpfs", "/tmp"]
        for raw_path in self.spec.readonly_bind_paths:
            path = pathlib.Path(raw_path)
            if not path.exists():
                raise SemanticAdapterUnavailable(f"configured LSP read-only bind is missing: {path}")
            prefix += ["--ro-bind", str(path), str(path)]
        prefix += [
            "--ro-bind", str(self.root), str(self.root),
            "--setenv", "HOME", "/tmp",
            "--chdir", str(self.root),
        ]
        return [*prefix, *self.spec.argv]

    def _drain_stderr(self) -> None:
        assert self.process is not None and self.process.stderr is not None
        try:
            while True:
                chunk = self.process.stderr.read(4_096)
                if not chunk:
                    return
                self._stderr_tail.extend(chunk)
                if len(self._stderr_tail) > 16_384:
                    del self._stderr_tail[:-16_384]
        except OSError:
            return

    @property
    def stderr_tail(self) -> str:
        return bytes(self._stderr_tail).decode("utf-8", errors="replace")

    def initialize(self, *, deadline: float) -> dict[str, Any]:
        assert self.rpc is not None
        result = self.rpc.request("initialize", {
            "processId": None,
            "rootUri": self.root.as_uri(),
            "workspaceFolders": [{"uri": self.root.as_uri(), "name": self.root.name}],
            "capabilities": {
                "workspace": {"configuration": False},
                "textDocument": {
                    "definition": {},
                    "references": {},
                    "documentSymbol": {},
                    "callHierarchy": {"dynamicRegistration": False},
                },
            },
            "initializationOptions": self.spec.initialization_options,
        }, deadline=deadline)
        self.rpc.notify("initialized", {})
        return result if isinstance(result, dict) else {}

    def close(self, *, deadline: float | None = None) -> None:
        process = self.process
        if process is None:
            return
        if process.poll() is None and self.rpc is not None and deadline is not None and deadline > time.monotonic():
            try:
                self.rpc.request("shutdown", {}, deadline=deadline)
                self.rpc.notify("exit", {})
                process.wait(timeout=max(0.01, deadline - time.monotonic()))
            except Exception:
                pass
        if process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=0.5)
            except (ProcessLookupError, subprocess.TimeoutExpired):
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                try:
                    process.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    pass
        if self._stderr_thread is not None:
            self._stderr_thread.join(timeout=0.2)

    def __exit__(self, exc_type, exc, traceback) -> None:
        self.close(deadline=time.monotonic() + 0.5)


class LSPSubprocessSemanticAdapter:
    """Normalize supported LSP responses into snapshot-bound Chimera receipts."""

    def __init__(
        self,
        root: pathlib.Path,
        spec: LSPLaunchSpec,
        *,
        snapshotter: WorkspaceSnapshotter | None = None,
        tokenizer: TokenizerMeasurer | None = None,
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.spec = spec
        self.adapter_id = spec.adapter_id
        self.snapshotter = snapshotter or WorkspaceSnapshotter(self.root)
        self.projector = SemanticContextProjector(self.root, tokenizer)

    def query(self, request: SemanticQueryRequest) -> SemanticQueryReceipt:
        started = time.perf_counter()
        observed = self.snapshotter.capture()
        if observed.digest != request.snapshot_digest:
            return self._receipt(request, observed.digest, started, status="rejected", message="request snapshot is stale", stale=True)
        if request.operation == "imports":
            return self._receipt(request, observed.digest, started, status="unsupported", message="LSP has no portable imports query; use CodeGraph fallback")
        deadline = time.monotonic() + request.timeout_seconds
        lifecycle: LSPSubprocessLifecycle | None = None
        try:
            lifecycle = LSPSubprocessLifecycle(self.root, self.spec)
            with lifecycle:
                lifecycle.initialize(deadline=deadline)
                assert lifecycle.rpc is not None
                rpc = lifecycle.rpc
                document_uri: str | None = None
                if request.path is not None:
                    document = (self.root / request.path).resolve()
                    if not document.is_relative_to(self.root) or not document.is_file():
                        return self._receipt(request, observed.digest, started, status="error", message="query path does not exist")
                    document_uri = document.as_uri()
                    rpc.notify("textDocument/didOpen", {
                        "textDocument": {
                            "uri": document_uri,
                            "languageId": request.language_id or self._language_id(document),
                            "version": 1,
                            "text": document.read_text(encoding="utf-8", errors="replace"),
                        }
                    })
                raw = self._query(rpc, request, document_uri, deadline)
                locations = self._supplement_structural(
                    request, self._normalize(raw, request, document_uri)
                )
                lifecycle.close(deadline=min(deadline, time.monotonic() + 0.5))
            consumed = self.snapshotter.capture()
            if consumed.digest != request.snapshot_digest:
                return self._receipt(
                    request, observed.digest, started, status="rejected",
                    message="workspace changed before semantic result consumption", stale=True,
                    consumed=consumed.digest,
                )
            projected = self.projector.project(request, locations)
            # Context rendering reads source bytes, so check once more afterwards.
            final = self.snapshotter.capture()
            if final.digest != request.snapshot_digest:
                return self._receipt(
                    request, observed.digest, started, status="rejected",
                    message="workspace changed while projecting semantic context", stale=True,
                    consumed=final.digest,
                )
            return SemanticQueryReceipt(
                request_id=request.request_id,
                operation=request.operation,
                adapter_id=self.adapter_id,
                status="completed",
                requested_snapshot_digest=request.snapshot_digest,
                observed_snapshot_digest=observed.digest,
                consumed_snapshot_digest=final.digest,
                results=projected.results,
                context=projected.text,
                token_measurement=projected.measurement,
                context_budget_satisfied=projected.budget_satisfied,
                latency_ms=(time.perf_counter() - started) * 1_000,
                message="fresh isolated LSP result",
            )
        except SemanticAdapterTimeout as exc:
            if lifecycle is not None:
                lifecycle.close()
            return self._receipt(request, observed.digest, started, status="timeout", message=str(exc))
        except (SemanticAdapterUnavailable, SemanticCodeIntelligenceError, OSError, ValueError) as exc:
            if lifecycle is not None:
                lifecycle.close()
            detail = f"{type(exc).__name__}: {exc}"
            if lifecycle is not None and lifecycle.stderr_tail:
                detail += "; stderr=" + lifecycle.stderr_tail[-1_000:]
            return self._receipt(request, observed.digest, started, status="error", message=detail)

    def _query(
        self,
        rpc: _FramedJSONRPC,
        request: SemanticQueryRequest,
        document_uri: str | None,
        deadline: float,
    ) -> Any:
        position = request.position.model_dump(mode="json") if request.position else None
        text_document = {"uri": document_uri} if document_uri else None
        if request.operation == "definition":
            first = rpc.request("textDocument/definition", {"textDocument": text_document, "position": position}, deadline=deadline)
            rows = first if isinstance(first, list) else ([first] if isinstance(first, dict) else [])
            expanded = list(rows)
            # TypeScript often resolves a use to its local import alias first.
            # Follow that alias once while retaining the original location.
            for item in rows[:5]:
                if not isinstance(item, dict):
                    continue
                uri = item.get("uri") or item.get("targetUri")
                target_range = item.get("range") or item.get("targetSelectionRange") or item.get("targetRange")
                start = target_range.get("start") if isinstance(target_range, dict) else None
                if uri == document_uri and isinstance(start, dict) and start != position:
                    follow_position = dict(start)
                    end = target_range.get("end") if isinstance(target_range, dict) else None
                    if isinstance(end, dict) and end.get("line") == start.get("line") and int(end.get("character", 0)) > int(start.get("character", 0)):
                        follow_position["character"] = int(start["character"]) + 1
                    second = rpc.request("textDocument/definition", {
                        "textDocument": {"uri": uri}, "position": follow_position,
                    }, deadline=deadline)
                    if isinstance(second, list): expanded.extend(second)
                    elif isinstance(second, dict): expanded.append(second)
            return expanded
        if request.operation == "references":
            return rpc.request("textDocument/references", {
                "textDocument": text_document,
                "position": position,
                "context": {"includeDeclaration": True},
            }, deadline=deadline)
        if request.operation == "document_symbols":
            result = rpc.request("textDocument/documentSymbol", {"textDocument": text_document}, deadline=deadline)
            rows = result if isinstance(result, list) else []
            # A natural-language document intent can name late symbols that are
            # omitted by a server's document-symbol cap. Add exact workspace
            # symbol probes, then normalization/path filtering remains local.
            for token in dict.fromkeys(re.findall(r"[A-Za-z_][A-Za-z0-9_]*", request.query or "")):
                extra = rpc.request("workspace/symbol", {"query": token}, deadline=deadline)
                if isinstance(extra, list):
                    rows.extend(extra)
            return rows
        if request.operation == "workspace_symbols":
            result: Any = []
            for _ in range(3):
                result = rpc.request("workspace/symbol", {"query": request.query or ""}, deadline=deadline)
                if result or time.monotonic() + 0.2 >= deadline:
                    break
                time.sleep(0.2)
            return result
        if request.operation == "outgoing_calls":
            prepared = rpc.request("textDocument/prepareCallHierarchy", {
                "textDocument": text_document,
                "position": position,
            }, deadline=deadline)
            items = prepared if isinstance(prepared, list) else ([prepared] if isinstance(prepared, dict) else [])
            if not items:
                return []
            return rpc.request("callHierarchy/outgoingCalls", {"item": items[0]}, deadline=deadline)
        raise SemanticCodeIntelligenceError(f"unsupported semantic operation: {request.operation}")

    def _normalize(self, raw: Any, request: SemanticQueryRequest, document_uri: str | None) -> tuple[SemanticLocation, ...]:
        rows = raw if isinstance(raw, list) else ([raw] if isinstance(raw, dict) else [])
        locations: list[SemanticLocation] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            value = row.get("to") if request.operation == "outgoing_calls" else row
            if not isinstance(value, dict):
                continue
            location = value.get("location") if isinstance(value.get("location"), dict) else value
            uri = str(location.get("uri") or location.get("targetUri") or value.get("uri") or document_uri or "")
            range_value = (
                location.get("range")
                or location.get("targetSelectionRange")
                or location.get("targetRange")
                or value.get("selectionRange")
                or value.get("range")
            )
            relative = self._relative_uri(uri)
            if relative is None or not isinstance(range_value, dict):
                continue
            start = range_value.get("start") or {}
            end = range_value.get("end") or start
            try:
                locations.append(SemanticLocation(
                    path=relative,
                    range=SemanticRange(
                        start=SemanticPosition(line=int(start["line"]), character=int(start["character"])),
                        end=SemanticPosition(line=int(end["line"]), character=int(end["character"])),
                    ),
                    symbol=(
                        str(value.get("name")) if value.get("name")
                        else self._symbol_at_range(relative, int(start["line"]), int(start["character"]), int(end["line"]), int(end["character"]))
                    ),
                    kind=str(value.get("kind")) if value.get("kind") is not None else "Symbol",
                    precision="semantic",
                    detail=f"{self.adapter_id} {request.operation}",
                ))
            except (KeyError, TypeError, ValueError):
                continue
        unique: list[SemanticLocation] = []
        seen_locations = set()
        for item in locations:
            key = (item.path, item.range.start.line, item.range.start.character, item.range.end.line, item.range.end.character, item.symbol)
            if key not in seen_locations:
                unique.append(item); seen_locations.add(key)
        locations = unique
        query_tokens = {
            token.lower() for token in re.findall(r"[A-Za-z_][A-Za-z0-9_]*", request.query or "")
        }
        locations.sort(key=lambda item: (
            0 if request.operation == "references" and request.path and item.path == request.path else 1,
            0 if item.symbol and item.symbol.lower() in query_tokens else 1,
            item.path, item.range.start.line, item.range.start.character, item.symbol or "",
        ))
        return tuple(locations[: request.max_results])

    def _supplement_structural(
        self,
        request: SemanticQueryRequest,
        locations: tuple[SemanticLocation, ...],
    ) -> tuple[SemanticLocation, ...]:
        """Fill explicitly named LSP omissions with exact CodeGraph symbols.

        Results remain individually labelled ``precision=structural`` and use
        the same source snapshot. This is a bounded partial fallback, not a
        semantic claim about unsupported server output.
        """
        if request.operation not in {"document_symbols", "workspace_symbols"} or not request.query:
            return locations
        query_tokens = tuple(dict.fromkeys(
            token for token in re.findall(r"[A-Za-z_][A-Za-z0-9_]*", request.query)
        ))
        existing = {item.symbol.lower() for item in locations if item.symbol}
        missing = [token for token in query_tokens if token.lower() not in existing]
        if not missing:
            return locations
        graph = CodeGraph(self.root)
        graph.build(persist=False)
        fallback = CodeGraphSemanticAdapter(self.root, snapshotter=self.snapshotter)
        additions: list[SemanticLocation] = []
        if request.operation == "document_symbols":
            candidates = fallback._select(graph, request)
            additions.extend(item for item in candidates if item.symbol and item.symbol.lower() in {token.lower() for token in missing})
        else:
            for token in missing:
                token_request = request.model_copy(update={"query": token})
                additions.extend(
                    item for item in fallback._select(graph, token_request)
                    if item.symbol and item.symbol.lower() == token.lower()
                )
        merged: list[SemanticLocation] = []
        seen = set()
        for item in (*locations, *additions):
            key = (item.path, item.range.start.line, item.range.start.character, item.symbol, item.precision)
            if key not in seen:
                merged.append(item); seen.add(key)
        wanted = {token.lower() for token in query_tokens}
        merged.sort(key=lambda item: (
            0 if item.symbol and item.symbol.lower() in wanted else 1,
            item.path, item.range.start.line, item.range.start.character,
            item.symbol or "", item.precision,
        ))
        return tuple(merged[: request.max_results])

    def _symbol_at_range(self, relative: str, start_line: int, start_character: int, end_line: int, end_character: int) -> str | None:
        try:
            lines = (self.root / relative).read_text(encoding="utf-8", errors="replace").splitlines()
            if start_line == end_line and start_line < len(lines):
                value = lines[start_line][start_character:end_character].strip()
                return value if value and len(value) <= 300 else None
        except OSError:
            pass
        return None

    def _relative_uri(self, uri: str) -> str | None:
        parsed = urlparse(uri)
        if parsed.scheme != "file":
            return None
        path = pathlib.Path(unquote(parsed.path)).resolve()
        if not path.is_relative_to(self.root):
            return None
        return path.relative_to(self.root).as_posix()

    @staticmethod
    def _language_id(path: pathlib.Path) -> str:
        return {
            ".py": "python", ".pyi": "python", ".ts": "typescript", ".tsx": "typescriptreact",
            ".js": "javascript", ".jsx": "javascriptreact", ".go": "go", ".rs": "rust",
        }.get(path.suffix.lower(), "plaintext")

    def _receipt(
        self,
        request: SemanticQueryRequest,
        observed: str,
        started: float,
        *,
        status: Literal["rejected", "timeout", "unsupported", "error"],
        message: str,
        stale: bool = False,
        consumed: str | None = None,
    ) -> SemanticQueryReceipt:
        return SemanticQueryReceipt(
            request_id=request.request_id,
            operation=request.operation,
            adapter_id=self.adapter_id,
            status=status,
            requested_snapshot_digest=request.snapshot_digest,
            observed_snapshot_digest=observed,
            consumed_snapshot_digest=consumed or observed,
            stale_state_rejected=stale,
            latency_ms=(time.perf_counter() - started) * 1_000,
            message=message,
        )
