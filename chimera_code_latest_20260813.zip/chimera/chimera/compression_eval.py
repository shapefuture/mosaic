"""Replay-fixture acceptance gate for context compression policies."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable
@dataclass(frozen=True)
class CompressionEvaluation:
 full_ok:bool;compressed_ok:bool;full_chars:int;compressed_chars:int;accepted:bool
class CompressionAcceptance:
 def evaluate(self,full:str,compressed:str,oracle:Callable[[str],bool])->CompressionEvaluation:
  full_ok=bool(oracle(full));compressed_ok=bool(oracle(compressed));return CompressionEvaluation(full_ok,compressed_ok,len(full),len(compressed),full_ok and compressed_ok and len(compressed)<=len(full))
