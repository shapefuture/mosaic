"""Map Chimera telemetry/WAL rows to OpenTelemetry GenAI-compatible spans."""
from __future__ import annotations

import json
import pathlib
import time
from typing import Any

from .telemetry_snapshot import TelemetrySnapshotBuilder
from .wal import WAL


def _openinference_kind(kind: str, data: dict[str, Any]) -> str:
    lowered = kind.lower()
    if data.get("model") or data.get("request_model") or data.get("provider") or "llm" in lowered or "model" in lowered:
        return "LLM"
    if data.get("tool") or "tool" in lowered or "mcp" in lowered:
        return "TOOL"
    if "retriev" in lowered or "search" in lowered or "research" in lowered:
        return "RETRIEVER"
    if "embed" in lowered:
        return "EMBEDDING"
    if "eval" in lowered or "judge" in lowered or "gauntlet" in lowered:
        return "EVALUATOR"
    if "guard" in lowered or "policy" in lowered or "approval" in lowered:
        return "GUARDRAIL"
    if "agent" in lowered or "run" in lowered or "goal" in lowered:
        return "AGENT"
    if "prompt" in lowered:
        return "PROMPT"
    return "CHAIN"


def _safe_json(value: Any, *, limit: int = 4000) -> str:
    text = json.dumps(value, sort_keys=True, default=str)
    return text if len(text) <= limit else text[:limit] + "…"


def wal_to_otel_spans(root: pathlib.Path, *, service_name: str = "chimera") -> list[dict[str, Any]]:
    spans: list[dict[str, Any]] = []
    for row in WAL(pathlib.Path(root)).replay():
        data = row.get("data", {}) if isinstance(row.get("data"), dict) else {}
        kind = str(row.get("kind", "unknown"))
        usage = data.get("usage") if isinstance(data.get("usage"), dict) else data
        oi_kind = _openinference_kind(kind, data)
        attrs: dict[str, Any] = {
            "service.name": service_name,
            "chimera.wal.kind": kind,
            "chimera.wal.seq": row.get("seq"),
            "openinference.span.kind": oi_kind,
        }
        if data.get("session_id") or data.get("run_id"):
            attrs["session.id"] = str(data.get("session_id") or data.get("run_id"))
        if "input" in data or "prompt" in data or "query" in data:
            attrs["input.value"] = _safe_json(data.get("input", data.get("prompt", data.get("query"))))
            attrs["input.mime_type"] = "application/json"
        if "output" in data or "result" in data or "response" in data:
            attrs["output.value"] = _safe_json(data.get("output", data.get("result", data.get("response"))))
            attrs["output.mime_type"] = "application/json"
        model = data.get("model") or data.get("request_model")
        provider = data.get("provider")
        if model:
            attrs["gen_ai.request.model"] = str(model)
        if provider:
            attrs["gen_ai.provider.name"] = str(provider)
        for source, target in (
            ("input_tokens", "gen_ai.usage.input_tokens"),
            ("prompt_tokens", "gen_ai.usage.input_tokens"),
            ("output_tokens", "gen_ai.usage.output_tokens"),
            ("completion_tokens", "gen_ai.usage.output_tokens"),
            ("total_tokens", "gen_ai.usage.total_tokens"),
            ("tokens", "gen_ai.usage.total_tokens"),
        ):
            value = usage.get(source) if isinstance(usage, dict) else None
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                attrs[target] = int(value)
        duration = data.get("duration_ms") or data.get("latency_ms") or data.get("model_ms")
        if isinstance(duration, (int, float)) and not isinstance(duration, bool):
            attrs["gen_ai.client.operation.duration"] = float(duration) / 1000.0
        if "tool" in data:
            attrs["gen_ai.tool.name"] = str(data.get("tool"))
            attrs["tool.name"] = str(data.get("tool"))
        if model:
            attrs["llm.model_name"] = str(model)
        if "gen_ai.usage.input_tokens" in attrs:
            attrs["llm.token_count.prompt"] = attrs["gen_ai.usage.input_tokens"]
        if "gen_ai.usage.output_tokens" in attrs:
            attrs["llm.token_count.completion"] = attrs["gen_ai.usage.output_tokens"]
        spans.append({
            "name": ("llm" if oi_kind == "LLM" else oi_kind.lower()) + f".{kind}",
            "kind": "CLIENT" if model or provider else "INTERNAL",
            "start_time_unix_nano": int(time.time() * 1_000_000_000),
            "attributes": attrs,
            "status": {"code": "OK"},
        })
    return spans


def telemetry_snapshot_to_otel_resource(root: pathlib.Path) -> dict[str, Any]:
    snapshot = TelemetrySnapshotBuilder(root).build().model_dump(mode="json")
    return {
        "resource": {"attributes": {"service.name": "chimera", "chimera.root": str(pathlib.Path(root).resolve())}},
        "scopeSpans": [{"scope": {"name": "chimera.telemetry"}, "spans": wal_to_otel_spans(root)}],
        "summary": {
            "schema_version": snapshot["schema_version"],
            "wal_entries": snapshot["wal"]["entries"],
            "provider_summary": snapshot["providers"],
            "token_usage": snapshot["token_usage"],
        },
    }
