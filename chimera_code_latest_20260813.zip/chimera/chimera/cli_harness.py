"""Continual harness CLI commands."""
from __future__ import annotations

import json

import click
from rich.json import JSON


def register(main: click.Group, *, console, cli_root) -> None:
    _cli_root = cli_root

    @main.group("harness")
    def harness_group():
        """Continual harness refinements and rollback."""
        pass

    @harness_group.command("status")
    @click.option("--namespace", default="default")
    def harness_status(namespace):
        from .continual import ContinualHarness
        state = ContinualHarness(_cli_root(), namespace=namespace).get()
        console.print(JSON(state.model_dump_json(indent=2)))

    @harness_group.command("refine")
    @click.argument("surface", type=click.Choice(["prompt", "memory", "skill", "subagent"]))
    @click.argument("key")
    @click.argument("content")
    @click.option("--reason", required=True)
    @click.option("--evidence", "evidence_refs", multiple=True, required=True)
    @click.option("--namespace", default="default")
    def harness_refine(surface, key, content, reason, evidence_refs, namespace):
        from .continual import ContinualHarness, Refinement
        try:
            parsed = json.loads(content)
        except json.JSONDecodeError:
            parsed = content
        harness = ContinualHarness(_cli_root(), namespace=namespace)
        result = harness.refine(
            [Refinement(surface=surface, key=key, content=parsed, reason=reason,
                        evidence_refs=list(evidence_refs), confidence=0.8)],
            evidence={"refs": list(evidence_refs), "source": "cli"},
        )
        console.print(JSON(json.dumps(result, indent=2)))

    @harness_group.command("rollback")
    @click.option("--revision", default=None)
    @click.option("--steps", default=1, type=int)
    @click.option("--namespace", default="default")
    def harness_rollback(revision, steps, namespace):
        from .continual import ContinualHarness
        state = ContinualHarness(_cli_root(), namespace=namespace).rollback(revision, steps)
        console.print(JSON(state.model_dump_json(indent=2)))

    @harness_group.command("diff")
    @click.option("--left", default=None)
    @click.option("--right", default=None)
    @click.option("--namespace", default="default")
    def harness_diff(left, right, namespace):
        from .continual import ContinualHarness
        result = ContinualHarness(_cli_root(), namespace=namespace).diff(left, right)
        console.print(JSON(json.dumps(result, indent=2)))

