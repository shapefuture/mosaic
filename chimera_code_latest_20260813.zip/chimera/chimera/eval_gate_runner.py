"""CLI/helper for strict stress eval gate decisions."""
from __future__ import annotations
import argparse, json, pathlib, sys
from .eval_gates import StrictStressGate

def load_rows(path: pathlib.Path):
    data=json.loads(path.read_text())
    if isinstance(data, dict) and 'rows' in data: return data['rows']
    if isinstance(data, dict) and 'summary' in data: return data['summary']
    if isinstance(data, dict): return [data]
    if isinstance(data, list): return data
    return []

def main(argv=None):
    ap=argparse.ArgumentParser()
    ap.add_argument('result_json')
    ap.add_argument('--min-pass-rate',type=float,default=1.0)
    ap.add_argument('--max-median-wall',type=float,default=10.0)
    ap.add_argument('--max-median-tokens',type=int,default=2500)
    ap.add_argument('--mode',choices=['warn','fail'],default='fail')
    ns=ap.parse_args(argv)
    result=StrictStressGate(min_pass_rate=ns.min_pass_rate,max_median_wall=ns.max_median_wall,max_median_tokens=ns.max_median_tokens).evaluate(load_rows(pathlib.Path(ns.result_json)))
    print(json.dumps(result.as_dict(),indent=2,default=str))
    return 1 if ns.mode=='fail' and not result.passed else 0
if __name__=='__main__': raise SystemExit(main())
