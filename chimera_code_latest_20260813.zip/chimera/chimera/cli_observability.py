"""Projection, browser, and provider-status CLI commands."""
from __future__ import annotations

import json

import click
from rich.json import JSON


def register(main: click.Group, *, console, cli_root) -> None:
    _cli_root = cli_root

    @main.command("project-wal")
    @click.option("--kind", default=None)
    @click.option("--limit", default=20, type=int)
    def project_wal(kind, limit):
        """Refresh and query the optional SQLite WAL read projection."""
        from .projection import WALProjection
        projection = WALProjection(_cli_root())
        try:
            refreshed = projection.refresh()
            rows = projection.query(kind=kind, limit=limit)
            console.print(JSON(json.dumps({"refresh": refreshed, "rows": rows}, indent=2)))
        finally:
            projection.close()

    @main.command("browser-status")
    def browser_status():
        """Report real WebContainer adapter availability without simulation."""
        from .browser_runtime import BrowserRuntime
        console.print(JSON(BrowserRuntime(_cli_root()).preflight().model_dump_json(indent=2)))

    @main.command("gui-serve")
    @click.option("--host", default="0.0.0.0", show_default=True)
    @click.option("--port", type=click.IntRange(1, 65535), default=8766, show_default=True)
    @click.option("--server", type=click.Choice(["uvicorn", "granian", "auto"]), default="uvicorn", show_default=True, help="ASGI server; granian is optional Rust-backed profile")
    def gui_serve(host, port, server):
        """Serve the hosted Chimera GUI ASGI API/SSE/WebSocket adapter."""
        from .gui_asgi import create_app
        if server in {"granian", "auto"}:
            try:
                from granian import Granian
                from granian.constants import Interfaces
                app = create_app(_cli_root())
                Granian(app, address=host, port=port, interface=Interfaces.ASGI).serve()
                return
            except ImportError:
                if server == "granian":
                    raise click.UsageError("install optional dependency granian for --server granian")
            except Exception as exc:
                if server == "granian":
                    raise click.ClickException(f"granian failed: {exc}") from exc
        try:
            import uvicorn
        except ImportError as exc:
            raise click.UsageError("install the mcp-http or restate-adapter extra for uvicorn") from exc
        uvicorn.run(create_app(_cli_root()), host=host, port=port, log_level="info")


    @main.command("telemetry-cost-report")
    @click.option("--record-history", is_flag=True)
    def telemetry_cost_report_cmd(record_history):
        """Report token/cost/error-tax from local WAL telemetry."""
        from .token_error_tax import TokenErrorTaxAnalyzer
        result = TokenErrorTaxAnalyzer(_cli_root()).analyze()
        if record_history:
            from .gate_history import GateHistoryLedger
            GateHistoryLedger(_cli_root()).append(result)
        click.echo(json.dumps(result, indent=2, sort_keys=True, default=str))

    @main.command("telemetry-duckdb")
    @click.option("--dry-run", is_flag=True, help="report rows and dependency availability without writing DuckDB")
    @click.option("--limit", default=None, type=int, help="project only the newest N WAL rows")
    def telemetry_duckdb_cmd(dry_run, limit):
        """Project local WAL telemetry into optional DuckDB analytics mirror."""
        from .telemetry_duckdb import DuckDBTelemetryProjection
        click.echo(json.dumps(DuckDBTelemetryProjection(_cli_root()).project(dry_run=dry_run, limit=limit), indent=2, sort_keys=True, default=str))

    @main.command("telemetry")
    @click.option("--model", default="*", show_default=True)
    @click.option("--recent", default=200, type=click.IntRange(1, 5000), show_default=True)
    @click.option("--otel", is_flag=True, help="emit OpenTelemetry/GenAI span mapping instead of snapshot")
    def telemetry_cmd(model, recent, otel):
        """Emit a redacted local observability snapshot for users/agents."""
        if otel:
            from .otel_mapping import telemetry_snapshot_to_otel_resource
            click.echo(json.dumps(telemetry_snapshot_to_otel_resource(_cli_root()), indent=2, sort_keys=True, default=str))
            return
        from .telemetry_snapshot import TelemetrySnapshotBuilder
        click.echo(TelemetrySnapshotBuilder(_cli_root()).build(model=model, recent=recent).model_dump_json(indent=2))

    @main.command("telemetry-otlp")
    @click.option("--endpoint", required=True, help="OTLP/HTTP endpoint to queue or drain to")
    @click.option("--drain", is_flag=True, help="deliver queued OTLP rows through egress policy")
    @click.option("--limit", default=100, type=int, show_default=True)
    def telemetry_otlp_cmd(endpoint, drain, limit):
        """Queue or drain OTLP telemetry using the telemetry outbox."""
        from .otlp_exporter import OTLPTelemetryExporter
        exporter = OTLPTelemetryExporter(_cli_root(), endpoint)
        result = exporter.drain(limit=limit) if drain else exporter.queue()
        click.echo(json.dumps(result, indent=2, sort_keys=True, default=str))

    @main.command("telemetry-retention")
    @click.option("--tenant-key", default=None)
    @click.option("--max-age-seconds", type=float, default=None)
    @click.option("--max-rows", type=int, default=10000, show_default=True)
    @click.option("--dry-run", is_flag=True)
    def telemetry_retention_cmd(tenant_key, max_age_seconds, max_rows, dry_run):
        """Prune local telemetry files by tenant/age/row count."""
        from .telemetry_retention import TelemetryRetentionPolicy
        receipts = TelemetryRetentionPolicy(_cli_root()).prune_default(
            tenant_key=tenant_key,
            max_age_seconds=max_age_seconds,
            max_rows=max_rows,
            dry_run=dry_run,
        )
        click.echo(json.dumps([receipt.as_dict() for receipt in receipts], indent=2, sort_keys=True, default=str))

    @main.command("providers")
    @click.option("--report", "full_report", is_flag=True, help="include QoS, canary, cancellation, and billing state")
    @click.option("--model", default="*", show_default=True, help="model key for provider state lookups")
    def providers_cmd(full_report, model):
        """Show unified provider configuration without revealing credentials."""
        if full_report:
            from .provider_report import ProviderSystemReporter
            click.echo(ProviderSystemReporter(_cli_root()).build(model=model).model_dump_json(indent=2))
            return
        from .providers import ProviderCatalog
        console.print(JSON(json.dumps(ProviderCatalog().report(), indent=2)))

