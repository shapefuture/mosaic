"""Deterministic task-shape routing for the coding harness.

The purpose is not to predict model quality. It avoids paying a multi-agent DAG
control-plane cost for a small, independently judged, one-target code change,
while refusing that fast path for high-risk, multi-target, unobservable, or
irreversible work.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import StrEnum
from typing import Any

from .intent_policy import IntentGate
from .path_policy import PathPolicyResolver


class ExecutionMode(StrEnum):
    ASSESSMENT = "assessment"
    MICRO_TRANSACTION = "micro_transaction"
    COHESIVE_TRANSACTION = "cohesive_transaction"
    DAG = "dag"


@dataclass(frozen=True)
class TaskExecutionProfile:
    mode: ExecutionMode
    reasons: tuple[str, ...]
    target_count: int
    # ``test_count`` is the narrowly selected independent acceptance set, not
    # the number of repository tests that remain protected/finally executed.
    test_count: int
    available_test_count: int
    acceptance_tests: tuple[str, ...]
    high_risk_paths: tuple[str, ...]

    def evidence(self) -> dict[str, Any]:
        value = asdict(self)
        value["mode"] = self.mode.value
        return value


class TaskExecutionProfiler:
    """Small fixed classifier; model text can neither edit nor bypass it."""

    _COMPLEX_TERMS = (
        "migration", "deploy", "infrastructure", "permission", "credential",
        "authentication", "authorization", "payment", "billing", "refactor",
        "architecture", "parallel", "multi-step", "multiple steps", "workflow",
    )

    def __init__(self, path_policy: PathPolicyResolver | None = None) -> None:
        self.path_policy = path_policy or PathPolicyResolver()

    @staticmethod
    def _acceptance_tests(contract: Any, targets: tuple[Any, ...]) -> tuple[str, ...]:
        """Select tests deterministically tied to a one-target contract.

        Repository-wide test count is not a proxy for micro-task uncertainty:
        a repository may have thousands of unrelated tests. This selector is
        intentionally lexical/structural, never model-ranked. If it cannot
        identify a direct target/test relation, the fast path is refused.
        """
        tests = getattr(contract, "tests", {}) or {}
        if not 1 <= len(targets) <= 2 or not isinstance(tests, dict):
            return ()
        target_info = []
        symbols_by_path = getattr(contract, "required_symbols", {}) or {}
        for target in targets:
            path = str(getattr(target, "path", "")).replace("\\", "/").removeprefix("./")
            target_info.append((
                path, path[:-3].replace("/", ".") if path.endswith(".py") else "",
                path.rsplit("/", 1)[-1].rsplit(".", 1)[0].lower(),
                set(symbols_by_path.get(path, ()) or ()),
            ))
        ranked: list[tuple[int, str]] = []
        for test_path, text in tests.items():
            source = str(text)
            score = 0
            for _path, module, stem, symbols in target_info:
                if module and (f"from {module} import" in source or f"import {module}" in source):
                    score += 10
                if stem and stem in str(test_path).lower():
                    score += 4
                score += sum(2 for symbol in symbols if symbol and symbol in source)
            if score:
                ranked.append((-score, str(test_path)))
        return tuple(path for _score, path in sorted(ranked)[:2])

    def classify(self, task: str, contract: Any, readiness: Any) -> TaskExecutionProfile:
        intent = IntentGate().decide(task)
        targets = tuple(getattr(contract, "targets", ()) or ())
        tests = getattr(contract, "tests", {}) or {}
        acceptance_tests = self._acceptance_tests(contract, targets)
        high_risk = tuple(sorted(
            str(target.path) for target in targets
            if self.path_policy.resolve(str(target.path)).risk == "high"
        ))
        common = (len(targets), len(acceptance_tests), len(tests), acceptance_tests, high_risk)
        reasons: list[str] = []
        if not intent.allow_write:
            reasons.append("intent gate did not authorize mutation")
            return TaskExecutionProfile(ExecutionMode.ASSESSMENT, tuple(reasons), *common)
        if getattr(readiness, "irreversible", False):
            reasons.append("task mentions an irreversible external commitment")
        if not (getattr(readiness, "observable", False) and getattr(readiness, "scoped", False) and getattr(readiness, "judge_independent", False)):
            reasons.append("task lacks bounded independently executable acceptance")
        if len(targets) not in {1, 2}:
            reasons.append(f"target count is {len(targets)}; direct transactions permit one or two")
        if not acceptance_tests or len(acceptance_tests) > 2:
            reasons.append(f"direct acceptance-test count is {len(acceptance_tests)}; direct transactions permit one or two")
        if high_risk:
            reasons.append("high-risk path policy: " + ", ".join(high_risk))
        lower = task.lower()
        if any(term in lower for term in self._COMPLEX_TERMS):
            reasons.append("task language requests a complex/high-risk work shape")
        if not reasons and len(targets) == 1:
            return TaskExecutionProfile(
                ExecutionMode.MICRO_TRANSACTION,
                ("one bounded standard-risk target with directly linked independently executable acceptance",),
                *common,
            )
        if not reasons and len(targets) == 2:
            selected_text = "\n".join(str(tests.get(path, "")) for path in acceptance_tests)
            linked = []
            for target in targets:
                path = str(target.path).replace("\\", "/").removeprefix("./")
                module = path[:-3].replace("/", ".") if path.endswith(".py") else ""
                linked.append(bool(module and (f"from {module} import" in selected_text or f"import {module}" in selected_text)))
            if all(linked):
                return TaskExecutionProfile(
                    ExecutionMode.COHESIVE_TRANSACTION,
                    ("two standard-risk targets share direct executable acceptance; one patch transaction avoids an artificial handoff",),
                    *common,
                )
            reasons.append("two targets lack one shared direct acceptance relation")
        return TaskExecutionProfile(ExecutionMode.DAG, tuple(reasons), *common)
