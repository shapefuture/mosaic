"""Typed hypergraph orchestration with bounded recursive next-layer planning.

This extends DAG execution only where AND dependencies are insufficient. It does
not permit arbitrary executable predicates: activation is closed and typed.
"""
from __future__ import annotations
import concurrent.futures
import hashlib
import json
import math
import time
from enum import StrEnum
from typing import Any, Callable, Iterable, Literal, Mapping, Optional
from pydantic import BaseModel, ConfigDict, Field, model_validator

class FrozenModel(BaseModel):
    model_config=ConfigDict(extra="forbid",frozen=True)

class ActivationKind(StrEnum):
    AND="and";OR="or";K_OF_N="k_of_n";WEIGHTED="weighted";CONDITION="condition"

class AtomSpec(FrozenModel):
    id:str
    atom_type:str="general"
    payload:dict[str,Any]=Field(default_factory=dict)
    priority:int=0
    token_budget:int=Field(default=1000,ge=0)
    cost_budget:float=Field(default=0.0,ge=0.0)

class OutputCondition(FrozenModel):
    source_id:str
    field:str
    op:Literal["eq","ne","gt","ge","lt","le","exists"]="exists"
    value:Any=None

    def evaluate(self,outputs:Mapping[str,Any])->bool:
        source=outputs.get(self.source_id)
        current=source
        for part in self.field.split(".") if self.field else ():
            if not isinstance(current,Mapping) or part not in current:return False
            current=current[part]
        if self.op=="exists":return current is not None
        if self.op=="eq":return current==self.value
        if self.op=="ne":return current!=self.value
        try:
            return {"gt":current>self.value,"ge":current>=self.value,"lt":current<self.value,"le":current<=self.value}[self.op]
        except (TypeError,KeyError):return False

class Hyperedge(FrozenModel):
    id:str
    sources:tuple[str,...]
    targets:tuple[str,...]
    activation:ActivationKind=ActivationKind.AND
    k:Optional[int]=Field(default=None,ge=1)
    weights:dict[str,float]=Field(default_factory=dict)
    threshold:Optional[float]=None
    conditions:tuple[OutputCondition,...]=()

    @model_validator(mode="after")
    def validate_shape(self):
        if not self.sources or not self.targets:raise ValueError("hyperedge requires sources and targets")
        if self.activation is ActivationKind.K_OF_N and (self.k is None or self.k>len(self.sources)):
            raise ValueError("k_of_n requires 1 <= k <= number of sources")
        if self.activation is ActivationKind.WEIGHTED:
            if self.threshold is None:raise ValueError("weighted activation requires threshold")
            if set(self.weights)-set(self.sources):raise ValueError("weights name unknown sources")
        if self.activation is ActivationKind.CONDITION:
            if not self.conditions:raise ValueError("condition activation requires typed conditions")
            if any(item.source_id not in self.sources for item in self.conditions):raise ValueError("condition source outside edge")
        return self

class HypergraphPlan(FrozenModel):
    id:str
    task:str
    atoms:tuple[AtomSpec,...]
    edges:tuple[Hyperedge,...]=()

    @model_validator(mode="after")
    def validate_graph(self):
        ids=[item.id for item in self.atoms]
        if not ids or len(ids)!=len(set(ids)):raise ValueError("atoms must be non-empty with unique ids")
        known=set(ids);edge_ids=[item.id for item in self.edges]
        if len(edge_ids)!=len(set(edge_ids)):raise ValueError("hyperedge ids must be unique")
        for edge in self.edges:
            if not set((*edge.sources,*edge.targets))<=known:raise ValueError("hyperedge references unknown atom")
            if set(edge.sources)&set(edge.targets):raise ValueError("hyperedge cannot target one of its own sources")
        targeted={target for edge in self.edges for target in edge.targets}
        if not (known-targeted):raise ValueError("hypergraph requires at least one root atom")
        return self

class AtomOutcome(FrozenModel):
    status:Literal["succeeded","failed"]
    output:Any=None
    tokens:int=Field(default=0,ge=0)
    cost:float=Field(default=0.0,ge=0.0)
    evidence_refs:tuple[str,...]=()
    error:Optional[str]=None

class HypergraphRun(FrozenModel):
    status:Literal["complete","partial","budget_exhausted"]
    outcomes:dict[str,AtomOutcome]
    skipped:tuple[str,...]
    activated_edges:tuple[str,...]
    tokens:int
    cost:float
    elapsed_seconds:float
    plan_hash:str

class HypergraphExecutor:
    def __init__(self,max_parallel:int=4,max_atoms:int=100,max_tokens:int=100000,max_cost:float=100.0,max_seconds:float=3600):
        self.max_parallel=max(1,int(max_parallel));self.max_atoms=max(1,int(max_atoms));self.max_tokens=max(0,int(max_tokens));self.max_cost=max(0.0,float(max_cost));self.max_seconds=max(0.01,float(max_seconds))

    @staticmethod
    def _hash(plan:HypergraphPlan)->str:
        return "sha256:"+hashlib.sha256(json.dumps(plan.model_dump(mode="json"),sort_keys=True,separators=(",",":"),default=str).encode()).hexdigest()

    @staticmethod
    def _edge_state(edge:Hyperedge,outcomes:Mapping[str,AtomOutcome])->tuple[bool,bool]:
        terminal=[source in outcomes for source in edge.sources]
        successes=[source in outcomes and outcomes[source].status=="succeeded" for source in edge.sources]
        outputs={source:(outcomes[source].output if source in outcomes else None) for source in edge.sources}
        if edge.activation is ActivationKind.AND:
            return all(successes),all(terminal) and not all(successes)
        if edge.activation is ActivationKind.OR:
            return any(successes),all(terminal) and not any(successes)
        if edge.activation is ActivationKind.K_OF_N:
            wins=sum(successes);possible=wins+sum(not item for item in terminal)
            return wins>=int(edge.k or 1),possible<int(edge.k or 1)
        if edge.activation is ActivationKind.WEIGHTED:
            score=sum(edge.weights.get(source,1.0) for source,ok in zip(edge.sources,successes) if ok)
            possible=score+sum(edge.weights.get(source,1.0) for source,done in zip(edge.sources,terminal) if not done)
            return score>=float(edge.threshold or 0),possible<float(edge.threshold or 0)
        if not all(terminal):return False,False
        passed=all(item.evaluate(outputs) for item in edge.conditions)
        return passed,not passed

    def execute(self,plan:HypergraphPlan,worker:Callable[[AtomSpec,dict[str,Any]],AtomOutcome|Mapping[str,Any]])->HypergraphRun:
        started=time.monotonic();atoms={item.id:item for item in plan.atoms};targeted={target for edge in plan.edges for target in edge.targets};pending=set(atoms);ready=set(atoms)-targeted;outcomes:dict[str,AtomOutcome]={};skipped:set[str]=set();activated:set[str]=set();running={};tokens=0;cost=0.0;dispatched=0
        incoming={atom_id:[] for atom_id in atoms}
        for edge in plan.edges:
            for target in edge.targets:incoming[target].append(edge)
        pool=concurrent.futures.ThreadPoolExecutor(max_workers=self.max_parallel,thread_name_prefix="chimera-hyper")
        try:
            while pending or running:
                elapsed=time.monotonic()-started
                budget_hit=(dispatched>=self.max_atoms or tokens>=self.max_tokens or cost>=self.max_cost or elapsed>=self.max_seconds)
                while ready and len(running)<self.max_parallel and not budget_hit:
                    atom_id=max(ready,key=lambda key:(atoms[key].priority,key));ready.remove(atom_id);pending.remove(atom_id);atom=atoms[atom_id]
                    context={"sources":{source:outcomes[source].output for edge in incoming[atom_id] if edge.id in activated for source in edge.sources if source in outcomes},"activated_edges":[edge.id for edge in incoming[atom_id] if edge.id in activated]}
                    running[pool.submit(worker,atom,context)]=atom_id;dispatched+=1
                if not running:
                    if budget_hit:break
                    changed=False
                    for atom_id in list(pending):
                        edges=incoming[atom_id]
                        states=[(edge,*self._edge_state(edge,outcomes)) for edge in edges]
                        winners=[edge for edge,active,_ in states if active]
                        if winners:
                            activated.update(edge.id for edge in winners);ready.add(atom_id);changed=True
                        elif states and all(impossible for _,_,impossible in states):
                            pending.remove(atom_id);skipped.add(atom_id);changed=True
                    if not changed:
                        skipped.update(pending);pending.clear()
                    continue
                done,_=concurrent.futures.wait(running,return_when=concurrent.futures.FIRST_COMPLETED)
                for future in done:
                    atom_id=running.pop(future)
                    try:
                        raw=future.result();outcome=raw if isinstance(raw,AtomOutcome) else AtomOutcome.model_validate(raw)
                    except Exception as exc:
                        outcome=AtomOutcome(status="failed",error=f"{type(exc).__name__}: {exc}")
                    outcomes[atom_id]=outcome;tokens+=outcome.tokens;cost+=outcome.cost
                    for target in set(edge_target for edge in plan.edges if atom_id in edge.sources for edge_target in edge.targets)&pending:
                        states=[(edge,*self._edge_state(edge,outcomes)) for edge in incoming[target]]
                        winners=[edge for edge,active,_ in states if active]
                        if winners:
                            activated.update(edge.id for edge in winners);ready.add(target)
                        elif states and all(impossible for _,_,impossible in states):
                            pending.remove(target);skipped.add(target)
        finally:pool.shutdown(wait=True,cancel_futures=True)
        budget_exhausted=bool(pending) and (dispatched>=self.max_atoms or tokens>=self.max_tokens or cost>=self.max_cost or time.monotonic()-started>=self.max_seconds)
        skipped.update(pending)
        source_ids={source for edge in plan.edges for source in edge.sources};sink_ids=set(atoms)-source_ids
        successful_sinks=bool(sink_ids) and all(atom_id in outcomes and outcomes[atom_id].status=="succeeded" for atom_id in sink_ids)
        status="budget_exhausted" if budget_exhausted else "complete" if successful_sinks and not (set(skipped)&sink_ids) else "partial"
        return HypergraphRun(status=status,outcomes=outcomes,skipped=tuple(sorted(skipped)),activated_edges=tuple(sorted(activated)),tokens=tokens,cost=cost,elapsed_seconds=time.monotonic()-started,plan_hash=self._hash(plan))

class RecursiveRun(FrozenModel):
    status:Literal["complete","stopped"]
    layers:tuple[HypergraphRun,...]
    state:dict[str,Any]
    depth:int
    tokens:int
    cost:float

class RecursiveHypergraphController:
    """Plan one bounded layer, execute, observe, and only then plan the next."""
    def __init__(self,executor:HypergraphExecutor,max_depth:int=8):self.executor=executor;self.max_depth=max(1,int(max_depth))
    def run(self,task:str,planner:Callable[[str,dict[str,Any],int],HypergraphPlan],worker:Callable[[AtomSpec,dict[str,Any]],AtomOutcome|Mapping[str,Any]],objective:Callable[[str,dict[str,Any]],bool],initial_state:Optional[dict[str,Any]]=None)->RecursiveRun:
        state=dict(initial_state or {});layers=[];tokens=0;cost=0.0
        for depth in range(self.max_depth):
            if objective(task,state):return RecursiveRun(status="complete",layers=tuple(layers),state=state,depth=depth,tokens=tokens,cost=cost)
            plan=planner(task,dict(state),depth);result=self.executor.execute(plan,worker);layers.append(result);tokens+=result.tokens;cost+=result.cost
            state[f"layer:{depth}"]={key:value.output for key,value in result.outcomes.items() if value.status=="succeeded"}
            state[f"layer:{depth}:evidence"]={"plan_hash":result.plan_hash,"status":result.status,"activated_edges":list(result.activated_edges),"skipped":list(result.skipped)}
            if result.status=="budget_exhausted":break
        return RecursiveRun(status="complete" if objective(task,state) else "stopped",layers=tuple(layers),state=state,depth=len(layers),tokens=tokens,cost=cost)
