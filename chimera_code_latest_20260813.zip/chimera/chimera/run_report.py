"""Compact user-facing run report assembly."""
from __future__ import annotations
from typing import Any, Mapping

def summarize_run(result: Mapping[str,Any])->str:
    diff=result.get('diff') if isinstance(result.get('diff'),Mapping) else {}
    paths=[op.get('path') for op in diff.get('ops',[]) if isinstance(op,Mapping) and op.get('path')]
    verification=result.get('verification',{}) if isinstance(result.get('verification'),Mapping) else {}
    heldout=result.get('heldout') or {}
    lines=[
        f"Task: {result.get('task','')}",
        "Changed: "+(", ".join(paths) if paths else "no user files"),
        f"Verification: {verification.get('status','unknown')} ltl={result.get('ltl_ok')}",
        f"Held-out: {heldout.get('passed','unavailable')}",
        f"Tests/usage: {result.get('usage',{})}",
        f"Limitations: {result.get('ltl_msg') or 'none recorded'}",
    ]
    if result.get('heldout',{}).get('evidence_ref'): lines.append(f"Evidence: {result['heldout']['evidence_ref']}")
    return "\n".join(lines)
