"""First-principles solver qualification before spending evolutionary budget."""
from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, ConfigDict, Field


class ProblemProfile(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    functional_seed: bool
    automated_evaluator: bool
    evaluator_is_protected: bool
    bounded_mutation_surface: bool
    semantic_code_search: bool = True
    numeric_dimensions: int = Field(default=0, ge=0)
    gradients_available: bool = False
    convex_or_exact_solver_available: bool = False
    noisy_evaluator: bool = False
    multi_objective: bool = False
    estimated_evaluation_seconds: float = Field(default=1.0, ge=0.0)


class SolverDecision(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    ready: bool
    solver: Literal[
        "coding-agent", "classical-solver", "gradient-optimizer",
        "coordinate-or-bayesian", "evolutionary-search", "not-ready"
    ]
    reasons: tuple[str, ...]
    required_safeguards: tuple[str, ...]


def qualify(profile: ProblemProfile) -> SolverDecision:
    if not profile.functional_seed:
        return SolverDecision(
            ready=False, solver="coding-agent",
            reasons=("evolution requires a functionally correct seed",),
            required_safeguards=("build and verify baseline first",),
        )
    if not profile.automated_evaluator or not profile.evaluator_is_protected:
        return SolverDecision(
            ready=False, solver="not-ready",
            reasons=("optimization requires an automated evaluator hidden from candidate authority",),
            required_safeguards=("define protected grader and holdout",),
        )
    if not profile.bounded_mutation_surface:
        return SolverDecision(
            ready=False, solver="not-ready",
            reasons=("mutation authority is not bounded",),
            required_safeguards=("define EVOLVE blocks or transactional patch contract",),
        )
    if profile.convex_or_exact_solver_available:
        return SolverDecision(
            ready=True, solver="classical-solver",
            reasons=("known exact/classical solver dominates open-ended code search",),
            required_safeguards=("cross-check solution constraints",),
        )
    if profile.gradients_available and not profile.semantic_code_search:
        return SolverDecision(
            ready=True, solver="gradient-optimizer",
            reasons=("differentiable numeric objective",),
            required_safeguards=("holdout evaluation",),
        )
    if 0 < profile.numeric_dimensions <= 20 and not profile.semantic_code_search:
        safeguards = ["bounded parameter ranges", "one-coordinate attribution"]
        if profile.noisy_evaluator: safeguards.append("paired seeds and sequential racing")
        return SolverDecision(
            ready=True, solver="coordinate-or-bayesian",
            reasons=("small numeric black-box search is more sample-efficient than LLM mutation",),
            required_safeguards=tuple(safeguards),
        )
    safeguards = ["quality-diversity archive", "novelty filter", "sealed promotion evaluation"]
    if profile.noisy_evaluator: safeguards.extend(["paired common random seeds", "repeated robust metrics"])
    if profile.multi_objective: safeguards.append("Pareto archive with hard constraints")
    if profile.estimated_evaluation_seconds > 10: safeguards.append("cascade evaluation and bounded parallel workers")
    return SolverDecision(
        ready=True, solver="evolutionary-search",
        reasons=("semantic or multimodal code search lacks a tractable numeric solver",),
        required_safeguards=tuple(safeguards),
    )
