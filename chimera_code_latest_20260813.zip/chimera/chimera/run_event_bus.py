"""Persistent, redacted run-event bus for GUI/WebSocket/API observers."""
from __future__ import annotations

import json
import os
import pathlib
import time
import uuid
from dataclasses import asdict, dataclass
from typing import Any, Iterable, Mapping


@dataclass(frozen=True)
class RunEvent:
    schema_version: str
    id: str
    ts: float
    run_id: str
    kind: str
    data: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


SENSITIVE_KEYS = {"api_key", "apikey", "authorization", "cookie", "password", "secret", "token", "endpoint", "url"}


def _redact(value: Any) -> Any:
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            skey = str(key)
            if any(part in skey.lower() for part in SENSITIVE_KEYS):
                out[skey] = "[REDACTED]"
            else:
                out[skey] = _redact(item)
        return out
    if isinstance(value, list):
        return [_redact(item) for item in value]
    if isinstance(value, str) and ("sk-" in value or "postgresql://" in value or "postgresql+" in value):
        return "[REDACTED]"
    return value


AG_UI_KIND_MAP = {
    "run.started": "RUN_STARTED",
    "run.start": "RUN_STARTED",
    "started": "RUN_STARTED",
    "gui.action.started": "RUN_STARTED",
    "text.delta": "TEXT_MESSAGE_CONTENT",
    "text.content": "TEXT_MESSAGE_CONTENT",
    "message.delta": "TEXT_MESSAGE_CONTENT",
    "llm.delta": "TEXT_MESSAGE_CONTENT",
    "tool.start": "TOOL_CALL_START",
    "tool.started": "TOOL_CALL_START",
    "tool.end": "TOOL_CALL_END",
    "tool.completed": "TOOL_CALL_END",
    "tool.result": "TOOL_CALL_END",
    "state.delta": "STATE_DELTA",
    "state.patch": "STATE_DELTA",
    "approval.required": "APPROVAL_REQUIRED",
    "human.approval.required": "APPROVAL_REQUIRED",
    "run.finished": "RUN_FINISHED",
    "run.completed": "RUN_FINISHED",
    "run.done": "RUN_FINISHED",
    "gui.action.completed": "RUN_FINISHED",
    "run.error": "RUN_ERROR",
    "run.failed": "RUN_ERROR",
    "gui.action.failed": "RUN_ERROR",
}


def _ag_ui_type(kind: str) -> str:
    lowered = str(kind).lower()
    if lowered in AG_UI_KIND_MAP:
        return AG_UI_KIND_MAP[lowered]
    if "approval" in lowered and ("required" in lowered or "request" in lowered):
        return "APPROVAL_REQUIRED"
    if "tool" in lowered and any(part in lowered for part in ("start", "begin")):
        return "TOOL_CALL_START"
    if "tool" in lowered and any(part in lowered for part in ("end", "result", "complete", "finish")):
        return "TOOL_CALL_END"
    if any(part in lowered for part in ("delta", "token", "text", "message")):
        return "TEXT_MESSAGE_CONTENT"
    if "state" in lowered or "patch" in lowered:
        return "STATE_DELTA"
    if any(part in lowered for part in ("error", "fail")):
        return "RUN_ERROR"
    if any(part in lowered for part in ("finish", "complete", "done")):
        return "RUN_FINISHED"
    if any(part in lowered for part in ("start", "begin")):
        return "RUN_STARTED"
    return "STATE_DELTA"


def run_event_to_ag_ui(event: Mapping[str, Any] | RunEvent) -> dict[str, Any]:
    """Project a canonical Chimera run event to AG-UI-compatible JSON.

    Chimera's internal event schema remains canonical; this is an adapter for
    frontends that expect AG-UI lifecycle/text/tool/state/approval events.
    """
    row = event.as_dict() if isinstance(event, RunEvent) else dict(event)
    data = row.get("data") if isinstance(row.get("data"), dict) else {}
    kind = str(row.get("kind", "event"))
    typ = _ag_ui_type(kind)
    out: dict[str, Any] = {
        "type": typ,
        "eventId": row.get("id"),
        "timestamp": row.get("ts"),
        "runId": row.get("run_id"),
        "chimera": {"kind": kind, "schemaVersion": row.get("schema_version")},
    }
    if typ == "TEXT_MESSAGE_CONTENT":
        out["delta"] = str(data.get("delta") or data.get("text") or data.get("content") or data.get("message") or "")
        if data.get("message_id") or data.get("messageId"):
            out["messageId"] = data.get("message_id") or data.get("messageId")
    elif typ in {"TOOL_CALL_START", "TOOL_CALL_END"}:
        out["toolCallId"] = str(data.get("tool_call_id") or data.get("toolCallId") or row.get("id"))
        out["name"] = str(data.get("tool") or data.get("name") or data.get("kind") or "tool")
        if typ == "TOOL_CALL_START":
            out["args"] = data.get("args") or data.get("arguments") or {}
        else:
            out["result"] = data.get("result") if "result" in data else data.get("output")
            out["ok"] = bool(data.get("ok", "error" not in data))
    elif typ == "STATE_DELTA":
        delta = data.get("delta") or data.get("patch") or data.get("json_patch")
        out["delta"] = delta if isinstance(delta, list) else [{"op": "add", "path": "/events/-", "value": data}]
    elif typ == "APPROVAL_REQUIRED":
        out["approval"] = {
            "id": str(data.get("approval_id") or data.get("id") or row.get("id")),
            "reason": str(data.get("reason") or data.get("message") or "approval required"),
            "action": data.get("action") or data.get("tool") or kind,
        }
    elif typ == "RUN_ERROR":
        out["error"] = {"message": str(data.get("error") or data.get("message") or kind), "data": data}
    else:
        out["data"] = data
    return out


def run_events_to_ag_ui(events: Iterable[Mapping[str, Any] | RunEvent]) -> list[dict[str, Any]]:
    return [run_event_to_ag_ui(event) for event in events]


class RunEventBus:
    def __init__(self, root: pathlib.Path, *, max_bytes: int = 10_000_000):
        self.root = pathlib.Path(root).resolve()
        self.path = self.root / ".chimera" / "run-events.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.max_bytes = max(4096, int(max_bytes))

    def append(self, run_id: str, kind: str, data: dict[str, Any] | None = None) -> RunEvent:
        event = RunEvent(
            schema_version="chimera.run-event.v1",
            id="run-event:" + uuid.uuid4().hex,
            ts=time.time(),
            run_id=str(run_id),
            kind=str(kind),
            data=_redact(dict(data or {})),
        )
        payload = json.dumps(event.as_dict(), sort_keys=True, default=str) + "\n"
        with self.path.open("a", encoding="utf-8") as handle:
            if os.fstat(handle.fileno()).st_size + len(payload.encode()) > self.max_bytes:
                # Compact to the newest half before appending; this is a local
                # UI/event bus, not the authoritative WAL.
                rows = self.replay(limit=5000)
                keep = rows[len(rows) // 2 :]
                handle.close()
                tmp = self.path.with_suffix(".tmp")
                tmp.write_text("".join(json.dumps(row, sort_keys=True, default=str) + "\n" for row in keep), encoding="utf-8")
                os.replace(tmp, self.path)
                with self.path.open("a", encoding="utf-8") as retry:
                    retry.write(payload)
                return event
            handle.write(payload)
        return event

    def replay(self, *, after_id: str | None = None, run_id: str | None = None, limit: int = 200) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        rows = []
        seen_after = after_id is None
        for line in self.path.read_text(encoding="utf-8", errors="replace").splitlines():
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not seen_after:
                seen_after = row.get("id") == after_id
                continue
            if run_id is not None and row.get("run_id") != run_id:
                continue
            rows.append(row)
        return rows[-max(1, min(5000, int(limit))):]

    def replay_ag_ui(self, *, after_id: str | None = None, run_id: str | None = None, limit: int = 200) -> list[dict[str, Any]]:
        return run_events_to_ag_ui(self.replay(after_id=after_id, run_id=run_id, limit=limit))

    def seed_from_wal(self, wal_rows: Iterable[dict[str, Any]], *, max_rows: int = 100) -> int:
        count = 0
        for row in list(wal_rows)[-max_rows:]:
            data = row.get("data") if isinstance(row.get("data"), dict) else {}
            run_id = str(data.get("run_id") or data.get("session_id") or data.get("branch") or "wal")
            self.append(run_id, "wal." + str(row.get("kind", "unknown")), {"seq": row.get("seq"), **data})
            count += 1
        return count
