"""Explicit PgBouncer transaction/session carve-out for PostgreSQL features."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class PoolRoute(_FrozenModel):
    operation: Literal["query", "listen", "persistent-set", "temp-table", "session-advisory-lock"]
    route: Literal["transaction-pool", "session-pool-or-direct"]
    reason: str


class PgBouncerRoutingPolicy:
    """One pool architecture; session-bound features never enter transaction mode."""

    _SESSION = {"listen", "persistent-set", "temp-table", "session-advisory-lock"}

    @classmethod
    def route(cls, operation: str) -> PoolRoute:
        if operation not in {"query", *cls._SESSION}:
            raise ValueError("unknown PostgreSQL pool operation")
        if operation in cls._SESSION:
            return PoolRoute(
                operation=operation,
                route="session-pool-or-direct",
                reason=f"{operation} requires stable PostgreSQL session identity",
            )
        return PoolRoute(
            operation="query", route="transaction-pool",
            reason="stateless query is compatible with transaction pooling",
        )
