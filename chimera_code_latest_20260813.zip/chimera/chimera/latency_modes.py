"""Latency SLO modes for choosing how much machinery a task pays for."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Literal

Mode=Literal["inspect","micro_edit","normal_fix","high_risk"]

@dataclass(frozen=True)
class LatencyModeDecision:
    mode:Mode; max_turns:int; run_tests:bool; allow_dag:bool; heldout_required:bool; reason:str

def decide_latency_mode(task:str, *, target_count:int=0, high_risk:bool=False, allow_write:bool=False)->LatencyModeDecision:
    lower=task.lower()
    if not allow_write or any(w in lower for w in ("inspect","explain","why","analyze","analyse")):
        return LatencyModeDecision("inspect",3,False,False,False,"assessment/inspection path")
    if high_risk or any(w in lower for w in ("auth","payment","credential","security","delete","migration")):
        return LatencyModeDecision("high_risk",10,True,True,True,"high-risk task requires full gates")
    if target_count and target_count<=2:
        return LatencyModeDecision("micro_edit",5,True,False,False,"small bounded edit")
    return LatencyModeDecision("normal_fix",8,True,True,True,"default fix path")
