"""Optional DuckDB local analytics projection for Chimera WAL telemetry."""
from __future__ import annotations

import json
import pathlib
from typing import Any

from .wal import WAL


class DuckDBTelemetryProjection:
    """Import redacted WAL rows into DuckDB when the optional dependency exists.

    The WAL remains the source of truth.  DuckDB is a local analytical mirror for
    fast ad-hoc cost/error/timeline queries and may be deleted at any time.
    """

    def __init__(self, root: pathlib.Path, *, database: pathlib.Path | None = None):
        self.root = pathlib.Path(root).resolve()
        self.database = database or (self.root / ".chimera" / "telemetry.duckdb")

    def available(self) -> bool:
        try:
            import duckdb  # noqa: F401
            return True
        except Exception:
            return False

    def project(self, *, dry_run: bool = False, limit: int | None = None) -> dict[str, Any]:
        rows = WAL(self.root).replay()
        if limit is not None:
            rows = rows[-max(1, int(limit)):]
        prepared = [self._flatten(row) for row in rows]
        if dry_run:
            return {
                "schema_version": "chimera.telemetry-duckdb-projection.v1",
                "available": self.available(),
                "dry_run": True,
                "rows_seen": len(prepared),
                "database": str(self.database),
                "would_write": False,
            }
        try:
            import duckdb
        except Exception:
            return {
                "schema_version": "chimera.telemetry-duckdb-projection.v1",
                "available": False,
                "dry_run": False,
                "rows_seen": len(prepared),
                "database": str(self.database),
                "written": 0,
                "error": "missing optional dependency: duckdb",
            }
        self.database.parent.mkdir(parents=True, exist_ok=True)
        con = duckdb.connect(str(self.database))
        try:
            con.execute(
                "CREATE TABLE IF NOT EXISTS wal_events (seq BIGINT PRIMARY KEY, ts VARCHAR, kind VARCHAR, provider VARCHAR, model VARCHAR, input_tokens BIGINT, output_tokens BIGINT, total_tokens BIGINT, duration_ms DOUBLE, payload_json VARCHAR)"
            )
            con.execute("DELETE FROM wal_events")
            if prepared:
                con.executemany(
                    "INSERT INTO wal_events VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [(
                        r["seq"], r["ts"], r["kind"], r["provider"], r["model"],
                        r["input_tokens"], r["output_tokens"], r["total_tokens"], r["duration_ms"], r["payload_json"],
                    ) for r in prepared],
                )
            summary = con.execute(
                "SELECT count(*) rows, coalesce(sum(input_tokens),0) input_tokens, coalesce(sum(output_tokens),0) output_tokens, coalesce(sum(total_tokens),0) total_tokens FROM wal_events"
            ).fetchone()
        finally:
            con.close()
        return {
            "schema_version": "chimera.telemetry-duckdb-projection.v1",
            "available": True,
            "dry_run": False,
            "database": str(self.database),
            "written": len(prepared),
            "summary": {"rows": int(summary[0]), "input_tokens": int(summary[1]), "output_tokens": int(summary[2]), "total_tokens": int(summary[3])},
        }

    @staticmethod
    def _flatten(row: dict[str, Any]) -> dict[str, Any]:
        data = row.get("data") if isinstance(row.get("data"), dict) else {}
        usage = data.get("usage") if isinstance(data.get("usage"), dict) else data
        def num(*keys: str) -> int | None:
            for key in keys:
                value = usage.get(key) if isinstance(usage, dict) else None
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    return int(value)
            return None
        return {
            "seq": int(row.get("seq") or 0),
            "ts": str(row.get("ts") or ""),
            "kind": str(row.get("kind") or ""),
            "provider": str(data.get("provider")) if data.get("provider") is not None else None,
            "model": str(data.get("model") or data.get("request_model")) if (data.get("model") or data.get("request_model")) is not None else None,
            "input_tokens": num("input_tokens", "prompt_tokens"),
            "output_tokens": num("output_tokens", "completion_tokens"),
            "total_tokens": num("total_tokens", "tokens"),
            "duration_ms": float(data.get("duration_ms") or data.get("latency_ms")) if isinstance(data.get("duration_ms") or data.get("latency_ms"), (int, float)) else None,
            "payload_json": json.dumps(row, sort_keys=True, default=str),
        }
