"""Per-turn latency ownership ledger: model, tools, and client orchestration."""
from __future__ import annotations
import pathlib,time
from dataclasses import dataclass
from typing import Any
from .wal import WAL, wal_write

@dataclass
class TurnLatency:
    session:str;turn:int;started:float;model_ms:float=0.;tool_ms:float=0.;first_output_ms:float|None=None
    def finish(self)->dict[str,Any]:
        wall=(time.perf_counter()-self.started)*1000
        client=max(0.,wall-self.model_ms-self.tool_ms)
        return {"session":self.session,"turn":self.turn,"wall_ms":round(wall,3),"model_ms":round(self.model_ms,3),"tool_ms":round(self.tool_ms,3),"client_overhead_ms":round(client,3),"first_output_ms":self.first_output_ms}
class LatencyAttributionLedger:
 def __init__(self,root:pathlib.Path):self.wal=WAL(pathlib.Path(root))
 def start(self,session:str,turn:int):return TurnLatency(session,turn,time.perf_counter())
 def record(self,row:dict[str,Any]):wal_write(self.wal, "turn_latency",row);return row
