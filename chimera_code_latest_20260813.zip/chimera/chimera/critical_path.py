"""Critical-path latency accounting for one harness run/turn."""
from __future__ import annotations
from dataclasses import dataclass, field
import time
from contextlib import contextmanager

@dataclass
class CriticalPathTrace:
    run_id:str
    spans:dict[str,float]=field(default_factory=dict)
    started:float=field(default_factory=time.perf_counter)
    @contextmanager
    def span(self,name:str):
        start=time.perf_counter()
        try: yield
        finally: self.spans[name]=self.spans.get(name,0.0)+(time.perf_counter()-start)*1000
    def summary(self)->dict:
        wall=(time.perf_counter()-self.started)*1000
        known=sum(self.spans.values())
        rows={k:round(v,3) for k,v in sorted(self.spans.items())}
        rows.update({"critical_path_ms":round(wall,3),"other_ms":round(max(0.0,wall-known),3)})
        return rows
