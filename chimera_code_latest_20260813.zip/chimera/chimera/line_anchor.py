"""Line-range anchor verification for resilient exact edits."""
from __future__ import annotations
import hashlib

def anchor(text:str,start:int,end:int)->dict:
 lines=text.splitlines(keepends=True);start=max(1,start);end=max(start,min(len(lines),end));before=''.join(lines[max(0,start-2):start-1]);after=''.join(lines[end:min(len(lines),end+2)])
 return {"start":start,"end":end,"before_hash":"sha256:"+hashlib.sha256(before.encode()).hexdigest(),"after_hash":"sha256:"+hashlib.sha256(after.encode()).hexdigest()}
def verify(text:str,value:dict)->bool:
 expected=anchor(text,int(value.get("start",1)),int(value.get("end",1)));return all(expected.get(k)==value.get(k) for k in ("before_hash","after_hash"))
