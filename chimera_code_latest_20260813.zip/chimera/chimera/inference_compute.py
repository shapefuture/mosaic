"""Task-aware inference-time compute routing policy."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class InferenceComputeDecision(_Frozen):
    schema_version: str = "chimera.inference-compute-decision.v1"
    task_type: Literal["coding", "math", "analysis", "simple", "creative"]
    system_mode: Literal["system1", "system2"]
    reasoning_effort: Literal["none", "low", "medium", "high"]
    reasoning_budget_tokens: int = Field(ge=0)
    candidate_strategy: Literal["single", "gsa"]
    temperature: float
    top_p: float
    over_reasoning_guard: str
    notes: tuple[str, ...]


class InferenceComputePlanner:
    """Small deterministic policy: spend reasoning only where it buys quality."""

    def classify(self, task: str) -> str:
        lower = task.lower()
        if any(word in lower for word in ("implement", "fix", "code", "pytest", "function", "script", "bug", "refactor")):
            return "coding"
        if any(word in lower for word in ("prove", "derive", "calculate", "equation", "math")):
            return "math"
        if any(word in lower for word in ("analyze", "compare", "audit", "architecture", "plan")):
            return "analysis"
        if any(word in lower for word in ("poem", "story", "creative", "tagline")):
            return "creative"
        return "simple"

    def plan(self, task: str, *, latency_priority: bool = False) -> InferenceComputeDecision:
        task_type = self.classify(task)
        if task_type in {"coding", "math"}:
            budget = 8000 if latency_priority else 16000
            return InferenceComputeDecision(
                task_type=task_type,
                system_mode="system2",
                reasoning_effort="high" if not latency_priority else "medium",
                reasoning_budget_tokens=budget,
                candidate_strategy="gsa" if task_type == "coding" else "single",
                temperature=0.3,
                top_p=0.9,
                over_reasoning_guard="cap retries; final verdict must come from external tool/test result",
                notes=(
                    "Use higher reasoning only for high-stakes checkable work.",
                    "For coding, prefer diverse drafts plus synthesis, then external execution tests.",
                ),
            )
        if task_type == "analysis":
            return InferenceComputeDecision(
                task_type="analysis",
                system_mode="system2",
                reasoning_effort="medium",
                reasoning_budget_tokens=4000 if not latency_priority else 2000,
                candidate_strategy="single",
                temperature=0.4,
                top_p=0.9,
                over_reasoning_guard="stop when evidence is sufficient; do not add speculative certainty",
                notes=("Use moderate reasoning and evidence retrieval; avoid over-thinking settled facts.",),
            )
        return InferenceComputeDecision(
            task_type=task_type,  # type: ignore[arg-type]
            system_mode="system1",
            reasoning_effort="low" if task_type == "creative" else "none",
            reasoning_budget_tokens=1000 if task_type == "creative" else 0,
            candidate_strategy="single",
            temperature=0.8 if task_type == "creative" else 0.2,
            top_p=0.9,
            over_reasoning_guard="do not spend high reasoning budget on trivial or subjective tasks",
            notes=("Route simple/creative tasks to fast mode to reduce latency and cost.",),
        )
