
"""
Etas — Effect-Typed Language for Agent Systems (2607.17780)

Core calculus port per PRD §7.2:
- agent {input: T, output: U, tools: Surface, prompt, trace}
- effect Row = {fs, net, env, mcp, time}
- spec = allow/deny/temporal (G/F/U)
- typing with spec conformance emits residual obligations
- handlers trace-transparent (request→handled→committed)

This module provides:
- Etas HIR-like checker: chimera check --trace trace.json
- Spec compiler: allow/deny/temporal -> LTLMonitor + CapabilitySet
- Handler trace-transparency check

Reuses Etas Rust prototype CLI semantics as `chimera check` pre-exec.
For code queries, integrates Gödel: code -> COREF facts -> Soufflé (via graph.py Cypher)

Example per PRD:
effect { fs: read["./src/**"], net: deny_all }
agent ReviewAuth : { input: Diff, output: Report }
  tools: [infigraph.query, mirage.read]
  prompt: "Review auth, use graph not grep"
  trace: [request(fetch_url) -> handled -> committed]
spec Sec: G(!access(financial) | authenticated)
"""
from __future__ import annotations
import json, pathlib, re, shlex
from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field
from .effects import CapabilitySet, EffectRequest, check_effect
from .verifier import LTLMonitor

class EtasSpec(BaseModel):
    name: str
    formula: str  # LTL temporal: G(...), F(...), ...
    kind: str = "temporal"  # allow|deny|temporal

class EtasAgent(BaseModel):
    name: str
    input_type: str = "Diff"
    output_type: str = "Report"
    tools: List[str] = Field(default_factory=list)
    effect_row: Dict[str, List[str]] = Field(default_factory=dict)
    prompt: str = ""
    trace_spec: List[str] = Field(default_factory=list)

class EtasCheckResult(BaseModel):
    agent: str
    spec_conformance: bool
    residual_obligations: List[str] = Field(default_factory=list)
    violations: List[str] = Field(default_factory=list)
    trace_transparent: bool = True

def parse_effect_row(s: str) -> Dict[str, List[str]]:
    """
    Parse Etas effect row syntax: effect { fs: read["./src/**"], net: deny_all }
    Returns needs dict like {"fs": ["./src/**"], "net": []}
    """
    row={}
    # Find blocks like fs: read["./src/**"] or net: deny_all
    for kind in ["fs","net","env","mcp","time"]:
        m=re.search(rf"{kind}\s*:\s*(?:read\s*\[([^\]]+)\]|write\s*\[([^\]]+)\]|deny_all|allow_all|\[([^\]]+)\])", s, re.IGNORECASE)
        if m:
            g = m.group(1) or m.group(2) or m.group(3)
            if g:
                # split by comma, strip quotes
                items=[x.strip().strip('"').strip("'") for x in g.split(",")]
                row[kind]=items
            else:
                if "deny_all" in s:
                    row[kind]=[]
                else:
                    row[kind]=["./**"]
    return row

def check_spec_conformance(agent: EtasAgent, specs: List[EtasSpec], trace: List[Dict], capability: CapabilitySet) -> EtasCheckResult:
    residuals=[]
    violations=[]
    # Check each tool effect against capability (Etas HIR check)
    for tool in agent.tools:
        # Map tool to effect: infigraph.query -> fs.read, mirage.read -> fs.read
        effect = "fs.read" if "graph" in tool or "mirage" in tool or "read" in tool else "net.fetch" if "fetch" in tool else "mcp.call"
        needs={}
        if effect.startswith("fs"):
            needs["fs"]=agent.effect_row.get("fs", ["./src/**"])
        if effect.startswith("net"):
            needs["net"]=agent.effect_row.get("net", [])
        v=check_effect(EffectRequest(effect=effect, needs=needs), capability)
        if not v.allowed:
            violations.append(f"{tool}: {v.denied_reason}")
        residuals.extend(v.residual_obligations)

    # Spec conformance: compile specs to LTL + capability
    for spec in specs:
        # Allow/deny specs -> capability already checked
        # Temporal specs -> LTLMonitor
        if spec.kind=="temporal" or spec.formula.strip().startswith("G(") or "->" in spec.formula:
            mon=LTLMonitor(spec.formula)
            ok,msg=mon.check(trace)
            if not ok:
                violations.append(f"spec {spec.name} {spec.formula} violated: {msg}")
        # handler trace-transparency: ensure handled→committed not invisible
        # Check that trace contains requested→handled→committed triple
        # Handlers must not hide requests from audit
        if agent.trace_spec:
            # Simple check: if trace has 'handled' but not 'requested', transparency broken
            trace_str=json.dumps(trace).lower()
            if "handled" in trace_str and "requested" not in trace_str:
                violations.append(f"trace-transparency broken for {agent.name}: handled without requested")

    return EtasCheckResult(
        agent=agent.name,
        spec_conformance=len(violations)==0,
        residual_obligations=residuals,
        violations=violations,
        trace_transparent=len([v for v in violations if "transparency" in v])==0
    )

def _shell_write_paths(command: str) -> List[str]:
    """Conservatively extract explicit filesystem sinks from a shell command."""
    paths: List[str] = []
    # Redirection and tee are the most common ways a model bypasses a nominal
    # read-only command.  Ignore descriptor redirects such as 2>&1.
    for match in re.finditer(r"(?<![0-9])(?:>>|>)\s*(?!&)([^\s;&|]+)", command):
        paths.append(match.group(1).strip("'\""))
    try:
        tokens = shlex.split(command, posix=True)
    except ValueError as exc:
        raise ValueError(f"unparseable shell command: {exc}") from exc
    if not tokens:
        return paths
    executable = pathlib.PurePosixPath(tokens[0]).name
    if executable in {"touch", "mkdir", "rmdir", "rm", "truncate"}:
        paths.extend(t for t in tokens[1:] if not t.startswith("-"))
    elif executable in {"cp", "mv", "install"} and len(tokens) >= 3:
        paths.append(tokens[-1])
    elif executable == "tee":
        paths.extend(t for t in tokens[1:] if not t.startswith("-"))
    elif executable == "sed" and any(t == "-i" or t.startswith("-i") for t in tokens):
        paths.extend(t for t in tokens[1:] if not t.startswith("-") and not t.startswith("s/"))
    return list(dict.fromkeys(paths))


def _shell_network_hosts(command: str) -> List[str]:
    from urllib.parse import urlparse
    hosts: List[str] = []
    for raw in re.findall(r"https?://[^\s'\";&|]+", command):
        host = urlparse(raw).hostname
        if host:
            hosts.append(host)
    return list(dict.fromkeys(hosts))


def preflight_command(command: str, capability: CapabilitySet) -> Dict[str, Any]:
    """Compile a command into effects and enforce them before execution.

    The result is evidence suitable for the WAL.  Parse failures and unresolved
    resources fail closed; this function must never be wrapped in a blanket
    ``except: pass`` at the execution boundary.
    """
    if not isinstance(command, str) or not command.strip():
        return {"allowed": False, "violations": ["empty command"], "effects": [], "trace_transparent": False}
    if "\x00" in command or "\n" in command:
        return {"allowed": False, "violations": ["NUL/newline command injection"], "effects": [], "trace_transparent": False}
    try:
        write_paths = _shell_write_paths(command)
        hosts = _shell_network_hosts(command)
    except ValueError as exc:
        return {"allowed": False, "violations": [str(exc)], "effects": [], "trace_transparent": False}

    requests: List[EffectRequest] = []
    if write_paths:
        requests.append(EffectRequest(effect="fs.write", needs={"fs": write_paths}))
    if hosts:
        requests.append(EffectRequest(effect="net.fetch", needs={"net": hosts}))

    violations: List[str] = []
    residuals: List[str] = []
    effects: List[Dict[str, Any]] = []
    for request in requests:
        verdict = check_effect(request, capability)
        effects.append({"request": request.model_dump(), "verdict": verdict.model_dump()})
        if not verdict.allowed:
            violations.append(verdict.denied_reason or f"denied {request.effect}")
        residuals.extend(verdict.residual_obligations)
    if residuals:
        violations.extend(f"unresolved obligation: {item}" for item in residuals)

    # A handler trace is transparent only when the request and verdict are both
    # represented in this evidence object.
    return {
        "allowed": not violations,
        "violations": violations,
        "residual_obligations": residuals,
        "effects": effects,
        "trace_transparent": True,
        "command_digest": __import__("hashlib").sha256(command.encode()).hexdigest(),
    }


def check_file(path: pathlib.Path, trace_path: Optional[pathlib.Path]=None, capability: Optional[CapabilitySet]=None) -> Dict:
    """
    chimera check --trace trace.json
    Parses Etas-like file or JSON and runs HIR checks.
    If file is .etas, parse Etas syntax; if .json, load agent/spec.
    """
    if not path.exists():
        return {"error": f"{path} not found"}
    text=path.read_text()
    # Try JSON first
    try:
        data=json.loads(text)
        agent=EtasAgent(**data.get("agent", data))
        specs=[EtasSpec(**s) for s in data.get("specs", [])]
        trace=json.loads(trace_path.read_text()) if trace_path and trace_path.exists() else []
        cap=capability or CapabilitySet(fs_allow=["./src/**"], net_allow=["api.anthropic.com"])
        res=check_spec_conformance(agent, specs, trace, cap)
        return res.model_dump()
    except Exception:
        pass
    # Fallback: parse Etas pseudo-syntax from .etas file
    effect_row=parse_effect_row(text)
    agent=EtasAgent(name="FileAgent", effect_row=effect_row, tools=["infigraph.query"], prompt=text[:200])
    trace=[]
    if trace_path and trace_path.exists():
        trace=json.loads(trace_path.read_text())
    cap=capability or CapabilitySet(fs_allow=["./src/**"], net_allow=[])
    res=check_spec_conformance(agent, [], trace, cap)
    return res.model_dump()
