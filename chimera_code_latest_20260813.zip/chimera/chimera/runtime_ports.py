"""Narrow, authority-aware ports for local and cloud Chimera adapters.

Ports carry immutable identity, deadline, budget, and tenant context.  They do
not grant policy or commit authority; application use cases own those decisions.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from enum import StrEnum
from typing import (
    Any,
    Literal,
    Protocol,
    runtime_checkable,
)


class CompletionOutcome(StrEnum):
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"
    UNKNOWN = "unknown_outcome"


@dataclass(frozen=True)
class CompletionRequest:
    # Preserve the historical two-position constructor while carrying the full
    # cloud/application context through newer call sites.
    prompt: str
    model: str
    tenant_key: str | None = None
    principal_hash: str | None = None
    run_id: str | None = None
    request_id: str | None = None
    trace_id: str | None = None
    deadline_unix_ms: int | None = None
    max_input_tokens: int | None = None
    max_output_tokens: int | None = None
    max_cost_usd: float | None = None
    idempotency_key: str | None = None
    tools: tuple[Mapping[str, Any], ...] = ()
    response_schema: Mapping[str, Any] | None = None
    cancellation_token: str | None = None


@dataclass(frozen=True)
class CompletionResult:
    outcome: CompletionOutcome
    answer: str = ""
    model: str = ""
    provider: str = ""
    usage: Mapping[str, Any] = field(default_factory=dict)
    request_id: str | None = None
    retry_count: int = 0
    error_class: str | None = None
    reconciliation_required: bool = False
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def as_mapping(self) -> dict[str, Any]:
        return {
            "outcome": self.outcome.value,
            "answer": self.answer,
            "model": self.model,
            "provider": self.provider,
            "usage": dict(self.usage),
            "request_id": self.request_id,
            "retry_count": self.retry_count,
            "error_class": self.error_class,
            "reconciliation_required": self.reconciliation_required,
            **dict(self.metadata),
        }


@runtime_checkable
class ModelCompletionPort(Protocol):
    def complete(
        self, request: CompletionRequest
    ) -> Mapping[str, Any] | CompletionResult: ...


class CallableModelCompletionAdapter:
    """Compatibility adapter for existing ``callable(prompt, model=...)`` providers."""

    def __init__(
        self, invoke: Callable[..., Mapping[str, Any] | CompletionResult]
    ) -> None:
        self._invoke = invoke

    def complete(
        self, request: CompletionRequest
    ) -> Mapping[str, Any] | CompletionResult:
        response = self._invoke(request.prompt, model=request.model)
        if isinstance(response, CompletionResult):
            return response
        if not isinstance(response, Mapping):
            raise TypeError(
                "model completion adapter must return a mapping or CompletionResult"
            )
        return dict(response)


@runtime_checkable
class WorkspaceTransactionPort(Protocol):
    def branch(self, name: str, from_branch: str = "main") -> Any: ...
    def diff(self, branch: str) -> Mapping[str, Any]: ...
    def commit(self, branch: str, message: str) -> str: ...
    def abort(self, branch: str) -> None: ...
    def list_branches(self) -> Sequence[str]: ...


@runtime_checkable
class ArtifactPort(Protocol):
    def put(
        self,
        data: bytes | str,
        *,
        media_type: str = "application/octet-stream",
        provenance: Mapping[str, Any] | None = None,
    ) -> Any: ...
    def get(self, digest: str) -> bytes: ...
    def has(self, digest: str) -> bool: ...


@runtime_checkable
class EventLogPort(Protocol):
    def append(self, kind: str, data: dict[str, Any]) -> Any: ...
    def replay(
        self, after_seq: int = -1, kind: str | None = None
    ) -> list[dict[str, Any]]: ...


@runtime_checkable
class WaitPort(Protocol):
    def register(
        self,
        *,
        run_id: str,
        kind: Any,
        target: Any,
        owner: str,
        timeout_seconds: float,
        evidence_ref: str | None = None,
    ) -> Any: ...
    def pending(self, run_id: str) -> Sequence[Any]: ...


@runtime_checkable
class LeasePort(Protocol):
    def acquire_lease(self, key: str, holder: str, ttl_seconds: float) -> Any: ...
    def release_lease(
        self, key: str, holder: str, fencing_token: int | None = None
    ) -> bool: ...


@runtime_checkable
class SecretPort(Protocol):
    def get(self, *, tenant_key: str | None, name: str) -> str | None: ...


@runtime_checkable
class QuotaPort(Protocol):
    def admit(
        self,
        *,
        tenant_key: str,
        run_id: str,
        max_active_runs: int,
        expires_at: float,
    ) -> Any: ...
    def release(self, *, tenant_key: str, run_id: str) -> bool: ...


@runtime_checkable
class ClockPort(Protocol):
    def time(self) -> float: ...
    def monotonic(self) -> float: ...


@runtime_checkable
class IdentifierPort(Protocol):
    def new(self, prefix: str) -> str: ...


@runtime_checkable
class TelemetryPort(Protocol):
    def emit(self, kind: str, data: Mapping[str, Any]) -> Any: ...


@runtime_checkable
class EgressPort(Protocol):
    def authorize(self, url: str, *, tenant_key: str | None = None) -> Any: ...


@runtime_checkable
class CodeIntelligencePort(Protocol):
    def query(
        self, query: str, *, limit: int, kind: str | None = None
    ) -> Sequence[Mapping[str, Any]]: ...


@runtime_checkable
class TaskRunnerPort(Protocol):
    def run(
        self,
        task: str,
        *,
        branch: str,
        model: str,
        auto_commit: bool,
    ) -> Mapping[str, Any]: ...


@runtime_checkable
class IndependentReviewPort(Protocol):
    def review(self, request: Any) -> Any: ...


@runtime_checkable
class SessionPort(Protocol):
    def open(
        self,
        objective: str,
        *,
        model: str,
        base_branch: str,
        protocol: Literal["rpc", "acp", "mcp"],
    ) -> Any: ...
    def get(self, session_id: str) -> Any: ...
    def list(self) -> Sequence[Any]: ...
    def send(self, session_id: str, message: str) -> Mapping[str, Any]: ...
    def verify(self, session_id: str, command: str) -> Any: ...
    def commit(self, session_id: str, message: str) -> Any: ...
    def record_commit(self, session_id: str, commit_hash: str) -> Any: ...
    def abort(self, session_id: str) -> Any: ...
