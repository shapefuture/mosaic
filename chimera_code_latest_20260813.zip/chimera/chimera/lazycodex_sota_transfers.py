"""Additional LazyCodex/SOTA-skills transfers for Chimera.

Small stdlib ports only: ranked fetch/WAF profiles, visual diff hotspots,
comment request extraction, team coordination, and skill/eval/release/hook
invariants.  These are deterministic helpers for Chimera agents and CI gates.
"""
from __future__ import annotations

import json
import pathlib
import re
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable, Mapping, Sequence


@dataclass(frozen=True)
class ProfileHit:
    profile_id: str
    confidence: float
    signals: tuple[str, ...]


class RankedWAFProfileDetector:
    DEFAULT_PROFILES = {
        "cloudflare": {"cookies": ["cf_clearance", "__cf_bm"], "headers": ["cf-ray", "cf-cache-status"], "body": ["cloudflare"]},
        "akamai": {"cookies": ["ak_bmsc", "bm_sv"], "headers": ["x-akamai-*"], "body": ["akamai"]},
        "datadome": {"cookies": ["datadome"], "headers": ["x-datadome"], "body": ["datadome"]},
        "unknown_challenge": {"cookies": [], "headers": [], "body": ["captcha", "challenge", "enable javascript"]},
    }

    def __init__(self, profiles: Mapping[str, Mapping[str, Sequence[str]]] | None = None) -> None:
        self.profiles = dict(profiles or self.DEFAULT_PROFILES)

    def rank(self, *, headers: Mapping[str, str] | None = None, cookies: Mapping[str, str] | None = None, body: str = "") -> list[dict[str, Any]]:
        hkeys = {str(k).lower() for k in (headers or {})}
        ckeys = {str(k).lower() for k in (cookies or {})}
        lower_body = str(body).lower()
        hits: list[ProfileHit] = []
        for profile_id, profile in self.profiles.items():
            signals: list[str] = []
            for pat in profile.get("cookies", ()):
                if self._matches(ckeys, str(pat).lower()):
                    signals.append(f"cookie:{pat}")
            for pat in profile.get("headers", ()):
                if self._matches(hkeys, str(pat).lower()):
                    signals.append(f"header:{pat}")
            for needle in profile.get("body", ()):
                if str(needle).lower() in lower_body:
                    signals.append(f"body:{needle}")
            if signals:
                confidence = 0.9 if len(signals) >= 2 else 0.6
                hits.append(ProfileHit(str(profile_id), confidence, tuple(signals)))
        hits.sort(key=lambda h: (-h.confidence, h.profile_id))
        return [asdict(hit) for hit in hits]

    @staticmethod
    def _matches(values: set[str], pattern: str) -> bool:
        if "*" in pattern:
            prefix = pattern.split("*", 1)[0]
            return any(v.startswith(prefix) for v in values)
        return pattern in values


@dataclass(frozen=True)
class DecodedImage:
    width: int
    height: int
    rgba: bytes
    has_transparent_pixels: bool = False


class VisualDiffHotspots:
    @staticmethod
    def diff(reference: DecodedImage, actual: DecodedImage, *, grid_size: int = 8) -> dict[str, Any]:
        overlap_w = min(reference.width, actual.width)
        overlap_h = min(reference.height, actual.height)
        total = overlap_w * overlap_h
        cols = max(1, min(grid_size, overlap_w or 1))
        rows = max(1, min(grid_size, overlap_h or 1))
        cell_diff = [0] * (cols * rows)
        cell_total = [0] * (cols * rows)
        diff_pixels = 0
        for y in range(overlap_h):
            cy = min(rows - 1, (y * rows) // overlap_h)
            for x in range(overlap_w):
                cx = min(cols - 1, (x * cols) // overlap_w)
                idx = cy * cols + cx
                cell_total[idx] += 1
                ro = (y * reference.width + x) * 4
                ao = (y * actual.width + x) * 4
                if reference.rgba[ro:ro+4] != actual.rgba[ao:ao+4]:
                    diff_pixels += 1
                    cell_diff[idx] += 1
        hotspots = []
        for gy in range(rows):
            for gx in range(cols):
                i = gy * cols + gx
                if cell_diff[i] and cell_total[i]:
                    left = (gx * overlap_w) // cols
                    right = ((gx + 1) * overlap_w) // cols
                    top = (gy * overlap_h) // rows
                    bottom = ((gy + 1) * overlap_h) // rows
                    hotspots.append({"gridX": gx, "gridY": gy, "x": left, "y": top, "width": right-left, "height": bottom-top, "diffRatio": round(cell_diff[i] / cell_total[i], 4)})
        hotspots.sort(key=lambda h: -h["diffRatio"])
        ratio = 0 if total == 0 else diff_pixels / total
        score = round((1 - ratio) * 100)
        return {
            "schema_version": "chimera.visual-diff-hotspots.v1",
            "dimensionsMatch": reference.width == actual.width and reference.height == actual.height,
            "reference": {"width": reference.width, "height": reference.height},
            "actual": {"width": actual.width, "height": actual.height},
            "totalPixels": total,
            "diffPixels": diff_pixels,
            "diffRatio": round(ratio, 4),
            "similarityScore": score,
            "alphaChannelIntact": not (reference.has_transparent_pixels and not actual.has_transparent_pixels),
            "hotspots": hotspots,
            "summary": f"{score}/100 similarity; {diff_pixels}/{total} pixels differ; {len(hotspots)} hotspot region(s).",
        }


class CommentRequestExtractor:
    FAILURE_WORDS = ("error", "error:", "failed to", "could not")

    def extract(self, event: Mapping[str, Any]) -> list[dict[str, Any]]:
        if event.get("isError"):
            return []
        text = self._content_text(event.get("content"))
        if self._is_failure(text):
            return []
        tool = str(event.get("toolName") or event.get("tool_name") or "").lower()
        data = event.get("input") if isinstance(event.get("input"), Mapping) else event
        if tool == "write":
            path = self._get(data, "filePath", "file_path", "path")
            content = self._get(data, "content")
            if path and content is not None:
                return [{"sourceToolName": event.get("toolName", tool), "toolName": "Write", "filePath": path, "toolInput": {"file_path": path, "content": content}}]
        if tool == "edit":
            path = self._get(data, "filePath", "file_path", "path")
            old = self._get(data, "oldString", "old_string")
            new = self._get(data, "newString", "new_string")
            if path and old is not None and new is not None:
                return [{"sourceToolName": event.get("toolName", tool), "toolName": "Edit", "filePath": path, "toolInput": {"file_path": path, "old_string": old, "new_string": new}}]
        if tool in {"multiedit", "multi_edit"}:
            path = self._get(data, "filePath", "file_path", "path")
            edits = []
            for item in data.get("edits", []) if isinstance(data.get("edits"), list) else []:
                if isinstance(item, Mapping):
                    old = self._get(item, "oldString", "old_string")
                    new = self._get(item, "newString", "new_string")
                    if old is not None and new is not None:
                        edits.append({"old_string": old, "new_string": new})
            if path and edits:
                return [{"sourceToolName": event.get("toolName", tool), "toolName": "MultiEdit", "filePath": path, "toolInput": {"file_path": path, "edits": edits}}]
        return []

    @classmethod
    def _is_failure(cls, text: str) -> bool:
        lower = text.strip().lower()
        return lower.startswith("error") or any(w in lower for w in cls.FAILURE_WORDS[1:])

    @staticmethod
    def _content_text(content: Any) -> str:
        if not isinstance(content, list):
            return ""
        return "\n".join(str(block.get("text", "")) for block in content if isinstance(block, Mapping) and block.get("type") == "text")

    @staticmethod
    def _get(mapping: Mapping[str, Any], *keys: str) -> str | None:
        for key in keys:
            value = mapping.get(key)
            if isinstance(value, str):
                return value
        return None


@dataclass
class TeamMember:
    id: str
    name: str
    focus: str
    status: str = "pending"
    thread_title: str | None = None


class TeamCoordinationState:
    MIN_MEMBERS = 2

    def __init__(self, *, team_name: str, session_name: str, transport: str = "threads") -> None:
        if not team_name.strip() or not session_name.strip():
            raise ValueError("team and session names are required")
        self.value = {
            "schema_version": "chimera.team-coordination-state.v1",
            "team_id": uuid.uuid4().hex,
            "team_name": team_name.strip(),
            "session_name": session_name.strip(),
            "transport": transport,
            "status": "active",
            "created_at": time.time(),
            "updated_at": time.time(),
            "members": [],
            "log": [{"event": "created", "detail": team_name.strip(), "ts": time.time()}],
        }

    def add_member(self, name: str, focus: str) -> dict[str, Any]:
        member = TeamMember(id="member:" + uuid.uuid4().hex[:12], name=name.strip(), focus=focus.strip(), thread_title=f"[{self.value['team_name']}] {name.strip()}")
        trial = [*self.value["members"], asdict(member)]
        self._assert_unique(trial, "focus")
        self._assert_unique(trial, "name")
        self.value["members"] = trial
        self._touch("member-added", member.name)
        return asdict(member)

    def ready(self) -> bool:
        return len(self.value["members"]) >= self.MIN_MEMBERS

    def as_dict(self) -> dict[str, Any]:
        return json.loads(json.dumps(self.value, sort_keys=True, default=str))

    def _touch(self, event: str, detail: str) -> None:
        self.value["updated_at"] = time.time()
        self.value["log"].append({"event": event, "detail": detail, "ts": time.time()})

    @staticmethod
    def _assert_unique(members: list[dict[str, Any]], field: str) -> None:
        seen: set[str] = set()
        for member in members:
            key = str(member.get(field, "")).strip().lower()
            if not key:
                raise ValueError(f"member {field} is required")
            if key in seen:
                raise ValueError(f"duplicate member {field}: {key}")
            seen.add(key)


class SOTASkillInvariantAudit:
    """Additional invariants from SOTA-skills for future Chimera registries."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def run(self) -> dict[str, Any]:
        findings: list[dict[str, Any]] = []
        findings.extend(self._router_library_map_findings())
        findings.extend(self._scoreboard_findings())
        findings.extend(self._release_frontdoor_findings())
        findings.extend(self._hook_docs_findings())
        return {
            "schema_version": "chimera.sota-skill-invariant-audit.v1",
            "root": str(self.root),
            "status": "pass" if not [f for f in findings if f["severity"] == "error"] else "fail",
            "findings": findings,
            "promotion_allowed": False,
        }

    def _router_library_map_findings(self) -> list[dict[str, Any]]:
        skills_dir = self.root / "skills"
        if not skills_dir.exists():
            return [{"severity": "info", "rule": "router-library-map", "path": str(skills_dir), "message": "no skills directory"}]
        skill_names = sorted(p.parent.name for p in skills_dir.glob("*/SKILL.md"))
        router = skills_dir / "sota" / "SKILL.md"
        if not router.exists():
            return [{"severity": "warning", "rule": "router-library-map", "path": str(router), "message": "router skill missing"}]
        text = router.read_text(encoding="utf-8", errors="replace")
        missing = [name for name in skill_names if name not in text]
        return [{"severity": "error", "rule": "router-library-map", "path": str(router), "message": f"skill not named in router: {name}"} for name in missing]

    def _scoreboard_findings(self) -> list[dict[str, Any]]:
        candidates = list(self.root.glob("**/RESULTS.md"))
        if not candidates:
            return [{"severity": "info", "rule": "scoreboard-denominator", "path": str(self.root), "message": "no RESULTS.md scoreboard"}]
        out = []
        for path in candidates:
            text = path.read_text(encoding="utf-8", errors="replace")
            if "|" in text and "sample" not in text.lower():
                out.append({"severity": "error", "rule": "scoreboard-denominator", "path": str(path), "message": "scoreboard/table lacks sample denominator wording"})
        return out

    def _release_frontdoor_findings(self) -> list[dict[str, Any]]:
        changelog = self.root / "CHANGELOG.md"
        if not changelog.exists():
            return [{"severity": "info", "rule": "release-frontdoor", "path": str(changelog), "message": "no changelog"}]
        text = changelog.read_text(encoding="utf-8", errors="replace")
        if "Front door checked:" in text:
            terms = re.findall(r"\*\*Front door checked:\*\*([^\n]+)", text)
            readme = (self.root / "README.md").read_text(encoding="utf-8", errors="replace") if (self.root / "README.md").exists() else ""
            missing = []
            for term_line in terms:
                for term in re.split(r"[,·•]", term_line):
                    value = term.strip(" .`*")
                    if value and value not in readme and value not in text:
                        missing.append(value)
            return [{"severity": "error", "rule": "release-frontdoor", "path": str(changelog), "message": f"front-door term not resolved: {m}"} for m in missing]
        return [{"severity": "warning", "rule": "release-frontdoor", "path": str(changelog), "message": "no '**Front door checked:**' declaration"}]

    def _hook_docs_findings(self) -> list[dict[str, Any]]:
        hooks = self.root / "hooks" / "hooks.json"
        readme = self.root / "README.md"
        if not hooks.exists() or not readme.exists():
            return [{"severity": "info", "rule": "hook-docs-equivalence", "path": str(self.root), "message": "no hook/readme pair"}]
        hook_text = hooks.read_text(encoding="utf-8", errors="replace")
        readme_text = readme.read_text(encoding="utf-8", errors="replace")
        try:
            parsed = json.loads(hook_text)
            names = sorted(str(k) for k in parsed.keys()) if isinstance(parsed, dict) else []
        except Exception:
            return [{"severity": "error", "rule": "hook-docs-equivalence", "path": str(hooks), "message": "hooks.json is not valid JSON"}]
        missing = [name for name in names if name not in readme_text]
        return [{"severity": "warning", "rule": "hook-docs-equivalence", "path": str(readme), "message": f"hook name not documented in README: {name}"} for name in missing]


class PngDecodeError(ValueError):
    pass


class PngDecoder:
    """Tiny PNG decoder for screenshot diff receipts without Pillow.

    Supports non-interlaced 8-bit grayscale/RGB/gray-alpha/RGBA PNGs, enough for
    deterministic screenshots generated by most browser tooling.
    """
    SIGNATURE = b"\x89PNG\r\n\x1a\n"

    @classmethod
    def decode(cls, data: bytes) -> DecodedImage:
        import struct, zlib
        if not data.startswith(cls.SIGNATURE):
            raise PngDecodeError("not a PNG file")
        chunks = []
        offset = 8
        while offset + 8 <= len(data):
            length = struct.unpack(">I", data[offset:offset+4])[0]
            ctype = data[offset+4:offset+8].decode("ascii", errors="replace")
            start = offset + 8
            end = start + length
            if end + 4 > len(data):
                raise PngDecodeError("truncated PNG chunk")
            chunks.append((ctype, data[start:end]))
            offset = end + 4
            if ctype == "IEND":
                break
        ihdr = next((chunk for typ, chunk in chunks if typ == "IHDR"), None)
        if ihdr is None or len(ihdr) < 13:
            raise PngDecodeError("missing IHDR")
        width, height = struct.unpack(">II", ihdr[:8])
        bit_depth = ihdr[8]
        color_type = ihdr[9]
        interlace = ihdr[12]
        if bit_depth != 8 or interlace != 0:
            raise PngDecodeError("only non-interlaced 8-bit PNGs are supported")
        channels = {0: 1, 2: 3, 4: 2, 6: 4}.get(color_type)
        if channels is None:
            raise PngDecodeError(f"unsupported color type {color_type}")
        idat = b"".join(chunk for typ, chunk in chunks if typ == "IDAT")
        if not idat:
            raise PngDecodeError("missing IDAT")
        inflated = zlib.decompress(idat)
        row_bytes = width * channels
        rgba = bytearray(width * height * 4)
        prev = bytearray(row_bytes)
        src = 0
        transparent = False
        for y in range(height):
            if src >= len(inflated):
                raise PngDecodeError("truncated image data")
            filter_type = inflated[src]
            src += 1
            raw = bytearray(inflated[src:src+row_bytes])
            src += row_bytes
            row = cls._unfilter(filter_type, raw, prev, channels)
            prev = row
            for x in range(width):
                si = x * channels
                if channels == 1:
                    r = g = b = row[si]; a = 255
                elif channels == 2:
                    r = g = b = row[si]; a = row[si+1]
                elif channels == 3:
                    r, g, b = row[si], row[si+1], row[si+2]; a = 255
                else:
                    r, g, b, a = row[si], row[si+1], row[si+2], row[si+3]
                if a < 255:
                    transparent = True
                di = (y * width + x) * 4
                rgba[di:di+4] = bytes([r, g, b, a])
        return DecodedImage(width, height, bytes(rgba), transparent)

    @staticmethod
    def _unfilter(filter_type: int, raw: bytearray, prev: bytearray, bpp: int) -> bytearray:
        out = bytearray(len(raw))
        for i, value in enumerate(raw):
            a = out[i-bpp] if i >= bpp else 0
            b = prev[i] if i < len(prev) else 0
            c = prev[i-bpp] if i >= bpp and i-bpp < len(prev) else 0
            if filter_type == 0:
                out[i] = value
            elif filter_type == 1:
                out[i] = (value + a) & 0xFF
            elif filter_type == 2:
                out[i] = (value + b) & 0xFF
            elif filter_type == 3:
                out[i] = (value + ((a + b) >> 1)) & 0xFF
            elif filter_type == 4:
                out[i] = (value + PngDecoder._paeth(a, b, c)) & 0xFF
            else:
                raise PngDecodeError(f"unsupported filter type {filter_type}")
        return out

    @staticmethod
    def _paeth(a: int, b: int, c: int) -> int:
        p = a + b - c
        pa, pb, pc = abs(p-a), abs(p-b), abs(p-c)
        if pa <= pb and pa <= pc:
            return a
        return b if pb <= pc else c


class WAFProfileConfig:
    """Load ranked WAF profiles from JSON or a tiny YAML subset."""
    @staticmethod
    def load(path: pathlib.Path) -> tuple[dict[str, Any], str | None]:
        try:
            text = pathlib.Path(path).read_text(encoding="utf-8")
        except Exception as exc:
            return dict(RankedWAFProfileDetector.DEFAULT_PROFILES), f"load error: {type(exc).__name__}: {str(exc)[:200]}"
        try:
            if str(path).endswith(".json"):
                value = json.loads(text)
            else:
                value = WAFProfileConfig._parse_simple_yaml(text)
            if not isinstance(value, dict) or not value:
                raise ValueError("profile config is empty or not an object")
            return value, None
        except Exception as exc:
            return dict(RankedWAFProfileDetector.DEFAULT_PROFILES), f"parse error: {type(exc).__name__}: {str(exc)[:200]}"

    @staticmethod
    def _parse_simple_yaml(text: str) -> dict[str, Any]:
        # Enough for profiles like:
        # cloudflare:\n  cookies: [cf_clearance]\n  headers:\n    - cf-ray
        out: dict[str, Any] = {}
        current: str | None = None
        current_key: str | None = None
        for raw in text.splitlines():
            line = raw.rstrip()
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            if not line.startswith(" ") and line.endswith(":"):
                current = line[:-1].strip()
                out[current] = {}
                current_key = None
            elif current and re.match(r"^\s+[A-Za-z_][A-Za-z0-9_-]*:\s*", line):
                key, value = line.strip().split(":", 1)
                current_key = key
                value = value.strip()
                if value.startswith("[") and value.endswith("]"):
                    out[current][key] = [v.strip().strip('"\'') for v in value[1:-1].split(",") if v.strip()]
                elif value:
                    out[current][key] = [value.strip('"\'')]
                else:
                    out[current][key] = []
            elif current and current_key and line.strip().startswith("-"):
                out[current][current_key].append(line.strip()[1:].strip().strip('"\''))
        return out


class TeamStateStore:
    SESSION_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.base = self.root / ".chimera" / "teams"

    def path_for(self, session_id: str) -> pathlib.Path:
        if not self.SESSION_ID_PATTERN.fullmatch(session_id):
            raise ValueError("invalid team session id")
        return self.base / session_id / "team.json"

    def save(self, session_id: str, team: TeamCoordinationState | Mapping[str, Any]) -> pathlib.Path:
        path = self.path_for(session_id)
        self._assert_no_symlink_escape(path.parent)
        path.parent.mkdir(parents=True, exist_ok=True)
        value = team.as_dict() if isinstance(team, TeamCoordinationState) else dict(team)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(value, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
        import os
        os.replace(tmp, path)
        return path

    def load(self, session_id: str) -> dict[str, Any]:
        path = self.path_for(session_id)
        self._assert_no_symlink_escape(path.parent)
        return json.loads(path.read_text(encoding="utf-8"))

    def _assert_no_symlink_escape(self, path: pathlib.Path) -> None:
        base = self.base.resolve()
        current = path
        parts = []
        while current != current.parent and current != base.parent:
            parts.append(current)
            current = current.parent
        for item in reversed(parts):
            if item.exists() and item.is_symlink():
                raise ValueError(f"team state path contains symlink: {item}")
        resolved_parent = path.parent.resolve() if path.parent.exists() else path.parent
        try:
            resolved_parent.relative_to(base.parent.resolve())
        except Exception as exc:
            raise ValueError("team state path escapes root") from exc


class WorktreeBindingRules:
    @staticmethod
    def validate(root: pathlib.Path, members: Sequence[Mapping[str, Any]], *, base_dir: str = "worktrees") -> dict[str, Any]:
        root = pathlib.Path(root).resolve()
        base = (root / base_dir).resolve()
        seen_paths: set[str] = set()
        seen_tasks: set[str] = set()
        findings: list[dict[str, str]] = []
        for member in members:
            name = str(member.get("name") or member.get("id") or "member")
            task = str(member.get("taskName") or member.get("focus") or name).strip().lower().replace(" ", "-")
            if not task or task in seen_tasks:
                findings.append({"member": name, "error": "duplicate or empty task identity"})
            seen_tasks.add(task)
            raw_path = member.get("worktree") or member.get("worktreePath") or (base / task)
            path = pathlib.Path(str(raw_path))
            if not path.is_absolute():
                path = root / path
            resolved = path.resolve(strict=False)
            try:
                resolved.relative_to(base)
            except ValueError:
                findings.append({"member": name, "error": "worktree path escapes worktree root"})
            key = str(resolved)
            if key in seen_paths:
                findings.append({"member": name, "error": "duplicate worktree path"})
            seen_paths.add(key)
        return {"schema_version": "chimera.worktree-binding-rules.v1", "ok": not findings, "base": str(base), "findings": findings}


# Extend SOTASkillInvariantAudit with deeper checks by monkey-patching methods
_old_sota_run = SOTASkillInvariantAudit.run

def _sota_run_with_deeper_checks(self: SOTASkillInvariantAudit) -> dict[str, Any]:
    result = _old_sota_run(self)
    findings = list(result["findings"])
    findings.extend(_mutation_watch_findings(self.root))
    findings.extend(_count_surface_findings(self.root))
    findings.extend(_last_verified_findings(self.root))
    findings.extend(_asset_freshness_findings(self.root))
    result["findings"] = findings
    result["status"] = "pass" if not [f for f in findings if f["severity"] == "error"] else "fail"
    return result


def _mutation_watch_findings(root: pathlib.Path) -> list[dict[str, Any]]:
    script = root / "scripts" / "check-invariants.sh"
    if not script.exists():
        return [{"severity": "info", "rule": "watch-it-fail-first", "path": str(script), "message": "no invariant script"}]
    text = script.read_text(encoding="utf-8", errors="replace").lower()
    if "watch it fail first" not in text and "mutation" not in text:
        return [{"severity": "warning", "rule": "watch-it-fail-first", "path": str(script), "message": "invariant script lacks mutation/watch-it-fail-first guidance"}]
    return []


def _count_surface_findings(root: pathlib.Path) -> list[dict[str, Any]]:
    skills = list((root / "skills").glob("*/SKILL.md")) if (root / "skills").exists() else []
    readme = root / "README.md"
    if not skills or not readme.exists():
        return []
    text = readme.read_text(encoding="utf-8", errors="replace")
    nums = [int(n) for n in re.findall(r"(\d+)\s+(?:domain\s+)?skills", text, flags=re.I)]
    if nums and len(set(nums + [len(skills)])) > 1:
        return [{"severity": "error", "rule": "count-bearing-surface", "path": str(readme), "message": f"README skill count {nums} does not match tree count {len(skills)}"}]
    return []


def _last_verified_findings(root: pathlib.Path) -> list[dict[str, Any]]:
    stamp = root / "LAST-VERIFIED"
    if not stamp.exists():
        return []
    changelog = root / "CHANGELOG.md"
    text = changelog.read_text(encoding="utf-8", errors="replace") if changelog.exists() else ""
    if "LAST-VERIFIED" not in text and "verified" not in text.lower():
        return [{"severity": "warning", "rule": "last-verified-sweep", "path": str(stamp), "message": "LAST-VERIFIED exists but changelog does not declare a verification sweep"}]
    return []


def _asset_freshness_findings(root: pathlib.Path) -> list[dict[str, Any]]:
    out = []
    assets = root / "assets"
    if not assets.exists():
        return out
    for html in assets.glob("*.html"):
        png = html.with_suffix(".png")
        if png.exists() and png.stat().st_mtime < html.stat().st_mtime:
            out.append({"severity": "error", "rule": "asset-render-freshness", "path": str(png), "message": f"PNG older than source HTML {html.name}"})
    return out

SOTASkillInvariantAudit.run = _sota_run_with_deeper_checks
