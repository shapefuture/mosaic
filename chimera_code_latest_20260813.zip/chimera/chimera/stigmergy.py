"""Durable evidence-backed stigmergic coordination without agent-to-agent messaging."""
from __future__ import annotations
import base64,hashlib,json,math,pathlib,sqlite3,threading,time,uuid
from typing import Any,Iterable,Literal,Mapping,Optional
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from pydantic import BaseModel,ConfigDict,Field
from .context_evidence import ContextSigner
from .wal import WAL
class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
class Deposit(FrozenModel):
    id:str;mission_id:str;region:str;agent_id:str;confidence:float;created_at:float;half_life_seconds:float;artifact_refs:tuple[str,...];metadata:dict[str,Any]=Field(default_factory=dict)
class RegionSignal(FrozenModel):
    mission_id:str;region:str;effective_signal:float;contributors:int;trusted_contributors:int;mean_trust_lcb:float;latest_at:float;artifact_refs:tuple[str,...]
class Claim(FrozenModel):
    mission_id:str;region:str;agent_id:str;lease_until:float
_SCHEMA="""
CREATE TABLE IF NOT EXISTS deposits(id TEXT PRIMARY KEY,mission_id TEXT NOT NULL,region TEXT NOT NULL,agent_id TEXT NOT NULL,confidence REAL NOT NULL,created_at REAL NOT NULL,half_life_seconds REAL NOT NULL,artifact_refs TEXT NOT NULL,metadata TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_deposits_mission_region ON deposits(mission_id,region,created_at);
CREATE TABLE IF NOT EXISTS claims(mission_id TEXT NOT NULL,region TEXT NOT NULL,agent_id TEXT NOT NULL,lease_until REAL NOT NULL,PRIMARY KEY(mission_id,region));
CREATE TABLE IF NOT EXISTS agent_trust(mission_id TEXT NOT NULL,agent_id TEXT NOT NULL,alpha REAL NOT NULL,beta REAL NOT NULL,observations INTEGER NOT NULL,PRIMARY KEY(mission_id,agent_id));
CREATE TABLE IF NOT EXISTS claim_commits(commitment TEXT PRIMARY KEY,mission_id TEXT NOT NULL,agent_id TEXT NOT NULL,reveal_after REAL NOT NULL,expires_at REAL NOT NULL,revealed INTEGER NOT NULL DEFAULT 0);
"""
class StigmergicField:
    def __init__(self,root:pathlib.Path):
        self.root=pathlib.Path(root).resolve();self.path=self.root/".chimera"/"stigmergy.sqlite";self.path.parent.mkdir(parents=True,exist_ok=True);self.db=sqlite3.connect(self.path,check_same_thread=False);self.db.executescript(_SCHEMA);self.lock=threading.RLock();self.wal=WAL(self.root)
    def close(self):self.db.close()
    def deposit(self,mission_id:str,region:str,agent_id:str,confidence:float,artifact_refs:Iterable[str],*,half_life_seconds:float=900.,metadata:Optional[dict[str,Any]]=None,now:Optional[float]=None)->Deposit:
        refs=tuple(artifact_refs)
        if not refs:raise ValueError("stigmergic deposit requires evidence refs")
        confidence=min(1.,max(0.,float(confidence)));half=max(1.,float(half_life_seconds));created=float(now if now is not None else time.time());semantic={"mission":mission_id,"region":region,"agent":agent_id,"confidence":confidence,"created_at":created,"refs":refs};deposit_id="dep-"+hashlib.sha256(json.dumps(semantic,sort_keys=True,default=str).encode()).hexdigest()[:20]
        value=Deposit(id=deposit_id,mission_id=mission_id,region=region,agent_id=agent_id,confidence=confidence,created_at=created,half_life_seconds=half,artifact_refs=refs,metadata=metadata or {})
        with self.lock,self.db:self.db.execute("INSERT OR IGNORE INTO deposits VALUES(?,?,?,?,?,?,?,?,?)",(value.id,value.mission_id,value.region,value.agent_id,value.confidence,value.created_at,value.half_life_seconds,json.dumps(value.artifact_refs),json.dumps(value.metadata,sort_keys=True,default=str)))
        self.wal.append("stigmergy_deposit",{"id":value.id,"mission_id":mission_id,"region_hash":"sha256:"+hashlib.sha256(region.encode()).hexdigest(),"agent_id":agent_id,"confidence":confidence,"evidence_root":"sha256:"+hashlib.sha256(json.dumps(sorted(refs)).encode()).hexdigest()})
        return value
    def record_outcome(self,mission_id:str,agent_id:str,accepted:bool,evidence_refs:Iterable[str])->None:
        refs=tuple(evidence_refs)
        if not refs:raise ValueError("trust update requires evidence refs")
        with self.lock,self.db:
            row=self.db.execute("SELECT alpha,beta,observations FROM agent_trust WHERE mission_id=? AND agent_id=?",(mission_id,agent_id)).fetchone();alpha,beta,count=row if row else (1.,1.,0);alpha+=1 if accepted else 0;beta+=0 if accepted else 1;count+=1
            self.db.execute("INSERT INTO agent_trust VALUES(?,?,?,?,?) ON CONFLICT(mission_id,agent_id) DO UPDATE SET alpha=excluded.alpha,beta=excluded.beta,observations=excluded.observations",(mission_id,agent_id,alpha,beta,count))
        self.wal.append("stigmergy_trust_observation",{"mission_id":mission_id,"agent_id":agent_id,"accepted":bool(accepted),"evidence_root":"sha256:"+hashlib.sha256(json.dumps(sorted(refs)).encode()).hexdigest()})
    def trust(self,mission_id:str,agent_id:str)->tuple[float,int]:
        row=self.db.execute("SELECT alpha,beta,observations FROM agent_trust WHERE mission_id=? AND agent_id=?",(mission_id,agent_id)).fetchone();alpha,beta,count=row if row else (1.,1.,0);mean=alpha/(alpha+beta);variance=alpha*beta/(((alpha+beta)**2)*(alpha+beta+1));return max(.05,mean-math.sqrt(variance)),int(count)
    def signals(self,mission_id:str,limit:int=20,*,now:Optional[float]=None,minimum_trust:float=0.)->list[RegionSignal]:
        current=float(now if now is not None else time.time());rows=self.db.execute("SELECT region,agent_id,confidence,created_at,half_life_seconds,artifact_refs FROM deposits WHERE mission_id=?",(mission_id,)).fetchall();grouped={}
        for region,agent,confidence,created,half,refs in rows:
            trust,observations=self.trust(mission_id,agent)
            if trust<minimum_trust:continue
            effective=float(confidence)*2**(-max(0.,current-float(created))/float(half))*trust;prior=grouped.setdefault(region,{})
            # One agent cannot amplify a region by depositing repeatedly; only its strongest live signal counts.
            if agent not in prior or effective>prior[agent][0]:prior[agent]=(effective,float(created),tuple(json.loads(refs)),trust,observations)
        output=[]
        for region,agents in grouped.items():
            values=[item[0] for item in agents.values()];support=math.log2(1+len(values));score=(sum(values)/len(values))*support if values else 0.;refs=tuple(dict.fromkeys(ref for item in agents.values() for ref in item[2]));latest=max(item[1] for item in agents.values());trusted=sum(item[4]>=3 for item in agents.values());mean_trust=sum(item[3] for item in agents.values())/max(1,len(agents))
            output.append(RegionSignal(mission_id=mission_id,region=region,effective_signal=score,contributors=len(values),trusted_contributors=trusted,mean_trust_lcb=mean_trust,latest_at=latest,artifact_refs=refs))
        return sorted(output,key=lambda item:(-item.effective_signal,-item.contributors,item.region))[:max(1,int(limit))]
    def claim(self,mission_id:str,region:str,agent_id:str,lease_seconds:float=30.,*,now:Optional[float]=None)->Optional[Claim]:
        current=float(now if now is not None else time.time());until=current+max(1.,float(lease_seconds))
        with self.lock,self.db:
            row=self.db.execute("SELECT agent_id,lease_until FROM claims WHERE mission_id=? AND region=?",(mission_id,region)).fetchone()
            if row and float(row[1])>current and row[0]!=agent_id:return None
            self.db.execute("INSERT INTO claims VALUES(?,?,?,?) ON CONFLICT(mission_id,region) DO UPDATE SET agent_id=excluded.agent_id,lease_until=excluded.lease_until",(mission_id,region,agent_id,until))
        return Claim(mission_id=mission_id,region=region,agent_id=agent_id,lease_until=until)
    @staticmethod
    def claim_commitment(mission_id:str,region:str,agent_id:str,nonce:str)->str:
        return "sha256:"+hashlib.sha256(json.dumps({"mission":mission_id,"region":region,"agent":agent_id,"nonce":nonce},sort_keys=True,separators=(",",":")).encode()).hexdigest()
    def commit_claim(self,mission_id:str,agent_id:str,commitment:str,*,reveal_delay_seconds:float=1.,ttl_seconds:float=60.,now:Optional[float]=None)->None:
        current=time.time() if now is None else float(now)
        if not commitment.startswith("sha256:") or len(commitment)!=71:raise ValueError("claim commitment must be sha256")
        with self.lock,self.db:self.db.execute("INSERT INTO claim_commits VALUES(?,?,?,?,?,0)",(commitment,mission_id,agent_id,current+max(0.,reveal_delay_seconds),current+max(1.,ttl_seconds)))
        self.wal.append("stigmergy_claim_committed",{"mission_id":mission_id,"agent_id":agent_id,"commitment":commitment,"reveal_after":current+max(0.,reveal_delay_seconds)})
    def reveal_claim(self,mission_id:str,region:str,agent_id:str,nonce:str,*,lease_seconds:float=30.,now:Optional[float]=None)->Optional[Claim]:
        current=time.time() if now is None else float(now);commitment=self.claim_commitment(mission_id,region,agent_id,nonce);row=self.db.execute("SELECT mission_id,agent_id,reveal_after,expires_at,revealed FROM claim_commits WHERE commitment=?",(commitment,)).fetchone()
        if not row or row[0]!=mission_id or row[1]!=agent_id or row[4] or current<row[2] or current>row[3]:return None
        claim=self.claim(mission_id,region,agent_id,lease_seconds,now=current)
        if claim:
            with self.lock,self.db:self.db.execute("UPDATE claim_commits SET revealed=1 WHERE commitment=? AND revealed=0",(commitment,))
            self.wal.append("stigmergy_claim_revealed",{"mission_id":mission_id,"region_hash":"sha256:"+hashlib.sha256(region.encode()).hexdigest(),"agent_id":agent_id,"commitment":commitment})
        return claim
    def convergence(self,mission_id:str,active_agents:int,*,window_seconds:float=60.,threshold:float=.1,min_deposits:int=2,now:Optional[float]=None)->dict[str,Any]:
        current=float(now if now is not None else time.time());count=int(self.db.execute("SELECT COUNT(*) FROM deposits WHERE mission_id=?",(mission_id,)).fetchone()[0]);recent=int(self.db.execute("SELECT COUNT(*) FROM deposits WHERE mission_id=? AND created_at>=?",(mission_id,current-max(1.,window_seconds))).fetchone()[0]);rate=recent/max(1,int(active_agents));return {"converged":count>=min_deposits and rate<float(threshold),"total_deposits":count,"recent_deposits":recent,"active_agents":max(0,int(active_agents)),"deposit_rate_per_agent":rate,"threshold":float(threshold)}
    def prune_evaporated(self,minimum_signal:float=.001,*,now:Optional[float]=None)->int:
        current=float(now if now is not None else time.time());rows=self.db.execute("SELECT id,confidence,created_at,half_life_seconds FROM deposits").fetchall();doomed=[row[0] for row in rows if float(row[1])*2**(-max(0.,current-float(row[2]))/float(row[3]))<minimum_signal]
        with self.lock,self.db:self.db.executemany("DELETE FROM deposits WHERE id=?",((item,) for item in doomed))
        return len(doomed)

class FederatedSignal(FrozenModel):
    origin_node:str;scope:Literal["team","public"];valid_until:float;signal:RegionSignal;key_id:str;public_key:str;signature:str
    def unsigned(self):return self.model_dump(mode="json",exclude={"signature"})
    def verify(self)->bool:
        try:
            public=base64.b64decode(self.public_key,validate=True)
            if "ed25519:"+hashlib.sha256(public).hexdigest()!=self.key_id:return False
            Ed25519PublicKey.from_public_bytes(public).verify(base64.b64decode(self.signature,validate=True),json.dumps(self.unsigned(),sort_keys=True,separators=(",",":"),default=str).encode());return True
        except (ValueError,InvalidSignature):return False
class StigmergyFederation:
    """Transport-neutral signed signal replication; private traces cannot enter it."""
    def __init__(self,field:StigmergicField,node_id:str,signer:ContextSigner,trusted_keys:Mapping[str,str]):self.field=field;self.node_id=node_id;self.signer=signer;self.trusted=dict(trusted_keys)
    def export(self,signal:RegionSignal,scope:Literal["team","public"],valid_until:float)->FederatedSignal:
        if valid_until<=time.time():raise ValueError("federated signal already expired")
        unsigned={"origin_node":self.node_id,"scope":scope,"valid_until":float(valid_until),"signal":signal.model_dump(mode="json"),"key_id":self.signer.key_id,"public_key":self.signer.public_key};signature=self.signer.sign(json.dumps(unsigned,sort_keys=True,separators=(",",":"),default=str).encode());return FederatedSignal(**unsigned,signature=signature)
    def ingest(self,envelope:FederatedSignal)->bool:
        if envelope.valid_until<=time.time() or not envelope.verify():return False
        if self.trusted.get(envelope.origin_node)!=envelope.public_key:return False
        self.field.deposit(envelope.signal.mission_id,envelope.signal.region,f"peer:{envelope.origin_node}",min(1.,envelope.signal.effective_signal),envelope.signal.artifact_refs,half_life_seconds=max(1.,envelope.valid_until-time.time()),metadata={"federated":True,"scope":envelope.scope,"origin":envelope.origin_node})
        return True
