"""Read-only advisory checker port bound to transcript-minimized briefs.

Checker output is deliberately non-authoritative.  It may surface bounded
findings with evidence references, but cannot commit, merge, promote, grant
capabilities, or override deterministic quality/held-out gates.
"""
from __future__ import annotations

import json
import pathlib
import time
import uuid
from typing import Callable, Literal, Protocol

from pydantic import BaseModel, ConfigDict, Field

from .artifacts import ContentAddressedArtifactStore
from .verification_brief import IndependentVerificationBrief
from .wal import WAL


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class CheckerRequest(_FrozenModel):
    brief_ref: str
    brief_hash: str
    branch: str
    diff_id: str
    read_only: bool = True
    merge_authority: bool = False
    promotion_authority: bool = False


class CheckerFinding(_FrozenModel):
    severity: Literal["info", "warning", "error"]
    path: str | None = None
    message: str = Field(min_length=1, max_length=1_000)
    evidence_refs: tuple[str, ...] = ()


class CheckerReview(_FrozenModel):
    checker_id: str
    findings: tuple[CheckerFinding, ...] = ()
    summary: str = Field(default="", max_length=1_000)
    advisory_only: bool = True
    merge_authority: bool = False
    promotion_authority: bool = False


class IndependentCheckerPort(Protocol):
    def review(self, request: CheckerRequest) -> CheckerReview: ...


class CallableIndependentCheckerPort:
    def __init__(self, invoke: Callable[[CheckerRequest], CheckerReview]):
        self._invoke = invoke

    def review(self, request: CheckerRequest) -> CheckerReview:
        value = self._invoke(request)
        if not isinstance(value, CheckerReview):
            raise TypeError("checker port must return CheckerReview")
        return value


class CheckerReviewLedger:
    """Persist bounded advisory findings after validating the fact-only brief."""

    def __init__(self, root: pathlib.Path, *, artifacts: ContentAddressedArtifactStore | None = None):
        self.root = pathlib.Path(root).resolve()
        self.artifacts = artifacts or ContentAddressedArtifactStore(self.root)
        self.wal = WAL(self.root)

    def request_for(self, brief_ref: str) -> CheckerRequest:
        raw = self.artifacts.get(brief_ref)
        brief = IndependentVerificationBrief.model_validate_json(raw)
        return CheckerRequest(
            brief_ref=brief_ref,
            brief_hash=brief.brief_hash,
            branch=brief.branch,
            diff_id=brief.diff_id,
        )

    def run(self, port: IndependentCheckerPort, request: CheckerRequest) -> CheckerReview:
        if not request.read_only or request.merge_authority or request.promotion_authority:
            raise PermissionError("independent checker requests are strictly read-only and advisory")
        verified = self.request_for(request.brief_ref)
        if verified.brief_hash != request.brief_hash or verified.branch != request.branch or verified.diff_id != request.diff_id:
            raise ValueError("checker request does not match its persisted verification brief")
        review = port.review(request)
        if not review.advisory_only or review.merge_authority or review.promotion_authority:
            raise PermissionError("checker review attempted to claim authority")
        # Persist only bounded structured findings, not a raw model transcript.
        payload = {
            "review_id": "checker-review:" + uuid.uuid4().hex,
            "brief_ref": request.brief_ref,
            "brief_hash": request.brief_hash,
            "branch": request.branch,
            "diff_id": request.diff_id,
            "checker_id": review.checker_id,
            "findings": [item.model_dump(mode="json") for item in review.findings],
            "summary": review.summary,
            "advisory_only": True,
            "merge_authority": False,
            "promotion_authority": False,
            "created_at": time.time(),
        }
        self.wal.append("independent_checker_review", payload)
        return review
