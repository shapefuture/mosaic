"""PostgreSQL content-addressed artifact store for multi-node durable adapters."""
from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping

from .artifacts import ArtifactIntegrityError, ArtifactRef


class PostgresContentAddressedArtifactStore:
    """Immutable CAS rows shared by DBOS/Restate executors."""

    def __init__(self, database_url: str, *, schema: str = "public") -> None:
        from sqlalchemy import create_engine
        if not schema.replace("_", "").isalnum():
            raise ValueError("artifact schema must be an identifier")
        self.engine = create_engine(database_url, pool_pre_ping=True)
        self.table = f'"{schema}".chimera_artifacts'
        with self.engine.begin() as connection:
            connection.exec_driver_sql(f"""CREATE TABLE IF NOT EXISTS {self.table} (
                digest text PRIMARY KEY,
                data bytea NOT NULL,
                media_type text NOT NULL,
                provenance_json text NOT NULL,
                provenance_digest text NOT NULL
            )""")

    @staticmethod
    def _digest(data: bytes) -> str:
        return "sha256:" + hashlib.sha256(data).hexdigest()

    @staticmethod
    def _provenance(value: Mapping[str, Any]) -> tuple[str, str]:
        text=json.dumps(dict(value),sort_keys=True,separators=(",", ":"),default=str)
        return text,"sha256:"+hashlib.sha256(text.encode()).hexdigest()

    def put(self, data: bytes | str, *, media_type: str="application/octet-stream", provenance: Mapping[str,Any] | None=None) -> ArtifactRef:
        raw=data.encode() if isinstance(data,str) else data
        if not isinstance(raw,bytes):raise TypeError("artifact content must be bytes or str")
        digest=self._digest(raw);provenance_json,provenance_digest=self._provenance(provenance or {})
        with self.engine.begin() as connection:
            connection.exec_driver_sql(
                f"INSERT INTO {self.table} (digest,data,media_type,provenance_json,provenance_digest) VALUES (%s,%s,%s,%s,%s) ON CONFLICT (digest) DO NOTHING",
                (digest,raw,media_type,provenance_json,provenance_digest),
            )
            row=connection.exec_driver_sql(f"SELECT data,media_type,provenance_digest FROM {self.table} WHERE digest=%s",(digest,)).first()
        if row is None or self._digest(bytes(row[0]))!=digest:raise ArtifactIntegrityError(f"shared artifact is corrupt: {digest}")
        return ArtifactRef(digest=digest,size=len(raw),media_type=str(row[1]),provenance_digest=str(row[2]))

    def get(self,digest:str)->bytes:
        with self.engine.connect() as connection:row=connection.exec_driver_sql(f"SELECT data FROM {self.table} WHERE digest=%s",(digest,)).first()
        if row is None:raise FileNotFoundError(digest)
        data=bytes(row[0]);actual=self._digest(data)
        if actual!=digest:raise ArtifactIntegrityError(f"shared artifact hash mismatch: {digest}")
        return data

    def has(self,digest:str)->bool:
        try:self.get(digest);return True
        except FileNotFoundError:return False

    def close(self)->None:self.engine.dispose()
