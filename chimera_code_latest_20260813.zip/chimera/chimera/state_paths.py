"""Cloud-ready state directory resolver."""
from __future__ import annotations
import os, pathlib, uuid
from dataclasses import dataclass, asdict

@dataclass(frozen=True)
class ChimeraStatePaths:
    root: pathlib.Path
    state_dir: pathlib.Path
    session_id: str
    def as_dict(self): return {k:str(v) for k,v in asdict(self).items()}

def resolve_state_paths(root: pathlib.Path | str='.') -> ChimeraStatePaths:
    root=pathlib.Path(root).resolve()
    session=os.environ.get('CHIMERA_SESSION_ID') or ('session-'+uuid.uuid4().hex[:12])
    state=pathlib.Path(os.environ.get('CHIMERA_STATE_DIR') or str(root/'.chimera')).resolve()
    state.mkdir(parents=True,exist_ok=True)
    return ChimeraStatePaths(root,state,session)
