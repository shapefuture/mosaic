"""Durable, privacy-minimal run/request/action lifecycle receipts.

This is Chimera's small deterministic transfer of the useful protocol insight
from the supplied Warp analysis: a conversation, one execution run, and an
individual model request must not share a single ambiguous identifier.  Model
or tool output is never persisted here; WAL rows contain opaque IDs, hashes,
typed state transitions, and bounded outcome metadata only.

The ledger is evidence/observability, not merge authority. Existing task
contracts, action IR, capability checks, transactional branches, and tests stay
authoritative.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
import hashlib
import json
import pathlib
import threading
import time
import uuid
from typing import Any, Mapping

from .wal import WAL
from .run_types import ActionState


class RunTerminal(StrEnum):
    DONE = "done"
    MAX_TURNS = "max_turns"
    BUDGET = "budget"
    CONTEXT_LIMIT = "context_limit"
    PROVIDER_UNAVAILABLE = "provider_unavailable"
    INVALID_CREDENTIAL = "invalid_credential"
    INTERNAL_ERROR = "internal_error"
    CANCELLED = "cancelled"


_TERMINAL_ACTIONS = frozenset({ActionState.COMPLETED, ActionState.FAILED, ActionState.REJECTED, ActionState.CANCELLED})
_ALLOWED = {
    ActionState.PROPOSED: frozenset({ActionState.ACCEPTED, ActionState.REJECTED, ActionState.CANCELLED}),
    ActionState.ACCEPTED: frozenset({ActionState.STARTED, ActionState.REJECTED, ActionState.CANCELLED}),
    ActionState.STARTED: frozenset({ActionState.COMPLETED, ActionState.FAILED, ActionState.CANCELLED}),
}


@dataclass(frozen=True)
class RunIdentity:
    conversation_id: str
    run_id: str


@dataclass(frozen=True)
class RequestIdentity:
    conversation_id: str
    run_id: str
    request_id: str
    ordinal: int


class RunLifecycleLedger:
    """Append-only lifecycle journal with transition validation and summaries."""

    def __init__(self, root: pathlib.Path) -> None:
        self.wal = WAL(pathlib.Path(root))
        self._actions: dict[tuple[str, str], ActionState] = {}
        self._requests: dict[str, int] = {}
        self._lock = threading.RLock()

    @staticmethod
    def _hash(value: Any) -> str:
        raw = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    @staticmethod
    def _opaque_conversation(value: str) -> str:
        return "conversation:" + hashlib.sha256(str(value).encode()).hexdigest()[:24]

    def begin_run(self, conversation: str, *, task: str, source: str = "rlm") -> RunIdentity:
        identity = RunIdentity(
            conversation_id=self._opaque_conversation(conversation),
            run_id="run:" + uuid.uuid4().hex,
        )
        self.wal.append("run_lifecycle", {
            "event": "stream_init", "conversation_id": identity.conversation_id,
            "run_id": identity.run_id, "source": str(source),
            "task_hash": self._hash(task),
        })
        return identity

    def begin_request(self, run: RunIdentity, *, model: str) -> RequestIdentity:
        with self._lock:
            ordinal = self._requests.get(run.run_id, 0) + 1
            self._requests[run.run_id] = ordinal
        request = RequestIdentity(
            conversation_id=run.conversation_id, run_id=run.run_id,
            request_id="request:" + uuid.uuid4().hex, ordinal=ordinal,
        )
        self.wal.append("run_lifecycle", {
            "event": "request_started", **request.__dict__, "model": str(model),
        })
        return request

    def action(
        self,
        request: RequestIdentity,
        *,
        action_id: str,
        kind: str,
        state: ActionState,
        arguments: Mapping[str, Any] | None = None,
        outcome: Mapping[str, Any] | None = None,
        reason: str | None = None,
    ) -> None:
        key = (request.run_id, str(action_id))
        with self._lock:
            prior = self._actions.get(key)
            if prior is None:
                if state is not ActionState.PROPOSED:
                    raise ValueError("first action lifecycle state must be proposed")
            elif prior in _TERMINAL_ACTIONS:
                raise ValueError(f"action {action_id!r} is already terminal ({prior.value})")
            elif state not in _ALLOWED.get(prior, frozenset()):
                raise ValueError(f"invalid action lifecycle transition {prior.value}->{state.value}")
            self._actions[key] = state
        row: dict[str, Any] = {
            "event": "client_action", **request.__dict__, "action_id": str(action_id),
            "kind": str(kind), "state": state.value,
        }
        if arguments is not None:
            row["arguments_hash"] = self._hash(dict(arguments))
        if outcome is not None:
            # Results may contain tool text/secrets. Persist only a digest plus
            # the typed fields needed to measure success/partial failure.
            row["outcome_hash"] = self._hash(dict(outcome))
            row["ok"] = bool(outcome.get("ok"))
            row["tool"] = str(outcome.get("tool", kind))
        if reason:
            row["reason_class"] = str(reason)[:120]
        self.wal.append("run_lifecycle", row)

    def finish(self, run: RunIdentity, terminal: RunTerminal, *, detail: str = "") -> None:
        self.wal.append("run_lifecycle", {
            "event": "stream_finished", **run.__dict__, "terminal": terminal.value,
            "detail_hash": self._hash(detail),
        })

    def projection(self, run_id: str):
        # Local import avoids a reducer/lifecycle import cycle while keeping the
        # reducer strictly a shadow observer during the migration.
        from .run_reducer import RunEventReducer
        return RunEventReducer.reduce(self.wal.replay(kind="run_lifecycle"), run_id=run_id)

    def summary(self, run_id: str) -> dict[str, Any]:
        rows = [entry["data"] for entry in self.wal.replay(kind="run_lifecycle") if entry.get("data", {}).get("run_id") == run_id]
        states: dict[str, int] = {state.value: 0 for state in ActionState}
        by_kind: dict[str, dict[str, int]] = {}
        requests = 0
        terminal: str | None = None
        for row in rows:
            if row.get("event") == "request_started":
                requests += 1
            elif row.get("event") == "client_action":
                state = str(row.get("state", ""))
                if state in states:
                    states[state] += 1
                kind = str(row.get("kind", "unknown"))
                by_kind.setdefault(kind, {}).setdefault(state, 0)
                by_kind[kind][state] += 1
            elif row.get("event") == "stream_finished":
                terminal = str(row.get("terminal"))
        return {
            "run_id": run_id, "requests": requests, "action_states": states,
            "by_kind": by_kind, "terminal": terminal,
        }
