"""Redacted provider capability/QoS/cancellation status report."""
from __future__ import annotations

import os
import pathlib
import time
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .provider_capabilities import ProviderCapabilities
from .provider_state import ProviderStateRegistry
from .providers import PROVIDERS, ProviderCatalog
from .wal import WAL


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ProviderReportRow(_Frozen):
    id: str
    implemented: bool
    protocol: str | None
    configured: bool
    configured_env_names: tuple[str, ...]
    credential_slots: int
    openai_compatible: bool
    capability_manifest: dict[str, bool]
    proved_capabilities: dict[str, bool]
    qos: dict[str, Any]
    reliability: dict[str, Any]
    route_penalty: float
    canary_proofs: int = 0
    cancellation_canaries: int = 0
    billing_reservations: int = 0
    unresolved_billing_exposure_microusd: int = 0
    state: str


class ProviderSystemReport(_Frozen):
    schema_version: str = "chimera.provider-system-report.v1"
    generated_at: float = Field(default_factory=time.time)
    root: str
    redaction: str = "credential values are never included; only env-var names and slot counts are reported"
    rows: tuple[ProviderReportRow, ...]
    summary: dict[str, int]
    operator_notes: tuple[str, ...] = (
        "configured only means a credential-shaped environment variable is present; it is not a live-call proof.",
        "proved_capabilities come only from artifact-backed canary WAL entries and expire via ProviderCapabilityRegistry TTL.",
        "local cancellation does not prove provider-side billing termination; unresolved exposure remains reserved until authoritative receipts arrive.",
    )


_MANIFEST_BY_PROTOCOL: dict[str, dict[str, bool]] = {
    "openai-compatible-chat": {
        "streaming": True,
        "native_tools": True,
        "strict_json": True,
        "prompt_cache": False,
        "terminal_cancellation_proven": False,
        "idempotent_request_replay_proven": False,
        "local": False,
    },
    "openai-chat": {
        "streaming": True,
        "native_tools": True,
        "strict_json": True,
        "prompt_cache": False,
        "terminal_cancellation_proven": False,
        "idempotent_request_replay_proven": False,
        "local": False,
    },
    "anthropic-messages": {
        "streaming": True,
        "native_tools": True,
        "strict_json": False,
        "prompt_cache": True,
        "terminal_cancellation_proven": False,
        "idempotent_request_replay_proven": False,
        "local": False,
    },
    "gemini-generate-content": {
        "streaming": False,
        "native_tools": False,
        "strict_json": False,
        "prompt_cache": False,
        "terminal_cancellation_proven": False,
        "idempotent_request_replay_proven": False,
        "local": False,
    },
    "ollama-generate": {
        "streaming": False,
        "native_tools": False,
        "strict_json": False,
        "prompt_cache": False,
        "terminal_cancellation_proven": False,
        "idempotent_request_replay_proven": False,
        "local": True,
    },
}


def _credential_names(spec_id: str) -> tuple[str, ...]:
    spec = PROVIDERS[spec_id]
    return tuple(key for key in spec.env_keys if os.environ.get(key))


def _proof_counts(root: pathlib.Path) -> dict[str, dict[str, int]]:
    result: dict[str, dict[str, int]] = {}
    wal = WAL(root)
    for entry in wal.replay(kind="provider_capability_proof"):
        data = entry.get("data", {})
        provider = str(data.get("provider", "unknown"))
        result.setdefault(provider, {}).setdefault("canary_proofs", 0)
        result[provider]["canary_proofs"] += 1
    for entry in wal.replay(kind="provider_cancellation_canary"):
        data = entry.get("data", {})
        provider = str(data.get("provider", data.get("route", "unknown")))
        result.setdefault(provider, {}).setdefault("cancellation_canaries", 0)
        result[provider]["cancellation_canaries"] += 1
    return result


def _billing_counts(root: pathlib.Path) -> dict[str, dict[str, int]]:
    result: dict[str, dict[str, int]] = {}
    states: dict[str, dict[str, Any]] = {}
    for entry in WAL(root).replay(kind="provider_billing"):
        data = entry.get("data", {})
        request_id = str(data.get("request_id", ""))
        if not request_id:
            continue
        action = data.get("action")
        if action == "reserve":
            states[request_id] = {
                "provider": str(data.get("provider", "unknown")),
                "max_cost_microusd": int(data.get("max_cost_microusd", 0) or 0),
                "reconciliation_required": True,
            }
        elif action == "local_cancel" and request_id in states:
            states[request_id]["reconciliation_required"] = True
        elif action == "reconcile" and request_id in states:
            states[request_id]["reconciliation_required"] = False
    for state in states.values():
        provider = str(state.get("provider", "unknown"))
        bucket = result.setdefault(provider, {"billing_reservations": 0, "unresolved_billing_exposure_microusd": 0})
        bucket["billing_reservations"] += 1
        if state.get("reconciliation_required"):
            bucket["unresolved_billing_exposure_microusd"] += int(state.get("max_cost_microusd", 0) or 0)
    return result


class ProviderSystemReporter:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.catalog = ProviderCatalog()
        self.state = ProviderStateRegistry(self.root)

    def build(self, *, model: str = "*") -> ProviderSystemReport:
        proof_counts = _proof_counts(self.root)
        billing_counts = _billing_counts(self.root)
        rows: list[ProviderReportRow] = []
        for spec in self.catalog.list():
            names = _credential_names(spec.id)
            credentials = self.catalog.credentials(spec.id)
            profile = self.state.profile(spec.id, model)
            manifest = dict(_MANIFEST_BY_PROTOCOL.get(spec.protocol or "", {}))
            if not manifest:
                manifest = {name: False for name in (
                    "streaming", "native_tools", "strict_json", "prompt_cache",
                    "terminal_cancellation_proven", "idempotent_request_replay_proven", "local",
                )}
            proved = ProviderCapabilities(**profile.capabilities)
            counts = proof_counts.get(spec.id, {})
            billing = billing_counts.get(spec.id, {})
            if spec.implemented and names:
                state = "configured-needs-canary" if not proved.enabled() else "configured-with-proofs"
            elif spec.implemented:
                state = "implemented-unconfigured"
            else:
                state = "not-implemented"
            rows.append(ProviderReportRow(
                id=spec.id,
                implemented=bool(spec.implemented),
                protocol=spec.protocol,
                configured=bool(names),
                configured_env_names=names,
                credential_slots=len(credentials),
                openai_compatible=bool(spec.openai_compatible),
                capability_manifest=manifest,
                proved_capabilities={name: getattr(proved, name) for name in proved.names()},
                qos=profile.qos,
                reliability=profile.reliability,
                route_penalty=profile.route_penalty,
                canary_proofs=int(counts.get("canary_proofs", 0)),
                cancellation_canaries=int(counts.get("cancellation_canaries", 0)),
                billing_reservations=int(billing.get("billing_reservations", 0)),
                unresolved_billing_exposure_microusd=int(billing.get("unresolved_billing_exposure_microusd", 0)),
                state=state,
            ))
        summary = {
            "providers": len(rows),
            "implemented": sum(row.implemented for row in rows),
            "configured": sum(row.configured for row in rows),
            "with_canary_proofs": sum(row.canary_proofs > 0 for row in rows),
            "with_unresolved_billing_exposure": sum(row.unresolved_billing_exposure_microusd > 0 for row in rows),
        }
        return ProviderSystemReport(root=str(self.root), rows=tuple(rows), summary=summary)
