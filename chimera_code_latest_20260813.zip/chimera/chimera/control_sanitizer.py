"""Terminal/control character sanitizer for model-visible observations."""
from __future__ import annotations
import re
from dataclasses import dataclass, asdict

ANSI_CSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
ANSI_OSC = re.compile(r"\x1b\].*?(?:\x07|\x1b\\)", re.S)
BIDI_ZERO = re.compile("[\u202a-\u202e\u2066-\u2069\u200b\u200c\u200d\ufeff]")

@dataclass(frozen=True)
class SanitizedText:
    text: str
    removed: int
    def as_dict(self): return asdict(self)

def sanitize_controls(text: str) -> SanitizedText:
    value=str(text or "")
    before=len(value)
    value=ANSI_OSC.sub("", value)
    value=ANSI_CSI.sub("", value)
    value=BIDI_ZERO.sub("", value)
    value="".join(ch for ch in value if ch in "\t\n\r" or ord(ch) >= 32)
    return SanitizedText(value, before-len(value))
