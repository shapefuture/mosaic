"""Segmented context-window accounting without retaining model input text.

Provider billed usage arrives after a request and often lacks a breakdown of
which part of a prompt consumed the context window.  This ledger records a
privacy-minimal *preflight estimate* by the stable categories that appear in
provider APIs and the supplied Warp protocol analysis: system prompt, tool
definitions, conversation history, latest input, images, and other.

It is an optimization diagnostic only.  It never truncates, routes a model, or
claims billed/provider-exact token counts.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import StrEnum
import hashlib
import json
import pathlib
from typing import Any, Mapping

from .context_window import ContextWindowPolicy
from .wal import WAL


class ContextSegmentType(StrEnum):
    SYSTEM_PROMPT = "system_prompt"
    TOOL_DEFINITIONS = "tool_definitions"
    CONVERSATION_HISTORY = "conversation_history"
    LATEST_INPUT = "latest_input"
    IMAGES = "images"
    OTHER = "other"


@dataclass(frozen=True)
class ContextSegment:
    segment_type: str
    content_hash: str
    bytes: int
    estimated_tokens: int


@dataclass(frozen=True)
class ContextSegmentReceipt:
    session: str
    request_id: str
    model: str
    window_tokens: int
    window_source: str
    total_estimated_tokens: int
    segments: tuple[ContextSegment, ...]
    dominant_segment: str | None
    dominant_fraction: float
    guidance: str | None

    def as_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["segments"] = [asdict(item) for item in self.segments]
        return value


class ContextSegmentLedger:
    def __init__(self, root: pathlib.Path) -> None:
        self.wal = WAL(pathlib.Path(root))

    @staticmethod
    def _hash(value: Any) -> str:
        text = value if isinstance(value, str) else json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)
        return "sha256:" + hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()

    @staticmethod
    def _estimate(value: Any) -> tuple[int, int, str]:
        text = value if isinstance(value, str) else json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)
        raw = text.encode("utf-8", errors="replace")
        return len(raw), max(0, (len(raw) + 3) // 4), text

    @staticmethod
    def _guidance(dominant: str | None, fraction: float) -> str | None:
        if dominant is None or fraction < 0.40:
            return None
        return {
            ContextSegmentType.TOOL_DEFINITIONS.value: "tool definitions dominate; prefer deferred discovery or a smaller typed tool surface",
            ContextSegmentType.CONVERSATION_HISTORY.value: "conversation history dominates; consider evidence-preserving compaction or artifact rehydration",
            ContextSegmentType.LATEST_INPUT.value: "latest input dominates; narrow attachments or materialize references only after selection",
            ContextSegmentType.SYSTEM_PROMPT.value: "system prompt dominates; keep stable policy separate from task-specific context and inspect prefix-cache shape",
            ContextSegmentType.IMAGES.value: "image context dominates; use bounded image evidence and retain snapshot provenance",
            ContextSegmentType.OTHER.value: "other context dominates; inspect typed context-pack provenance before increasing the context budget",
        }.get(dominant)

    def record(
        self,
        *,
        session: str,
        request_id: str,
        model: str,
        segments: Mapping[str | ContextSegmentType, Any],
        fallback_window_tokens: int,
    ) -> ContextSegmentReceipt:
        window, source = ContextWindowPolicy.resolve(model, fallback_window_tokens)
        rows: list[ContextSegment] = []
        for kind, value in segments.items():
            name = str(kind)
            if value in (None, "", (), [], {}):
                continue
            size, tokens, rendered = self._estimate(value)
            rows.append(ContextSegment(name, self._hash(rendered), size, tokens))
        total = sum(row.estimated_tokens for row in rows)
        largest = max(rows, key=lambda row: row.estimated_tokens, default=None)
        fraction = (largest.estimated_tokens / total) if largest and total else 0.0
        dominant = largest.segment_type if largest else None
        receipt = ContextSegmentReceipt(
            session=str(session), request_id=str(request_id), model=str(model),
            window_tokens=window, window_source=source, total_estimated_tokens=total,
            segments=tuple(rows), dominant_segment=dominant,
            dominant_fraction=round(fraction, 6), guidance=self._guidance(dominant, fraction),
        )
        self.wal.append("context_window_segments", receipt.as_dict())
        return receipt
