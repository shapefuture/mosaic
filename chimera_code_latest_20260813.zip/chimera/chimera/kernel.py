"""Bounded persistent read-only Python-like kernel for model experimentation.

This is deliberately not ``exec``/IPython.  A small AST interpreter supports
pure data operations and four typed host functions.  Imports, attributes,
loops, function definitions, filesystem builtins, subprocesses, and network
access are unrepresentable.  Host I/O is supplied by Chimera and therefore
still passes through ActionIR and capability checks.
"""
from __future__ import annotations

import ast
import json
from dataclasses import dataclass
from typing import Any, Callable


class KernelPolicyError(ValueError):
    """Code is outside the bounded read-only language."""


@dataclass(frozen=True)
class KernelResult:
    output: Any
    variables: dict[str, dict[str, Any]]
    host_results: tuple[dict[str, Any], ...]
    statements: int

    def evidence(self) -> dict[str, Any]:
        return {
            "output": self.output,
            "variables": self.variables,
            "host_results": list(self.host_results),
            "statements": self.statements,
        }


HostCall = Callable[[dict[str, Any]], dict[str, Any]]


class PersistentReadOnlyKernel:
    MAX_CODE_CHARS = 8_000
    MAX_STATEMENTS = 32
    MAX_STATE_BYTES = 100_000
    MAX_COLLECTION = 2_000

    def __init__(self) -> None:
        self._values: dict[str, Any] = {}

    @staticmethod
    def _safe_name(name: str) -> None:
        if name.startswith("_") or not name.isidentifier():
            raise KernelPolicyError(f"unsafe variable/function name: {name!r}")

    @staticmethod
    def _bounded(value: Any) -> Any:
        try:
            encoded = json.dumps(value, default=str)
        except (TypeError, ValueError) as exc:
            raise KernelPolicyError(f"value is not JSON-serializable: {exc}") from exc
        if len(encoded.encode()) > PersistentReadOnlyKernel.MAX_STATE_BYTES:
            raise KernelPolicyError("kernel value exceeds state budget")
        return value

    @staticmethod
    def _arguments(node: ast.Call, evaluate: Callable[[ast.AST], Any]) -> tuple[list[Any], dict[str, Any]]:
        args = [evaluate(arg) for arg in node.args]
        kwargs: dict[str, Any] = {}
        for keyword in node.keywords:
            if keyword.arg is None:
                raise KernelPolicyError("**kwargs expansion is not allowed")
            kwargs[keyword.arg] = evaluate(keyword.value)
        return args, kwargs

    def _host(self, name: str, args: list[Any], kwargs: dict[str, Any], host_call: HostCall) -> tuple[Any, dict[str, Any]]:
        if name == "read":
            if not args or len(args) > 3:
                raise KernelPolicyError("read(path[, start, end]) expected")
            arguments = {"path": args[0]}
            if len(args) > 1:
                arguments["start"] = args[1]
            if len(args) > 2:
                arguments["end"] = args[2]
            arguments.update(kwargs)
            call = {"name": "read_file", "arguments": arguments}
        elif name == "list_files":
            if len(args) > 1:
                raise KernelPolicyError("list_files([pattern]) expected")
            arguments = {"pattern": args[0]} if args else {}
            arguments.update(kwargs)
            call = {"name": "list_files", "arguments": arguments}
        elif name == "graph":
            if len(args) != 1 or kwargs:
                raise KernelPolicyError("graph(query) expected")
            call = {"name": "graph_query", "arguments": {"query": args[0]}}
        elif name == "artifact":
            if not args or len(args) > 3:
                raise KernelPolicyError("artifact(digest[, start, end]) expected")
            arguments = {"digest": args[0]}
            if len(args) > 1:
                arguments["start"] = args[1]
            if len(args) > 2:
                arguments["end"] = args[2]
            arguments.update(kwargs)
            call = {"name": "artifact_read", "arguments": arguments}
        else:
            raise KernelPolicyError(f"unknown host function: {name}")
        result = host_call(call)
        if not result.get("ok"):
            raise KernelPolicyError(f"host call {name} failed: {result.get('error', 'unknown error')}")
        if name in {"read", "artifact"}:
            return result.get("content", ""), result
        if name == "list_files":
            return result.get("files", []), result
        return result.get("hits", []), result

    def execute(self, code: str, host_call: HostCall) -> KernelResult:
        if not isinstance(code, str) or not code.strip():
            raise KernelPolicyError("kernel code must be a non-empty string")
        if len(code) > self.MAX_CODE_CHARS:
            raise KernelPolicyError("kernel code exceeds character budget")
        try:
            tree = ast.parse(code, mode="exec")
        except SyntaxError as exc:
            raise KernelPolicyError(f"invalid bounded Python syntax: {exc}") from exc
        if len(tree.body) > self.MAX_STATEMENTS:
            raise KernelPolicyError("kernel statement budget exceeded")

        host_results: list[dict[str, Any]] = []

        def evaluate(node: ast.AST) -> Any:
            if isinstance(node, ast.Constant):
                if isinstance(node.value, (str, int, float, bool, type(None))):
                    return node.value
                raise KernelPolicyError(f"constant type is not allowed: {type(node.value).__name__}")
            if isinstance(node, ast.Name):
                self._safe_name(node.id)
                if node.id not in self._values:
                    raise KernelPolicyError(f"unknown variable: {node.id}")
                return self._values[node.id]
            if isinstance(node, ast.List):
                if len(node.elts) > self.MAX_COLLECTION:
                    raise KernelPolicyError("list literal exceeds collection budget")
                return [evaluate(item) for item in node.elts]
            if isinstance(node, ast.Tuple):
                if len(node.elts) > self.MAX_COLLECTION:
                    raise KernelPolicyError("tuple literal exceeds collection budget")
                return tuple(evaluate(item) for item in node.elts)
            if isinstance(node, ast.Dict):
                if len(node.keys) > self.MAX_COLLECTION:
                    raise KernelPolicyError("dict literal exceeds collection budget")
                return {evaluate(key): evaluate(value) for key, value in zip(node.keys, node.values)}
            if isinstance(node, ast.Subscript):
                value = evaluate(node.value)
                if isinstance(node.slice, ast.Slice):
                    lower = evaluate(node.slice.lower) if node.slice.lower else None
                    upper = evaluate(node.slice.upper) if node.slice.upper else None
                    step = evaluate(node.slice.step) if node.slice.step else None
                    return value[slice(lower, upper, step)]
                return value[evaluate(node.slice)]
            if isinstance(node, ast.BinOp):
                left, right = evaluate(node.left), evaluate(node.right)
                if isinstance(node.op, ast.Add):
                    return self._bounded(left + right)
                if isinstance(node.op, ast.Sub) and isinstance(left, (int, float)) and isinstance(right, (int, float)):
                    return left - right
                if isinstance(node.op, ast.Mult) and isinstance(left, (int, float)) and isinstance(right, (int, float)):
                    return left * right
                if isinstance(node.op, ast.Div) and isinstance(left, (int, float)) and isinstance(right, (int, float)):
                    return left / right
                raise KernelPolicyError("binary operation/type combination is not allowed")
            if isinstance(node, ast.UnaryOp):
                value = evaluate(node.operand)
                if isinstance(node.op, ast.Not):
                    return not value
                if isinstance(node.op, ast.USub) and isinstance(value, (int, float)):
                    return -value
                raise KernelPolicyError("unary operation is not allowed")
            if isinstance(node, ast.BoolOp):
                values = [evaluate(item) for item in node.values]
                return all(values) if isinstance(node.op, ast.And) else any(values)
            if isinstance(node, ast.Compare):
                if len(node.ops) != 1 or len(node.comparators) != 1:
                    raise KernelPolicyError("chained comparisons are not allowed")
                left, right = evaluate(node.left), evaluate(node.comparators[0])
                op = node.ops[0]
                if isinstance(op, ast.Eq): return left == right
                if isinstance(op, ast.NotEq): return left != right
                if isinstance(op, ast.In): return left in right
                if isinstance(op, ast.NotIn): return left not in right
                if isinstance(op, ast.Lt): return left < right
                if isinstance(op, ast.LtE): return left <= right
                if isinstance(op, ast.Gt): return left > right
                if isinstance(op, ast.GtE): return left >= right
                raise KernelPolicyError("comparison is not allowed")
            if isinstance(node, ast.Call):
                if not isinstance(node.func, ast.Name):
                    raise KernelPolicyError("only named safe functions may be called")
                name = node.func.id
                self._safe_name(name)
                args, kwargs = self._arguments(node, evaluate)
                if name in {"read", "list_files", "graph", "artifact"}:
                    value, receipt = self._host(name, args, kwargs, host_call)
                    host_results.append(receipt)
                    return self._bounded(value)
                if kwargs:
                    raise KernelPolicyError(f"safe function {name} does not accept keyword arguments")
                safe = {
                    "len": lambda x: len(x),
                    "sorted": lambda x: sorted(x),
                    "min": lambda x: min(x),
                    "max": lambda x: max(x),
                    "sum": lambda x: sum(x),
                    "str": lambda x: str(x),
                    "int": lambda x: int(x),
                    "float": lambda x: float(x),
                    "bool": lambda x: bool(x),
                    "lines": lambda x: str(x).splitlines(),
                    "lower": lambda x: str(x).lower(),
                    "unique": lambda x: sorted(set(x)),
                    "json_loads": lambda x: json.loads(x),
                    "json_dumps": lambda x: json.dumps(x, sort_keys=True),
                }
                if name not in safe:
                    raise KernelPolicyError(f"function is not allowed: {name}")
                try:
                    return self._bounded(safe[name](*args))
                except Exception as exc:
                    raise KernelPolicyError(f"safe function {name} failed: {exc}") from exc
            raise KernelPolicyError(f"syntax is not allowed: {type(node).__name__}")

        output: Any = None
        for statement in tree.body:
            if isinstance(statement, ast.Assign):
                if len(statement.targets) != 1 or not isinstance(statement.targets[0], ast.Name):
                    raise KernelPolicyError("assignment target must be one simple variable")
                name = statement.targets[0].id
                self._safe_name(name)
                value = self._bounded(evaluate(statement.value))
                self._values[name] = value
                output = value
            elif isinstance(statement, ast.Expr):
                output = self._bounded(evaluate(statement.value))
            else:
                raise KernelPolicyError(
                    f"statement is not allowed: {type(statement).__name__}; no imports, loops, functions, or control flow"
                )
        state_bytes = len(json.dumps(self._values, default=str).encode())
        if state_bytes > self.MAX_STATE_BYTES:
            raise KernelPolicyError("persistent kernel state exceeds budget")
        variables = {
            name: {"type": type(value).__name__, "bytes": len(json.dumps(value, default=str).encode())}
            for name, value in sorted(self._values.items())
        }
        return KernelResult(
            output=output, variables=variables, host_results=tuple(host_results),
            statements=len(tree.body),
        )
