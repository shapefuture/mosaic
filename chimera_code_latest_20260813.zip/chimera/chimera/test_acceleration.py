"""Explicit, evidence-gated test acceleration command planning.

Parallel and coverage-backed test selection can reduce wall time, but they are
never defaulted for arbitrary projects.  This module produces a command plan
only after an operator explicitly enables the relevant experimental lane.
"""
from __future__ import annotations

import importlib.util
import os
import shlex
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class TestAccelerationPlan(_FrozenModel):
    command: str
    mode: Literal["serial", "parallel-loadscope", "testmon"]
    enabled: bool
    reason: str


class TestAccelerationPolicy:
    """No environment flag can silently change a non-pytest custom command."""

    ENABLE = "CHIMERA_ENABLE_TEST_ACCELERATION"
    CERTIFIED = "CHIMERA_TEST_ACCELERATION_CERTIFIED"
    WORKERS = "CHIMERA_TEST_PARALLEL_WORKERS"
    TESTMON = "CHIMERA_ENABLE_TESTMON"

    @classmethod
    def plan(cls, command: str, *, environ: dict[str, str] | None = None) -> TestAccelerationPlan:
        env = os.environ if environ is None else environ
        normalized = " ".join(shlex.split(command))
        if normalized != "pytest -q":
            return TestAccelerationPlan(command=command, mode="serial", enabled=False, reason="explicit/custom test command is not rewritten")
        if env.get(cls.ENABLE) != "1" or env.get(cls.CERTIFIED) != "1":
            return TestAccelerationPlan(command=command, mode="serial", enabled=False, reason="test acceleration requires explicit enablement and local certification")
        if env.get(cls.TESTMON) == "1":
            if importlib.util.find_spec("testmon") is None:
                return TestAccelerationPlan(command=command, mode="serial", enabled=False, reason="pytest-testmon is unavailable")
            return TestAccelerationPlan(command="pytest -q --testmon", mode="testmon", enabled=True, reason="explicit testmon experimental lane")
        if importlib.util.find_spec("xdist") is None:
            return TestAccelerationPlan(command=command, mode="serial", enabled=False, reason="pytest-xdist is unavailable")
        try:
            workers = int(env.get(cls.WORKERS, "2"))
        except ValueError:
            return TestAccelerationPlan(command=command, mode="serial", enabled=False, reason="parallel worker count is invalid")
        if workers < 2 or workers > 64:
            return TestAccelerationPlan(command=command, mode="serial", enabled=False, reason="parallel worker count must be in [2, 64]")
        return TestAccelerationPlan(
            command=f"pytest -q -n {workers} --dist=loadscope",
            mode="parallel-loadscope",
            enabled=True,
            reason="explicit locally certified parallel test lane",
        )
