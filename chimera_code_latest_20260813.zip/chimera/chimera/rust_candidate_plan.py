"""Python-to-Rust migration candidate planning without auto-promotion."""
from __future__ import annotations

import ast
import json
import pathlib
import shutil
from dataclasses import dataclass, asdict
from typing import Any


@dataclass(frozen=True)
class RustCandidate:
    qualname: str
    file: str
    line: int
    annotated_args: int
    returns_annotated: bool
    loops: int
    branches: int
    dynamic_penalty: int
    score: float
    reasons: tuple[str, ...]


_DYNAMIC_NODES = (ast.Exec if hasattr(ast, "Exec") else ast.Call,)


class RustCandidatePlanner:
    """Rank typed, relatively pure Python functions for Rust experiments.

    This planner does not transpile by default and never promotes generated code.
    It creates a receipt that a human/CI can use to choose PyO3, depyler, or
    py2many experiments behind equivalence tests and benchmarks.
    """

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def plan(self, module_or_path: str = "chimera") -> dict[str, Any]:
        target = pathlib.Path(module_or_path)
        if not target.is_absolute():
            target = self.root / target
        files = [target] if target.is_file() else sorted(target.rglob("*.py")) if target.exists() else []
        candidates: list[RustCandidate] = []
        for file in files:
            if any(part in {"__pycache__", ".venv", "node_modules"} for part in file.parts):
                continue
            try:
                tree = ast.parse(file.read_text(encoding="utf-8"), filename=str(file))
            except Exception:
                continue
            rel = str(file.relative_to(self.root)) if file.is_relative_to(self.root) else str(file)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    cand = self._score_function(rel, node)
                    if cand.score > 0:
                        candidates.append(cand)
        candidates.sort(key=lambda c: (-c.score, c.file, c.line))
        return {
            "schema_version": "chimera.rust-candidate-plan.v1",
            "root": str(self.root),
            "target": str(target),
            "candidate_count": len(candidates),
            "tools_detected": {
                "depyler": shutil.which("depyler") is not None,
                "py2many": shutil.which("py2many") is not None,
                "maturin": shutil.which("maturin") is not None,
                "rustc": shutil.which("rustc") is not None,
            },
            "promotion_allowed": False,
            "promotion_requirements": [
                "baseline Python tests pass",
                "generated/handwritten Rust compiles",
                "property equivalence tests pass",
                "benchmark shows material latency or memory win",
                "public Python API remains stable",
            ],
            "candidates": [asdict(c) for c in candidates[:100]],
        }

    def _score_function(self, file: str, node: ast.FunctionDef | ast.AsyncFunctionDef) -> RustCandidate:
        args = list(node.args.args) + list(node.args.kwonlyargs)
        annotated = sum(1 for arg in args if arg.annotation is not None)
        returns = node.returns is not None
        loops = sum(isinstance(child, (ast.For, ast.While, ast.AsyncFor, ast.ListComp, ast.DictComp, ast.SetComp, ast.GeneratorExp)) for child in ast.walk(node))
        branches = sum(isinstance(child, (ast.If, ast.IfExp, ast.Match, ast.Try, ast.BoolOp)) for child in ast.walk(node))
        calls = [child for child in ast.walk(node) if isinstance(child, ast.Call)]
        dynamic_penalty = 0
        reasons: list[str] = []
        for call in calls:
            name = ""
            if isinstance(call.func, ast.Name):
                name = call.func.id
            elif isinstance(call.func, ast.Attribute):
                name = call.func.attr
            if name in {"eval", "exec", "compile", "getattr", "setattr", "delattr", "globals", "locals", "__import__"}:
                dynamic_penalty += 5
        if isinstance(node, ast.AsyncFunctionDef):
            dynamic_penalty += 3
            reasons.append("async functions require hand-written runtime bridging")
        if annotated:
            reasons.append("typed arguments")
        if returns:
            reasons.append("return type annotated")
        if loops:
            reasons.append("loop/comprehension hot-path potential")
        if branches:
            reasons.append("branchy logic benefits from compile-time checks")
        if dynamic_penalty:
            reasons.append("dynamic Python features reduce transpiler suitability")
        score = annotated * 2 + (3 if returns else 0) + loops * 1.5 + branches * 0.5 - dynamic_penalty
        return RustCandidate(
            qualname=node.name,
            file=file,
            line=int(getattr(node, "lineno", 0)),
            annotated_args=annotated,
            returns_annotated=returns,
            loops=loops,
            branches=branches,
            dynamic_penalty=dynamic_penalty,
            score=round(float(score), 3),
            reasons=tuple(reasons),
        )


def main() -> None:  # pragma: no cover
    print(json.dumps(RustCandidatePlanner(pathlib.Path.cwd()).plan(), indent=2, sort_keys=True))


if __name__ == "__main__":  # pragma: no cover
    main()
