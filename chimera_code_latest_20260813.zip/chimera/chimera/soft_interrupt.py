"""Persistent soft-interrupt queue injected only at provider/tool safe points."""
from __future__ import annotations
import hashlib,json,os,pathlib,time,uuid
from dataclasses import dataclass
from typing import Literal
from .wal import WAL
@dataclass(frozen=True)
class SoftInterrupt:
 id:str;session:str;content:str;urgent:bool;source:str;created_at:str
class SoftInterruptQueue:
 def __init__(self,root:pathlib.Path):self.root=pathlib.Path(root);self.dir=self.root/".chimera"/"interrupts";self.dir.mkdir(parents=True,exist_ok=True);self.wal=WAL(self.root)
 def _path(self,s):return self.dir/f"{hashlib.sha256(s.encode()).hexdigest()}.jsonl"
 def _cursor(self,s):return self.dir/f"{hashlib.sha256(s.encode()).hexdigest()}.cursor"
 def enqueue(self,session:str,content:str,*,urgent:bool=False,source:Literal["user","system","background"]="user"):
  if not content.strip():raise ValueError("soft interrupt content required")
  iid="interrupt-"+uuid.uuid4().hex[:12];row={"id":iid,"session":session,"content":content,"urgent":urgent,"source":source,"created_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())}
  with self._path(session).open("a") as h:h.write(json.dumps(row,sort_keys=True)+"\n")
  self.wal.append("soft_interrupt_enqueue",{"id":iid,"session":session,"urgent":urgent,"source":source,"content_hash":"sha256:"+hashlib.sha256(content.encode()).hexdigest()});return SoftInterrupt(**row)
 def pending(self,session:str):
  path=self._path(session);cursor=int(self._cursor(session).read_text()) if self._cursor(session).exists() else 0
  if not path.exists():return []
  rows=[json.loads(x) for x in path.read_text().splitlines() if x.strip()]
  return [SoftInterrupt(**row) for row in rows[cursor:]]
 def drain(self,session:str,*,point:Literal["B","C","D"],urgent_only:bool=False):
  path=self._path(session);rows=[json.loads(x) for x in path.read_text().splitlines() if x.strip()] if path.exists() else [];cursor=int(self._cursor(session).read_text()) if self._cursor(session).exists() else 0;pending=rows[cursor:]
  if urgent_only and pending and not all(row["urgent"] for row in pending):return []
  if not pending:return []
  temp=self._cursor(session).with_suffix(".tmp");temp.write_text(str(len(rows)));os.replace(temp,self._cursor(session));items=[SoftInterrupt(**row) for row in pending]
  self.wal.append("soft_interrupt_inject",{"session":session,"point":point,"ids":[x.id for x in items]});return items
