"""Deterministic whole-turn microcompaction with a loss-aware breadcrumb."""
from __future__ import annotations
import re
from dataclasses import dataclass
@dataclass(frozen=True)
class MicrocompactResult: text:str;removed_chars:int;breadcrumb:str

def microcompact(text:str,max_chars:int=48_000)->MicrocompactResult|None:
 if len(text)<=max_chars:return None
 # Keep complete recent tool/result turns, failures and the tail; never silently
 # remove material without saying how much can be recovered from CAS transcript.
 lines=text.splitlines();keep=[]
 for line in lines:
  if re.search(r'(error|failed|denied|test_result|patch_applied|artifact:)',line,re.I):keep.append(line)
 tail='\n'.join(lines[-max_chars//2:]);head='\n'.join(keep[-80:])
 removed=max(0,len(text)-len(head)-len(tail));crumb=f"[microcompacted {removed} chars; failures/artifact refs retained]"
 return MicrocompactResult(crumb+'\n'+head+'\n'+tail,removed,crumb)
