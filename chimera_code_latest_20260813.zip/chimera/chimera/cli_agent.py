"""Branch supervisor agent CLI commands."""
from __future__ import annotations

import json

import click
from rich.json import JSON


def register(main: click.Group, *, console, cli_root) -> None:
    _cli_root = cli_root

    @main.group("agent")
    def agent_group():
        """Daemon-backed branch workers."""
        pass

    @agent_group.command("start")
    @click.argument("task")
    @click.option("--branch", default="agent-work")
    @click.option("--model", default="mock-echo")
    @click.option("--auto-commit", is_flag=True)
    def agent_start(task, branch, model, auto_commit):
        from .supervisor import BranchSupervisor
        session = BranchSupervisor(_cli_root()).start(task, branch, model, auto_commit)
        console.print(JSON(session.model_dump_json(indent=2)))

    @agent_group.command("list")
    def agent_list():
        from .supervisor import BranchSupervisor
        sessions = [session.model_dump() for session in BranchSupervisor(_cli_root()).list()]
        console.print(JSON(json.dumps(sessions, indent=2)))

    @agent_group.command("status")
    @click.argument("session_id")
    def agent_status(session_id):
        from .supervisor import BranchSupervisor
        console.print(JSON(BranchSupervisor(_cli_root()).get(session_id).model_dump_json(indent=2)))

    @agent_group.command("stop")
    @click.argument("session_id")
    @click.option("--force", is_flag=True)
    def agent_stop(session_id, force):
        from .supervisor import BranchSupervisor
        console.print(JSON(BranchSupervisor(_cli_root()).stop(session_id, force).model_dump_json(indent=2)))

    @agent_group.command("send")
    @click.argument("session_id")
    @click.argument("message")
    def agent_send(session_id, message):
        from .supervisor import BranchSupervisor
        console.print(JSON(json.dumps(BranchSupervisor(_cli_root()).send(session_id, message), indent=2)))

    @agent_group.command("events")
    @click.argument("session_id")
    @click.option("--after", default=0, type=int)
    def agent_events(session_id, after):
        from .supervisor import BranchSupervisor
        console.print(JSON(json.dumps(BranchSupervisor(_cli_root()).events(session_id, after), indent=2)))

    @agent_group.command("service")
    @click.option("--workspace", default=".")
    def agent_service(workspace):
        """Run the private Unix push socket for worker events/control."""
        from .supervisor_socket import serve
        serve(pathlib.Path(workspace))

