"""Inbound MCP stdio and Streamable-HTTP adapters over Chimera use cases."""

from __future__ import annotations

import base64
import json
import pathlib
import sys
import threading
import time
import uuid
from collections import OrderedDict
from collections.abc import Callable, Mapping
from functools import lru_cache
from typing import Any, Protocol

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from .application import (
    AbortBranchCommand,
    ApplicationError,
    CancelSessionCommand,
    ChimeraApplication,
    CommitBranchCommand,
    CreateBranchCommand,
    GetDiffCommand,
    OpenSessionCommand,
    QueryCodeCommand,
    ResumeSessionCommand,
    RunContext,
    RunTaskCommand,
    SendSessionInputCommand,
    VerifyBranchCommand,
)
from .bootstrap import build_local_application, new_run_context
from .config import DeploymentProfile
from .mcp_remote import MODERN_PROTOCOL_VERSION
from .wire import WireCodec


class _Args(BaseModel):
    model_config = ConfigDict(extra="forbid")


class GraphQueryArgs(_Args):
    query: str = Field(min_length=1, max_length=20_000)
    limit: int = Field(default=10, ge=1, le=200)
    kind: str | None = Field(default=None, max_length=100)
    cursor: int = Field(default=0, ge=0)
    wire_format: str = Field(default="json", pattern=r"^(json|gcf|auto)$")


class BranchCreateArgs(_Args):
    branch: str = Field(min_length=1, max_length=128)
    from_branch: str = Field(default="main", min_length=1, max_length=128)


class BranchArgs(_Args):
    branch: str = Field(min_length=1, max_length=128)
    wire_format: str = Field(default="json", pattern=r"^(json|gcf|auto)$")


class BranchVerifyArgs(_Args):
    branch: str = Field(min_length=1, max_length=128)
    command: str = Field(default="pytest -q", min_length=1, max_length=10_000)


class BranchCommitArgs(_Args):
    branch: str = Field(min_length=1, max_length=128)
    task: str = Field(min_length=1, max_length=200_000)
    message: str = Field(min_length=1, max_length=10_000)


class RunArgs(_Args):
    task: str = Field(min_length=1, max_length=200_000)
    branch: str = Field(default="exp-mcp", min_length=1, max_length=128)
    model: str = Field(default="mock-echo", min_length=1, max_length=300)
    high_risk_review: bool = False


class ArtifactPageArgs(_Args):
    digest: str = Field(pattern=r"^(?:artifact:)?sha256:[0-9a-f]{64}$")
    offset: int = Field(default=0, ge=0)
    limit: int = Field(default=32_768, ge=256, le=65_536)


class SessionOpenArgs(_Args):
    objective: str = Field(min_length=1, max_length=200_000)
    model: str = Field(default="mock-echo", min_length=1, max_length=300)
    base_branch: str = Field(default="main", min_length=1, max_length=128)


class SessionInputArgs(_Args):
    session_id: str = Field(min_length=1, max_length=200)
    message: str = Field(min_length=1, max_length=200_000)


class SessionResumeArgs(_Args):
    session_id: str = Field(min_length=1, max_length=200)
    command: str = Field(default="pytest -q", min_length=1, max_length=10_000)


class SessionCancelArgs(_Args):
    session_id: str = Field(min_length=1, max_length=200)


class TelemetrySnapshotArgs(_Args):
    model: str = Field(default="*", min_length=1, max_length=300)
    recent: int = Field(default=200, ge=1, le=5000)
    wire_format: str = Field(default="json", pattern=r"^(json|gcf|auto)$")


_TOOL_MODELS: dict[str, type[_Args]] = {
    "graph.query": GraphQueryArgs,
    "branch.create": BranchCreateArgs,
    "branch.diff": BranchArgs,
    "branch.verify": BranchVerifyArgs,
    "verify.run": BranchVerifyArgs,
    "branch.commit": BranchCommitArgs,
    "branch.abort": BranchArgs,
    "rlm.run": RunArgs,
    "artifact.page": ArtifactPageArgs,
    "session.open": SessionOpenArgs,
    "session.input": SessionInputArgs,
    "session.resume": SessionResumeArgs,
    "session.cancel": SessionCancelArgs,
    "telemetry.snapshot": TelemetrySnapshotArgs,
}

_TOOL_DESCRIPTIONS = {
    "graph.query": "Snapshot-bound lexical/structural code query with bounded pagination.",
    "branch.create": "Create an isolated transactional branch.",
    "branch.diff": "Read a branch's typed transactional diff.",
    "branch.verify": "Run a bounded verification command in the branch sandbox.",
    "verify.run": "Compatibility alias for branch.verify.",
    "branch.commit": "Commit only through exact scoped approval owned by the application use case.",
    "branch.abort": "Abort a reversible transactional branch.",
    "rlm.run": "Run a task and return a versioned evidence-bound RunResult.",
    "artifact.page": "Read a bounded page from an immutable CAS artifact.",
    "session.open": "Open a durable branch-per-session control session.",
    "session.input": "Record bounded input for a control session.",
    "session.resume": "Resume session verification with a bounded command.",
    "session.cancel": "Cancel/abort a non-committed control session.",
    "telemetry.snapshot": "Read redacted WAL/event/provider/token/latency telemetry for observability and self-improvement.",
}


def _schema(model: type[_Args]) -> dict[str, Any]:
    value = model.model_json_schema()
    value["additionalProperties"] = False
    return value


TOOLS = [
    {
        "name": name,
        "description": _TOOL_DESCRIPTIONS[name],
        "inputSchema": _schema(model),
        "annotations": {
            "readOnlyHint": name in {"graph.query", "branch.diff", "artifact.page"},
            "destructiveHint": name
            in {"branch.commit", "branch.abort", "session.cancel"},
        },
    }
    for name, model in _TOOL_MODELS.items()
]


ContextFactory = Callable[[], tuple[ChimeraApplication, RunContext]]
ProgressSink = Callable[[Mapping[str, Any]], None]


class MCPServer:
    def __init__(
        self,
        context_factory: ContextFactory,
        *,
        root: pathlib.Path,
        progress_sink: ProgressSink | None = None,
        cancellation_registry: set[str] | None = None,
        registry_lock: threading.RLock | None = None,
    ) -> None:
        self.context_factory = context_factory
        self.root = pathlib.Path(root).resolve()
        self.codec = WireCodec(default="json", max_decode_bytes=2_000_000)
        self.progress_sink = progress_sink
        self._cancelled = (
            cancellation_registry if cancellation_registry is not None else set()
        )
        self._lock = registry_lock or threading.RLock()

    @staticmethod
    def _result(request_id: Any, data: Mapping[str, Any]) -> dict[str, Any]:
        return {"jsonrpc": "2.0", "id": request_id, "result": dict(data)}

    @staticmethod
    def _error(
        request_id: Any, code: int, message: str, data: Mapping[str, Any] | None = None
    ):
        error: dict[str, Any] = {"code": code, "message": message}
        if data:
            error["data"] = dict(data)
        return {"jsonrpc": "2.0", "id": request_id, "error": error}

    def _progress(
        self,
        token: str | int | None,
        *,
        progress: int,
        message: str,
    ) -> None:
        if token is None or self.progress_sink is None:
            return
        self.progress_sink(
            {
                "jsonrpc": "2.0",
                "method": "notifications/progress",
                "params": {
                    "progressToken": token,
                    "progress": progress,
                    "total": 1,
                    "message": message,
                },
            }
        )

    def _text(self, value: Any, *, mode: str = "json", graph: bool = False) -> str:
        if mode == "json":
            return json.dumps(value, separators=(",", ":"), default=str)
        envelope = (
            self.codec.encode_graph(value, tool="mcp_graph", mode=mode)
            if graph
            else self.codec.encode_generic(value, mode=mode)
        )
        return envelope.model_text()

    def _tool_call(
        self,
        application: ChimeraApplication,
        context: RunContext,
        name: str,
        arguments: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        model = _TOOL_MODELS.get(name)
        if model is None:
            raise ApplicationError("unknown_tool", "unknown MCP tool")
        args = model.model_validate(arguments)
        if name == "graph.query":
            page = application.query_code(
                QueryCodeCommand(
                    query=args.query,
                    limit=args.limit,
                    kind=args.kind,
                    cursor=args.cursor,
                    context=context,
                )
            )
            payload = page.model_dump(mode="json")
            return {
                "content": [
                    {
                        "type": "text",
                        "text": self._text(
                            list(page.items), mode=args.wire_format, graph=True
                        ),
                    }
                ],
                "structuredContent": payload,
            }
        if name == "branch.create":
            value = application.create_branch(
                CreateBranchCommand(
                    name=args.branch, from_branch=args.from_branch, context=context
                )
            )
        elif name == "branch.diff":
            value = application.get_diff(
                GetDiffCommand(branch=args.branch, context=context)
            )
        elif name in {"branch.verify", "verify.run"}:
            value = application.verify(
                VerifyBranchCommand(
                    branch=args.branch, command=args.command, context=context
                )
            )
        elif name == "branch.commit":
            value = application.commit(
                CommitBranchCommand(
                    branch=args.branch,
                    task=args.task,
                    message=args.message,
                    context=context,
                )
            )
        elif name == "branch.abort":
            value = application.abort(
                AbortBranchCommand(branch=args.branch, context=context)
            )
        elif name == "rlm.run":
            value = application.run(
                RunTaskCommand(
                    task=args.task,
                    branch=args.branch,
                    model=args.model,
                    high_risk_review=args.high_risk_review,
                    context=context,
                )
            )
        elif name == "artifact.page":
            value = application.artifact_page(
                args.digest,
                offset=args.offset,
                limit=args.limit,
            )
        elif name == "session.open":
            value = application.open_session(
                OpenSessionCommand(
                    objective=args.objective,
                    model=args.model,
                    base_branch=args.base_branch,
                    protocol="mcp",
                    context=context,
                )
            )
        elif name == "session.input":
            value = application.send_session_input(
                SendSessionInputCommand(
                    session_id=args.session_id,
                    message=args.message,
                    context=context,
                )
            )
        elif name == "session.resume":
            value = application.resume_session(
                ResumeSessionCommand(
                    session_id=args.session_id,
                    command=args.command,
                    context=context,
                )
            )
        elif name == "session.cancel":
            value = application.cancel_session(
                CancelSessionCommand(
                    session_id=args.session_id,
                    context=context,
                )
            )
        elif name == "telemetry.snapshot":
            from .telemetry_snapshot import TelemetrySnapshotBuilder
            payload = TelemetrySnapshotBuilder(self.root).build(model=args.model, recent=args.recent).model_dump(mode="json")
            return {
                "content": [{"type": "text", "text": self._text(payload, mode=args.wire_format)}],
                "structuredContent": payload,
            }
        else:  # pragma: no cover - model registry and dispatch are kept together
            raise ApplicationError("unknown_tool", "unknown MCP tool")
        payload = value.model_dump(mode="json")
        mode = getattr(args, "wire_format", "json")
        return {
            "content": [{"type": "text", "text": self._text(payload, mode=mode)}],
            "structuredContent": payload,
        }

    def handle(self, request: Mapping[str, Any]) -> dict[str, Any] | None:
        request_id = request.get("id")
        method = request.get("method")
        params = (
            request.get("params") if isinstance(request.get("params"), Mapping) else {}
        )
        try:
            if request.get("jsonrpc") != "2.0" or not isinstance(method, str):
                return self._error(request_id, -32600, "invalid JSON-RPC request")
            if method == "initialize":
                from . import __version__

                return self._result(
                    request_id,
                    {
                        "protocolVersion": MODERN_PROTOCOL_VERSION,
                        "capabilities": {
                            "tools": {"listChanged": False},
                            "logging": {},
                        },
                        "serverInfo": {"name": "chimera", "version": __version__},
                        "instructions": "All mutation and commit policy is enforced by Chimera application use cases.",
                    },
                )
            if method == "notifications/initialized":
                return None
            if method == "notifications/cancelled":
                token = str(params.get("requestId", ""))
                if token:
                    with self._lock:
                        if len(self._cancelled) >= 1_024:
                            self._cancelled.pop()
                        self._cancelled.add(token)
                return None
            if method == "ping":
                return self._result(request_id, {})
            if method == "tools/list":
                return self._result(request_id, {"tools": TOOLS})
            if method != "tools/call":
                return self._error(request_id, -32601, "unknown method")
            name = params.get("name")
            arguments = params.get("arguments")
            if not isinstance(name, str) or not isinstance(arguments, Mapping):
                return self._error(
                    request_id, -32602, "tools/call requires name and object arguments"
                )
            with self._lock:
                if str(request_id) in self._cancelled:
                    self._cancelled.discard(str(request_id))
                    return self._error(request_id, -32800, "request was cancelled")
            meta = params.get("_meta", {})
            if not isinstance(meta, Mapping):
                return self._error(request_id, -32602, "params._meta must be an object")
            progress_token = meta.get("progressToken")
            traceparent = meta.get("traceparent") or meta.get("otel.traceparent")
            if traceparent is not None and (not isinstance(traceparent, str) or len(traceparent) > 128):
                return self._error(request_id, -32602, "invalid traceparent")
            if progress_token is not None and (
                not isinstance(progress_token, (str, int))
                or isinstance(progress_token, bool)
                or len(str(progress_token)) > 128
            ):
                return self._error(request_id, -32602, "invalid progress token")
            self._progress(progress_token, progress=0, message="started")
            application, context = self.context_factory()
            if traceparent:
                try:
                    context = context.model_copy(update={"trace_id": traceparent})
                except AttributeError:
                    pass
            try:
                result = self._tool_call(application, context, name, arguments)
                if traceparent and isinstance(result, dict):
                    result = {**result, "_meta": {**dict(result.get("_meta", {})), "traceparent": traceparent}}
            except Exception:
                self._progress(progress_token, progress=1, message="failed")
                raise
            self._progress(progress_token, progress=1, message="completed")
            return self._result(request_id, result)
        except ValidationError as exc:
            return self._error(
                request_id,
                -32602,
                "invalid tool arguments",
                {
                    "issues": [
                        {"path": ".".join(map(str, item["loc"])), "type": item["type"]}
                        for item in exc.errors(include_input=False)[:16]
                    ]
                },
            )
        except ApplicationError as exc:
            return self._error(
                request_id, -32001, exc.public_message, exc.public_dict()
            )
        except Exception as exc:  # noqa: BLE001 - transport sanitizes all adapter failures
            # Record internals locally and expose only a correlation identifier.
            error_id = "error:" + uuid.uuid4().hex
            try:
                from .wal import WAL

                WAL(self.root).append(
                    "mcp_internal_error",
                    {
                        "error_id": error_id,
                        "error_class": type(exc).__name__,
                        "method": str(method),
                    },
                )
            except Exception:  # noqa: BLE001,S110 - primary error must remain returnable
                pass
            return self._error(
                request_id,
                -32603,
                "internal application error",
                {"error_id": error_id},
            )

    def close(self) -> None:
        self.codec.close()


@lru_cache(maxsize=16)
def _default_server(root_text: str) -> MCPServer:
    root = pathlib.Path(root_text).resolve()
    application, _composition = build_local_application(root)

    def factory() -> tuple[ChimeraApplication, RunContext]:
        return application, new_run_context(
            profile=DeploymentProfile.LOCAL_DETERMINISTIC,
            deadline_seconds=1_800,
        )

    return MCPServer(factory, root=root)


def handle_request(request: Mapping[str, Any], root: pathlib.Path) -> dict[str, Any]:
    """Compatibility entry point used by local integrations and tests."""
    response = _default_server(str(pathlib.Path(root).resolve())).handle(request)
    return response or {"jsonrpc": "2.0", "id": request.get("id"), "result": {}}


def serve_stdio(
    root: pathlib.Path = pathlib.Path("."),
    *,
    server: MCPServer | None = None,
    max_message_bytes: int = 2_000_000,
) -> None:
    close_on_exit = server is not None
    selected = server or _default_server(str(pathlib.Path(root).resolve()))

    def emit_progress(event: Mapping[str, Any]) -> None:
        sys.stdout.write(json.dumps(dict(event), separators=(",", ":")) + "\n")
        sys.stdout.flush()

    if selected.progress_sink is None:
        selected.progress_sink = emit_progress
    try:
        for line in sys.stdin:
            if not line.strip():
                continue
            if len(line.encode("utf-8")) > max_message_bytes:
                response = MCPServer._error(
                    None, -32600, "MCP request exceeds size limit"
                )
            else:
                try:
                    value = json.loads(line)
                    if not isinstance(value, Mapping):
                        raise TypeError("request must be an object")
                    response = selected.handle(value)
                except (json.JSONDecodeError, TypeError):
                    response = MCPServer._error(None, -32700, "invalid JSON request")
            if response is not None:
                sys.stdout.write(json.dumps(response, separators=(",", ":")) + "\n")
                sys.stdout.flush()
    finally:
        if close_on_exit:
            selected.close()


class HTTPContextResolver(Protocol):
    def resolve(
        self, headers: Mapping[str, str]
    ) -> tuple[ChimeraApplication, RunContext]: ...


class SignedGrantHTTPContextResolver:
    """Reauthorize a gateway-authenticated principal and signed tenant grant per request."""

    def __init__(
        self,
        root: pathlib.Path,
        *,
        trusted_key_ids: set[str] | frozenset[str],
        profile: DeploymentProfile = DeploymentProfile.MULTI_TENANT_PRODUCTION,
        principal_header: str = "x-chimera-principal",
        tenant_header: str = "x-chimera-tenant-id",
        grant_header: str = "x-chimera-authorization",
        application_factory: Callable[[pathlib.Path], ChimeraApplication] | None = None,
    ) -> None:
        if not trusted_key_ids:
            raise ValueError("HTTP MCP requires trusted tenant authorization keys")
        self.root = pathlib.Path(root).resolve()
        self.trusted_key_ids = frozenset(trusted_key_ids)
        self.profile = profile
        from .bootstrap import profile_policy

        if profile_policy(profile).require_shared_state and application_factory is None:
            raise ValueError(
                "cloud MCP profiles require an explicit shared-state application factory"
            )
        self.principal_header = principal_header.lower()
        self.tenant_header = tenant_header.lower()
        self.grant_header = grant_header.lower()
        self.application_factory = application_factory
        self._applications: dict[str, ChimeraApplication] = {}
        self._lock = threading.RLock()

    def resolve(
        self, headers: Mapping[str, str]
    ) -> tuple[ChimeraApplication, RunContext]:
        principal = headers.get(self.principal_header, "")
        tenant_id = headers.get(self.tenant_header, "")
        encoded = headers.get(self.grant_header, "")
        if not principal or not tenant_id or not encoded:
            raise ApplicationError(
                "authentication_required", "tenant authentication headers are required"
            )
        try:
            padding = "=" * (-len(encoded) % 4)
            raw = base64.urlsafe_b64decode(encoded + padding)
            from .tenancy import TenantContext
            from .tenant_authorization import (
                AuthorizedTenantWorkspaceBoundary,
                TenantAuthorizationGrant,
            )

            grant = TenantAuthorizationGrant.model_validate_json(raw)
            workspace, tenant_context, _receipt = AuthorizedTenantWorkspaceBoundary(
                self.root,
                trusted_key_ids=self.trusted_key_ids,
            ).resolve(
                tenant=TenantContext.from_id(tenant_id),
                authenticated_principal=principal,
                grant=grant,
                scope="mcp",
            )
        except ApplicationError:
            raise
        except Exception as exc:
            raise ApplicationError(
                "authentication_failed", "tenant authorization is invalid"
            ) from exc
        workspace_root = pathlib.Path(workspace.workspace_root)
        with self._lock:
            application = self._applications.get(tenant_context.tenant_key)
            if application is None:
                if self.application_factory is not None:
                    application = self.application_factory(workspace_root)
                else:
                    application, _composition = build_local_application(workspace_root)
                self._applications[tenant_context.tenant_key] = application
        context = new_run_context(
            profile=self.profile,
            deadline_seconds=1_800,
            tenant_key=tenant_context.tenant_key,
            principal_hash=tenant_context.principal_hash,
            grant_digest=tenant_context.grant_digest,
        )
        return application, context


class MCPStreamableHTTPApplication:
    """Small dependency-free ASGI adapter; deploy behind an authenticated gateway."""

    def __init__(
        self,
        root: pathlib.Path,
        resolver: HTTPContextResolver,
        *,
        allowed_origins: set[str] | frozenset[str],
        max_body_bytes: int = 2_000_000,
    ) -> None:
        if not allowed_origins:
            raise ValueError("HTTP MCP requires an explicit Origin allowlist")
        self.root = pathlib.Path(root).resolve()
        self.resolver = resolver
        self.allowed_origins = frozenset(allowed_origins)
        self.max_body_bytes = max(1_024, int(max_body_bytes))
        self._sessions: OrderedDict[str, tuple[str | None, float]] = OrderedDict()
        self._session_cancellations: dict[str, set[str]] = {}
        self._session_lock = threading.RLock()
        self._max_sessions = 1_024
        self._session_ttl_seconds = 3_600.0

    async def __call__(self, scope, receive, send) -> None:
        if scope.get("type") != "http":
            return
        headers = {
            key.decode("latin-1").lower(): value.decode("latin-1")
            for key, value in scope.get("headers", [])
        }
        origin = headers.get("origin")
        if scope.get("method") != "POST" or scope.get("path") != "/mcp":
            await self._respond(send, 404, {"error": "not found"})
            return
        if origin not in self.allowed_origins:
            await self._respond(send, 403, {"error": "origin denied"})
            return
        body = bytearray()
        while True:
            event = await receive()
            body.extend(event.get("body", b""))
            if len(body) > self.max_body_bytes:
                await self._respond(send, 413, {"error": "request too large"})
                return
            if not event.get("more_body", False):
                break
        try:
            request = json.loads(body)
            if not isinstance(request, Mapping):
                raise TypeError("request must be an object")
            application, context = self.resolver.resolve(headers)
            method = request.get("method")
            session_id = headers.get("mcp-session-id")
            if method != "initialize" and (
                not session_id
                or not self._session_valid(session_id, tenant_key=context.tenant_key)
            ):
                raise ApplicationError(
                    "mcp_session_required",
                    "a valid MCP-Session-Id is required after initialization",
                )
            progress_events: list[Mapping[str, Any]] = []
            cancellations = (
                self._session_cancellations.get(session_id, set())
                if session_id
                else set()
            )
            server = MCPServer(
                lambda: (application, context),
                root=self.root,
                progress_sink=progress_events.append,
                cancellation_registry=cancellations,
                registry_lock=self._session_lock,
            )
            response = server.handle(request)
        except ApplicationError as exc:
            await self._respond(send, 401, {"error": exc.public_dict()})
            return
        except (json.JSONDecodeError, TypeError, ValueError):
            await self._respond(send, 400, {"error": "invalid JSON-RPC request"})
            return
        response_headers = [(b"content-type", b"application/json")]
        if request.get("method") == "initialize":
            session_id = uuid.uuid4().hex
            self._remember_session(session_id, tenant_key=context.tenant_key)
            response_headers.append((b"mcp-session-id", session_id.encode("ascii")))
        if progress_events:
            await self._respond_sse(send, [*progress_events, response or {}])
            return
        await self._respond(send, 200, response or {}, headers=response_headers)

    def _remember_session(self, session_id: str, *, tenant_key: str | None) -> None:
        with self._session_lock:
            now = time.monotonic()
            self._sessions[session_id] = (
                tenant_key,
                now + self._session_ttl_seconds,
            )
            self._session_cancellations.setdefault(session_id, set())
            self._sessions.move_to_end(session_id)
            while len(self._sessions) > self._max_sessions:
                expired_id, _ = self._sessions.popitem(last=False)
                self._session_cancellations.pop(expired_id, None)

    def _session_valid(self, session_id: str, *, tenant_key: str | None) -> bool:
        with self._session_lock:
            value = self._sessions.pop(session_id, None)
            if value is None:
                return False
            expected_tenant, expires_at = value
            if expires_at <= time.monotonic() or expected_tenant != tenant_key:
                self._session_cancellations.pop(session_id, None)
                return False
            self._sessions[session_id] = value
            return True

    @staticmethod
    async def _respond_sse(send, events: list[Mapping[str, Any]]) -> None:
        raw = "".join(
            "event: message\ndata: "
            + json.dumps(dict(event), separators=(",", ":"))
            + "\n\n"
            for event in events
        ).encode()
        await send(
            {
                "type": "http.response.start",
                "status": 200,
                "headers": [(b"content-type", b"text/event-stream")],
            }
        )
        await send({"type": "http.response.body", "body": raw})

    @staticmethod
    async def _respond(
        send, status: int, value: Mapping[str, Any], headers=None
    ) -> None:
        raw = json.dumps(dict(value), separators=(",", ":")).encode()
        await send(
            {
                "type": "http.response.start",
                "status": status,
                "headers": headers or [(b"content-type", b"application/json")],
            }
        )
        await send({"type": "http.response.body", "body": raw})
