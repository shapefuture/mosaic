"""Unified provider catalog with environment-only credential discovery."""
from __future__ import annotations

import os
from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class ProviderSpec(BaseModel):
    id: str
    env_keys: List[str] = Field(default_factory=list)
    model_patterns: List[str] = Field(default_factory=list)
    openai_compatible: bool = False
    base_url_env: Optional[str] = None
    implemented: bool = False
    protocol: Optional[str] = None


PROVIDERS: Dict[str, ProviderSpec] = {
    spec.id: spec for spec in [
        ProviderSpec(id="openrouter", env_keys=["OPENROUTER_API_KEY", "OPENROUTER_API_KEYS"], model_patterns=["/"], openai_compatible=True),
        ProviderSpec(id="tokenrouter", env_keys=["TOKENROUTER_API_KEY", "TOKENROUTER_KEY"], model_patterns=["tokenrouter"], openai_compatible=True),
        ProviderSpec(id="anthropic", env_keys=["ANTHROPIC_API_KEY"], model_patterns=["claude", "anthropic"]),
        ProviderSpec(id="openai", env_keys=["OPENAI_API_KEY"], model_patterns=["gpt", "o1", "o3", "codex"], openai_compatible=True),
        ProviderSpec(id="azure-openai", env_keys=["AZURE_OPENAI_API_KEY"], model_patterns=["azure"], openai_compatible=True, base_url_env="AZURE_OPENAI_BASE_URL"),
        ProviderSpec(id="google", env_keys=["GEMINI_API_KEY", "GOOGLE_API_KEY", "GEMINI_API_KEYS", "GOOGLE_API_KEYS"], model_patterns=["gemini", "google"]),
        ProviderSpec(id="deepseek", env_keys=["DEEPSEEK_API_KEY"], model_patterns=["deepseek"], openai_compatible=True),
        ProviderSpec(id="mistral", env_keys=["MISTRAL_API_KEY"], model_patterns=["mistral"], openai_compatible=True),
        ProviderSpec(id="groq", env_keys=["GROQ_API_KEY"], model_patterns=["groq"], openai_compatible=True),
        ProviderSpec(id="cerebras", env_keys=["CEREBRAS_API_KEY"], model_patterns=["cerebras"], openai_compatible=True),
        ProviderSpec(id="xai", env_keys=["XAI_API_KEY"], model_patterns=["grok", "xai"], openai_compatible=True),
        ProviderSpec(id="prime-inference", env_keys=["PRIME_API_KEY"], model_patterns=["prime"], openai_compatible=True),
        ProviderSpec(id="fireworks", env_keys=["FIREWORKS_API_KEY"], model_patterns=["fireworks"], openai_compatible=True),
        ProviderSpec(id="huggingface", env_keys=["HF_TOKEN"], model_patterns=["huggingface", "hf/"]),
        ProviderSpec(id="zai", env_keys=["ZAI_API_KEY"], model_patterns=["glm", "zai"], openai_compatible=True),
        ProviderSpec(id="kimi", env_keys=["KIMI_API_KEY", "MOONSHOT_API_KEY"], model_patterns=["kimi", "moonshot"], openai_compatible=True),
        ProviderSpec(id="minimax", env_keys=["MINIMAX_API_KEY", "MINIMAX_CN_API_KEY"], model_patterns=["minimax"], openai_compatible=True),
        ProviderSpec(id="qwen", env_keys=["DASHSCOPE_API_KEY", "QWEN_API_KEY"], model_patterns=["qwen"], openai_compatible=True),
        ProviderSpec(id="ollama", env_keys=["OLLAMA_HOST"], model_patterns=["ollama", "llama"]),
        ProviderSpec(id="vercel-ai-gateway", env_keys=["AI_GATEWAY_API_KEY"], model_patterns=["vercel"], openai_compatible=True),
        ProviderSpec(id="cloudflare-ai-gateway", env_keys=["CLOUDFLARE_API_KEY"], model_patterns=["cloudflare"], openai_compatible=True),
        ProviderSpec(id="bedrock", env_keys=["AWS_PROFILE", "AWS_ACCESS_KEY_ID", "AWS_BEARER_TOKEN_BEDROCK"], model_patterns=["bedrock"]),
        ProviderSpec(id="opencode", env_keys=["OPENCODE_API_KEY"], model_patterns=["opencode"], openai_compatible=True),
        ProviderSpec(id="xiaomi", env_keys=["XIAOMI_API_KEY", "XIAOMI_TOKEN_PLAN_AMS_API_KEY", "XIAOMI_TOKEN_PLAN_SGP_API_KEY"], model_patterns=["mimo", "xiaomi"], openai_compatible=True),
    ]
}

# The capability catalog must not advertise a configured credential as an
# implemented transport. These are the protocol paths currently bound by the
# legacy runtime or the new protocol adapters; all others remain unavailable.
_IMPLEMENTED_PROTOCOLS = {
    "openrouter": "openai-compatible-chat",
    "tokenrouter": "openai-compatible-chat",
    "anthropic": "anthropic-messages",
    "openai": "openai-chat",
    "google": "gemini-generate-content",
    "deepseek": "openai-compatible-chat",
    "mistral": "openai-compatible-chat",
    "groq": "openai-compatible-chat",
    "cerebras": "openai-compatible-chat",
    "xai": "openai-compatible-chat",
    "prime-inference": "openai-compatible-chat",
    "fireworks": "openai-compatible-chat",
    "zai": "openai-compatible-chat",
    "kimi": "openai-compatible-chat",
    "minimax": "openai-compatible-chat",
    "qwen": "openai-compatible-chat",
    "ollama": "ollama-generate",
}
for _provider_id, _protocol in _IMPLEMENTED_PROTOCOLS.items():
    PROVIDERS[_provider_id].implemented = True
    PROVIDERS[_provider_id].protocol = _protocol


class ProviderCatalog:
    def list(self) -> List[ProviderSpec]:
        return list(PROVIDERS.values())

    def resolve(self, model: str) -> ProviderSpec:
        lower = model.lower()
        # Explicit direct-provider prefixes are not OpenRouter slugs. Keep the
        # historical slash=>OpenRouter fallback for all other gateway model IDs.
        explicit_prefixes = {
            "tokenrouter/": "tokenrouter",
            "cerebras/": "cerebras",
            "gemini/": "google",
            "kimi/": "kimi",
            "moonshot/": "kimi",
        }
        for prefix, provider_id in explicit_prefixes.items():
            if lower.startswith(prefix):
                return PROVIDERS[provider_id]
        if "/" in model:
            return PROVIDERS["openrouter"]
        for spec in PROVIDERS.values():
            if any(pattern in lower for pattern in spec.model_patterns if pattern != "/"):
                return spec
        return PROVIDERS["openrouter"]

    def credentials(self, provider_id: str) -> List[str]:
        spec = PROVIDERS[provider_id]
        values = []
        for key in spec.env_keys:
            value = os.environ.get(key)
            if value:
                if key.endswith("_KEYS"):
                    values.extend(item.strip() for item in value.replace(";", ",").split(",") if item.strip())
                else:
                    values.append(value)
        return list(dict.fromkeys(values))

    def available(self) -> List[str]:
        return [spec.id for spec in PROVIDERS.values() if self.credentials(spec.id)]

    def report(self) -> List[Dict[str, object]]:
        return [
            {
                "id": spec.id,
                "configured": bool(self.credentials(spec.id)),
                "credential_slots": len(self.credentials(spec.id)),
                "openai_compatible": spec.openai_compatible,
                "base_url_env": spec.base_url_env,
                "implemented": spec.implemented,
                "protocol": spec.protocol,
                "state": (
                    "available" if spec.implemented and bool(self.credentials(spec.id))
                    else "implemented-unconfigured" if spec.implemented
                    else "unavailable-no-bound-adapter"
                ),
            }
            for spec in PROVIDERS.values()
        ]
