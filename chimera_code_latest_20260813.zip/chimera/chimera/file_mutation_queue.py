"""Per-canonical-path mutation serialization."""
from __future__ import annotations
import pathlib, threading
from contextlib import contextmanager

class FileMutationQueue:
    def __init__(self): self._locks={}; self._guard=threading.Lock()
    def _lock(self,path:pathlib.Path):
        key=str(path.resolve(strict=False))
        with self._guard:
            return self._locks.setdefault(key, threading.RLock())
    @contextmanager
    def locked(self,path:pathlib.Path):
        lock=self._lock(path); lock.acquire()
        try: yield
        finally: lock.release()
