"""Optional browser/WebContainer runtime adapter with explicit availability evidence.

Chimera does not label Node subprocesses as WebContainers. A real adapter must
be configured through CHIMERA_WEBCONTAINER_CMD and satisfy the JSON contract.
"""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import shlex
import shutil
import subprocess
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from .wal import WAL


class BrowserRuntimeStatus(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    status: Literal["available", "unavailable", "error"]
    backend: Optional[str]
    detail: str
    node_available: bool
    configured: bool


class BrowserRuntimeResult(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    status: Literal["pass", "fail", "unavailable", "error"]
    backend: Optional[str]
    exit_code: Optional[int]
    stdout: str = ""
    stderr: str = ""
    evidence: dict[str, Any] = Field(default_factory=dict)


class BrowserRuntime:
    def __init__(self, root: pathlib.Path, command: Optional[str] = None) -> None:
        self.root = pathlib.Path(root).resolve()
        self.command = command or os.environ.get("CHIMERA_WEBCONTAINER_CMD")
        self.wal = WAL(self.root)

    def preflight(self) -> BrowserRuntimeStatus:
        node = shutil.which("node") is not None
        if not self.command:
            return BrowserRuntimeStatus(
                status="unavailable", backend=None,
                detail="set CHIMERA_WEBCONTAINER_CMD to a real browser/WebContainer adapter",
                node_available=node, configured=False,
            )
        try:
            argv = shlex.split(self.command)
            executable = shutil.which(argv[0]) if argv else None
            if not executable and (not argv or not pathlib.Path(argv[0]).exists()):
                return BrowserRuntimeStatus(
                    status="error", backend="external-webcontainer-adapter",
                    detail="configured adapter executable not found", node_available=node, configured=True,
                )
        except ValueError as exc:
            return BrowserRuntimeStatus(
                status="error", backend="external-webcontainer-adapter", detail=str(exc),
                node_available=node, configured=True,
            )
        return BrowserRuntimeStatus(
            status="available", backend="external-webcontainer-adapter",
            detail="configured adapter command available", node_available=node, configured=True,
        )

    def run(self, *, files: dict[str, str], command: tuple[str, ...], timeout: int = 120) -> BrowserRuntimeResult:
        status = self.preflight()
        if status.status != "available":
            return BrowserRuntimeResult(
                status="unavailable" if status.status == "unavailable" else "error",
                backend=status.backend, exit_code=None, stderr=status.detail,
                evidence=status.model_dump(mode="json"),
            )
        for path in files:
            pure = pathlib.PurePosixPath(path)
            if pure.is_absolute() or ".." in pure.parts:
                return BrowserRuntimeResult(status="error", backend=status.backend, exit_code=None,
                                            stderr=f"unsafe virtual file path: {path}")
        payload = {
            "schema": "chimera.webcontainer.v1",
            "files": files,
            "command": list(command),
            "network": False,
            "timeout": timeout,
        }
        payload_hash = "sha256:" + hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        try:
            result = subprocess.run(
                shlex.split(self.command or ""), input=json.dumps(payload),
                capture_output=True, text=True, timeout=timeout + 10,
                env={"PATH": os.environ.get("PATH", ""), "LANG": os.environ.get("LANG", "C")},
            )
            value = json.loads(result.stdout) if result.stdout.strip().startswith("{") else {}
            exit_code = int(value.get("exit_code", result.returncode))
            evidence = {
                "payload_hash": payload_hash,
                "adapter_returncode": result.returncode,
                "network_requested": False,
                "adapter_evidence": value.get("evidence", {}),
            }
            self.wal.append("webcontainer_run", {
                "payload_hash": payload_hash, "exit_code": exit_code,
                "backend": "external-webcontainer-adapter",
            })
            return BrowserRuntimeResult(
                status="pass" if exit_code == 0 else "fail",
                backend="external-webcontainer-adapter", exit_code=exit_code,
                stdout=str(value.get("stdout", ""))[-10000:],
                stderr=(str(value.get("stderr", "")) + result.stderr)[-10000:],
                evidence=evidence,
            )
        except Exception as exc:
            return BrowserRuntimeResult(
                status="error", backend="external-webcontainer-adapter", exit_code=None,
                stderr=f"{type(exc).__name__}: {exc}", evidence={"payload_hash": payload_hash},
            )
