"""Evidence-driven action-cap controller for compact tool programs."""
from __future__ import annotations
from dataclasses import dataclass
@dataclass
class AdaptiveActionCap:
 base:int;minimum:int=2;maximum:int=64;pressure:float=0.;utility:float=1.
 def cap(self)->int:
  factor=max(.25,min(1.5,self.utility-self.pressure*.5))
  return max(self.minimum,min(self.maximum,int(self.base*factor)))
 def observe(self,requested:int,successful:int,context_chars:int)->None:
  self.utility=.8*self.utility+.2*(successful/max(1,requested))
  self.pressure=.8*self.pressure+.2*min(1.,context_chars/80_000)
