"""Cohesive multi-file coder methods for RLMRuntime."""
from __future__ import annotations

import hashlib
import json
import pathlib
import re
import time
from typing import Any, Dict, List, Mapping, Optional

from .quality import TaskContract, PatchQualityGate, ChangeTarget
from .capsule import build_capsule_spec

class RLMCohesiveCoderMixin:
    def _cohesive_coder(self, branch: str, model: str, task: str, contract: TaskContract) -> Dict[str, Any]:
        """Generate one checked patch for two tightly coupled standard-risk files.

        The profile classifier has already proved the small target count and
        shared acceptance relation. This method keeps one model patch call
        possible, then puts the whole candidate through the ordinary static,
        protected-test, overlay, and full-test gates. It never commits.
        """
        from .cohesive_transaction import CohesiveTransactionPolicy
        from .fable_transfers import TestIntegrityGuard
        from .typed_context import ContextKind, ContextTrust, TypedContextItem
        from .context_plan import ContextPlan

        policy = CohesiveTransactionPolicy()
        policy.validate_targets(len(contract.targets))
        protected_before: Dict[str, str] = {}
        for path in contract.protected_paths:
            if not path.startswith("tests/"):
                continue
            try:
                protected_before[path] = self.workspace.read(branch, path).decode("utf-8", errors="surrogateescape")
            except (FileNotFoundError, ValueError):
                protected_before[path] = "<missing-before>"
        protected_snapshot = TestIntegrityGuard.snapshot(protected_before)
        current_targets: Dict[str, str] = {}
        for target in contract.targets:
            try:
                current_targets[target.path] = self.workspace.read(branch, target.path).decode("utf-8", errors="replace")
            except (FileNotFoundError, ValueError):
                current_targets[target.path] = "<absent>"
        target_paths = [target.path for target in contract.targets]
        policy_text = (
            "JSON PATCH ONLY. Use compact wire {\"f\":{path:complete_source},\"e\":[{\"p\":path,\"o\":old,\"n\":new}]}; "
            f"Allowed target paths exactly: {target_paths}. "
            "Write real code only; do not modify tests, invoke commands, add unrelated files, or use prose.\n"
            + contract.compact_prompt()
        )
        plan = ContextPlan(
            model=model,
            snapshot_id=self.workspace.diff(branch).get("id", ""),
            items=(
                TypedContextItem("policy", ContextKind.POLICY, ContextTrust.POLICY, policy_text, source_ref="cohesive-contract", priority="required", required=True, preserve=True, order=0),
                TypedContextItem("targets", ContextKind.WORKSPACE, ContextTrust.VERIFIED, "CURRENT TARGETS:\n" + json.dumps(current_targets, sort_keys=True), source_ref="cohesive-workspace", priority="high", order=1),
                TypedContextItem("closing", ContextKind.POLICY, ContextTrust.POLICY, "\nJSON ONLY.", source_ref="cohesive-output", priority="required", required=True, preserve=True, order=2),
            ),
            max_tokens=self.config.planner.context_max_tokens,
            max_chars=self.config.planner.context_max_chars,
        )
        compiled = self.context_plan_compiler.compile(plan)
        evidence: List[Dict[str, Any]] = [{"stage": "context-plan", "ok": True, **compiled.evidence()}]
        total_tokens = 0
        repair_rounds = 0
        last_response: Dict[str, Any] = {}
        applied: List[str] = []
        test: Dict[str, Any] = {"status": 125, "stdout": "", "stderr": "no candidate admitted"}
        prompt = compiled.text
        # Fast path: if every target has a verified deterministic local scaffold,
        # compose them into one cohesive patch and avoid provider/DAG overhead.
        scaffold_files = []
        for target in contract.targets:
            target_contract = TaskContract(
                task=contract.task, tests=contract.tests, targets=[target],
                protected_paths=contract.protected_paths,
                required_literals=contract.required_literals,
                required_symbols=contract.required_symbols,
                required_calls=contract.required_calls,
                required_mapping_keys=contract.required_mapping_keys,
                required_prefixes=contract.required_prefixes,
                required_call_arity=contract.required_call_arity,
            )
            scaffold = self._deterministic_domain_scaffold(target_contract, target)
            if not scaffold:
                scaffold_files = []
                break
            scaffold_files.extend(scaffold.get("files", []))
        if scaffold_files and len({row.get("path") for row in scaffold_files}) == len(contract.targets):
            payload = {"summary": "deterministic cohesive scaffolds", "files": scaffold_files, "edits": [], "insertions": [], "aci_approved": True}
            gate = PatchQualityGate(self.root, contract)
            valid, errors = gate.validate(payload)
            evidence.append({"stage": "deterministic-cohesive-scaffold", "ok": valid, "errors": errors if not valid else []})
            if valid:
                patch = self.action_executor.apply_patch_payload(branch, payload)
                applied.extend(patch.get("applied", []))
                evidence.append({"stage": "apply", "ok": bool(patch.get("applied")), "attempt": -1, **patch})
                if patch.get("applied"):
                    test = self.action_executor.run_branch_tests(branch, command="pytest -q", impact_scope=False)
                    evidence.append({"stage": "full-integration", "ok": test.get("status") == 0, "attempt": -1, "status": test.get("status"), "scope": test.get("evidence", {}).get("verification_scope", {})})
        if test.get("status") != 0:
            # Fall back to provider repair/generation only if deterministic fast path did not pass.
            pass
        for attempt in range(policy.max_repairs + 1):
            if test.get("status") == 0:
                break
            payload, response, tokens = self._strict_patch_call(prompt, model, contract.targets[0], attempts=2)
            total_tokens += tokens
            last_response = response
            if payload is None:
                evidence.append({"stage": "generation", "ok": False, "attempt": attempt, "diagnostics": response.get("_quality_diagnostics", [])})
                break
            gate = PatchQualityGate(self.root, contract)
            valid, errors = gate.validate(payload)
            evidence.append({"stage": "quality-gate", "ok": valid, "attempt": attempt, "errors": errors if not valid else [], "path_policies": getattr(gate, "last_path_policies", [])})
            if not valid:
                break
            patch = self.action_executor.apply_patch_payload(branch, payload)
            applied.extend(patch.get("applied", []))
            evidence.append({"stage": "apply", "ok": bool(patch.get("applied")), "attempt": attempt, **patch})
            if not patch.get("applied"):
                break
            test = self.action_executor.run_branch_tests(branch, command="pytest -q", impact_scope=False)
            evidence.append({"stage": "full-integration", "ok": test.get("status") == 0, "attempt": attempt, "status": test.get("status"), "scope": test.get("evidence", {}).get("verification_scope", {})})
            if test.get("status") == 0 or attempt >= policy.max_repairs:
                break
            repair_rounds += 1
            prompt = compiled.text + (
                "\nFAILED FULL TEST EVIDENCE (repair the root cause; preserve correct changes):\n"
                f"status={test.get('status')}\nstdout={str(test.get('stdout', ''))[-3000:]}\n"
            )
        protected_after: Dict[str, str] = {}
        for path in protected_before:
            try:
                protected_after[path] = self.workspace.read(branch, path).decode("utf-8", errors="surrogateescape")
            except (FileNotFoundError, ValueError):
                protected_after[path] = "<missing-after>"
        protected_ok = TestIntegrityGuard.unchanged(protected_snapshot, protected_after)
        if not protected_ok:
            test = {**test, "status": 66, "stdout": str(test.get("stdout", "")) + "\nprotected test integrity violation"}
        deduped = list(dict.fromkeys(applied))
        quality = {
            "admissible": bool(deduped) and test.get("status") == 0 and protected_ok,
            "protected_tests_unchanged": protected_ok,
            "repair_rounds": repair_rounds,
            "target_coverage": len(set(deduped)) / max(1, len(contract.targets)),
            "model_outputs_admitted": 1 if deduped else 0,
            "verification_scope": "full",
        }
        return {
            "artifacts": {
                "answer": str(last_response.get("answer", "")),
                "patch": {"applied": deduped, "rejected": [item for row in evidence for item in row.get("rejected", [])]},
                "diff": self.workspace.diff(branch), "ops": self.workspace.diff(branch).get("ops", []),
                "test_status": test.get("status"), "test_evidence": test,
                "quality_evidence": evidence, "quality": quality,
                "provider": {"model": model, "provider": last_response.get("provider", "local"), "real_call": bool(last_response.get("real_call")), "api_calls": int(last_response.get("_quality_attempts", 0) or 0)},
            },
            "trace": [
                {"kind": "cohesive_transaction", "data": {"targets": target_paths, "repairs": repair_rounds, "test_status": test.get("status")}},
                {"kind": "test_result", "data": {"status": test.get("status"), "duration_ms": test.get("duration_ms")}},
            ],
            "tokens": total_tokens,
        }
