"""Budget and routing cost ledger.

Pricing produces estimates unless a provider supplies billed cost. No benchmark,
savings percentage, or percentile is inferred from planned run counts.
"""
from __future__ import annotations
from typing import Dict,List
PRICING={
 "deepseek-v4-flash":{"input":.14,"output":.28,"tier":"exploration"},"deepseek-v3.2":{"input":.28,"output":.42,"tier":"exploration"},
 "glm-5.2":{"input":.5,"output":1.,"tier":"exploration"},"qwen3.5-9b":{"input":.5,"output":1.,"tier":"exploration"},
 "kimi-k2.5:agent-swarm":{"input":5.,"output":15.,"tier":"validation"},"kimi-k2.5":{"input":5.,"output":15.,"tier":"validation"},
 "claude-opus-5":{"input":15.,"output":75.,"tier":"validation"},"claude-sonnet-4.5":{"input":3.,"output":15.,"tier":"validation"},
 "gpt-5":{"input":10.,"output":30.,"tier":"validation"},"mock-echo":{"input":0.,"output":0.,"tier":"test"}}
class CostGovernor:
 def __init__(self,budget_usd:float=10.):self.budget=max(0,float(budget_usd));self.spent=0.;self.ledger:List[Dict]=[]
 def route(self,phase:str)->str:
  if phase in {"digester","planner","evolver","exploration"}:return "deepseek-v4-flash"
  if phase in {"critic","validation","final","swarm"}:return "kimi-k2.5:agent-swarm"
  return "mock-echo"
 def account(self,model:str,input_tokens:int,output_tokens:int,*,billed_cost:float|None=None,source:str="measured")->Dict:
  """Account measured token counts when available; callers pass source='estimate' for explicit fallbacks."""
  pricing=PRICING.get(model,{"input":1.,"output":3.,"tier":"unknown"});estimate=max(0,input_tokens)/1e6*pricing["input"]+max(0,output_tokens)/1e6*pricing["output"]
  cost=float(billed_cost) if billed_cost is not None else estimate;self.spent+=cost
  entry={"model":model,"input_tokens":input_tokens,"output_tokens":output_tokens,"estimated_cost":estimate,"cost":cost,"cost_kind":"provider-billed" if billed_cost is not None else "estimate","source":source,"spent":self.spent,"budget":self.budget,"over":self.spent>self.budget};self.ledger.append(entry);return entry
 def should_stop(self):return self.spent>=self.budget*.95
 def report(self):
  by_tier={}
  for e in self.ledger:
   tier=PRICING.get(e["model"],{}).get("tier","unknown");by_tier[tier]=by_tier.get(tier,0)+e["cost"]
  return {"spent":round(self.spent,6),"budget":self.budget,"entries":len(self.ledger),"by_tier":by_tier,"provider_billed_entries":sum(e["cost_kind"]=="provider-billed" for e in self.ledger),"estimated_entries":sum(e["cost_kind"]=="estimate" for e in self.ledger),"savings":None,"p95":None}
 def evolve_cost_split(self,iterations:int=10,tasks:int=89)->Dict:
  exploration_runs=iterations*tasks;validation_runs=iterations*5;exp=exploration_runs*2000/1e6*PRICING["deepseek-v4-flash"]["input"];val=validation_runs*5000/1e6*PRICING["kimi-k2.5:agent-swarm"]["input"]
  return {"kind":"scenario-estimate-not-executed","assumptions":{"iterations":iterations,"tasks":tasks,"exploration_tokens_per_run":2000,"validation_tokens_per_run":5000},"exploration_runs":exploration_runs,"validation_runs":validation_runs,"estimated_cost_usd":round(exp+val,4),"measured_runs":0,"measured_savings":None}
