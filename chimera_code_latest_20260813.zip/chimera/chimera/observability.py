
"""
Observability — structured logs, progress tracking, human intervention, approval gates

Provides:
- structured jsonl logs to .chimera/logs.jsonl
- progress tracker per plan
- approval gate hook
"""
from __future__ import annotations
import json, pathlib, time
from typing import Dict, List, Any, Optional

class Logger:
    def __init__(self, root: pathlib.Path = pathlib.Path(".")):
        self.root = pathlib.Path(root)
        self.path = self.root / ".chimera" / "logs.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, level: str, msg: str, **fields):
        entry={"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "level": level, "msg": msg, **fields}
        with open(self.path, "a") as f:
            f.write(json.dumps(entry)+"\n")
        return entry

    def info(self, msg: str, **fields): return self.log("info", msg, **fields)
    def warn(self, msg: str, **fields): return self.log("warn", msg, **fields)
    def error(self, msg: str, **fields): return self.log("error", msg, **fields)

    def tail(self, n:int=20) -> List[Dict]:
        if not self.path.exists(): return []
        lines=self.path.read_text().splitlines()
        return [json.loads(l) for l in lines[-n:] if l.strip()]

class ProgressTracker:
    def __init__(self):
        self.steps: List[Dict]=[]
    def update(self, step: str, status: str, detail: str=""):
        self.steps.append({"step": step, "status": status, "detail": detail, "ts": time.time()})
    def snapshot(self) -> Dict:
        return {"steps": self.steps, "current": self.steps[-1] if self.steps else None}

class ApprovalGate:
    def __init__(self, auto_approve: bool=True):
        self.auto_approve=auto_approve
    def request(self, action: str, diff: Dict, justification: str) -> bool:
        # In prod, would prompt human; for auto, approve if no private IP exfil
        if self.auto_approve:
            # deny if diff contains /etc or exfiltrate
            ops=json.dumps(diff).lower()
            if "/etc/shadow" in ops or "169.254.169.254" in ops:
                return False
            return True
        # manual: would block
        return False
