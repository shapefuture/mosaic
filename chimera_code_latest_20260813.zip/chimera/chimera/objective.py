"""Constrained objective, five-tier held-out corpus, and objective traces.

Promotion is not a raw score comparison. A challenger must first satisfy every
hard constraint on a sealed, query-budgeted corpus with resolvable evidence;
only then may weighted utility choose among feasible candidates.
"""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import time
import uuid
from enum import StrEnum
from typing import Any, Callable, Iterable, Literal, Mapping, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .config import FrozenDict
from .wal import WAL


class TierName(StrEnum):
    PUBLIC_DEVELOPMENT = "public-development"
    PRIVATE_VALIDATION = "private-validation"
    SEALED_PROMOTION = "sealed-promotion"
    ROTATING_FUTURE = "rotating-future"
    DELAYED_OUTCOME = "delayed-outcome"


ScoreVisibility = Literal["exact", "band", "opaque", "aggregate"]
QueryPurpose = Literal["development", "validation", "promotion", "outcome"]


class FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class CorpusItem(FrozenModel):
    id: str
    artifact_digest: str
    task_class: str
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("artifact_digest")
    @classmethod
    def _digest(cls, value: str) -> str:
        raw = value.removeprefix("sha256:")
        if not value.startswith("sha256:") or len(raw) != 64 or any(c not in "0123456789abcdef" for c in raw.lower()):
            raise ValueError("artifact_digest must be sha256:<64 hex>")
        return value.lower()


class CorpusTier(FrozenModel):
    name: TierName
    score_visibility: ScoreVisibility
    query_budget_per_candidate_cycle: Optional[int] = Field(default=None, ge=1)
    items: tuple[CorpusItem, ...]

    @model_validator(mode="after")
    def _unique(self) -> "CorpusTier":
        ids = [item.id for item in self.items]
        if not self.items:
            raise ValueError(f"corpus tier {self.name} must not be empty")
        if len(ids) != len(set(ids)):
            raise ValueError(f"corpus tier {self.name} has duplicate item ids")
        return self


class CorpusManifest(FrozenModel):
    schema_version: int = 1
    created_at: str = "1970-01-01T00:00:00Z"
    rotation_id: str = "initial"
    tiers: tuple[CorpusTier, ...]

    @model_validator(mode="after")
    def _five_tiers(self) -> "CorpusManifest":
        names = [tier.name for tier in self.tiers]
        if set(names) != set(TierName) or len(names) != len(TierName):
            raise ValueError("corpus manifest must contain each of the five fixed tiers exactly once")
        expected = {
            TierName.PUBLIC_DEVELOPMENT: ("exact", None),
            TierName.PRIVATE_VALIDATION: ("band", "budgeted"),
            TierName.SEALED_PROMOTION: ("opaque", 1),
            TierName.ROTATING_FUTURE: ("band", "budgeted"),
            TierName.DELAYED_OUTCOME: ("aggregate", None),
        }
        for tier in self.tiers:
            visibility, budget = expected[tier.name]
            if tier.score_visibility != visibility:
                raise ValueError(f"tier {tier.name} must use score visibility {visibility}")
            if budget == "budgeted" and tier.query_budget_per_candidate_cycle is None:
                raise ValueError(f"tier {tier.name} requires a query budget")
            if isinstance(budget, int) and tier.query_budget_per_candidate_cycle != budget:
                raise ValueError(f"tier {tier.name} query budget is fixed at {budget}")
        return self

    @classmethod
    def build(
        cls,
        items: Mapping[TierName, Iterable[CorpusItem]],
        *,
        private_validation_budget: int = 3,
        rotating_future_budget: int = 1,
        rotation_id: str = "initial",
    ) -> "CorpusManifest":
        policies = {
            TierName.PUBLIC_DEVELOPMENT: ("exact", None),
            TierName.PRIVATE_VALIDATION: ("band", private_validation_budget),
            TierName.SEALED_PROMOTION: ("opaque", 1),
            TierName.ROTATING_FUTURE: ("band", rotating_future_budget),
            TierName.DELAYED_OUTCOME: ("aggregate", None),
        }
        return cls(
            created_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            rotation_id=rotation_id,
            tiers=tuple(
                CorpusTier(
                    name=name,
                    score_visibility=policies[name][0],  # type: ignore[arg-type]
                    query_budget_per_candidate_cycle=policies[name][1],
                    items=tuple(items.get(name, ())),
                )
                for name in TierName
            ),
        )

    @property
    def content_hash(self) -> str:
        payload = self.model_dump(mode="json", exclude={"created_at"})
        return _hash(payload)

    def tier_names(self) -> tuple[TierName, ...]:
        return tuple(tier.name for tier in self.tiers)

    def tier(self, name: TierName) -> CorpusTier:
        return next(tier for tier in self.tiers if tier.name == name)


class CorpusQueryAuthorization(FrozenModel):
    receipt: str
    manifest_hash: str
    tier: TierName
    candidate_id: str
    cycle_id: str
    purpose: QueryPurpose
    score_visibility: ScoreVisibility
    item_digests: tuple[str, ...] = Field(exclude=True)
    usage: int
    budget: Optional[int]


class CorpusController:
    """Durable query-budget gate. It authorizes; it never scores candidates."""

    def __init__(self, root: pathlib.Path, manifest: CorpusManifest) -> None:
        self.root = pathlib.Path(root).resolve()
        self.manifest = manifest
        self.wal = WAL(self.root)

    def _usage(self, tier: TierName, candidate_id: str, cycle_id: str) -> int:
        return sum(
            1 for entry in self.wal.replay(kind="corpus_query")
            if entry.get("data", {}).get("manifest_hash") == self.manifest.content_hash
            and entry.get("data", {}).get("tier") == tier.value
            and entry.get("data", {}).get("candidate_id") == candidate_id
            and entry.get("data", {}).get("cycle_id") == cycle_id
        )

    def authorize_query(
        self,
        tier: TierName,
        *,
        candidate_id: str,
        cycle_id: str,
        purpose: QueryPurpose,
    ) -> CorpusQueryAuthorization:
        if not candidate_id or not cycle_id:
            raise ValueError("candidate_id and cycle_id are required")
        if tier is TierName.SEALED_PROMOTION and purpose != "promotion":
            raise PermissionError("sealed-promotion corpus is available only for promotion purpose")
        if tier is TierName.DELAYED_OUTCOME and purpose != "outcome":
            raise PermissionError("delayed-outcome corpus is available only for outcome purpose")
        if tier is TierName.PRIVATE_VALIDATION and purpose not in {"validation", "promotion"}:
            raise PermissionError("private-validation corpus requires validation or promotion purpose")
        if tier is TierName.ROTATING_FUTURE and purpose not in {"validation", "promotion"}:
            raise PermissionError("rotating-future corpus requires validation or promotion purpose")
        record = self.manifest.tier(tier)
        used = self._usage(tier, candidate_id, cycle_id)
        budget = record.query_budget_per_candidate_cycle
        if budget is not None and used >= budget:
            raise PermissionError(
                f"query budget exhausted for {tier.value}: candidate={candidate_id} cycle={cycle_id} budget={budget}"
            )
        usage = used + 1
        receipt_payload = {
            "manifest_hash": self.manifest.content_hash,
            "tier": tier.value,
            "candidate_id": candidate_id,
            "cycle_id": cycle_id,
            "purpose": purpose,
            "usage": usage,
            "item_root": _hash(sorted(item.artifact_digest for item in record.items)),
        }
        receipt = _hash(receipt_payload)
        self.wal.append("corpus_query", {**receipt_payload, "receipt": receipt, "items": len(record.items)})
        return CorpusQueryAuthorization(
            receipt=receipt,
            manifest_hash=self.manifest.content_hash,
            tier=tier,
            candidate_id=candidate_id,
            cycle_id=cycle_id,
            purpose=purpose,
            score_visibility=record.score_visibility,
            item_digests=tuple(item.artifact_digest for item in record.items),
            usage=usage,
            budget=budget,
        )


OBJECTIVE_DIMENSIONS = (
    "latency", "cost", "quality", "reliability", "coverage", "novelty",
    "safety_margin", "maintainability",
)


class HardMetrics(FrozenModel):
    escaped_defect_rate: float = Field(ge=0.0, le=1.0)
    irreversible_loss_risk: float = Field(ge=0.0, le=1.0)
    cost_usd: float = Field(ge=0.0)
    p99_latency_ms: float = Field(ge=0.0)
    tenant_leaks: int = Field(ge=0)
    c0_violations: int = Field(ge=0)
    ltl_violations: int = Field(ge=0)
    verification_failures: int = Field(ge=0)


class TaskOutcome(FrozenModel):
    task_id: str
    score: float = Field(ge=0.0, le=1.0)
    verified: bool
    evidence_refs: tuple[str, ...] = ()


class EvaluationReport(FrozenModel):
    candidate_id: str
    corpus_hash: str
    tier: TierName
    cycle_id: str
    query_receipt: str
    # Score comparisons are valid only within one evaluator definition. New
    # evaluators should set a content/version fingerprint; legacy callers are
    # explicitly labelled rather than silently pretending equivalence.
    evaluator_epoch: str = "legacy-unknown"
    dimensions: dict[str, float]
    hard_metrics: HardMetrics
    outcomes: tuple[TaskOutcome, ...]

    @field_validator("dimensions", mode="after")
    @classmethod
    def _dimensions(cls, value: dict[str, float]) -> dict[str, float]:
        if set(value) != set(OBJECTIVE_DIMENSIONS):
            raise ValueError(f"dimensions must be exactly {list(OBJECTIVE_DIMENSIONS)}")
        normalized = {key: float(value[key]) for key in OBJECTIVE_DIMENSIONS}
        if any(item < 0.0 or item > 1.0 for item in normalized.values()):
            raise ValueError("objective dimensions must be in [0,1]")
        return FrozenDict(normalized)

    @model_validator(mode="after")
    def _outcomes(self) -> "EvaluationReport":
        ids = [item.task_id for item in self.outcomes]
        if not self.candidate_id or not self.corpus_hash or not self.cycle_id or not self.query_receipt or not self.evaluator_epoch:
            raise ValueError("candidate, corpus, cycle, query receipt, and evaluator epoch are required")
        if not self.outcomes or len(ids) != len(set(ids)):
            raise ValueError("outcomes must be non-empty with unique task ids")
        return self

    @property
    def report_hash(self) -> str:
        return _hash(self.model_dump(mode="json"))


class ObjectivePolicy(FrozenModel):
    escaped_defect_rate_max: float = Field(default=0.02, ge=0.0, le=1.0)
    irreversible_loss_risk_max: float = Field(default=0.001, ge=0.0, le=1.0)
    cost_usd_max: float = Field(default=10.0, ge=0.0)
    p99_latency_ms_max: float = Field(default=120_000.0, ge=0.0)
    minimum_utility_gain: float = Field(default=0.01, ge=0.0)
    maximum_task_regression: float = Field(default=0.05, ge=0.0, le=1.0)
    minimum_tasks: int = Field(default=2, ge=1)
    weights: dict[str, float]

    @field_validator("weights", mode="after")
    @classmethod
    def _weights(cls, value: dict[str, float]) -> dict[str, float]:
        if set(value) != set(OBJECTIVE_DIMENSIONS):
            raise ValueError(f"weights must be exactly {list(OBJECTIVE_DIMENSIONS)}")
        normalized = {key: float(value[key]) for key in OBJECTIVE_DIMENSIONS}
        if any(item < 0 for item in normalized.values()) or sum(normalized.values()) <= 0:
            raise ValueError("objective weights must be non-negative with positive total")
        total = sum(normalized.values())
        return FrozenDict({key: item / total for key, item in normalized.items()})

    @classmethod
    def default(cls) -> "ObjectivePolicy":
        return cls(weights={
            "latency": 0.10, "cost": 0.10, "quality": 0.20, "reliability": 0.15,
            "coverage": 0.10, "novelty": 0.05, "safety_margin": 0.20,
            "maintainability": 0.10,
        })


class ConstraintViolation(FrozenModel):
    name: str
    limit: Any
    actual: Any
    reason: str


class PromotionDecision(FrozenModel):
    accepted: bool
    reason: str
    baseline_report: str
    challenger_report: str
    baseline_utility: float
    challenger_utility: float
    utility_gain: float
    violations: tuple[ConstraintViolation, ...] = ()

    @property
    def decision_hash(self) -> str:
        return _hash(self.model_dump(mode="json"))


EvidenceResolver = Callable[[str], bool]


class PromotionEvaluator:
    def __init__(self, policy: ObjectivePolicy, evidence_resolver: EvidenceResolver) -> None:
        self.policy = policy
        self.evidence_resolver = evidence_resolver

    def _utility(self, report: EvaluationReport) -> float:
        return sum(self.policy.weights[key] * report.dimensions[key] for key in OBJECTIVE_DIMENSIONS)

    def _violations(self, report: EvaluationReport) -> list[ConstraintViolation]:
        metrics = report.hard_metrics
        checks = (
            ("escaped_defect_rate", self.policy.escaped_defect_rate_max, metrics.escaped_defect_rate, "escaped defect bound exceeded"),
            ("irreversible_loss_risk", self.policy.irreversible_loss_risk_max, metrics.irreversible_loss_risk, "irreversible risk bound exceeded"),
            ("cost_usd", self.policy.cost_usd_max, metrics.cost_usd, "cost budget exceeded"),
            ("p99_latency_ms", self.policy.p99_latency_ms_max, metrics.p99_latency_ms, "latency target exceeded"),
            ("tenant_leaks", 0, metrics.tenant_leaks, "tenant leakage must be zero"),
            ("c0_violations", 0, metrics.c0_violations, "constitutional violations must be zero"),
            ("ltl_violations", 0, metrics.ltl_violations, "LTL violations must be zero"),
            ("verification_failures", 0, metrics.verification_failures, "verification failures must be zero"),
        )
        output = [
            ConstraintViolation(name=name, limit=limit, actual=actual, reason=reason)
            for name, limit, actual, reason in checks if actual > limit
        ]
        if len(report.outcomes) < self.policy.minimum_tasks:
            output.append(ConstraintViolation(
                name="minimum_tasks", limit=self.policy.minimum_tasks,
                actual=len(report.outcomes), reason="sealed evaluation has too few tasks",
            ))
        for outcome in report.outcomes:
            if not outcome.verified or not outcome.evidence_refs or not all(
                self.evidence_resolver(ref) for ref in outcome.evidence_refs
            ):
                output.append(ConstraintViolation(
                    name="evidence", limit="all outcomes verified with resolvable refs",
                    actual=outcome.task_id, reason="missing, unverified, or unresolvable task evidence",
                ))
        return output

    def compare(self, baseline: EvaluationReport, challenger: EvaluationReport) -> PromotionDecision:
        base_utility = self._utility(baseline)
        challenger_utility = self._utility(challenger)
        violations = [*self._violations(baseline), *self._violations(challenger)]
        if baseline.tier is not TierName.SEALED_PROMOTION or challenger.tier is not TierName.SEALED_PROMOTION:
            violations.append(ConstraintViolation(
                name="tier", limit=TierName.SEALED_PROMOTION.value,
                actual=f"{baseline.tier.value}/{challenger.tier.value}",
                reason="promotion requires sealed-promotion reports",
            ))
        for name, left, right in (
            ("corpus_hash", baseline.corpus_hash, challenger.corpus_hash),
            ("cycle_id", baseline.cycle_id, challenger.cycle_id),
            ("evaluator_epoch", baseline.evaluator_epoch, challenger.evaluator_epoch),
        ): 
            if left != right:
                violations.append(ConstraintViolation(
                    name=name, limit=left, actual=right, reason="null arm and challenger must share evaluation frame",
                ))
        base_tasks = {item.task_id: item for item in baseline.outcomes}
        challenge_tasks = {item.task_id: item for item in challenger.outcomes}
        if set(base_tasks) != set(challenge_tasks):
            violations.append(ConstraintViolation(
                name="task_set", limit=sorted(base_tasks), actual=sorted(challenge_tasks),
                reason="null arm and challenger task sets differ",
            ))
        else:
            for task_id, base in base_tasks.items():
                after = challenge_tasks[task_id]
                regression = base.score - after.score
                if regression > self.policy.maximum_task_regression:
                    violations.append(ConstraintViolation(
                        name="task_regression", limit=self.policy.maximum_task_regression,
                        actual=regression, reason=f"task {task_id} regression exceeds ceiling",
                    ))
        gain = challenger_utility - base_utility
        if violations:
            accepted = False
            reason = "hard constraint or evidence gate failed"
        elif gain < self.policy.minimum_utility_gain:
            accepted = False
            reason = (
                f"null-arm gain {gain:.6f} below required {self.policy.minimum_utility_gain:.6f}"
            )
        else:
            accepted = True
            reason = f"sealed constrained promotion accepted with utility gain {gain:.6f}"
        return PromotionDecision(
            accepted=accepted,
            reason=reason,
            baseline_report=baseline.report_hash,
            challenger_report=challenger.report_hash,
            baseline_utility=base_utility,
            challenger_utility=challenger_utility,
            utility_gain=gain,
            violations=tuple(violations),
        )


class ObjectiveTrace(FrozenModel):
    mechanism: str
    objective_clause: str
    owner: str
    evidence_refs: tuple[str, ...] = ()
    mutable: bool = True

    @property
    def trace_hash(self) -> str:
        return _hash(self.model_dump(mode="json"))


class ObjectiveTraceRegistry:
    def __init__(self, root: pathlib.Path, evidence_resolver: EvidenceResolver) -> None:
        self.root = pathlib.Path(root).resolve()
        self.path = self.root / ".chimera" / "objective" / "traces.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.evidence_resolver = evidence_resolver
        self.wal = WAL(self.root)

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        value = json.loads(self.path.read_text())
        if not isinstance(value, dict):
            raise ValueError("objective trace registry must contain an object")
        return value

    def _atomic_write(self, value: dict[str, Any]) -> None:
        temporary = self.path.with_name(f".{self.path.name}.{uuid.uuid4().hex}.tmp")
        try:
            with temporary.open("w") as handle:
                json.dump(value, handle, indent=2, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.path)
        finally:
            if temporary.exists():
                temporary.unlink()

    def register(self, trace: ObjectiveTrace) -> ObjectiveTrace:
        if not trace.mechanism or not trace.objective_clause or not trace.owner:
            raise ValueError("mechanism, objective clause, and owner are required")
        if not trace.evidence_refs or not all(self.evidence_resolver(ref) for ref in trace.evidence_refs):
            raise ValueError("objective trace requires resolvable evidence refs")
        rows = self._load()
        rows[trace.mechanism] = {**trace.model_dump(mode="json"), "trace_hash": trace.trace_hash}
        self._atomic_write(rows)
        self.wal.append("objective_trace", {
            "mechanism": trace.mechanism,
            "objective_clause": trace.objective_clause,
            "trace_hash": trace.trace_hash,
            "evidence_root": _hash(sorted(trace.evidence_refs)),
        })
        return trace

    def coverage(self, required_mechanisms: Iterable[str]) -> dict[str, Any]:
        rows = self._load()
        required = sorted(set(required_mechanisms))
        covered = [name for name in required if name in rows]
        return {
            "covered": covered,
            "missing": [name for name in required if name not in rows],
            "coverage": len(covered) / len(required) if required else 1.0,
            "registry_hash": _hash(rows),
        }


def _hash(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()
    return "sha256:" + hashlib.sha256(encoded).hexdigest()
