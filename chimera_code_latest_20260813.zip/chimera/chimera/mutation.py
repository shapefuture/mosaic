"""Bounded deterministic mutation testing for Python patch contracts."""
from __future__ import annotations
import ast,hashlib,pathlib,uuid
from dataclasses import dataclass
from typing import Any,Iterable
from .sandbox import Sandbox

@dataclass(frozen=True)
class Mutant:
    id:str;path:str;description:str;source:str
@dataclass(frozen=True)
class MutationResult:
    generated:int;killed:int;survived:int;kill_rate:float;survivors:tuple[str,...];evidence:tuple[dict[str,Any],...]

class MutationGenerator:
    @staticmethod
    def generate(path:str,source:str,limit:int=8)->list[Mutant]:
        tree=ast.parse(source,filename=path);candidates=[]
        for node in ast.walk(tree):
            if isinstance(node,ast.Compare) and len(node.ops)==1:candidates.append((node,"compare"))
            elif isinstance(node,ast.Constant) and isinstance(node.value,(bool,int)) and not isinstance(getattr(node,"parent",None),ast.Expr):candidates.append((node,"constant"))
            elif isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub)):candidates.append((node,"binop"))
        output=[]
        for target,(node,kind) in enumerate(candidates[:max(0,limit)]):
            current=-1
            class T(ast.NodeTransformer):
                def generic_visit(self,n):
                    nonlocal current
                    eligible=(isinstance(n,ast.Compare) and len(n.ops)==1) or (isinstance(n,ast.Constant) and isinstance(n.value,(bool,int))) or (isinstance(n,ast.BinOp) and isinstance(n.op,(ast.Add,ast.Sub)))
                    if eligible:
                        current+=1
                        if current==target:
                            if isinstance(n,ast.Compare):
                                mapping={ast.Eq:ast.NotEq,ast.NotEq:ast.Eq,ast.Lt:ast.GtE,ast.LtE:ast.Gt,ast.Gt:ast.LtE,ast.GtE:ast.Lt}
                                op=type(n.ops[0]);n.ops=[mapping.get(op,ast.NotEq)()]
                            elif isinstance(n,ast.Constant):n.value=(not n.value) if isinstance(n.value,bool) else n.value+1
                            elif isinstance(n,ast.BinOp):n.op=ast.Sub() if isinstance(n.op,ast.Add) else ast.Add()
                    return super().generic_visit(n)
            import copy
            mutated=T().visit(copy.deepcopy(tree));ast.fix_missing_locations(mutated);text=ast.unparse(mutated).strip()+"\n"
            if text==source:continue
            digest=hashlib.sha256(f"{path}:{target}:{text}".encode()).hexdigest()[:12]
            output.append(Mutant(f"mutant-{digest}",path,kind,text))
        return output

class RiskRanker:
    """Cheap deterministic mutation budget allocator.

    Mutation is most valuable on access-control, financial, persistence, and
    public API code. Ranking avoids spending a fixed mutation budget on docs or
    low-impact glue merely because it changed.
    """
    KEYWORDS=("auth","permission","security","token","credential","payment","billing","tenant","account","policy","acl","access")
    @classmethod
    def rank(cls,paths:Iterable[str],task:str)->list[tuple[str,int]]:
        task_l=task.lower();rows=[]
        for path in paths:
            lower=str(path).lower();score=sum(3 for key in cls.KEYWORDS if key in lower)+sum(1 for key in cls.KEYWORDS if key in task_l)
            if lower.endswith(".py"):score+=1
            if "/tests/" in f"/{lower}":score-=2
            rows.append((str(path),score))
        return sorted(rows,key=lambda row:(-row[1],row[0]))

class MutationVerifier:
    def __init__(self,root:pathlib.Path,workspace,capability):self.root=pathlib.Path(root);self.workspace=workspace;self.capability=capability
    def evaluate(self,branch:str,paths:Iterable[str],test_command:str,max_mutants:int=8)->MutationResult:
        mutants=[]
        for path in paths:
            if path.endswith(".py"):
                try:source=self.workspace.read(branch,path).decode()
                except Exception:continue
                mutants.extend(MutationGenerator.generate(path,source,max(0,max_mutants-len(mutants))))
            if len(mutants)>=max_mutants:break
        killed=0;survivors=[];evidence=[]
        for mutant in mutants:
            child=f"mut-{uuid.uuid4().hex[:10]}";self.workspace.fork(child,branch);self.workspace.write(child,mutant.path,mutant.source)
            result=Sandbox(self.root,self.capability,branch=child,workspace=self.workspace).exec(test_command,timeout=120)
            dead=result.status!=0;killed+=int(dead)
            if not dead:survivors.append(mutant.id)
            evidence.append({"id":mutant.id,"path":mutant.path,"operator":mutant.description,"killed":dead,"status":result.status,"backend":result.evidence.get("backend")})
            self.workspace.abort(child)
        total=len(mutants)
        return MutationResult(total,killed,total-killed,(killed/total if total else 1.0),tuple(survivors),tuple(evidence))
