"""Compatibility imports for coder mixins split out of RLMRuntime."""
from __future__ import annotations

from .rlm_coder_focused import RLMFocusedCoderMixin
from .rlm_coder_cohesive import RLMCohesiveCoderMixin


class RLMCoderMixin(RLMFocusedCoderMixin, RLMCohesiveCoderMixin):
    pass
