"""Focused-coder prompt and typed context construction."""
from __future__ import annotations

from typing import Any, Dict, Optional

from .code_execution_prompt_policy import (
    CODE_EXECUTION_VERDICT_POLICY,
    COMPACT_CODE_EXECUTION_VERDICT_POLICY,
)
from .quality import ChangeTarget, TaskContract
from .project_forge_prompt_policy import (
    COMPACT_PROJECT_FORGE_CODING_POLICY,
    PROJECT_FORGE_CODING_POLICY,
    should_apply_project_forge_policy,
)


class FocusedPromptMixin:
        def _target_prompt(self, contract: TaskContract, target: ChangeTarget, interface_context: str,
                           repair: Optional[Dict[str, Any]] = None, model: str = "unknown",
                           context_mode: str = "standard") -> str:
            if context_mode not in {"standard", "micro"}:
                raise ValueError("context_mode must be standard or micro")
            current = ""
            if target.mode == "edit" and (self.root / target.path).exists():
                source = self.workspace.read("main", target.path).decode("utf-8", errors="ignore") if "main" in self.workspace.list_branches() else (self.root / target.path).read_text()
                # Imports + command-registration tail are more valuable than the
                # middle of a large CLI module.
                current = source if len(source) <= 18_000 else source[:5_000] + "\n...[middle omitted]...\n" + source[-12_000:]
            repair_block = ""
            if repair:
                hint_text = ""
                if repair.get("repair_hints"):
                    hint_text = "\nREPAIR HINTS (derived from pytest; still verify against tests):\n" + "\n".join(f"- {item}" for item in repair.get("repair_hints", [])) + "\n"
                if repair.get("repair_anchors"):
                    hint_text += "Anchors: " + ", ".join(str(item) for item in repair.get("repair_anchors", [])) + "\n"
                repair_block = (
                    f"\nFAILED TEST EVIDENCE (fix the root cause):\nstatus={repair.get('status')}\n"
                    f"stdout:\n{repair.get('stdout', '')[-4_000:]}\nstderr:\n{repair.get('stderr', '')[-4_000:]}\n"
                    + hint_text
                )
            if target.mode == "create":
                output_contract = (
                    f"- summary: a short string\n"
                    f"- files: a list with exactly one object; path must equal {target.path!r}; content must be the complete executable source code\n"
                    f"- edits: an empty list\n- insertions: an empty list"
                )
                required_symbols = contract.required_symbols.get(target.path, [])
                mode_instruction = (
                    "Generate a small complete production module (prefer <=120 lines; never exceed 180). "
                    "Use direct top-level functions, not a new framework or orchestration class. "
                    "Do not invoke pytest or the acceptance test suite from production code—the harness runs tests externally. "
                    f"Define these symbols at module top level: {required_symbols or ['as required by tests']}."
                )
            else:
                output_contract = (
                    f"- summary: a short string\n- files: an empty list\n"
                    f"- edits: a list of objects with path={target.path!r}, an exact unique find string, and its replacement; OR\n"
                    f"- insertions: a list with path={target.path!r}, exact anchor, position before/after, and insertion content"
                )
                mode_instruction = "Return only minimal exact edits or an insertion. Never replace this large file wholesale."
            forge_policy = ""
            if should_apply_project_forge_policy(contract.prompt()):
                forge_policy = (COMPACT_PROJECT_FORGE_CODING_POLICY if context_mode == "micro" else PROJECT_FORGE_CODING_POLICY) + "\n"
            if context_mode == "micro":
                # The static gate owns syntax/scope/protected-test enforcement. A
                # short, exact envelope instruction avoids spending model tokens
                # re-describing empty lists and prose prohibitions on every small
                # task while retaining the closed patch shape.
                required = (
                    f"JSON PATCH ONLY. target={target.path} mode={target.mode}. "
                    "Use compact wire {\"f\":{path:complete_source},\"e\":[{\"p\":path,\"o\":old,\"n\":new}]}; "
                    "omit an empty f or e. Use only the target path; write real code, no tests/commands/prose. "
                    f"{COMPACT_CODE_EXECUTION_VERDICT_POLICY} "
                    f"{forge_policy}"
                    f"{mode_instruction}\n{contract.compact_prompt()}\n"
                )
            else:
                required = (
                    "RETURN ONLY ONE VALID JSON OBJECT. NO PROSE, MARKDOWN, TOOL CALLS, OR ELLIPSES.\n"
                    f"You are implementing exactly one target: {target.path} ({target.mode}).\n"
                    f"{CODE_EXECUTION_VERDICT_POLICY}\n"
                    f"{forge_policy}"
                    f"{mode_instruction}\nOUTPUT OBJECT REQUIREMENTS (instructions, not literal values):\n{output_contract}\n"
                    "The object must have exactly these top-level keys: summary, files, edits, insertions.\n"
                    "Do not copy requirement phrases such as 'complete source' into a value. Write the actual code.\n\n"
                    f"{contract.prompt()}\n\n"
                )
            from .context_memory import structural_page
            from .context_pack import ContextPackBuilder
            from .typed_context import (
                ContextKind, ContextSensitivity, ContextTrust, TypedContextCompiler, TypedContextItem,
            )
            current_compact = structural_page(target.path, current).text if current else ""
            items = [
                TypedContextItem(
                    "required", ContextKind.POLICY, ContextTrust.POLICY, required,
                    source_ref="task-contract", priority="required", required=True, preserve=True, order=0,
                ),
            ]
            audited_state = getattr(self._thread_local, "audited_task_state", None)
            if audited_state is not None and getattr(audited_state, "revision", 0) > 0:
                state_text = audited_state.context()
                items.append(TypedContextItem(
                    "audited-continuation", ContextKind.ARTIFACT, ContextTrust.VERIFIED,
                    "AUDITED CONTINUATION STATE (environment-derived only):\n" + state_text,
                    compact=state_text, source_ref="audited-task-state-wal", priority="high", order=1,
                ))
            # Do not spend a context slot on an empty label in the micro create
            # path. Non-empty verified interfaces/current source and repair
            # evidence keep their existing typed provenance and priority.
            if interface_context:
                items.append(TypedContextItem(
                    "interfaces", ContextKind.INTERFACE, ContextTrust.VERIFIED,
                    f"RELEVANT VERIFIED INTERFACES:\n{interface_context}\n\n",
                    compact=f"RELEVANT INTERFACE SUMMARY:\n{interface_context[:3000]}\n\n",
                    source_ref="verified-interfaces", priority="high", order=1,
                ))
            if current:
                items.append(TypedContextItem(
                    "current", ContextKind.WORKSPACE, ContextTrust.VERIFIED,
                    f"CURRENT TARGET CONTENT:\n{current}\n",
                    compact=f"CURRENT TARGET STRUCTURE:\n{current_compact}\n",
                    source_ref=f"workspace:{target.path}", snapshot_id=self.workspace.diff(branch="main").get("id", "") if "main" in self.workspace.list_branches() else "",
                    priority="high", order=2,
                ))
            if repair_block:
                items.append(TypedContextItem(
                    "repair", ContextKind.TEST_EVIDENCE, ContextTrust.UNTRUSTED, repair_block,
                    compact=repair_block[-2500:], source_ref="materialized-test-output",
                    sensitivity=ContextSensitivity.SECRET_SHAPED, priority="required", required=True, order=3,
                ))
            items.append(TypedContextItem(
                "closing", ContextKind.POLICY, ContextTrust.POLICY, "\nOUTPUT JSON ONLY.",
                source_ref="patch-output-contract", priority="required", required=True, preserve=True, order=4,
            ))
            builder = self._context_pack_builders.get(model)
            if builder is None:
                builder = ContextPackBuilder(model)
                self._context_pack_builders[model] = builder
            typed = TypedContextCompiler(self.retrieved_content_guard).compile(
                items, builder=builder, max_tokens=self.config.planner.context_max_tokens,
                max_chars=self.config.planner.context_max_chars,
            )
            selection = typed.selection
            self._thread_local.last_context_pack = {
                "tokens": selection.tokens, "chars": selection.chars,
                "token_kind": selection.token_kind,
                "decisions": [item.__dict__ for item in selection.decisions],
                "typed_manifest": typed.manifest_dict(),
            }
            return selection.text
