"""Measured off-critical-path primitives; disabled by default until useful."""
from __future__ import annotations
import concurrent.futures, threading, time
from dataclasses import dataclass
from typing import Any, Callable

@dataclass(frozen=True)
class SpeculationMetrics:
 submitted:int;hits:int;cancellations:int;failures:int;usefulness:float

class SpeculationPolicy:
 def __init__(self,min_usefulness:float=.70,max_cancellations:float=.30):self.min_usefulness=min_usefulness;self.max_cancellations=max_cancellations
 def promote(self,metrics:SpeculationMetrics)->bool:
  return metrics.submitted>0 and metrics.usefulness>=self.min_usefulness and metrics.cancellations/metrics.submitted<=self.max_cancellations and metrics.failures==0

class ReadOnlySpeculator:
 def __init__(self,max_active:int=1):
  self.pool=concurrent.futures.ThreadPoolExecutor(max_workers=max(1,max_active),thread_name_prefix='chimera-spec')
  self.rows={};self.lock=threading.Lock();self.submitted=self.hits=self.cancellations=self.failures=0
 def submit(self,key:str,producer:Callable[[],Any])->bool:
  with self.lock:
   if key in self.rows:return False
   self.rows[key]=self.pool.submit(producer);self.submitted+=1;return True
 def take(self,key:str):
  with self.lock:future=self.rows.pop(key,None)
  if future is None:return None
  if not future.done():
   future.cancel();self.cancellations+=1;return None
  try:self.hits+=1;return future.result()
  except Exception:self.failures+=1;return None
 def metrics(self):
  useful=self.hits/max(1,self.submitted)
  return SpeculationMetrics(self.submitted,self.hits,self.cancellations,self.failures,useful)
 def close(self):self.pool.shutdown(wait=False,cancel_futures=True)
