"""MCP CLI commands."""
from __future__ import annotations

import pathlib
import sys

import click


def register(main: click.Group, *, console, cli_context, cli_state, cli_config, tenant_transport_root) -> None:
    _cli_context = cli_context
    _cli_state = cli_state
    _cli_config = cli_config
    _tenant_transport_root = tenant_transport_root

    @main.group()
    def mcp():
        pass

    @mcp.command("serve")
    @click.option("--workspace", default=".")
    @click.option("--tenant-id", default=None)
    @click.option("--principal", default=None)
    @click.option("--authorization-file", type=click.Path(path_type=pathlib.Path), default=None)
    @click.option("--trusted-key-id", "trusted_key_ids", multiple=True)
    def mcp_serve(workspace, tenant_id, principal, authorization_file, trusted_key_ids):
        from .bootstrap import build_local_application, new_run_context
        from .mcp_server import MCPServer, serve_stdio

        cache = {}
        def context_factory():
            # Resolve and reauthorize on every request so grant expiry/revocation is
            # not hidden by a long-lived stdio process.
            root, tenant_context = _tenant_transport_root(
                workspace, tenant_id, principal, authorization_file, trusted_key_ids, "mcp",
            )
            key = str(root.resolve())
            if key not in cache:
                cache[key] = build_local_application(root)
            application, composition = cache[key]
            values = tenant_context.model_dump(mode="json") if tenant_context is not None else {}
            context = new_run_context(
                profile=composition.config.deployment_profile,
                deadline_seconds=_cli_state().get("deadline_seconds", 1_800.0),
                trace_id=_cli_state().get("trace_id"),
                tenant_key=values.get("tenant_key"),
                principal_hash=values.get("principal_hash"),
                grant_digest=values.get("grant_digest"),
                max_input_tokens=composition.config.planner.context_max_tokens,
            )
            return application, context

        initial_root, _ = _tenant_transport_root(
            workspace, tenant_id, principal, authorization_file, trusted_key_ids, "mcp",
        )
        server = MCPServer(context_factory, root=initial_root)
        console.print("[cyan]MCP server starting on stdio...[/cyan]", file=sys.stderr)
        serve_stdio(initial_root, server=server)


    @mcp.command("serve-http")
    @click.option("--workspace", default=".")
    @click.option("--host", default="127.0.0.1", show_default=True)
    @click.option("--port", type=click.IntRange(1, 65535), default=8765, show_default=True)
    @click.option("--allow-origin", "allowed_origins", multiple=True, required=True)
    @click.option("--trusted-key-id", "trusted_key_ids", multiple=True, required=True)
    def mcp_serve_http(workspace, host, port, allowed_origins, trusted_key_ids):
        """Serve authenticated development Streamable HTTP; cloud needs a shared-state factory."""
        try:
            import uvicorn
        except ImportError as exc:
            raise click.UsageError("install the mcp-http or restate-adapter extra for uvicorn") from exc
        from .bootstrap import build_local_application
        from .config import DeploymentProfile
        from .mcp_server import (
            MCPStreamableHTTPApplication,
            SignedGrantHTTPContextResolver,
        )

        resolver = SignedGrantHTTPContextResolver(
            pathlib.Path(workspace),
            trusted_key_ids=set(trusted_key_ids),
            profile=DeploymentProfile.DEV_EXTERNAL,
            application_factory=lambda root: build_local_application(root)[0],
        )
        application = MCPStreamableHTTPApplication(
            pathlib.Path(workspace),
            resolver,
            allowed_origins=set(allowed_origins),
        )
        console.print(
            "[cyan]Authenticated MCP Streamable HTTP development adapter starting...[/cyan]",
            file=sys.stderr,
        )
        uvicorn.run(application, host=host, port=port, log_level="info")


    @mcp.command("proxy")
    @click.option("--workspace", default=".")
    @click.option("--tenant-id", default=None)
    @click.option("--principal", default=None)
    @click.option("--authorization-file", type=click.Path(path_type=pathlib.Path), default=None)
    @click.option("--trusted-key-id", "trusted_key_ids", multiple=True)
    @click.option("--allow-tool", "allowed_tools", multiple=True, required=True)
    @click.argument("command", nargs=-1, required=True)
    def mcp_proxy(workspace, tenant_id, principal, authorization_file, trusted_key_ids, allowed_tools, command):
        """Wrap a third-party stdio MCP server with allowlists, GCF, and WAL evidence."""
        from .mcp_proxy import GCFMCPProxy, MCPSubprocessClient, serve_proxy_stdio
        root, _tenant_context = _tenant_transport_root(
            workspace, tenant_id, principal, authorization_file, trusted_key_ids, "mcp",
        )
        upstream = MCPSubprocessClient(command)
        proxy = GCFMCPProxy(root, upstream, allowed_tools=allowed_tools)
        console.print("[cyan]MCP GCF proxy starting on stdio...[/cyan]", file=sys.stderr)
        serve_proxy_stdio(proxy)


    @mcp.command("proxy-remote")
    @click.option("--workspace", default=".")
    @click.option("--tenant-id", default=None)
    @click.option("--principal", default=None)
    @click.option("--authorization-file", type=click.Path(path_type=pathlib.Path), default=None)
    @click.option("--trusted-key-id", "trusted_key_ids", multiple=True)
    @click.option("--url", "endpoint", required=True, help="HTTPS Streamable-HTTP MCP endpoint")
    @click.option("--allow-tool", "allowed_tools", multiple=True, required=True)
    @click.option("--pin-manifest", default=None, help="Optional SHA-256 manifest pin; fail closed on drift")
    @click.option("--pin-tool", "pinned_tools", multiple=True, help="Optional NAME=sha256:<digest> tool pin (repeatable)")
    @click.option("--timeout", "timeout_seconds", default=30.0, type=click.FloatRange(min=0.1, max=600.0))
    def mcp_proxy_remote(workspace, tenant_id, principal, authorization_file, trusted_key_ids, endpoint, allowed_tools, pin_manifest, pinned_tools, timeout_seconds):
        """Expose an explicit remote MCP endpoint through the same GCF proxy policy.

        No OAuth/DCR credential flow is performed or persisted. The caller must
        name every tool it permits; an optional operator pin locks the observed
        remote catalog to a known manifest/schema contract.
        """
        from urllib.parse import urlparse
        from .bootstrap import ProfileEgressPolicy, profile_policy
        from .mcp_proxy import GCFMCPProxy, serve_proxy_stdio
        from .mcp_remote import MCPRemoteHTTPClient, MCPStreamableHTTPUpstream
        from .mcp_health import MCPHealthLedger
        policy = profile_policy(_cli_config().deployment_profile)
        if not policy.allow_remote_mcp:
            raise click.UsageError(
                f"{policy.profile.value} denies remote MCP; select an explicit external profile"
            )
        host = (urlparse(endpoint).hostname or "").lower().rstrip(".")
        egress = ProfileEgressPolicy(policy, allowed_hosts={host})
        egress.authorize(endpoint)
        root, _tenant_context = _tenant_transport_root(
            workspace, tenant_id, principal, authorization_file, trusted_key_ids, "mcp",
        )
        pins = {}
        for item in pinned_tools:
            if "=" not in item:
                raise click.UsageError("--pin-tool requires NAME=sha256:<digest>")
            name, digest = item.split("=", 1)
            if not name or not digest.startswith("sha256:"):
                raise click.UsageError("--pin-tool requires NAME=sha256:<digest>")
            if name in pins:
                raise click.UsageError(f"duplicate --pin-tool name: {name}")
            pins[name] = digest
        client = MCPRemoteHTTPClient(
            endpoint, timeout_seconds=timeout_seconds,
            expected_manifest_hash=pin_manifest, expected_tool_hashes=pins,
            health_ledger=MCPHealthLedger(root),
            egress=egress,
        )
        upstream = MCPStreamableHTTPUpstream(client)
        proxy = GCFMCPProxy(
            root, upstream, allowed_tools=allowed_tools,
            pinned_manifest_hash=pin_manifest, pinned_tool_hashes=pins,
        )
        console.print("[cyan]Remote MCP GCF proxy starting on stdio...[/cyan]", file=sys.stderr)
        serve_proxy_stdio(proxy)

