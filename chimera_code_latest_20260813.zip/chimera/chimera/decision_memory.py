"""Read-only BM25 decision memory with graph-root freshness quarantine."""
from __future__ import annotations
import hashlib,json,math,pathlib,re,time
from dataclasses import dataclass
from typing import Any,Iterable
from .wal import WAL

@dataclass(frozen=True)
class Decision:
    id:str;summary:str;rationale:str;references:tuple[str,...];evidence_refs:tuple[str,...];created_at:str
class DecisionMemory:
    def __init__(self,root:pathlib.Path):self.root=pathlib.Path(root).resolve();self.path=self.root/".chimera"/"decisions.jsonl";self.path.parent.mkdir(parents=True,exist_ok=True);self.wal=WAL(self.root)
    def append(self,summary:str,rationale:str,references:Iterable[str],evidence_refs:Iterable[str]):
        refs=tuple(references);evidence=tuple(evidence_refs)
        if not summary or not rationale or not evidence:raise ValueError("decision requires summary, rationale, and evidence")
        payload={"summary":summary,"rationale":rationale,"references":refs,"evidence_refs":evidence,"created_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())}
        did="decision:"+hashlib.sha256(json.dumps(payload,sort_keys=True,default=str).encode()).hexdigest();row={"id":did,**payload}
        with self.path.open("a") as h:h.write(json.dumps(row,sort_keys=True)+"\n")
        self.wal.append("decision_memory",{"id":did,"evidence_root":"sha256:"+hashlib.sha256(json.dumps(sorted(evidence)).encode()).hexdigest()});return Decision(did,summary,rationale,refs,evidence,payload["created_at"])
    def list(self):
        if not self.path.exists():return []
        return [Decision(id=r["id"],summary=r["summary"],rationale=r["rationale"],references=tuple(r["references"]),evidence_refs=tuple(r["evidence_refs"]),created_at=r["created_at"]) for r in map(json.loads,self.path.read_text().splitlines()) if r]
    @staticmethod
    def _tokens(text):return re.findall(r"[a-z0-9_]{2,}",text.lower())
    def _fresh(self,d:Decision):
        stale=[]
        for ref in d.references:
            path=ref.split("#",1)[0]
            if path and not (self.root/path).exists():stale.append(ref)
        return stale
    def search(self,query:str,limit:int=5):
        docs=self.list();q=self._tokens(query);n=len(docs);out=[]
        for d in docs:
            toks=self._tokens(d.summary+" "+d.rationale+" "+" ".join(d.references));score=0
            for term in q:
                df=sum(term in self._tokens(x.summary+" "+x.rationale+" "+" ".join(x.references)) for x in docs);idf=math.log((n+1)/(df+1))+1;score+=toks.count(term)*idf
            stale=self._fresh(d);out.append({"decision":d,"score":score,"status":"quarantined-stale" if stale else "fresh","stale_refs":stale})
        return sorted((x for x in out if x["score"]>0),key=lambda x:(-x["score"],x["decision"].id))[:limit]
    def render(self,query:str,max_chars:int=3000):
        lines=[]
        for hit in self.search(query):
            d=hit["decision"];lines.append(f"[{hit['status']}] {d.id} {d.summary} refs={','.join(d.references)}")
        return "\n".join(lines)[:max_chars]
