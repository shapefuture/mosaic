"""Typed, snapshot-bound context packs with late materialization receipts.

The model-facing prompt remains text, but the runtime should not forget whether
that text came from a policy, verified workspace file, test failure, user input,
or untrusted remote result.  This module compiles such items through Chimera's
existing token-budgeted ``ContextPackBuilder`` and emits a raw-content-free
manifest for evidence and later diagnosis.

It is deliberately not an embedding store or semantic response cache.  Exact
content hashes/snapshot IDs and bounded materialization are the authority.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import StrEnum
import hashlib
from typing import Any, Iterable

from .context_pack import ContextPack, ContextPackBuilder, ContextSelection
from .context_quarantine import RetrievedContentGuard


class ContextKind(StrEnum):
    POLICY = "policy"
    WORKSPACE = "workspace"
    INTERFACE = "interface"
    DIFF = "diff"
    TEST_EVIDENCE = "test_evidence"
    TOOL_RESULT = "tool_result"
    ARTIFACT = "artifact"
    USER = "user"
    REMOTE = "remote"
    OTHER = "other"


class ContextTrust(StrEnum):
    POLICY = "policy"
    VERIFIED = "verified"
    USER = "user"
    UNTRUSTED = "untrusted"


class ContextSensitivity(StrEnum):
    NORMAL = "normal"
    SECRET_SHAPED = "secret_shaped"
    RESTRICTED = "restricted"


@dataclass(frozen=True)
class TypedContextItem:
    id: str
    kind: ContextKind
    trust: ContextTrust
    full: str
    compact: str = ""
    source_ref: str = ""
    snapshot_id: str = ""
    sensitivity: ContextSensitivity = ContextSensitivity.NORMAL
    priority: str = "medium"
    required: bool = False
    preserve: bool = False
    order: int = 0

    @property
    def content_hash(self) -> str:
        return "sha256:" + hashlib.sha256(self.full.encode("utf-8", errors="replace")).hexdigest()


@dataclass(frozen=True)
class ContextManifestItem:
    id: str
    kind: str
    trust: str
    sensitivity: str
    source_ref: str
    snapshot_id: str
    content_hash: str
    full_chars: int
    compact_chars: int
    status: str
    reason: str | None


@dataclass(frozen=True)
class TypedContextSelection:
    selection: ContextSelection
    manifest: tuple[ContextManifestItem, ...]

    def manifest_dict(self) -> list[dict[str, Any]]:
        return [asdict(item) for item in self.manifest]


class TypedContextCompiler:
    def __init__(self, guard: RetrievedContentGuard | None = None) -> None:
        self.guard = guard or RetrievedContentGuard()

    def compile(
        self,
        items: Iterable[TypedContextItem],
        *,
        builder: ContextPackBuilder,
        max_tokens: int,
        max_chars: int,
    ) -> TypedContextSelection:
        ordered = list(items)
        if len({item.id for item in ordered}) != len(ordered):
            raise ValueError("typed context item IDs must be unique")
        packs: list[ContextPack] = []
        provisional: dict[str, ContextManifestItem] = {}
        for item in ordered:
            if not item.id:
                raise ValueError("typed context item requires ID")
            full, compact = item.full, item.compact
            status, reason = "candidate", None
            # Policy and verified workspace evidence are not treated as remote
            # instructions. Untrusted results are inspected before they can
            # re-enter a model context, while raw bytes remain available via
            # their existing artifact/source reference.
            if item.trust is ContextTrust.UNTRUSTED:
                decision = self.guard.inspect(full, source=item.source_ref or item.id)
                if decision.quarantined:
                    full = decision.placeholder
                    compact = decision.placeholder
                    status = "quarantined"
                    reason = ",".join(decision.reasons)
            packs.append(ContextPack(
                id=item.id, full=full, compact=compact, priority=item.priority,
                required=item.required, preserve=item.preserve, order=item.order,
            ))
            provisional[item.id] = ContextManifestItem(
                id=item.id, kind=item.kind.value, trust=item.trust.value,
                sensitivity=item.sensitivity.value, source_ref=item.source_ref,
                snapshot_id=item.snapshot_id, content_hash=item.content_hash,
                full_chars=len(item.full), compact_chars=len(item.compact),
                status=status, reason=reason,
            )
        selection = builder.build(packs, max_tokens=max_tokens, max_chars=max_chars)
        decisions = {item.id: item for item in selection.decisions}
        manifest: list[ContextManifestItem] = []
        for item in ordered:
            prior = provisional[item.id]
            decision = decisions[item.id]
            if prior.status == "quarantined":
                manifest.append(prior)
            else:
                manifest.append(ContextManifestItem(
                    **{**asdict(prior), "status": decision.status, "reason": decision.reason}
                ))
        return TypedContextSelection(selection, tuple(manifest))
