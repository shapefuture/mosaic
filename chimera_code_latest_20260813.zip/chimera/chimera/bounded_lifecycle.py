"""Bounded explicit-state checks for the declared local run lifecycle model.

This is deliberately a model check of a *small transition table*, not a proof
about threads, remote endpoints, or the production scheduler.  It gives the
reducer migration a checkable safety/liveness gate and counterexamples while
keeping authority with the existing runtime and verifier.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Iterable, Mapping


@dataclass(frozen=True)
class LifecycleModelReport:
    bound: int
    safety_holds: bool
    liveness_holds_under_progress_assumption: bool
    terminal_reachable: tuple[str, ...]
    counterexamples: tuple[str, ...]

    def as_dict(self) -> dict:
        return asdict(self)


class BoundedLifecycleModelChecker:
    """Enumerate the finite action-state graph and report unsafe cycles.

    The liveness conclusion is explicitly conditional: a scheduler must keep
    selecting enabled transitions. An external tool can still hang, a worker
    can starve, and a real deployment can violate that assumption.
    """

    def __init__(self, *, initial: str = "proposed", terminal: Iterable[str] = ("completed", "failed", "rejected", "cancelled")) -> None:
        self.initial = str(initial)
        self.terminal = frozenset(map(str, terminal))

    def verify(self, allowed: Mapping[str, Iterable[str]], *, bound: int = 8) -> LifecycleModelReport:
        if bound < 1:
            raise ValueError("bound must be positive")
        graph = {str(state): tuple(sorted(map(str, next_states))) for state, next_states in allowed.items()}
        counterexamples: list[str] = []
        if self.initial in self.terminal:
            counterexamples.append("initial state is terminal")
        for state in self.terminal:
            if graph.get(state):
                counterexamples.append(f"terminal state {state} has outgoing transitions")

        reachable: set[str] = {self.initial}
        frontier = {self.initial}
        for _ in range(bound):
            next_frontier: set[str] = set()
            for state in frontier:
                for target in graph.get(state, ()):
                    if target not in reachable:
                        reachable.add(target)
                        next_frontier.add(target)
            frontier = next_frontier
            if not frontier:
                break
        reachable_terminals = tuple(sorted(reachable & self.terminal))
        if not reachable_terminals:
            counterexamples.append(f"no terminal state is reachable within bound {bound}")

        # A reachable non-terminal cycle is a liveness counterexample unless a
        # stronger external fairness/progress premise rules it out. Detect it
        # by bounded DFS paths; this is intentionally small and transparent.
        def has_cycle(state: str, path: tuple[str, ...]) -> bool:
            if len(path) >= bound or state in self.terminal:
                return False
            for target in graph.get(state, ()):
                if target in self.terminal:
                    continue
                if target in path:
                    counterexamples.append("reachable non-terminal cycle: " + "->".join((*path, target)))
                    return True
                if has_cycle(target, (*path, target)):
                    return True
            return False

        cycle = has_cycle(self.initial, (self.initial,))
        safety_holds = not any(
            message.startswith("initial state") or message.startswith("terminal state")
            for message in counterexamples
        )
        liveness = bool(reachable_terminals) and not cycle
        return LifecycleModelReport(
            bound=bound, safety_holds=safety_holds,
            liveness_holds_under_progress_assumption=liveness,
            terminal_reachable=reachable_terminals, counterexamples=tuple(dict.fromkeys(counterexamples)),
        )
