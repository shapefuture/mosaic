"""Fault-aware pheromone routing and evidence-calibrated coordination-mode choice."""
from __future__ import annotations
import hashlib,json,time
from typing import Iterable,Literal,Mapping,Optional
from pydantic import BaseModel,ConfigDict,Field
from .capability_calibration import ContextualCapabilityRegistry
from .stigmergy import StigmergicField
class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
class RouteChoice(FrozenModel):agent_id:str;score:float;reason:str;signals:dict[str,float]
class CoordinationFeatures(FrozenModel):
    agent_count:int=Field(ge=1);independent_subgoals:int=Field(ge=0);coupling:float=Field(ge=0,le=1);trace_coverage:float=Field(ge=0,le=1);shared_mutable_state:bool=False
class ModeChoice(FrozenModel):mode:Literal["individual","hierarchical","stigmergic","hybrid"];reason:str;calibrated:bool
class FaultAwareStigmergyRouter:
    def __init__(self,field:StigmergicField,half_life_seconds:float=300.):self.field=field;self.half=max(1.,float(half_life_seconds))
    @staticmethod
    def _region(cluster,agent,status):return f"route:{cluster}:{agent}:{status}"
    def record(self,cluster:str,agent_id:str,status:Literal["success","failure","timeout","invalid"],evidence_refs:Iterable[str],*,now:Optional[float]=None):
        accepted=status=="success";kind="success" if accepted else "fault";confidence=1. if status in {"success","failure"} else .8
        self.field.deposit("routing",self._region(cluster,agent_id,kind),agent_id,confidence,evidence_refs,half_life_seconds=self.half,metadata={"status":status},now=now);self.field.record_outcome("routing",agent_id,accepted,evidence_refs)
    def choose(self,cluster:str,agents:Iterable[str],*,now:Optional[float]=None)->RouteChoice:
        current=time.time() if now is None else float(now);signals={item.region:item.effective_signal for item in self.field.signals("routing",limit=10000,now=current)};rows=[]
        for agent in agents:
            success=signals.get(self._region(cluster,agent,"success"),0.);fault=signals.get(self._region(cluster,agent,"fault"),0.);trust,count=self.field.trust("routing",agent);score=success-fault+.25*trust;rows.append((score,agent,{"success":success,"fault":fault,"trust_lcb":trust,"trust_samples":float(count)}))
        if not rows:raise ValueError("routing agent pool is empty")
        score,agent,detail=max(rows,key=lambda item:(item[0],item[1]));return RouteChoice(agent_id=agent,score=score,reason="decayed success pressure minus fault pressure plus behavior-trust lower bound",signals=detail)
class CoordinationModeSelector:
    """Hierarchy is the safe default; stigmergy must earn mode-specific evidence."""
    MODES=("individual","hierarchical","stigmergic","hybrid")
    def __init__(self,registry:Optional[ContextualCapabilityRegistry]=None):self.registry=registry
    @staticmethod
    def _features(value:CoordinationFeatures):return value.model_dump(mode="json")
    def choose(self,features:CoordinationFeatures)->ModeChoice:
        if features.agent_count==1:return ModeChoice(mode="individual",reason="single executor",calibrated=False)
        if features.shared_mutable_state or features.coupling>.3:
            return ModeChoice(mode="hierarchical",reason="tight coupling/shared mutation requires explicit authority and dependencies",calibrated=False)
        if features.independent_subgoals<8:
            allowed=("hierarchical","hybrid");fallback="hierarchical";reason="small task count does not amortize decentralized coordination"
        elif features.trace_coverage>=.2 and features.agent_count>=4:
            allowed=("stigmergic","hybrid","hierarchical");fallback="hybrid";reason="wide weakly-coupled work has enough trace coverage for bounded stigmergy"
        else:
            allowed=("hierarchical","hybrid");fallback="hybrid";reason="trace substrate not dense enough for stigmergy-only mode"
        if self.registry is not None:
            choice=self.registry.choose(allowed,"coordination-mode",self._features(features),task_value=1.)
            if choice.posterior.samples>=5:return ModeChoice(mode=choice.agent_id,reason="evidence-backed contextual mode posterior",calibrated=True)
        return ModeChoice(mode=fallback,reason=reason,calibrated=False)
    def record(self,mode:str,features:CoordinationFeatures,success:bool,evidence_refs:Iterable[str],latency_ms:float=0.,cost:float=0.):
        if self.registry is None:raise RuntimeError("mode calibration registry unavailable")
        if mode not in self.MODES:raise ValueError("unknown coordination mode")
        self.registry.update(mode,"coordination-mode",self._features(features),success=success,latency_ms=latency_ms,cost=cost,evidence_refs=evidence_refs)
