"""Self-improvement campaign using evaluator-owned task bank + promotion gate."""
from __future__ import annotations

import pathlib
import tempfile
import time
from dataclasses import asdict, dataclass
from typing import Any

from .candidate_promotion_gate import CandidatePromotionGate
from .evaluator_task_bank import EvaluatorOwnedTaskBank, EvaluatorTask


@dataclass(frozen=True)
class TaskBankAttempt:
    task_id: str
    copy_index: int
    evaluation_passed: bool
    failures: tuple[str, ...]
    candidate_path_recorded: bool
    hidden_seal_match: bool | None


class TaskBankCandidateFactory:
    """Deterministic local candidates for short evaluator-owned tasks.

    This validates the self-improvement plumbing without making a provider-model
    capability claim.  Some copies are intentionally weak so the campaign proves
    selection, not just a single happy path.
    """

    def write_candidate(self, root: pathlib.Path, task: EvaluatorTask, copy_index: int) -> None:
        target = root / task.target
        target.parent.mkdir(parents=True, exist_ok=True)
        if task.id == "parse_flags_recursive_v1":
            code = self._parse_flags(copy_index)
        elif task.id == "safe_join_escape_v1":
            code = self._safe_join(copy_index)
        elif task.id == "agui_delta_projection_v1":
            code = self._agui(copy_index)
        elif task.id == "traceparent_validate_v1":
            code = self._trace(copy_index)
        elif task.id == "waiver_hash_stability_v1":
            code = self._waiver(copy_index)
        elif task.id == "mcp_trace_meta_v1":
            code = self._mcp_trace(copy_index)
        elif task.id == "gateway_stream_usage_v1":
            code = self._gateway_stream(copy_index)
        elif task.id == "sandbox_relpath_v1":
            code = self._sandbox_relpath(copy_index)
        elif task.id == "team_worktree_binding_v1":
            code = self._team_bindings(copy_index)
        elif task.id == "png_hotspot_summary_v1":
            code = self._pngdiff(copy_index)
        elif task.id == "cost_tax_summary_v1":
            code = self._tax(copy_index)
        else:
            raise KeyError(task.id)
        target.write_text(code, encoding="utf-8")

    @staticmethod
    def _parse_flags(copy_index: int) -> str:
        if copy_index == 0:
            return "def parse_flags(text):\n    return {}\n"
        return '''
def parse_flags(text):
    out = {}
    for part in str(text or "").split():
        if not part.startswith("--"):
            continue
        item = part[2:]
        if "=" in item:
            key, value = item.split("=", 1)
            if key in out:
                out[key] = out[key] + [value] if isinstance(out[key], list) else [out[key], value]
            else:
                out[key] = value
        else:
            out[item] = True
    return out
'''.lstrip()

    @staticmethod
    def _safe_join(copy_index: int) -> str:
        if copy_index == 0:
            return "def safe_join(root, user_path):\n    return root / user_path\n"
        return '''
def safe_join(root, user_path):
    import pathlib
    base = pathlib.Path(root).resolve()
    raw = pathlib.Path(str(user_path))
    if raw.is_absolute():
        raise ValueError("absolute paths are not allowed")
    candidate = (base / raw).resolve(strict=False)
    try:
        candidate.relative_to(base)
    except ValueError as exc:
        raise ValueError("path escapes root") from exc
    return candidate
'''.lstrip()


    @staticmethod
    def _agui(copy_index: int) -> str:
        if copy_index == 0:
            return "def project_state_delta(data):\n    return [{'op':'add','path':'/state','value':data}]\n"
        return "def project_state_delta(data):\n    return [{'op':'add','path':'/state/'+str(k),'value':v} for k,v in (data or {}).items()]\n"

    @staticmethod
    def _trace(copy_index: int) -> str:
        if copy_index == 0:
            return "def valid_traceparent(text):\n    return True\n"
        return """
def valid_traceparent(text):
    import re
    return isinstance(text, str) and re.fullmatch(r'[0-9a-fA-F]{2}-[0-9a-fA-F]{32}-[0-9a-fA-F]{16}-[0-9a-fA-F]{2}', text) is not None
""".lstrip()

    @staticmethod
    def _waiver(copy_index: int) -> str:
        if copy_index == 0:
            return "def finding_hash(finding):\n    return 'sha256:bad'\n"
        return """
def finding_hash(finding):
    import hashlib, json
    payload = {'path': finding.get('path'), 'kind': finding.get('kind'), 'evidence': finding.get('evidence')}
    return 'sha256:' + hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':'), default=str).encode()).hexdigest()
""".lstrip()


    @staticmethod
    def _mcp_trace(copy_index: int) -> str:
        if copy_index == 0:
            return "def inject_trace_meta(params, traceparent):\n    params['_meta']={'traceparent':traceparent}\n    return params\n"
        return """
def inject_trace_meta(params, traceparent):
    import re
    out = dict(params or {})
    meta = dict(out.get('_meta') or {})
    if isinstance(traceparent, str) and re.fullmatch(r'[0-9a-fA-F]{2}-[0-9a-fA-F]{32}-[0-9a-fA-F]{16}-[0-9a-fA-F]{2}', traceparent):
        meta.setdefault('traceparent', traceparent)
    out['_meta'] = meta
    return out
""".lstrip()

    @staticmethod
    def _gateway_stream(copy_index: int) -> str:
        if copy_index == 0:
            return "def parse_sse_usage(lines):\n    return {'content':'', 'usage_seen': False}\n"
        return """
def parse_sse_usage(lines):
    import json
    parts=[]; usage=False
    for line in lines or []:
        line=str(line).strip()
        if not line or line.startswith(':') or not line.startswith('data:'):
            continue
        data=line[5:].strip()
        if data == '[DONE]':
            break
        try: obj=json.loads(data)
        except Exception: continue
        if isinstance(obj.get('usage'), dict): usage=True
        for choice in obj.get('choices') or []:
            delta=choice.get('delta') if isinstance(choice, dict) else None
            if isinstance(delta, dict) and delta.get('content'):
                parts.append(str(delta['content']))
    return {'content': ''.join(parts), 'usage_seen': usage}
""".lstrip()

    @staticmethod
    def _sandbox_relpath(copy_index: int) -> str:
        if copy_index == 0:
            return "def safe_relpath(path):\n    return path\n"
        return """
def safe_relpath(path):
    import posixpath
    raw=str(path or '')
    if not raw or raw.startswith('/'):
        raise ValueError('invalid path')
    norm=posixpath.normpath(raw)
    if norm == '.' or norm == '..' or norm.startswith('../') or '/..' in norm.split('/'):
        raise ValueError('path escapes root')
    parts=norm.split('/')
    if any(part == '..' for part in parts):
        raise ValueError('path escapes root')
    return norm
""".lstrip()

    @staticmethod
    def _team_bindings(copy_index: int) -> str:
        if copy_index == 0:
            return "def validate_bindings(members):\n    return {'ok': True, 'findings': []}\n"
        return """
def validate_bindings(members):
    findings=[]; focuses=set(); paths=set()
    for m in members or []:
        focus=str(m.get('focus') or m.get('taskName') or '').strip().lower()
        wt=str(m.get('worktree') or '')
        if not focus or focus in focuses: findings.append({'error':'duplicate or empty focus'})
        focuses.add(focus)
        if not wt.startswith('worktrees/') or '..' in wt.split('/'):
            findings.append({'error':'worktree path escapes worktree root'})
        if wt in paths: findings.append({'error':'duplicate worktree path'})
        paths.add(wt)
    return {'ok': not findings, 'findings': findings}
""".lstrip()

    @staticmethod
    def _pngdiff(copy_index: int) -> str:
        if copy_index == 0:
            return "def hotspot_summary(ref, actual):\n    return {'diffPixels': 0, 'similarityScore': 100}\n"
        return """
def hotspot_summary(ref, actual):
    total = min(len(ref), len(actual)) // 4
    if total == 0:
        return {'diffPixels': 0, 'similarityScore': 100}
    diff=0
    for i in range(total):
        if ref[i*4:i*4+4] != actual[i*4:i*4+4]:
            diff += 1
    return {'diffPixels': diff, 'similarityScore': round((1 - diff/total) * 100)}
""".lstrip()

    @staticmethod
    def _tax(copy_index: int) -> str:
        if copy_index == 0:
            return "def summarize_tax(rows):\n    return {'token_error_tax': 0}\n"
        return '''
def summarize_tax(rows):
    total = 0
    wasted = 0
    for row in rows or []:
        tokens = int(row.get('tokens', row.get('total_tokens', 0)) or 0)
        total += tokens
        if row.get('failed') or row.get('retry') or row.get('repair'):
            wasted += tokens
    return {
        'total_tokens': total,
        'wasted_tokens': wasted,
        'useful_tokens': max(0, total - wasted),
        'token_error_tax': 0 if total == 0 else wasted / total,
    }
'''.lstrip()


class SelfImprovementTaskBankCampaign:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.bank = EvaluatorOwnedTaskBank()
        self.factory = TaskBankCandidateFactory()

    def run(self, *, chimera_copies: int = 3, levels: int = 3) -> dict[str, Any]:
        started = time.perf_counter()
        task_count = len(self.bank.tasks) if int(levels) >= 3 else max(1, min(len(self.bank.tasks), int(levels)))
        tasks = self.bank.tasks[:task_count]
        attempts: list[TaskBankAttempt] = []
        rows: list[dict[str, Any]] = []
        with tempfile.TemporaryDirectory(prefix="chimera-self-improve-bank-") as td:
            base = pathlib.Path(td)
            for task in tasks:
                task_attempts: list[TaskBankAttempt] = []
                for copy_index in range(max(1, int(chimera_copies))):
                    candidate = base / task.id / f"copy-{copy_index}"
                    self.factory.write_candidate(candidate, task, copy_index)
                    gate = CandidatePromotionGate(self.root).evaluate(
                        candidate,
                        task=task.prompt,
                        task_bank_id=task.id,
                        authorize_promotion_evaluation=True,
                        timeout_seconds=60,
                    )
                    seal = None
                    if isinstance(gate.get("task_bank_artifact"), dict):
                        hidden = gate["task_bank_artifact"].get("hidden", {})
                        seal = bool(hidden.get("matches_seal"))
                    attempt = TaskBankAttempt(
                        task_id=task.id,
                        copy_index=copy_index,
                        evaluation_passed=bool(gate.get("evaluation_passed")),
                        failures=tuple(gate.get("failures", [])),
                        candidate_path_recorded=False,
                        hidden_seal_match=seal,
                    )
                    attempts.append(attempt)
                    task_attempts.append(attempt)
                rows.append({
                    "task": task.public_dict(),
                    "attempts": [asdict(a) for a in task_attempts],
                    "task_passed": any(a.evaluation_passed for a in task_attempts),
                    "selected_copy": next((a.copy_index for a in task_attempts if a.evaluation_passed), None),
                })
        return {
            "schema_version": "chimera.self-improvement-task-bank-campaign.v1",
            "chimera_copies": max(1, int(chimera_copies)),
            "task_count": len(tasks),
            "rows": rows,
            "all_tasks_have_passing_copy": all(row["task_passed"] for row in rows),
            "hidden_tests_evaluator_owned": True,
            "candidate_paths_recorded": False,
            "repository_promotion_applied": False,
            "promotion_allowed": False,
            "live_provider_model_claim": False,
            "duration_ms": round((time.perf_counter() - started) * 1000, 3),
            "limits": [
                "Uses deterministic local candidates to validate evaluator-owned task bank + candidate promotion gate plumbing.",
                "No repository promotion is applied and no provider-model capability is claimed.",
            ],
        }
