"""Cryptographically signed exact-command proof cache."""
from __future__ import annotations
import base64,hashlib,json,os,pathlib,threading,time,uuid
from typing import Any,Callable,Optional
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from pydantic import BaseModel,ConfigDict
from .artifacts import ContentAddressedArtifactStore
from .context_evidence import ContextSigner
from .wal import WAL
class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
class CommandProofSpec(FrozenModel):
 schema_version:str="chimera.command-proof.v1";profile:str;command:str;workspace_root:str;runtime_versions:tuple[str,...];policy_hash:str;env_hash:str="";dependency_hashes:tuple[str,...]=();selected_input_hashes:tuple[str,...]=()
 @property
 def key(self):return _hash(self.model_dump(mode="json"))
class CommandProofReceipt(FrozenModel):
 spec_key:str;status:int;output_ref:str;output_hash:str;completed_at:str;key_id:str;public_key:str;signing_scope:str;signature:str
 def unsigned(self):return self.model_dump(mode="json",exclude={"signature"})
 @property
 def receipt_hash(self):return _hash(self.model_dump(mode="json"))
 def verify(self):
  try:
   raw=base64.b64decode(self.public_key,validate=True)
   if "ed25519:"+hashlib.sha256(raw).hexdigest()!=self.key_id:return False
   Ed25519PublicKey.from_public_bytes(raw).verify(base64.b64decode(self.signature,validate=True),_canonical(self.unsigned()));return True
  except (ValueError,InvalidSignature):return False
class CommandProofResult(FrozenModel):
 reused:bool;receipt:CommandProofReceipt;output:dict[str,Any]
class CommandProofCache:
 def __init__(self,root:pathlib.Path,store:Optional[ContentAddressedArtifactStore]=None,signer:Optional[ContextSigner]=None):
  self.root=pathlib.Path(root);self.dir=self.root/".chimera"/"command_proofs";self.dir.mkdir(parents=True,exist_ok=True);self.store=store or ContentAddressedArtifactStore(root);self.signer=signer or ContextSigner.from_environment_or_ephemeral();self.wal=WAL(root);self.locks={};self.guard=threading.Lock()
 def _path(self,key):return self.dir/f"{key.removeprefix('sha256:')}.json"
 def _lock(self,key):
  with self.guard:return self.locks.setdefault(key,threading.Lock())
 def check(self,spec:CommandProofSpec):
  path=self._path(spec.key)
  if not path.exists():return None
  try:
   value=json.loads(path.read_text());record_hash=value.pop("record_hash");receipt=CommandProofReceipt.model_validate(value)
   if receipt.spec_key!=spec.key or receipt.receipt_hash!=record_hash or not receipt.verify():raise ValueError("proof receipt invalid")
   anchored=any(e.get("data",{}).get("spec_key")==spec.key and e.get("data",{}).get("receipt_hash")==receipt.receipt_hash for e in self.wal.replay(kind="command_proof_store"))
   if not anchored:raise ValueError("proof receipt is not anchored in canonical WAL")
   output=json.loads(self.store.get(receipt.output_ref));
   if _hash(output)!=receipt.output_hash:raise ValueError("proof output hash mismatch")
   self.wal.append("command_proof_reuse",{"spec_key":spec.key,"receipt_hash":receipt.receipt_hash,"status":receipt.status})
   return CommandProofResult(reused=True,receipt=receipt,output=output)
  except Exception as exc:
   self.wal.append("command_proof_corrupt",{"spec_key":spec.key,"error":f"{type(exc).__name__}: {exc}"[:300]});return None
 def prove(self,spec:CommandProofSpec,runner:Callable[[],dict[str,Any]]):
  with self._lock(spec.key):
   hit=self.check(spec)
   if hit:return hit
   output=runner();status=int(output.get("status",1));encoded=json.dumps(output,sort_keys=True,separators=(",",":"),default=str);ref=self.store.put(encoded,media_type="application/vnd.chimera.command-proof-output+json",provenance={"spec_key":spec.key})
   unsigned={"spec_key":spec.key,"status":status,"output_ref":ref.digest,"output_hash":_hash(output),"completed_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"key_id":self.signer.key_id,"public_key":self.signer.public_key,"signing_scope":self.signer.scope}
   receipt=CommandProofReceipt(**unsigned,signature=self.signer.sign(_canonical(unsigned)));payload={**receipt.model_dump(mode="json"),"record_hash":receipt.receipt_hash};path=self._path(spec.key);temp=path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
   try:temp.write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n");os.replace(temp,path)
   finally:
    if temp.exists():temp.unlink()
   self.wal.append("command_proof_store",{"spec_key":spec.key,"receipt_hash":receipt.receipt_hash,"status":status});return CommandProofResult(reused=False,receipt=receipt,output=output)
def _canonical(v):return json.dumps(v,sort_keys=True,separators=(",",":"),default=str).encode()
def _hash(v):return "sha256:"+hashlib.sha256(_canonical(v)).hexdigest()


def file_hashes(root:pathlib.Path, paths:tuple[str,...])->tuple[str,...]:
 out=[]
 for raw in sorted(set(paths)):
  rel=str(raw).replace("\\","/")
  if rel.startswith("/") or ".." in pathlib.PurePosixPath(rel).parts:continue
  path=pathlib.Path(root)/rel
  if path.exists() and path.is_file():
   out.append(rel+"=sha256:"+hashlib.sha256(path.read_bytes()).hexdigest())
  else:
   out.append(rel+"=<missing>")
 return tuple(out)

def environment_hash(env:dict[str,str]|None=None, keys:tuple[str,...]=("PATH","PYTHONPATH","LANG","LC_ALL"))->str:
 data={k:(env or os.environ).get(k,"") for k in keys}
 return _hash(data)
