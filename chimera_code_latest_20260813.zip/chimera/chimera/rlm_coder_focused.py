"""Focused coder methods for RLMRuntime."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .quality import TaskContract
from .focused_capsules import FocusedCapsuleMixin
from .focused_generation import FocusedGenerationMixin
from .focused_prompt import FocusedPromptMixin
from .focused_quality import FocusedQualityMixin
from .focused_repair import FocusedRepairMixin
from .focused_result import FocusedResultMixin
from .focused_session import FocusedSessionMixin


class RLMFocusedCoderMixin(
    FocusedGenerationMixin,
    FocusedPromptMixin,
    FocusedCapsuleMixin,
    FocusedQualityMixin,
    FocusedRepairMixin,
    FocusedResultMixin,
    FocusedSessionMixin,
):
    def _focused_coder(self, branch: str, model: str, task: str,
                       contract_override: Optional[TaskContract] = None,
                       test_command: str = "pytest -q",
                       shared_context: str = "", context_mode: str = "standard",
                       verification_scope: str = "impact") -> Dict[str, Any]:
        """Contract-first generation with per-file scope and test-driven repair.

        ``micro`` is a deterministic low-overhead mode for one bounded target;
        all static gates, transactional overlay writes, protected tests, and
        executable verification remain unchanged.
        """
        if context_mode not in {"standard", "micro"}:
            raise ValueError("context_mode must be standard or micro")
        if verification_scope not in {"impact", "full"}:
            raise ValueError("verification_scope must be impact or full")
        contract = self._focused_contract(task, contract_override)
        acceptance_ledger, acceptance_cards, acceptance_states = self._acceptance_setup(
            contract, test_command,
        )
        protected_test_before, protected_test_snapshot = self._protected_test_setup(
            branch, contract,
        )
        self._maybe_generate_branch_local_tests(branch, contract, protected_test_before)
        baseline_test = self._baseline_test(branch, test_command, verification_scope)
        capsule_spec = self._focused_capsule_spec(
            branch=branch,
            task=task,
            model=model,
            contract=contract,
            test_command=test_command,
            context_mode=context_mode,
        )
        capsule_hit = self._try_replay_focused_capsule(
            capsule_spec=capsule_spec,
            branch=branch,
            contract=contract,
            model=model,
        )
        if capsule_hit is not None:
            return capsule_hit
        interfaces = self._focused_interfaces(task, shared_context, context_mode)
        evidence: List[Dict[str, Any]] = list(getattr(self._thread_local, "tester_agent_evidence", []) or [])
        changed, total_tokens, api_calls, last_response, provider_records, static_errors_by_target = self._focused_initial_generation_pass(
            branch=branch,
            model=model,
            contract=contract,
            interfaces=interfaces,
            context_mode=context_mode,
            evidence=evidence,
        )

        # Baseline execution is useful even when no candidate passed the static
        # gate: it supplies grounded repair evidence instead of model self-talk.
        test = self._run_focused_tests(branch, test_command, verification_scope)
        test, changed, total_tokens, api_calls, last_response, provider_records, repair_rounds = self._focused_repair_loop(
            branch=branch,
            model=model,
            contract=contract,
            interfaces=interfaces,
            context_mode=context_mode,
            test_command=test_command,
            verification_scope=verification_scope,
            test=test,
            evidence=evidence,
            changed=changed,
            total_tokens=total_tokens,
            api_calls=api_calls,
            last_response=last_response,
            provider_records=provider_records,
            static_errors_by_target=static_errors_by_target,
        )
        test, changed = self._focused_test_scaffold_fallback(
            branch=branch,
            contract=contract,
            test_command=test_command,
            verification_scope=verification_scope,
            test=test,
            evidence=evidence,
            changed=changed,
        )

        test, protected_tests_unchanged = self._enforce_protected_test_integrity(
            branch, test, protected_test_before, protected_test_snapshot, evidence,
        )
        test, mutation_summary = self._run_mutation_challenge(
            branch=branch,
            task=task,
            changed=changed,
            test_command=test_command,
            test=test,
            evidence=evidence,
        )
        self._store_verified_capsule(
            capsule_spec=capsule_spec,
            branch=branch,
            changed=changed,
            test=test,
            evidence=evidence,
        )

        return self._focused_result(
            branch=branch,
            model=model,
            contract=contract,
            changed=changed,
            test=test,
            baseline_test=baseline_test,
            evidence=evidence,
            acceptance_ledger=acceptance_ledger,
            acceptance_cards=acceptance_cards,
            acceptance_states=acceptance_states,
            protected_tests_unchanged=protected_tests_unchanged,
            mutation_summary=mutation_summary,
            capsule_spec=capsule_spec,
            repair_rounds=repair_rounds,
            provider_records=provider_records,
            last_response=last_response,
            api_calls=api_calls,
            total_tokens=total_tokens,
        )
