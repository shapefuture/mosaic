"""Structured degradation/confession ledger for non-fatal fallback paths."""
from __future__ import annotations
from dataclasses import dataclass, asdict
import pathlib, time
from .wal import WAL, wal_write

@dataclass(frozen=True)
class DegradationEvent:
    kind: str
    scope: str
    reason: str
    severity: str
    ts: float
    def as_dict(self): return asdict(self)

def confess_degradation(root: pathlib.Path, kind: str, scope: str, reason: str, severity: str = "warn") -> DegradationEvent:
    row=DegradationEvent(kind, scope, reason[:500], severity, time.time())
    wal_write(WAL(pathlib.Path(root)), "degradation", row.as_dict())
    return row
