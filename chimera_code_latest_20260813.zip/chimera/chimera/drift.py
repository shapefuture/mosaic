
"""
Drift Mitigation — synthesis of 60+ research papers on self-improvement drift

Research distilled:
- Goal Drift Index (SAHOO): measurable drift, threshold 0.44 → stop
- Capability Erosion (2605.09315): 4 dims (workflow/skill/model/memory), destructive interference via mutable repo rewrite
  Mitigation: Capability-Preserving Evolution (CPE) — evidence-gated preservation, Fisher regularization, stable memories protected
- Progressive Capability Collapse (Pebblous): 3 traps — what to keep (84% vs 3.7% reusable: principle vs instance), when to pull (global vs per-step injection), whose path (teacher vs student self-play) — cure: abstract to principles, selective per-step injection, teacher trajectories
- Library Drift (2605.19576, Ratchet 2605.22148): unbounded accumulation → retrieval degradation → performance < no-skill baseline
  Mitigation: Ratchet hygiene — bounded cap (≤20 active), contribution-score retirement (<θ), 5-consecutive rollback gate, canonicalisation, meta-skill
- Blind Curator (2607.07436): biased judge → curator blindness, false-pass bias > τ → starvation
  Mitigation: deterministic grader + anchor guards, fail-closed anchoring, validity gate
- Agent Drift (Addy Osmani, Ralph Wiggum): long loops need periodic fresh starts, AGENTS.md re-injection, verification loops
- Layered Mutability / Identity Drift (2604.14717): compositional drift, local reasonable updates compound to un-authorized trajectory
  Mitigation: observability depth >= modification depth, layered mutability gate
- Misevolution (Experience-Driven 2604.16968, Safety 2606.23075): benign tasks still erode safety via execution-oriented experience
- DPA Dual-Process (2603.xxx): conservative curator gate, bulletized memory with utility stats, reflector + curator separate
- Coherence-Based Alignment (CBA): L_tot = L_task + λ(1-C) as regularizer

Implements for Chimera: DriftMonitor, CPE preservers, Ratchet guard, Re-injection scheduler
"""
from __future__ import annotations
import pathlib, json, time, math, re
from typing import Dict, List, Optional, Tuple
from collections import defaultdict, Counter

class GoalContract:
    """Immutable goal anchor used by drift monitoring and re-injection."""
    def __init__(self, task: str):
        self.task = task.strip()
        self.digest = __import__("hashlib").sha256(self.task.encode()).hexdigest()
        stop = {"the", "and", "that", "with", "from", "into", "this", "then", "uses", "using", "all", "new", "add"}
        self.terms = {
            token for token in re.findall(r"[a-z_][a-z0-9_]{2,}", self.task.lower())
            if token not in stop
        }
        self.constraints = {
            token for token in self.terms
            if token in {"deny", "denied", "never", "only", "must", "ltl", "capability", "sandbox", "wal", "tests", "verify", "verification"}
        }


class DriftMonitor:
    """Evidence-based goal drift monitor without pseudo-embeddings.

    Goal coverage and action alignment are inspectable lexical measures.  They
    are intentionally conservative: drift is a control signal to stop or ask
    for review, not a scientific claim inferred from a random hash vector.
    """
    DIMENSIONS = [
        "goal_coverage", "action_alignment", "constraint_preservation",
        "error_rate", "coordination_alignment", "evidence_density",
    ]

    def __init__(self, root: pathlib.Path = pathlib.Path("."), threshold: float = 0.72):
        self.root = pathlib.Path(root).resolve()
        self.log_path = self.root / ".chimera" / "drift.jsonl"
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.contract: Optional[GoalContract] = None
        self._threshold = threshold

    def set_baseline(self, task: str):
        self.contract = GoalContract(task)

    @staticmethod
    def _trace_text(trace: List[Dict]) -> str:
        return " ".join(json.dumps(item, sort_keys=True).lower() for item in trace[-100:])

    def gdi(self, trace: List[Dict], task: Optional[str] = None) -> float:
        contract = GoalContract(task) if task else self.contract
        if contract is None:
            return 0.0
        text = self._trace_text(trace)
        observed = set(re.findall(r"[a-z_][a-z0-9_]{2,}", text))
        if not trace:
            return 1.0
        coverage = len(contract.terms & observed) / max(1, len(contract.terms))
        # Error-only traces should not look aligned merely because they repeat
        # the task in an exception message.
        errors = sum(1 for item in trace if item.get("kind") in {"error", "timeout", "violation"})
        error_penalty = min(0.35, errors / max(1, len(trace)))
        return round(max(0.0, min(1.0, 1.0 - coverage + error_penalty)), 3)

    def measure(self, trace: List[Dict], task: str) -> Dict:
        if self.contract is None or self.contract.task != task.strip():
            self.set_baseline(task)
        assert self.contract is not None
        text = self._trace_text(trace)
        observed = set(re.findall(r"[a-z_][a-z0-9_]{2,}", text))
        coverage = len(self.contract.terms & observed) / max(1, len(self.contract.terms))
        action_events = [item for item in trace if item.get("kind") in {"model_call", "patch_applied", "test_result", "commit", "graph_retrieval"}]
        action_text = self._trace_text(action_events)
        action_terms = set(re.findall(r"[a-z_][a-z0-9_]{2,}", action_text))
        action_alignment = len(self.contract.terms & action_terms) / max(1, len(self.contract.terms))
        explicit_violations = [item for item in trace if item.get("kind") in {"violation", "capability_denied"}]
        constraints_seen = len(self.contract.constraints & observed) / max(1, len(self.contract.constraints)) if self.contract.constraints else 1.0
        constraint_preservation = max(0.0, constraints_seen - 0.25 * len(explicit_violations))
        errors = sum(1 for item in trace if item.get("kind") in {"error", "timeout"})
        error_rate = errors / max(1, len(trace))
        evidence_events = sum(1 for item in trace if item.get("kind") in {"graph_retrieval", "test_result", "patch_applied", "verification"})
        evidence_density = evidence_events / max(1, len(trace))
        coordination = 1.0 if not any(item.get("kind") == "dependency_failure" for item in trace) else 0.0
        gdi = self.gdi(trace, task)
        drift = gdi > self._threshold or constraint_preservation < 0.5 or error_rate > 0.35
        scores = {
            "goal_coverage": round(coverage, 3),
            "action_alignment": round(action_alignment, 3),
            "constraint_preservation": round(constraint_preservation, 3),
            "error_rate": round(error_rate, 3),
            "coordination_alignment": coordination,
            "evidence_density": round(evidence_density, 3),
        }
        entry = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "task_digest": self.contract.digest, "gdi": gdi, "threshold": self._threshold,
            "drift": drift, "dims": scores,
            "overall": round((coverage + action_alignment + constraint_preservation + (1 - error_rate) + coordination) / 5, 3),
        }
        with self.log_path.open("a") as handle:
            handle.write(json.dumps(entry) + "\n")
        return entry

class CPEPreserver:
    """Capability-Preserving Evolution per 2605.09315
    Evidence-gated preservation: historically reliable memories/skills protected
    Fisher-importance regularization simulated via usage count
    """
    def __init__(self, root: pathlib.Path = pathlib.Path(".")):
        self.root = pathlib.Path(root).resolve()
        self.evidence_path = self.root / ".chimera" / "cpe_evidence.json"
        self.evidence: Dict[str, Dict] = {}
        if self.evidence_path.exists():
            try: self.evidence = json.loads(self.evidence_path.read_text())
            except: self.evidence = {}

    def observe(self, key: str, success: bool, reward: float):
        """Accumulate stability: repeated self-verified support -> protected"""
        rec = self.evidence.get(key, {"success":0, "fail":0, "reward_sum":0.0, "stability":0})
        if success: rec["success"] += 1
        else: rec["fail"] += 1
        rec["reward_sum"] += reward
        total = rec["success"] + rec["fail"]
        rec["stability"] = rec["success"] / total if total else 0
        rec["evidence"] = rec["success"] - rec["fail"]
        self.evidence[key] = rec
        self.evidence_path.parent.mkdir(parents=True, exist_ok=True)
        self.evidence_path.write_text(json.dumps(self.evidence, indent=2))
        return rec

    def is_protected(self, key: str, threshold: int=3) -> bool:
        """Evidence-gated: historically reliable (>=threshold successes) -> protected from destructive rewrite"""
        rec = self.evidence.get(key)
        if not rec: return False
        return rec.get("success",0) >= threshold and rec.get("stability",0) > 0.7

    def fisher_regularize(self, adaptation_plan: List[Dict]) -> List[Dict]:
        """Fisher-based: encourage adaptation along low-interference directions
        If plan touches protected processor, dampen delta
        """
        out=[]
        for plan in adaptation_plan:
            proc = plan.get("processor", "")
            key = f"processor:{proc}"
            if self.is_protected(key):
                # Dampen: reduce delta magnitude to preserve old capability
                def damp(value):
                    if isinstance(value, (int, float)):
                        return value * 0.3
                    if isinstance(value, dict):
                        return {key: damp(item) for key, item in value.items()}
                    # Symbolic deltas cannot be scaled; protection means the
                    # evolver must skip the write entirely.
                    return value
                plan = {**plan, "cpe_dampened": True, "delta": {k: damp(v) for k, v in plan.get("delta", {}).items()}}
                plan["cpe_reason"] = f"{proc} protected (evidence {self.evidence[key]['success']} successes), dampened"
            out.append(plan)
        return out

    def should_evict(self, key: str) -> bool:
        """Conservative curator: only evict low-evidence entries"""
        rec = self.evidence.get(key)
        if not rec: return True
        if self.is_protected(key): return False
        return rec.get("evidence",0) < -2 or rec.get("stability",0) < 0.3

class CuratorGate:
    """DPA Conservative Curator + Ratchet bounded cap + rollback gate
    - Bulletized memory entries with utility stats
    - Conservative gate filters generic/redundant/conflicting insertions
    - Bounded cap ≤20 active, contribution-score retirement, 5-consecutive rollback
    """
    def __init__(self, root: pathlib.Path = pathlib.Path(".")):
        self.root = pathlib.Path(root).resolve()
        self.cpe = CPEPreserver(root)
        self.cap = 20
        self.retirement_threshold = -0.1  # contribution < θ
        self.rollback_threshold = 0.10
        self.consecutive_regressions = 0

    def filter_insertion(self, candidate: str, existing: List[str]) -> Tuple[bool, str]:
        """Conservative: reject generic/redundant/conflicting"""
        cand_l = candidate.lower()
        # Generic check
        if len(cand_l.split()) < 5 or "great code" in cand_l or "be helpful" in cand_l:
            return False, "generic insertion rejected by curator gate"
        # Redundant: near-duplicate via token overlap
        cand_tokens = set(re.findall(r"\w+", cand_l))
        for ex in existing:
            ex_tokens = set(re.findall(r"\w+", ex.lower()))
            overlap = len(cand_tokens & ex_tokens) / max(len(cand_tokens),1)
            if overlap > 0.85:
                return False, f"redundant with existing ({overlap:.2f} overlap)"
        # Conflicting: explicit negation
        if any(neg in cand_l for neg in ["never use", "always deny"]):
            # Check if conflicts with protected memory
            for ex in existing[:5]:
                if ex.lower() in cand_l:
                    return False, "conflicting insertion"
        return True, "pass"

    def should_retire(self, key: str, contribution: float, trials: int) -> bool:
        """Contribution-score retirement with evidence floor (Ratchet §3)"""
        if trials < 5: return False  # evidence floor
        if self.cpe.is_protected(key): return False
        return contribution < self.retirement_threshold

    def check_rollback(self, heldout_pass: float, best: float) -> Tuple[bool, str]:
        """Rollback with persistence gate: flag if drop >10% below best, fire only after 5 consecutive"""
        if heldout_pass < best - self.rollback_threshold:
            self.consecutive_regressions += 1
            if self.consecutive_regressions >= 5:
                self.consecutive_regressions = 0
                return True, f"rollback: 5 consecutive regressions {heldout_pass:.2f} < best {best:.2f}-0.10"
            return False, f"regression {self.consecutive_regressions}/5"
        else:
            self.consecutive_regressions = 0
            return False, "no rollback"

    def enforce_bounded_cap(self, active: List[str]) -> List[str]:
        """Bounded cap ≤20 active, LRU eviction of low-evidence"""
        if len(active) <= self.cap:
            return active
        # Evict lowest evidence
        scored = [(k, self.cpe.evidence.get(k, {}).get("stability", 0)) for k in active]
        scored.sort(key=lambda x: x[1])
        to_evict = scored[:len(active)-self.cap]
        keep = [k for k,_ in scored[len(active)-self.cap:]]
        return keep

class ReInjectionScheduler:
    """Periodic fresh starts + AGENTS.md re-injection (Ralph Wiggum + Addy Osmani)
    Drift's antidote: every N turns, re-inject system prompt + AGENTS.md + recent evidence
    """
    def __init__(self, root: pathlib.Path = pathlib.Path("."), every_n: int=5):
        self.root = pathlib.Path(root).resolve()
        self.every_n = every_n
        self.turn = 0
        from .project_rules import ProjectRuleLoader
        self.rules = ProjectRuleLoader(self.root)
        self.last_manifest = []

    def should_reinject(self) -> bool:
        self.turn += 1
        return self.turn % self.every_n == 0

    def inject(self, base_prompt: str) -> str:
        rules = self.rules.load()
        self.last_manifest = rules.manifest()
        return (
            base_prompt
            + "\n# Re-injected scoped repository guidance (anti-drift, turn {}):\n".format(self.turn)
            + rules.text[:2000]
        )

class LibraryDriftGuard:
    """Library Drift (2605.19576): silent degradation via unbounded skill accumulation
    Diagnostics + fix: Ratchet recipe — outcome-driven retirement, bounded cap, meta-skill
    """
    def __init__(self, root: pathlib.Path = pathlib.Path(".")):
        self.root = pathlib.Path(root).resolve()
        self.curator = CuratorGate(root)

    def diagnose(self, skills: List[Dict]) -> Dict:
        if not skills:
            return {"drift": False, "reason": "no skills"}
        active = [s for s in skills if s.get("status")=="active"]
        if len(active) > self.curator.cap:
            return {"drift": True, "reason": f"bloat: {len(active)} > cap {self.curator.cap}", "mode": "bloat"}
        # Stagnation: skills accumulate but never reach solver
        if len(skills) > 30 and len(active) / len(skills) < 0.2:
            return {"drift": True, "reason": "stagnation: low retrieval", "mode": "stagnation"}
        return {"drift": False, "reason": "healthy"}

    def fix(self, skills: List[Dict]) -> List[Dict]:
        diag = self.diagnose(skills)
        if not diag["drift"]:
            return skills
        # Bounded cap + retirement
        active_ids = [s["id"] for s in skills if s.get("status")=="active"]
        kept = self.curator.enforce_bounded_cap(active_ids)
        out=[]
        for s in skills:
            if s["id"] in active_ids and s["id"] not in kept:
                s = {**s, "status":"retired", "retire_reason": diag["reason"]}
            out.append(s)
        return out
