"""Tenant authorization/provisioning CLI commands."""
from __future__ import annotations

import json
import pathlib

import click
from rich.json import JSON


def register(main: click.Group, *, console, cli_root):
    _cli_root = cli_root

    @main.group("tenant")
    def tenant_group():
        """Opaque tenant workspace provisioning and quota controls."""
        pass


    @tenant_group.command("issue-authorization")
    @click.argument("tenant_id")
    @click.argument("authenticated_principal")
    @click.option("--scope", "scopes", multiple=True, required=True, type=click.Choice([
        "cli", "rpc", "mcp", "scheduler", "sandbox", "durable", "artifact", "lsp",
    ]))
    @click.option("--ttl-seconds", type=click.FloatRange(min=1, max=86400), default=3600, show_default=True)
    @click.option("--output", type=click.Path(path_type=pathlib.Path), required=True)
    @click.option("--signing-key-env", required=True)
    @click.option("--signing-scope", default="tenant-authority", show_default=True)
    def tenant_issue_authorization(tenant_id, authenticated_principal, scopes, ttl_seconds, output, signing_key_env, signing_scope):
        """Issue a signed principal-to-tenant grant without persisting raw identities."""
        import os
        from .context_evidence import ContextSigner
        from .tenant_authorization import TenantAuthorizationAuthority
        from .tenancy import TenantContext

        encoded = os.environ.get(signing_key_env)
        if not encoded:
            raise click.UsageError(f"tenant signing key environment variable is absent: {signing_key_env}")
        signer = ContextSigner.from_base64_private_key(encoded, scope=signing_scope)
        grant = TenantAuthorizationAuthority(signer).issue(
            tenant=TenantContext.from_id(tenant_id),
            authenticated_principal=authenticated_principal,
            scopes=list(scopes),
            ttl_seconds=ttl_seconds,
        )
        output.parent.mkdir(parents=True, exist_ok=True)
        temporary = output.with_suffix(output.suffix + ".tmp")
        temporary.write_text(grant.model_dump_json(indent=2), encoding="utf-8")
        temporary.replace(output)
        console.print(JSON(json.dumps({
            "grant_digest": grant.digest,
            "tenant_key": grant.tenant_key,
            "principal_hash": grant.principal_hash,
            "scopes": list(grant.scopes),
            "issuer_key_id": grant.issuer_key_id,
            "output": str(output),
        }, indent=2)))


    def _tenant_cli_authorize(tenant_id, principal, authorization_file, trusted_key_ids):
        from .tenant_authorization import TenantAuthorizationGuard, grant_from_file
        from .tenancy import TenantContext

        tenant = TenantContext.from_id(tenant_id)
        context, receipt = TenantAuthorizationGuard(trusted_key_ids=set(trusted_key_ids)).authorize(
            grant_from_file(authorization_file), tenant=tenant,
            authenticated_principal=principal, scope="cli",
        )
        return tenant, context, receipt


    @tenant_group.command("provision")
    @click.argument("tenant_id")
    @click.option("--source", "source_root", default=".")
    @click.option("--principal", required=True, help="Authenticated transport principal")
    @click.option("--authorization-file", type=click.Path(path_type=pathlib.Path), required=True)
    @click.option("--trusted-key-id", "trusted_key_ids", multiple=True, required=True)
    def tenant_provision(tenant_id, source_root, principal, authorization_file, trusted_key_ids):
        from .tenancy import TenantWorkspaceResolver

        tenant, context, authorization = _tenant_cli_authorize(
            tenant_id, principal, authorization_file, trusted_key_ids,
        )
        value = TenantWorkspaceResolver(_cli_root()).provision(
            tenant, source_root=pathlib.Path(source_root),
        )
        from .wal import WAL
        WAL(pathlib.Path(value.workspace_root)).append("tenant_authorization", {
            "tenant_key": context.tenant_key,
            "principal_hash": context.principal_hash,
            "grant_digest": context.grant_digest,
            "scope": context.scope,
            "authorized": True,
        })
        console.print(JSON(json.dumps({
            "workspace": value.model_dump(mode="json"),
            "authorization": authorization.model_dump(mode="json"),
            "tenant_context_propagated": context.model_dump(mode="json"),
        }, indent=2)))


    @tenant_group.command("status")
    @click.argument("tenant_id")
    @click.option("--principal", required=True, help="Authenticated transport principal")
    @click.option("--authorization-file", type=click.Path(path_type=pathlib.Path), required=True)
    @click.option("--trusted-key-id", "trusted_key_ids", multiple=True, required=True)
    def tenant_status(tenant_id, principal, authorization_file, trusted_key_ids):
        from .tenancy import TenantWorkspaceResolver

        tenant, context, authorization = _tenant_cli_authorize(
            tenant_id, principal, authorization_file, trusted_key_ids,
        )
        value = TenantWorkspaceResolver(_cli_root()).resolve(tenant)
        console.print(JSON(json.dumps({
            "workspace": value.model_dump(mode="json"),
            "authorization": authorization.model_dump(mode="json"),
            "tenant_context_propagated": context.model_dump(mode="json"),
        }, indent=2)))


    def _tenant_transport_root(workspace, tenant_id, principal, authorization_file, trusted_key_ids, scope):
        values = (tenant_id, principal, authorization_file, bool(trusted_key_ids))
        if not any(values):
            return pathlib.Path(workspace), None
        if not all(values):
            raise click.UsageError(
                "tenant transport requires --tenant-id, --principal, --authorization-file, and --trusted-key-id together"
            )
        from .tenant_authorization import AuthorizedTenantWorkspaceBoundary, grant_from_file
        from .tenancy import TenantContext

        tenant_workspace, context, _receipt = AuthorizedTenantWorkspaceBoundary(
            pathlib.Path(workspace), trusted_key_ids=set(trusted_key_ids),
        ).resolve(
            tenant=TenantContext.from_id(tenant_id),
            authenticated_principal=principal,
            grant=grant_from_file(authorization_file),
            scope=scope,
        )
        return pathlib.Path(tenant_workspace.workspace_root), context



    return _tenant_transport_root
