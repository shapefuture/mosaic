"""Daemon-backed branch workers with durable session records.

Credentials are inherited by workers from the launcher environment and are
never written to the registry.
"""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import signal
import subprocess
import sys
import time
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

from .rlm import AgentMessageBus


class WorkerSession(BaseModel):
    id: str
    task: str
    root: str
    branch: str
    model: str
    status: Literal["starting", "running", "complete", "failed", "stopped", "orphaned"] = "starting"
    pid: Optional[int] = None
    created_at: str
    updated_at: str
    heartbeat_at: Optional[str] = None
    result_path: Optional[str] = None
    event_path: Optional[str] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class BranchSupervisor:
    """Start, inspect, message, and stop workers that survive terminal exit."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.dir = self.root / ".chimera" / "supervisor"
        self.sessions_dir = self.dir / "sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.messages = AgentMessageBus(self.root)

    @staticmethod
    def _id(task: str, branch: str) -> str:
        return "agent-" + hashlib.sha256(f"{task}:{branch}:{time.time_ns()}".encode()).hexdigest()[:12]

    def _path(self, session_id: str) -> pathlib.Path:
        return self.sessions_dir / f"{session_id}.json"

    def _save(self, session: WorkerSession) -> None:
        session.updated_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        temp = self._path(session.id).with_suffix(".tmp")
        temp.write_text(session.model_dump_json(indent=2))
        temp.replace(self._path(session.id))

    def get(self, session_id: str) -> WorkerSession:
        session = WorkerSession.model_validate_json(self._path(session_id).read_text())
        return self._reconcile(session)

    @staticmethod
    def _alive(pid: Optional[int]) -> bool:
        if not pid:
            return False
        try:
            os.kill(pid, 0)
            return True
        except (ProcessLookupError, PermissionError):
            return False

    def _reconcile(self, session: WorkerSession) -> WorkerSession:
        if session.status in {"starting", "running"} and not self._alive(session.pid):
            if session.result_path and pathlib.Path(session.result_path).exists():
                result = json.loads(pathlib.Path(session.result_path).read_text())
                session.status = "complete" if result.get("ok") else "failed"
                session.error = result.get("error")
            else:
                session.status = "orphaned"
                session.error = "worker process disappeared without result"
            self._save(session)
        return session

    def list(self) -> List[WorkerSession]:
        return sorted(
            [self._reconcile(WorkerSession.model_validate_json(path.read_text())) for path in self.sessions_dir.glob("agent-*.json")],
            key=lambda session: session.updated_at,
            reverse=True,
        )

    def start(self, task: str, branch: str, model: str, auto_commit: bool = False,
              metadata: Optional[Dict[str, Any]] = None) -> WorkerSession:
        session_id = self._id(task, branch)
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        result_path = self.sessions_dir / f"{session_id}.result.json"
        event_path = self.sessions_dir / f"{session_id}.events.jsonl"
        session = WorkerSession(
            id=session_id, task=task, root=str(self.root), branch=branch, model=model,
            created_at=now, updated_at=now, result_path=str(result_path),
            event_path=str(event_path), metadata=metadata or {},
        )
        self._save(session)
        command = [
            sys.executable, "-m", "chimera.supervisor", "worker",
            "--root", str(self.root), "--session", session_id,
        ]
        if auto_commit:
            command.append("--auto-commit")
        env = dict(os.environ)
        # Preserve the package checkout for source runs without recording env.
        package_root = str(pathlib.Path(__file__).resolve().parents[1])
        env["PYTHONPATH"] = package_root + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
        log = open(self.sessions_dir / f"{session_id}.worker.log", "a")
        process = subprocess.Popen(
            command, cwd=self.root, env=env, stdout=log, stderr=log,
            start_new_session=True, close_fds=True,
        )
        log.close()
        session.pid = process.pid
        session.status = "running"
        session.heartbeat_at = now
        self._save(session)
        return session

    def stop(self, session_id: str, force: bool = False) -> WorkerSession:
        session = self.get(session_id)
        if self._alive(session.pid):
            try:
                os.killpg(session.pid, signal.SIGKILL if force else signal.SIGTERM)
            except ProcessLookupError:
                pass
        session.status = "stopped"
        self._save(session)
        return session

    def health(self, session_id: str, sample_ms: int = 500) -> Dict[str, Any]:
        session = self.get(session_id)
        if not session.pid:
            return {"status": "unavailable", "stuck": None, "reason": "session has no pid"}
        from .process_health import analyze_process
        result = analyze_process(session.pid, sample_ms=sample_ms)
        return {"session": session_id, "pid": session.pid, **result}

    def send(self, session_id: str, message: str) -> Dict[str, Any]:
        session = self.get(session_id)
        delivered = self.messages.send("user", "child", session.branch, message, kind="steering")
        from .soft_interrupt import SoftInterruptQueue
        interrupt = SoftInterruptQueue(self.root).enqueue(session.branch, message, source="user")
        return {**delivered, "soft_interrupt_id": interrupt.id}

    def events(self, session_id: str, after: int = 0) -> List[Dict[str, Any]]:
        session = self.get(session_id)
        if not session.event_path or not pathlib.Path(session.event_path).exists():
            return []
        output = []
        for index, line in enumerate(pathlib.Path(session.event_path).read_text().splitlines()):
            if index >= after and line.strip():
                output.append(json.loads(line))
        return output


def _worker(root: pathlib.Path, session_id: str, auto_commit: bool) -> int:
    supervisor = BranchSupervisor(root)
    session = supervisor.get(session_id)
    event_path = pathlib.Path(session.event_path)

    def emit(kind: str, **data):
        with event_path.open("a") as handle:
            handle.write(json.dumps({
                "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "kind": kind, "session": session_id, "data": data,
            }, default=str) + "\n")

    try:
        from .orchestrator import ChimeraHarness
        emit("worker_start", branch=session.branch, model=session.model)
        harness = ChimeraHarness(root)
        result = harness.run(session.task, branch=session.branch, model=session.model, auto_commit=auto_commit)
        pathlib.Path(session.result_path).write_text(json.dumps({"ok": True, "result": result}, indent=2, default=str))
        session.status = "complete"
        emit("worker_complete", verification=result.get("verification"), committed=result.get("committed"))
    except Exception as exc:
        pathlib.Path(session.result_path).write_text(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, indent=2))
        session.status = "failed"
        session.error = f"{type(exc).__name__}: {exc}"
        emit("worker_failed", error=session.error)
    finally:
        session.heartbeat_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        supervisor._save(session)
    return 0 if session.status == "complete" else 1


def main(argv: Optional[List[str]] = None) -> int:
    import argparse
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    worker = sub.add_parser("worker")
    worker.add_argument("--root", required=True)
    worker.add_argument("--session", required=True)
    worker.add_argument("--auto-commit", action="store_true")
    args = parser.parse_args(argv)
    if args.command == "worker":
        return _worker(pathlib.Path(args.root), args.session, args.auto_commit)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
