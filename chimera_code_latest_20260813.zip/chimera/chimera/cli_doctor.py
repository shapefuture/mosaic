"""Capability doctor CLI registration."""
from __future__ import annotations

import json

import click
from rich.json import JSON
from rich.table import Table


def register(main: click.Group, *, console, cli_root, cli_state) -> None:
    _cli_root = cli_root
    _cli_state = cli_state

    @main.command("doctor")
    @click.option(
        "--profile",
        "doctor_profile",
        type=click.Choice([
            "local",
            "cloud",
            "enterprise",
            "cloud-postgres",
            "durable-restate",
            "sandbox-linux",
            "cloud-runtime",
        ]),
        default="local",
        show_default=True,
    )
    @click.option("--json", "as_json", is_flag=True, help="emit compact JSON instead of a table")
    @click.option("--fail-on-blockers", is_flag=True, help="exit 1 when required lanes are not ready")
    def doctor(doctor_profile, as_json, fail_on_blockers):
        """Report optional integration readiness without overclaiming certification."""
        from .platform import PlatformDoctor

        report = PlatformDoctor(_cli_root()).capability_matrix(doctor_profile)
        data = report.model_dump(mode="json")
        if as_json or _cli_state().get("output") == "json":
            click.echo(json.dumps(data, separators=(",", ":"), default=str))
            if fail_on_blockers and report.blockers:
                raise click.exceptions.Exit(1)
            return
        table = Table(title=f"Chimera doctor: {doctor_profile}")
        table.add_column("Lane")
        table.add_column("Status")
        table.add_column("Required")
        table.add_column("Detail")
        for lane in report.lanes:
            style = {
                "ready": "green",
                "installed-not-certified": "yellow",
                "configured-but-untested": "yellow",
                "missing-dependency": "red",
                "manual-only": "magenta",
                "not-supported-on-host": "red",
            }[lane.status]
            table.add_row(lane.name, f"[{style}]{lane.status}[/{style}]", ",".join(lane.required_for), lane.detail)
        console.print(table)
        console.print(JSON(json.dumps({"certified": report.certified, "summary": report.summary, "blockers": report.blockers}, indent=2)))
        if fail_on_blockers and report.blockers:
            raise click.exceptions.Exit(1)


