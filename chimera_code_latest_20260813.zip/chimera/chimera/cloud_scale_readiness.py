"""Cloud-scale readiness planning for thousands of Chimera agents."""
from __future__ import annotations

import importlib.util
import math
import os
import pathlib
import shutil
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class CloudScaleCheck:
    name: str
    status: str  # ready | optional | missing | manual | warning
    evidence: str
    action: str


@dataclass(frozen=True)
class AgentShardPlan:
    agents: int
    tenants: int
    hot_agents: int
    warm_agents: int
    cold_agents: int
    suggested_shards: int
    max_agents_per_shard: int
    db_pool_per_shard: int
    event_partitions: int


class CloudScaleReadinessPlanner:
    """Conservative cloud plan without pretending untested infra is live.

    This is a deployment/readiness adapter over the existing ports: it does not
    make NATS, Postgres, Restate, gateways, or sandboxes mandatory for local
    mode.  It tells operators what is ready, what is optional, and what must be
    benchmarked before thousands of resident agents are promoted.
    """

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def plan(self, *, agents: int = 1000, tenants: int = 100, mode: str = "self-hosted") -> dict[str, Any]:
        agents = max(1, min(1_000_000, int(agents)))
        tenants = max(1, min(agents, int(tenants)))
        shard_plan = self._shard_plan(agents, tenants)
        checks = self._checks(mode)
        blockers = [check.name for check in checks if check.status == "missing" and self._is_required_for_cloud(check.name)]
        warnings = [check.name for check in checks if check.status == "warning"]
        return {
            "schema_version": "chimera.cloud-scale-readiness.v1",
            "root": str(self.root),
            "mode": mode,
            "target_agents": agents,
            "target_tenants": tenants,
            "ready_for_local_mode": True,
            "ready_for_thousands_cloud_agents": not blockers,
            "cloud_blockers": blockers,
            "warnings": warnings,
            "shard_plan": asdict(shard_plan),
            "checks": [asdict(check) for check in checks],
            "recommended_topology": self._topology(mode),
            "required_evidence_before_promotion": [
                "runtime-density-benchmark at target hot/warm/cold ratios",
                "cloud-runtime doctor with configured Postgres and durable workflow endpoint, or explicit accepted alternative",
                "event bus replay/fanout benchmark if JSONL polling is replaced",
                "gateway benchmark preserving streaming, tool calls, trace context, usage, and prompt-cache fields",
                "tenant isolation proof under concurrent tenants",
                "sandbox threat-tier proof for trusted/semi-trusted/hostile workloads",
                "full test suite pass in the deployment image",
            ],
            "local_mode_preserved": True,
            "promotion_allowed": False,
            "promotion_rule": "This readiness plan is a gate. It does not certify live cloud operation until the listed evidence exists.",
        }

    def _shard_plan(self, agents: int, tenants: int) -> AgentShardPlan:
        hot = max(1, math.ceil(agents * 0.05))
        warm = max(0, math.ceil(agents * 0.20))
        cold = max(0, agents - hot - warm)
        max_per_shard = 250
        shards = max(1, math.ceil(agents / max_per_shard) * 2, math.ceil(tenants / 50))
        return AgentShardPlan(
            agents=agents,
            tenants=tenants,
            hot_agents=hot,
            warm_agents=warm,
            cold_agents=cold,
            suggested_shards=shards,
            max_agents_per_shard=max_per_shard,
            db_pool_per_shard=max(4, min(64, math.ceil(hot / shards / 2))),
            event_partitions=max(shards, math.ceil(hot / 100)),
        )

    def _checks(self, mode: str) -> list[CloudScaleCheck]:
        return [
            CloudScaleCheck("hexagonal-ports", "ready", "stack alternatives are adapter/profile based", "continue keeping defaults local and ports-driven"),
            CloudScaleCheck("local-jsonl-wal", "ready", "local WAL/event bus exists and is tested", "retain as local source of truth and fallback"),
            CloudScaleCheck("postgres-tenant-state", "ready" if self._has_env("CHIMERA_POSTGRES_URL", "DATABASE_URL") or shutil.which("psql") else "manual", "Postgres/RLS profile and tests exist; runtime endpoint may be configured externally", "set CHIMERA_POSTGRES_URL or DATABASE_URL for cloud runtime smoke"),
            CloudScaleCheck("durable-workflow", "ready" if self._has_env("CHIMERA_RESTATE_INGRESS", "CHIMERA_RESTATE_ENDPOINT", "RESTATE_ENDPOINT") else "manual", "Restate/DBOS adapters exist but live endpoint is optional", "configure Restate/DBOS/accepted alternative for long waits and recovery"),
            CloudScaleCheck("event-bus-fanout", "optional" if not shutil.which("nats-server") else "ready", "JSONL default plus NATS/Redpanda benchmark candidates exist", "use NATS JetStream for many subscribers only after benchmark receipt"),
            CloudScaleCheck("gateway-routing", "optional", "direct provider path and gateway benchmark candidates exist", "benchmark direct vs LiteLLM/AgentGateway/Agentify/Bifrost/AISIX before defaulting to a gateway"),
            CloudScaleCheck("runtime-density", "warning", "density benchmark exists but target-host receipt is still required", "run chimera platform runtime-density-benchmark --counts 1,10,100,1000 on deployment image"),
            CloudScaleCheck("tenant-auth", "ready", "tenant grant endpoint and authorization tests exist", "rotate signing keys and enforce per-tenant budgets in cloud"),
            CloudScaleCheck("otel-openinference", "ready", "OTLP/OpenInference mapping and trace propagation exist", "configure OTLP backend and tail sampling for failures/expensive runs"),
            CloudScaleCheck("ag-ui-stream", "ready", "AG-UI event adapter and GUI events endpoint exist", "frontends can consume /api/runs/events?format=ag-ui"),
            CloudScaleCheck("sandbox-tiering", "manual", "sandbox alternatives and certification profiles exist; host runtimes are optional", "choose Wasmtime/gVisor/Kata/Firecracker per threat tier and run sandbox benchmark/certification"),
            CloudScaleCheck("exploit-scanner", "warning", "benchmark exploit scanner is still a planned gate", "implement scanner before self-improvement promotion against public benchmarks"),
        ]

    @staticmethod
    def _has_env(*names: str) -> bool:
        return any(os.environ.get(name) for name in names)

    @staticmethod
    def _has_module(name: str) -> bool:
        return importlib.util.find_spec(name) is not None

    @staticmethod
    def _is_required_for_cloud(name: str) -> bool:
        # Manual checks are not blockers in this receipt because operators may
        # choose accepted alternatives.  Missing is reserved for non-negotiable
        # code-level capabilities.
        return name in {"hexagonal-ports", "local-jsonl-wal", "tenant-auth", "otel-openinference"}

    @staticmethod
    def _topology(mode: str) -> dict[str, Any]:
        common = {
            "control_plane": "Chimera Python API/CLI/ASGI app with direct provider path preserved",
            "execution_plane": "sandbox adapters selected by threat tier; do not put raw secrets in sandboxes",
            "observability": "OTLP/OpenInference plus local WAL fallback",
            "state": "Postgres/RLS for enterprise tenants; local WAL/SQLite/DuckDB for local analytics",
        }
        if mode == "edge":
            common.update({"edge_profile": "Cloudflare/Rivet actor profile is optional; keep core portable"})
        elif mode == "k8s":
            common.update({"kubernetes_profile": "NATS/Redpanda, Gateway API/Envoy/Kong, RuntimeClass gVisor/Kata are optional adapters"})
        else:
            common.update({"self_hosted_profile": "single VM can start with WAL + Postgres + Restate/DBOS; add NATS/gateways only after benchmark"})
        return common
