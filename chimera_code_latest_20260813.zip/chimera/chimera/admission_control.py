"""Bounded local admission control for agent work queues.

Admission control tells the truth about capacity before work enters a queue. It is
separate from scheduling: an admitted item can still wait, but expired,
low-priority, or saturated work is explicitly deferred/rejected rather than
silently creating an unbounded promise backlog.
"""
from __future__ import annotations

from dataclasses import dataclass
import time


@dataclass(frozen=True)
class WorkItem:
    id: str
    priority: int
    created_at: float
    queue_budget_seconds: float


@dataclass(frozen=True)
class AdmissionDecision:
    allowed: bool
    reason: str
    effective_priority: int


class AdmissionController:
    def __init__(self, *, max_active: int, max_pending: int, aging_seconds: float = 30.0) -> None:
        self.max_active=max(1, int(max_active)); self.max_pending=max(0, int(max_pending)); self.aging=max(1.0, float(aging_seconds))

    def decide(self, item: WorkItem, *, active: int, pending: int, now: float | None = None) -> AdmissionDecision:
        now = time.time() if now is None else now
        age = max(0.0, now - item.created_at)
        if age > item.queue_budget_seconds:
            return AdmissionDecision(False, "queue_budget_expired", item.priority)
        # Aging prevents permanent starvation under a strict priority queue.
        effective = item.priority + int(age // self.aging)
        if active >= self.max_active and pending >= self.max_pending:
            return AdmissionDecision(False, "queue_full", effective)
        return AdmissionDecision(True, "admitted", effective)
