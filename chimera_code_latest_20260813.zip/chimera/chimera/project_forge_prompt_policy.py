"""Project Forge policy injection for general coding tasks."""
from __future__ import annotations

PROJECT_FORGE_CODING_POLICY = """
PROJECT FORGE GATES FOR CODING TASKS:
- Before adding any new dependency, framework, wrapper, scanner, queue, gateway, sandbox, cache, database, or architecture component, first prefer the existing codebase if it already solves the need.
- If the task genuinely requires a new reusable component, state in the JSON summary whether you used: self-contained stdlib, small internal port, or external dependency. Default to self-contained stdlib for small well-understood code.
- Do not add imports for optional external systems unless the target already depends on them or the task explicitly requires them. Use probes/adapters and graceful skips for optional infrastructure.
- Never replace a working existing architecture choice unless the task explicitly asks to reconsider it or tests require it.
- Do not invent ecosystem facts, benchmark numbers, star counts, prices, or maintenance status in comments or summaries.
- For sandbox/security/runtime code, preserve threat-tier semantics: fast shared-kernel runtimes are not equivalent to gVisor/Kata/Firecracker for hostile code.
""".strip()

COMPACT_PROJECT_FORGE_CODING_POLICY = (
    "ProjectForge: before new deps/wrappers/frameworks, reuse existing code; "
    "prefer stdlib/self-contained, then small internal port, then dependency only if explicit/evidenced; "
    "optional infra via adapters/probes/skips; don't weaken threat-tier semantics or invent ecosystem facts."
)


def should_apply_project_forge_policy(task: str) -> bool:
    lower = str(task).lower()
    triggers = (
        "dependency", "library", "package", "framework", "stack", "architecture", "alternative",
        "gateway", "sandbox", "queue", "workflow", "database", "cache", "vector", "graph",
        "telemetry", "observability", "provider", "runtime", "wrapper", "scanner", "adapter",
        "self-improve", "self improvement", "cloud", "k8s", "edge", "durable",
    )
    return any(term in lower for term in triggers)
