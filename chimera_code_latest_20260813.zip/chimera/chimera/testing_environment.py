"""Explicit, non-production test-environment gate and one-shot credential port.

This module does not store, print, serialize, or add credentials to process
environment variables.  A test host may pass a secret on an inherited file
descriptor; it is read once into memory only after an explicit testing flag and
exact route/model match.  The flag never bypasses provider authorization,
route authority, capability policy, or evidence gates.
"""
from __future__ import annotations

import os
from typing import Mapping


class TransientEnvironmentError(RuntimeError):
    pass


class TestingEnvironment:
    FLAG = "CHIMERA_TESTING_ENVIRONMENT"
    ROUTE = "CHIMERA_TEST_ROUTE"
    CREDENTIAL_FD = "CHIMERA_TEST_CREDENTIAL_FD"
    TOKENROUTER_ROUTE = "tokenrouter-kimi-cancellation-v1"
    TOKENROUTER_MODEL = "moonshotai/kimi-k3-free"

    @classmethod
    def enabled(cls, environ: Mapping[str, str] | None = None) -> bool:
        env = os.environ if environ is None else environ
        return env.get(cls.FLAG) == "1"

    @classmethod
    def require_tokenrouter_kimi(cls, *, model: str, environ: Mapping[str, str] | None = None) -> None:
        env = os.environ if environ is None else environ
        if env.get(cls.FLAG) != "1":
            raise TransientEnvironmentError(f"{cls.FLAG}=1 is required for transient live provider testing")
        if env.get(cls.ROUTE) != cls.TOKENROUTER_ROUTE:
            raise TransientEnvironmentError(f"{cls.ROUTE} must equal {cls.TOKENROUTER_ROUTE}")
        if model != cls.TOKENROUTER_MODEL:
            raise TransientEnvironmentError("testing environment route does not authorize this model")

    @classmethod
    def read_one_shot_credential(cls, *, environ: Mapping[str, str] | None = None) -> str:
        """Read a bounded secret from an inherited FD without persisting it.

        The descriptor is closed after the read.  Environment variables are
        intentionally not accepted here: the caller must choose a secure host
        injection path rather than writing a key into source or command text.
        """
        env = os.environ if environ is None else environ
        raw_fd = env.get(cls.CREDENTIAL_FD)
        if raw_fd is None:
            raise TransientEnvironmentError(f"{cls.CREDENTIAL_FD} is required; no credential fallback is permitted")
        try:
            fd = int(raw_fd)
        except ValueError as exc:
            raise TransientEnvironmentError("test credential descriptor is invalid") from exc
        if fd < 0:
            raise TransientEnvironmentError("test credential descriptor is invalid")
        try:
            raw = os.read(fd, 16_384)
        except OSError as exc:
            raise TransientEnvironmentError(f"test credential descriptor cannot be read: {type(exc).__name__}") from exc
        finally:
            try:
                os.close(fd)
            except OSError:
                pass
        value = raw.decode("utf-8", errors="strict").strip()
        if not value or "\x00" in value:
            raise TransientEnvironmentError("test credential payload is empty or invalid")
        return value
