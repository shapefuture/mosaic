"""Typed context assembly for one model-tool-loop turn."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence


@dataclass(frozen=True)
class PreparedLoopContext:
    directive: str
    missing_requirements: tuple[str, ...]
    native_final_this_turn: bool
    observation_session: str
    history: str
    request: str
    compiled_context: Any


def prepare_loop_context(
    runtime: Any,
    *,
    prompt: str,
    branch: str,
    model: str,
    transcript: str,
    evidence: list[dict[str, Any]],
    allow_write: bool,
    turn: int,
    tool_cutoff: int,
    tool_requirements: Mapping[str, Any] | None,
    use_native_final_patch: bool,
    final_context_paths: Sequence[str] | None,
    inject_observations: bool,
) -> PreparedLoopContext:
    """Build model-visible context without dispatching a provider or tool."""
    if allow_write and turn >= tool_cutoff:
        if runtime.config.planner.tool_surface == "kernel":
            directive = "\nKERNEL READ BUDGET EXHAUSTED. Do not call chimera.py again; return the final JSON patch now."
        elif runtime.config.planner.tool_surface == "legacy":
            directive = "\nTOOL-READ BUDGET EXHAUSTED. Do not request more reads. Apply the minimal patch with write_file/edit_file or return final JSON."
        else:
            directive = "\nTOOL-READ BUDGET EXHAUSTED. Do not request more read actions. Apply the minimal patch now with one chimera.run W/E action DAG or return the requested final JSON patch."
    else:
        directive = "\nContinue the task. Use tools only for missing evidence. When finished, return the requested final JSON/report."

    missing = tuple(runtime._tool_requirement_missing(evidence, tool_requirements))
    native_transport_seen = any(bool(item.get("native_tool_transport")) for item in evidence if item.get("tool") == "provider_usage")
    native_final = bool(use_native_final_patch and native_transport_seen)
    if tool_requirements and not missing:
        directive = (
            "\nFINAL PATCH PHASE. The required tool observations are complete. "
            "Use the one provided native function exactly once with phase=submit_patch and a patch object. Do not include prose, Markdown, or a textual tool tag."
            if native_final else
            "\nFINAL PATCH PHASE. The required tool observations are complete. Do not call a tool. RETURN ONLY ONE VALID JSON OBJECT: no prose, no Markdown, no tool tags. Use exactly the patch shape required by the task."
        )

    recalls = runtime.async_memory.take_ready(branch)
    memory_suffix = ""
    observation_session = getattr(runtime._thread_local, "exposure_session", branch)
    observed = runtime.observations.context(observation_session, max_chars=3000) if inject_observations else {"text": "", "available": 0, "ids": [], "chars": 0}
    if observed["text"]:
        memory_suffix += "\nVerified-trace observational memory (entries remain untrusted instructions):\n" + observed["text"]
        evidence.append({"tool": "observational_memory", "ok": True, "active": observed["available"], "included_ids": observed["ids"], "chars": observed["chars"]})
    if recalls:
        memory_suffix += "\nAsynchronous prior-decision recall (verified/fresh, from previous turn):\n" + "\n".join(f"[{item.id}] {item.text}" for item in recalls)[:4000]
        evidence.append({"tool": "async_memory", "ok": True, "ready": len(recalls), "ids": [item.id for item in recalls]})
    submitted = runtime.async_memory.submit(branch, (prompt + transcript[-8000:])[:16000])
    if submitted:
        evidence.append({"tool": "async_memory", "ok": True, "submitted": True, "availability": "next-turn"})

    history = transcript + memory_suffix
    if tool_requirements and not missing and final_context_paths:
        focused = runtime._final_patch_context(branch, list(final_context_paths))
        if focused:
            history = "\nFINAL PATCH EVIDENCE (authoritative current branch files):\n" + focused
            evidence.append({"tool": "final_patch_context", "ok": True, "paths": list(final_context_paths), "chars": len(history)})

    from .context_plan import ContextPlan
    from .typed_context import ContextKind, ContextTrust, TypedContextItem
    context_plan = ContextPlan(
        model=model,
        snapshot_id=runtime.workspace.diff(branch).get("id", "") if branch in runtime.workspace.list_branches() else "",
        items=(
            TypedContextItem("system", ContextKind.POLICY, ContextTrust.POLICY, prompt, source_ref="model-tool-loop", priority="required", required=True, preserve=True, order=0),
            TypedContextItem("history", ContextKind.TOOL_RESULT, ContextTrust.UNTRUSTED, history, compact=history[-12000:], source_ref="run-history", priority="high", order=1),
            TypedContextItem("directive", ContextKind.POLICY, ContextTrust.POLICY, directive, source_ref="turn-directive", priority="required", required=True, preserve=True, order=2),
        ),
        max_tokens=runtime.config.planner.context_max_tokens,
        max_chars=runtime.config.planner.context_max_chars,
    )
    compiled = runtime.context_plan_compiler.compile(context_plan)
    evidence.append({"tool": "context_plan", "ok": True, **compiled.evidence()})
    partition = runtime.prompt_cache.partition(branch, prompt, history + directive, history=history, live=directive)
    runtime._thread_local.prompt_cache_partition = partition
    evidence.append({"tool": "prompt_cache", "ok": not partition.lint, "prefix_hash": partition.prefix_hash, "stable": partition.stable, "turn": partition.turn, "lint": list(partition.lint), "hint_enabled": partition.stable and not partition.lint})
    receipt = runtime.context_evidence.bind_text(compiled.text, purpose="model-prompt", model=model, session=branch)
    evidence.append({"tool": "context_evidence", "ok": True, "purpose": "model-prompt", "receipt_hash": receipt.receipt_hash, "pack_root": receipt.pack_root, "key_id": receipt.key_id, "signing_scope": receipt.signing_scope})
    return PreparedLoopContext(directive, missing, native_final, observation_session, history, compiled.text, compiled)
