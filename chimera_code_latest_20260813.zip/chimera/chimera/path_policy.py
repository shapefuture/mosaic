"""Deterministic path-scoped patch policy resolution.

Task contracts define *what* the task may change; this resolver adds a compact,
versioned answer to *how risky that path is* and which extra evidence is
required.  It is not a second capability system and cannot grant a write that
TaskContract/CapabilitySet already deny.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from fnmatch import fnmatch
import hashlib
import json
import pathlib
from typing import Iterable


@dataclass(frozen=True)
class PathPolicy:
    id: str
    patterns: tuple[str, ...]
    risk: str
    explicit_task_path: bool = False
    independent_evidence: bool = False
    protected: bool = False
    test_profile: str = "standard"


@dataclass(frozen=True)
class PathPolicyDecision:
    path: str
    policy_ids: tuple[str, ...]
    risk: str
    explicit_task_path: bool
    independent_evidence: bool
    protected: bool
    test_profile: str
    policy_hash: str

    def as_dict(self) -> dict:
        return asdict(self)


class PathPolicyResolver:
    """Small immutable default policy set; most-specific matching policy wins."""

    VERSION = "chimera.path-policy.v1"
    DEFAULTS = (
        PathPolicy("tests-protected", ("tests/**", "test/**"), "high", protected=True, test_profile="protected"),
        PathPolicy("migration", ("**/migrations/**", "migrations/**", "**/alembic/**"), "high", explicit_task_path=True, independent_evidence=True, test_profile="migration"),
        PathPolicy("ci-infra", (".github/**", ".gitlab/**", "Dockerfile", "docker-compose*.yml", "infra/**", "deploy/**"), "high", explicit_task_path=True, independent_evidence=True, test_profile="infra"),
        PathPolicy("security-critical", ("**/*auth*", "**/*api_token*", "**/*access_token*", "**/*secret_token*", "**/*jwt*", "**/*credential*", "**/*payment*", "**/*billing*", "**/*acl*", "**/*permission*"), "high", independent_evidence=True, test_profile="security"),
        PathPolicy("documentation", ("docs/**", "**/*.md", "**/*.rst"), "low", test_profile="documentation"),
        PathPolicy("default", ("**",), "standard"),
    )

    def __init__(self, policies: Iterable[PathPolicy] | None = None) -> None:
        self.policies = tuple(policies or self.DEFAULTS)

    @staticmethod
    def normalize(path: str) -> str:
        value = pathlib.PurePosixPath(str(path).replace("\\", "/")).as_posix()
        return value.removeprefix("./")

    @staticmethod
    def _matches(path: str, pattern: str) -> bool:
        # fnmatch's ** behavior is adequate for policy glob selection and is
        # deliberately not reused as a filesystem authorization primitive.
        return fnmatch(path, pattern) or fnmatch("/" + path, pattern)

    def resolve(self, path: str) -> PathPolicyDecision:
        normalized = self.normalize(path)
        matched = [policy for policy in self.policies if any(self._matches(normalized, pattern) for pattern in policy.patterns)]
        if not matched:
            matched = [PathPolicy("implicit-default", ("**",), "standard")]
        # More literal pattern characters are more specific; then preserve
        # declaration order to make equal specificity deterministic.
        matched.sort(key=lambda policy: max(len(pattern.replace("*", "")) for pattern in policy.patterns), reverse=True)
        top = matched[0]
        chosen = tuple(dict.fromkeys(policy.id for policy in matched))
        payload = {"version": self.VERSION, "path": normalized, "policies": [asdict(policy) for policy in matched]}
        digest = "sha256:" + hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        return PathPolicyDecision(
            path=normalized, policy_ids=chosen, risk=top.risk,
            explicit_task_path=any(policy.explicit_task_path for policy in matched),
            independent_evidence=any(policy.independent_evidence for policy in matched),
            protected=any(policy.protected for policy in matched),
            test_profile=top.test_profile, policy_hash=digest,
        )

    @staticmethod
    def task_names_path(task: str, path: str) -> bool:
        lower = task.lower()
        normalized = PathPolicyResolver.normalize(path).lower()
        return normalized in lower or pathlib.PurePosixPath(normalized).name.lower() in lower
