"""Candidate promotion gate for coding/self-improvement patches.

A single place to compose the checks that prevent benchmark Goodharting: exploit
scan, visible/hidden tests, architecture ratchet, Project Forge gates, and
supreme local gate context.  It never mutates or promotes a repository by itself.
"""
from __future__ import annotations

import json
import hashlib
import pathlib
import shlex
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from typing import Any

from .architecture_ratchet import ArchitectureRatchet
from .benchmark_exploit_scanner import BenchmarkExploitScanner
from .project_forge_agent import ProjectForgeAgent


@dataclass(frozen=True)
class CommandReceipt:
    command: str
    status: str
    returncode: int | None
    elapsed_ms: float | None
    stdout_tail: str
    stderr_tail: str


class CandidatePromotionGate:
    """Evaluate whether a candidate can even be considered for promotion."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def evaluate(
        self,
        candidate_path: pathlib.Path,
        *,
        task: str = "",
        visible_test: str | None = None,
        hidden_test: str | None = None,
        task_bank_id: str | None = None,
        waiver_file: pathlib.Path | None = None,
        require_signed_waivers: bool = False,
        trusted_evaluators_file: pathlib.Path | None = None,
        authorize_promotion_evaluation: bool = False,
        timeout_seconds: float = 120.0,
    ) -> dict[str, Any]:
        candidate = pathlib.Path(candidate_path).resolve()
        policy_errors = []
        for policy_file in (waiver_file, trusted_evaluators_file):
            if policy_file is not None and pathlib.Path(policy_file).resolve().is_relative_to(candidate):
                policy_errors.append("candidate-controlled-evaluator-policy")
        before_hash = self._candidate_hash(candidate)
        test_artifact: dict[str, Any] | None = None
        if task_bank_id and authorize_promotion_evaluation and before_hash is not None and not policy_errors:
            visible_test, hidden_test, test_artifact = self._materialize_task_bank_tests(candidate, task_bank_id)
        exploit = BenchmarkExploitScanner(candidate).scan(waiver_path=waiver_file, require_signed_waivers=True, trusted_evaluators_path=trusted_evaluators_file, discover_local_waivers=False) if candidate.exists() else {
            "schema_version": "chimera.benchmark-exploit-scan.v1",
            "status": "blocked",
            "blocker_count": 1,
            "finding_count": 1,
            "findings": [{"path": str(candidate), "kind": "missing-candidate", "severity": "blocker", "evidence": "candidate path missing", "remediation": "provide candidate worktree/path"}],
        }
        can_execute = authorize_promotion_evaluation and not policy_errors and before_hash is not None and not exploit.get("finding_count", 0)
        visible_test = visible_test if can_execute else None
        hidden_test = hidden_test if can_execute else None
        visible = self._run_command(visible_test, timeout_seconds, cwd=candidate if candidate.exists() else self.root) if visible_test else CommandReceipt("", "skipped", None, None, "", "")
        hidden = self._run_command(hidden_test, timeout_seconds, cwd=candidate if candidate.exists() else self.root) if hidden_test else CommandReceipt("", "missing", None, None, "", "")
        ratchet_root = candidate if (candidate / "chimera" / "cli.py").exists() else self.root
        ratchet = ArchitectureRatchet(ratchet_root).run()
        forge = ProjectForgeAgent(self.root).plan(task or "candidate promotion", paths=(str(candidate),))
        after_hash = self._candidate_hash(candidate)
        failures: list[str] = list(policy_errors)
        if before_hash is None:
            failures.append("candidate-snapshot-invalid")
        if before_hash != after_hash:
            failures.append("candidate-changed-during-evaluation")
        if exploit.get("finding_count", 0):
            failures.append("unresolved-exploit-findings")
        if exploit.get("blocker_count", 0):
            failures.append("exploit-scan-blockers")
        if visible.status not in {"passed", "skipped"}:
            failures.append("visible-tests-failed")
        if hidden.status != "passed":
            failures.append("hidden-tests-missing-or-failed")
        if ratchet.get("status") == "fail":
            failures.append("architecture-ratchet-failed")
        if not authorize_promotion_evaluation:
            failures.append("promotion-evaluation-not-authorized")
        return {
            "schema_version": "chimera.candidate-promotion-gate.v1",
            "root": str(self.root),
            "candidate_path": str(candidate),
            "task": task,
            "authorize_promotion_evaluation": bool(authorize_promotion_evaluation),
            "task_bank_id": task_bank_id,
            "task_bank_artifact": test_artifact,
            "waiver_file": str(waiver_file) if waiver_file else None,
            "require_signed_waivers": bool(require_signed_waivers),
            "trusted_evaluators_file": str(trusted_evaluators_file) if trusted_evaluators_file else None,
            "exploit_scan": exploit,
            "visible_test": asdict(visible),
            "hidden_test": asdict(hidden),
            "architecture_ratchet": ratchet,
            "project_forge": forge,
            "failures": failures,
            "evaluation_passed": not failures,
            "candidate_hash_before": before_hash,
            "candidate_hash_after": after_hash,
            "evaluator_isolation": "local-subprocess-not-security-isolated",
            "promotion_blockers": ["isolated-evaluator-attestation-required"],
            "promotion_allowed": False,
            "repository_promotion_applied": False,
            "promotion_rule": "Promotion requires explicit authorization, clean exploit blockers, hidden tests passed, no ratchet failures, and separate human/release approval.",
        }

    @staticmethod
    def _candidate_hash(candidate: pathlib.Path) -> str | None:
        if not candidate.is_dir():
            return None
        digest = hashlib.sha256()
        try:
            for path in sorted(candidate.rglob("*")):
                rel = path.relative_to(candidate)
                if any(p in {".git", ".chimera", "__pycache__", ".pytest_cache"} for p in rel.parts):
                    continue
                if path.is_symlink():
                    return None
                if path.is_file():
                    name = rel.as_posix().encode()
                    digest.update(len(name).to_bytes(8, "big") + name)
                    digest.update(hashlib.sha256(path.read_bytes()).digest())
            return "sha256:" + digest.hexdigest()
        except OSError:
            return None

    @staticmethod
    def _test_env(cwd: pathlib.Path) -> dict[str, str]:
        import os
        env = {k: v for k, v in os.environ.items() if k in {"PATH", "LANG", "LC_ALL", "SYSTEMROOT"}}
        env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
        prior = None
        prefix = str(cwd)
        env["PYTHONPATH"] = prefix if not prior else prefix + os.pathsep + prior
        return env

    def _materialize_task_bank_tests(self, candidate: pathlib.Path, task_id: str) -> tuple[str, str, dict[str, Any]]:
        from .evaluator_task_bank import EvaluatorOwnedTaskBank
        bank = EvaluatorOwnedTaskBank()
        task = bank._get(task_id)  # evaluator-owned internal lookup; body stays out of public catalog
        test_dir = candidate / ".chimera" / "evaluator-hidden" / task_id
        test_dir.mkdir(parents=True, exist_ok=True)
        visible_path = test_dir / f"test_visible_{task_id}.py"
        visible_path.write_text(task.visible_test, encoding="utf-8")
        hidden = bank.materialize_hidden(task_id, test_dir)
        artifact = {
            "schema_version": "chimera.candidate-task-bank-tests.v1",
            "task_public": task.public_dict(),
            "visible_path": str(visible_path),
            "hidden": hidden,
            "hidden_body_returned": False,
        }
        cmd = f"{shlex.quote(sys.executable)} -m pytest -q {shlex.quote(str(visible_path))}"
        hidden_cmd = f"{shlex.quote(sys.executable)} -m pytest -q {shlex.quote(str(hidden['path']))}"
        return cmd, hidden_cmd, artifact

    def _run_command(self, command: str | None, timeout: float, *, cwd: pathlib.Path | None = None) -> CommandReceipt:
        if not command:
            return CommandReceipt("", "skipped", None, None, "", "")
        started = time.perf_counter()
        try:
            completed = subprocess.run(
                shlex.split(command),
                cwd=cwd or self.root,
                text=True,
                env=self._test_env(cwd or self.root),
                capture_output=True,
                timeout=max(1.0, float(timeout)),
                check=False,
            )
            elapsed = round((time.perf_counter() - started) * 1000, 3)
            return CommandReceipt(command, "passed" if completed.returncode == 0 else "failed", completed.returncode, elapsed, completed.stdout[-2000:], completed.stderr[-2000:])
        except subprocess.TimeoutExpired as exc:
            return CommandReceipt(command, "timeout", None, round((time.perf_counter() - started) * 1000, 3), str(exc.stdout or "")[-2000:], str(exc.stderr or "")[-2000:])
        except Exception as exc:
            return CommandReceipt(command, "error", None, round((time.perf_counter() - started) * 1000, 3), "", f"{type(exc).__name__}: {str(exc)[:500]}")
