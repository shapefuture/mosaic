"""Exact, composable identity for safe durable work reuse.

A checkpoint key is a label, not proof that old work applies to current inputs.
This value combines the immutable dimensions that can change a coding result.
Callers may leave fields empty when unavailable, but then cannot claim the
stronger reuse boundary.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Iterable


@dataclass(frozen=True)
class ResumeIdentity:
    task_contract_hash: str
    workspace_input_root: str
    plan_identity: str
    path_policy_hash: str = ""
    tool_manifest_hash: str = ""
    provider_policy_hash: str = ""
    evidence_refs: tuple[str, ...] = ()

    @property
    def evidence_set_hash(self) -> str:
        raw = json.dumps(sorted(self.evidence_refs), separators=(",", ":")).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    @property
    def digest(self) -> str:
        value = {**asdict(self), "evidence_set_hash": self.evidence_set_hash}
        raw = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    def as_dict(self) -> dict:
        return {**asdict(self), "evidence_set_hash": self.evidence_set_hash, "digest": self.digest}

    @classmethod
    def build(
        cls,
        *,
        task_contract_hash: str,
        workspace_input_root: str,
        plan_identity: str,
        path_policy_hash: str = "",
        tool_manifest_hash: str = "",
        provider_policy_hash: str = "",
        evidence_refs: Iterable[str] = (),
    ) -> "ResumeIdentity":
        if not task_contract_hash or not workspace_input_root or not plan_identity:
            raise ValueError("resume identity requires task contract, workspace root, and plan identity")
        return cls(
            task_contract_hash=str(task_contract_hash), workspace_input_root=str(workspace_input_root),
            plan_identity=str(plan_identity), path_policy_hash=str(path_policy_hash),
            tool_manifest_hash=str(tool_manifest_hash), provider_policy_hash=str(provider_policy_hash),
            evidence_refs=tuple(sorted(dict.fromkeys(str(ref) for ref in evidence_refs))),
        )
