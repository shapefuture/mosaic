"""Evidence-preserving deterministic transcript compaction."""
from __future__ import annotations
import hashlib,json,re
from dataclasses import dataclass
from .artifacts import ContentAddressedArtifactStore
@dataclass(frozen=True)
class CompactionResult:
 text:str;artifact_ref:str;removed_chars:int;summary:str
 manifest_ref:str="";source_hash:str="";retained_hash:str="";protected_fact_count:int=0
 pointer_block:str="";tail_block:str=""
 def content_blocks(self)->list[dict]:
  blocks=[]
  if self.pointer_block:blocks.append({"type":"text","text":self.pointer_block,"cache_control":{"type":"ephemeral"}})
  if self.tail_block:blocks.append({"type":"text","text":self.tail_block,"cache_control":{"type":"ephemeral"}})
  return blocks
class TranscriptCompactor:
 BOUNDARY_PATTERNS=(r"\n(?:### |## )",r"\nAssistant tool request:",r"\nTool result",r"\n\{\"kind\":\s*\"(?:node_end|run_checkpoint|test_result)",r"\n<!-- chimera:subgoal-boundary -->",r"\n=== SUBGOAL BOUNDARY ===")
 def __init__(self,store:ContentAddressedArtifactStore,max_chars:int=60000,tail_chars:int=40000):self.store=store;self.max=max_chars;self.tail=tail_chars
 def _cut_index(self,text:str)->int:
  naive=max(0,len(text)-self.tail)
  if naive<=0:return 0
  window=max(2000,min(20000,self.tail//2 if self.tail else 2000))
  lower=max(0,naive-window);segment=text[lower:naive]
  best=-1
  for pattern in self.BOUNDARY_PATTERNS:
   for match in re.finditer(pattern,segment,re.I):
    best=max(best,lower+match.start()+1)
  return best if best>=0 else naive
 def compact(self,text:str,session:str):
  if len(text)<=self.max:return None
  cut=self._cut_index(text);old=text[:cut];tail=text[cut:]
  ref=self.store.put(old,media_type="text/plain",provenance={"kind":"conversation-compaction","session":session,"chars":len(old)})
  tools=re.findall(r"Assistant tool request:\s*([^\n<]{0,120}|<tool_call>[^<]{0,120})",old)
  failures=re.findall(r"(?:error|failed|denied)[^\n]{0,160}",old,re.I)
  source_hash="sha256:"+hashlib.sha256(old.encode()).hexdigest()
  retained_hash="sha256:"+hashlib.sha256(tail.encode()).hexdigest()
  manifest={"schema_version":"chimera.transcript-replacement.v1","session_hash":"sha256:"+hashlib.sha256(session.encode()).hexdigest(),"replaced_content_hash":source_hash,"replacement_artifact":ref.digest,"retained_tail_hash":retained_hash,"replaced_chars":len(old),"retained_chars":len(tail),"tool_request_count":len(tools),"failure_signal_count":len(failures),"cut_strategy":"boundary-snap" if cut!=max(0,len(text)-self.tail) else "fixed-tail"}
  manifest_ref=self.store.put(json.dumps(manifest,sort_keys=True,separators=(",",":")),media_type="application/vnd.chimera.transcript-replacement+json",provenance={"kind":"transcript-replacement-manifest","source":ref.digest})
  summary=f"compacted_turn_material chars={len(old)} tools={len(tools)} failures={len(failures)} cut={manifest['cut_strategy']}"
  pointer=f"[prior transcript replaced: artifact:{ref.digest}; replacement_manifest:artifact:{manifest_ref.digest}; {summary}]\n"
  return CompactionResult(pointer+tail,f"artifact:{ref.digest}",len(old),summary,f"artifact:{manifest_ref.digest}",source_hash,retained_hash,len(failures)+len(tools),pointer,tail)
