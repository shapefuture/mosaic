"""Provider reliability profile from existing usage/tool-protocol telemetry."""
from __future__ import annotations
from dataclasses import dataclass, asdict
import pathlib
from .wal import WAL

@dataclass(frozen=True)
class ProviderReliabilityProfile:
    provider:str; model:str; calls:int; failures:int; malformed_tool_calls:int; rate_limits:int; reliability:float
    def as_dict(self): return asdict(self)

class ProviderReliabilityRegistry:
    def __init__(self, root:pathlib.Path): self.wal=WAL(pathlib.Path(root))
    def record(self, provider:str, model:str, *, success:bool, malformed_tool_call:bool=False, rate_limited:bool=False):
        self.wal.append("provider_reliability",{"provider":provider,"model":model,"success":bool(success),"malformed_tool_call":bool(malformed_tool_call),"rate_limited":bool(rate_limited)})
    def profile(self, provider:str, model:str)->ProviderReliabilityProfile:
        rows=[e["data"] for e in self.wal.replay(kind="provider_reliability") if e["data"].get("provider")==provider and e["data"].get("model")==model]
        calls=len(rows); failures=sum(not r.get("success") for r in rows); malformed=sum(bool(r.get("malformed_tool_call")) for r in rows); rate=sum(bool(r.get("rate_limited")) for r in rows)
        reliability=1.0 if calls==0 else max(0.0,1.0-(failures+malformed+rate)/max(1,calls))
        return ProviderReliabilityProfile(provider,model,calls,failures,malformed,rate,reliability)
