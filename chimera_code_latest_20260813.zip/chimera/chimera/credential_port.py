"""Fail-closed credential boundary for future provider/MCP integrations."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Protocol


class CredentialUnavailable(PermissionError): pass


@dataclass(frozen=True)
class CredentialContext:
    issuer: str
    subject_hash: str
    authorization_context_id: str


class CredentialPort(Protocol):
    def context(self, issuer: str) -> CredentialContext: ...
    def headers(self, issuer: str) -> Mapping[str, str]: ...
    def revoke(self, issuer: str) -> None: ...


class NullCredentialPort:
    """Default local implementation: no environment probing or secret storage."""
    def context(self, issuer: str) -> CredentialContext:
        raise CredentialUnavailable(f"no credential context configured for issuer {issuer!r}")
    def headers(self, issuer: str) -> Mapping[str, str]:
        raise CredentialUnavailable(f"no ephemeral credential headers configured for issuer {issuer!r}")
    def revoke(self, issuer: str) -> None:
        raise CredentialUnavailable(f"no credential context configured for issuer {issuer!r}")
