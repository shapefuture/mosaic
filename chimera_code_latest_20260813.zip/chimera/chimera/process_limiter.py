"""Immutable process-wide LLM concurrency gate with interactive priority."""
from __future__ import annotations
import os,threading
class ProcessLLMGate:
 _lock=threading.Lock();_gate=None;_limit=None
 @classmethod
 def acquire(cls,interactive:bool=True):
  limit=max(1,int(os.environ.get('CHIMERA_MAX_CONCURRENT_LLM','4')))
  with cls._lock:
   if cls._gate is None:cls._gate=threading.BoundedSemaphore(limit);cls._limit=limit
  cls._gate.acquire()
  return cls._gate
