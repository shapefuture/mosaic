"""Conservative prompt-injection quarantine for retrieved tool content.

This is not a claim to solve prompt injection.  It blocks a small, explicit set
of high-confidence instruction-override/exfiltration patterns before retrieved
content is re-injected into a model turn.  The original content stays available
to deterministic local tooling; the model receives a bounded receipt rather
than attacker-authored instructions.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import re


@dataclass(frozen=True)
class QuarantineDecision:
    quarantined: bool
    reasons: tuple[str, ...]
    content_hash: str
    placeholder: str


class RetrievedContentGuard:
    # Patterns intentionally require an instruction-like combination rather
    # than a generic word such as "system" that is common in legitimate code.
    # Anchor command-like patterns at a line start.  A codebase or security
    # document may discuss prompt injection ("how to ignore previous
    # instructions") without itself instructing the agent to do so.
    PATTERNS = (
        ("instruction_override", re.compile(r"(?:^|\n)\s*(?:ignore|disregard|override)\b.{0,80}\b(?:previous|prior|system|developer)\b.{0,80}\b(?:instructions?|rules?|message)\b", re.I)),
        ("role_impersonation", re.compile(r"(?:^|\n)\s*(?:(?:system|developer)\s+message\s*[:#]|you\s+are\s+now\b)", re.I)),
        ("secret_exfiltration", re.compile(r"(?:^|\n)\s*(?:send|upload|exfiltrate|reveal|print)\b.{0,100}\b(?:api[_ -]?key|token|secret|credential|password)\b", re.I)),
        ("tool_override", re.compile(r"(?:^|\n)\s*(?:call|use|invoke)\b.{0,80}\b(?:tool|shell|terminal)\b.{0,80}\b(?:ignore|bypass|without confirmation)\b", re.I)),
    )

    @staticmethod
    def _hash(content: str) -> str:
        return "sha256:" + hashlib.sha256(content.encode("utf-8", errors="replace")).hexdigest()

    def inspect(self, content: str, *, source: str = "retrieved-content") -> QuarantineDecision:
        reasons = tuple(name for name, pattern in self.PATTERNS if pattern.search(content))
        digest = self._hash(content)
        if not reasons:
            return QuarantineDecision(False, (), digest, "")
        return QuarantineDecision(
            True, reasons, digest,
            f"[quarantined {source}: high-confidence untrusted instruction pattern; "
            f"reasons={','.join(reasons)}; content_hash={digest}]",
        )
