"""Live provider QoS ledger for latency/tokens/error-aware routing."""
from __future__ import annotations
from dataclasses import dataclass, asdict
import pathlib, statistics, time
from .wal import WAL, wal_write

@dataclass(frozen=True)
class ProviderQoSProfile:
    provider:str; model:str; samples:int; p50_ms:float|None; p95_ms:float|None; avg_tokens:float|None; errors:int; score:float
    def as_dict(self): return asdict(self)

class ProviderQoSLedger:
    def __init__(self, root:pathlib.Path): self.wal=WAL(pathlib.Path(root))
    def record(self, provider:str, model:str, *, latency_ms:float, tokens:int=0, ok:bool=True, error_class:str|None=None):
        wal_write(self.wal,"provider_qos",{"provider":provider or "unknown","model":model or "unknown","latency_ms":float(latency_ms),"tokens":int(tokens or 0),"ok":bool(ok),"error_class":error_class,"ts":time.time()})
    def profile(self, provider:str, model:str, window:int=100)->ProviderQoSProfile:
        rows=[e["data"] for e in self.wal.replay(kind="provider_qos") if e["data"].get("provider")==provider and e["data"].get("model")==model][-window:]
        lat=[float(r.get("latency_ms",0)) for r in rows if r.get("ok")]
        toks=[int(r.get("tokens",0)) for r in rows if r.get("ok")]
        errors=sum(1 for r in rows if not r.get("ok"))
        p50=statistics.median(lat) if lat else None
        p95=(sorted(lat)[max(0,int(len(lat)*0.95)-1)] if lat else None)
        avg=statistics.mean(toks) if toks else None
        # Lower is better; errors dominate. Unknown = neutral 1.0.
        score=(1.0 + errors) * ((p95 or p50 or 1000.0)/1000.0) * (1.0 + ((avg or 0)/10000.0))
        return ProviderQoSProfile(provider,model,len(rows),p50,p95,avg,errors,round(score,4))
