"""Prompt assembly facade for stable-cache-aware RLM prompts."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .prompt_cache import PromptCacheTracker, PromptPartition


@dataclass(frozen=True)
class AssembledPrompt:
    text: str
    partition: PromptPartition | None = None


class PromptAssembler:
    def __init__(self, tracker: PromptCacheTracker | None = None) -> None:
        self.tracker = tracker or PromptCacheTracker()

    def assemble(self, *, session: str, prefix: str, suffix: str, history: str = "", live: str = "") -> AssembledPrompt:
        partition = self.tracker.partition(session, prefix, suffix, history=history, live=live)
        return AssembledPrompt(prefix + (history or "") + (live or suffix), partition)

    @staticmethod
    def from_blocks(blocks: list[dict[str, Any]]) -> str:
        return "".join(str(block.get("text", "")) for block in blocks)


    def assemble_blocks(self, *, session: str, stable_blocks: list[dict[str, Any]], live_blocks: list[dict[str, Any]] | None = None) -> AssembledPrompt:
        """Assemble provider content blocks while preserving block boundaries."""
        live_blocks = live_blocks or []
        text = self.from_blocks(stable_blocks + live_blocks)
        partition = self.tracker.partition(session, self.from_blocks(stable_blocks), self.from_blocks(live_blocks))
        return AssembledPrompt(text, partition)

    @staticmethod
    def compaction_blocks(compaction_result: Any) -> list[dict[str, Any]]:
        if compaction_result is None:
            return []
        if hasattr(compaction_result, "content_blocks"):
            return list(compaction_result.content_blocks())
        return [{"type":"text","text":str(compaction_result)}]
