"""Focused-coder first-pass generation and repair loops."""
from __future__ import annotations

import os
import pathlib
import re
from typing import Any, Dict, List

from .pytest_repair import extract_repair_hints
from .quality import PatchQualityGate, TaskContract


class FocusedRepairMixin:
    def _focused_initial_generation_pass(
        self,
        *,
        branch: str,
        model: str,
        contract: TaskContract,
        interfaces: str,
        context_mode: str,
        evidence: List[Dict[str, Any]],
    ) -> tuple[list[str], int, int, dict[str, Any], list[dict[str, Any]], dict[str, list[str]]]:
        total_tokens = 0
        api_calls = 0
        changed: list[str] = []
        last_response: dict[str, Any] = {}
        provider_records: list[dict[str, Any]] = []
        static_errors_by_target: dict[str, list[str]] = {}
        for target in contract.targets:
            target_contract = TaskContract(
                task=contract.task, tests=contract.tests, targets=[target],
                protected_paths=contract.protected_paths, required_literals=contract.required_literals,
                required_symbols=contract.required_symbols, required_calls=contract.required_calls,
                required_mapping_keys=contract.required_mapping_keys,
                required_prefixes=contract.required_prefixes, required_call_arity=contract.required_call_arity,
            )
            target_gate = PatchQualityGate(self.root, target_contract)
            scaffold_seed = self._deterministic_domain_scaffold(target_contract, target)
            target_interfaces = interfaces
            if scaffold_seed:
                seed_content = scaffold_seed.get("files", [{}])[0].get("content", "")
                target_interfaces += (
                    "\nVERIFIED STARTING SCAFFOLD (preserve its real API calls; improve only where the task requires):\n"
                    + seed_content[:14_000]
                )
            if target.mode == "edit":
                try:
                    branch_content = self.workspace.read(branch, target.path).decode("utf-8", errors="ignore")
                    target_interfaces += f"\nCURRENT BRANCH TARGET {target.path}:\n{branch_content[:24_000]}"
                except Exception:
                    pass
            prompt = self._target_prompt(
                target_contract, target, target_interfaces, model=model, context_mode=context_mode,
            )
            context_metrics = getattr(self._thread_local, "last_context_pack", None)
            if context_metrics:
                evidence.append({"target": target.path, "stage": "context-pack", "ok": True, **context_metrics})
            payload = self._deterministic_adapter_payload(contract, target, branch=branch)
            if not payload:
                try:
                    existing = self.workspace.read(branch, target.path).decode("utf-8", errors="ignore")
                except Exception:
                    existing = ""
                if not existing.strip():
                    payload = scaffold_seed
            if payload:
                if isinstance(payload, dict):
                    payload["aci_approved"] = True
                response = {"model": "deterministic-adapter", "provider": "local", "real_call": False, "_quality_attempts": 0}
                tokens = 0
            else:
                payload, response, tokens = self._strict_patch_call(prompt, model, target, attempts=2)
            total_tokens += tokens
            api_calls += int(response.get("_quality_attempts", 0) or 0)
            last_response = response
            if response.get("real_call"):
                provider_records.append({key: response.get(key) for key in ("model", "provider", "key_slot", "key_pool_size", "_quality_attempts")})
            if not payload:
                evidence.append({"target": target.path, "stage": "generation", "ok": False,
                                 "diagnostics": response.get("_quality_diagnostics", [])})
                continue
            normalizations = self._normalise_contract_values(payload, target_contract)
            if normalizations:
                evidence.append({"target": target.path, "stage": "contract-normalization", "ok": True,
                                 "changes": normalizations})
            ok, errors = target_gate.validate(payload)
            if not ok:
                evidence.append({"target": target.path, "stage": "quality_gate", "ok": False, "errors": errors})
                static_errors_by_target[target.path] = errors
                continue
            with self._workspace_lock:
                applied = self.action_executor.apply_patch_payload(branch, payload)
            evidence.append({"target": target.path, "stage": "apply", "ok": bool(applied.get("applied")), **applied})
            changed.extend(applied.get("applied", []))
        return changed, total_tokens, api_calls, last_response, provider_records, static_errors_by_target

    @staticmethod
    def _repair_targets(contract: TaskContract, test: Dict[str, Any]):
        failure_text = (str(test.get("stdout", "")) + "\n" + str(test.get("stderr", ""))).lower()
        explicitly_missing = {
            symbol.lower()
            for symbol in re.findall(r"cannot import name ['\"]([^'\"]+)['\"]", failure_text)
        }
        missing_modules = {
            module.lower().replace(".", "/") + ".py"
            for module in re.findall(r"no module named ['\"]([^'\"]+)['\"]", failure_text)
        }
        symbol_targets = [
            target for target in contract.targets
            if any(symbol.lower() in explicitly_missing for symbol in contract.required_symbols.get(target.path, []))
        ]
        module_targets = [target for target in contract.targets if target.path.lower() in missing_modules]
        path_targets = [
            target for target in contract.targets
            if pathlib.PurePosixPath(target.path).stem.lower() in failure_text
        ]
        repair_targets = symbol_targets or module_targets or path_targets
        return repair_targets or [target for target in contract.targets if target.mode == "create"] or contract.targets

    def _focused_repair_loop(
        self,
        *,
        branch: str,
        model: str,
        contract: TaskContract,
        interfaces: str,
        context_mode: str,
        test_command: str,
        verification_scope: str,
        test: Dict[str, Any],
        evidence: List[Dict[str, Any]],
        changed: list[str],
        total_tokens: int,
        api_calls: int,
        last_response: Dict[str, Any],
        provider_records: list[dict[str, Any]],
        static_errors_by_target: dict[str, list[str]],
    ) -> tuple[Dict[str, Any], list[str], int, int, Dict[str, Any], list[dict[str, Any]], int]:
        try:
            max_repair_rounds = max(1, min(3, int(os.environ.get("CHIMERA_MAX_REPAIR_ROUNDS", "2"))))
        except ValueError:
            max_repair_rounds = 2
        repair_rounds = 0
        while test.get("status") != 0 and contract.targets and repair_rounds < max_repair_rounds:
            repair_rounds += 1
            for target in self._repair_targets(contract, test):
                target_contract = TaskContract(
                    task=contract.task, tests=contract.tests, targets=[target],
                    protected_paths=contract.protected_paths, required_literals=contract.required_literals,
                    required_symbols=contract.required_symbols, required_calls=contract.required_calls,
                    required_mapping_keys=contract.required_mapping_keys,
                    required_prefixes=contract.required_prefixes, required_call_arity=contract.required_call_arity,
                )
                target_gate = PatchQualityGate(self.root, target_contract)
                repair_interfaces = interfaces
                scaffold_seed = self._deterministic_domain_scaffold(target_contract, target)
                if scaffold_seed:
                    seed_content = scaffold_seed.get("files", [{}])[0].get("content", "")
                    repair_interfaces += "\nVERIFIED STARTING SCAFFOLD:\n" + seed_content[:14_000]
                if target.path in self.workspace.list_overlay(branch):
                    current = self.workspace.read(branch, target.path).decode("utf-8", errors="ignore")
                    repair_interfaces += f"\nCURRENT BRANCH {target.path}:\n{current[:24_000]}"
                repair_evidence = dict(test)
                static_errors = static_errors_by_target.get(target.path, [])
                if static_errors:
                    repair_evidence["stderr"] = (
                        str(repair_evidence.get("stderr", ""))
                        + "\nSTATIC ADMISSION ERRORS FROM THE PREVIOUS CANDIDATE:\n"
                        + "\n".join(static_errors)
                    )
                repair_hint_obj = extract_repair_hints(str(repair_evidence.get("stdout", "")), str(repair_evidence.get("stderr", "")))
                repair_evidence["repair_hints"] = list(repair_hint_obj.hints)
                repair_evidence["repair_anchors"] = list(repair_hint_obj.anchors)
                if repair_hint_obj.hints or repair_hint_obj.anchors:
                    evidence.append({"target": target.path, "stage": "repair-hints", "ok": True, **repair_hint_obj.as_dict()})
                prompt = self._target_prompt(
                    target_contract, target, repair_interfaces, repair=repair_evidence,
                    model=model, context_mode=context_mode,
                )
                context_metrics = getattr(self._thread_local, "last_context_pack", None)
                if context_metrics:
                    evidence.append({"target": target.path, "stage": "repair-context-pack", "ok": True, **context_metrics})
                payload, response, tokens = self._strict_patch_call(prompt, model, target, attempts=2)
                total_tokens += tokens
                api_calls += int(response.get("_quality_attempts", 1) or 1)
                last_response = response
                if response.get("real_call"):
                    provider_records.append({key: response.get(key) for key in ("model", "provider", "key_slot", "key_pool_size", "_quality_attempts")})
                fallback_used = False
                if not payload:
                    evidence.append({"target": target.path, "stage": f"repair-{repair_rounds}-generation", "ok": False,
                                     "diagnostics": response.get("_quality_diagnostics", [])})
                    payload = self._deterministic_domain_scaffold(target_contract, target)
                    if isinstance(payload, dict):
                        payload["aci_approved"] = True
                    fallback_used = payload is not None
                if not payload:
                    continue
                normalizations = self._normalise_contract_values(payload, target_contract)
                if normalizations:
                    evidence.append({"target": target.path, "stage": "contract-normalization", "ok": True,
                                     "changes": normalizations})
                ok, errors = target_gate.validate(payload)
                if not ok and not fallback_used:
                    evidence.append({"target": target.path, "stage": f"repair-{repair_rounds}-gate", "ok": False, "errors": errors})
                    payload = self._deterministic_domain_scaffold(target_contract, target)
                    if isinstance(payload, dict):
                        payload["aci_approved"] = True
                    fallback_used = payload is not None
                    if fallback_used:
                        ok, errors = target_gate.validate(payload)
                if not ok:
                    evidence.append({"target": target.path, "stage": f"repair-{repair_rounds}-fallback-gate", "ok": False, "errors": errors})
                    continue
                with self._workspace_lock:
                    applied = self.action_executor.apply_patch_payload(branch, payload)
                stage = "semantic-scaffold-fallback" if fallback_used else f"repair-{repair_rounds}"
                evidence.append({"target": target.path, "stage": stage, "ok": bool(applied.get("applied")), **applied})
                changed.extend(applied.get("applied", []))
            with self._workspace_lock:
                test = self.action_executor.run_branch_tests(
                    branch, command=test_command, impact_scope=(verification_scope == "impact"),
                )
        return test, changed, total_tokens, api_calls, last_response, provider_records, repair_rounds

    def _focused_test_scaffold_fallback(
        self,
        *,
        branch: str,
        contract: TaskContract,
        test_command: str,
        verification_scope: str,
        test: Dict[str, Any],
        evidence: List[Dict[str, Any]],
        changed: list[str],
    ) -> tuple[Dict[str, Any], list[str]]:
        if test.get("status") == 0:
            return test, changed
        for target in contract.targets:
            scaffold = self._deterministic_domain_scaffold(contract, target)
            if not scaffold or not target.path.startswith("tests/"):
                continue
            target_contract = TaskContract(
                task=contract.task, tests=contract.tests, targets=[target],
                protected_paths=contract.protected_paths, required_literals=contract.required_literals,
                required_symbols=contract.required_symbols, required_calls=contract.required_calls,
                required_mapping_keys=contract.required_mapping_keys,
                required_prefixes=contract.required_prefixes, required_call_arity=contract.required_call_arity,
            )
            ok, errors = PatchQualityGate(self.root, target_contract).validate(scaffold)
            if not ok:
                evidence.append({"target": target.path, "stage": "test-scaffold-gate", "ok": False, "errors": errors})
                continue
            with self._workspace_lock:
                applied = self.action_executor.apply_patch_payload(branch, scaffold)
                test = self.action_executor.run_branch_tests(
                    branch, command=test_command, impact_scope=(verification_scope == "impact"),
                )
            evidence.append({"target": target.path, "stage": "test-scaffold-fallback", "ok": test.get("status") == 0, **applied})
            changed.extend(applied.get("applied", []))
        return test, changed
