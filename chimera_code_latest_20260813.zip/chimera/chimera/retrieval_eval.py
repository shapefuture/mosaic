"""Small deterministic corpus runner for local changed-line retrieval fixtures."""
from __future__ import annotations

from dataclasses import dataclass
import json
import pathlib
from typing import Any

from .changed_lines import parse_unified_diff_ranges, python_symbol_anchors


@dataclass(frozen=True)
class RetrievalEvalResult:
    case_id: str
    passed: bool
    expected_symbols: tuple[str, ...]
    actual_symbols: tuple[str, ...]
    range_count: int


def run_changed_symbol_corpus(corpus_dir: pathlib.Path) -> dict[str, Any]:
    root = pathlib.Path(corpus_dir)
    manifest = json.loads((root / "manifest.json").read_text())
    results: list[RetrievalEvalResult] = []
    for case in manifest.get("cases", []):
        case_id = str(case["id"])
        path = str(case["path"])
        source = (root / case["source"]).read_text()
        diff = (root / case["diff"]).read_text()
        anchors = python_symbol_anchors(path, source, parse_unified_diff_ranges(diff))
        actual = tuple(anchor.name for anchor in anchors)
        expected = tuple(case.get("expected_symbols", []))
        results.append(RetrievalEvalResult(case_id, set(expected) <= set(actual), expected, actual, len(parse_unified_diff_ranges(diff))))
    return {
        "kind": "deterministic-changed-symbol-corpus",
        "cases": [result.__dict__ for result in results],
        "passed": all(result.passed for result in results),
        "passed_cases": sum(result.passed for result in results),
        "total_cases": len(results),
        "note": "structural correctness fixture, not a claim of coding-task outcome superiority",
    }
