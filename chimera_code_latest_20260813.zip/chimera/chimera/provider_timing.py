"""Reasoning-aware provider timeout and cache-age policies."""
from __future__ import annotations
from dataclasses import dataclass
@dataclass(frozen=True)
class ProviderTimingPolicy:
    base_idle_seconds:float=180
    def timeout(self,effort:str|None,total_cap:float=720):
        scale={"low":1,"medium":1,"high":2,"xhigh":3,"max":4}.get((effort or "").lower(),1)
        return min(total_cap,self.base_idle_seconds*scale)
