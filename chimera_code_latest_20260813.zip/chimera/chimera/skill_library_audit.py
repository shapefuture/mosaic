"""Skill library invariant audit.

Ported from SOTA-skills invariants where applicable to Chimera's skill corpus
and external skill packs.  It focuses on instruction surfaces only and fails
closed on empty scopes so a green check cannot mean "checked nothing".
"""
from __future__ import annotations

import json
import pathlib
import re
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class SkillFinding:
    severity: str  # error | warning | info
    path: str
    rule: str
    message: str


class SkillLibraryAudit:
    def __init__(self, root: pathlib.Path, *, max_instruction_lines: int = 500, max_description_chars: int = 1024) -> None:
        self.root = pathlib.Path(root).resolve()
        self.max_instruction_lines = int(max_instruction_lines)
        self.max_description_chars = int(max_description_chars)

    def run(self) -> dict[str, Any]:
        files = self._instruction_files()
        findings: list[SkillFinding] = []
        if not files:
            findings.append(SkillFinding("error", str(self.root), "non-empty-scope", "no SKILL.md or rules/*.md instruction files found"))
        for path in files:
            rel = self._rel(path)
            text = path.read_text(encoding="utf-8", errors="replace")
            lines = text.splitlines()
            if len(lines) > self.max_instruction_lines:
                findings.append(SkillFinding("error", rel, "instruction-line-budget", f"{len(lines)} lines > {self.max_instruction_lines}"))
            if path.name == "SKILL.md":
                front = self._frontmatter(text)
                description = str(front.get("description", ""))
                name = str(front.get("name", ""))
                if not name:
                    findings.append(SkillFinding("error", rel, "frontmatter-name", "missing name"))
                if not description:
                    findings.append(SkillFinding("error", rel, "frontmatter-description", "missing description"))
                if len(description) > self.max_description_chars:
                    findings.append(SkillFinding("error", rel, "description-budget", f"description {len(description)} chars > {self.max_description_chars}"))
                if ": " in name:
                    findings.append(SkillFinding("error", rel, "yaml-name-shape", "name contains unquoted ': ' pattern"))
            if "/rules/" in path.as_posix() and "## Audit checklist" not in text:
                findings.append(SkillFinding("warning", rel, "rules-audit-checklist", "rules file lacks ## Audit checklist"))
            for target in self._markdown_links(text):
                if target.endswith(".md") and not (path.parent / target).resolve().exists():
                    findings.append(SkillFinding("error", rel, "relative-md-link", f"missing linked markdown target {target}"))
            lower = text.lower()
            for secretish in ("sk-", "api_key=", "authorization: bearer", "private key"):
                if secretish in lower:
                    findings.append(SkillFinding("warning", rel, "secret-shaped-text", f"contains secret-shaped marker {secretish!r}"))
        errors = [f for f in findings if f.severity == "error"]
        return {
            "schema_version": "chimera.skill-library-audit.v1",
            "root": str(self.root),
            "instruction_files_checked": len(files),
            "status": "pass" if not errors else "fail",
            "findings": [asdict(f) for f in findings],
            "rules": {
                "max_instruction_lines": self.max_instruction_lines,
                "max_description_chars": self.max_description_chars,
                "rules_files_should_have_audit_checklist": True,
                "relative_markdown_links_must_resolve": True,
                "empty_scope_fails_closed": True,
            },
            "promotion_allowed": False,
        }

    def _instruction_files(self) -> list[pathlib.Path]:
        values = set(self.root.glob("**/SKILL.md"))
        values.update(self.root.glob("**/rules/*.md"))
        return sorted(p for p in values if "__MACOSX" not in p.parts and p.is_file())

    @staticmethod
    def _frontmatter(text: str) -> dict[str, str]:
        if not text.startswith("---"):
            return {}
        parts = text.split("---", 2)
        if len(parts) < 3:
            return {}
        out: dict[str, str] = {}
        current: str | None = None
        for line in parts[1].splitlines():
            if re.match(r"^[A-Za-z_][A-Za-z0-9_-]*:\s*", line):
                key, value = line.split(":", 1)
                current = key.strip()
                out[current] = value.strip().strip('"\'')
            elif current and line.startswith((" ", "\t")):
                out[current] = (out[current] + " " + line.strip()).strip()
        return out

    @staticmethod
    def _markdown_links(text: str) -> list[str]:
        out = []
        for match in re.finditer(r"\[[^\]]+\]\(([^)]+)\)", text):
            target = match.group(1).split("#", 1)[0]
            if target and not re.match(r"^[a-z]+://", target) and not target.startswith("mailto:"):
                out.append(target)
        return out

    def _rel(self, path: pathlib.Path) -> str:
        try:
            return str(path.relative_to(self.root))
        except ValueError:
            return str(path)
