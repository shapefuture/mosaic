"""Budgeted ablation-based causal context attribution."""
from __future__ import annotations
import hashlib,json
from dataclasses import dataclass
from typing import Any,Callable,Mapping
@dataclass(frozen=True)
class Attribution:
    item:str;changed:bool;baseline_hash:str;ablated_hash:str;score_delta:float|None
@dataclass(frozen=True)
class AttributionReport:
    status:str;evaluations:int;items:tuple[Attribution,...];dead_items:tuple[str,...];reason:str
class ContextAttributor:
    def __init__(self,max_ablations:int=8):self.max=max(0,max_ablations)
    @staticmethod
    def _hash(value):return "sha256:"+hashlib.sha256(json.dumps(value,sort_keys=True,default=str).encode()).hexdigest()
    def attribute(self,items:Mapping[str,Any],evaluate:Callable[[dict[str,Any]],dict[str,Any]])->AttributionReport:
        if not items:return AttributionReport("unavailable",0,(),(),"no context items")
        baseline=evaluate(dict(items));base_hash=self._hash(baseline.get("output"));base_score=baseline.get("score");rows=[]
        for key in list(items)[:self.max]:
            subset=dict(items);subset.pop(key);result=evaluate(subset);h=self._hash(result.get("output"));score=result.get("score")
            delta=(float(base_score)-float(score)) if isinstance(base_score,(int,float)) and isinstance(score,(int,float)) else None
            rows.append(Attribution(key,h!=base_hash,base_hash,h,delta))
        dead=tuple(row.item for row in rows if not row.changed and (row.score_delta is None or row.score_delta==0))
        return AttributionReport("measured",1+len(rows),tuple(rows),dead,"ablation relative to supplied evaluator; not embedding similarity")
