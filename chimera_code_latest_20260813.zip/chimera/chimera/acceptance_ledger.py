"""Durable, scope-bound acceptance cards.

A plan is not evidence.  Each card binds one observable acceptance condition to
its target paths and to the exact contract snapshot that introduced it.  A card
can close only with a resolvable content-addressed evidence artifact.  During a
replan, completed cards survive *only* when their condition and scoped paths
are unchanged; changed work opens a new card rather than inheriting a stale
"done" state.

This is the useful deterministic core from source-audited spec/Fable workflows:
explicit acceptance, evidence to close, and completed-work preservation without
turning an agent's narration into authority.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import pathlib
import time
from typing import Any, Iterable, Mapping

from .artifacts import ContentAddressedArtifactStore
from .wal import WAL


@dataclass(frozen=True)
class AcceptanceCard:
    id: str
    criterion: str
    paths: tuple[str, ...]
    contract_hash: str

    @property
    def identity(self) -> str:
        # Excludes the contract hash so a replan can identify the same scoped
        # condition while still deciding whether the old closure is valid.
        value = {"criterion": self.criterion, "paths": list(self.paths)}
        return "sha256:" + hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


@dataclass(frozen=True)
class AcceptanceState:
    card: AcceptanceCard
    status: str  # open | closed | stale
    evidence_refs: tuple[str, ...] = ()
    closed_at: float | None = None
    stale_reason: str | None = None

    def as_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["card"] = asdict(self.card)
        return value


class AcceptanceLedger:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.wal = WAL(self.root)
        self.artifacts = ContentAddressedArtifactStore(self.root)

    @staticmethod
    def contract_hash(contract: Mapping[str, Any]) -> str:
        raw = json.dumps(dict(contract), sort_keys=True, separators=(",", ":"), default=str).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    @staticmethod
    def _card_id(criterion: str, paths: Iterable[str], contract_hash: str) -> str:
        value = {"criterion": criterion, "paths": sorted(set(paths)), "contract_hash": contract_hash}
        return "ac:" + hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()[:20]

    @classmethod
    def card(cls, criterion: str, paths: Iterable[str], contract_hash: str) -> AcceptanceCard:
        scoped = tuple(sorted(set(str(path) for path in paths if path)))
        return AcceptanceCard(cls._card_id(criterion, scoped, contract_hash), criterion, scoped, contract_hash)

    def _artifact_exists(self, ref: str) -> bool:
        if not isinstance(ref, str) or not ref.startswith("artifact:sha256:"):
            return False
        return self.artifacts.has(ref.removeprefix("artifact:"))

    def _events(self) -> list[dict[str, Any]]:
        return [entry["data"] for entry in self.wal.replay(kind="acceptance_card")]

    def _prior_by_identity(self) -> dict[str, AcceptanceState]:
        rows: dict[str, AcceptanceState] = {}
        for event in self._events():
            card_data = event.get("card")
            if not isinstance(card_data, Mapping):
                continue
            try:
                card = AcceptanceCard(
                    id=str(card_data["id"]), criterion=str(card_data["criterion"]),
                    paths=tuple(str(item) for item in card_data.get("paths", ())),
                    contract_hash=str(card_data["contract_hash"]),
                )
            except (KeyError, TypeError, ValueError):
                continue
            status = str(event.get("status", "open"))
            refs = tuple(str(item) for item in event.get("evidence_refs", ()) if self._artifact_exists(str(item)))
            if status == "closed" and not refs:
                # A bogus/non-resolvable evidence reference cannot close a card.
                continue
            rows[card.identity] = AcceptanceState(
                card=card, status=status, evidence_refs=refs,
                closed_at=event.get("closed_at"), stale_reason=event.get("stale_reason"),
            )
        return rows

    def reconcile(self, cards: Iterable[AcceptanceCard]) -> tuple[AcceptanceState, ...]:
        """Open/reuse cards for a current plan and make stale closure explicit."""
        prior = self._prior_by_identity()
        states: list[AcceptanceState] = []
        for card in cards:
            before = prior.get(card.identity)
            if before is not None and before.status == "closed" and before.card.contract_hash == card.contract_hash:
                states.append(AcceptanceState(card, "closed", before.evidence_refs, before.closed_at))
                continue
            if before is not None and before.status == "closed":
                stale = AcceptanceState(card, "stale", before.evidence_refs, before.closed_at, "contract scope changed")
                self.wal.append("acceptance_card", stale.as_dict())
            open_state = AcceptanceState(card, "open")
            self.wal.append("acceptance_card", open_state.as_dict())
            states.append(open_state)
        return tuple(states)

    def close(self, card: AcceptanceCard, evidence_refs: Iterable[str]) -> AcceptanceState:
        refs = tuple(dict.fromkeys(str(ref) for ref in evidence_refs))
        if not refs:
            raise ValueError("acceptance card requires evidence to close")
        if not all(self._artifact_exists(ref) for ref in refs):
            raise ValueError("acceptance card evidence must be resolvable artifact:<sha256> references")
        state = AcceptanceState(card, "closed", refs, time.time())
        self.wal.append("acceptance_card", state.as_dict())
        return state

    def snapshot(self, cards: Iterable[AcceptanceCard]) -> dict[str, Any]:
        states = self.reconcile(cards)
        return {
            "cards": [state.as_dict() for state in states],
            "closed": sum(state.status == "closed" for state in states),
            "open": sum(state.status == "open" for state in states),
            "stale": sum(state.status == "stale" for state in states),
        }
