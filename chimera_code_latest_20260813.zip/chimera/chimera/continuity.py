"""Constitution and temporal commitment ledger with optional cryptographic erasure."""
from __future__ import annotations
import base64,hashlib,json,os,pathlib,sqlite3,threading,time,uuid
from typing import Any,Iterable,Literal,Optional
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from pydantic import BaseModel,ConfigDict,Field
from .wal import WAL
class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
class Constitution(FrozenModel):
    purpose:str
    value_order:tuple[str,...]=("prevent_irreversible_harm","preserve_integrity_and_auditability","honor_existing_commitments","usefulness_and_speed")
    version:int=1
    limitations:tuple[str,...]=("internal ordering does not confer external legitimacy",)
    @property
    def digest(self):return "sha256:"+hashlib.sha256(json.dumps(self.model_dump(mode="json"),sort_keys=True,separators=(",",":")).encode()).hexdigest()
    def resolve(self,principles:Iterable[str])->Optional[str]:
        values=set(principles)
        return next((item for item in self.value_order if item in values),None)
class ConstitutionStore:
    def __init__(self,root:pathlib.Path):self.root=pathlib.Path(root).resolve();self.path=self.root/".chimera"/"governance"/"constitution.json";self.path.parent.mkdir(parents=True,exist_ok=True)
    def initialize(self,purpose:str)->Constitution:
        if self.path.exists():return self.load()
        value=Constitution(purpose=purpose);payload={**value.model_dump(mode="json"),"digest":value.digest};temp=self.path.with_suffix(".tmp");temp.write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n");os.replace(temp,self.path);return value
    def load(self)->Constitution:
        payload=json.loads(self.path.read_text());digest=payload.pop("digest");value=Constitution.model_validate(payload)
        if value.digest!=digest:raise ValueError("constitution digest mismatch")
        return value

class Commitment(FrozenModel):
    id:str;subject_hash:str;statement:Optional[str];classification:Literal["public","internal","personal"];created_at:float;expires_at:Optional[float];fulfilled_at:Optional[float];revoked_at:Optional[float];evidence_refs:tuple[str,...];shredded:bool=False
_SCHEMA="""
CREATE TABLE IF NOT EXISTS subject_keys(subject_hash TEXT PRIMARY KEY,wrapped_key BLOB NOT NULL,nonce BLOB NOT NULL);
CREATE TABLE IF NOT EXISTS commitments(id TEXT PRIMARY KEY,subject_hash TEXT NOT NULL,classification TEXT NOT NULL,payload BLOB NOT NULL,nonce BLOB,created_at REAL NOT NULL,expires_at REAL,fulfilled_at REAL,revoked_at REAL,evidence_refs TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_commitment_subject_time ON commitments(subject_hash,created_at);
"""
class ContinuityLedger:
    def __init__(self,root:pathlib.Path,master_key:Optional[bytes]=None):
        self.root=pathlib.Path(root).resolve();self.path=self.root/".chimera"/"continuity.sqlite";self.path.parent.mkdir(parents=True,exist_ok=True);self.db=sqlite3.connect(self.path,check_same_thread=False);self.db.executescript(_SCHEMA);self.lock=threading.RLock();self.wal=WAL(self.root)
        if master_key is None:
            encoded=os.environ.get("CHIMERA_LEDGER_MASTER_KEY")
            master_key=base64.b64decode(encoded,validate=True) if encoded else None
        if master_key is not None and len(master_key)!=32:raise ValueError("ledger master key must be 32 bytes")
        self.master_key=master_key
    def close(self):self.db.close()
    @staticmethod
    def subject_hash(entity_id:str)->str:return "sha256:"+hashlib.sha256(entity_id.encode()).hexdigest()
    def _subject_key(self,subject_hash:str,create:bool)->Optional[bytes]:
        row=self.db.execute("SELECT wrapped_key,nonce FROM subject_keys WHERE subject_hash=?",(subject_hash,)).fetchone()
        if row:
            if self.master_key is None:return None
            return AESGCM(self.master_key).decrypt(row[1],row[0],subject_hash.encode())
        if not create:return None
        if self.master_key is None:raise RuntimeError("personal commitments require CHIMERA_LEDGER_MASTER_KEY")
        key=os.urandom(32);nonce=os.urandom(12);wrapped=AESGCM(self.master_key).encrypt(nonce,key,subject_hash.encode());self.db.execute("INSERT INTO subject_keys VALUES(?,?,?)",(subject_hash,wrapped,nonce));return key
    def create(self,entity_id:str,statement:str,*,classification:Literal["public","internal","personal"]="internal",expires_at:Optional[float]=None,evidence_refs:Iterable[str])->Commitment:
        refs=tuple(evidence_refs)
        if not refs:raise ValueError("commitment requires evidence refs")
        subject=self.subject_hash(entity_id);created=time.time();commitment_id="commit-"+hashlib.sha256(json.dumps({"subject":subject,"statement":statement,"created":created},sort_keys=True).encode()).hexdigest()[:20];nonce=None
        with self.lock,self.db:
            if classification=="personal":
                key=self._subject_key(subject,True);nonce=os.urandom(12);payload=AESGCM(key).encrypt(nonce,statement.encode(),commitment_id.encode())
            else:payload=statement.encode()
            self.db.execute("INSERT INTO commitments VALUES(?,?,?,?,?,?,?,?,?,?)",(commitment_id,subject,classification,payload,nonce,created,expires_at,None,None,json.dumps(refs)))
        self.wal.append("commitment_created",{"id":commitment_id,"subject_hash":subject,"classification":classification,"expires_at":expires_at,"evidence_root":"sha256:"+hashlib.sha256(json.dumps(sorted(refs)).encode()).hexdigest()})
        return Commitment(id=commitment_id,subject_hash=subject,statement=statement,classification=classification,created_at=created,expires_at=expires_at,fulfilled_at=None,revoked_at=None,evidence_refs=refs)
    def query(self,entity_id:str,*,as_of:Optional[float]=None,open_only:bool=True)->list[Commitment]:
        subject=self.subject_hash(entity_id);at=float(as_of if as_of is not None else time.time());rows=self.db.execute("SELECT id,classification,payload,nonce,created_at,expires_at,fulfilled_at,revoked_at,evidence_refs FROM commitments WHERE subject_hash=? AND created_at<=? ORDER BY created_at",(subject,at)).fetchall();key=self._subject_key(subject,False);output=[]
        for cid,classification,payload,nonce,created,expires,fulfilled,revoked,refs in rows:
            if open_only and ((expires is not None and expires<=at) or (fulfilled is not None and fulfilled<=at) or (revoked is not None and revoked<=at)):continue
            shredded=False
            if classification=="personal":
                if key is None:statement=None;shredded=True
                else:
                    try:statement=AESGCM(key).decrypt(nonce,payload,cid.encode()).decode()
                    except Exception:statement=None;shredded=True
            else:statement=payload.decode()
            output.append(Commitment(id=cid,subject_hash=subject,statement=statement,classification=classification,created_at=created,expires_at=expires,fulfilled_at=fulfilled,revoked_at=revoked,evidence_refs=tuple(json.loads(refs)),shredded=shredded))
        return output
    def transition(self,commitment_id:str,status:Literal["fulfilled","revoked"],*,evidence_refs:Iterable[str])->None:
        refs=tuple(evidence_refs)
        if not refs:raise ValueError("commitment transition requires evidence refs")
        column="fulfilled_at" if status=="fulfilled" else "revoked_at"
        with self.lock,self.db:
            changed=self.db.execute(f"UPDATE commitments SET {column}=? WHERE id=? AND fulfilled_at IS NULL AND revoked_at IS NULL",(time.time(),commitment_id)).rowcount
        if changed!=1:raise ValueError("commitment missing or already closed")
        self.wal.append("commitment_"+status,{"id":commitment_id,"evidence_root":"sha256:"+hashlib.sha256(json.dumps(sorted(refs)).encode()).hexdigest()})
    def shred_subject(self,entity_id:str,*,authorized_by:str,scope:str)->bool:
        subject=self.subject_hash(entity_id);request_id="shred-"+uuid.uuid4().hex
        request={"request_id":request_id,"subject_hash":subject,"authorized_by_hash":"sha256:"+hashlib.sha256(authorized_by.encode()).hexdigest(),"scope":scope,"ts":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())}
        # Intent is durable before irreversible key destruction. A request with
        # no matching confirmation is a detectable recovery obligation.
        self.wal.append("subject_data_shred_requested",request)
        with self.lock,self.db:changed=self.db.execute("DELETE FROM subject_keys WHERE subject_hash=?",(subject,)).rowcount
        self.wal.append("subject_data_shred_confirmed",{**request,"destroyed":bool(changed)})
        return bool(changed)
