"""Agent-computer interface primitives for upstream action shaping.

The goal is to make the model operate through small, line-anchored, stateful
views instead of raw repository dumps.  This module is deliberately local and
cheap: read/search/window/edit helpers return concise structured observations
and never call a model.
"""
from __future__ import annotations

from dataclasses import dataclass
import fnmatch
import pathlib
import re
import hashlib
from typing import Any, Iterable

from .branch import TransactionalWorkspace


@dataclass(frozen=True)
class FileWindow:
    path: str
    start: int
    end: int
    total_lines: int
    text: str

    def as_observation(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "start": self.start,
            "end": self.end,
            "total_lines": self.total_lines,
            "text": self.text,
        }


@dataclass(frozen=True)
class SearchHit:
    path: str
    line: int
    preview: str


class AgentComputerInterface:
    """Windowed file view/search/edit interface backed by a transactional branch."""

    def __init__(self, root: pathlib.Path, workspace: TransactionalWorkspace | None = None) -> None:
        self.root = pathlib.Path(root).resolve()
        self.workspace = workspace or TransactionalWorkspace(self.root)

    @staticmethod
    def _normalise(path: str) -> str:
        raw = str(path).replace("\\", "/")
        if raw.startswith("/") or ".." in pathlib.PurePosixPath(raw).parts:
            raise ValueError("ACI paths must be workspace-relative")
        return pathlib.PurePosixPath(raw).as_posix()

    def _read_text(self, path: str, branch: str | None = None) -> str:
        rel = self._normalise(path)
        if branch:
            return self.workspace.read(branch, rel).decode("utf-8", errors="replace")
        return (self.root / rel).read_text(errors="replace")

    def view(self, path: str, *, branch: str | None = None, start: int = 1, lines: int = 80) -> FileWindow:
        rel = self._normalise(path)
        source = self._read_text(rel, branch)
        rows = source.splitlines()
        total = len(rows)
        start = max(1, int(start))
        lines = max(1, min(500, int(lines)))
        end = min(total, start + lines - 1)
        numbered = [f"{index:5d}: {rows[index-1]}" for index in range(start, end + 1)]
        return FileWindow(rel, start, end, total, "\n".join(numbered))

    def search(self, query: str, *, branch: str | None = None, glob: str = "*.py", limit: int = 20) -> tuple[SearchHit, ...]:
        if not query.strip():
            return ()
        pattern = re.compile(re.escape(query), re.IGNORECASE)
        hits: list[SearchHit] = []
        for path in sorted(self.root.rglob("*")):
            if len(hits) >= limit:
                break
            if not path.is_file() or ".chimera" in path.parts or "__pycache__" in path.parts:
                continue
            rel = path.relative_to(self.root).as_posix()
            if not fnmatch.fnmatch(rel, glob):
                continue
            try:
                text = self._read_text(rel, branch)
            except Exception:
                continue
            for line_no, line in enumerate(text.splitlines(), 1):
                if pattern.search(line):
                    hits.append(SearchHit(rel, line_no, line.strip()[:160]))
                    break
        return tuple(hits)

    @staticmethod
    def lint(path: str, source: str) -> tuple[str, ...]:
        if path.endswith(".py"):
            try:
                import ast
                ast.parse(source, filename=path)
            except SyntaxError as exc:
                return (f"SyntaxError: {exc}",)
        return ()

    def line_edit(self, branch: str, path: str, *, start: int, end: int, replacement: str, expected_hash: str | None = None) -> dict[str, Any]:
        rel = self._normalise(path)
        source = self._read_text(rel, branch)
        actual_hash = "sha256:" + hashlib.sha256(source.encode()).hexdigest()
        if expected_hash and expected_hash != actual_hash:
            return {"status": "rejected", "reason": "stale_source", "path": rel, "expected_hash": expected_hash, "actual_hash": actual_hash, "retryable": True}
        rows = source.splitlines(keepends=True)
        if start < 1 or end < start or end > len(rows):
            return {"status": "rejected", "reason": "line_range_out_of_bounds", "path": rel}
        new_rows = rows[:start-1] + [replacement if replacement.endswith("\n") else replacement + "\n"] + rows[end:]
        updated = "".join(new_rows)
        problems = self.lint(rel, updated)
        if problems:
            return {"status": "rejected", "reason": "lint_failed", "path": rel, "problems": list(problems)}
        self.workspace.write(branch, rel, updated)
        return {"status": "applied", "path": rel, "start": start, "end": end}

    def mine_failure_shapes(self, rows: Iterable[dict[str, Any]]) -> dict[str, int]:
        counts = {"malformed_patch": 0, "wrong_file": 0, "context_miss": 0, "lint_failed": 0}
        for row in rows:
            text = repr(row).lower()
            if "malformed" in text or "invalid json" in text:
                counts["malformed_patch"] += 1
            if "wrong file" in text or "outside" in text:
                counts["wrong_file"] += 1
            if "not found" in text or "matched 0" in text or "context" in text:
                counts["context_miss"] += 1
            if "syntaxerror" in text or "lint_failed" in text:
                counts["lint_failed"] += 1
        return counts
