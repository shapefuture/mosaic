"""Retained depth-1 child harnesses with direct messaging and durable registry."""
from __future__ import annotations

import concurrent.futures
import hashlib
import json
import pathlib
import threading
import time
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

from .rlm import AgentMessageBus
from .contradiction_ledger import ContradictionLedger


class SubagentRecord(BaseModel):
    id: str
    name: str
    task: str
    parent_branch: str
    branch: str
    model: str
    status: Literal["admitted", "running", "complete", "failed", "cancelled"] = "admitted"
    created_at: str
    updated_at: str
    result_path: Optional[str] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class SubagentManager:
    """Run full child harnesses concurrently; child answers arrive via files/messages."""

    def __init__(self, root: pathlib.Path, runtime, max_workers: int = 4):
        self.root = pathlib.Path(root).resolve()
        self.runtime = runtime
        self.dir = self.root / ".chimera" / "subagents"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.pool = concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)
        self.futures: Dict[str, concurrent.futures.Future] = {}
        self.lock = threading.RLock()
        self.messages = AgentMessageBus(self.root)
        self.contradictions = ContradictionLedger(self.root)

    @staticmethod
    def _id(name: str, task: str) -> str:
        return "sub-" + hashlib.sha256(f"{name}:{task}:{time.time_ns()}".encode()).hexdigest()[:12]

    def _path(self, child_id: str) -> pathlib.Path:
        return self.dir / f"{child_id}.json"

    def _save(self, record: SubagentRecord) -> None:
        record.updated_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        temp = self._path(record.id).with_suffix(".tmp")
        temp.write_text(record.model_dump_json(indent=2))
        temp.replace(self._path(record.id))

    def get(self, child_id: str) -> SubagentRecord:
        return SubagentRecord.model_validate_json(self._path(child_id).read_text())

    def list(self, status: Optional[str] = None) -> List[SubagentRecord]:
        records = [SubagentRecord.model_validate_json(path.read_text()) for path in self.dir.glob("sub-*.json")]
        if status:
            records = [record for record in records if record.status == status]
        return sorted(records, key=lambda record: record.updated_at, reverse=True)

    def spawn(self, task: str, parent_branch: str, model: str, name: Optional[str] = None,
              metadata: Optional[Dict[str, Any]] = None) -> SubagentRecord:
        child_id = self._id(name or "child", task)
        readable = name or child_id
        branch = f"{parent_branch}--{readable[:24]}-{child_id[-6:]}"
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        record = SubagentRecord(
            id=child_id, name=readable, task=task, parent_branch=parent_branch,
            branch=branch, model=model, created_at=now, updated_at=now,
            metadata=metadata or {},
        )
        self._save(record)
        self.messages.send(parent_branch, "child", readable, f"admitted:{child_id}:{task}", kind="subagent_admitted")
        future = self.pool.submit(self._run, child_id)
        with self.lock:
            self.futures[child_id] = future
        return record


    def _condense_result(self, task: str, result: dict) -> str:
        """Trajectory-aware condensation for parent-context handoff."""
        answer = str(result.get("answer", ""))
        diff = result.get("diff", "")
        verification = result.get("verification", {})
        status = verification.get("status", "unknown") if isinstance(verification, dict) else "unknown"
        failure_reason = result.get("error") or (
            verification.get("reason") if isinstance(verification, dict) else None
        )
        touched_paths: list[str] = []
        if isinstance(diff, dict):
            for op in diff.get("ops", []) or []:
                if isinstance(op, dict) and op.get("path"):
                    touched_paths.append(str(op["path"]))
        elif isinstance(diff, str) and diff:
            touched_paths = ["<text-diff>"]
        task_lower = task.lower()
        is_investigation = any(word in task_lower for word in ("investigate", "why", "explain", "understand", "find out", "inspect"))
        lines = [f"status={status}"]
        if failure_reason:
            lines.append(f"failure={failure_reason}")
        if is_investigation:
            lines.append(f"answer={answer[:1200]}")
            if touched_paths:
                lines.append(f"touched={touched_paths}")
        else:
            if touched_paths:
                lines.append(f"touched={touched_paths}")
            lines.append(f"verification={status}")
            if answer:
                lines.append(f"summary={answer[:600]}")
        return "\n".join(lines)[:8000]

    def _run(self, child_id: str) -> None:
        record = self.get(child_id)
        record.status = "running"
        self._save(record)
        try:
            # The runtime enforces depth=1; this child receives a fresh context
            # and the complete transactional/tool/verification harness.
            result = self.runtime.rlm(record.task, branch=record.branch, model=record.model, depth=1, use_dag=True)
            result_path = self.dir / f"{child_id}.result.json"
            result_path.write_text(json.dumps(result, indent=2, default=str))
            record.status = "complete"
            record.result_path = str(result_path)
            condensed = self._condense_result(record.task, result)
            record.metadata["condensed_summary"] = condensed
            self.contradictions.record_claim(record.task, "subagent_status", str(result.get("verification", {}).get("status", "unknown") if isinstance(result.get("verification", {}), dict) else "unknown"), source=record.name, trust="agent", evidence_ref=str(result_path))
            self.messages.send(
                record.branch, "parent", record.parent_branch,
                f"subagent {record.name} complete; result={result_path}\n{condensed}", kind="subagent_result",
            )
        except Exception as exc:
            record.status = "failed"
            record.error = f"{type(exc).__name__}: {exc}"
            self.messages.send(
                record.branch, "parent", record.parent_branch,
                f"subagent {record.name} failed: {record.error}", kind="subagent_error",
            )
        finally:
            self._save(record)

    def wait(self, child_id: str, timeout: Optional[float] = None) -> SubagentRecord:
        future = self.futures.get(child_id)
        if future:
            future.result(timeout=timeout)
        return self.get(child_id)

    def send(self, child_id: str, message: str) -> Dict[str, Any]:
        child = self.get(child_id)
        delivered = self.messages.send(
            child.parent_branch, "child", child.name, message, kind="steering",
        )
        from .soft_interrupt import SoftInterruptQueue
        interrupt = SoftInterruptQueue(self.root).enqueue(child.branch, message, source="user")
        return {**delivered, "soft_interrupt_id": interrupt.id}

    def recv_parent(self, parent_branch: str) -> List[Dict[str, Any]]:
        return self.messages.recv("parent", parent_branch)

    def cancel(self, child_id: str) -> SubagentRecord:
        future = self.futures.get(child_id)
        if future:
            future.cancel()
        record = self.get(child_id)
        if record.status in {"admitted", "running"}:
            record.status = "cancelled"
            self._save(record)
        return record

    def recover(self) -> List[SubagentRecord]:
        """Reconcile stale in-process records after a controller restart."""
        recovered = []
        for record in self.list():
            if record.status in {"admitted", "running"} and record.id not in self.futures:
                record.status = "failed"
                record.error = "controller restarted before child completion"
                self._save(record)
                recovered.append(record)
        return recovered
