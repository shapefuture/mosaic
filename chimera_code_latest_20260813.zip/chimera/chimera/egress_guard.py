"""Small deterministic secret/canary scan for model-produced artifacts.

This is a pre-apply egress guard, not a claim of complete secret detection.  It
catches high-confidence credential forms and registered canary values before a
candidate patch can enter a branch.  Matches are returned as redacted labels,
never echoed back into model context or logs.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class EgressFinding:
    kind: str
    digest: str


class ArtifactEgressGuard:
    PATTERNS = (
        ("private-key", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |PGP )?PRIVATE KEY-----")),
        ("aws-access-key", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
        ("github-token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b")),
        ("openai-style-key", re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b")),
        ("bearer-token", re.compile(r"\bAuthorization\s*:\s*Bearer\s+[A-Za-z0-9._~-]{20,}", re.I)),
    )

    @staticmethod
    def _digest(value: str) -> str:
        return "sha256:" + hashlib.sha256(value.encode()).hexdigest()[:24]

    def scan(self, text: str, *, canaries: Iterable[str] = ()) -> tuple[EgressFinding, ...]:
        findings: list[EgressFinding] = []
        for kind, pattern in self.PATTERNS:
            for match in pattern.finditer(text):
                findings.append(EgressFinding(kind, self._digest(match.group(0))))
        for canary in canaries:
            if canary and canary in text:
                findings.append(EgressFinding("canary-secret", self._digest(canary)))
        return tuple(dict.fromkeys(findings))
