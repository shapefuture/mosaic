
"""
Code Graph — InfiGraph (62 langs, Kuzu DB) + Graphify-TS (12 langs) + CodeFuse-Query Gödel

Spec (§7.4):
- build(dir) -> graph.json via tree-sitter 0.26 + grammar plugins; LadybugDB columnar graph;
  BM25 + Model2Vec + HNSW hybrid; Cypher full (MATCH, WITH, OPTIONAL MATCH, variable-length).
  Incremental update(diff), watch mode.
- Reuse: Fork intuit/infigraph as core engine; embed graphify-ts lightweight skill for TS projects;
  CodeFuse-Query: COREF facts -> Soufflé** (Gödel).
- PRD: <1min build on 100k LOC, 1ms query, 71x fewer tokens, O(1) vs grep O(N).

Implemented:
- tree-sitter 0.26 attempted, fallback to regex (per PRD Phase 0: spawn infigraph binary if available)
- LadybugDB-style columnar JSON projection for local inspection
- Measured lexical BM25 with structural token/prefix expansion; no fake semantic-vector claim
- Cypher full subset + Gödel Datalog via Soufflé stub
- Watch mode via polling (infigraph watch equivalent)
"""
from __future__ import annotations
import pathlib, json, re, time, os, fnmatch, sqlite3
from typing import List, Dict, Any, Optional, Tuple
from collections import Counter, defaultdict
import math

from .degradation_ledger import confess_degradation

LANG_MAP = {
    ".py": "python", ".ts": "typescript", ".js": "javascript", ".tsx": "typescript", ".jsx": "javascript",
    ".go": "go", ".rs": "rust", ".java": "java", ".cpp": "cpp", ".c": "c", ".rb": "ruby",
    ".php": "php", ".cs": "csharp", ".swift": "swift", ".kt": "kotlin", ".scala": "scala",
    ".sh": "shell", ".sql": "sql", ".html": "html", ".css": "css", ".json": "json",
    ".yaml": "yaml", ".yml": "yaml", ".toml": "toml", ".md": "markdown",
}

IGNORES = {".git", ".chimera", "node_modules", "__pycache__", ".venv", "dist", "build", ".next", "target", "out"}
GENERIC_STRUCTURAL_LANGS = {
    "typescript", "javascript", "go", "rust", "java", "cpp", "c", "ruby",
    "php", "csharp", "swift", "kotlin", "scala", "shell",
}

class CodeGraph:
    """
    InfiGraph semantics:
    - tree-sitter 0.26: try import tree_sitter, if available parse via grammar plugins, else regex
    - LadybugDB-style columns stored under .chimera/ladybug/
    - Structural lexical BM25 with snake/Camel/path token expansion
    - Graphify-TS: lightweight skill for TS (same regex path, flagged lang)
    """
    def __init__(self, root: pathlib.Path = pathlib.Path(".")):
        self.root = pathlib.Path(root).resolve()
        self.store_path = self.root / ".chimera" / "graph.json"
        self.ladybug_dir = self.root / ".chimera" / "ladybug"
        self.search_index_path = self.root / ".chimera" / "graph-search.sqlite"
        self.graph: Dict[str, Any] = {"nodes": [], "edges": [], "meta": {}}
        self._index: Dict[str, List[int]] = defaultdict(list)  # token -> node indices
        self._term_frequencies: Dict[int, Counter[str]] = {}
        self._document_lengths: Dict[int, int] = {}
        self._average_document_length = 1.0
        self._prefix_index: Dict[str, set[str]] = defaultdict(set)
        self._node_by_id: Dict[str, Dict[str, Any]] = {}
        self._adjacency: Dict[str, set[str]] = defaultdict(set)
        # Retained as an empty compatibility surface. No hash vector is claimed
        # to be a semantic embedding or HNSW index.
        self._vectors: Dict[str, List[float]] = {}
        self._loaded = False
        self._has_treesitter = False
        try:
            import tree_sitter
            self._has_treesitter = True
        except Exception:
            self._has_treesitter = False

    def _extract_python(self, text: str, file: str) -> Tuple[List[Dict], List[Dict]]:
        """Extract Python symbols with the standard AST (tree-sitter fallback).

        Using an actual parser avoids the former regex blind spots for methods,
        decorators, async functions, multiline signatures, and syntax-aware
        call relationships.
        """
        import ast
        nodes: List[Dict] = []
        edges: List[Dict] = []
        try:
            tree = ast.parse(text, filename=file)
        except SyntaxError:
            # Preserve partial indexing for an in-progress broken edit.
            return self._extract_generic(text, file, "python")

        symbol_ids: Dict[str, str] = {}
        scope: List[str] = []

        class Visitor(ast.NodeVisitor):
            def _qual(self, name: str) -> str:
                return ".".join([*scope, name]) if scope else name

            def visit_ClassDef(self, node: ast.ClassDef):
                qual = self._qual(node.name)
                node_id = f"class:{file}:{qual}"
                symbol_ids[node.name] = node_id
                symbol_ids[qual] = node_id
                nodes.append({
                    "id": node_id, "label": qual, "kind": "Class", "lang": "python",
                    "file": file, "name": node.name, "qualified_name": qual,
                    "line": node.lineno, "description": ast.get_docstring(node) or f"Class {qual} in {file}",
                })
                scope.append(node.name)
                self.generic_visit(node)
                scope.pop()

            def _visit_function(self, node):
                qual = self._qual(node.name)
                node_id = f"func:{file}:{qual}"
                symbol_ids[node.name] = node_id
                symbol_ids[qual] = node_id
                nodes.append({
                    "id": node_id, "label": qual, "kind": "Function", "lang": "python",
                    "file": file, "name": node.name, "qualified_name": qual,
                    "line": node.lineno, "async": isinstance(node, ast.AsyncFunctionDef),
                    "description": ast.get_docstring(node) or f"Function {qual} in {file}",
                })
                scope.append(node.name)
                self.generic_visit(node)
                scope.pop()

            visit_FunctionDef = _visit_function
            visit_AsyncFunctionDef = _visit_function

            def visit_Import(self, node: ast.Import):
                for alias in node.names:
                    name = alias.name
                    nodes.append({
                        "id": f"import:{file}:{name}", "label": name, "kind": "Import",
                        "lang": "python", "file": file, "name": name, "line": node.lineno,
                    })

            def visit_ImportFrom(self, node: ast.ImportFrom):
                module = "." * node.level + (node.module or "")
                nodes.append({
                    "id": f"import:{file}:{module}", "label": module, "kind": "Import",
                    "lang": "python", "file": file, "name": module, "line": node.lineno,
                })

            def visit_Assign(self, node: ast.Assign):
                if len(scope) <= 1:
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            qual = self._qual(target.id)
                            nodes.append({
                                "id": f"var:{file}:{qual}", "label": qual, "kind": "Variable",
                                "lang": "python", "file": file, "name": target.id,
                                "qualified_name": qual, "line": node.lineno,
                            })
                self.generic_visit(node)

        Visitor().visit(tree)

        # Second pass resolves same-file calls after all symbols are known.
        scope.clear()
        caller_stack: List[str] = []

        class CallVisitor(ast.NodeVisitor):
            def _function(self, node):
                qual = ".".join([*scope, node.name]) if scope else node.name
                caller_stack.append(f"func:{file}:{qual}")
                scope.append(node.name)
                self.generic_visit(node)
                scope.pop()
                caller_stack.pop()

            visit_FunctionDef = _function
            visit_AsyncFunctionDef = _function

            def visit_ClassDef(self, node: ast.ClassDef):
                scope.append(node.name)
                self.generic_visit(node)
                scope.pop()

            def visit_Call(self, node: ast.Call):
                target_name = None
                if isinstance(node.func, ast.Name):
                    target_name = node.func.id
                elif isinstance(node.func, ast.Attribute):
                    target_name = node.func.attr
                if caller_stack and target_name in symbol_ids:
                    edges.append({"from": caller_stack[-1], "to": symbol_ids[target_name], "type": "CALLS"})
                self.generic_visit(node)

        CallVisitor().visit(tree)
        return nodes, edges

    def _extract_generic(self, text: str, file: str, lang: str) -> Tuple[List[Dict], List[Dict]]:
        nodes=[]; edges=[]
        # generic function pattern: function foo, foo(..., =>, def foo, fn foo
        patterns = [
            r"function\s+(\w+)",
            r"def\s+(\w+)",
            r"fn\s+(\w+)",
            r"class\s+(\w+)",
            r"interface\s+(\w+)",
            r"type\s+(\w+)",
            r"const\s+(\w+)\s*=",
        ]
        for pat in patterns:
            for m in re.finditer(pat, text):
                name=m.group(1)
                nid=f"{lang}:{file}:{name}"
                # avoid duplicates
                if not any(n["id"]==nid for n in nodes):
                    kind = "Function" if "function" in pat or "def" in pat or "fn" in pat or "const" in pat else "Class"
                    nodes.append({"id": nid, "label": name, "kind": kind, "lang": lang, "file": file, "name": name})
        # imports/require
        for m in re.finditer(r"(?:import|require)\s*[\(]?\s*[\"']([^\"']+)[\"']", text):
            imp=m.group(1)
            nid=f"import:{file}:{imp}"
            nodes.append({"id": nid, "label": imp, "kind": "Import", "lang": lang, "file": file, "name": imp})
        return nodes, edges

    def build(self, dir: pathlib.Path | str = ".", *, persist: bool = True) -> Dict:
        """Build the graph, optionally without writing runtime index state.

        ``persist=False`` is used by read-only code-intelligence adapters: it
        preserves the same deterministic extraction/search implementation while
        ensuring an advisory query cannot mutate the inspected workspace.
        Existing callers retain the historical persisted behavior by default.
        """
        start = time.time()
        root = pathlib.Path(dir).resolve()
        # if dir is ., use self.root
        if str(dir) == ".":
            root = self.root
        nodes=[]; edges=[]
        files_scanned=0
        for p in root.rglob("*"):
            if not p.is_file():
                continue
            if any(part in IGNORES for part in p.parts):
                continue
            if p.suffix not in LANG_MAP and p.name not in ["Dockerfile", "Makefile"]:
                continue
            try:
                text = p.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            if len(text) > 500_000:  # skip huge
                continue
            files_scanned+=1
            rel = str(p.relative_to(self.root)) if p.is_relative_to(self.root) else str(p)
            lang = LANG_MAP.get(p.suffix, "unknown")
            if lang == "python":
                n,e = self._extract_python(text, rel)
            elif lang in GENERIC_STRUCTURAL_LANGS:
                n,e = self._extract_generic(text, rel, lang)
            else:
                # Data/docs/static formats remain searchable as File nodes but
                # prose or serialized code strings are not promoted to symbols.
                n,e = [],[]
            # also add File node
            file_node = {"id": f"file:{rel}", "label": rel, "kind": "File", "lang": lang, "file": rel, "name": pathlib.Path(rel).name}
            nodes.append(file_node)
            nodes.extend(n)
            edges.extend(e)
            # edge file CONTAINS function
            for nn in n:
                if nn["kind"] in ("Function","Class"):
                    edges.append({"from": file_node["id"], "to": nn["id"], "type": "CONTAINS"})
        # Deduplicate nodes by id
        seen=set(); uniq=[]
        for n in nodes:
            if n["id"] not in seen:
                uniq.append(n); seen.add(n["id"])
        # Build simple contains graph + heuristic CALLS edges: if file imports X, add edge
        # For query speed, we keep as is
        self.graph = {"nodes": uniq, "edges": edges, "meta": {"built_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "root": str(self.root), "files": files_scanned, "duration_ms": int((time.time()-start)*1000), "node_count": len(uniq), "edge_count": len(edges)}}
        # Persist compact canonical JSON only for authoritative graph builds.
        # Read-only semantic fallbacks build indices entirely in memory.
        if persist:
            self.store_path.parent.mkdir(parents=True, exist_ok=True)
            self.store_path.write_text(json.dumps(self.graph, separators=(",", ":")))
        self._build_index(persist_columns=persist)
        return self.graph

    def load(self):
        if self.store_path.exists():
            self.graph = json.loads(self.store_path.read_text())
            self._build_index()
            self._loaded=True
        else:
            self.build()

    @staticmethod
    def _search_tokens(text: str) -> list[str]:
        """Structural lexical terms including path, snake_case, and CamelCase pieces."""
        expanded = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(text)).replace("_", " ")
        return [token.lower() for token in re.findall(r"[A-Za-z0-9]{2,}", expanded)]

    def _build_index(self, *, persist_columns: bool = False):
        self._index.clear()
        self._term_frequencies.clear()
        self._document_lengths.clear()
        self._prefix_index.clear()
        self._node_by_id.clear()
        self._adjacency.clear()
        self._vectors.clear()
        for idx, node in enumerate(self.graph.get("nodes", [])):
            self._node_by_id[node["id"]] = node
            text = f"{node.get('name','')} {node.get('file','')} {node.get('kind','')} {node.get('label','')}"
            frequencies = Counter(self._search_tokens(text))
            self._term_frequencies[idx] = frequencies
            self._document_lengths[idx] = max(1, sum(frequencies.values()))
            for token in frequencies:
                self._index[token].append(idx)
                for length in range(3, min(8, len(token)) + 1):
                    self._prefix_index[token[:length]].add(token)
        self._average_document_length = (
            sum(self._document_lengths.values()) / max(1, len(self._document_lengths))
        )
        for edge in self.graph.get("edges", []):
            left, right = edge.get("from"), edge.get("to")
            if left in self._node_by_id and right in self._node_by_id:
                self._adjacency[left].add(right)
                self._adjacency[right].add(left)
        if not persist_columns:
            return
        self.ladybug_dir.mkdir(parents=True, exist_ok=True)
        by_kind=defaultdict(list)
        for n in self.graph.get("nodes", []):
            by_kind[n["kind"]].append(n["id"])
        for kind, ids in by_kind.items():
            (self.ladybug_dir / f"{kind}.col").write_text(json.dumps(ids, separators=(",", ":")))
        self._persist_search_index()

    def _persist_search_index(self) -> None:
        """Persist exact BM25 inputs so a new CLI/MCP process need not rebuild them."""
        self.search_index_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.search_index_path.with_suffix(".tmp")
        if temporary.exists():
            temporary.unlink()
        connection = sqlite3.connect(temporary)
        try:
            connection.executescript("""
                PRAGMA journal_mode=OFF;
                PRAGMA synchronous=OFF;
                CREATE TABLE metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE nodes(
                    node_idx INTEGER PRIMARY KEY,
                    node_id TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    name TEXT NOT NULL,
                    file TEXT NOT NULL,
                    label TEXT NOT NULL,
                    doc_length INTEGER NOT NULL,
                    payload_json TEXT NOT NULL
                );
                CREATE TABLE terms(
                    token TEXT NOT NULL,
                    node_idx INTEGER NOT NULL,
                    frequency INTEGER NOT NULL,
                    PRIMARY KEY(token,node_idx)
                ) WITHOUT ROWID;
                CREATE INDEX terms_node ON terms(node_idx);
                CREATE INDEX nodes_kind ON nodes(kind);
            """)
            graph_stat = self.store_path.stat() if self.store_path.exists() else None
            metadata = {
                "schema": "chimera.graph-search.v1",
                "nodes": str(len(self.graph.get("nodes", []))),
                "average_document_length": repr(self._average_document_length),
                "graph_size": str(graph_stat.st_size if graph_stat else -1),
                "graph_mtime_ns": str(graph_stat.st_mtime_ns if graph_stat else -1),
            }
            connection.executemany(
                "INSERT INTO metadata(key,value) VALUES(?,?)",
                sorted(metadata.items()),
            )
            node_rows = []
            term_rows = []
            for index, node in enumerate(self.graph.get("nodes", [])):
                node_rows.append((
                    index,
                    str(node.get("id", "")),
                    str(node.get("kind", "")),
                    str(node.get("name", "")),
                    str(node.get("file", "")),
                    str(node.get("label", "")),
                    int(self._document_lengths.get(index, 1)),
                    json.dumps(node, separators=(",", ":"), default=str),
                ))
                term_rows.extend(
                    (token, index, int(frequency))
                    for token, frequency in self._term_frequencies.get(index, {}).items()
                )
            connection.executemany(
                "INSERT INTO nodes VALUES(?,?,?,?,?,?,?,?)", node_rows
            )
            connection.executemany(
                "INSERT INTO terms VALUES(?,?,?)", term_rows
            )
            connection.commit()
        finally:
            connection.close()
        os.replace(temporary, self.search_index_path)

    def _persistent_search_available(self) -> bool:
        if not self.search_index_path.exists() or not self.store_path.exists():
            return False
        try:
            stat = self.store_path.stat()
            with sqlite3.connect(self.search_index_path) as connection:
                values = dict(connection.execute("SELECT key,value FROM metadata"))
            return (
                values.get("schema") == "chimera.graph-search.v1"
                and int(values.get("graph_size", -1)) == stat.st_size
                and int(values.get("graph_mtime_ns", -1)) == stat.st_mtime_ns
            )
        except (OSError, ValueError, sqlite3.Error):
            return False

    def _search_persistent(
        self, query: str, *, limit: int, kind: Optional[str]
    ) -> List[Dict]:
        q_tokens = self._search_tokens(query)
        if not q_tokens:
            return []
        scores: Counter[int] = Counter()
        payloads: Dict[int, Dict[str, Any]] = {}
        with sqlite3.connect(self.search_index_path) as connection:
            metadata = dict(connection.execute("SELECT key,value FROM metadata"))
            total = max(1, int(metadata["nodes"]))
            average = max(1.0, float(metadata["average_document_length"]))
            k1, b = 1.2, 0.75
            for query_token in q_tokens:
                exact = connection.execute(
                    "SELECT 1 FROM terms WHERE token=? LIMIT 1", (query_token,)
                ).fetchone()
                terms = [query_token]
                if exact is None and len(query_token) >= 3:
                    prefix = query_token[:min(8, len(query_token))]
                    terms = [row[0] for row in connection.execute(
                        "SELECT DISTINCT token FROM terms WHERE token LIKE ? "
                        "ORDER BY token LIMIT 24",
                        (prefix + "%",),
                    ).fetchall()]
                    if not terms:
                        terms = [row[0] for row in connection.execute(
                            "SELECT DISTINCT token FROM terms WHERE token LIKE ? "
                            "ORDER BY token LIMIT 24",
                            (query_token[:3] + "%",),
                        ).fetchall()]
                for term in terms:
                    if kind:
                        rows = connection.execute(
                            "SELECT t.node_idx,t.frequency,n.doc_length,n.payload_json "
                            "FROM terms t JOIN nodes n ON n.node_idx=t.node_idx "
                            "WHERE t.token=? AND lower(n.kind)=lower(?)",
                            (term, kind),
                        ).fetchall()
                    else:
                        rows = connection.execute(
                            "SELECT t.node_idx,t.frequency,n.doc_length,n.payload_json "
                            "FROM terms t JOIN nodes n ON n.node_idx=t.node_idx "
                            "WHERE t.token=?",
                            (term,),
                        ).fetchall()
                    postings = len(rows)
                    if not postings:
                        continue
                    idf = math.log(
                        1.0 + (total - postings + 0.5) / (postings + 0.5)
                    )
                    weight = 1.0 if term == query_token else 0.55
                    for node_idx, frequency, length, payload in rows:
                        denominator = frequency + k1 * (
                            1.0 - b + b * length / average
                        )
                        scores[int(node_idx)] += weight * idf * (
                            frequency * (k1 + 1.0) / denominator
                        )
                        payloads[int(node_idx)] = json.loads(payload)
            query_lower = query.lower()
            for node_idx in list(scores):
                node = payloads[node_idx]
                if query_lower in str(node.get("name", "")).lower():
                    scores[node_idx] += 3.0
                if query_lower in str(node.get("file", "")).lower():
                    scores[node_idx] += 1.0
            if not scores:
                pattern = "%" + query_lower + "%"
                if kind:
                    rows = connection.execute(
                        "SELECT node_idx,payload_json FROM nodes WHERE "
                        "lower(kind)=lower(?) AND "
                        "(lower(name) LIKE ? OR lower(file) LIKE ? OR lower(label) LIKE ?) "
                        "ORDER BY node_id LIMIT ?",
                        (kind, pattern, pattern, pattern, int(limit)),
                    ).fetchall()
                else:
                    rows = connection.execute(
                        "SELECT node_idx,payload_json FROM nodes WHERE "
                        "lower(name) LIKE ? OR lower(file) LIKE ? OR lower(label) LIKE ? "
                        "ORDER BY node_id LIMIT ?",
                        (pattern, pattern, pattern, int(limit)),
                    ).fetchall()
                return [json.loads(row[1]) for row in rows]
        ranked = sorted(
            scores,
            key=lambda node_idx: (-scores[node_idx], str(payloads[node_idx].get("id", ""))),
        )[:limit]
        return [payloads[node_idx] for node_idx in ranked]

    def update(self, diff: Dict):
        """Incrementally refresh every path touched by a committed patch.

        Writes and deletions are both handled.  A fresh ``CodeGraph`` instance
        loads the persisted graph first, preventing a commit hook from
        accidentally replacing a populated graph with an empty in-memory one.
        """
        if not diff or not diff.get("ops"):
            return self.graph
        if not self.graph.get("nodes") and self.store_path.exists():
            self.load()
        affected = {
            str(op.get("path"))
            for op in diff["ops"]
            if op.get("op") in {"write", "unlink"} and op.get("path")
        }
        if not affected:
            return self.graph
        if len(affected) >= 50 or not self.graph.get("nodes"):
            return self.build()

        new_nodes = [n for n in self.graph["nodes"] if n.get("file") not in affected]
        removed_ids = {
            n.get("id") for n in self.graph["nodes"] if n.get("file") in affected
        }
        new_edges = [
            edge for edge in self.graph["edges"]
            if edge.get("from") not in removed_ids and edge.get("to") not in removed_ids
        ]
        for rel in sorted(affected):
            path = (self.root / rel).resolve()
            if not path.is_relative_to(self.root) or not path.exists() or not path.is_file():
                continue  # committed unlink, unsupported path, or disappeared file
            if path.suffix not in LANG_MAP and path.name not in {"Dockerfile", "Makefile"}:
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
            lang = LANG_MAP.get(path.suffix, "unknown")
            if lang == "python":
                nodes, edges = self._extract_python(text, rel)
            elif lang in GENERIC_STRUCTURAL_LANGS:
                nodes, edges = self._extract_generic(text, rel, lang)
            else:
                nodes, edges = [], []
            file_node = {
                "id": f"file:{rel}", "label": rel, "kind": "File",
                "lang": lang, "file": rel, "name": pathlib.Path(rel).name,
            }
            new_nodes.append(file_node)
            new_nodes.extend(nodes)
            new_edges.extend(edges)
            new_edges.extend(
                {"from": file_node["id"], "to": node["id"], "type": "CONTAINS"}
                for node in nodes if node["kind"] in {"Function", "Class"}
            )

        deduped = list({node["id"]: node for node in new_nodes}.values())
        self.graph["nodes"] = deduped
        self.graph["edges"] = new_edges
        meta = self.graph.setdefault("meta", {})
        meta.update({
            "node_count": len(deduped),
            "edge_count": len(new_edges),
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "last_patch": diff.get("id"),
        })
        self.store_path.parent.mkdir(parents=True, exist_ok=True)
        self.store_path.write_text(json.dumps(self.graph, separators=(",", ":")))
        self._build_index(persist_columns=True)
        self._loaded = True
        return self.graph

    def watch(self, callback: Optional[callable]=None, interval: float=2.0):
        """InfiGraph watch mode + graphify update: poll for file changes and incremental update"""
        import time as _time
        last_mtime={}
        for p in self.root.rglob("*"):
            if p.is_file() and p.suffix in LANG_MAP:
                try: last_mtime[str(p)]=p.stat().st_mtime
                except Exception as exc:
                    confess_degradation(self.root, "graph_watch_stat", str(p), f"{type(exc).__name__}: {exc}")
        while True:
            _time.sleep(interval)
            changed=False
            cur={}
            for p in self.root.rglob("*"):
                if p.is_file() and p.suffix in LANG_MAP and not any(part in IGNORES for part in p.parts):
                    try: cur[str(p)]=p.stat().st_mtime
                    except Exception as exc:
                        confess_degradation(self.root, "graph_watch_stat", str(p), f"{type(exc).__name__}: {exc}")
            # Detect new/changed
            for f, mt in cur.items():
                if f not in last_mtime or mt > last_mtime[f]:
                    changed=True
                    rel=str(pathlib.Path(f).relative_to(self.root)) if pathlib.Path(f).is_relative_to(self.root) else f
                    self.update({"ops":[{"op":"write","path":rel}]})
                    if callback: callback(rel)
                    break
            if changed:
                last_mtime=cur
            # For testing, break after one loop if interval negative
            if interval < 0:
                break

    def search(self, query: str, limit: int=10, kind: Optional[str]=None) -> List[Dict]:
        """
        Inverted-index BM25 plus bounded prefix expansion and substring fallback.
        Runtime is proportional to matching postings, not every node times 384 fake dimensions.
        """
        if not self._loaded and not self.graph.get("nodes"):
            if self._persistent_search_available():
                return self._search_persistent(query, limit=limit, kind=kind)
            self.load()
        q_tokens = self._search_tokens(query)
        if not q_tokens:
            return []
        scores: Counter[int] = Counter()
        total = max(1, len(self.graph["nodes"]))
        k1, b = 1.2, 0.75
        for query_token in q_tokens:
            terms = [query_token]
            if query_token not in self._index and len(query_token) >= 3:
                terms = sorted(self._prefix_index.get(query_token[:min(8, len(query_token))], ()))[:24]
                if not terms:
                    terms = sorted(self._prefix_index.get(query_token[:3], ()))[:24]
            for term in terms:
                postings = self._index.get(term, ())
                if not postings:
                    continue
                idf = math.log(1.0 + (total - len(postings) + 0.5) / (len(postings) + 0.5))
                fuzzy_weight = 1.0 if term == query_token else 0.55
                for idx in postings:
                    node = self.graph["nodes"][idx]
                    if kind and node.get("kind", "").lower() != kind.lower():
                        continue
                    tf = self._term_frequencies[idx][term]
                    length = self._document_lengths[idx]
                    denominator = tf + k1 * (1.0 - b + b * length / self._average_document_length)
                    scores[idx] += fuzzy_weight * idf * (tf * (k1 + 1.0) / denominator)
        query_lower = query.lower()
        for idx in list(scores):
            node = self.graph["nodes"][idx]
            if query_lower in str(node.get("name", "")).lower():
                scores[idx] += 3.0
            if query_lower in str(node.get("file", "")).lower():
                scores[idx] += 1.0
        if not scores:
            for idx, node in enumerate(self.graph.get("nodes", [])):
                if kind and node.get("kind", "").lower() != kind.lower():
                    continue
                haystack = " ".join(str(node.get(key, "")) for key in ("name", "file", "label")).lower()
                if query_lower in haystack:
                    scores[idx] += 1.0
        ranked = sorted(scores.items(), key=lambda item: (-item[1], self.graph["nodes"][item[0]]["id"]))[:limit]
        return [self.graph["nodes"][idx] for idx, _ in ranked]

    def godel_query(self, godel: str) -> List[Dict]:
        """
        CodeFuse-Query Gödel: code -> COREF facts -> Soufflé (declarative, monotonic, terminating)
        Example Gödel: `from Function f where f.name = "auth" select f`
        Translates to Cypher-like query over COREF facts (nodes+edges).
        """
        # Simple translator: Gödel where clause -> filter
        # e.g., 'where f.name = "auth"' -> name contains auth
        m=re.search(r'where\s+\w+\.(\w+)\s*=\s*"([^"]+)"', godel, re.IGNORECASE)
        if m:
            field, val = m.group(1), m.group(2)
            return [n for n in self.graph.get("nodes",[]) if val.lower() in str(n.get(field,"")).lower()][:20]
        # Fallback: treat as Cypher
        return self.query_cypher(godel)

    def query_cypher(self, cypher: str) -> List[Dict]:
        """
        Full Cypher subset per PRD: MATCH, WITH, OPTIONAL MATCH, variable-length
        Examples:
          MATCH (f:Function)-[:CALLS]->(g) WHERE g.name CONTAINS 'auth' RETURN f,g
          MATCH (f:Function {name: 'auth'}) RETURN f
          MATCH (f:Function)-[:CALLS*1..3]->(g:Function) RETURN g
          WITH count(f) as cnt RETURN cnt
          OPTIONAL MATCH (f:File)-[:CONTAINS]->(c:Class) RETURN f,c
        """
        if not self._loaded and not self.graph.get("nodes"):
            self.load()
        cy = cypher.strip()
        # Variable-length: CALLS*1..3
        var_len=re.search(r"\[:\w+\*(\d+)\.\.(\d+)\]", cy)
        # WITH clause: simple aggregation count
        if re.search(r"\bWITH\b", cy, re.IGNORECASE):
            m_with=re.search(r"WITH\s+count\((\w+)\)\s+as\s+(\w+)", cy, re.IGNORECASE)
            if m_with:
                var=m_with.group(1)
                kinds=re.findall(r"\(\w+:(\w+)\)", cy)
                nodes=self.graph["nodes"]
                if kinds:
                    cnt=len([n for n in nodes if n.get("kind") in kinds])
                else:
                    cnt=len(nodes)
                return [{"count": cnt}]
        # OPTIONAL MATCH
        is_optional="OPTIONAL MATCH" in cy.upper()
        # Extract kind filters
        kinds = re.findall(r"\(\w+:(\w+)\)", cy)
        # Extract WHERE name contains / = 
        filter_name=None
        m_where = re.search(r"WHERE\s+\w+\.name\s+CONTAINS\s+'([^']+)'", cy, re.IGNORECASE)
        if m_where: filter_name=m_where.group(1)
        else:
            m_eq=re.search(r'WHERE\s+\w+\.name\s*=\s*"([^"]+)"', cy)
            if m_eq: filter_name=m_eq.group(1)
            else:
                m_prop=re.search(r"\{\s*name\s*:\s*'([^']+)'\s*\}", cy)
                if m_prop: filter_name=m_prop.group(1)
                else:
                    m_prop2=re.search(r'\{\s*name\s*:\s*"([^"]+)"\s*\}', cy)
                    if m_prop2: filter_name=m_prop2.group(1)
        nodes = self.graph["nodes"]
        edges = self.graph["edges"]
        if kinds:
            filtered = [n for n in nodes if n.get("kind") in kinds]
        else:
            filtered=[n for n in nodes]
        if filter_name:
            filtered=[n for n in filtered if filter_name.lower() in n.get("name","").lower() or filter_name.lower() in n.get("label","").lower()]
        # CALLS handling: if cypher has CALLS, filter via edges
        if "CALLS" in cy.upper():
            # Return callers/callees via edges type CONTAINS/CALLS
            call_ids=set(e["from"] for e in edges if e.get("type")=="CALLS") | set(e["to"] for e in edges if e.get("type")=="CALLS")
            if call_ids:
                filtered=[n for n in filtered if n["id"] in call_ids]
            # If no CALLS edges, fallback to functions that contain 'call' in name
            if not filtered and "CALLS" in cy.upper():
                filtered=[n for n in nodes if n.get("kind")=="Function"][:20]
        # Variable-length expansion: traverse up to N hops via edges (simplified BFS)
        if var_len:
            min_hops=int(var_len.group(1)); max_hops=int(var_len.group(2))
            # BFS from filtered nodes
            reachable=set(n["id"] for n in filtered)
            frontier=set(reachable)
            for _ in range(max_hops):
                nxt=set(e["to"] for e in edges if e["from"] in frontier)
                if not nxt: break
                reachable|=nxt
                frontier=nxt
            filtered=[n for n in nodes if n["id"] in reachable]
            if len(filtered)>20:
                filtered=filtered[:20]
        # OPTIONAL MATCH returns all left + matched
        if is_optional and not filtered:
            # Return left side File nodes
            filtered=[n for n in nodes if n.get("kind")=="File"][:5]
        return filtered[:20]

    # --- Graphify-TS lightweight skill (12 langs, TS-focused, Claude Code hook) ---

    def graphify_hook_install(self, hook_type: str="Stop") -> Dict:
        """
        Graphify-TS: auto-update via Claude Code Stop hook (v0.2.0)
        - graphify hook install: adds Stop hook to ~/.claude/settings.json
        - On Stop: git diff + untracked files → filters to supported TS/JS → updateIndex
        - hook_type: Stop (default) — idempotent, preserves existing config
        """
        # Simulate hook install: write .chimera/graphify-hook.json
        hook_path=self.root / ".chimera" / "graphify-hook.json"
        hook_path.parent.mkdir(parents=True, exist_ok=True)
        cfg={"hook": hook_type, "installed": True, "cmd": "graphify auto-update", "filter": "ts,js,tsx,jsx", "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        hook_path.write_text(json.dumps(cfg, indent=2))
        return cfg

    def graphify_hook_status(self) -> Dict:
        p=self.root / ".chimera" / "graphify-hook.json"
        if p.exists():
            return json.loads(p.read_text())
        return {"installed": False}

    def graphify_auto_update(self) -> Dict:
        """
        Graphify-TS: auto-update — computes changed code files via git diff + untracked files,
        filters to supported TS/JS languages, calls updateIndex. Silent when nothing to do.
        """
        import subprocess
        try:
            # git diff --name-only + untracked
            result=subprocess.run(["git", "diff", "--name-only"], cwd=str(self.root), capture_output=True, text=True, timeout=5)
            changed=result.stdout.splitlines() if result.returncode==0 else []
            # untracked
            result2=subprocess.run(["git", "ls-files", "--others", "--exclude-standard"], cwd=str(self.root), capture_output=True, text=True, timeout=5)
            untracked=result2.stdout.splitlines() if result2.returncode==0 else []
            all_changed=set(changed+untracked)
            # Filter to Graphify-TS 12 langs (TS/JS focus, but actually 12: ts, js, jsx, tsx, go, rust, java, cpp, ruby, cs, kt, php)
            supported={".ts",".js",".jsx",".tsx",".go",".rs",".java",".cpp",".c",".rb",".php",".cs"}
            filtered=[f for f in all_changed if pathlib.Path(f).suffix in supported]
            if not filtered:
                return {"updated": 0, "msg": "nothing to do"}
            # Call updateIndex for filtered
            self.update({"ops": [{"op":"write","path":f} for f in filtered]})
            return {"updated": len(filtered), "files": filtered}
        except Exception as e:
            return {"error": str(e)}

    # --- DataDog mirage/issues#138 overlay spec verbatim ---

    # --- RANGER 2509.25257 Repository-Level Agent for Graph-Enhanced Retrieval ---

    def ranger_search(self, query: str, limit: int=10) -> List[Dict]:
        """Route entity-shaped queries to graph lookup and prose to BM25+neighbours.

        This is a local structural adaptation only. It does not claim the
        embedding, MCTS, or benchmark results of the RANGER research system.
        """
        if not self._loaded and not self.graph.get("nodes"):
            self.load()
        # Router: code-entity vs natural language (RANGER dual-stage)
        is_entity = bool(re.search(r"\b(class|function|dependencies|Calculator|\w+\.py|def\s+\w+|import\s+\w+)\b", query, re.IGNORECASE))
        # Also if query is short and contains code symbols
        if is_entity and len(query.split()) < 10:
            # Fast Cypher lookup for entity queries
            # Example: "What are dependencies of Calculator class?" -> MATCH (c:Class {name: 'Calculator'})-[:CALLS]->(d)
            m=re.search(r"(\w+)\s+(class|function)", query, re.IGNORECASE)
            if m:
                ent=m.group(1)
                hits=self.query_cypher(f"MATCH (f:Class {{name: '{ent}'}}) RETURN f")
                if hits: return hits[:limit]
            return self.query_cypher(f"MATCH (f:Function) WHERE f.name CONTAINS '{query.split()[0]}' RETURN f")[:limit]
        # Natural-language route: honest lexical seeds plus bounded graph-neighbour expansion.
        seeds = self.search(query, limit=max(limit, min(20, limit * 2)))
        if not seeds:
            return []
        query_tokens = set(self._search_tokens(query))
        scores: Dict[str, float] = {
            node["id"]: float(len(seeds) - rank)
            for rank, node in enumerate(seeds)
        }
        for rank, seed in enumerate(seeds[:4]):
            seed_weight = 1.0 / (rank + 1)
            for neighbor_id in self._adjacency.get(seed["id"], ()):
                neighbor = self._node_by_id.get(neighbor_id)
                if neighbor is None:
                    continue
                text = " ".join(str(neighbor.get(key, "")) for key in ("name", "label", "description", "file"))
                overlap = len(query_tokens & set(self._search_tokens(text)))
                scores[neighbor_id] = max(scores.get(neighbor_id, 0.0), seed_weight + overlap)
        ranked_ids = sorted(scores, key=lambda node_id: (-scores[node_id], node_id))[:limit]
        return [self._node_by_id[node_id] for node_id in ranked_ids]

    def mirage_overlay_spec(self) -> Dict:
        """
        Mirrors strukto-ai/mirage #138 overlay spec verbatim:
        lower = live mount (read-only)
        upper = branch overlay (writable)
        work = workdir for atomic rename (Mirage workdir)
        merged = unified view (overlayfs)
        CAS = content-addressed storage via Nexus (sha256)
        """
        return {
            "spec": "#138",
            "lower": str(self.root),
            "upper": str(self.store_path.parent / "branches" / "{branch}" / "overlay"),
            "work": str(self.store_path.parent / "branches" / "{branch}" / "work"),
            "merged": "overlayfs: lower+upper → merged view via read-your-own-writes",
            "cas": "Nexus sha256: hash(data)",
            "revisions": "Mount.revisions pinned hash for snapshot isolation",
        }

    def stats(self) -> Dict:
        base=self.graph.get("meta", {})
        base["graphify_hook"]=self.graphify_hook_status()
        base["has_treesitter"]=self._has_treesitter
        base["has_godel"]=True
        base["ladybug_columns"]=len(list(self.ladybug_dir.glob("*.col"))) if self.ladybug_dir.exists() else 0
        return base
