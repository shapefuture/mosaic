"""Evidence-preserving observer/reflector memory with bounded active context."""
from __future__ import annotations
import hashlib,json,pathlib,sqlite3,threading,time
from typing import Any,Callable,Iterable,Literal,Optional
from pydantic import BaseModel,ConfigDict,Field
from .artifacts import ContentAddressedArtifactStore
from .wal import WAL
class FrozenModel(BaseModel):model_config=ConfigDict(extra="forbid",frozen=True)
class Observation(FrozenModel):
    id:str;session:str;summary:str;importance:Literal["critical","important","informational"];created_at:float;valid_until:Optional[float];content_ref:str;evidence_refs:tuple[str,...];supersedes:tuple[str,...]=();untrusted:bool=True
class Reflection(FrozenModel):summary:str;source_ids:tuple[str,...];importance:Literal["critical","important","informational"]="important";valid_until:Optional[float]=None
_SCHEMA="""
CREATE TABLE IF NOT EXISTS observations(id TEXT PRIMARY KEY,session TEXT NOT NULL,payload TEXT NOT NULL,created_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS idx_observation_session_time ON observations(session,created_at);
"""
class ObservationalMemory:
    def __init__(self,root:pathlib.Path):self.root=pathlib.Path(root).resolve();self.path=self.root/".chimera"/"observations.sqlite";self.path.parent.mkdir(parents=True,exist_ok=True);self.db=sqlite3.connect(self.path,check_same_thread=False);self.db.executescript(_SCHEMA);self.store=ContentAddressedArtifactStore(self.root);self.wal=WAL(self.root);self.lock=threading.RLock()
    def close(self):self.db.close()
    def observe(self,session:str,summary:str,raw_content:bytes|str,*,importance:Literal["critical","important","informational"]="informational",valid_until:Optional[float]=None,evidence_refs:Iterable[str],untrusted:bool=True,supersedes:Iterable[str]=())->Observation:
        refs=tuple(evidence_refs)
        if not refs:raise ValueError("observation requires evidence refs")
        raw=raw_content.encode() if isinstance(raw_content,str) else raw_content;content=self.store.put(raw,media_type="text/plain",provenance={"kind":"observation","session":session});created=time.time();semantic={"session":session,"summary":summary,"content":content.digest,"created":created,"supersedes":sorted(supersedes)};oid="obs-"+hashlib.sha256(json.dumps(semantic,sort_keys=True).encode()).hexdigest()[:20];item=Observation(id=oid,session=session,summary=summary[:4000],importance=importance,created_at=created,valid_until=valid_until,content_ref=content.digest,evidence_refs=refs,supersedes=tuple(supersedes),untrusted=untrusted)
        with self.lock,self.db:self.db.execute("INSERT OR IGNORE INTO observations VALUES(?,?,?,?)",(item.id,session,item.model_dump_json(),created))
        self.wal.append("observation_recorded",{"id":item.id,"session":session,"importance":importance,"content_ref":content.digest,"evidence_root":"sha256:"+hashlib.sha256(json.dumps(sorted(refs)).encode()).hexdigest(),"untrusted":untrusted})
        return item
    def active(self,session:str,*,now:Optional[float]=None)->list[Observation]:
        current=time.time() if now is None else float(now);rows=[Observation.model_validate_json(row[0]) for row in self.db.execute("SELECT payload FROM observations WHERE session=? ORDER BY created_at",(session,)).fetchall()];superseded={source for item in rows for source in item.supersedes};return [item for item in rows if item.id not in superseded and (item.valid_until is None or item.valid_until>current)]
    def context(self,session:str,max_chars:int=8000)->dict[str,Any]:
        priority={"critical":0,"important":1,"informational":2};rows=sorted(self.active(session),key=lambda item:(priority[item.importance],-item.created_at,item.id));selected=[];used=0
        for item in rows:
            marker="[UNTRUSTED OBSERVATION] " if item.untrusted else "";line=f"{marker}[{item.id} {item.importance}] {item.summary}\n"
            if used+len(line)>max_chars:continue
            selected.append(line);used+=len(line)
        return {"text":"".join(selected),"ids":[item.id for item in rows if any(item.id in line for line in selected)],"chars":used,"available":len(rows)}
    def needs_reflection(self,session:str,max_active:int=50,max_summary_chars:int=40000)->bool:
        rows=self.active(session);return len(rows)>max_active or sum(len(item.summary) for item in rows)>max_summary_chars
    def reflect_deterministic(self,session:str,max_sources:int=20)->list[Observation]:
        rows=[item for item in self.active(session) if item.importance!="critical"][:max(2,int(max_sources))]
        if len(rows)<2:return []
        summary="; ".join(item.summary for item in rows)
        if len(summary)>4000:summary=summary[:2000]+" ... "+summary[-1900:]
        return self.reflect(session,lambda active:[Reflection(summary=f"Deterministic reflection of {len(rows)} observations: {summary}",source_ids=tuple(item.id for item in rows),importance="important")])
    def reflect(self,session:str,synthesizer:Callable[[tuple[Observation,...]],Iterable[Reflection]])->list[Observation]:
        active=tuple(self.active(session));by_id={item.id:item for item in active};output=[]
        for reflection in synthesizer(active):
            if not reflection.source_ids or not set(reflection.source_ids)<=set(by_id):raise ValueError("reflection sources must be active observations")
            raw=json.dumps({"summary":reflection.summary,"sources":[by_id[item].content_ref for item in reflection.source_ids]},sort_keys=True);refs=tuple(dict.fromkeys(ref for item in reflection.source_ids for ref in by_id[item].evidence_refs));output.append(self.observe(session,reflection.summary,raw,importance=reflection.importance,valid_until=reflection.valid_until,evidence_refs=refs,untrusted=True,supersedes=reflection.source_ids))
        return output
