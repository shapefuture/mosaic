"""Deterministic audited task state for long-horizon branch continuation.

This is the safe transfer from LongHorizon-Harness's Manage-Execute-Audit
idea. It does not add a manager or auditor model: task state is updated only
from Chimera's existing branch diff, protected-test result and verification
receipt. Model answers are never written into this state as facts.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
import hashlib
import json
import pathlib
import time
from typing import Any, Iterable, Mapping

from .quality import TaskContract
from .wal import WAL


@dataclass(frozen=True)
class AuditedRequirement:
    path: str
    status: str  # pending | completed | blocked | untrusted
    evidence_ref: str | None = None


@dataclass(frozen=True)
class AuditedTaskState:
    session_id: str
    branch: str
    revision: int
    requirements: tuple[AuditedRequirement, ...]
    verified_facts: tuple[dict[str, Any], ...] = ()
    updated_at: float = 0.0

    def as_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["requirements"] = [asdict(row) for row in self.requirements]
        return value

    def context(self, *, max_chars: int = 2400) -> str:
        completed = [row.path for row in self.requirements if row.status == "completed"]
        pending = [row.path for row in self.requirements if row.status != "completed"]
        facts = [
            {key: value for key, value in row.items() if key in {"diff_id", "verification_status", "test_status", "protected_tests_unchanged", "changed_paths"}}
            for row in self.verified_facts[-3:]
        ]
        text = json.dumps(
            {
                "session": self.session_id,
                "revision": self.revision,
                "completed_targets": completed,
                "pending_targets": pending,
                "verified_phase_facts": facts,
            },
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        )
        return text[:max_chars]


class AuditedTaskStateLedger:
    """WAL-backed state machine keyed by branch/session, not model history."""

    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root)
        self.wal = WAL(self.root)

    @staticmethod
    def _session(branch: str) -> str:
        return "branch:" + str(branch)

    def latest(self, branch: str) -> AuditedTaskState | None:
        session = self._session(branch)
        rows = [entry.get("data", {}) for entry in self.wal.replay(kind="audited_task_state")]
        for row in reversed(rows):
            if row.get("session_id") != session:
                continue
            requirements = tuple(
                AuditedRequirement(str(item.get("path", "")), str(item.get("status", "pending")), item.get("evidence_ref"))
                for item in row.get("requirements", [])
                if isinstance(item, Mapping) and item.get("path")
            )
            facts = tuple(item for item in row.get("verified_facts", []) if isinstance(item, Mapping))
            return AuditedTaskState(session, str(row.get("branch", branch)), int(row.get("revision", 0)), requirements, facts, float(row.get("updated_at", 0.0)))
        return None

    def prepare(self, branch: str, contract: TaskContract) -> AuditedTaskState:
        prior = self.latest(branch)
        by_path = {row.path: row for row in prior.requirements} if prior else {}
        for target in contract.targets:
            by_path.setdefault(target.path, AuditedRequirement(target.path, "pending"))
        state = AuditedTaskState(
            self._session(branch), branch,
            prior.revision if prior else 0,
            tuple(sorted(by_path.values(), key=lambda row: row.path)),
            prior.verified_facts if prior else (),
            time.time(),
        )
        return state

    def record(
        self,
        state: AuditedTaskState,
        *,
        contract: TaskContract,
        diff: Mapping[str, Any],
        verification: Mapping[str, Any] | None,
        protected_tests_unchanged: bool | None,
        evidence_ref: str | None = None,
    ) -> AuditedTaskState:
        changed = {
            str(item.get("path"))
            for item in diff.get("ops", []) if isinstance(item, Mapping) and item.get("path")
        }
        verified_pass = bool(isinstance(verification, Mapping) and verification.get("status") == "pass")
        by_path = {row.path: row for row in state.requirements}
        for target in contract.targets:
            status = "completed" if verified_pass and target.path in changed and protected_tests_unchanged is True else "pending"
            by_path[target.path] = AuditedRequirement(target.path, status, evidence_ref if status == "completed" else None)
        fact = {
            "diff_id": diff.get("id"),
            "changed_paths": sorted(changed),
            "verification_status": verification.get("status") if isinstance(verification, Mapping) else None,
            "test_status": (verification.get("integration_test", {}) or {}).get("status") if isinstance(verification, Mapping) and isinstance(verification.get("integration_test"), Mapping) else None,
            "protected_tests_unchanged": protected_tests_unchanged,
        }
        updated = AuditedTaskState(
            state.session_id,
            state.branch,
            state.revision + 1,
            tuple(sorted(by_path.values(), key=lambda row: row.path)),
            tuple([*state.verified_facts[-7:], fact]),
            time.time(),
        )
        self.wal.append("audited_task_state", updated.as_dict())
        return updated
