"""Concrete trace proofs with an optional Lean 4 kernel.

This module never labels ``theorem True := trivial`` as a proof of an LTL
property.  It first evaluates the supported finite-trace proposition, emits a
Lean artifact containing the concrete Boolean witness, and asks Lean's kernel
to check it when Lean is installed.  Without Lean, the runtime result remains
useful but is explicitly non-formal.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import re
import shutil
import subprocess
from typing import Dict, List, Optional


class LeanVerifier:
    def __init__(self, root: pathlib.Path = pathlib.Path("."), lean_bin: Optional[str] = None):
        self.root = pathlib.Path(root).resolve()
        self.proof_dir = self.root / ".chimera" / "proofs"
        self.proof_dir.mkdir(parents=True, exist_ok=True)
        self.lean_bin = lean_bin or shutil.which("lean") or "lean"
        self.lake_bin = shutil.which("lake")
        self.has_lean = shutil.which(self.lean_bin) is not None
        if self.has_lean:
            try:
                subprocess.run([self.lean_bin, "--version"], capture_output=True, timeout=5, check=True)
            except Exception:
                self.has_lean = False

    @staticmethod
    def _prop_occurs(prop: str, state: Dict) -> bool:
        text = json.dumps(state, sort_keys=True).lower()
        clean = re.sub(r"\(.*\)", "", prop.lower().replace(" ", ""))
        return clean in text

    def _unsafe_flags(self, ltl: str, trace: List[Dict]) -> Optional[List[bool]]:
        match = re.fullmatch(r"G\s*\(\s*!\s*([^()]+(?:\([^)]*\))?)\s*\)", ltl.strip(), re.IGNORECASE)
        if not match:
            return None
        proposition = match.group(1)
        return [self._prop_occurs(proposition, state) for state in trace]

    def ltl_to_lean(self, ltl: str, trace: List[Dict]) -> Optional[str]:
        flags = self._unsafe_flags(ltl, trace)
        if flags is None:
            return None
        literals = ", ".join("true" if flag else "false" for flag in flags)
        digest = hashlib.sha256((ltl + json.dumps(trace, sort_keys=True)).encode()).hexdigest()[:16]
        theorem = f"trace_safe_{digest}"
        return f'''import Std
-- Concrete finite-trace witness generated from: {ltl}
def unsafeFlags : List Bool := [{literals}]

theorem {theorem} : unsafeFlags.all (fun unsafe => !unsafe) = true := by
  native_decide
'''

    def verify(self, ltl: str, trace: List[Dict]) -> Dict:
        from .verifier import LTLMonitor

        runtime_ok, runtime_message = LTLMonitor(ltl).check(trace)
        code = self.ltl_to_lean(ltl, trace)
        digest = hashlib.sha256((ltl + json.dumps(trace, sort_keys=True)).encode()).hexdigest()
        artifact = self.proof_dir / f"{digest}.lean"
        if code is None:
            return {
                "tier": 3, "ltl": ltl, "runtime_holds": runtime_ok,
                "lean_holds": None, "formal": False, "artifact": None,
                "output": "unsupported LTL shape for concrete Lean compiler",
            }
        artifact.write_text(code)
        if not self.has_lean:
            return {
                "tier": 3, "ltl": ltl, "runtime_holds": runtime_ok,
                "lean_holds": None, "formal": False, "artifact": str(artifact),
                "output": f"Lean unavailable; runtime monitor: {runtime_message or 'holds'}",
            }

        command = [self.lean_bin, str(artifact)]
        if self.lake_bin and any((self.root / name).exists() for name in ("lakefile.lean", "lakefile.toml")):
            command = [self.lake_bin, "env", "lean", str(artifact)]
        try:
            result = subprocess.run(command, cwd=self.root, capture_output=True, text=True, timeout=30)
            return {
                "tier": 3, "ltl": ltl, "runtime_holds": runtime_ok,
                "lean_holds": result.returncode == 0, "formal": True,
                "artifact": str(artifact), "command": command,
                "output": (result.stdout + result.stderr)[-2000:],
            }
        except Exception as exc:
            return {
                "tier": 3, "ltl": ltl, "runtime_holds": runtime_ok,
                "lean_holds": False, "formal": True, "artifact": str(artifact),
                "output": f"Lean invocation failed: {exc}",
            }

    def three_tier(self, capability_ok: bool, ltl_holds: bool, lean_holds: Optional[bool],
                   formal: bool = False) -> Dict:
        tier3 = "pass" if formal and lean_holds else "fail" if formal else "unavailable"
        overall = capability_ok and ltl_holds and (bool(lean_holds) if formal else True)
        return {
            "tier1_etas": "pass" if capability_ok else "fail",
            "tier2_ltl": "pass" if ltl_holds else "fail",
            "tier3_lean": tier3,
            "overall": "pass" if overall else "fail",
            "formal_assurance": bool(formal and lean_holds),
        }
