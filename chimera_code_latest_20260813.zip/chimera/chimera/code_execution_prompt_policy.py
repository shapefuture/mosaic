"""Prompt policy requiring external execution evidence for coding tasks."""
from __future__ import annotations

CODE_EXECUTION_VERDICT_POLICY = """
CODE-EXECUTION VERDICT POLICY FOR CODING TASKS:
- If this model call exposes a code execution / code interpreter / Python tool, use it before returning the final patch.
- In that execution call, run the candidate code with 3-5 assert-style tests covering normal input, empty/null input where applicable, boundary input, and at least one adversarial case likely to break a first draft.
- Treat the tool's stdout/stderr/exit code as the only pass/fail verdict. Do not replace it with self-reflection or text like "this works".
- If a code-execution tool is unavailable in this provider call, do not claim local verification in your JSON summary; Chimera's external harness will run tests after your patch.
- Never write a correctness claim that is not grounded in an execution/tool result from this turn or in supplied Chimera test evidence.
""".strip()

COMPACT_CODE_EXECUTION_VERDICT_POLICY = (
    "If a code execution/code interpreter tool is available, run candidate code plus 3-5 assert tests "
    "before returning the patch; use stdout/stderr/exit code as the only verdict. "
    "If no such tool exists, do not claim verification; Chimera's harness will test externally."
)
