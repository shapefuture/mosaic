"""Frozen execution-coverage manifests for dependency DAGs.

A DAG result is not "complete" merely because it produced a synthesis string.
This module records the *pre-dispatch* node denominator and requires every
selected node to reach exactly one terminal outcome: completed, checkpoint-
reused, failed, or explicitly waived.  The immutable manifest makes partial
coverage visible to callers and durable receipts without giving an LLM any new
authority.

This is a small, generalized transfer from the source-audited open-code-review
session manifest design:

* freeze the work inventory before concurrent execution;
* retain typed failure reasons instead of turning an error into a success;
* distinguish verified re-use from fresh verified completion;
* derive terminal state from the coverage partition, never from prose.

It deliberately does *not* decide whether a patch may merge.  Verification,
transaction overlays, CAS merge, and protected-test checks remain authoritative.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum
import hashlib
import json
import re
import threading
import time
from typing import Any, Iterable, Mapping


SCHEMA_VERSION = "chimera.dag-coverage/v1"


class CoverageFailureClass(str, Enum):
    """Stable, machine-readable reasons a selected DAG node was not verified."""

    BUDGET = "budget"
    TIMEOUT = "timeout"
    DEPENDENCY = "dependency"
    EXECUTION = "execution"
    VERIFICATION = "verification"
    CANCELLED = "cancelled"
    INTERNAL = "internal"
    UNKNOWN = "unknown"


class CoverageTerminalState(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass(frozen=True)
class CoverageItem:
    """One selected DAG node and (when terminal) its outcome metadata."""

    item_id: str
    node_id: str
    node_fingerprint: str
    dependencies: tuple[str, ...]
    failure_class: str | None = None
    reason: str | None = None

    def as_dict(self) -> dict[str, Any]:
        # JSON-shaped output avoids a subtle divergence between the returned
        # manifest and its CAS receipt (tuples serialize as JSON arrays).
        return {
            "item_id": self.item_id,
            "node_id": self.node_id,
            "node_fingerprint": self.node_fingerprint,
            "dependencies": list(self.dependencies),
            "failure_class": self.failure_class,
            "reason": self.reason,
        }


@dataclass(frozen=True)
class DAGCoverageManifest:
    """An immutable, versioned partition of a single plan execution."""

    schema_version: str
    plan_id: str
    plan_identity: str
    checkpoint_key_hash: str | None
    checkpoint_scope_identity: str | None
    terminal_state: str
    elapsed_ms: int
    selected: tuple[CoverageItem, ...]
    completed: tuple[CoverageItem, ...]
    reused: tuple[CoverageItem, ...]
    failed: tuple[CoverageItem, ...]
    waived: tuple[CoverageItem, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "plan_id": self.plan_id,
            "plan_identity": self.plan_identity,
            "checkpoint_key_hash": self.checkpoint_key_hash,
            "checkpoint_scope_identity": self.checkpoint_scope_identity,
            "terminal_state": self.terminal_state,
            "elapsed_ms": self.elapsed_ms,
            "coverage": {
                "selected": [item.as_dict() for item in self.selected],
                "completed": [item.as_dict() for item in self.completed],
                "reused": [item.as_dict() for item in self.reused],
                "failed": [item.as_dict() for item in self.failed],
                "waived": [item.as_dict() for item in self.waived],
            },
        }


class CoverageStateError(ValueError):
    """An attempt would weaken the frozen coverage invariant."""


class _ItemState(str, Enum):
    SELECTED = "selected"
    COMPLETED = "completed"
    REUSED = "reused"
    FAILED = "failed"
    WAIVED = "waived"


_URL_USERINFO = re.compile(r"([A-Za-z][A-Za-z0-9+.\-]*://)[^/\s:@]+(?::[^/\s@]+)?@")
_BEARER = re.compile(r"(?i)\b(?:bearer|basic)\s+[A-Za-z0-9._~+/=\-]+")
_SECRET_ASSIGNMENT = re.compile(
    r"(?i)\b(authorization|api[_-]?key|access[_-]?token|refresh[_-]?token|"
    r"client[_-]?secret|secret|password|passwd|token)\b(\s*[:=]\s*)"
    r"(\"[^\"]*\"|'[^']*'|[^\s\"']+)"
)


def _sanitize_reason(value: object, *, limit: int = 360) -> str:
    """Store a short diagnostic without becoming a raw provider-error sink."""

    text = str(value or "").replace("\x00", " ")
    cleaned: list[str] = []
    for char in text:
        if char in "\r\n\t\v\f":
            cleaned.append(" ")
        elif ord(char) < 32 or ord(char) == 127:
            continue
        else:
            cleaned.append(char)
    text = "".join(cleaned)
    text = _URL_USERINFO.sub(r"\1<redacted>@", text)
    text = _BEARER.sub("<redacted-auth>", text)
    text = _SECRET_ASSIGNMENT.sub(r"\1\2<redacted>", text)
    text = " ".join(text.split())
    if not text:
        return "no terminal outcome recorded"
    return text[:limit]


class DAGCoverageBuilder:
    """Concurrency-safe builder that freezes selected work before dispatch.

    The builder is intentionally in-memory.  Callers persist its finalized
    output as a CAS receipt; a half-written on-disk manifest must never be
    mistaken for a final execution result.
    """

    def __init__(
        self,
        *,
        plan_id: str,
        plan_identity: str,
        checkpoint_key_hash: str | None = None,
        checkpoint_scope_identity: str | None = None,
    ) -> None:
        if not plan_id or not plan_identity:
            raise ValueError("coverage manifest requires non-empty plan_id and plan_identity")
        self.plan_id = str(plan_id)
        self.plan_identity = str(plan_identity)
        self.checkpoint_key_hash = str(checkpoint_key_hash) if checkpoint_key_hash else None
        self.checkpoint_scope_identity = str(checkpoint_scope_identity) if checkpoint_scope_identity else None
        self._items: dict[str, CoverageItem] = {}
        self._states: dict[str, _ItemState] = {}
        self._sealed = False
        self._frozen: DAGCoverageManifest | None = None
        self._lock = threading.RLock()

    @staticmethod
    def node_fingerprint(node: Any) -> str:
        """Fingerprint authored node contract fields, excluding mutable runtime state."""

        if hasattr(node, "model_dump"):
            raw = dict(node.model_dump())
        elif isinstance(node, Mapping):
            raw = dict(node)
        else:
            raise TypeError("node must provide model_dump() or be a mapping")
        raw.pop("status", None)
        inputs = raw.get("inputs")
        if isinstance(inputs, Mapping):
            # DAG propagation adds dependency outputs under ``from_*`` and can
            # replace large values with artifact references.  Those are runtime
            # facts, not the node contract selected before dispatch.
            raw["inputs"] = {
                str(key): value for key, value in inputs.items()
                if not str(key).startswith("from_")
            }
        encoded = json.dumps(raw, sort_keys=True, separators=(",", ":"), default=str).encode()
        return "sha256:" + hashlib.sha256(encoded).hexdigest()

    @staticmethod
    def item_id(plan_identity: str, node_id: str) -> str:
        payload = "\x00".join((SCHEMA_VERSION, str(plan_identity), str(node_id))).encode()
        return "dag:" + hashlib.sha256(payload).hexdigest()[:24]

    def register_selected(self, node: Any) -> CoverageItem:
        """Register one node before dispatch; duplicate registration is idempotent."""

        if isinstance(node, Mapping):
            node_id = str(node.get("id", ""))
            dependencies = node.get("dependencies", ())
        else:
            node_id = str(getattr(node, "id", ""))
            dependencies = getattr(node, "dependencies", ())
        if not node_id:
            raise CoverageStateError("selected node requires a non-empty id")
        if not isinstance(dependencies, Iterable) or isinstance(dependencies, (str, bytes)):
            raise CoverageStateError(f"node {node_id!r} dependencies must be a sequence")
        item_id = self.item_id(self.plan_identity, node_id)
        item = CoverageItem(
            item_id=item_id,
            node_id=node_id,
            node_fingerprint=self.node_fingerprint(node),
            dependencies=tuple(sorted(dict.fromkeys(str(value) for value in dependencies))),
        )
        with self._lock:
            if self._frozen is not None:
                raise CoverageStateError("coverage manifest is already finalized")
            if self._sealed:
                raise CoverageStateError("selected node set is sealed")
            prior = self._items.get(item_id)
            if prior is not None:
                if prior != item:
                    raise CoverageStateError(f"conflicting duplicate selected node {node_id!r}")
                return prior
            if any(current.node_id == node_id for current in self._items.values()):
                raise CoverageStateError(f"duplicate node id {node_id!r}")
            self._items[item_id] = item
            self._states[item_id] = _ItemState.SELECTED
            return item

    def seal_selected(self) -> None:
        with self._lock:
            if self._frozen is not None:
                raise CoverageStateError("coverage manifest is already finalized")
            self._sealed = True

    @property
    def sealed(self) -> bool:
        with self._lock:
            return self._sealed

    def _lookup(self, node_or_item_id: str) -> str:
        value = str(node_or_item_id)
        if value in self._items:
            return value
        matches = [item_id for item_id, item in self._items.items() if item.node_id == value]
        if len(matches) != 1:
            raise CoverageStateError(f"unknown selected node/item {value!r}")
        return matches[0]

    def _transition(
        self,
        node_or_item_id: str,
        to: _ItemState,
        *,
        failure_class: CoverageFailureClass | None = None,
        reason: object = "",
    ) -> None:
        with self._lock:
            if self._frozen is not None:
                raise CoverageStateError("coverage manifest is already finalized")
            item_id = self._lookup(node_or_item_id)
            current = self._states[item_id]
            if to is _ItemState.FAILED and failure_class is None:
                raise CoverageStateError("failed coverage item requires a typed failure class")
            if to is _ItemState.WAIVED and not str(reason or "").strip():
                raise CoverageStateError("waived coverage item requires a reason")
            if current is not _ItemState.SELECTED:
                existing = self._items[item_id]
                expected = replace(
                    existing,
                    failure_class=failure_class.value if failure_class else None,
                    reason=_sanitize_reason(reason) if to in {_ItemState.FAILED, _ItemState.WAIVED} else None,
                )
                if current is to and existing == expected:
                    return
                raise CoverageStateError(
                    f"node {existing.node_id!r} is already {current.value}; cannot transition to {to.value}"
                )
            item = self._items[item_id]
            if to is _ItemState.FAILED:
                item = replace(item, failure_class=failure_class.value, reason=_sanitize_reason(reason))
            elif to is _ItemState.WAIVED:
                item = replace(item, reason=_sanitize_reason(reason))
            self._items[item_id] = item
            self._states[item_id] = to

    def mark_completed(self, node_or_item_id: str) -> None:
        self._transition(node_or_item_id, _ItemState.COMPLETED)

    def mark_reused(self, node_or_item_id: str) -> None:
        self._transition(node_or_item_id, _ItemState.REUSED)

    def mark_failed(
        self,
        node_or_item_id: str,
        failure_class: CoverageFailureClass,
        reason: object,
    ) -> None:
        self._transition(node_or_item_id, _ItemState.FAILED, failure_class=failure_class, reason=reason)

    def mark_waived(self, node_or_item_id: str, reason: object) -> None:
        self._transition(node_or_item_id, _ItemState.WAIVED, reason=reason)

    @staticmethod
    def _sort(items: Iterable[CoverageItem]) -> tuple[CoverageItem, ...]:
        return tuple(sorted(items, key=lambda item: item.item_id))

    def finalize(self, *, elapsed_ms: int | float | None = None) -> DAGCoverageManifest:
        """Freeze a complete partition; undecided selected nodes fail unknown."""

        with self._lock:
            if self._frozen is not None:
                return self._frozen
            if not self._sealed:
                raise CoverageStateError("selected node set must be sealed before finalization")
            for item_id, state in tuple(self._states.items()):
                if state is _ItemState.SELECTED:
                    self._states[item_id] = _ItemState.FAILED
                    self._items[item_id] = replace(
                        self._items[item_id],
                        failure_class=CoverageFailureClass.UNKNOWN.value,
                        reason="no terminal outcome recorded",
                    )
            groups: dict[_ItemState, list[CoverageItem]] = {state: [] for state in _ItemState}
            for item_id, item in self._items.items():
                groups[self._states[item_id]].append(item)
            selected = self._sort(self._items.values())
            completed = self._sort(groups[_ItemState.COMPLETED])
            reused = self._sort(groups[_ItemState.REUSED])
            failed = self._sort(groups[_ItemState.FAILED])
            waived = self._sort(groups[_ItemState.WAIVED])
            if len(selected) != len(completed) + len(reused) + len(failed) + len(waived):
                raise CoverageStateError("coverage partition invariant failed")
            if not selected:
                terminal = CoverageTerminalState.SKIPPED
            elif not failed:
                terminal = CoverageTerminalState.COMPLETE
            elif len(failed) == len(selected):
                terminal = CoverageTerminalState.FAILED
            else:
                terminal = CoverageTerminalState.PARTIAL
            self._frozen = DAGCoverageManifest(
                schema_version=SCHEMA_VERSION,
                plan_id=self.plan_id,
                plan_identity=self.plan_identity,
                checkpoint_key_hash=self.checkpoint_key_hash,
                checkpoint_scope_identity=self.checkpoint_scope_identity,
                terminal_state=terminal.value,
                elapsed_ms=max(0, int(elapsed_ms or 0)),
                selected=selected,
                completed=completed,
                reused=reused,
                failed=failed,
                waived=waived,
            )
            return self._frozen


def persisted_manifest_payload(manifest: DAGCoverageManifest) -> str:
    """Canonical JSON suitable for a content-addressed evidence artifact."""

    return json.dumps(manifest.as_dict(), sort_keys=True, separators=(",", ":"))
