"""Opaque tenant workspace provisioning and quota receipts.

A tenant is not a label applied to a shared Chimera state directory. Provisioned
tenants receive a copied workspace root and therefore separate branch/WAL/CAS
state. This module deliberately does not infer a default tenant.
"""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import shutil
import time
import uuid
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from .wal import WAL


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class TenantContext(_FrozenModel):
    tenant_id: str = Field(min_length=1, max_length=256)
    tenant_key: str

    @classmethod
    def from_id(cls, tenant_id: str) -> "TenantContext":
        raw = str(tenant_id).strip()
        if not raw or "\x00" in raw:
            raise ValueError("tenant id must be non-empty and NUL-free")
        return cls(tenant_id=raw, tenant_key=hashlib.sha256(raw.encode("utf-8")).hexdigest())


class TenantQuota(_FrozenModel):
    max_active_runs: int = Field(default=1, ge=1, le=10_000)
    max_tokens_per_run: int = Field(default=80_000, ge=0)
    max_seconds_per_run: int = Field(default=1_800, ge=1)
    max_concurrent_workers: int = Field(default=1, ge=1, le=10_000)


class TenantWorkspace(_FrozenModel):
    tenant_key: str
    workspace_root: str
    source_fingerprint: str
    created_at: float


class TenantQuotaDecision(_FrozenModel):
    allowed: bool
    reason: str
    active_runs: int
    quota: TenantQuota


class TenantWorkspaceResolver:
    """Provision separate tenant roots from a source snapshot, never shared state."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.base = self.root / ".chimera" / "tenants"
        self.base.mkdir(parents=True, exist_ok=True)

    def tenant_dir(self, tenant: TenantContext) -> pathlib.Path:
        return self.base / tenant.tenant_key

    @staticmethod
    def _source_fingerprint(source: pathlib.Path) -> str:
        rows = []
        for path in sorted(source.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(source)
            if any(part in {".chimera", ".git", "__pycache__", ".pytest_cache", "node_modules", "build", "dist"} for part in rel.parts):
                continue
            stat = path.stat()
            rows.append((rel.as_posix(), stat.st_size, stat.st_mtime_ns))
        return "sha256:" + hashlib.sha256(json.dumps(rows, separators=(",", ":")).encode()).hexdigest()

    def provision(self, tenant: TenantContext, *, source_root: pathlib.Path) -> TenantWorkspace:
        source = pathlib.Path(source_root).resolve()
        if not source.is_dir():
            raise ValueError("tenant source root must be an existing directory")
        tenant_dir = self.tenant_dir(tenant)
        workspace = tenant_dir / "workspace"
        if workspace.exists():
            raise FileExistsError("tenant workspace already exists; explicit reset/migration required")
        tenant_dir.mkdir(parents=True, exist_ok=True)
        shutil.copytree(
            source,
            workspace,
            ignore=shutil.ignore_patterns(
                ".chimera", ".git", ".pytest_cache", "__pycache__", "node_modules", "build", "dist", "coverage",
            ),
        )
        value = TenantWorkspace(
            tenant_key=tenant.tenant_key,
            workspace_root=str(workspace),
            source_fingerprint=self._source_fingerprint(source),
            created_at=time.time(),
        )
        metadata = tenant_dir / "tenant.json"
        temporary = metadata.with_suffix(".tmp")
        temporary.write_text(value.model_dump_json(indent=2), encoding="utf-8")
        os.replace(temporary, metadata)
        WAL(workspace).append("tenant_provision", {
            "tenant_key": tenant.tenant_key,
            "source_fingerprint": value.source_fingerprint,
            "raw_tenant_id_persisted": False,
        })
        return value

    def resolve(self, tenant: TenantContext) -> TenantWorkspace:
        metadata = self.tenant_dir(tenant) / "tenant.json"
        if not metadata.exists():
            raise KeyError("tenant workspace is not provisioned")
        value = TenantWorkspace.model_validate_json(metadata.read_text(encoding="utf-8"))
        if value.tenant_key != tenant.tenant_key:
            raise PermissionError("tenant workspace key mismatch")
        root = pathlib.Path(value.workspace_root).resolve()
        if self.tenant_dir(tenant) not in root.parents:
            raise PermissionError("tenant workspace escapes tenant root")
        return value


class LocalTenantQuotaPort:
    """Inter-process local quota adapter used by tenant-scoped application runs."""

    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root).resolve()
        self.directory = self.root / ".chimera" / "quota"
        self.directory.mkdir(parents=True, exist_ok=True)

    def _paths(self, tenant_key: str) -> tuple[pathlib.Path, pathlib.Path]:
        if len(tenant_key) != 64 or any(char not in "0123456789abcdef" for char in tenant_key):
            raise ValueError("quota tenant key is invalid")
        return (
            self.directory / f"{tenant_key}.json",
            self.directory / f"{tenant_key}.lock",
        )

    def _mutate(self, tenant_key: str, callback):
        path, lock_path = self._paths(tenant_key)
        with lock_path.open("a+b") as handle:
            try:
                import fcntl
            except ImportError as exc:  # pragma: no cover
                raise RuntimeError("local multi-process quotas require fcntl") from exc
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            try:
                try:
                    rows = json.loads(path.read_text()) if path.exists() else {}
                except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
                    raise RuntimeError("tenant quota state is invalid") from exc
                result, rows = callback(dict(rows))
                temporary = path.with_suffix(".tmp")
                temporary.write_text(json.dumps(rows, sort_keys=True) + "\n")
                os.replace(temporary, path)
                return result
            finally:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    def admit(
        self,
        *,
        tenant_key: str,
        run_id: str,
        max_active_runs: int,
        expires_at: float,
    ) -> TenantQuotaDecision:
        now = time.time()
        if not run_id or max_active_runs < 1 or expires_at <= now:
            raise ValueError("quota admission parameters are invalid")

        def change(rows):
            rows = {
                key: float(value)
                for key, value in rows.items()
                if float(value) > now
            }
            quota = TenantQuota(max_active_runs=max_active_runs)
            if len(rows) >= max_active_runs and run_id not in rows:
                return TenantQuotaDecision(
                    allowed=False,
                    reason="tenant active-run quota exhausted",
                    active_runs=len(rows),
                    quota=quota,
                ), rows
            rows[run_id] = float(expires_at)
            return TenantQuotaDecision(
                allowed=True,
                reason="tenant run admitted",
                active_runs=len(rows),
                quota=quota,
            ), rows

        return self._mutate(tenant_key, change)

    def release(self, *, tenant_key: str, run_id: str) -> bool:
        def change(rows):
            existed = run_id in rows
            rows.pop(run_id, None)
            return existed, rows
        return bool(self._mutate(tenant_key, change))


class TenantQuotaLedger:
    """Compatibility wrapper for one already resolved tenant workspace."""

    def __init__(self, tenant_workspace: TenantWorkspace):
        self.root = pathlib.Path(tenant_workspace.workspace_root).resolve()
        self.path = self.root / ".chimera" / "tenant_runs.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.wal = WAL(self.root)

    def _load(self) -> dict[str, float]:
        if not self.path.exists():
            return {}
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            return {str(key): float(value) for key, value in raw.items()}
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            raise RuntimeError("tenant run ledger is unreadable")

    def _save(self, rows: dict[str, float]) -> None:
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps(rows, sort_keys=True), encoding="utf-8")
        os.replace(temporary, self.path)

    def admit(self, quota: TenantQuota) -> tuple[TenantQuotaDecision, str | None]:
        rows = self._load()
        if len(rows) >= quota.max_active_runs:
            return TenantQuotaDecision(allowed=False, reason="tenant active-run quota exhausted", active_runs=len(rows), quota=quota), None
        run_id = "tenant-run:" + uuid.uuid4().hex
        rows[run_id] = time.time()
        self._save(rows)
        self.wal.append("tenant_run", {"event": "admitted", "run_id": run_id, "active_runs": len(rows)})
        return TenantQuotaDecision(allowed=True, reason="tenant run admitted", active_runs=len(rows), quota=quota), run_id

    def release(self, run_id: str) -> bool:
        rows = self._load()
        if run_id not in rows:
            return False
        del rows[run_id]
        self._save(rows)
        self.wal.append("tenant_run", {"event": "released", "run_id": run_id, "active_runs": len(rows)})
        return True
