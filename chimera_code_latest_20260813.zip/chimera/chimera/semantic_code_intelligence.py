"""Snapshot-bound, read-only semantic code-intelligence boundary.

Semantic adapters are advisory retrieval components.  They receive no mutation,
provider, MCP, sandbox, or promotion authority.  Every request names the exact
workspace snapshot it was created from and every result is checked again before
it can be consumed.  A semantic adapter may fail, time out, or report an
unsupported operation; :class:`SemanticCodeIntelligenceRouter` then uses the
local :class:`~chimera.graph.CodeGraph` adapter only if the workspace still
matches the request.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import os
import pathlib
import re
import time
from typing import Literal, Protocol, Sequence, runtime_checkable
import uuid

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .graph import CodeGraph, IGNORES, LANG_MAP
from .tokenizer import TokenMeasurement, TokenizerMeasurer


_DIGEST_RE = re.compile(r"sha256:[0-9a-f]{64}")
_IDENTIFIER_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


class SemanticCodeIntelligenceError(RuntimeError):
    """Base error raised by semantic code-intelligence adapters."""


class SemanticAdapterTimeout(SemanticCodeIntelligenceError):
    """The adapter did not produce a terminal response within its deadline."""


class SemanticAdapterUnavailable(SemanticCodeIntelligenceError):
    """The configured adapter cannot run in the current environment."""


class WorkspaceSnapshotError(SemanticCodeIntelligenceError):
    """A stable workspace snapshot could not be captured."""


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


def _digest(value: str) -> str:
    if not _DIGEST_RE.fullmatch(str(value)):
        raise ValueError("snapshot identity must use sha256:<64 lowercase hex>")
    return str(value)


def _relative_path(value: str) -> str:
    path = pathlib.PurePosixPath(str(value).replace("\\", "/"))
    if not value or path.is_absolute() or ".." in path.parts:
        raise ValueError("semantic paths must be non-empty workspace-relative paths")
    normalized = path.as_posix()
    if normalized in {".", ""}:
        raise ValueError("semantic paths must name a file")
    return normalized


class WorkspaceSnapshot(_FrozenModel):
    """Deterministic identity of all non-runtime files below one workspace."""

    schema_version: Literal["chimera.workspace-snapshot.v1"] = "chimera.workspace-snapshot.v1"
    digest: str
    file_count: int = Field(ge=0)
    total_bytes: int = Field(ge=0)

    _snapshot_digest = field_validator("digest")(_digest)


class SemanticPosition(_FrozenModel):
    line: int = Field(ge=0)
    character: int = Field(ge=0)


class SemanticRange(_FrozenModel):
    start: SemanticPosition
    end: SemanticPosition

    @model_validator(mode="after")
    def _ordered(self) -> "SemanticRange":
        if (self.end.line, self.end.character) < (self.start.line, self.start.character):
            raise ValueError("semantic range end precedes start")
        return self


SemanticOperation = Literal[
    "definition",
    "references",
    "imports",
    "outgoing_calls",
    "document_symbols",
    "workspace_symbols",
]


class SemanticQueryRequest(_FrozenModel):
    """One read-only semantic query bound to an exact source snapshot."""

    schema_version: Literal["chimera.semantic-query.v1"] = "chimera.semantic-query.v1"
    request_id: str = Field(default_factory=lambda: "semantic:" + uuid.uuid4().hex, min_length=1, max_length=200)
    snapshot_digest: str
    operation: SemanticOperation
    path: str | None = None
    position: SemanticPosition | None = None
    query: str | None = Field(default=None, max_length=1_000)
    language_id: str | None = Field(default=None, max_length=100)
    timeout_seconds: float = Field(default=10.0, ge=0.05, le=120.0)
    max_results: int = Field(default=20, ge=1, le=200)
    context_lines: int = Field(default=2, ge=0, le=20)
    max_context_tokens: int = Field(default=2_000, ge=0, le=100_000)
    tokenizer_model: str = Field(default="unknown", min_length=1, max_length=300)

    _request_snapshot = field_validator("snapshot_digest")(_digest)

    @field_validator("path")
    @classmethod
    def _path(cls, value: str | None) -> str | None:
        return None if value is None else _relative_path(value)

    @model_validator(mode="after")
    def _operation_arguments(self) -> "SemanticQueryRequest":
        positioned = {"definition", "references", "outgoing_calls"}
        if self.operation in positioned and (self.path is None or self.position is None):
            raise ValueError(f"{self.operation} requires path and position")
        if self.operation in {"imports", "document_symbols"} and self.path is None:
            raise ValueError(f"{self.operation} requires path")
        if self.operation == "workspace_symbols" and not (self.query or "").strip():
            raise ValueError("workspace_symbols requires a non-empty query")
        return self


class SemanticLocation(_FrozenModel):
    path: str
    range: SemanticRange
    symbol: str | None = None
    kind: str | None = None
    precision: Literal["semantic", "structural", "lexical"]
    detail: str | None = Field(default=None, max_length=2_000)

    _location_path = field_validator("path")(_relative_path)


class SemanticQueryReceipt(_FrozenModel):
    """Typed evidence returned by either the primary adapter or CodeGraph."""

    schema_version: Literal["chimera.semantic-receipt.v1"] = "chimera.semantic-receipt.v1"
    request_id: str
    operation: SemanticOperation
    adapter_id: str
    status: Literal["completed", "fallback", "rejected", "timeout", "unsupported", "error"]
    requested_snapshot_digest: str
    observed_snapshot_digest: str
    consumed_snapshot_digest: str | None = None
    stale_state_rejected: bool = False
    results: tuple[SemanticLocation, ...] = ()
    context: str = ""
    token_measurement: TokenMeasurement | None = None
    context_budget_satisfied: bool | None = None
    latency_ms: float = Field(ge=0)
    message: str = ""
    primary_adapter_id: str | None = None
    fallback_reason: str | None = None

    _requested = field_validator("requested_snapshot_digest")(_digest)
    _observed = field_validator("observed_snapshot_digest")(_digest)

    @field_validator("consumed_snapshot_digest")
    @classmethod
    def _consumed(cls, value: str | None) -> str | None:
        return None if value is None else _digest(value)


@runtime_checkable
class SemanticCodeIntelligencePort(Protocol):
    """Read-only adapter boundary; implementations must enforce their deadline."""

    adapter_id: str

    def query(self, request: SemanticQueryRequest) -> SemanticQueryReceipt: ...


class WorkspaceSnapshotter:
    """Hash workspace paths and bytes without following directory symlinks.

    Runtime state and common dependency/build caches are excluded.  Everything
    else—including fixtures, static files, lockfiles, and generated files—is
    included so a query cannot silently cross their drift.
    """

    def __init__(
        self,
        root: pathlib.Path,
        *,
        ignored_names: Sequence[str] = tuple(sorted(IGNORES | {".pytest_cache", ".mypy_cache", ".ruff_cache"})),
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.ignored_names = frozenset(ignored_names)

    def capture(self) -> WorkspaceSnapshot:
        if not self.root.is_dir():
            raise WorkspaceSnapshotError(f"workspace root is not a directory: {self.root}")
        # Retry once when a concurrent writer makes a file disappear mid-walk.
        last_error: OSError | None = None
        for _ in range(2):
            try:
                return self._capture_once()
            except OSError as exc:
                last_error = exc
        raise WorkspaceSnapshotError(f"workspace changed while snapshotting: {last_error}")

    def _capture_once(self) -> WorkspaceSnapshot:
        rows: list[tuple[str, bytes, bytes]] = []
        for current, directories, filenames in os.walk(self.root, topdown=True, followlinks=False):
            directories[:] = sorted(name for name in directories if name not in self.ignored_names)
            base = pathlib.Path(current)
            for name in sorted(filenames):
                if name in self.ignored_names or name.endswith((".pyc", ".pyo")):
                    continue
                path = base / name
                relative = path.relative_to(self.root).as_posix()
                if path.is_symlink():
                    data = os.readlink(path).encode("utf-8", errors="surrogateescape")
                    kind = b"symlink"
                elif path.is_file():
                    data = path.read_bytes()
                    kind = b"file"
                else:
                    continue
                rows.append((relative, kind, data))
        digest = hashlib.sha256(b"chimera.workspace-snapshot.v1\0")
        total = 0
        for relative, kind, data in rows:
            encoded = relative.encode("utf-8", errors="surrogateescape")
            digest.update(len(encoded).to_bytes(8, "big")); digest.update(encoded)
            digest.update(kind); digest.update(len(data).to_bytes(8, "big")); digest.update(data)
            total += len(data)
        return WorkspaceSnapshot(
            digest="sha256:" + digest.hexdigest(),
            file_count=len(rows),
            total_bytes=total,
        )


@dataclass(frozen=True)
class _ProjectedContext:
    results: tuple[SemanticLocation, ...]
    text: str
    measurement: TokenMeasurement
    budget_satisfied: bool | None


class SemanticContextProjector:
    """Render bounded source context and measure it with the configured tokenizer."""

    def __init__(self, root: pathlib.Path, tokenizer: TokenizerMeasurer | None = None) -> None:
        self.root = pathlib.Path(root).resolve()
        self.tokenizer = tokenizer or TokenizerMeasurer()

    def project(self, request: SemanticQueryRequest, results: Sequence[SemanticLocation]) -> _ProjectedContext:
        selected = tuple(results[: request.max_results])
        while True:
            text = self._render(request, selected)
            measurement = self.tokenizer.measure(request.tokenizer_model, text)
            if measurement.status != "measured" or measurement.tokens is None:
                return _ProjectedContext(selected, text, measurement, None)
            if measurement.tokens <= request.max_context_tokens:
                return _ProjectedContext(selected, text, measurement, True)
            if not selected:
                return _ProjectedContext((), "", self.tokenizer.measure(request.tokenizer_model, ""), False)
            selected = selected[:-1]

    def _render(self, request: SemanticQueryRequest, results: Sequence[SemanticLocation]) -> str:
        blocks: list[str] = []
        for item in results:
            path = (self.root / item.path).resolve()
            if not path.is_relative_to(self.root) or not path.is_file():
                continue
            try:
                lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            first = max(0, item.range.start.line - request.context_lines)
            # LSP document symbols often span an entire class/module. Context
            # projection is evidence around the symbol anchor, not a request to
            # copy the complete body into the model window.
            natural_last = item.range.end.line + request.context_lines + 1
            bounded_last = item.range.start.line + max(5, request.context_lines * 2 + 5)
            last = min(len(lines), natural_last, bounded_last)
            header = f"{item.path}:{item.range.start.line + 1}:{item.range.start.character + 1}"
            if item.symbol:
                header += f" {item.symbol}"
            body = "\n".join(f"{number + 1:>6} | {lines[number]}" for number in range(first, last))
            blocks.append(header + ("\n" + body if body else ""))
        return "\n\n".join(blocks)


class CodeGraphSemanticAdapter:
    """Deterministic, local fallback over a non-persisted CodeGraph build."""

    adapter_id = "local-codegraph-semantic-fallback-v1"

    def __init__(
        self,
        root: pathlib.Path,
        *,
        snapshotter: WorkspaceSnapshotter | None = None,
        tokenizer: TokenizerMeasurer | None = None,
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.snapshotter = snapshotter or WorkspaceSnapshotter(self.root)
        self.projector = SemanticContextProjector(self.root, tokenizer)

    def query(self, request: SemanticQueryRequest) -> SemanticQueryReceipt:
        started = time.perf_counter()
        observed = self.snapshotter.capture()
        if observed.digest != request.snapshot_digest:
            return self._rejected(request, observed.digest, started, "request snapshot does not match workspace")
        try:
            graph = CodeGraph(self.root)
            graph.build(persist=False)
            results = self._select(graph, request)
            projected = self.projector.project(request, results)
            consumed = self.snapshotter.capture()
            if consumed.digest != request.snapshot_digest:
                return self._rejected(request, observed.digest, started, "workspace changed before CodeGraph results could be consumed", consumed.digest)
            return SemanticQueryReceipt(
                request_id=request.request_id,
                operation=request.operation,
                adapter_id=self.adapter_id,
                status="completed",
                requested_snapshot_digest=request.snapshot_digest,
                observed_snapshot_digest=observed.digest,
                consumed_snapshot_digest=consumed.digest,
                results=projected.results,
                context=projected.text,
                token_measurement=projected.measurement,
                context_budget_satisfied=projected.budget_satisfied,
                latency_ms=(time.perf_counter() - started) * 1_000,
                message="read-only CodeGraph fallback result",
            )
        except Exception as exc:
            # Adapter errors are data, not authority to reuse a partial result.
            consumed = self.snapshotter.capture()
            return SemanticQueryReceipt(
                request_id=request.request_id,
                operation=request.operation,
                adapter_id=self.adapter_id,
                status="error",
                requested_snapshot_digest=request.snapshot_digest,
                observed_snapshot_digest=observed.digest,
                consumed_snapshot_digest=consumed.digest,
                stale_state_rejected=consumed.digest != request.snapshot_digest,
                latency_ms=(time.perf_counter() - started) * 1_000,
                message=f"CodeGraph fallback failed: {type(exc).__name__}: {exc}",
            )

    def _rejected(
        self,
        request: SemanticQueryRequest,
        observed: str,
        started: float,
        message: str,
        consumed: str | None = None,
    ) -> SemanticQueryReceipt:
        return SemanticQueryReceipt(
            request_id=request.request_id,
            operation=request.operation,
            adapter_id=self.adapter_id,
            status="rejected",
            requested_snapshot_digest=request.snapshot_digest,
            observed_snapshot_digest=observed,
            consumed_snapshot_digest=consumed or observed,
            stale_state_rejected=True,
            latency_ms=(time.perf_counter() - started) * 1_000,
            message=message,
        )

    def _select(self, graph: CodeGraph, request: SemanticQueryRequest) -> tuple[SemanticLocation, ...]:
        if request.operation == "workspace_symbols":
            return tuple(self._node_location(node, "structural") for node in graph.search(request.query or "", limit=request.max_results))
        if request.operation == "imports":
            nodes = [
                node for node in graph.graph.get("nodes", ())
                if node.get("file") == request.path and node.get("kind") == "Import"
            ]
            return tuple(self._node_location(node, "structural") for node in sorted(nodes, key=lambda row: row.get("id", ""))[: request.max_results])
        if request.operation == "document_symbols":
            nodes = [
                node for node in graph.graph.get("nodes", ())
                if node.get("file") == request.path and node.get("kind") in {"Function", "Class"}
            ]
            return tuple(self._node_location(node, "structural") for node in sorted(nodes, key=lambda row: (row.get("line", 0), row.get("id", "")))[: request.max_results])

        assert request.path is not None and request.position is not None
        symbol = self._identifier_at(request.path, request.position)
        if not symbol:
            return ()
        if request.operation == "references":
            return self._lexical_references(symbol, request.max_results)
        candidates = [
            node for node in graph.graph.get("nodes", ())
            if node.get("name") == symbol and node.get("kind") in {"Function", "Class"}
        ]
        candidates.sort(key=lambda row: (row.get("file", ""), row.get("line", 0), row.get("id", "")))
        if request.operation == "definition":
            return tuple(self._node_location(node, "structural") for node in candidates[: request.max_results])
        if request.operation == "outgoing_calls":
            source_ids = {node.get("id") for node in candidates if node.get("file") == request.path}
            target_ids = {
                edge.get("to") for edge in graph.graph.get("edges", ())
                if edge.get("type") == "CALLS" and edge.get("from") in source_ids
            }
            targets = [node for node in graph.graph.get("nodes", ()) if node.get("id") in target_ids]
            targets.sort(key=lambda row: row.get("id", ""))
            return tuple(self._node_location(node, "structural") for node in targets[: request.max_results])
        return ()

    def _identifier_at(self, relative: str, position: SemanticPosition) -> str | None:
        path = (self.root / relative).resolve()
        if not path.is_relative_to(self.root) or not path.is_file():
            return None
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        if position.line >= len(lines):
            return None
        line = lines[position.line]
        if position.character > len(line):
            return None
        for match in _IDENTIFIER_RE.finditer(line):
            if match.start() <= position.character <= match.end():
                return match.group(0)
        return None

    def _node_location(self, node: dict, precision: Literal["semantic", "structural", "lexical"]) -> SemanticLocation:
        relative = _relative_path(str(node.get("file")))
        name = str(node.get("name") or node.get("label") or "")
        line_number = max(0, int(node.get("line") or 1) - 1)
        character = 0
        path = self.root / relative
        try:
            line = path.read_text(encoding="utf-8", errors="replace").splitlines()[line_number]
            found = line.find(name)
            character = max(0, found)
        except (OSError, IndexError):
            pass
        return SemanticLocation(
            path=relative,
            range=SemanticRange(
                start=SemanticPosition(line=line_number, character=character),
                end=SemanticPosition(line=line_number, character=character + len(name)),
            ),
            symbol=name or None,
            kind=str(node.get("kind") or "symbol"),
            precision=precision,
            detail=str(node.get("description")) if node.get("description") else None,
        )

    def _lexical_references(self, symbol: str, limit: int) -> tuple[SemanticLocation, ...]:
        pattern = re.compile(rf"\b{re.escape(symbol)}\b")
        rows: list[SemanticLocation] = []
        for path in sorted(self.root.rglob("*")):
            if len(rows) >= limit:
                break
            if not path.is_file() or path.suffix not in LANG_MAP or any(part in IGNORES for part in path.parts):
                continue
            relative = path.relative_to(self.root).as_posix()
            try:
                lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for number, line in enumerate(lines):
                for match in pattern.finditer(line):
                    rows.append(SemanticLocation(
                        path=relative,
                        range=SemanticRange(
                            start=SemanticPosition(line=number, character=match.start()),
                            end=SemanticPosition(line=number, character=match.end()),
                        ),
                        symbol=symbol,
                        kind="Reference",
                        precision="lexical",
                        detail="CodeGraph fallback lexical reference; not a semantic binding claim",
                    ))
                    if len(rows) >= limit:
                        return tuple(rows)
        return tuple(rows)


class SemanticCodeIntelligenceRouter:
    """Validate snapshots, contain primary failures, and fail deterministically to CodeGraph."""

    adapter_id = "snapshot-bound-semantic-router-v1"

    def __init__(
        self,
        root: pathlib.Path,
        *,
        primary: SemanticCodeIntelligencePort | None = None,
        fallback: SemanticCodeIntelligencePort | None = None,
        snapshotter: WorkspaceSnapshotter | None = None,
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.snapshotter = snapshotter or WorkspaceSnapshotter(self.root)
        self.primary = primary
        self.fallback = fallback or CodeGraphSemanticAdapter(self.root, snapshotter=self.snapshotter)

    def snapshot(self) -> WorkspaceSnapshot:
        return self.snapshotter.capture()

    def query(self, request: SemanticQueryRequest) -> SemanticQueryReceipt:
        started = time.perf_counter()
        before = self.snapshotter.capture()
        if before.digest != request.snapshot_digest:
            return self._stale_receipt(request, before.digest, started, "request snapshot is stale before adapter dispatch")
        if self.primary is None:
            return self._checked_fallback(request, before, started, primary_receipt=None)

        primary_receipt: SemanticQueryReceipt | None = None
        failure: str | None = None
        try:
            primary_receipt = self.primary.query(request)
        except SemanticAdapterTimeout as exc:
            failure = f"timeout: {exc}"
        except (SemanticAdapterUnavailable, SemanticCodeIntelligenceError) as exc:
            failure = f"{type(exc).__name__}: {exc}"
        except Exception as exc:
            failure = f"unexpected {type(exc).__name__}: {exc}"

        after_primary = self.snapshotter.capture()
        if after_primary.digest != request.snapshot_digest:
            return self._stale_receipt(
                request,
                before.digest,
                started,
                "workspace changed while primary semantic adapter was running; result and fallback rejected",
                consumed=after_primary.digest,
                primary_adapter_id=getattr(self.primary, "adapter_id", type(self.primary).__name__),
            )
        if primary_receipt is not None and primary_receipt.status == "completed":
            if (
                primary_receipt.requested_snapshot_digest != request.snapshot_digest
                or primary_receipt.observed_snapshot_digest != request.snapshot_digest
                or primary_receipt.consumed_snapshot_digest not in {None, request.snapshot_digest}
            ):
                return self._stale_receipt(
                    request,
                    before.digest,
                    started,
                    "primary adapter returned a receipt for a different snapshot",
                    consumed=after_primary.digest,
                    primary_adapter_id=primary_receipt.adapter_id,
                )
            return primary_receipt.model_copy(update={"consumed_snapshot_digest": after_primary.digest})
        if primary_receipt is not None:
            failure = f"primary status={primary_receipt.status}: {primary_receipt.message}"
        return self._checked_fallback(request, before, started, primary_receipt=primary_receipt, failure=failure)

    def _checked_fallback(
        self,
        request: SemanticQueryRequest,
        before: WorkspaceSnapshot,
        started: float,
        *,
        primary_receipt: SemanticQueryReceipt | None,
        failure: str | None = None,
    ) -> SemanticQueryReceipt:
        primary_id = (
            primary_receipt.adapter_id if primary_receipt is not None
            else getattr(self.primary, "adapter_id", None)
        )
        try:
            fallback_receipt = self.fallback.query(request)
        except Exception as exc:
            after = self.snapshotter.capture()
            return SemanticQueryReceipt(
                request_id=request.request_id,
                operation=request.operation,
                adapter_id=getattr(self.fallback, "adapter_id", type(self.fallback).__name__),
                status="error",
                requested_snapshot_digest=request.snapshot_digest,
                observed_snapshot_digest=before.digest,
                consumed_snapshot_digest=after.digest,
                stale_state_rejected=after.digest != request.snapshot_digest,
                latency_ms=(time.perf_counter() - started) * 1_000,
                message=f"semantic primary and fallback unavailable: {type(exc).__name__}: {exc}",
                primary_adapter_id=primary_id,
                fallback_reason=failure,
            )
        after = self.snapshotter.capture()
        if after.digest != request.snapshot_digest:
            return self._stale_receipt(
                request,
                before.digest,
                started,
                "workspace changed while CodeGraph fallback was running",
                consumed=after.digest,
                primary_adapter_id=primary_id,
            )
        if fallback_receipt.status != "completed":
            return fallback_receipt.model_copy(update={
                "consumed_snapshot_digest": after.digest,
                "primary_adapter_id": primary_id,
                "fallback_reason": failure,
            })
        if self.primary is None:
            return fallback_receipt.model_copy(update={"consumed_snapshot_digest": after.digest})
        return fallback_receipt.model_copy(update={
            "status": "fallback",
            "consumed_snapshot_digest": after.digest,
            "primary_adapter_id": primary_id,
            "fallback_reason": failure or "primary adapter did not return a usable result",
        })

    def _stale_receipt(
        self,
        request: SemanticQueryRequest,
        observed: str,
        started: float,
        message: str,
        *,
        consumed: str | None = None,
        primary_adapter_id: str | None = None,
    ) -> SemanticQueryReceipt:
        return SemanticQueryReceipt(
            request_id=request.request_id,
            operation=request.operation,
            adapter_id=self.adapter_id,
            status="rejected",
            requested_snapshot_digest=request.snapshot_digest,
            observed_snapshot_digest=observed,
            consumed_snapshot_digest=consumed or observed,
            stale_state_rejected=True,
            latency_ms=(time.perf_counter() - started) * 1_000,
            message=message,
            primary_adapter_id=primary_adapter_id,
        )
