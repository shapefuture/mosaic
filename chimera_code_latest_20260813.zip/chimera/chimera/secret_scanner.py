"""Outbound secret scanner/redactor for tool/model observations."""
from __future__ import annotations
import base64
import binascii
import math
import re
from dataclasses import dataclass, asdict

SECRET_PATTERNS=(
    re.compile(r"AIza[0-9A-Za-z_\-]{20,}"),
    re.compile(r"sk-or-v1-[a-f0-9]{32,}", re.I),
    re.compile(r"sk-[A-Za-z0-9_\-]{24,}"),
    re.compile(r"csk-[a-z0-9]{24,}", re.I),
    re.compile(r"(?i)(api[_-]?key|token|secret)\s*[:=]\s*['\"]?([A-Za-z0-9_\-]{16,})"),
)

@dataclass(frozen=True)
class RedactionResult:
    text:str; redactions:int
    def as_dict(self): return asdict(self)

def redact_secrets(text:str)->RedactionResult:
    count=0
    value=str(text or "")
    def repl(match):
        nonlocal count
        count+=1
        if match.lastindex and match.lastindex >= 2:
            return f"{match.group(1)}=<redacted>"
        return "<redacted-secret>"
    for pattern in SECRET_PATTERNS:
        value=pattern.sub(repl,value)
    return RedactionResult(value,count)


def redact_encoded_secrets(text: str, known_values: tuple[str, ...] = ()) -> RedactionResult:
    value=str(text or "")
    count=0
    # redact encodings of known canaries/secrets without storing plaintext in reports
    for secret in known_values:
        if not secret: continue
        encodings={
            base64.b64encode(secret.encode()).decode(),
            secret.encode().hex(),
        }
        for enc in encodings:
            if enc and enc in value:
                value=value.replace(enc, "<redacted-encoded-secret>"); count+=1
    # High-entropy base64-ish strings near credential words.
    def repl(match):
        nonlocal count
        token=match.group(0)
        if len(token) >= 32 and re.fullmatch(r"[A-Za-z0-9+/=_-]+", token):
            count += 1; return "<redacted-high-entropy>"
        return token
    value=re.sub(r"(?i)(?:api[_-]?key|token|secret|authorization)[^\n]{0,40}([A-Za-z0-9+/=_-]{32,})", lambda m: m.group(0).replace(m.group(1), "<redacted-high-entropy>"), value)
    return RedactionResult(value,count)
