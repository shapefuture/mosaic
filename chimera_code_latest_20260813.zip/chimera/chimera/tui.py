"""Interactive terminal operator dashboard for goals, workers, DAGs, and refinements."""
from __future__ import annotations

import curses
import json
import pathlib
import time
from dataclasses import dataclass
from typing import Any

from .long_running import GoalStore
from .supervisor import BranchSupervisor


@dataclass(frozen=True)
class DashboardSnapshot:
    goals: tuple[dict[str, Any], ...]
    workers: tuple[dict[str, Any], ...]
    dag: dict[str, Any]
    refinement: dict[str, Any]
    captured_at: str


class DashboardModel:
    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root).resolve()
        self.goals = GoalStore(self.root)
        self.workers = BranchSupervisor(self.root)

    def _latest_dag(self) -> dict[str, Any]:
        candidates = sorted((self.root / ".chimera" / "plans").glob("*.json")) if (self.root / ".chimera" / "plans").exists() else []
        if not candidates: return {"status": "unavailable", "reason": "no persisted plan"}
        value = json.loads(candidates[-1].read_text())
        return {"status": "available", "id": value.get("id"), "nodes": len(value.get("nodes", []))}

    def _refinement(self) -> dict[str, Any]:
        base = self.root / ".chimera" / "continual"
        heads = sorted(base.glob("*/HEAD")) if base.exists() else []
        if not heads: return {"status": "unavailable", "reason": "no refinement history"}
        return {"status": "available", "namespaces": len(heads), "heads": [path.read_text().strip() for path in heads]}

    def snapshot(self) -> DashboardSnapshot:
        return DashboardSnapshot(
            goals=tuple({
                "id": item.id, "status": item.status, "branch": item.branch,
                "turns": f"{item.used_turns}/{item.budget.max_turns}",
                "tokens": f"{item.used_tokens}/{item.budget.max_tokens}",
                "objective": item.objective,
            } for item in self.goals.list()),
            workers=tuple({
                "id": item.id, "status": item.status, "branch": item.branch,
                "model": item.model, "heartbeat": item.heartbeat_at,
            } for item in self.workers.list()),
            dag=self._latest_dag(), refinement=self._refinement(),
            captured_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        )


def render_snapshot(snapshot: DashboardSnapshot, width: int = 120) -> list[str]:
    def clip(text: str) -> str: return text if len(text) <= width else text[:max(0, width - 1)] + "…"
    lines = [clip(f"CHIMERA OPERATOR  {snapshot.captured_at}   [q quit] [r refresh]"), "=" * min(width, 80)]
    lines.append("GOALS")
    if not snapshot.goals: lines.append("  (none)")
    for item in snapshot.goals[:12]:
        lines.append(clip(f"  {item['status']:<9} {item['id']} {item['branch']} turns={item['turns']} tokens={item['tokens']}  {item['objective']}"))
    lines.append("WORKERS")
    if not snapshot.workers: lines.append("  (none)")
    for item in snapshot.workers[:12]:
        lines.append(clip(f"  {item['status']:<9} {item['id']} {item['branch']} model={item['model']} heartbeat={item['heartbeat']}"))
    lines.append(clip(f"DAG         {snapshot.dag}"))
    lines.append(clip(f"REFINEMENT  {snapshot.refinement}"))
    return lines


def run_tui(root: pathlib.Path = pathlib.Path("."), refresh_seconds: float = 1.0) -> None:
    model = DashboardModel(root)

    def app(screen):
        curses.curs_set(0)
        screen.nodelay(True)
        while True:
            height, width = screen.getmaxyx()
            lines = render_snapshot(model.snapshot(), max(20, width - 1))
            screen.erase()
            clipped_rows = 0
            for row, line in enumerate(lines[:height - 1]):
                try:
                    screen.addstr(row, 0, line)
                except curses.error:
                    # A terminal resize/render boundary is display-only; count
                    # it explicitly instead of silently treating it as success.
                    clipped_rows += 1
            # ``clipped_rows`` is intentionally local display telemetry; the
            # dashboard's data-plane is never affected by terminal geometry.
            screen.refresh()
            deadline = time.monotonic() + refresh_seconds
            while time.monotonic() < deadline:
                key = screen.getch()
                if key in {ord("q"), ord("Q")}: return
                if key in {ord("r"), ord("R")}: break
                time.sleep(0.05)

    curses.wrapper(app)
