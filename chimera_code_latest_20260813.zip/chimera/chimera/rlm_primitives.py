"""Primitive data structures for the RLM runtime.

Extracted from rlm.py to keep the runtime file focused on orchestration while
preserving the public import surface (rlm.py re-exports these names).
"""
from __future__ import annotations

import json
import pathlib
import re
import time
from typing import Any, Dict, List, Optional

class Variable:
    """Addressable, chunked context variable.

    Large strings are split into bounded chunks and indexed lexically.  Solvers
    retrieve a query-relevant working set instead of serialising the whole
    variable into every prompt.  This is an actual context reduction mechanism;
    it does not claim that a provider accepts ten million prompt tokens.
    """
    def __init__(self, name: str, value: Any, lineage: Optional[List[str]] = None,
                 chunk_chars: int = 32_768):
        self.name = name
        self.lineage = lineage or [name]
        self.version = 0
        self.chunk_chars = max(4096, int(chunk_chars))
        self._chunks: List[str] = []
        self._index: Dict[str, set[int]] = {}
        self._raw: Any = None
        self.history: List[Dict[str, Any]] = []
        self.set(value, initial=True)

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return set(re.findall(r"[A-Za-z_][A-Za-z0-9_]{2,}", text.lower()))

    def _reindex(self) -> None:
        self._index = {}
        for idx, chunk in enumerate(self._chunks):
            for token in self._tokens(chunk):
                self._index.setdefault(token, set()).add(idx)

    def set(self, value: Any, initial: bool = False):
        if isinstance(value, str):
            self._chunks = [value[i:i + self.chunk_chars] for i in range(0, len(value), self.chunk_chars)] or [""]
            self._raw = None
            self._reindex()
            size = len(value)
        else:
            self._raw = value
            self._chunks = []
            self._index = {}
            size = len(str(value))
        self.history.append({"version": self.version, "size_chars": size, "chunks": len(self._chunks)})
        if not initial:
            self.version += 1

    @property
    def value(self) -> Any:
        return self.get()

    def get(self) -> Any:
        return "".join(self._chunks) if self._chunks else self._raw

    def retrieve(self, query: str, max_chars: int = 100_000, max_chunks: int = 16) -> str:
        if not self._chunks:
            return str(self._raw)
        query_tokens = self._tokens(query)
        scores: Dict[int, float] = {}
        for token in query_tokens:
            postings = self._index.get(token, set())
            idf = 1.0 + (len(self._chunks) / (1 + len(postings)))
            for idx in postings:
                scores[idx] = scores.get(idx, 0.0) + idf
        if scores:
            ordered = [idx for idx, _ in sorted(scores.items(), key=lambda item: (-item[1], item[0]))]
        else:
            # Preserve both the instruction prefix and recent suffix.
            ordered = [0] + ([len(self._chunks) - 1] if len(self._chunks) > 1 else [])
        selected: List[str] = []
        used = 0
        for idx in ordered[:max_chunks]:
            chunk = self._chunks[idx]
            if selected and used + len(chunk) > max_chars:
                break
            selected.append(f"[chunk {idx + 1}/{len(self._chunks)}]\n{chunk[:max_chars - used]}")
            used += len(chunk)
            if used >= max_chars:
                break
        return "\n".join(selected)

    def fork(self, new_name: str) -> "Variable":
        return Variable(new_name, self.get(), lineage=self.lineage + [new_name], chunk_chars=self.chunk_chars)

    def to_dict(self) -> Dict:
        preview = self.retrieve(self.name, max_chars=500, max_chunks=2)
        return {
            "name": self.name, "preview": preview, "version": self.version,
            "lineage": self.lineage, "chunks": len(self._chunks),
            "size_chars": sum(len(chunk) for chunk in self._chunks) if self._chunks else len(str(self._raw)),
            "indexed_terms": len(self._index),
        }

class AgentMessageBus:
    """
    Prime Agent agent_message: parent/sibling/child messaging
    - send(receiver_role, receiver_name, message)
    - recv() for current branch
    - Shared via .chimera/messages.jsonl + in-memory

    Roles: parent, sibling, child
    """
    def __init__(self, root: pathlib.Path):
        self.root=pathlib.Path(root).resolve()
        self.path=self.root / ".chimera" / "messages.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._inbox: Dict[str, List[Dict]] = {}

    def send(self, sender_branch: str, receiver_role: str, receiver_name: str, message: str, kind: str="text"):
        entry={"ts": time.time(), "sender": sender_branch, "receiver_role": receiver_role, "receiver": receiver_name, "message": message, "kind": kind}
        with open(self.path, "a") as f:
            f.write(json.dumps(entry)+"\n")
        # Also in-memory
        key=f"{receiver_role}:{receiver_name}"
        self._inbox.setdefault(key, []).append(entry)
        return entry

    def recv(self, role: str, name: str) -> List[Dict]:
        key=f"{role}:{name}"
        # Load from file
        msgs=[]
        if self.path.exists():
            for line in self.path.read_text().splitlines():
                if not line.strip(): continue
                e=json.loads(line)
                if e.get("receiver")==name and e.get("receiver_role")==role:
                    msgs.append(e)
        # Merge in-memory
        msgs.extend(self._inbox.get(key, []))
        # Dedup by ts+sender
        seen=set()
        uniq=[]
        for m in msgs:
            k=(m["ts"], m["sender"])
            if k not in seen:
                uniq.append(m); seen.add(k)
        return uniq

    def broadcast(self, sender_branch: str, message: str):
        # Broadcast to all siblings/children
        return self.send(sender_branch, "sibling", "*", message, kind="broadcast")

class AuthStorage:
    """Provider routing without credential persistence.

    Credentials are environment-only.  The historical ``auth.json`` store was
    removed because file permissions do not turn a persisted bearer token into
    a safe artifact, and branch/materialization filters are not a substitute for
    never writing the secret in the first place.
    """
    PROVIDERS = {
        "kimi": ["kimi-k2", "kimi"],
        "deepseek": ["deepseek"],
        "qwen": ["qwen"],
        "claude": ["claude", "anthropic", "opus", "sonnet"],
        "openai": ["gpt", "openai", "o1", "o3"],
        "gemini": ["gemini", "google"],
        "minimax": ["minimax"],
        "openrouter": ["openrouter"],
        "tokenrouter": ["tokenrouter"],
        "ollama": ["ollama", "llama"],
    }

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.tokens: Dict[str, str] = {}

    def set_token(self, provider: str, token: str):
        raise RuntimeError(
            "provider credentials are environment-only; set the provider's API-key environment variable"
        )

    def resolve_provider(self, model: str) -> str:
        m=model.lower()
        if "mock" in m:
            return "mock"
        from .providers import ProviderCatalog
        resolved = ProviderCatalog().resolve(model).id
        # Preserve legacy internal route names used by the direct clients.
        return {"anthropic": "claude", "google": "gemini"}.get(resolved, resolved)

    def list_providers(self) -> List[str]:
        from .providers import ProviderCatalog
        return [spec.id for spec in ProviderCatalog().list()] + ["mock"]

class TaskScript:
    """
    RAH Task() executable script: parent generates EXE script that spawns sub-harnesses in parallel
    Per RAH paper 2606.13643 §3: RAH improves Codex 71.75%->81.36% Oolong-Synthetic 199 samples 13 buckets 4M,
    harness recursion > model recursion. Parent generates executable Task() script:

    # Generated file: .chimera/task_scripts/<parent_branch>.py
    # Executable script content per RAH:
    from chimera.rlm import Task, run_task
    tasks = [
        Task(question="Summarize auth flow", branch="task-auth-xxx", model="kimi-k2.5:agent-swarm"),
        Task(question="Summarize API layer", branch="task-api-xxx", model="kimi-k2.5:agent-swarm"),
    ]
    results = await asyncio.gather(*[run_task(t) for t in tasks])  # parallel sub-harnesses

    Each Task is full harness (FS tools, code execution, planning) not bare model call.

    Also includes agent_message for inter-harness: parent/sibling/child
    """
    def __init__(self, question: str, branch: str, model: str="mock-echo", dependencies: Optional[List[str]]=None, verification_criteria: str=""):
        self.question=question
        self.branch=branch
        self.model=model
        self.dependencies=dependencies or []
        self.verification_criteria=verification_criteria

    def to_dict(self) -> Dict:
        return {"question": self.question, "branch": self.branch, "model": self.model, "dependencies": self.dependencies, "verification_criteria": self.verification_criteria}

    def to_executable_script(self) -> str:
        """RAH: generate executable Python script string (harness recursion)"""
        deps_str = f", dependencies={self.dependencies}" if self.dependencies else ""
        question = json.dumps(self.question)
        branch = json.dumps(self.branch)
        model = json.dumps(self.model)
        return f'TaskScript(question={question}, branch={branch}, model={model}{deps_str})'

    @staticmethod
    def generate_executable_file(parent_branch: str, tasks: List["TaskScript"], root: pathlib.Path) -> pathlib.Path:
        """RAH: write executable Task() script to .chimera/task_scripts/<parent>.py (611★ rlm-harness pattern)"""
        script_dir=root / ".chimera" / "task_scripts"
        script_dir.mkdir(parents=True, exist_ok=True)
        path=script_dir / f"{parent_branch}.py"
        header='# RAH executable Task() script — harness recursion (RAH paper 2606.13643 81.36% Oolong)\n# Parent generates and runs this script that spawns sub-agent harnesses in parallel\n# Each Task is full harness (FS tools, code exec, planning) not bare model call\nimport asyncio\nfrom chimera.rlm import TaskScript\n\nasync def run_task(task: TaskScript):\n    from chimera.rlm import RLMRuntime\n    import pathlib\n    rt=RLMRuntime(pathlib.Path("."))\n    return rt.rlm(task.question, branch=task.branch, model=task.model)\n\n'
        body="tasks = [\n"
        for t in tasks:
            body+=f"    {t.to_executable_script()},\n"
        body+="]\n\n"
        body+="# Harness recursion: 71.75%->81.36% Codex, 89.77% Sonnet 4.5 — same backbone, harness gain\n"
        body+="async def main():\n    results = await asyncio.gather(*[run_task(t) for t in tasks])\n    return results\n\n"
        body+="if __name__ == '__main__': asyncio.run(main())\n"
        path.write_text(header+body)
        return path

    @staticmethod
    def generate(parent_task: str, num_subtasks: int=3, model: str="mock-echo") -> List["TaskScript"]:
        # Decompose parent_task into subtasks via heuristic (matches DAGPlanner)
        base = re.split(r"[.;]|\band\b", parent_task)
        parts=[p.strip() for p in base if len(p.strip())>10][:num_subtasks]
        if len(parts)<num_subtasks:
            # Fallback templates
            templates=[
                "Identify blast radius via code graph (MATCH functions calling auth)",
                "Implement fix and ensure file writes are within allowed fs capabilities",
                "Verify fix via tests + LTL proof G(!write OutsideAllow)",
            ]
            parts=(parts+templates)[:num_subtasks]
        tasks=[]
        for i, q in enumerate(parts[:num_subtasks]):
            tasks.append(TaskScript(
                question=q,
                branch=f"task-{i+1:03d}-{int(time.time()*1000)%10000}",
                model=model,
                dependencies=[f"task-{j+1:03d}" for j in range(i)] if i>0 and "fix" in q.lower() else [],
                verification_criteria="Answer cites 2+ sources with URLs" if "blast" in q.lower() else "Diff shows only allowed paths edited and tests pass"
            ))
        return tasks

class Blackboard:
    """Chained RLM blackboard — shared artifacts across fresh roots (not conversational history)"""
    def __init__(self):
        self.artifacts: Dict[str,Any] = {}
        self.messages: List[Dict] = []
        self.variables: Dict[str, Variable] = {}
    def put(self, key: str, value: Any): self.artifacts[key]=value; self.messages.append({"kind":"put","key":key,"ts":time.time()})
    def get(self, key: str, default=None): return self.artifacts.get(key, default)
    def append_trace(self, entry: Dict): self.messages.append(entry)
    def variable(self, name: str, value: Any=None) -> Variable:
        if name not in self.variables and value is not None:
            self.variables[name]=Variable(name, value)
        return self.variables.get(name)
    def set_var(self, name: str, value: Any):
        if name not in self.variables:
            self.variables[name]=Variable(name, value)
        else:
            self.variables[name].set(value)

