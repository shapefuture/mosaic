"""Provider-neutral external-agent harness contract and local fixture adapter."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
import pathlib
import subprocess
import time
from typing import Any, Iterable, Protocol

from .process_control import ProcessGroupCancellationReceipt, terminate_process_group


@dataclass(frozen=True)
class HarnessEvent:
    kind: str
    data: dict[str, Any]


class AgentHarness(Protocol):
    def start(self, task: str) -> None: ...
    def stream_events(self) -> Iterable[HarnessEvent]: ...
    def snapshot(self) -> dict[str, Any]: ...
    def cancel(self) -> None: ...
    def collect_candidate_diff(self) -> dict[str, Any]: ...


class FixtureSubprocessHarness:
    """A test-only JSONL harness process; no shell invocation or commit authority."""

    def __init__(self, command: list[str], *, cwd: pathlib.Path, timeout_seconds: float = 30.0) -> None:
        self.command, self.cwd, self.timeout = list(command), pathlib.Path(cwd), float(timeout_seconds)
        self.process: subprocess.Popen[str] | None = None
        self.last_cancellation: ProcessGroupCancellationReceipt | None = None
        self._events: list[HarnessEvent] = []
        self._diff: dict[str, Any] = {"ops": []}

    def start(self, task: str) -> None:
        if self.process is not None:
            raise RuntimeError("harness already started")
        env = {key: value for key, value in os.environ.items() if key in {"PATH", "LANG", "LC_ALL"}}
        self.process = subprocess.Popen(self.command + [task], cwd=self.cwd, env=env, text=True, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)

    def stream_events(self) -> Iterable[HarnessEvent]:
        if self.process is None or self.process.stdout is None:
            raise RuntimeError("harness not started")
        started = time.monotonic()
        for line in self.process.stdout:
            if time.monotonic() - started > self.timeout:
                self.cancel()
                yield HarnessEvent("error", {"reason": "timeout"})
                return
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                yield HarnessEvent("error", {"reason": "malformed_jsonl"})
                continue
            if not isinstance(value, dict) or not isinstance(value.get("kind"), str):
                yield HarnessEvent("error", {"reason": "malformed_event"})
                continue
            event = HarnessEvent(value["kind"], dict(value.get("data", {})))
            self._events.append(event)
            if event.kind == "candidate_diff" and isinstance(event.data.get("diff"), dict):
                self._diff = dict(event.data["diff"])
            yield event

    def snapshot(self) -> dict[str, Any]:
        encoded = json.dumps(self._diff, sort_keys=True, separators=(",", ":")).encode()
        return {"events": len(self._events), "diff_hash": "sha256:" + hashlib.sha256(encoded).hexdigest(), "running": bool(self.process and self.process.poll() is None)}

    def cancel(self) -> None:
        if self.process is not None:
            self.last_cancellation = terminate_process_group(
                self.process, reason="fixture harness cancelled", grace_seconds=2.0,
            )

    def collect_candidate_diff(self) -> dict[str, Any]:
        return dict(self._diff)
