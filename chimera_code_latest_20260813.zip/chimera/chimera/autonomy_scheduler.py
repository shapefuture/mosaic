"""Durable, single-claim scheduler for explicitly authorized autonomous goals.

This module owns schedule claims, not model routing.  A host must explicitly
supply a step resolver.  Every claimed callback is dispatched through
``AutonomousController.run_background_managed``; there is intentionally no
foreground/cooperative callback fallback and no automatic provider/model creation.
"""
from __future__ import annotations

from dataclasses import dataclass
import time
from typing import Callable, Literal

from .autonomy_execution import ManagedGoalStepPort
from .long_running import AutonomousController, GoalRecord, GoalStore, ScheduleClaim


StepResolver = Callable[[GoalRecord], ManagedGoalStepPort]


@dataclass(frozen=True)
class ScheduledDispatchReceipt:
    schedule_id: str
    goal_id: str
    claim_id: str
    outcome: Literal["known", "unknown"]
    controller_status: str | None
    completed_claim: bool
    reason: str | None = None


class GoalScheduleRunner:
    """Advance due schedules once; safe across crashes and concurrent runners.

    A crash after a durable claim but before its completion leaves the schedule
    claimed.  Once that claim expires, ``GoalStore.claim_due`` records it as an
    unknown outcome and disables it.  It is never automatically replayed.
    """

    def __init__(
        self,
        store: GoalStore,
        controller: AutonomousController,
        step_resolver: StepResolver,
        *,
        claim_lease_seconds: float = 300.0,
    ) -> None:
        if claim_lease_seconds <= 0:
            raise ValueError("claim_lease_seconds must be positive")
        if controller.store.root != store.root:
            raise ValueError("scheduler and controller must use the same workspace root")
        self.store = store
        self.controller = controller
        self.step_resolver = step_resolver
        self.claim_lease_seconds = float(claim_lease_seconds)

    def run_due(self, *, now: float | None = None) -> list[ScheduledDispatchReceipt]:
        current = time.time() if now is None else float(now)
        claims = self.store.claim_due(now=current, lease_seconds=self.claim_lease_seconds)
        receipts: list[ScheduledDispatchReceipt] = []
        for claim in claims:
            receipts.append(self._dispatch(claim, now=current))
        return receipts

    def _dispatch(self, claim: ScheduleClaim, *, now: float) -> ScheduledDispatchReceipt:
        try:
            goal = self.store.get(claim.goal_id)
            step = self.step_resolver(goal)
        except Exception as exc:
            completed = self.store.complete_schedule_claim(claim, now=now, outcome="resolver_unavailable")
            self.store.wal.append("goal_schedule", {
                "event": "resolver_unavailable", "schedule_id": claim.schedule_id,
                "goal_id": claim.goal_id, "claim_id": claim.claim_id,
                "error_type": type(exc).__name__,
            })
            return ScheduledDispatchReceipt(
                claim.schedule_id, claim.goal_id, claim.claim_id, "known", None, completed,
                f"step resolver unavailable: {type(exc).__name__}",
            )
        try:
            # Structural authority boundary: scheduler work is always a managed
            # local process, so lease/host admission are checked while it runs
            # and revocation has a process-group cancellation receipt.
            result = self.controller.run_background_managed(goal.id, step)
        except Exception as exc:
            # Do not complete/retry an exception whose callback outcome could be
            # unknown.  The claim will age into the explicit unknown state.
            self.store.wal.append("goal_schedule", {
                "event": "dispatch_exception_unknown", "schedule_id": claim.schedule_id,
                "goal_id": claim.goal_id, "claim_id": claim.claim_id,
                "error_type": type(exc).__name__,
            })
            return ScheduledDispatchReceipt(
                claim.schedule_id, claim.goal_id, claim.claim_id, "unknown", None, False,
                f"background callback raised {type(exc).__name__}; no automatic replay",
            )
        status = str(result.get("status", "unknown")) if isinstance(result, dict) else "unknown"
        execution_outcome = str(result.get("execution_outcome", "unknown")) if isinstance(result, dict) else "unknown"
        if execution_outcome == "unknown":
            self.store.wal.append("goal_schedule", {
                "event": "managed_outcome_unknown", "schedule_id": claim.schedule_id,
                "goal_id": claim.goal_id, "claim_id": claim.claim_id,
            })
            return ScheduledDispatchReceipt(
                claim.schedule_id, claim.goal_id, claim.claim_id, "unknown", status, False,
                "managed step outcome is unknown; claim retained for operator recovery",
            )
        completed = self.store.complete_schedule_claim(claim, now=now, outcome=f"controller:{status}")
        if not completed:
            self.store.wal.append("goal_schedule", {
                "event": "completion_mismatch_unknown", "schedule_id": claim.schedule_id,
                "goal_id": claim.goal_id, "claim_id": claim.claim_id,
            })
            return ScheduledDispatchReceipt(
                claim.schedule_id, claim.goal_id, claim.claim_id, "unknown", status, False,
                "claim changed before completion; no automatic replay",
            )
        return ScheduledDispatchReceipt(claim.schedule_id, claim.goal_id, claim.claim_id, "known", status, True)
