"""Unified gate dashboard for users, API, GUI, and agents."""
from __future__ import annotations

import json
import pathlib
from dataclasses import dataclass, asdict
from typing import Any

from .architecture_ratchet import ArchitectureRatchet
from .cloud_scale_readiness import CloudScaleReadinessPlanner
from .token_error_tax import TokenErrorTaxAnalyzer
from .gate_history import GateHistoryLedger


@dataclass(frozen=True)
class GateArtifactSummary:
    path: str
    schema_version: str
    status: str | None
    promotion_allowed: bool | None
    failures: int | None
    findings: int | None


class GateDashboardBuilder:
    """Small read-only dashboard over latest gate artifacts and cheap live gates."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.artifacts = self.root / "artifacts"

    def build(self, *, recent: int = 50) -> dict[str, Any]:
        artifact_summaries = self._artifact_summaries(limit=recent)
        ratchet = ArchitectureRatchet(self.root).run()
        token_tax = TokenErrorTaxAnalyzer(self.root).analyze()
        cloud = CloudScaleReadinessPlanner(self.root).plan(agents=1000, tenants=100, mode="self-hosted")
        history = GateHistoryLedger(self.root).trends(limit=50)
        blockers = []
        warnings = []
        if ratchet.get("status") == "fail":
            blockers.append("architecture-ratchet")
        if cloud.get("cloud_blockers"):
            blockers.extend("cloud:" + item for item in cloud.get("cloud_blockers", []))
        if cloud.get("warnings"):
            warnings.extend("cloud:" + item for item in cloud.get("warnings", []))
        latest_supreme = next((a for a in artifact_summaries if a.schema_version == "chimera.supreme-gate.v1"), None)
        if latest_supreme and latest_supreme.status not in {"pass", None}:
            warnings.append("latest-supreme-gate:" + str(latest_supreme.status))
        return {
            "schema_version": "chimera.gate-dashboard.v1",
            "root": str(self.root),
            "status": "blocked" if blockers else "review" if warnings else "green",
            "blockers": blockers,
            "warnings": warnings,
            "latest_supreme_gate": asdict(latest_supreme) if latest_supreme else None,
            "token_error_tax": token_tax,
            "architecture_ratchet": {"status": ratchet.get("status"), "finding_count": len(ratchet.get("findings", []))},
            "cloud_scale_readiness": {
                "ready_for_local_mode": cloud.get("ready_for_local_mode"),
                "ready_for_thousands_cloud_agents": cloud.get("ready_for_thousands_cloud_agents"),
                "warnings": cloud.get("warnings"),
                "shard_plan": cloud.get("shard_plan"),
            },
            "gate_history": history,
            "artifacts": [asdict(item) for item in artifact_summaries],
            "promotion_allowed": False,
            "next_required_actions": self._next_actions(blockers, warnings, latest_supreme),
        }

    def _artifact_summaries(self, *, limit: int) -> list[GateArtifactSummary]:
        if not self.artifacts.exists():
            return []
        paths = sorted(self.artifacts.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[: max(1, int(limit))]
        out: list[GateArtifactSummary] = []
        for path in paths:
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            failures = data.get("failures")
            findings = data.get("findings")
            out.append(GateArtifactSummary(
                path=str(path.relative_to(self.root)),
                schema_version=str(data.get("schema_version", "unknown")),
                status=str(data.get("status")) if data.get("status") is not None else None,
                promotion_allowed=data.get("promotion_allowed") if isinstance(data.get("promotion_allowed"), bool) else None,
                failures=len(failures) if isinstance(failures, list) else None,
                findings=len(findings) if isinstance(findings, list) else data.get("finding_count") if isinstance(data.get("finding_count"), int) else None,
            ))
        return out

    @staticmethod
    def _next_actions(blockers: list[str], warnings: list[str], latest_supreme: GateArtifactSummary | None) -> list[str]:
        if blockers:
            return ["resolve blockers before any promotion: " + ", ".join(blockers)]
        actions = []
        if latest_supreme is None:
            actions.append("run chimera platform supreme-gate and store an artifact")
        if warnings:
            actions.append("review warnings: " + ", ".join(warnings))
        actions.extend([
            "run candidate-promotion-gate with evaluator-owned hidden tests for each candidate patch",
            "run cloud-scale-smoke in the deployment image before claiming cloud readiness",
            "run gateway-fidelity-benchmark for any configured gateway before using it as default",
        ])
        return actions
