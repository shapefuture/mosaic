"""Shared PostgreSQL state and object-CAS adapters for explicit cloud composition."""

from __future__ import annotations

import hashlib
import json
import re
import time
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Protocol

from .artifacts import ArtifactIntegrityError, ArtifactRef

_TENANT = re.compile(r"^[0-9a-f]{64}$")


def _tenant_key(value: str) -> str:
    if not _TENANT.fullmatch(str(value)):
        raise ValueError("cloud state requires a 64-hex tenant key")
    return str(value)


def _json(value: Mapping[str, Any]) -> str:
    return json.dumps(dict(value), sort_keys=True, separators=(",", ":"), default=str)


@dataclass(frozen=True)
class CloudLease:
    key: str
    holder: str
    fencing_token: int
    expires_at: float


@dataclass(frozen=True)
class CloudQuotaDecision:
    allowed: bool
    active_runs: int
    reason: str


@dataclass(frozen=True)
class OutboxRecord:
    id: int
    tenant_key: str
    kind: str
    payload: dict[str, Any]
    attempts: int


class PostgresCloudStateAdapter:
    """Transactional event, lease, quota, session, and telemetry-outbox state."""

    def __init__(
        self,
        database_url: str,
        *,
        schema: str = "public",
        enable_rls: bool = False,
        initialize_schema: bool = True,
    ) -> None:
        if not schema.replace("_", "").isalnum():
            raise ValueError("cloud state schema must be an identifier")
        try:
            from sqlalchemy import create_engine
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError(
                "install the durable-postgres extra for cloud state"
            ) from exc
        self.engine = create_engine(database_url, pool_pre_ping=True)
        self.schema = schema
        self.prefix = f'"{schema}".chimera_cloud_'
        if not initialize_schema:
            with self.engine.connect() as connection:
                exists = connection.exec_driver_sql(
                    "SELECT to_regclass(%s)",
                    (f"{schema}.chimera_cloud_events",),
                ).scalar_one()
            if exists is None:
                self.engine.dispose()
                raise RuntimeError(
                    "cloud state schema is not initialized; run migrations with the owner role"
                )
            return
        with self.engine.begin() as connection:
            connection.exec_driver_sql(f"""
                CREATE TABLE IF NOT EXISTS {self.prefix}events (
                    seq bigserial PRIMARY KEY,
                    tenant_key text NOT NULL,
                    kind text NOT NULL,
                    data_json text NOT NULL,
                    created_at double precision NOT NULL
                );
                CREATE INDEX IF NOT EXISTS chimera_cloud_events_tenant_seq
                    ON {self.prefix}events (tenant_key, seq);
                CREATE TABLE IF NOT EXISTS {self.prefix}leases (
                    tenant_key text NOT NULL,
                    lease_key text NOT NULL,
                    holder text NOT NULL,
                    fencing_token bigint NOT NULL,
                    expires_at double precision NOT NULL,
                    PRIMARY KEY (tenant_key, lease_key)
                );
                CREATE TABLE IF NOT EXISTS {self.prefix}quota_runs (
                    tenant_key text NOT NULL,
                    run_id text NOT NULL,
                    expires_at double precision NOT NULL,
                    PRIMARY KEY (tenant_key, run_id)
                );
                CREATE TABLE IF NOT EXISTS {self.prefix}sessions (
                    tenant_key text NOT NULL,
                    session_id text NOT NULL,
                    version bigint NOT NULL,
                    payload_json text NOT NULL,
                    updated_at double precision NOT NULL,
                    PRIMARY KEY (tenant_key, session_id)
                );
                CREATE TABLE IF NOT EXISTS {self.prefix}waits (
                    tenant_key text NOT NULL,
                    wait_id text NOT NULL,
                    run_id text NOT NULL,
                    version bigint NOT NULL,
                    state text NOT NULL,
                    deadline double precision NOT NULL,
                    payload_json text NOT NULL,
                    updated_at double precision NOT NULL,
                    PRIMARY KEY (tenant_key, wait_id)
                );
                CREATE INDEX IF NOT EXISTS chimera_cloud_waits_run
                    ON {self.prefix}waits (tenant_key, run_id, state, deadline);
                CREATE TABLE IF NOT EXISTS {self.prefix}outbox (
                    id bigserial PRIMARY KEY,
                    tenant_key text NOT NULL,
                    kind text NOT NULL,
                    payload_json text NOT NULL,
                    attempts integer NOT NULL DEFAULT 0,
                    available_at double precision NOT NULL,
                    delivered_at double precision,
                    last_error text
                );
                CREATE INDEX IF NOT EXISTS chimera_cloud_outbox_ready
                    ON {self.prefix}outbox (available_at, id)
                    WHERE delivered_at IS NULL;
            """)
            if enable_rls:
                self._enable_rls(connection)

    def _enable_rls(self, connection: Any) -> None:
        for name in ("events", "leases", "quota_runs", "sessions", "waits", "outbox"):
            table = f"{self.prefix}{name}"
            policy = f"chimera_{name}_tenant"
            connection.exec_driver_sql(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
            connection.exec_driver_sql(f"DROP POLICY IF EXISTS {policy} ON {table}")
            connection.exec_driver_sql(
                f"CREATE POLICY {policy} ON {table} "
                "USING (tenant_key = current_setting('chimera.tenant_key', true)) "
                "WITH CHECK (tenant_key = current_setting('chimera.tenant_key', true))"
            )

    @staticmethod
    def _scope(connection: Any, tenant_key: str) -> None:
        connection.exec_driver_sql(
            "SELECT set_config('chimera.tenant_key', %s, true)", (tenant_key,)
        )

    def append_event(
        self, *, tenant_key: str, kind: str, data: Mapping[str, Any]
    ) -> int:
        tenant = _tenant_key(tenant_key)
        if not kind:
            raise ValueError("cloud event kind is required")
        with self.engine.begin() as connection:
            self._scope(connection, tenant)
            row = connection.exec_driver_sql(
                f"INSERT INTO {self.prefix}events "
                "(tenant_key,kind,data_json,created_at) VALUES (%s,%s,%s,%s) RETURNING seq",
                (tenant, kind, _json(data), time.time()),
            ).first()
        if row is None:
            raise RuntimeError("cloud event insert returned no sequence")
        return int(row[0])

    def replay_events(
        self,
        *,
        tenant_key: str,
        after_seq: int = 0,
        kind: str | None = None,
        limit: int = 1_000,
    ) -> list[dict[str, Any]]:
        tenant = _tenant_key(tenant_key)
        size = min(10_000, max(1, int(limit)))
        with self.engine.connect() as connection:
            self._scope(connection, tenant)
            if kind is None:
                rows = connection.exec_driver_sql(
                    f"SELECT seq,kind,data_json,created_at FROM {self.prefix}events "
                    "WHERE tenant_key=%s AND seq>%s ORDER BY seq LIMIT %s",
                    (tenant, int(after_seq), size),
                ).fetchall()
            else:
                rows = connection.exec_driver_sql(
                    f"SELECT seq,kind,data_json,created_at FROM {self.prefix}events "
                    "WHERE tenant_key=%s AND seq>%s AND kind=%s ORDER BY seq LIMIT %s",
                    (tenant, int(after_seq), kind, size),
                ).fetchall()
        return [
            {
                "seq": int(row[0]),
                "kind": str(row[1]),
                "data": json.loads(row[2]),
                "created_at": float(row[3]),
            }
            for row in rows
        ]

    def acquire_lease(
        self,
        key: str,
        holder: str,
        ttl_seconds: float,
        *,
        tenant_key: str,
    ) -> CloudLease | None:
        tenant = _tenant_key(tenant_key)
        if not key or not holder or ttl_seconds <= 0:
            raise ValueError("lease requires key, holder, and positive TTL")
        now = time.time()
        expires = now + float(ttl_seconds)
        with self.engine.begin() as connection:
            self._scope(connection, tenant)
            row = connection.exec_driver_sql(
                f"""INSERT INTO {self.prefix}leases
                    (tenant_key,lease_key,holder,fencing_token,expires_at)
                    VALUES (%s,%s,%s,1,%s)
                    ON CONFLICT (tenant_key,lease_key) DO UPDATE SET
                      holder=EXCLUDED.holder,
                      fencing_token={self.prefix}leases.fencing_token+1,
                      expires_at=EXCLUDED.expires_at
                    WHERE {self.prefix}leases.expires_at<=%s
                       OR {self.prefix}leases.holder=EXCLUDED.holder
                    RETURNING holder,fencing_token,expires_at""",
                (tenant, key, holder, expires, now),
            ).first()
        if row is None:
            return None
        return CloudLease(key, str(row[0]), int(row[1]), float(row[2]))

    def release_lease(
        self,
        key: str,
        holder: str,
        fencing_token: int | None = None,
        *,
        tenant_key: str,
    ) -> bool:
        tenant = _tenant_key(tenant_key)
        with self.engine.begin() as connection:
            self._scope(connection, tenant)
            if fencing_token is None:
                result = connection.exec_driver_sql(
                    f"DELETE FROM {self.prefix}leases "
                    "WHERE tenant_key=%s AND lease_key=%s AND holder=%s",
                    (tenant, key, holder),
                )
            else:
                result = connection.exec_driver_sql(
                    f"DELETE FROM {self.prefix}leases "
                    "WHERE tenant_key=%s AND lease_key=%s AND holder=%s AND fencing_token=%s",
                    (tenant, key, holder, int(fencing_token)),
                )
        return bool(result.rowcount)

    def admit(
        self,
        *,
        tenant_key: str,
        run_id: str,
        max_active_runs: int,
        expires_at: float,
    ) -> CloudQuotaDecision:
        tenant = _tenant_key(tenant_key)
        if not run_id or max_active_runs < 1 or expires_at <= time.time():
            raise ValueError(
                "quota admission requires run, positive cap, and future expiry"
            )
        with self.engine.begin() as connection:
            self._scope(connection, tenant)
            connection.exec_driver_sql(
                "SELECT pg_advisory_xact_lock(hashtext(%s))",
                ("chimera-quota:" + tenant,),
            )
            connection.exec_driver_sql(
                f"DELETE FROM {self.prefix}quota_runs WHERE tenant_key=%s AND expires_at<=%s",
                (tenant, time.time()),
            )
            count = int(
                connection.exec_driver_sql(
                    f"SELECT count(*) FROM {self.prefix}quota_runs WHERE tenant_key=%s",
                    (tenant,),
                ).scalar_one()
            )
            if count >= int(max_active_runs):
                return CloudQuotaDecision(
                    False, count, "tenant active-run quota exhausted"
                )
            connection.exec_driver_sql(
                f"INSERT INTO {self.prefix}quota_runs (tenant_key,run_id,expires_at) "
                "VALUES (%s,%s,%s) ON CONFLICT (tenant_key,run_id) DO UPDATE "
                "SET expires_at=EXCLUDED.expires_at",
                (tenant, run_id, float(expires_at)),
            )
        return CloudQuotaDecision(True, count + 1, "tenant run admitted")

    def release(self, *, tenant_key: str, run_id: str) -> bool:
        tenant = _tenant_key(tenant_key)
        with self.engine.begin() as connection:
            self._scope(connection, tenant)
            result = connection.exec_driver_sql(
                f"DELETE FROM {self.prefix}quota_runs WHERE tenant_key=%s AND run_id=%s",
                (tenant, run_id),
            )
        return bool(result.rowcount)

    def put_session(
        self,
        *,
        tenant_key: str,
        session_id: str,
        payload: Mapping[str, Any],
        expected_version: int | None,
    ) -> int:
        tenant = _tenant_key(tenant_key)
        with self.engine.begin() as connection:
            self._scope(connection, tenant)
            if expected_version is None:
                row = connection.exec_driver_sql(
                    f"INSERT INTO {self.prefix}sessions "
                    "(tenant_key,session_id,version,payload_json,updated_at) "
                    "VALUES (%s,%s,1,%s,%s) ON CONFLICT DO NOTHING RETURNING version",
                    (tenant, session_id, _json(payload), time.time()),
                ).first()
            else:
                row = connection.exec_driver_sql(
                    f"UPDATE {self.prefix}sessions SET version=version+1,payload_json=%s,updated_at=%s "
                    "WHERE tenant_key=%s AND session_id=%s AND version=%s RETURNING version",
                    (
                        _json(payload),
                        time.time(),
                        tenant,
                        session_id,
                        int(expected_version),
                    ),
                ).first()
        if row is None:
            raise RuntimeError("cloud session compare-and-swap conflict")
        return int(row[0])

    def get_session(
        self, *, tenant_key: str, session_id: str
    ) -> tuple[int, dict[str, Any]]:
        tenant = _tenant_key(tenant_key)
        with self.engine.connect() as connection:
            self._scope(connection, tenant)
            row = connection.exec_driver_sql(
                f"SELECT version,payload_json FROM {self.prefix}sessions "
                "WHERE tenant_key=%s AND session_id=%s",
                (tenant, session_id),
            ).first()
        if row is None:
            raise KeyError(session_id)
        return int(row[0]), json.loads(row[1])

    def register_wait(
        self,
        *,
        tenant_key: str,
        wait_id: str,
        run_id: str,
        deadline: float,
        payload: Mapping[str, Any],
    ) -> int:
        tenant = _tenant_key(tenant_key)
        if not wait_id or not run_id or deadline <= time.time():
            raise ValueError("cloud wait requires IDs and a future deadline")
        with self.engine.begin() as connection:
            self._scope(connection, tenant)
            row = connection.exec_driver_sql(
                f"INSERT INTO {self.prefix}waits "
                "(tenant_key,wait_id,run_id,version,state,deadline,payload_json,updated_at) "
                "VALUES (%s,%s,%s,1,'waiting',%s,%s,%s) "
                "ON CONFLICT (tenant_key,wait_id) DO NOTHING RETURNING version",
                (tenant, wait_id, run_id, float(deadline), _json(payload), time.time()),
            ).first()
        if row is None:
            raise RuntimeError("cloud wait ID already exists")
        return int(row[0])

    def transition_wait(
        self,
        *,
        tenant_key: str,
        wait_id: str,
        expected_version: int,
        state: str,
        payload: Mapping[str, Any],
    ) -> int:
        if state not in {"resolved", "expired", "cancelled"}:
            raise ValueError("cloud wait terminal state is invalid")
        tenant = _tenant_key(tenant_key)
        with self.engine.begin() as connection:
            self._scope(connection, tenant)
            row = connection.exec_driver_sql(
                f"UPDATE {self.prefix}waits SET version=version+1,state=%s,payload_json=%s,updated_at=%s "
                "WHERE tenant_key=%s AND wait_id=%s AND version=%s AND state='waiting' "
                "RETURNING version",
                (
                    state,
                    _json(payload),
                    time.time(),
                    tenant,
                    wait_id,
                    int(expected_version),
                ),
            ).first()
        if row is None:
            raise RuntimeError("cloud wait compare-and-swap conflict")
        return int(row[0])

    def pending_waits(
        self, *, tenant_key: str, run_id: str, limit: int = 1_000
    ) -> list[dict[str, Any]]:
        tenant = _tenant_key(tenant_key)
        with self.engine.connect() as connection:
            self._scope(connection, tenant)
            rows = connection.exec_driver_sql(
                f"SELECT wait_id,version,deadline,payload_json FROM {self.prefix}waits "
                "WHERE tenant_key=%s AND run_id=%s AND state='waiting' AND deadline>%s "
                "ORDER BY wait_id LIMIT %s",
                (tenant, run_id, time.time(), min(10_000, max(1, int(limit)))),
            ).fetchall()
        return [
            {
                "wait_id": str(row[0]),
                "version": int(row[1]),
                "deadline": float(row[2]),
                "payload": json.loads(row[3]),
            }
            for row in rows
        ]

    def enqueue_outbox(
        self,
        *,
        tenant_key: str,
        kind: str,
        payload: Mapping[str, Any],
    ) -> int:
        tenant = _tenant_key(tenant_key)
        with self.engine.begin() as connection:
            self._scope(connection, tenant)
            row = connection.exec_driver_sql(
                f"INSERT INTO {self.prefix}outbox "
                "(tenant_key,kind,payload_json,available_at) VALUES (%s,%s,%s,%s) RETURNING id",
                (tenant, kind, _json(payload), time.time()),
            ).first()
        if row is None:
            raise RuntimeError("cloud outbox insert returned no identifier")
        return int(row[0])

    def claim_outbox(
        self,
        *,
        limit: int = 100,
        tenant_key: str | None = None,
    ) -> tuple[OutboxRecord, ...]:
        size = min(1_000, max(1, int(limit)))
        tenant = _tenant_key(tenant_key) if tenant_key is not None else None
        with self.engine.begin() as connection:
            if tenant is not None:
                self._scope(connection, tenant)
            rows = connection.exec_driver_sql(
                f"SELECT id,tenant_key,kind,payload_json,attempts FROM {self.prefix}outbox "
                "WHERE delivered_at IS NULL AND available_at<=%s "
                "ORDER BY id FOR UPDATE SKIP LOCKED LIMIT %s",
                (time.time(), size),
            ).fetchall()
            ids = [int(row[0]) for row in rows]
            if ids:
                connection.exec_driver_sql(
                    f"UPDATE {self.prefix}outbox SET attempts=attempts+1 "
                    "WHERE id = ANY(%s)",
                    (ids,),
                )
        return tuple(
            OutboxRecord(
                int(row[0]),
                str(row[1]),
                str(row[2]),
                json.loads(row[3]),
                int(row[4]) + 1,
            )
            for row in rows
        )

    def finish_outbox(
        self,
        record_id: int,
        *,
        error: str | None = None,
        tenant_key: str | None = None,
    ) -> None:
        tenant = _tenant_key(tenant_key) if tenant_key is not None else None
        with self.engine.begin() as connection:
            if tenant is not None:
                self._scope(connection, tenant)
            if error is None:
                connection.exec_driver_sql(
                    f"UPDATE {self.prefix}outbox SET delivered_at=%s,last_error=NULL WHERE id=%s",
                    (time.time(), int(record_id)),
                )
            else:
                connection.exec_driver_sql(
                    f"UPDATE {self.prefix}outbox SET available_at=%s,last_error=%s WHERE id=%s",
                    (time.time() + 30, str(error)[:500], int(record_id)),
                )

    def close(self) -> None:
        self.engine.dispose()


class ObjectClientPort(Protocol):
    def put(self, *, key: str, data: bytes, metadata: Mapping[str, str]) -> None: ...
    def get(self, *, key: str) -> tuple[bytes, Mapping[str, str]]: ...
    def has(self, *, key: str) -> bool: ...


class ObjectStorageArtifactAdapter:
    """Digest-verifying object CAS over an injected S3/GCS/Azure-compatible client."""

    def __init__(self, client: ObjectClientPort, *, tenant_key: str) -> None:
        self.client = client
        self.tenant_key = _tenant_key(tenant_key)

    @staticmethod
    def _digest(data: bytes) -> str:
        return "sha256:" + hashlib.sha256(data).hexdigest()

    def _key(self, digest: str) -> str:
        value = digest.removeprefix("sha256:")
        if len(value) != 64 or any(char not in "0123456789abcdef" for char in value):
            raise ValueError("object artifact digest is invalid")
        return f"tenants/{self.tenant_key}/sha256/{value[:2]}/{value}"

    def put(
        self,
        data: bytes | str,
        *,
        media_type: str = "application/octet-stream",
        provenance: Mapping[str, Any] | None = None,
    ) -> ArtifactRef:
        raw = data.encode() if isinstance(data, str) else data
        if not isinstance(raw, bytes):
            raise TypeError("artifact data must be bytes or str")
        digest = self._digest(raw)
        provenance_json = _json(provenance or {})
        provenance_digest = self._digest(provenance_json.encode())
        metadata = {
            "digest": digest,
            "media_type": media_type,
            "provenance_digest": provenance_digest,
            "size": str(len(raw)),
        }
        key = self._key(digest)
        if not self.client.has(key=key):
            self.client.put(key=key, data=raw, metadata=metadata)
        stored, stored_metadata = self.client.get(key=key)
        if self._digest(stored) != digest:
            raise ArtifactIntegrityError("object artifact content digest mismatch")
        if stored_metadata.get("digest") != digest or stored_metadata.get(
            "size"
        ) != str(len(stored)):
            raise ArtifactIntegrityError("object artifact metadata mismatch")
        return ArtifactRef(
            digest=digest,
            size=len(stored),
            media_type=str(stored_metadata.get("media_type", media_type)),
            provenance_digest=str(
                stored_metadata.get("provenance_digest", provenance_digest)
            ),
        )

    def get(self, digest: str) -> bytes:
        raw, metadata = self.client.get(key=self._key(digest))
        if self._digest(raw) != digest or metadata.get("digest") != digest:
            raise ArtifactIntegrityError("object artifact failed digest verification")
        return raw

    def has(self, digest: str) -> bool:
        return self.client.has(key=self._key(digest))
