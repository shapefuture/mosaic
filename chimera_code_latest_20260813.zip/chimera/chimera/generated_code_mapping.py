"""Explicit, byte-bound source-to-generated mapping contracts.

A comment such as ``generated from schema.py`` is discovery text, not an
avigable provenance edge. This module accepts only a typed mapping contract that
names the generator, binds each source/generated span to exact file digests, and
references a separately resolvable producer-evidence artifact.

The mapping is advisory code-intelligence data. It has no authority to generate
files, modify a branch, grant capabilities, or prove semantic equivalence of the
two languages. A stale/tampered/unattested contract is rejected rather than
falling back to a heuristic edge.
"""
from __future__ import annotations

import base64
import hashlib
import json
import pathlib
import re
from typing import Callable, Literal

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


_SHA = re.compile(r"^sha256:[0-9a-f]{64}$")
_ARTIFACT = re.compile(r"^artifact:sha256:[0-9a-f]{64}$")


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class GeneratedMappingError(RuntimeError):
    pass


def _sha(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _path(value: str) -> str:
    result = str(value).replace("\\", "/").removeprefix("./")
    if not result or result.startswith("/") or "\x00" in result:
        raise ValueError("mapping path must be a non-empty relative path")
    if any(part in {"", ".", ".."} for part in pathlib.PurePosixPath(result).parts):
        raise ValueError("mapping path traversal is prohibited")
    return result


def _digest(value: str) -> str:
    if not _SHA.fullmatch(str(value)):
        raise ValueError("digest must be sha256:<64 lowercase hex>")
    return str(value)


class GeneratorManifestEntry(_FrozenModel):
    """One exact file in a generator input or output manifest."""

    path: str
    digest: str
    size: int = Field(ge=0)

    _manifest_path = field_validator("path")(_path)
    _manifest_digest = field_validator("digest")(_digest)


def generator_manifest_digest(entries: tuple[GeneratorManifestEntry, ...]) -> str:
    payload = [entry.model_dump(mode="json") for entry in sorted(entries, key=lambda item: item.path)]
    return _sha(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8"))


class GeneratorProducerAttestation(_FrozenModel):
    """CAS-stored build receipt for a real generator invocation.

    The receipt is local provenance, not a release signature.  Shared/remote
    consumption still requires an independently trusted signature policy.
    """

    schema_version: Literal["chimera.generator-producer-attestation.v1"] = "chimera.generator-producer-attestation.v1"
    generator_id: str = Field(min_length=1, max_length=200)
    generator_version: str = Field(min_length=1, max_length=200)
    generator_binary_digest: str
    generator_arguments: tuple[str, ...]
    generator_command_digest: str
    input_manifest: tuple[GeneratorManifestEntry, ...] = Field(min_length=1)
    input_manifest_digest: str
    output_manifest: tuple[GeneratorManifestEntry, ...] = Field(min_length=1)
    output_manifest_digest: str

    _binary_digest = field_validator("generator_binary_digest")(_digest)
    _command_digest = field_validator("generator_command_digest")(_digest)
    _input_digest = field_validator("input_manifest_digest")(_digest)
    _output_digest = field_validator("output_manifest_digest")(_digest)

    @model_validator(mode="after")
    def _manifests_match(self) -> "GeneratorProducerAttestation":
        if generator_manifest_digest(self.input_manifest) != self.input_manifest_digest:
            raise ValueError("producer input manifest digest does not match its entries")
        if generator_manifest_digest(self.output_manifest) != self.output_manifest_digest:
            raise ValueError("producer output manifest digest does not match its entries")
        command = _sha(json.dumps(list(self.generator_arguments), separators=(",", ":")).encode("utf-8"))
        if command != self.generator_command_digest:
            raise ValueError("producer command digest does not match its arguments")
        return self


class SignedGeneratorProducerAttestation(_FrozenModel):
    """Detached Ed25519 signature over one canonical producer attestation."""

    schema_version: Literal["chimera.signed-generator-attestation.v1"] = "chimera.signed-generator-attestation.v1"
    attestation_digest: str
    algorithm: Literal["ed25519"] = "ed25519"
    key_id: str
    public_key: str
    signing_scope: str
    signature: str

    _attestation_digest = field_validator("attestation_digest")(_digest)

    def signed_payload(self) -> dict[str, str]:
        return self.model_dump(exclude={"signature"}, mode="json")

    def verify(self, *, trusted_key_ids: set[str] | frozenset[str]) -> bool:
        try:
            public_bytes = base64.b64decode(self.public_key, validate=True)
            key_id = "ed25519:" + hashlib.sha256(public_bytes).hexdigest()
            if key_id != self.key_id or self.key_id not in trusted_key_ids:
                return False
            Ed25519PublicKey.from_public_bytes(public_bytes).verify(
                base64.b64decode(self.signature, validate=True),
                json.dumps(self.signed_payload(), sort_keys=True, separators=(",", ":")).encode("utf-8"),
            )
            return True
        except (ValueError, InvalidSignature):
            return False


def generator_attestation_digest(attestation: GeneratorProducerAttestation) -> str:
    payload = json.dumps(attestation.model_dump(mode="json"), sort_keys=True, separators=(",", ":")).encode("utf-8")
    return _sha(payload)


def sign_generator_attestation(attestation: GeneratorProducerAttestation, signer) -> SignedGeneratorProducerAttestation:
    """Sign with an explicitly pinned signer; ephemeral scope is not shareable."""
    if getattr(signer, "scope", "") in {"", "ephemeral-process"}:
        raise ValueError("shared generator attestations require a non-ephemeral signing scope")
    unsigned = {
        "schema_version": "chimera.signed-generator-attestation.v1",
        "attestation_digest": generator_attestation_digest(attestation),
        "algorithm": "ed25519",
        "key_id": str(signer.key_id),
        "public_key": str(signer.public_key),
        "signing_scope": str(signer.scope),
    }
    payload = json.dumps(unsigned, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return SignedGeneratorProducerAttestation(**unsigned, signature=signer.sign(payload))


class SourceRange(_FrozenModel):
    path: str
    start_line: int = Field(ge=0)
    start_character: int = Field(ge=0)
    end_line: int = Field(ge=0)
    end_character: int = Field(ge=0)
    file_digest: str

    _path_check = field_validator("path")(_path)
    _digest_check = field_validator("file_digest")(_digest)

    @model_validator(mode="after")
    def _ordered(self) -> "SourceRange":
        if (self.end_line, self.end_character) < (self.start_line, self.start_character):
            raise ValueError("mapping range end precedes start")
        return self

    def contains(self, *, line: int, character: int) -> bool:
        point = (int(line), int(character))
        return (self.start_line, self.start_character) <= point <= (self.end_line, self.end_character)


class GeneratorIdentity(_FrozenModel):
    generator_id: str = Field(min_length=1, max_length=200)
    generator_version: str = Field(min_length=1, max_length=200)
    generator_command_digest: str
    input_manifest_digest: str
    # v1 fixture contracts omitted these fields.  Real producers set both and
    # therefore require the verifier to load and validate their CAS receipt.
    output_manifest_digest: str | None = None
    generator_binary_digest: str | None = None
    producer_evidence_ref: str
    producer_signature_ref: str | None = None

    _command = field_validator("generator_command_digest")(_digest)
    _input = field_validator("input_manifest_digest")(_digest)

    @field_validator("output_manifest_digest", "generator_binary_digest")
    @classmethod
    def _optional_digest(cls, value: str | None) -> str | None:
        return None if value is None else _digest(value)

    @field_validator("producer_evidence_ref")
    @classmethod
    def _evidence(cls, value: str) -> str:
        if not _ARTIFACT.fullmatch(str(value)):
            raise ValueError("producer evidence must be artifact:sha256:<64 lowercase hex>")
        return str(value)

    @field_validator("producer_signature_ref")
    @classmethod
    def _signature_ref(cls, value: str | None) -> str | None:
        if value is not None and not _ARTIFACT.fullmatch(str(value)):
            raise ValueError("producer signature must be artifact:sha256:<64 lowercase hex>")
        return None if value is None else str(value)


class SourceGeneratedEdge(_FrozenModel):
    id: str = Field(min_length=1, max_length=300)
    source: SourceRange
    generated: SourceRange
    relation: Literal["generates"] = "generates"


class GeneratorMappingContract(_FrozenModel):
    schema_version: Literal["chimera.generated-mapping.v1"] = "chimera.generated-mapping.v1"
    generator: GeneratorIdentity
    edges: tuple[SourceGeneratedEdge, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def _unique_edges(self) -> "GeneratorMappingContract":
        ids = [edge.id for edge in self.edges]
        if len(ids) != len(set(ids)):
            raise ValueError("generated mapping edge ids must be unique")
        return self

    @property
    def digest(self) -> str:
        return _sha(self.model_dump_json().encode("utf-8"))


class MappingVerificationReceipt(_FrozenModel):
    contract_digest: str
    status: Literal["verified", "rejected"]
    evidence_resolved: bool
    producer_attestation_verified: bool = False
    producer_signature_verified: bool = False
    checked_edges: int
    errors: tuple[str, ...] = ()


class GeneratedMappingIndex:
    """Read-only bidirectional queries over a successfully verified contract."""

    def __init__(self, contract: GeneratorMappingContract, receipt: MappingVerificationReceipt):
        if receipt.status != "verified" or receipt.contract_digest != contract.digest:
            raise GeneratedMappingError("mapping index requires an exact verified contract receipt")
        self.contract = contract
        self.receipt = receipt

    def generated_to_source(self, *, path: str, line: int, character: int) -> tuple[SourceRange, ...]:
        selected = _path(path)
        return tuple(edge.source for edge in self.contract.edges if edge.generated.path == selected and edge.generated.contains(line=line, character=character))

    def source_to_generated(self, *, path: str, line: int, character: int) -> tuple[SourceRange, ...]:
        selected = _path(path)
        return tuple(edge.generated for edge in self.contract.edges if edge.source.path == selected and edge.source.contains(line=line, character=character))


class GeneratedMappingVerifier:
    """Verify evidence, manifests, exact bytes, and span bounds before indexing.

    Legacy fixture contracts only prove that an evidence artifact resolves.  A
    real producer sets binary/output-manifest digests; those contracts are
    rejected unless ``evidence_loader`` returns a matching typed attestation.
    """

    def __init__(
        self,
        root: pathlib.Path,
        *,
        evidence_resolver: Callable[[str], bool],
        evidence_loader: Callable[[str], bytes] | None = None,
        signature_loader: Callable[[str], bytes] | None = None,
        trusted_signing_key_ids: set[str] | frozenset[str] = frozenset(),
        require_trusted_signature: bool = False,
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.evidence_resolver = evidence_resolver
        self.evidence_loader = evidence_loader
        self.signature_loader = signature_loader or evidence_loader
        self.trusted_signing_key_ids = frozenset(trusted_signing_key_ids)
        self.require_trusted_signature = bool(require_trusted_signature)

    def verify(self, contract: GeneratorMappingContract) -> MappingVerificationReceipt:
        errors: list[str] = []
        evidence_ok = False
        attestation_ok = False
        signature_ok = False
        try:
            evidence_ok = bool(self.evidence_resolver(contract.generator.producer_evidence_ref))
        except Exception:
            evidence_ok = False
        if not evidence_ok:
            errors.append("producer evidence reference is unresolved")
        requires_attestation = bool(
            contract.generator.output_manifest_digest or contract.generator.generator_binary_digest
        )
        if requires_attestation and evidence_ok:
            attestation_ok = self._check_attestation(contract.generator, errors)
        should_check_signature = self.require_trusted_signature or bool(
            contract.generator.producer_signature_ref and self.trusted_signing_key_ids
        )
        if should_check_signature:
            signature_ok = self._check_signature(contract.generator, errors)
        for edge in contract.edges:
            self._check_range("source", edge.source, errors)
            self._check_range("generated", edge.generated, errors)
        return MappingVerificationReceipt(
            contract_digest=contract.digest,
            status="verified" if not errors else "rejected",
            evidence_resolved=evidence_ok,
            producer_attestation_verified=attestation_ok,
            producer_signature_verified=signature_ok,
            checked_edges=len(contract.edges),
            errors=tuple(dict.fromkeys(errors)),
        )

    def _check_attestation(self, identity: GeneratorIdentity, errors: list[str]) -> bool:
        if self.evidence_loader is None:
            errors.append("typed producer attestation loader is required for this contract")
            return False
        try:
            raw = self.evidence_loader(identity.producer_evidence_ref)
            attestation = GeneratorProducerAttestation.model_validate_json(raw)
        except Exception as exc:
            errors.append(f"producer attestation is invalid: {type(exc).__name__}: {exc}")
            return False
        expected = {
            "generator id": (identity.generator_id, attestation.generator_id),
            "generator version": (identity.generator_version, attestation.generator_version),
            "generator binary digest": (identity.generator_binary_digest, attestation.generator_binary_digest),
            "generator command digest": (identity.generator_command_digest, attestation.generator_command_digest),
            "input manifest digest": (identity.input_manifest_digest, attestation.input_manifest_digest),
            "output manifest digest": (identity.output_manifest_digest, attestation.output_manifest_digest),
        }
        for label, (claimed, observed) in expected.items():
            if claimed != observed:
                errors.append(f"producer attestation {label} mismatch")
        for entry in (*attestation.input_manifest, *attestation.output_manifest):
            candidate = (self.root / entry.path).resolve()
            if not candidate.is_relative_to(self.root) or not candidate.is_file():
                errors.append(f"producer manifest path is missing or escapes mapping root: {entry.path}")
                continue
            data = candidate.read_bytes()
            if len(data) != entry.size or _sha(data) != entry.digest:
                errors.append(f"producer manifest file drifted: {entry.path}")
        return not any(error.startswith("producer attestation") or error.startswith("producer manifest") for error in errors)

    def _check_signature(self, identity: GeneratorIdentity, errors: list[str]) -> bool:
        if identity.producer_signature_ref is None:
            errors.append("trusted producer signature is required for shared mapping use")
            return False
        if self.evidence_loader is None or self.signature_loader is None:
            errors.append("producer attestation and signature loaders are required for shared mapping use")
            return False
        if not self.trusted_signing_key_ids:
            errors.append("no trusted generator signing key ids are configured")
            return False
        try:
            attestation = GeneratorProducerAttestation.model_validate_json(
                self.evidence_loader(identity.producer_evidence_ref)
            )
            signed = SignedGeneratorProducerAttestation.model_validate_json(
                self.signature_loader(identity.producer_signature_ref)
            )
        except Exception as exc:
            errors.append(f"producer signature is invalid: {type(exc).__name__}: {exc}")
            return False
        if signed.attestation_digest != generator_attestation_digest(attestation):
            errors.append("producer signature attestation digest mismatch")
            return False
        if not signed.verify(trusted_key_ids=self.trusted_signing_key_ids):
            errors.append("producer signature is invalid or signed by an untrusted key")
            return False
        return True

    def _check_range(self, role: str, value: SourceRange, errors: list[str]) -> None:
        candidate = (self.root / value.path).resolve()
        if self.root not in candidate.parents or not candidate.is_file():
            errors.append(f"{role} path is missing or escapes mapping root: {value.path}")
            return
        data = candidate.read_bytes()
        if _sha(data) != value.file_digest:
            errors.append(f"{role} file digest drifted: {value.path}")
            return
        lines = data.decode("utf-8", errors="replace").splitlines()
        if value.end_line >= len(lines):
            errors.append(f"{role} range exceeds file lines: {value.path}")
            return
        if value.start_character > len(lines[value.start_line]) or value.end_character > len(lines[value.end_line]):
            errors.append(f"{role} range exceeds line width: {value.path}")


def contract_from_json(path: pathlib.Path) -> GeneratorMappingContract:
    return GeneratorMappingContract.model_validate_json(pathlib.Path(path).read_text(encoding="utf-8"))
