"""Versioned agent release bundles and deterministic drift comparison."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Any, Mapping


@dataclass(frozen=True)
class AgentReleaseBundle:
    policy_hash: str
    prompt_prefix_hash: str
    tool_manifest_hash: str
    context_schema_hash: str
    model_id: str
    provider_adapter: str
    evaluation_set_hash: str

    @property
    def digest(self) -> str:
        raw = json.dumps(asdict(self), sort_keys=True, separators=(",", ":")).encode()
        return "sha256:" + hashlib.sha256(raw).hexdigest()


def compare_release_bundles(current: AgentReleaseBundle, candidate: AgentReleaseBundle) -> dict[str, Any]:
    changed = tuple(key for key in asdict(current) if getattr(current, key) != getattr(candidate, key))
    identity_affecting = tuple(key for key in changed if key in {"policy_hash", "tool_manifest_hash", "context_schema_hash", "model_id", "provider_adapter"})
    return {
        "current": current.digest,
        "candidate": candidate.digest,
        "changed": changed,
        "identity_affecting": identity_affecting,
        "requires_recertification": bool(identity_affecting),
        "reason": "identity-affecting release dimensions changed" if identity_affecting else "only evaluation bundle changed",
    }
