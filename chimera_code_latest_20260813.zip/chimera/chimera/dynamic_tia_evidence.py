"""Promotion-quality accounting for dynamic test-impact campaigns.

This module scores externally executed paired focused/full observations.  It
never runs tests, builds a coverage map, or enables focused verification.  The
receipt makes false negatives, safe fallbacks, selection size, p50/p95 latency,
held-out partitioning, environment variants, stale-map drills, and periodic
full-suite agreement explicit, then routes every pair through DataEvidenceGate.
"""
from __future__ import annotations

import math
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from .data_evidence_gate import (
    DataEvidenceFrame,
    DataEvidenceGate,
    FeatureEvidenceDecision,
    FeatureEvidencePolicy,
    PairedFeatureObservation,
)


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


TIAVariant = Literal[
    "source",
    "environment",
    "dependency",
    "changed-test",
    "fixture",
    "generated-file",
    "static-asset",
    "dynamic-import",
    "subprocess",
    "reflection",
    "stale-map",
]


class DynamicTIAObservation(_FrozenModel):
    case_id: str
    repetition: int = Field(default=0, ge=0)
    partition: Literal["calibration", "held-out"]
    variant: TIAVariant
    selection_mode: Literal["focused-dynamic", "full"]
    map_current: bool
    map_rebuilt: bool = False
    periodic_full_suite_check: bool
    focused_completed: bool
    full_completed: bool
    focused_detected: bool
    full_detected: bool
    focused_failure_ids: tuple[str, ...] = ()
    full_failure_ids: tuple[str, ...] = ()
    focused_duration_ms: float = Field(ge=0)
    full_duration_ms: float = Field(ge=0)
    selected_test_count: int = Field(ge=0)
    full_test_count: int = Field(gt=0)
    protected_floor_passed: bool
    live_or_platform: bool
    evidence_refs: tuple[str, ...] = Field(min_length=1)


class DynamicTIAEvidencePolicy(_FrozenModel):
    feature_id: str = "dynamic-coverage-tia"
    minimum_pairs: int = Field(default=20, ge=2)
    minimum_heldout_cases: int = Field(default=10, ge=1)
    minimum_heldout_recall: float = Field(default=1.0, gt=0, le=1)
    maximum_fallback_frequency: float = Field(default=0.25, ge=0, le=1)
    maximum_p95_focused_to_full_ratio: float = Field(default=0.80, gt=0, le=1)
    minimum_speed_win_rate: float = Field(default=0.70, gt=0.5, le=1)
    minimum_relative_speed_gain: float = Field(default=0.05, ge=0, lt=1)
    required_variants: tuple[TIAVariant, ...] = (
        "source", "environment", "dependency", "changed-test", "fixture",
        "generated-file", "static-asset", "dynamic-import", "subprocess",
        "reflection", "stale-map",
    )


class DynamicTIAEvidenceReport(_FrozenModel):
    observations: int
    heldout_cases: int
    valid_heldout_mutants: int
    heldout_recall: float | None
    false_negatives: int
    fallback_count: int
    fallback_frequency: float | None
    selected_test_count_p50: float | None
    selected_test_count_p95: float | None
    focused_to_full_ratio_p50: float | None
    focused_to_full_ratio_p95: float | None
    variants_observed: tuple[str, ...]
    stale_map_drill_passed: bool
    periodic_full_suite_agreement: bool
    data_evidence_decision: FeatureEvidenceDecision
    accepted_for_manual_review: bool
    automatic_enablement: bool = False
    manual_promotion_required: bool = True
    reasons: tuple[str, ...]


def _percentile(values: list[float], percentile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    rank = max(1, math.ceil(percentile * len(ordered)))
    return ordered[rank - 1]


class DynamicTIAEvidenceEvaluator:
    """Aggregate paired receipts without changing verification policy."""

    def assess(
        self,
        observations: list[DynamicTIAObservation] | tuple[DynamicTIAObservation, ...],
        *,
        frame: DataEvidenceFrame,
        policy: DynamicTIAEvidencePolicy | None = None,
    ) -> DynamicTIAEvidenceReport:
        rows = tuple(observations)
        selected_policy = policy or DynamicTIAEvidencePolicy()
        reasons: list[str] = []
        keys = [(row.case_id, row.repetition) for row in rows]
        if len(keys) != len(set(keys)):
            reasons.append("duplicate case/repetition observation")
        if len(rows) < selected_policy.minimum_pairs:
            reasons.append(f"requires at least {selected_policy.minimum_pairs} paired observations")

        heldout = [row for row in rows if row.partition == "held-out"]
        if len(heldout) < selected_policy.minimum_heldout_cases:
            reasons.append(f"requires at least {selected_policy.minimum_heldout_cases} held-out cases")
        valid_heldout = [row for row in heldout if row.full_completed and row.full_detected]
        false_negatives = [row for row in rows if row.full_completed and row.full_detected and (not row.focused_completed or not row.focused_detected)]
        heldout_false_negatives = [row for row in valid_heldout if not row.focused_completed or not row.focused_detected]
        heldout_recall = (
            1.0 - len(heldout_false_negatives) / len(valid_heldout)
            if valid_heldout else None
        )
        if len(valid_heldout) != len(heldout):
            reasons.append("one or more held-out full suites did not complete and detect the seeded regression")
        if heldout_recall is None or heldout_recall < selected_policy.minimum_heldout_recall:
            reasons.append("held-out mutation recall is below the declared floor")
        if false_negatives:
            reasons.append("at least one full-suite regression was missed by focused selection")

        fallbacks = [row for row in rows if row.selection_mode == "full"]
        fallback_frequency = len(fallbacks) / len(rows) if rows else None
        if fallback_frequency is None or fallback_frequency > selected_policy.maximum_fallback_frequency:
            reasons.append("safe fallback frequency is above the declared speed budget")

        completed = [row for row in rows if row.focused_completed and row.full_completed]
        focused_completed = [row for row in completed if row.selection_mode == "focused-dynamic"]
        # Safe full-suite fallbacks are accounted separately by fallback_frequency;
        # speed percentiles describe only observations where focusing occurred.
        ratios = [row.focused_duration_ms / row.full_duration_ms for row in focused_completed if row.full_duration_ms > 0]
        ratio_p50 = _percentile(ratios, 0.50)
        ratio_p95 = _percentile(ratios, 0.95)
        if ratio_p95 is None or ratio_p95 > selected_policy.maximum_p95_focused_to_full_ratio:
            reasons.append("p95 focused/full duration ratio is above the declared threshold")
        selected_counts = [float(row.selected_test_count) for row in focused_completed]

        variants = tuple(sorted({row.variant for row in rows}))
        missing_variants = sorted(set(selected_policy.required_variants) - set(variants))
        if missing_variants:
            reasons.append("missing required variants: " + ", ".join(missing_variants))
        stale_rows = [row for row in rows if row.variant == "stale-map"]
        stale_passed = bool(stale_rows) and all(
            row.selection_mode == "full" and not row.map_current for row in stale_rows
        )
        if not stale_passed:
            reasons.append("stale-map rebuild/fallback drill did not fail closed")
        agreement = bool(rows) and all(
            row.periodic_full_suite_check
            and row.full_completed
            and row.protected_floor_passed
            and (not row.full_detected or row.focused_detected)
            for row in rows
        )
        if not agreement:
            reasons.append("periodic full-suite/protected-floor agreement is incomplete")

        paired = [PairedFeatureObservation(
            case_id=row.case_id,
            repetition=row.repetition,
            baseline_metric=row.full_duration_ms,
            challenger_metric=row.focused_duration_ms,
            baseline_success=row.full_completed and row.full_detected,
            challenger_success=row.focused_completed and row.focused_detected,
            baseline_safety_ok=row.full_completed and row.protected_floor_passed,
            challenger_safety_ok=row.focused_completed and row.protected_floor_passed,
            baseline_full_tests_ok=row.full_completed,
            challenger_full_tests_ok=row.periodic_full_suite_check and row.full_completed,
            baseline_protected_ok=row.protected_floor_passed,
            challenger_protected_ok=row.protected_floor_passed,
            baseline_unknown=not row.full_completed,
            challenger_unknown=not row.focused_completed,
            evidence_refs=row.evidence_refs,
            live_or_platform=row.live_or_platform,
        ) for row in rows]
        gate_policy = FeatureEvidencePolicy(
            feature_id=selected_policy.feature_id,
            metric_name="focused_verification_duration_ms",
            direction="lower",
            minimum_pairs=selected_policy.minimum_pairs,
            minimum_win_rate=selected_policy.minimum_speed_win_rate,
            minimum_relative_gain=selected_policy.minimum_relative_speed_gain,
            require_live_or_platform_evidence=True,
        )
        decision = DataEvidenceGate().evaluate(
            frame=frame,
            policy=gate_policy,
            observations=paired,
        )
        if not decision.accepted_for_manual_review:
            reasons.append("paired DataEvidenceGate rejected the campaign")
        return DynamicTIAEvidenceReport(
            observations=len(rows),
            heldout_cases=len(heldout),
            valid_heldout_mutants=len(valid_heldout),
            heldout_recall=heldout_recall,
            false_negatives=len(false_negatives),
            fallback_count=len(fallbacks),
            fallback_frequency=fallback_frequency,
            selected_test_count_p50=_percentile(selected_counts, 0.50),
            selected_test_count_p95=_percentile(selected_counts, 0.95),
            focused_to_full_ratio_p50=ratio_p50,
            focused_to_full_ratio_p95=ratio_p95,
            variants_observed=variants,
            stale_map_drill_passed=stale_passed,
            periodic_full_suite_agreement=agreement,
            data_evidence_decision=decision,
            accepted_for_manual_review=not reasons and decision.accepted_for_manual_review,
            reasons=tuple(dict.fromkeys(reasons)),
        )
