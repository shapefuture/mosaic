"""Snapshot-scoped warm LSP session for repeated read-only semantic queries."""
from __future__ import annotations

import pathlib
import threading
import time

from .semantic_code_intelligence import SemanticQueryReceipt, SemanticQueryRequest, WorkspaceSnapshotter
from .semantic_lsp import LSPLaunchSpec, LSPSubprocessLifecycle, LSPSubprocessSemanticAdapter
from .tokenizer import TokenizerMeasurer


class WarmLSPSubprocessSemanticSession:
    """Reuse one server only while every request names the exact same snapshot."""

    def __init__(self, root: pathlib.Path, spec: LSPLaunchSpec, *, snapshotter: WorkspaceSnapshotter | None=None, tokenizer: TokenizerMeasurer | None=None) -> None:
        self.root=pathlib.Path(root).resolve();self.spec=spec;self.adapter_id=spec.adapter_id+"-warm-snapshot-v1"
        self.snapshotter=snapshotter or WorkspaceSnapshotter(self.root)
        self.delegate=LSPSubprocessSemanticAdapter(self.root,spec,snapshotter=self.snapshotter,tokenizer=tokenizer)
        self.lifecycle:LSPSubprocessLifecycle|None=None;self.snapshot_digest:str|None=None;self.opened:set[str]=set();self.lock=threading.RLock()

    def _start(self,request:SemanticQueryRequest,deadline:float)->None:
        self.lifecycle=LSPSubprocessLifecycle(self.root,self.spec);self.lifecycle.__enter__();self.lifecycle.initialize(deadline=deadline);self.snapshot_digest=request.snapshot_digest

    def query(self,request:SemanticQueryRequest)->SemanticQueryReceipt:
        with self.lock:
            started=time.perf_counter();observed=self.snapshotter.capture()
            if observed.digest!=request.snapshot_digest:
                self.close();return self.delegate._receipt(request,observed.digest,started,status="rejected",message="warm LSP request snapshot is stale",stale=True)
            if self.snapshot_digest is not None and self.snapshot_digest!=request.snapshot_digest:
                self.close();return self.delegate._receipt(request,observed.digest,started,status="rejected",message="warm LSP session cannot cross snapshots",stale=True)
            if request.operation=="imports":
                return self.delegate._receipt(request,observed.digest,started,status="unsupported",message="LSP has no portable imports query; use CodeGraph fallback")
            deadline=time.monotonic()+request.timeout_seconds
            try:
                if self.lifecycle is None:self._start(request,deadline)
                assert self.lifecycle is not None and self.lifecycle.rpc is not None
                uri=None
                if request.path is not None:
                    document=(self.root/request.path).resolve()
                    if not document.is_relative_to(self.root) or not document.is_file():
                        return self.delegate._receipt(request,observed.digest,started,status="error",message="query path does not exist")
                    uri=document.as_uri()
                    if request.path not in self.opened:
                        self.lifecycle.rpc.notify("textDocument/didOpen",{"textDocument":{"uri":uri,"languageId":request.language_id or self.delegate._language_id(document),"version":1,"text":document.read_text(encoding="utf-8",errors="replace")}});self.opened.add(request.path)
                raw=self.delegate._query(self.lifecycle.rpc,request,uri,deadline)
                locations=self.delegate._supplement_structural(
                    request,self.delegate._normalize(raw,request,uri)
                )
                projected=self.delegate.projector.project(request,locations)
                final=self.snapshotter.capture()
                if final.digest!=request.snapshot_digest:
                    self.close();return self.delegate._receipt(request,observed.digest,started,status="rejected",message="workspace changed during warm LSP query",stale=True,consumed=final.digest)
                return SemanticQueryReceipt(request_id=request.request_id,operation=request.operation,adapter_id=self.adapter_id,status="completed",requested_snapshot_digest=request.snapshot_digest,observed_snapshot_digest=observed.digest,consumed_snapshot_digest=final.digest,results=projected.results,context=projected.text,token_measurement=projected.measurement,context_budget_satisfied=projected.budget_satisfied,latency_ms=(time.perf_counter()-started)*1000,message="fresh snapshot-scoped warm LSP result")
            except Exception as exc:
                self.close();return self.delegate._receipt(request,observed.digest,started,status="error",message=f"warm LSP failed: {type(exc).__name__}: {exc}")

    def close(self)->None:
        with self.lock:
            if self.lifecycle is not None:self.lifecycle.close(deadline=time.monotonic()+.5)
            self.lifecycle=None;self.snapshot_digest=None;self.opened.clear()

    def __enter__(self):return self
    def __exit__(self,exc_type,exc,tb):self.close()
