"""Append-only gate history for trend/regression tracking."""
from __future__ import annotations

import json
import pathlib
import time
from dataclasses import asdict, dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class GateHistoryEntry:
    schema_version: str
    ts: float
    source_schema: str
    status: str | None
    promotion_allowed: bool | None
    summary: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class GateHistoryLedger:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.path = self.root / ".chimera" / "gate-history.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, payload: Mapping[str, Any], *, source: str | None = None) -> dict[str, Any]:
        source_schema = str(payload.get("schema_version") or source or "unknown")
        entry = GateHistoryEntry(
            schema_version="chimera.gate-history-entry.v1",
            ts=time.time(),
            source_schema=source_schema,
            status=str(payload.get("status")) if payload.get("status") is not None else None,
            promotion_allowed=payload.get("promotion_allowed") if isinstance(payload.get("promotion_allowed"), bool) else None,
            summary=self._summary(payload),
        )
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry.as_dict(), sort_keys=True, default=str) + "\n")
        return entry.as_dict()

    def append_artifact(self, artifact: pathlib.Path) -> dict[str, Any]:
        artifact = pathlib.Path(artifact)
        payload = json.loads(artifact.read_text(encoding="utf-8"))
        entry = self.append(payload, source=str(artifact))
        return {**entry, "artifact": str(artifact)}

    def replay(self, *, limit: int = 100) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        rows = []
        for line in self.path.read_text(encoding="utf-8", errors="replace").splitlines():
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return rows[-max(1, min(10_000, int(limit))):]

    def trends(self, *, limit: int = 100) -> dict[str, Any]:
        rows = self.replay(limit=limit)
        by_schema: dict[str, dict[str, Any]] = {}
        for row in rows:
            schema = str(row.get("source_schema", "unknown"))
            bucket = by_schema.setdefault(schema, {"count": 0, "statuses": {}, "promotion_allowed": 0})
            bucket["count"] += 1
            status = str(row.get("status")) if row.get("status") is not None else "none"
            bucket["statuses"][status] = bucket["statuses"].get(status, 0) + 1
            if row.get("promotion_allowed") is True:
                bucket["promotion_allowed"] += 1
        latest = rows[-1] if rows else None
        return {
            "schema_version": "chimera.gate-history-trends.v1",
            "path": str(self.path),
            "entries": len(rows),
            "latest": latest,
            "by_schema": by_schema,
            "regression_watch": self._regression_watch(rows),
            "promotion_allowed": False,
        }

    @staticmethod
    def _summary(payload: Mapping[str, Any]) -> dict[str, Any]:
        summary: dict[str, Any] = {}
        for key in ("failures", "reviews", "warnings", "blockers", "hidden_failures", "adversarial_failures"):
            value = payload.get(key)
            if isinstance(value, list):
                summary[key + "_count"] = len(value)
        if isinstance(payload.get("findings"), list):
            summary["findings_count"] = len(payload["findings"])
        if isinstance(payload.get("finding_count"), int):
            summary["findings_count"] = payload["finding_count"]
        for key in ("token_error_tax", "total_tokens", "task_count", "agents", "tenants"):
            if key in payload:
                summary[key] = payload[key]
        if isinstance(payload.get("token_error_tax"), dict):
            summary["token_error_tax"] = payload["token_error_tax"].get("token_error_tax")
        return summary

    @staticmethod
    def _regression_watch(rows: list[dict[str, Any]]) -> dict[str, Any]:
        # Lightweight generic detector: latest status is worse than previous for same schema.
        rank = {"pass": 0, "green": 0, "clean": 0, "review": 1, "warning": 1, "blocked": 2, "fail": 2, "failed": 2}
        regressions = []
        last_by_schema: dict[str, dict[str, Any]] = {}
        for row in rows:
            schema = str(row.get("source_schema", "unknown"))
            prev = last_by_schema.get(schema)
            if prev is not None:
                old = rank.get(str(prev.get("status")), 1)
                new = rank.get(str(row.get("status")), 1)
                if new > old:
                    regressions.append({"source_schema": schema, "from": prev.get("status"), "to": row.get("status"), "ts": row.get("ts")})
            last_by_schema[schema] = row
        return {"regression_count": len(regressions), "regressions": regressions[-20:]}
