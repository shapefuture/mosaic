"""Stable, authority-free envelopes for future polyglot Chimera adapters.

These contracts implement P0 of the polyglot plan: an adapter boundary can be
built and mirror-tested before Rust, Zig, or BEAM owns any control-plane state.
They do not start a daemon, open a network listener, select models, retry a
provider call, or grant branch/commit authority.

Secret-bearing bytes are deliberately represented by a CAS reference or a
one-shot descriptor reference, never by a JSON field.  Workspace paths are
relative and traversal-free so a future transport cannot reinterpret an
operation as host-root authority.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


PROTOCOL_VERSION = "chimera.polyglot-contract.v1"
_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ProtocolContractError(ValueError):
    pass


def _relative_path(value: str) -> str:
    path = str(value).replace("\\", "/").removeprefix("./")
    if not path or path.startswith("/") or "\x00" in path:
        raise ValueError("path must be a non-empty relative path")
    parts = pathlib.PurePosixPath(path).parts
    if any(part in {"", ".", ".."} for part in parts):
        raise ValueError("path traversal is not permitted")
    return path


def _digest(value: str) -> str:
    item = str(value)
    if not _DIGEST.fullmatch(item):
        raise ValueError("reference must be sha256:<64 lowercase hex>")
    return item


class ContractEnvelope(_FrozenModel):
    """A typed, hashable payload to exchange across a local IPC/RPC boundary."""

    protocol: Literal["chimera.polyglot-contract.v1"] = PROTOCOL_VERSION
    kind: Literal["vfs", "sandbox-exec", "ledger-append", "provider-call", "session-state"]
    payload: dict[str, object]

    @property
    def digest(self) -> str:
        raw = self.model_dump_json(exclude_none=True, by_alias=False).encode("utf-8")
        return "sha256:" + hashlib.sha256(raw).hexdigest()


class VFSOperation(_FrozenModel):
    """A content-addressed VFS request; writes reference blobs, never embed bytes."""

    operation: Literal["branch-create", "read", "write", "delete", "diff", "materialize", "snapshot", "commit"]
    workspace_snapshot: str
    branch: str = Field(min_length=1, max_length=160)
    path: str | None = None
    content_ref: str | None = None
    expected_digest: str | None = None

    _path = field_validator("path")(lambda value: _relative_path(value) if value is not None else value)
    _snapshot = field_validator("workspace_snapshot")(lambda value: _digest(value))
    _content = field_validator("content_ref")(lambda value: _digest(value) if value is not None else value)
    _expected = field_validator("expected_digest")(lambda value: _digest(value) if value is not None else value)

    def to_envelope(self) -> ContractEnvelope:
        if self.operation == "write" and self.content_ref is None:
            raise ProtocolContractError("VFS write requires a content-addressed blob reference")
        if self.operation in {"read", "write", "delete"} and self.path is None:
            raise ProtocolContractError(f"VFS {self.operation} requires a relative path")
        return ContractEnvelope(kind="vfs", payload=self.model_dump(mode="json"))


class SandboxExecRequest(_FrozenModel):
    """Execution request without environment values, secrets, or ambient cwd."""

    branch_snapshot: str
    argv: tuple[str, ...] = Field(min_length=1, max_length=256)
    timeout_ms: int = Field(gt=0, le=3_600_000)
    env_allow: tuple[str, ...] = ()
    filesystem_policy_ref: str
    network_allowed: bool = False

    _snapshot = field_validator("branch_snapshot")(lambda value: _digest(value))
    _policy = field_validator("filesystem_policy_ref")(lambda value: _digest(value))

    @field_validator("argv")
    @classmethod
    def _argv(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        if any(not item or "\x00" in item for item in value):
            raise ValueError("argv cannot contain empty or NUL-containing items")
        return value

    @field_validator("env_allow")
    @classmethod
    def _env_names(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        if any(not re.fullmatch(r"[A-Z_][A-Z0-9_]*", name) for name in value):
            raise ValueError("env_allow contains an invalid environment variable name")
        return tuple(dict.fromkeys(value))

    def to_envelope(self) -> ContractEnvelope:
        return ContractEnvelope(kind="sandbox-exec", payload=self.model_dump(mode="json"))


class LedgerAppendRequest(_FrozenModel):
    """Optimistic append request; no adapter receives promotion authority."""

    session_id: str = Field(min_length=1, max_length=160)
    expected_sequence: int = Field(ge=0)
    event_kind: str = Field(min_length=1, max_length=120)
    event_ref: str

    _event_ref = field_validator("event_ref")(lambda value: _digest(value))

    def to_envelope(self) -> ContractEnvelope:
        return ContractEnvelope(kind="ledger-append", payload=self.model_dump(mode="json"))


class ProviderCallRequest(_FrozenModel):
    """A provider transport request with explicit model authority and no key field."""

    model: str = Field(min_length=1, max_length=300)
    prompt_ref: str
    max_output_tokens: int = Field(ge=1, le=65_536)
    route_id: str = Field(min_length=1, max_length=160)
    one_shot_credential_descriptor: str | None = None

    _prompt = field_validator("prompt_ref")(lambda value: _digest(value))

    @field_validator("one_shot_credential_descriptor")
    @classmethod
    def _descriptor(cls, value: str | None) -> str | None:
        if value is None:
            return None
        # A descriptor name identifies a host-inherited channel. It cannot carry
        # a credential payload or a file path.
        if not re.fullmatch(r"fd:[0-9]{1,9}", value):
            raise ValueError("credential descriptor must be a bounded fd:<number> reference")
        return value

    def to_envelope(self) -> ContractEnvelope:
        return ContractEnvelope(kind="provider-call", payload=self.model_dump(mode="json"))


class SessionStateProjection(_FrozenModel):
    """Transportable projection, not a replacement for Chimera's WAL authority."""

    session_id: str = Field(min_length=1, max_length=160)
    branch_snapshot: str
    lifecycle: Literal["created", "running", "paused", "completed", "failed", "unknown"]
    evidence_refs: tuple[str, ...] = ()

    _snapshot = field_validator("branch_snapshot")(lambda value: _digest(value))

    @field_validator("evidence_refs")
    @classmethod
    def _evidence(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        return tuple(_digest(item) for item in value)

    def to_envelope(self) -> ContractEnvelope:
        return ContractEnvelope(kind="session-state", payload=self.model_dump(mode="json"))


def verify_envelope(envelope: ContractEnvelope) -> bool:
    """Validate payload shape against its declared kind without executing it."""
    models = {
        "vfs": VFSOperation,
        "sandbox-exec": SandboxExecRequest,
        "ledger-append": LedgerAppendRequest,
        "provider-call": ProviderCallRequest,
        "session-state": SessionStateProjection,
    }
    model = models[envelope.kind]
    value = model.model_validate(envelope.payload)
    # Force operation-specific VFS invariants as well.
    if isinstance(value, VFSOperation):
        value.to_envelope()
    return True
