"""Host-local evidence for materialized and overlay Bubblewrap backends."""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
import time
from typing import Literal

from pydantic import BaseModel, ConfigDict

from .branch import TransactionalWorkspace
from .effects import CapabilitySet
from .sandbox import Sandbox


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class SandboxCertificationReceipt(_FrozenModel):
    schema_version: str = "chimera.sandbox-certification.v1"
    backend: Literal["bubblewrap-materialized"]
    certified: bool
    file_read_status: int
    network_probe_status: int
    network_isolation: bool
    timeout_status: int
    process_group_killed: bool
    created_at: float
    reason: str


class OverlaySandboxCertificationReceipt(_FrozenModel):
    schema_version: str = "chimera.sandbox-overlay-certification.v1"
    backend: Literal["bubblewrap-overlayfs"] = "bubblewrap-overlayfs"
    certified: bool
    changed_file_visible: bool
    new_file_visible: bool
    deletion_masked: bool
    command_write_ephemeral: bool
    host_base_unchanged: bool
    network_isolation: bool
    bwrap_digest: str
    created_at: float
    reason: str


class MaterializedBubblewrapCertifier:
    """Run three bounded local probes; no network destination is contacted."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.path = self.root / ".chimera" / "sandbox-materialized-bwrap-certification.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def run(self) -> SandboxCertificationReceipt:
        probe_root = pathlib.Path(tempfile.mkdtemp(prefix="chimera-bwrap-cert-"))
        try:
            (probe_root / "probe.txt").write_text("sealed", encoding="utf-8")
            sandbox = Sandbox(probe_root, CapabilitySet(fs_allow=["**"]))
            read = sandbox.exec(["/usr/bin/python3", "-c", "from pathlib import Path; print(Path('probe.txt').read_text())"], timeout=10)
            net = sandbox.exec(["/usr/bin/python3", "-c", "import socket; socket.create_connection(('1.1.1.1', 53), timeout=1)"], timeout=10)
            timeout = sandbox.exec(["/usr/bin/python3", "-c", "import time; time.sleep(10)"], timeout=1)
            evidence = dict(read.evidence)
            certified = bool(
                read.status == 0
                and evidence.get("backend") == "bubblewrap"
                and evidence.get("os_isolation") is True
                and net.status != 0
                and net.evidence.get("network_isolation") is True
                and timeout.status == 124
                and timeout.evidence.get("process_group_killed") is True
            )
            receipt = SandboxCertificationReceipt(
                backend="bubblewrap-materialized",
                certified=certified,
                file_read_status=read.status,
                network_probe_status=net.status,
                network_isolation=bool(net.evidence.get("network_isolation")),
                timeout_status=timeout.status,
                process_group_killed=bool(timeout.evidence.get("process_group_killed")),
                created_at=time.time(),
                reason="materialized Bubblewrap FS/network/process timeout probes passed" if certified else "one or more materialized Bubblewrap probes failed",
            )
            temporary = self.path.with_suffix(".tmp")
            temporary.write_text(receipt.model_dump_json(indent=2), encoding="utf-8")
            temporary.replace(self.path)
            return receipt
        finally:
            import shutil
            shutil.rmtree(probe_root, ignore_errors=True)

    def load(self) -> SandboxCertificationReceipt | None:
        if not self.path.exists():
            return None
        try:
            return SandboxCertificationReceipt.model_validate_json(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None


class OverlayBubblewrapCertifier:
    """Certify lower-layer precedence, new files, whiteouts, and ephemeral writes."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.path = self.root / ".chimera" / "sandbox-overlay-bwrap-certification.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def run(self) -> OverlaySandboxCertificationReceipt:
        import shutil
        probe = pathlib.Path(tempfile.mkdtemp(prefix="chimera-bwrap-overlay-cert-"))
        previous_mode = os.environ.get("CHIMERA_SANDBOX_MODE")
        previous_certified = os.environ.get("CHIMERA_BWRAP_OVERLAY_CERTIFIED")
        try:
            (probe / "changed.txt").write_text("base", encoding="utf-8")
            (probe / "deleted.txt").write_text("delete-me", encoding="utf-8")
            workspace = TransactionalWorkspace(probe)
            workspace.branch("overlay-cert")
            workspace.write("overlay-cert", "changed.txt", "branch")
            workspace.write("overlay-cert", "new/path.txt", "new")
            workspace.unlink("overlay-cert", "deleted.txt")
            os.environ["CHIMERA_SANDBOX_MODE"] = "bwrap"
            os.environ["CHIMERA_BWRAP_OVERLAY_CERTIFIED"] = "1"
            sandbox = Sandbox(
                probe,
                CapabilitySet(fs_allow=["./**"], env_allow=["PATH", "PYTHONPATH"]),
                branch="overlay-cert", workspace=workspace,
            )
            script = (
                "from pathlib import Path; "
                "print(Path('changed.txt').read_text()); "
                "print(Path('new/path.txt').read_text()); "
                "print(Path('deleted.txt').exists()); "
                "Path('ephemeral.txt').write_text('temporary')"
            )
            result = sandbox.exec(["/usr/bin/python3", "-c", script], timeout=10)
            lines = result.stdout.splitlines()
            changed = len(lines) >= 1 and lines[0] == "branch"
            new = len(lines) >= 2 and lines[1] == "new"
            deleted = len(lines) >= 3 and lines[2] == "False"
            ephemeral = not (probe / "ephemeral.txt").exists()
            base_unchanged = (
                (probe / "changed.txt").read_text(encoding="utf-8") == "base"
                and (probe / "deleted.txt").read_text(encoding="utf-8") == "delete-me"
            )
            net = sandbox.exec([
                "/usr/bin/python3", "-c",
                "import socket; socket.create_connection(('1.1.1.1', 53), timeout=1)",
            ], timeout=5)
            bwrap = pathlib.Path(shutil.which("bwrap") or "/missing")
            bwrap_digest = "sha256:" + hashlib.sha256(bwrap.read_bytes()).hexdigest() if bwrap.is_file() else "sha256:" + "0" * 64
            certified = bool(
                result.status == 0 and changed and new and deleted and ephemeral and base_unchanged
                and result.evidence.get("bwrap_overlay") is True
                and net.status != 0 and net.evidence.get("network_isolation") is True
            )
            receipt = OverlaySandboxCertificationReceipt(
                certified=certified,
                changed_file_visible=changed,
                new_file_visible=new,
                deletion_masked=deleted,
                command_write_ephemeral=ephemeral,
                host_base_unchanged=base_unchanged,
                network_isolation=bool(net.evidence.get("network_isolation")),
                bwrap_digest=bwrap_digest,
                created_at=time.time(),
                reason="Bubblewrap overlayfs branch/new/whiteout/ephemeral/network probes passed" if certified else "one or more Bubblewrap overlayfs probes failed",
            )
            temporary = self.path.with_suffix(".tmp")
            temporary.write_text(receipt.model_dump_json(indent=2), encoding="utf-8")
            os.replace(temporary, self.path)
            return receipt
        finally:
            if previous_mode is None: os.environ.pop("CHIMERA_SANDBOX_MODE", None)
            else: os.environ["CHIMERA_SANDBOX_MODE"] = previous_mode
            if previous_certified is None: os.environ.pop("CHIMERA_BWRAP_OVERLAY_CERTIFIED", None)
            else: os.environ["CHIMERA_BWRAP_OVERLAY_CERTIFIED"] = previous_certified
            shutil.rmtree(probe, ignore_errors=True)

    def load(self) -> OverlaySandboxCertificationReceipt | None:
        if not self.path.exists():
            return None
        try:
            return OverlaySandboxCertificationReceipt.model_validate_json(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None


class GVisorCertificationReceipt(_FrozenModel):
    schema_version: str = "chimera.sandbox-gvisor-certification.v1"
    backend: Literal["gvisor-ptrace-rootful"] = "gvisor-ptrace-rootful"
    certified: bool
    version: str
    binary_digest: str
    binary_digest_matches_expected: bool
    checksum_sidecar_verified: bool
    network_mode_none: bool
    rootfs_readonly: bool
    host_path_absent: bool
    exit_status: int
    reason: str


class GVisorRootfulCertifier:
    """Run a bounded OCI probe through an explicitly root-required runsc path."""

    def __init__(
        self,
        root: pathlib.Path,
        *,
        runsc: pathlib.Path,
        busybox: pathlib.Path,
        expected_sha256: str,
        checksum_sidecar_verified: bool,
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.runsc = pathlib.Path(runsc).resolve()
        self.busybox = pathlib.Path(busybox).resolve()
        expected = expected_sha256.removeprefix("sha256:").lower()
        if len(expected) != 64 or any(character not in "0123456789abcdef" for character in expected):
            raise ValueError("expected_sha256 must be a SHA-256 hex digest")
        self.expected_binary_digest = "sha256:" + expected
        self.checksum_sidecar_verified = bool(checksum_sidecar_verified)
        self.path = self.root / ".chimera" / "sandbox-gvisor-certification.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _store(self, receipt: GVisorCertificationReceipt) -> None:
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(receipt.model_dump_json(indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, self.path)

    def run(self) -> GVisorCertificationReceipt:
        binary_digest = "sha256:" + hashlib.sha256(self.runsc.read_bytes()).hexdigest()
        digest_matches = binary_digest == self.expected_binary_digest
        if not digest_matches or not self.checksum_sidecar_verified:
            reasons = []
            if not digest_matches:
                reasons.append("runsc SHA-256 did not match the pinned digest")
            if not self.checksum_sidecar_verified:
                reasons.append("runsc checksum sidecar was not verified")
            receipt = GVisorCertificationReceipt(
                certified=False,
                version="not-executed-unverified-binary",
                binary_digest=binary_digest,
                binary_digest_matches_expected=digest_matches,
                checksum_sidecar_verified=self.checksum_sidecar_verified,
                network_mode_none=False,
                rootfs_readonly=False,
                host_path_absent=False,
                exit_status=126,
                reason="; ".join(reasons),
            )
            self._store(receipt)
            return receipt

        probe = pathlib.Path(tempfile.mkdtemp(prefix="chimera-gvisor-cert-"))
        bundle = probe / "bundle"
        rootfs = bundle / "rootfs"
        (rootfs / "bin").mkdir(parents=True)
        shutil.copy2(self.busybox, rootfs / "bin/busybox")
        runtime_root = probe / "runsc-root"
        runtime_root.mkdir()
        script = (
            "test ! -e /host-secret || exit 40; echo host-path-absent; "
            "if touch /rootfs-write-probe 2>/dev/null; then exit 41; fi; "
            "echo rootfs-readonly; "
            "if ip route 2>/dev/null | grep -q '^default'; then exit 42; fi; "
            "echo network-none; echo gvisor-ok"
        )
        config = {
            "ociVersion": "1.0.2",
            "process": {
                "terminal": False,
                "user": {"uid": 0, "gid": 0},
                "args": ["/bin/busybox", "sh", "-c", script],
                "env": ["PATH=/bin"],
                "cwd": "/",
                "noNewPrivileges": True,
            },
            "root": {"path": "rootfs", "readonly": True},
            "hostname": "chimera-gvisor",
            "mounts": [
                {
                    "destination": "/proc",
                    "type": "proc",
                    "source": "proc",
                },
                {
                    "destination": "/dev",
                    "type": "tmpfs",
                    "source": "tmpfs",
                    "options": ["nosuid", "mode=755", "size=65536k"],
                },
                {
                    "destination": "/tmp",
                    "type": "tmpfs",
                    "source": "tmpfs",
                    "options": ["nosuid", "nodev", "mode=1777", "size=65536k"],
                },
            ],
            "linux": {
                "namespaces": [
                    {"type": item}
                    for item in ("pid", "network", "ipc", "uts", "mount")
                ]
            },
        }
        (bundle / "config.json").write_text(json.dumps(config), encoding="utf-8")
        identifier = (
            "chimera-gvisor-"
            + hashlib.sha256(str(probe).encode()).hexdigest()[:12]
        )
        try:
            version = subprocess.check_output(
                [str(self.runsc), "--version"], text=True, timeout=10
            ).splitlines()[0]
            try:
                result = subprocess.run(
                    [
                        "sudo",
                        "-n",
                        str(self.runsc),
                        "--network=none",
                        "--platform=ptrace",
                        f"--root={runtime_root}",
                        "run",
                        f"--bundle={bundle}",
                        identifier,
                    ],
                    text=True,
                    capture_output=True,
                    timeout=30,
                )
                exit_status = result.returncode
                stdout = result.stdout
                stderr = result.stderr
            except subprocess.TimeoutExpired as error:
                exit_status = 124
                stdout = error.stdout or ""
                stderr = error.stderr or "gVisor OCI probe timed out"
                if isinstance(stdout, bytes):
                    stdout = stdout.decode(errors="replace")
                if isinstance(stderr, bytes):
                    stderr = stderr.decode(errors="replace")

            host_absent = exit_status == 0 and "host-path-absent" in stdout
            rootfs_readonly = exit_status == 0 and "rootfs-readonly" in stdout
            network_none = exit_status == 0 and "network-none" in stdout
            certified = bool(
                exit_status == 0
                and "gvisor-ok" in stdout
                and host_absent
                and rootfs_readonly
                and network_none
                and digest_matches
                and self.checksum_sidecar_verified
            )
            receipt = GVisorCertificationReceipt(
                certified=certified,
                version=version,
                binary_digest=binary_digest,
                binary_digest_matches_expected=digest_matches,
                checksum_sidecar_verified=self.checksum_sidecar_verified,
                network_mode_none=network_none,
                rootfs_readonly=rootfs_readonly,
                host_path_absent=host_absent,
                exit_status=exit_status,
                reason=(
                    "checksum-pinned gVisor ptrace OCI isolation probes passed "
                    "with network=none"
                    if certified
                    else "gVisor OCI probe failed: " + stderr[-500:]
                ),
            )
            self._store(receipt)
            return receipt
        finally:
            subprocess.run(
                [
                    "sudo",
                    "-n",
                    str(self.runsc),
                    f"--root={runtime_root}",
                    "delete",
                    "--force",
                    identifier,
                ],
                text=True,
                capture_output=True,
                timeout=10,
                check=False,
            )
            shutil.rmtree(probe, ignore_errors=True)
            if probe.exists():
                subprocess.run(
                    ["sudo", "-n", "rm", "-rf", "--", str(probe)],
                    text=True,
                    capture_output=True,
                    timeout=10,
                    check=False,
                )
