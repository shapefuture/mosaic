"""Unix-domain push socket for the durable branch supervisor."""
from __future__ import annotations

import json
import os
import pathlib
import socketserver
import threading
import time
from typing import Any, Optional

from .supervisor import BranchSupervisor


class SupervisorService:
    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root).resolve()
        self.supervisor = BranchSupervisor(self.root)
        self.socket_path = self.root / ".chimera" / "supervisor" / "service.sock"
        self._server: Optional[socketserver.ThreadingUnixStreamServer] = None
        self._thread: Optional[threading.Thread] = None

    def dispatch(self, request: dict[str, Any]) -> dict[str, Any]:
        op = request.get("op")
        if op == "ping": return {"ok": True, "service": "chimera-supervisor"}
        if op == "list": return {"ok": True, "sessions": [item.model_dump(mode="json") for item in self.supervisor.list()]}
        if op == "status": return {"ok": True, "session": self.supervisor.get(request["session_id"]).model_dump(mode="json")}
        if op == "events": return {"ok": True, "events": self.supervisor.events(request["session_id"], int(request.get("after", 0)))}
        if op == "health": return {"ok": True, "health": self.supervisor.health(request["session_id"], int(request.get("sample_ms", 500)))}
        if op == "send": return {"ok": True, "message": self.supervisor.send(request["session_id"], request.get("message", ""))}
        if op == "stop": return {"ok": True, "session": self.supervisor.stop(request["session_id"], bool(request.get("force"))).model_dump(mode="json")}
        return {"ok": False, "error": f"unknown operation {op}"}

    def start(self) -> pathlib.Path:
        if os.name == "nt": raise RuntimeError("supervisor Unix socket is unavailable on Windows")
        if self._server is not None: return self.socket_path
        if self.socket_path.exists(): self.socket_path.unlink()
        service = self

        class Handler(socketserver.StreamRequestHandler):
            def handle(self):
                line = self.rfile.readline()
                if not line: return
                try: request = json.loads(line)
                except Exception as exc:
                    self.wfile.write((json.dumps({"ok": False, "error": str(exc)}) + "\n").encode()); return
                if request.get("op") != "subscribe":
                    self.wfile.write((json.dumps(service.dispatch(request), default=str) + "\n").encode())
                    self.wfile.flush(); return
                session_id = request.get("session_id")
                after = int(request.get("after", 0))
                timeout = min(3600.0, max(0.1, float(request.get("timeout", 60))))
                deadline = time.monotonic() + timeout
                while time.monotonic() < deadline:
                    events = service.supervisor.events(session_id, after)
                    for event in events:
                        self.wfile.write((json.dumps({"ok": True, "event": event, "index": after}) + "\n").encode())
                        self.wfile.flush(); after += 1
                    session = service.supervisor.get(session_id)
                    if session.status not in {"starting", "running"}:
                        self.wfile.write((json.dumps({"ok": True, "terminal": session.status, "after": after}) + "\n").encode())
                        self.wfile.flush(); return
                    time.sleep(0.1)
                self.wfile.write((json.dumps({"ok": True, "heartbeat": True, "after": after}) + "\n").encode())
                self.wfile.flush()

        class Server(socketserver.ThreadingUnixStreamServer):
            daemon_threads = True

        self._server = Server(str(self.socket_path), Handler)
        os.chmod(self.socket_path, 0o600)
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        return self.socket_path

    def stop(self) -> None:
        if self._server is not None:
            self._server.shutdown(); self._server.server_close(); self._server = None
        if self._thread is not None:
            self._thread.join(timeout=2); self._thread = None
        if self.socket_path.exists(): self.socket_path.unlink()


def serve(root: pathlib.Path) -> None:
    service = SupervisorService(root)
    service.start()
    try:
        while True: time.sleep(3600)
    except KeyboardInterrupt:
        pass
    finally:
        service.stop()
