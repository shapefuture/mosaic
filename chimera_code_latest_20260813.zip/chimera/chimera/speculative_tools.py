"""Gated one-step speculative tool execution.

This is deliberately conservative: it mines observed tool_trace transitions,
executes at most one predicted read-only/cheap successor through a caller-supplied
executor, and disables itself when gate-effectiveness telemetry shows grader vs
held-out divergence.  It is a coordination primitive, not a background queue.
"""
from __future__ import annotations

from dataclasses import dataclass
import pathlib
from typing import Any, Callable, Iterable

from .wal import WAL


@dataclass(frozen=True)
class ToolPattern:
    before: str
    after: str
    count: int
    confidence: float


@dataclass(frozen=True)
class SpeculationResult:
    predicted_tool: str | None
    executed: bool
    accepted: bool
    reason: str
    observation: Any = None


class SpeculativeToolExecutor:
    def __init__(self, root: pathlib.Path, *, min_count: int = 3, min_confidence: float = 0.7) -> None:
        self.root = pathlib.Path(root).resolve()
        self.wal = WAL(self.root)
        self.min_count = max(1, int(min_count))
        self.min_confidence = max(0.0, min(1.0, float(min_confidence)))
        self.predictions = 0
        self.hits = 0
        self.discards = 0

    def mine_patterns(self, rows: Iterable[dict[str, Any]] | None = None) -> tuple[ToolPattern, ...]:
        if rows is None:
            rows = [entry.get("data", {}) for entry in self.wal.replay(kind="tool_trace")]
        ordered = [row for row in rows if isinstance(row, dict) and row.get("tool")]
        transitions: dict[tuple[str, str], int] = {}
        totals: dict[str, int] = {}
        for left, right in zip(ordered, ordered[1:]):
            if left.get("run_id") != right.get("run_id"):
                continue
            before, after = str(left.get("tool")), str(right.get("tool"))
            transitions[(before, after)] = transitions.get((before, after), 0) + 1
            totals[before] = totals.get(before, 0) + 1
        patterns = []
        for (before, after), count in sorted(transitions.items()):
            confidence = count / max(1, totals.get(before, 0))
            if count >= self.min_count and confidence >= self.min_confidence:
                patterns.append(ToolPattern(before, after, count, confidence))
        return tuple(patterns)

    def gate_has_headroom(self) -> bool:
        entries = [entry.get("data", {}) for entry in self.wal.replay(kind="gate_dual_pass")]
        scored = [entry for entry in entries if entry.get("held_out_pass") is not None]
        if len(scored) < 10:
            return True
        grader = sum(1 for entry in scored if entry.get("grader_pass")) / len(scored)
        heldout = sum(1 for entry in scored if entry.get("held_out_pass")) / len(scored)
        return (grader - heldout) <= 0.15

    def predict_next(self, current_tool: str, rows: Iterable[dict[str, Any]] | None = None) -> ToolPattern | None:
        candidates = [pattern for pattern in self.mine_patterns(rows) if pattern.before == current_tool]
        return max(candidates, key=lambda item: (item.confidence, item.count, item.after), default=None)

    def speculate_one_step(
        self,
        current_tool: str,
        executor: Callable[[str], Any],
        *,
        rows: Iterable[dict[str, Any]] | None = None,
    ) -> SpeculationResult:
        if not self.gate_has_headroom():
            self.discards += 1
            return SpeculationResult(None, False, False, "verification pressure too high")
        pattern = self.predict_next(current_tool, rows)
        if pattern is None:
            self.discards += 1
            return SpeculationResult(None, False, False, "no stable one-step pattern")
        self.predictions += 1
        observation = executor(pattern.after)
        self.hits += 1
        return SpeculationResult(pattern.after, True, True, "stable one-step pattern", observation)

    def stats(self) -> dict[str, float | int]:
        total = self.predictions + self.discards
        return {"predictions": self.predictions, "hits": self.hits, "discards": self.discards, "positive_ev": self.hits > self.discards, "hit_rate": (self.hits / self.predictions if self.predictions else 0.0)}
