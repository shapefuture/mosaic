"""Pass-to-pass / fail-to-pass outcome ledger for coding patches."""
from __future__ import annotations
import hashlib,json,pathlib,time
from .wal import WAL, wal_write
class RegressionLedger:
 def __init__(self,root:pathlib.Path):self.wal=WAL(pathlib.Path(root))
 def record(self,diff:dict,baseline:int|None,post:int,scope:dict)->dict:
  paths=tuple(sorted(str(x.get('path')) for x in diff.get('ops',[]) if x.get('path')));kind='F2P' if baseline not in (0,None) and post==0 else 'P2P' if baseline==0 and post==0 else 'regression' if baseline==0 and post!=0 else 'unclassified';row={'id':'reg:'+hashlib.sha256(json.dumps([paths,baseline,post],sort_keys=True).encode()).hexdigest()[:16],'paths':paths,'baseline_status':baseline,'post_status':post,'kind':kind,'scope':scope,'at':time.time()};wal_write(self.wal, 'regression_outcome',row);return row
