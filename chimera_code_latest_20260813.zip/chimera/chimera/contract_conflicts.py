"""Deterministic detection of directly contradictory Python test assertions."""
from __future__ import annotations

import ast
from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True)
class ContractConflict:
    path: str
    expression: str
    first_value: str
    second_value: str
    first_line: int
    second_line: int


class ContractConflictDetector:
    """Find exact same-expression equality assertions with conflicting literals.

    This is intentionally narrow. It detects indisputable contradictions and
    does not attempt to infer semantic inconsistency from arbitrary Python.
    """

    @staticmethod
    def detect(tests: Mapping[str, str]) -> tuple[ContractConflict, ...]:
        seen: dict[tuple[str, str], tuple[str, int]] = {}
        output: list[ContractConflict] = []
        for path, source in sorted(tests.items()):
            try:
                tree = ast.parse(source, filename=path)
            except SyntaxError:
                continue
            for node in ast.walk(tree):
                if not isinstance(node, ast.Assert) or not isinstance(node.test, ast.Compare):
                    continue
                test = node.test
                if len(test.ops) != 1 or not isinstance(test.ops[0], ast.Eq) or len(test.comparators) != 1:
                    continue
                right = test.comparators[0]
                if not isinstance(right, ast.Constant) or isinstance(right.value, (dict, list, set)):
                    continue
                expression = ast.dump(test.left, include_attributes=False)
                value = repr(right.value)
                key = (path, expression)
                prior = seen.get(key)
                if prior is not None and prior[0] != value:
                    output.append(ContractConflict(path, ast.unparse(test.left), prior[0], value, prior[1], node.lineno))
                else:
                    seen[key] = (value, node.lineno)
        return tuple(output)
