"""Graph-related Chimera CLI commands.

Kept out of ``chimera.cli`` so the top-level CLI file only owns command wiring
and cross-command helpers.
"""
from __future__ import annotations

import json
import pathlib
import sys
import time

import click
from rich.json import JSON


def register(main: click.Group, *, console, cli_root) -> None:
    _cli_root = cli_root

    @main.group()
    def graph():
        """Code graph commands"""
        pass

    @graph.command("build")
    @click.argument("dir", default=".")
    @click.option("--watch", is_flag=True, help="watch mode")
    def graph_build(dir, watch):
        from .graph import CodeGraph
        selected = pathlib.Path(dir).resolve() if dir != "." else _cli_root()
        g=CodeGraph(selected)
        console.print(f"[cyan]Building code graph for {dir}...[/cyan]")
        start=time.time()
        graph_data=g.build(dir)
        dur=int((time.time()-start)*1000)
        meta=graph_data.get("meta",{})
        console.print(f"[green]Graph built: {meta.get('node_count',0)} nodes, {meta.get('edge_count',0)} edges, {meta.get('files',0)} files in {dur}ms[/green]")
        console.print(JSON(json.dumps(meta, indent=2)))
        if watch:
            console.print("[yellow]Watch mode: press Ctrl+C to exit[/yellow]")
            try:
                import time as t
                last_mtime=0
                while True:
                    t.sleep(2)
                    # naive mtime check
                    cur=max((p.stat().st_mtime for p in selected.rglob("*") if p.is_file()), default=0)
                    if cur>last_mtime:
                        last_mtime=cur
                        g.build(dir)
                        console.print("[green]Graph updated[/green]")
            except KeyboardInterrupt:
                console.print("watch stopped")

    @graph.command("query")
    @click.argument("q")
    @click.option("--limit", default=10)
    @click.option("--cypher", is_flag=True, help="treat query as Cypher")
    @click.option("--godel", is_flag=True, help="treat query as Gödel/Datalog (CodeFuse-Query)")
    @click.option("--wire-format", type=click.Choice(["json", "gcf", "auto"]), default="json")
    def graph_query(q, limit, cypher, godel, wire_format):
        from .graph import CodeGraph
        g=CodeGraph(_cli_root())
        if cypher or godel:
            g.load()
        def emit(items):
            if wire_format == "json":
                console.print(JSON(json.dumps(items, indent=2)))
            else:
                from .wire import WireCodec
                envelope = WireCodec().encode_graph(items, tool="graph.query", mode=wire_format)
                click.echo(envelope.model_text(), nl=False)
                console.print(f"[dim]wire={envelope.format} reduction={envelope.reduction:.1%}[/dim]")
        if godel:
            hits=g.godel_query(q)
            console.print(f"[cyan]Gödel: {q}[/cyan] -> {len(hits)} hits (COREF->Soufflé monotonic)")
            emit(hits[:limit])
        elif cypher:
            hits=g.query_cypher(q)
            console.print(f"[cyan]Cypher: {q}[/cyan] -> {len(hits)} hits")
            emit(hits[:limit])
        else:
            hits=g.search(q, limit=limit)
            if not hits:
                console.print(f"[yellow]No hits for '{q}' — try --cypher/--godel or broader term. Graph has {len(g.graph.get('nodes',[]))} nodes[/yellow]")
            else:
                console.print(f"[green]{len(hits)} hits for '{q}' (measured BM25 + structural expansion)[/green]")
            emit(hits)

    @graph.command("godel")
    @click.argument("q")
    @click.option("--limit", default=10)
    def graph_godel(q, limit):
        from .graph import CodeGraph
        g=CodeGraph(_cli_root())
        g.load()
        hits=g.godel_query(q)
        console.print(f"[cyan]Gödel (CodeFuse-Query): {q}[/cyan]")
        console.print(JSON(json.dumps(hits[:limit], indent=2)))

    @graph.command("ranger")
    @click.argument("q")
    @click.option("--limit", default=10)
    def graph_ranger(q, limit):
        from .graph import CodeGraph
        g=CodeGraph(_cli_root())
        g.load()
        hits=g.ranger_search(q, limit=limit)
        console.print(f"[cyan]RANGER 2509.25257: {q}[/cyan] -> {len(hits)} hits (entity-Cypher vs NL-MCTS router)")
        console.print(JSON(json.dumps(hits[:limit], indent=2)))

    @graph.command("serve")
    def graph_serve():
        """Serve snapshot-checked graph queries on a private Unix socket."""
        from .graph_daemon import GraphDaemon
        daemon = GraphDaemon(_cli_root())
        console.print(
            f"[cyan]Graph daemon listening on {daemon.socket_path}[/cyan]",
            file=sys.stderr,
        )
        daemon.serve_forever()


    @graph.command("watch")
    def graph_watch():
        from .graph import CodeGraph
        g=CodeGraph(_cli_root())
        g.load()
        console.print("[yellow]Watch mode (InfiGraph): polling for changes, incremental update --diff[/yellow]")
        console.print("[dim]Press Ctrl+C to exit[/dim]")
        try:
            g.watch(callback=lambda rel: console.print(f"[green]Updated: {rel}[/green]"))
        except KeyboardInterrupt:
            console.print("watch stopped")

