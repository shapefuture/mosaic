"""Learned shrink-only effective context ceilings per model alias."""
from __future__ import annotations

import json, pathlib, os, time
from dataclasses import dataclass, asdict

@dataclass(frozen=True)
class ContextCeilingObservation:
    model: str
    configured: int
    effective: int
    updated: bool
    reason: str
    def as_dict(self): return asdict(self)

class ObservedContextCeilings:
    def __init__(self, root: pathlib.Path):
        self.path=pathlib.Path(root)/".chimera"/"context-ceilings.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
    def _read(self)->dict[str,int]:
        try: return {str(k): int(v) for k,v in json.loads(self.path.read_text()).items()}
        except Exception: return {}
    def _write(self, rows:dict[str,int])->None:
        tmp=self.path.with_suffix('.tmp'); tmp.write_text(json.dumps(rows,sort_keys=True)+"\n"); os.replace(tmp,self.path)
    def effective(self, model:str, configured:int)->int:
        rows=self._read(); return min(int(configured), rows.get(model, int(configured)))
    def observe_overflow(self, model:str, estimated_tokens:int, configured:int, *, safety_ratio:float=.9, status_code:int|None=None)->ContextCeilingObservation:
        # Bare 413 is context overflow only when local estimate corroborates it.
        if status_code == 413 and estimated_tokens < int(configured)*0.75:
            return ContextCeilingObservation(model, configured, self.effective(model, configured), False, "413 treated as payload limit; estimate too small for context overflow")
        new=max(1, int(estimated_tokens * float(safety_ratio)))
        rows=self._read(); prior=rows.get(model, int(configured)); eff=min(prior, new, int(configured)); updated=eff < prior
        if updated: rows[model]=eff; self._write(rows)
        return ContextCeilingObservation(model, configured, eff, updated, "shrink-only overflow observation")
