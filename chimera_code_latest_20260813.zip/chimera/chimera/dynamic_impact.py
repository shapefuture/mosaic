"""Coverage-backed advisory test impact selection.

A collector external to this module must supply an execution map. The selector
fails safe to the full suite whenever the source/test/environment fingerprint is
missing, stale, corrupt, or does not cover a changed path. It never replaces
full-suite promotion verification.
"""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
import pathlib
import platform
import re
import sys
import time
from typing import Mapping

from pydantic import BaseModel, ConfigDict, Field

from .impact import ImpactScope


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class DynamicDependencyTrace(_FrozenModel):
    schema_version: str = "chimera.dynamic-dependency-trace.v1"
    test_to_paths: dict[str, tuple[str, ...]]
    evidence_ref: str


class DynamicImpactMap(_FrozenModel):
    schema_version: str = "chimera.dynamic-impact-map.v1"
    source_fingerprint: str
    source_file_hashes: dict[str, str]
    # New collectors bind dependency manifests, fixtures, generated files, and
    # static assets too. Empty means a legacy map and is retained only for local
    # compatibility; promotion evidence can require this field explicitly.
    workspace_file_hashes: dict[str, str] = Field(default_factory=dict)
    workspace_fingerprint: str | None = None
    test_fingerprint: str
    environment_fingerprint: str
    test_to_paths: dict[str, tuple[str, ...]]
    dependency_trace_digest: str | None = None
    collected_at: float
    evidence_ref: str


class DynamicImpactSelection(_FrozenModel):
    command: str
    mode: str
    selected_tests: tuple[str, ...]
    reason: str
    map_current: bool
    advisory_only: bool = True


class DynamicImpactStore:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.path = self.root / ".chimera" / "dynamic-impact-map.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def file_hashes(root: pathlib.Path, *, include_tests: bool) -> dict[str, str]:
        base = pathlib.Path(root).resolve()
        rows: dict[str, str] = {}
        for path in sorted(base.rglob("*.py")):
            rel = path.relative_to(base)
            is_test = rel.parts and rel.parts[0] == "tests"
            if is_test != include_tests:
                continue
            if any(part.startswith(".") or part in {"__pycache__", "node_modules", "build", "dist"} for part in rel.parts):
                continue
            rows[rel.as_posix()] = "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()
        return rows

    @classmethod
    def fingerprint(cls, root: pathlib.Path, *, include_tests: bool) -> str:
        rows = cls.file_hashes(root, include_tests=include_tests)
        return "sha256:" + hashlib.sha256(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

    @staticmethod
    def workspace_file_hashes(root: pathlib.Path) -> dict[str, str]:
        """Bind non-runtime project inputs beyond importable Python sources."""
        base = pathlib.Path(root).resolve()
        ignored_parts = {
            ".git", ".chimera", ".pytest_cache", ".mypy_cache", ".ruff_cache",
            "__pycache__", "node_modules", "build", "dist", "coverage", "target", "out",
        }
        ignored_files = {".coverage", ".testmondata"}
        rows: dict[str, str] = {}
        for path in sorted(base.rglob("*")):
            relative = path.relative_to(base)
            if any(part in ignored_parts for part in relative.parts):
                continue
            if path.name in ignored_files or path.name.endswith((".pyc", ".pyo")):
                continue
            try:
                if path.is_symlink():
                    data = os.readlink(path).encode("utf-8", errors="surrogateescape")
                elif path.is_file():
                    data = path.read_bytes()
                else:
                    continue
            except OSError:
                continue
            rows[relative.as_posix()] = "sha256:" + hashlib.sha256(data).hexdigest()
        return rows

    @classmethod
    def workspace_fingerprint_for(cls, root: pathlib.Path) -> str:
        rows = cls.workspace_file_hashes(root)
        return "sha256:" + hashlib.sha256(
            json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()

    @staticmethod
    def environment_fingerprint() -> str:
        distributions = {}
        for name in (
            "click", "httpx", "pydantic", "rich", "gcf-python", "cryptography",
            "pytest", "coverage", "pytest-xdist", "pytest-testmon",
        ):
            try:
                distributions[name] = importlib.metadata.version(name)
            except importlib.metadata.PackageNotFoundError:
                distributions[name] = None
        declared_environment = {}
        for key in sorted(filter(None, (item.strip() for item in os.environ.get("CHIMERA_TIA_ENV_KEYS", "").split(",")))):
            if not re.fullmatch(r"[A-Z][A-Z0-9_]{0,127}", key):
                continue
            raw = os.environ.get(key)
            declared_environment[key] = None if raw is None else "sha256:" + hashlib.sha256(raw.encode()).hexdigest()
        value = {
            "python": tuple(sys.version_info[:3]),
            "implementation": sys.implementation.name,
            "cache_tag": sys.implementation.cache_tag,
            "os": os.name,
            "platform_system": platform.system(),
            "platform_machine": platform.machine(),
            "pytest_addopts": os.environ.get("PYTEST_ADDOPTS", ""),
            "pythonhashseed": os.environ.get("PYTHONHASHSEED", ""),
            "declared_environment": declared_environment,
            "distributions": distributions,
        }
        return "sha256:" + hashlib.sha256(json.dumps(value, sort_keys=True, default=str).encode()).hexdigest()

    def save(self, value: DynamicImpactMap) -> None:
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(value.model_dump_json(indent=2), encoding="utf-8")
        os.replace(temporary, self.path)

    def load(self) -> DynamicImpactMap | None:
        if not self.path.exists():
            return None
        try:
            return DynamicImpactMap.model_validate_json(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None


class DynamicCoverageCollector:
    """Convert Coverage.py dynamic test contexts into a branch-local map."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.store = DynamicImpactStore(self.root)

    def collect(
        self,
        coverage_file: pathlib.Path,
        *,
        evidence_ref: str,
        dependency_trace_file: pathlib.Path | None = None,
    ) -> DynamicImpactMap:
        if not evidence_ref:
            raise ValueError("dynamic coverage collection requires an evidence reference")
        try:
            from coverage import CoverageData
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError("coverage.py is required for dynamic impact collection") from exc
        data = CoverageData(basename=str(coverage_file))
        data.read()
        mapping: dict[str, set[str]] = {}
        contexts = sorted(data.measured_contexts())
        for context in contexts:
            if "::" not in context or not context.endswith("|run"):
                continue
            test = context.split("::", 1)[0]
            # CoverageData treats query contexts as regular expressions. Test
            # parametrization may put brackets, parentheses, or other regex
            # metacharacters in a node id; escape the observed literal before
            # selecting its executed-file set.
            data.set_query_contexts([re.escape(context)])
            for raw_path in data.measured_files():
                path = pathlib.Path(raw_path)
                try:
                    relative = path.resolve().relative_to(self.root).as_posix()
                except ValueError:
                    continue
                if relative.startswith("tests/") or not data.lines(raw_path):
                    continue
                mapping.setdefault(test, set()).add(relative)
        dependency_trace_digest = None
        if dependency_trace_file is not None:
            trace_path = pathlib.Path(dependency_trace_file)
            trace_bytes = trace_path.read_bytes()
            trace = DynamicDependencyTrace.model_validate_json(trace_bytes)
            dependency_trace_digest = "sha256:" + hashlib.sha256(trace_bytes).hexdigest()
            for test, paths in trace.test_to_paths.items():
                normalized_test = str(test).replace("\\", "/").split("::", 1)[0]
                if not normalized_test.startswith("tests/") or not (self.root / normalized_test).is_file():
                    raise ValueError(f"dependency trace test is not a workspace test: {test}")
                for raw in paths:
                    relative = str(raw).replace("\\", "/").removeprefix("./")
                    candidate = (self.root / relative).resolve()
                    if not candidate.is_relative_to(self.root) or not candidate.is_file():
                        raise ValueError(f"dependency trace path is missing or escapes workspace: {raw}")
                    mapping.setdefault(normalized_test, set()).add(relative)
        workspace_hashes = self.store.workspace_file_hashes(self.root)
        value = DynamicImpactMap(
            source_fingerprint=self.store.fingerprint(self.root, include_tests=False),
            source_file_hashes=self.store.file_hashes(self.root, include_tests=False),
            workspace_file_hashes=workspace_hashes,
            workspace_fingerprint="sha256:" + hashlib.sha256(
                json.dumps(workspace_hashes, sort_keys=True, separators=(",", ":")).encode()
            ).hexdigest(),
            test_fingerprint=self.store.fingerprint(self.root, include_tests=True),
            environment_fingerprint=self.store.environment_fingerprint(),
            test_to_paths={test: tuple(sorted(paths)) for test, paths in sorted(mapping.items())},
            dependency_trace_digest=dependency_trace_digest,
            collected_at=time.time(),
            evidence_ref=evidence_ref,
        )
        self.store.save(value)
        return value


class DynamicImpactSelector:
    def __init__(self, root: pathlib.Path, *, constitutional_tests: tuple[str, ...] = ("tests/test_audit.py",)):
        self.root = pathlib.Path(root).resolve()
        self.store = DynamicImpactStore(self.root)
        self.constitutional_tests = constitutional_tests

    def select(self, changed_paths: tuple[str, ...] | list[str]) -> DynamicImpactSelection:
        mapping = self.store.load()
        normalized = tuple(sorted(set(str(path).replace("\\", "/").removeprefix("./") for path in changed_paths)))
        if not mapping:
            return self._full("no dynamic coverage map", False)
        tests = self.store.fingerprint(self.root, include_tests=True)
        environment = self.store.environment_fingerprint()
        if (mapping.test_fingerprint, mapping.environment_fingerprint) != (tests, environment):
            return self._full("dynamic coverage map is stale for tests or environment", False)
        current_hashes = self.store.file_hashes(self.root, include_tests=False)
        changed_set = set(normalized)
        drift = {
            path for path in set(current_hashes) | set(mapping.source_file_hashes)
            if current_hashes.get(path) != mapping.source_file_hashes.get(path)
        }
        if not drift.issubset(changed_set):
            return self._full("dynamic coverage map has unclaimed source drift: " + ", ".join(sorted(drift - changed_set)), False)
        if mapping.workspace_file_hashes:
            declared_fingerprint = "sha256:" + hashlib.sha256(
                json.dumps(mapping.workspace_file_hashes, sort_keys=True, separators=(",", ":")).encode()
            ).hexdigest()
            if mapping.workspace_fingerprint != declared_fingerprint:
                return self._full("dynamic coverage map workspace manifest is corrupt", False)
            current_workspace = self.store.workspace_file_hashes(self.root)
            workspace_drift = {
                path for path in set(current_workspace) | set(mapping.workspace_file_hashes)
                if current_workspace.get(path) != mapping.workspace_file_hashes.get(path)
            }
            if not workspace_drift.issubset(changed_set):
                return self._full(
                    "dynamic coverage map has unclaimed dependency/static/generated drift: "
                    + ", ".join(sorted(workspace_drift - changed_set)),
                    False,
                )
        selected = set(path for path in self.constitutional_tests if (self.root / path).exists())
        uncovered = []
        for changed in normalized:
            impacted = {test for test, paths in mapping.test_to_paths.items() if changed in paths}
            if not impacted:
                uncovered.append(changed)
            selected.update(impacted)
        if uncovered:
            return self._full("dynamic coverage map has no impacted tests for: " + ", ".join(uncovered), True)
        ordered = tuple(sorted(selected))
        return DynamicImpactSelection(
            command="pytest -q " + " ".join(ordered),
            mode="focused-dynamic",
            selected_tests=ordered,
            reason="coverage-backed impacted tests plus constitutional floor",
            map_current=True,
        )

    def _full(self, reason: str, current: bool) -> DynamicImpactSelection:
        return DynamicImpactSelection(
            command="pytest -q",
            mode="full",
            selected_tests=(),
            reason=reason,
            map_current=current,
        )
