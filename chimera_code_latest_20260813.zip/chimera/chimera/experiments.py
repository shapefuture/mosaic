"""Budgeted hedging and read-only counterfactual shadow experiments."""
from __future__ import annotations

import concurrent.futures
import hashlib
import json
import random
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Literal, Optional

from .action_ir import ActionIR, Reversibility


@dataclass(frozen=True)
class HedgeReceipt:
    winner: str
    duration_ms: float
    hedge_started: bool
    loser_cancelled_before_start: bool
    pessimistic_cost: float
    result: Any


class HedgedRequester:
    """Interactive-only hedging with pessimistic double-cost accounting."""

    def __init__(self, *, global_extra_cost_budget: float, trigger_delay_ms: float) -> None:
        self.budget = max(0.0, global_extra_cost_budget)
        self.trigger_delay_ms = max(0.0, trigger_delay_ms)
        self.extra_cost_spent = 0.0
        self._lock = threading.Lock()

    def request(
        self,
        primary: Callable[[], Any],
        secondary: Callable[[], Any],
        *,
        primary_max_cost: float,
        secondary_max_cost: float,
        workload: Literal["interactive", "background"],
    ) -> HedgeReceipt:
        if workload != "interactive":
            raise PermissionError("hedging is structurally disabled for background work")
        with self._lock:
            if self.extra_cost_spent + secondary_max_cost > self.budget:
                raise PermissionError("global hedge extra-cost budget exhausted")
            self.extra_cost_spent += secondary_max_cost
        started = time.perf_counter()
        pool = concurrent.futures.ThreadPoolExecutor(max_workers=2)
        try:
            first = pool.submit(primary)
            try:
                value = first.result(timeout=self.trigger_delay_ms / 1000)
                return HedgeReceipt(
                    winner="primary", duration_ms=(time.perf_counter() - started) * 1000,
                    hedge_started=False, loser_cancelled_before_start=True,
                    pessimistic_cost=primary_max_cost, result=value,
                )
            except concurrent.futures.TimeoutError:
                pass
            second = pool.submit(secondary)
            done, pending = concurrent.futures.wait(
                {first, second}, return_when=concurrent.futures.FIRST_COMPLETED
            )
            winner_future = next(iter(done))
            winner = "primary" if winner_future is first else "secondary"
            value = winner_future.result()
            loser = second if winner_future is first else first
            cancelled = loser.cancel()
            # Client cancellation does not prove provider billing stopped.
            return HedgeReceipt(
                winner=winner, duration_ms=(time.perf_counter() - started) * 1000,
                hedge_started=True, loser_cancelled_before_start=cancelled,
                pessimistic_cost=primary_max_cost + secondary_max_cost,
                result=value,
            )
        finally:
            pool.shutdown(wait=False, cancel_futures=True)



@dataclass(frozen=True)
class ShadowResult:
    sampled: bool
    alternatives: tuple[dict[str, Any], ...]
    reason: str


class CounterfactualShadowEvaluator:
    """Samples rejected read-only alternatives; never executes an effectful action."""

    def __init__(self, *, sample_rate: float = 0.1, max_alternatives: int = 3,
                 seed: int = 0) -> None:
        self.sample_rate = min(1.0, max(0.0, sample_rate))
        self.max_alternatives = max(0, max_alternatives)
        self.rng = random.Random(seed)

    @staticmethod
    def _read_only(action: ActionIR) -> bool:
        return (
            action.reversibility is Reversibility.READ_ONLY
            and not action.write_set
            and not any(effect.startswith(("net.", "mcp.", "env.")) for effect in action.effect_row)
        )

    def evaluate(
        self,
        alternatives: Iterable[ActionIR],
        execute: Callable[[ActionIR], dict[str, Any]],
    ) -> ShadowResult:
        rows = list(alternatives)
        if any(not self._read_only(action) for action in rows):
            raise PermissionError("counterfactual shadow execution accepts read-only local actions only")
        if not rows or self.rng.random() > self.sample_rate:
            return ShadowResult(sampled=False, alternatives=(), reason="not sampled")
        output = []
        for action in rows[:self.max_alternatives]:
            result = execute(action)
            output.append({
                "action_fingerprint": "sha256:" + hashlib.sha256(
                    json.dumps(action.evidence(), sort_keys=True).encode()
                ).hexdigest(),
                "result": result,
            })
        return ShadowResult(sampled=True, alternatives=tuple(output), reason="read-only comparison set recorded")
