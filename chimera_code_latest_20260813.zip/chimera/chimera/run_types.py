"""Cycle-free shared run lifecycle value types."""

from enum import StrEnum


class ActionState(StrEnum):
    PROPOSED = "proposed"
    ACCEPTED = "accepted"
    STARTED = "started"
    COMPLETED = "completed"
    FAILED = "failed"
    REJECTED = "rejected"
    CANCELLED = "cancelled"
