"""Transactional adapter from evolutionary patch bundles to software repositories."""
from __future__ import annotations

import hashlib
import pathlib
import uuid
from typing import Any, Callable, Literal, Optional

from pydantic import BaseModel, ConfigDict, field_validator, model_validator

from .branch import TransactionalWorkspace
from .capsule import workspace_input_root
from .effects import CapabilitySet, EffectRequest, check_effect
from .evolution_search import StageEvaluation
from .sandbox import Sandbox


class PatchOperation(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    op: Literal["write", "unlink"]
    path: str
    expected_digest: Optional[str]
    content: Optional[str] = None

    @model_validator(mode="after")
    def _shape(self) -> "PatchOperation":
        pure = pathlib.PurePosixPath(self.path.replace("\\", "/"))
        if not self.path.strip() or str(pure) == "." or pure.is_absolute() or ".." in pure.parts:
            raise ValueError("patch path must be non-empty, safe, and relative")
        if self.expected_digest is not None and not (
            self.expected_digest.startswith("sha256:")
            and len(self.expected_digest) == 71
            and all(char in "0123456789abcdef" for char in self.expected_digest[7:])
        ):
            raise ValueError("expected_digest must be a canonical sha256 digest or null")
        if self.op == "write" and self.content is None:
            raise ValueError("write operation requires content")
        if self.op == "unlink" and self.content is not None:
            raise ValueError("unlink operation must not carry content")
        return self


class PatchBundle(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    schema_version: Literal["chimera.patch-bundle.v1"] = "chimera.patch-bundle.v1"
    base_root: str
    operations: tuple[PatchOperation, ...]
    hypothesis: str

    @field_validator("base_root")
    @classmethod
    def _root_digest(cls, value: str) -> str:
        if not (
            value.startswith("sha256:") and len(value) == 71
            and all(char in "0123456789abcdef" for char in value[7:])
        ):
            raise ValueError("base_root must be a canonical sha256 digest")
        return value

    @model_validator(mode="after")
    def _unique(self) -> "PatchBundle":
        paths = [operation.path for operation in self.operations]
        if not self.operations or len(paths) != len(set(paths)):
            raise ValueError("patch bundle requires non-empty unique paths")
        return self


class TransactionalPatchEvaluator:
    """Evaluates candidate patches on disposable branches; evaluator stays out of prompts."""

    def __init__(
        self,
        root: pathlib.Path,
        workspace: TransactionalWorkspace,
        capability: CapabilitySet,
        *,
        base_branch: str = "main",
        test_command: str = "pytest -q",
        metric_callback: Optional[Callable[[pathlib.Path], dict[str, float]]] = None,
        timeout: int = 180,
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.workspace = workspace
        self.capability = capability
        self.base_branch = base_branch
        self.test_command = test_command
        self.metric_callback = metric_callback
        self.timeout = timeout

    def _digest(self, branch: str, path: str) -> Optional[str]:
        try: data = self.workspace.read(branch, path)
        except FileNotFoundError: return None
        return "sha256:" + hashlib.sha256(data).hexdigest()

    def _apply(self, branch: str, bundle: PatchBundle) -> None:
        # Preflight the complete bundle before the first mutation. This prevents
        # a late stale preimage or denied capability from creating a partial patch.
        for operation in bundle.operations:
            actual = self._digest(branch, operation.path)
            if actual != operation.expected_digest:
                raise ValueError(f"preimage mismatch for {operation.path}: expected={operation.expected_digest} actual={actual}")
            verdict = check_effect(
                EffectRequest(effect="fs.write", needs={"fs": [operation.path]}), self.capability
            )
            if not verdict.allowed or verdict.residual_obligations:
                raise PermissionError(verdict.denied_reason or str(verdict.residual_obligations))
        for operation in bundle.operations:
            if operation.op == "write":
                self.workspace.write(branch, operation.path, operation.content or "")
            else:
                self.workspace.unlink(branch, operation.path)

    def evaluate(self, encoded_bundle: str, seed: int) -> StageEvaluation:
        branch = f"evo-{uuid.uuid4().hex[:12]}"
        try:
            bundle = PatchBundle.model_validate_json(encoded_bundle)
            current_root = workspace_input_root(self.root, self.workspace, self.base_branch)
            if bundle.base_root != current_root:
                return StageEvaluation(
                    stage="software", passed=False, budget_class="real",
                    metrics={"correctness": 0.0}, insights=("candidate base root is stale",),
                )
            self.workspace.fork(branch, self.base_branch)
            self._apply(branch, bundle)
            result = Sandbox(
                self.root, self.capability, branch=branch, workspace=self.workspace
            ).exec(self.test_command, timeout=self.timeout)
            metrics = {"correctness": 1.0 if result.status == 0 else 0.0}
            if result.status == 0 and self.metric_callback:
                view = self.workspace.materialize(branch)
                metrics.update({key: float(value) for key, value in self.metric_callback(view).items()})
            return StageEvaluation(
                stage="software", passed=result.status == 0, metrics=metrics,
                insights=(
                    f"test exit={result.status}",
                    (result.stderr or result.stdout)[-1000:],
                ),
                artifacts={"diff": self.workspace.diff(branch), "backend": result.evidence.get("backend")},
            )
        except Exception as exc:
            return StageEvaluation(
                stage="software", passed=False, budget_class="real",
                metrics={"correctness": 0.0},
                insights=(f"patch evaluation failed: {type(exc).__name__}: {exc}",),
            )
        finally:
            if branch in self.workspace.list_branches(): self.workspace.abort(branch)

    def stage_for_promotion(self, encoded_bundle: str, target_branch: str) -> dict[str, Any]:
        """Verify on a disposable child, then CAS-merge into the target overlay."""
        bundle = PatchBundle.model_validate_json(encoded_bundle)
        current_root = workspace_input_root(self.root, self.workspace, target_branch)
        if current_root != bundle.base_root:
            raise RuntimeError("cannot promote patch: target workspace root changed")
        verification_branch = f"promote-verify-{uuid.uuid4().hex[:12]}"
        try:
            self.workspace.fork(verification_branch, target_branch)
            self._apply(verification_branch, bundle)
            result = Sandbox(
                self.root, self.capability, branch=verification_branch, workspace=self.workspace
            ).exec(self.test_command, timeout=self.timeout)
            if result.status != 0:
                raise RuntimeError("promotion staging failed verification")
            # The target may have changed while verification ran. Both the full
            # root check and merge_into's per-file CAS must still agree.
            if workspace_input_root(self.root, self.workspace, target_branch) != bundle.base_root:
                raise RuntimeError("cannot promote patch: target workspace root changed during verification")
            merged = self.workspace.merge_into(verification_branch, target_branch)
            return {
                "branch": target_branch,
                "diff": merged["target_diff"],
                "test_status": result.status,
                "verification_delta": merged["delta"]["id"],
            }
        finally:
            if verification_branch in self.workspace.list_branches():
                self.workspace.abort(verification_branch)
