
"""
Orchestrator — Harness main loop

Behave like autonomous engineering organization:
- supervisor owns VFS root, policy, replay buffer, variant router
- worker per branch with WASM isolate (Sandbox) + Etas trace
- catalog via CodeGraph
- scheduler work-stealing DAG

Exposes high-level API: ChimeraHarness.run(task, branch, model) -> verified diff or retry
"""
from __future__ import annotations
import pathlib, time, json
from typing import Dict, Any, Optional, List
from .branch import TransactionalWorkspace
from .config import ChimeraConfig
from .graph import CodeGraph
from .sandbox import Sandbox
from .effects import CapabilitySet
from .verifier import Verifier, LTLMonitor
from .dag import DAGPlanner
from .rlm import RLMRuntime
from .replay import ReplayBuffer
from .evolution import EvolutionEngine
from .observability import Logger, ProgressTracker
from .scoped_approval import ScopedApprovalLedger
from .capsule import workspace_input_root
from .wal import WAL
from .lean import LeanVerifier
from .cost_governor import CostGovernor
from .self_heal import SelfHealer
from .bench import BenchHarness
from .gate_effectiveness import GateEffectivenessLedger
from .degradation_ledger import confess_degradation
from .heldout_verifier import HeldOutVerifier
from .quality_rubric import PatchReviewRubric
try:
    from .drift import DriftMonitor, CPEPreserver, CuratorGate, ReInjectionScheduler, LibraryDriftGuard
    _has_drift = True
except: _has_drift=False

class ChimeraHarness:
    def __init__(self, root: pathlib.Path = pathlib.Path("."), config: Optional[ChimeraConfig]=None):
        self.root = pathlib.Path(root).resolve()
        self.config = config or ChimeraConfig.load(self.root / "chimera.toml")
        self.workspace = TransactionalWorkspace(self.root)
        self.graph = CodeGraph(self.root)
        self.wal = WAL(self.root)
        self.buffer = ReplayBuffer(self.root)
        self.evolution = EvolutionEngine(self.root, self.buffer)
        self.logger = Logger(self.root)
        self.tracker = ProgressTracker()
        self.verifier = Verifier(ltl_properties=["G(!writeOutsideAllow)", "G(request -> F response)"])
        self.rlm_runtime = RLMRuntime(self.root, self.workspace, self.config)
        # Irreversible commit authority is never a model-set global flag. A
        # host/operator must grant the exact reviewed task/diff/snapshot.
        self.approvals = ScopedApprovalLedger(self.root)
        # 11/10: Lean4 three-tier, Cost Governor, Self-Healer, Bench
        self.lean = LeanVerifier(self.root)
        self.cost_governor = CostGovernor(budget_usd=10.0)
        self.healer = SelfHealer(self.root)
        self.bench = BenchHarness(self.root)
        self.gate_effectiveness = GateEffectivenessLedger(self.root)
        self.heldout_verifier = HeldOutVerifier(self.root)
        self.patch_rubric = PatchReviewRubric()
        # Drift mitigation: periodic re-injection + CPE + curator (from 60+ drift research)
        if _has_drift:
            self.drift_monitor = DriftMonitor(self.root)
            self.cpe = CPEPreserver(self.root)
            self.curator = CuratorGate(self.root)
            self.reinjector = ReInjectionScheduler(self.root, every_n=5)
            self.library_guard = LibraryDriftGuard(self.root)
        else:
            self.drift_monitor = None
        # ensure graph exists lazily

    def run(self, task: str, branch: str="exp-001", model: str="mock-echo", auto_commit: bool=False) -> Dict[str,Any]:
        """
        Full agentic loop: branch -> plan -> execute -> verify -> replan/commit/abort
        Returns evidence bundle.
        """
        self.tracker.update("branch", "start", branch)
        if branch not in self.workspace.list_branches():
            self.workspace.branch(branch)
            self.logger.info("branch created", branch=branch)

        self.tracker.update("graph", "check", "")
        if not (self.root / ".chimera" / "graph.json").exists():
            try:
                self.graph.build()
                self.logger.info("graph built", nodes=len(self.graph.graph.get("nodes",[])))
            except Exception as e:
                self.logger.warn("graph build failed", error=str(e))

        self.tracker.update("rlm", "start", task[:80])
        # Drift mitigation: set baseline and periodic re-injection
        if _has_drift and self.drift_monitor:
            self.drift_monitor.set_baseline(task)
            if self.reinjector.should_reinject():
                task = self.reinjector.inject(task)
                self.logger.info("re-injected scoped repository guidance for anti-drift", turn=self.reinjector.turn,
                                 sources=self.reinjector.last_manifest)
        # Cost-aware routing: planner picks model per phase via cost_governor
        if hasattr(self.rlm_runtime, "cost_governor"):
            self.rlm_runtime.cost_governor = self.cost_governor
            self.rlm_runtime.dag_planner.cost_governor = self.cost_governor
        result = self.rlm_runtime.rlm(task, branch=branch, model=model, depth=1, use_dag=True)
        answer = result["answer"]
        verification = result["verification"]
        diff = result["diff"]

        # 11/10: LTL + Lean4 three-tier formal verification
        ltl_ok = True
        ltl_msg=None
        lean_res=None
        for mon in self.verifier.ltl_monitors:
            ok, msg = mon.check(result.get("traces", []))
            if not ok:
                ltl_ok=False; ltl_msg=msg; break
        # Lean4 tier 3: compile LTL to Lean theorem and check
        if ltl_ok:
            lean_res=self.lean.verify("G(!writeOutsideAllow)", result.get("traces", []))
            # Absence of Lean is not an LTL failure; a present kernel rejecting
            # the generated artifact is.
            if lean_res.get("formal") and not lean_res.get("lean_holds"):
                ltl_ok=False; ltl_msg=lean_res.get("output")

        heldout_result = self.heldout_verifier.evaluate(
            task=task, diff=diff, traces=result.get("traces", []), answer=answer,
        )
        rubric_result = self.patch_rubric.score(task=task, diff=diff, answer=answer)
        self.gate_effectiveness.record_dual_pass(
            branch,
            grader_pass=ltl_ok,
            held_out_pass=heldout_result.passed,
            evidence_ref=heldout_result.evidence_ref,
        )
        three_tier = self.lean.three_tier(
            True, ltl_ok,
            lean_res.get("lean_holds") if lean_res else None,
            formal=bool(lean_res and lean_res.get("formal")),
        ) if lean_res else None

        # Cost Governor: account tokens per DeepSeek Flash vs Kimi swarm split (PRD §13 R4)
        aggregate_tokens = int(result.get("usage", {}).get("tokens", 0) or 0)
        cost_entry=self.cost_governor.account(
            model, aggregate_tokens, 0,
            source="aggregate harness tokens treated as input-only estimate; provider billed cost unavailable",
        )

        # Replay buffer append + Drift mitigation
        reward = verification.get("completeness", 0.5) if isinstance(verification, dict) else 0.5
        if not ltl_ok:
            reward = 0.0
            heal_res=self.healer.heal_branch(branch, ltl_msg or "LTL violation", result.get("traces", []))
            self.logger.warn("self-healed", healed=heal_res.get("healed"), to=heal_res.get("to"))
        # Drift mitigation: measure GDI + CPE observe + curator filter
        if _has_drift and self.drift_monitor:
            drift_entry = self.drift_monitor.measure(result.get("traces", []), task)
            if drift_entry.get("drift"):
                self.logger.warn("drift detected", gdi=drift_entry["gdi"], overall=drift_entry["overall"])
                # Conservative: dampen reward to prevent reinforcing drifted traces (Blind Curator mitigation)
                reward = reward * 0.7
            # CPE: observe success/failure for preservation
            self.cpe.observe(f"branch:{branch}", ltl_ok and verification.get("status")=="pass", reward)
            # Library drift guard: check skill library drift
            try:
                import pathlib as _pl
                skills = []
                for p in (self.root / ".chimera" / "variants").glob("*.json"):
                    skills.append({"id": p.stem, "status": "active"})
                diag = self.library_guard.diagnose(skills)
                if diag.get("drift"):
                    self.logger.warn("library drift", reason=diag["reason"])
            except Exception as exc:
                confess_degradation(self.root, "library_drift_guard", branch, f"{type(exc).__name__}: {exc}")
        evidence_status = "verified" if (
            ltl_ok and verification.get("status") == "pass"
            and any(t.get("kind") == "test_result" and t.get("data", {}).get("status") == 0 for t in result.get("traces", []))
        ) else "unverified"
        self.buffer.append(
            model=model, harness_variant="default", task=task, reward=reward,
            trace=result.get("traces", []),
            metadata={"branch": branch, "ltl_ok": ltl_ok, "lean": lean_res, "cost": cost_entry},
            evidence_status=evidence_status,
            provenance={"source": "chimera.orchestrator", "branch": branch, "wal_head": self.wal._prev_hash},
        )

        self.tracker.update("verify", verification.get("status","partial"), str(verification.get("completeness","")))

        # Required handoff gates are fresh, exact-workspace command proofs.
        from .quality_gate import QualityGateRunner, RequiredGate
        required_gates = tuple(RequiredGate(**gate.model_dump()) for gate in self.config.quality.required_gates)
        if required_gates:
            gate_runner = QualityGateRunner(self.rlm_runtime)
            gate_receipts = gate_runner.run(branch, required_gates)
            gate_decision = gate_runner.authorize(branch, required_gates, gate_receipts)
        else:
            gate_receipts = ()
            gate_decision = None
        gates_ok = gate_decision.authorized if gate_decision is not None else True

        # Approval gate before commit.  Behavioral-trap findings are a compact
        # regression oracle for scope and evidence honesty; they do not replace
        # the deterministic tests/LTL gates above.
        behavioral_guard = result.get("behavioral_guard", {})
        behavioral_ok = behavioral_guard.get("passed", True) if isinstance(behavioral_guard, dict) else False
        completion_gate = result.get("completion_gate", {})
        completion_gate_ok = completion_gate.get("allowed", True) if isinstance(completion_gate, dict) else True
        commit_snapshot = workspace_input_root(self.root, self.workspace, branch)
        approval_decision = self.approvals.authorize(
            action="branch_commit", task=task, target=diff, snapshot_id=commit_snapshot,
        )
        can_commit = verification.get("status")=="pass" and ltl_ok and gates_ok and behavioral_ok and completion_gate_ok and approval_decision.allowed

        committed_hash=None
        if can_commit and auto_commit:
            committed_hash = self.workspace.commit(branch, message=f"chimera: {task[:50]}")
            self.logger.info("committed", branch=branch, hash=committed_hash)
            self.tracker.update("commit", "done", committed_hash[:12] if committed_hash else "")
        elif verification.get("recommendation")=="retry" and reward < 0.9:
            self.logger.warn("retry recommended", completeness=reward)
            # One replan handled inside DAG already; here we could re-run once
            pass
        elif verification.get("status")=="fail" or not ltl_ok:
            self.logger.error("verification failed", ltl_msg=ltl_msg, verification=verification)

        return {
            "task": task,
            "branch": branch,
            "answer": answer,
            "verification": verification,
            "ltl_ok": ltl_ok,
            "ltl_msg": ltl_msg,
            "lean": lean_res,
            "three_tier": three_tier if 'three_tier' in locals() else None,
            "heldout": heldout_result.as_dict() if 'heldout_result' in locals() else None,
            "quality_rubric": rubric_result.as_dict() if 'rubric_result' in locals() else None,
            "cost": cost_entry if 'cost_entry' in locals() else None,
            "diff": diff,
            "committed": committed_hash,
            "reward": reward,
            "usage": result.get("usage",{}),
            "session_dir": result.get("session_dir"),
            "plan": result.get("plan"),
            "traces": result.get("traces", []),
            "preflight": result.get("preflight"),
            "behavioral_guard": behavioral_guard,
            "completion_gate": completion_gate,
            "after_action": result.get("after_action"),
            "quality_gates": (
                gate_decision.model_dump(mode="json") if gate_decision is not None
                else {"authorized": True, "receipts": [], "reasons": []}
            ),
            "commit_approval": approval_decision.__dict__,
        }

    def grant_current_commit(
        self, branch: str, task: str, *, approved_by: str, evidence_ref: str, ttl_seconds: float = 300.0,
    ):
        """Host-only explicit approval after reviewing the current branch diff."""
        return self.approvals.grant(
            action="branch_commit", task=task, target=self.workspace.diff(branch),
            snapshot_id=workspace_input_root(self.root, self.workspace, branch),
            approved_by=approved_by, evidence_ref=evidence_ref, ttl_seconds=ttl_seconds,
        )

    def commit_approved(self, branch: str, task: str, *, message: str) -> str:
        """Commit only when an exact, unexpired operator grant still matches."""
        diff = self.workspace.diff(branch)
        snapshot = workspace_input_root(self.root, self.workspace, branch)
        decision = self.approvals.authorize(
            action="branch_commit", task=task, target=diff, snapshot_id=snapshot,
        )
        if not decision.allowed:
            raise PermissionError(decision.reason)
        return self.workspace.commit(branch, message=message)

    def health(self) -> Dict:
        ok, bad_seq = self.wal.verify_chain()
        if not self.graph.graph.get("meta"):
            try: self.graph.load()
            except Exception as exc:
                confess_degradation(self.root, "health_graph_load", "graph", f"{type(exc).__name__}: {exc}")
        return {
            "wal_ok": ok, "wal_bad_seq": bad_seq,
            "branches": self.workspace.list_branches(),
            "graph": self.graph.stats(),
            "buffer": self.buffer.stats(),
            "log_tail": self.logger.tail(3),
            # 11/10 exceeds
            "lean": {"has_lean": self.lean.has_lean, "tier": "Lean4 three-tier"},
            "cost": self.cost_governor.report(),
            "self_heal": self.healer.heartbeat("main"),
            "bench": self.bench.leaderboard(),
            "ranger": {"variable_nodes": len([n for n in self.graph.graph.get("nodes",[]) if n.get("kind")=="Variable"])},
            "nixo": {"sessions": len(list((self.root / ".chimera" / "nixo").glob("*.json"))) if (self.root / ".chimera" / "nixo").exists() else 0},
        }
