"""Fail-closed hash-chained write-ahead log.

Every durable mutation is canonicalized, hash-linked, fsynced, and protected by
an inter-thread/inter-process append lock.  A corrupt existing chain is never
extended: callers receive ``WALIntegrityError`` and the file remains untouched.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import pathlib
import tempfile
import threading
import time
from collections import OrderedDict
from typing import Any, Dict, List, Optional

def _hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


_GENESIS = "genesis:" + _hash(b"chimera-genesis-v1")
_LOCKS: dict[str, threading.RLock] = {}
_LOCKS_GUARD = threading.Lock()
# Process-local accelerators only. File identity includes ctime, so any ordinary
# external write/replacement invalidates trust and forces a full chain scan.
_MAX_CACHED_ROOTS = 256
_TRUSTED_HEADS: OrderedDict[
    str, tuple[tuple[Any, ...], tuple[Any, ...] | None, int, str]
] = OrderedDict()
_REPLAY_CACHE: OrderedDict[
    str, tuple[tuple[Any, ...], tuple[Dict[str, Any], ...]]
] = OrderedDict()
_CACHE_GUARD = threading.RLock()


def _bound_cache(cache: OrderedDict) -> None:
    while len(cache) > _MAX_CACHED_ROOTS:
        cache.popitem(last=False)


def _stat_signature(path: pathlib.Path) -> tuple[Any, ...] | None:
    try:
        value = path.stat()
    except FileNotFoundError:
        return None
    # Some overlay filesystems expose coarse timestamps. Include a bounded
    # content fingerprint so same-length rewrites cannot reuse trusted state.
    sample = bytearray()
    try:
        with path.open("rb") as handle:
            size = value.st_size
            if size <= 12_288:
                sample.extend(handle.read())
            else:
                offsets = (0, max(0, size // 2 - 2048), max(0, size - 4096))
                for offset in offsets:
                    handle.seek(offset)
                    sample.extend(handle.read(4096))
        sample_hash = hashlib.sha256(sample).hexdigest()
    except OSError:
        sample_hash = "unreadable"
    return (
        value.st_dev, value.st_ino, value.st_size,
        value.st_mtime_ns, value.st_ctime_ns, sample_hash,
    )


class WALIntegrityError(RuntimeError):
    """The durable log cannot be parsed or its hash/sequence chain is invalid."""


class WALEntry:
    def __init__(self, seq: int, ts: str, kind: str, data: Dict[str, Any], prev_hash: str, hash: str):
        self.seq = seq
        self.ts = ts
        self.kind = kind
        self.data = data
        self.prev_hash = prev_hash
        self.hash = hash

    def to_dict(self) -> dict[str, Any]:
        return {
            "seq": self.seq, "ts": self.ts, "kind": self.kind, "data": self.data,
            "prev_hash": self.prev_hash, "hash": self.hash,
        }


class WAL:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()
        self.dir = self.root / ".chimera"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.path = self.dir / "wal.jsonl"
        self.chain_path = self.dir / "wal.chain"
        self._seq = 0
        self._prev_hash = _GENESIS
        key = str(self.path)
        with _LOCKS_GUARD:
            self._thread_lock = _LOCKS.setdefault(key, threading.RLock())
        self._load()

    @staticmethod
    def _payload(seq: int, ts: str, kind: str, data: Dict[str, Any], prev_hash: str) -> bytes:
        return json.dumps(
            {"seq": seq, "ts": ts, "kind": kind, "data": data, "prev_hash": prev_hash},
            sort_keys=True,
        ).encode()

    def _load(self) -> None:
        """Load an untrusted tail hint in O(1); append verifies before using it."""
        self._seq = 0
        self._prev_hash = _GENESIS
        if not self.path.exists() or self.path.stat().st_size == 0:
            return
        if self.chain_path.exists():
            try:
                head = json.loads(self.chain_path.read_text())
                self._seq = int(head["next_seq"])
                self._prev_hash = str(head["head"])
                return
            except (json.JSONDecodeError, KeyError, TypeError, ValueError, OSError):
                pass
        # Legacy/no-sidecar fallback: seek only the final non-empty JSONL row.
        try:
            with self.path.open("rb") as handle:
                handle.seek(0, os.SEEK_END)
                position = handle.tell()
                buffer = bytearray()
                while position > 0:
                    position -= 1
                    handle.seek(position)
                    byte = handle.read(1)
                    if byte == b"\n" and buffer:
                        break
                    if byte not in {b"\n", b"\r"}:
                        buffer[:0] = byte
                last = json.loads(bytes(buffer))
            self._seq = int(last["seq"]) + 1
            self._prev_hash = str(last["hash"])
        except (json.JSONDecodeError, KeyError, TypeError, ValueError, OSError) as exc:
            raise WALIntegrityError(f"cannot load WAL tail: {exc}") from exc

    def _use_trusted_head(self) -> bool:
        if os.environ.get("CHIMERA_WAL_STRICT_APPEND") == "1":
            return False
        key = str(self.path)
        with _CACHE_GUARD:
            trusted = _TRUSTED_HEADS.pop(key, None)
            if trusted is not None:
                _TRUSTED_HEADS[key] = trusted
        if trusted is None:
            return False
        wal_sig, chain_sig, sequence, head = trusted
        if _stat_signature(self.path) != wal_sig or _stat_signature(self.chain_path) != chain_sig:
            return False
        self._seq = sequence
        self._prev_hash = head
        return True

    def _remember_trusted_head(self) -> None:
        wal_sig = _stat_signature(self.path)
        if wal_sig is None:
            return
        with _CACHE_GUARD:
            key = str(self.path)
            _TRUSTED_HEADS.pop(key, None)
            _TRUSTED_HEADS[key] = (
                wal_sig, _stat_signature(self.chain_path), self._seq, self._prev_hash,
            )
            _bound_cache(_TRUSTED_HEADS)

    def _write_chain_head(self, entry: WALEntry) -> None:
        payload = (json.dumps({"next_seq": entry.seq + 1, "head": entry.hash}, sort_keys=True) + "\n").encode()
        fd, raw_path = tempfile.mkstemp(prefix=".wal-chain-", dir=self.dir)
        temporary = pathlib.Path(raw_path)
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.chain_path)
        finally:
            if temporary.exists():
                temporary.unlink()

    def append(self, kind: str, data: Dict[str, Any]) -> WALEntry:
        return self.append_batch([(kind, data)])[0]

    def append_batch(self, items: List[tuple[str, Dict[str, Any]]]) -> List[WALEntry]:
        """Atomically append a validated batch with one lock, write, and fsync."""
        if not items:
            return []
        for kind, data in items:
            if not isinstance(kind, str) or not kind.strip():
                raise ValueError("WAL kind must be a non-empty string")
            if not isinstance(data, dict):
                raise TypeError("WAL data must be a JSON object")
            json.dumps(data, sort_keys=True)
        lock_path = self.path.with_suffix(".lock")
        with self._thread_lock:
            lock_handle = lock_path.open("a")
            try:
                try:
                    import fcntl
                except ImportError:  # pragma: no cover
                    fcntl = None
                if fcntl is not None:
                    fcntl.flock(lock_handle, fcntl.LOCK_EX)
                if not self._use_trusted_head():
                    valid, bad = self.verify_chain()
                    if not valid:
                        raise WALIntegrityError(f"refusing to extend corrupt WAL at sequence/line {bad}")
                sequence = self._seq
                previous = self._prev_hash
                prior_wal_signature = _stat_signature(self.path)
                entries: List[WALEntry] = []
                encoded_lines: List[bytes] = []
                for kind, data in items:
                    ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                    payload = self._payload(sequence, ts, kind, data, previous)
                    digest = _hash(payload)
                    entry = WALEntry(sequence, ts, kind, data, previous, digest)
                    entries.append(entry)
                    encoded_lines.append((json.dumps(entry.to_dict(), sort_keys=True) + "\n").encode())
                    sequence += 1
                    previous = digest
                with self.path.open("ab") as handle:
                    handle.write(b"".join(encoded_lines))
                    handle.flush()
                    os.fsync(handle.fileno())
                self._write_chain_head(entries[-1])
                self._seq = sequence
                self._prev_hash = previous
                self._remember_trusted_head()
                new_signature = _stat_signature(self.path)
                with _CACHE_GUARD:
                    cached = _REPLAY_CACHE.get(str(self.path))
                    if cached is not None and cached[0] == prior_wal_signature and new_signature is not None:
                        _REPLAY_CACHE[str(self.path)] = (
                            new_signature,
                            (*cached[1], *(entry.to_dict() for entry in entries)),
                        )
                        _bound_cache(_REPLAY_CACHE)
                    else:
                        _REPLAY_CACHE.pop(str(self.path), None)
                return entries
            finally:
                try:
                    if "fcntl" in locals() and fcntl is not None:
                        fcntl.flock(lock_handle, fcntl.LOCK_UN)
                finally:
                    lock_handle.close()

    def replay(self, after_seq: int = -1, kind: Optional[str] = None) -> List[Dict[str, Any]]:
        signature = _stat_signature(self.path)
        if signature is None:
            return []
        key = str(self.path)
        with _CACHE_GUARD:
            cached = _REPLAY_CACHE.pop(key, None)
            if cached is not None:
                _REPLAY_CACHE[key] = cached
        if cached is not None and cached[0] == signature:
            entries = cached[1]
        else:
            parsed: List[Dict[str, Any]] = []
            with self.path.open("r", encoding="utf-8") as handle:
                for line_no, line in enumerate(handle, 1):
                    if not line.strip():
                        continue
                    try:
                        parsed.append(json.loads(line))
                    except json.JSONDecodeError as exc:
                        raise WALIntegrityError(f"invalid JSON at WAL line {line_no}: {exc}") from exc
            entries = tuple(parsed)
            # Cache only if the file did not change while it was parsed.
            if _stat_signature(self.path) == signature:
                with _CACHE_GUARD:
                    _REPLAY_CACHE.pop(key, None)
                    _REPLAY_CACHE[key] = (signature, entries)
                    _bound_cache(_REPLAY_CACHE)
        return [
            copy.deepcopy(entry) for entry in entries
            if entry["seq"] > after_seq and (kind is None or entry["kind"] == kind)
        ]

    def verify_chain(self) -> tuple[bool, Optional[int]]:
        if not self.path.exists():
            return True, None
        previous = _GENESIS
        expected_seq = 0
        for line_no, line in enumerate(self.path.read_text().splitlines(), 1):
            if not line.strip():
                continue
            try:
                entry = json.loads(line)
                seq = int(entry["seq"])
                if seq != expected_seq:
                    return False, seq
                payload = self._payload(seq, entry["ts"], entry["kind"], entry["data"], previous)
                expected_hash = _hash(payload)
                if expected_hash != entry["hash"] or entry["prev_hash"] != previous:
                    return False, seq
                previous = entry["hash"]
                expected_seq += 1
            except (json.JSONDecodeError, KeyError, TypeError, ValueError):
                return False, line_no
        if self.chain_path.exists() and expected_seq:
            repair_head = False
            try:
                head = json.loads(self.chain_path.read_text())
                repair_head = (
                    head.get("head") != previous
                    or head.get("next_seq") != expected_seq
                )
            except (json.JSONDecodeError, OSError):
                repair_head = True
            if repair_head:
                # The JSONL hash chain is authoritative; the sidecar is only an
                # O(1) tail index. A crash between fsyncing the log and replacing
                # this index must be recoverable rather than bricking appends.
                self._write_chain_head(WALEntry(
                    expected_seq - 1,
                    "recovered-index",
                    "chain-head-recovery",
                    {},
                    "",
                    previous,
                ))
        self._seq = expected_seq
        self._prev_hash = previous
        self._remember_trusted_head()
        return True, None

    def snapshot(self, branch: str, diff_hash: str):
        return self.append("snapshot", {"branch": branch, "diff_hash": diff_hash})

    def query_at(self, at: str) -> List[Dict[str, Any]]:
        import datetime

        at_norm = at.replace("Z", "+00:00")
        try:
            at_dt = datetime.datetime.fromisoformat(at_norm)
        except Exception:
            return self.replay()
        output = []
        for entry in self.replay():
            try:
                entry_dt = datetime.datetime.fromisoformat(entry["ts"].replace("Z", "+00:00"))
            except Exception:
                continue
            if entry_dt <= at_dt:
                output.append(entry)
        return output

    def verify_with_ltl(self, property_file: pathlib.Path) -> Dict[str, Any]:
        props = json.loads(property_file.read_text()) if property_file.exists() else {"formula": "G(!exfiltrate)"}
        formula = props.get("formula") if isinstance(props, dict) else str(props)
        from .verifier import LTLMonitor

        trace_states = [{"kind": entry["kind"], "data": entry["data"]} for entry in self.replay()]
        ok, message = LTLMonitor(formula).check(trace_states)
        return {
            "holds": ok, "formula": formula, "violation": message,
            "traces": len(trace_states),
        }


class WALBatchScope:
    """Thread-local WAL group-commit scope for Tier-2 bookkeeping writes."""

    _local = threading.local()

    def __init__(self, wal: "WAL", *, flush_on_exception: bool = True) -> None:
        self.wal = wal
        self.flush_on_exception = bool(flush_on_exception)
        self._pending: List[tuple[str, Dict[str, Any]]] = []

    def append(self, kind: str, data: Dict[str, Any]) -> None:
        self._pending.append((kind, data))

    def flush(self) -> List[WALEntry]:
        if not self._pending:
            return []
        pending = self._pending
        self._pending = []
        return self.wal.append_batch(pending)

    def __enter__(self) -> "WALBatchScope":
        stack = getattr(self._local, "stack", None)
        if stack is None:
            stack = []
            self._local.stack = stack
        stack.append(self)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        try:
            if exc_type is None or self.flush_on_exception:
                self.flush()
            else:
                self._pending = []
        finally:
            stack = getattr(self._local, "stack", None)
            if stack:
                stack.pop()

    @classmethod
    def current(cls) -> Optional["WALBatchScope"]:
        stack = getattr(cls._local, "stack", None)
        return stack[-1] if stack else None


def wal_write(wal: "WAL", kind: str, data: Dict[str, Any]) -> List[WALEntry]:
    """Append immediately, or queue into the current WALBatchScope if present."""
    scope = WALBatchScope.current()
    if scope is not None and getattr(scope.wal, "path", None) == getattr(wal, "path", None):
        scope.append(kind, data)
        return []
    return wal.append_batch([(kind, data)])
