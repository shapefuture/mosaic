"""Safe shared persistent memory for long-running evolutionary agents.

Unlike symlinked writable trees, agents receive immutable snapshots/references;
private evaluator material never enters branch views.
"""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import time
import uuid
from typing import Any, Iterable, Optional

from .wal import WAL, wal_write


class EvolutionKnowledgeHub:
    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root).resolve()
        self.dir = self.root / ".chimera" / "evolution_hub"
        self.public = self.dir / "public"
        self.private = self.dir / "private"
        for name in ("attempts", "notes", "skills"):
            (self.public / name).mkdir(parents=True, exist_ok=True)
        self.private.mkdir(parents=True, exist_ok=True)
        try: os.chmod(self.private, 0o700)
        except OSError as exc:
            from .degradation_ledger import confess_degradation
            confess_degradation(self.root, "private_directory_mode", "evolution_hub", type(exc).__name__, severity="info")
        self.wal = WAL(self.root)

    @staticmethod
    def _atomic(path: pathlib.Path, value: dict[str, Any]) -> None:
        temp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        try:
            temp.write_text(json.dumps(value, indent=2, sort_keys=True, default=str) + "\n")
            os.replace(temp, path)
        finally:
            if temp.exists(): temp.unlink()

    def set_private_evaluator(self, evaluator_digest: str, metadata: Optional[dict[str, Any]] = None) -> None:
        # Store an allowlisted operational description only, never source/prompt/secrets.
        metadata = metadata or {}
        allowed = {"name", "version", "backend", "timeout_seconds"}
        unknown = set(metadata) - allowed
        if unknown:
            raise ValueError(f"private evaluator metadata keys are not allowlisted: {sorted(unknown)}")
        self._atomic(self.private / "evaluator.json", {
            "evaluator_digest": evaluator_digest,
            "metadata": metadata,
            "source_exposed": False,
        })
        wal_write(self.wal, "evolution_private_evaluator", {"evaluator_digest": evaluator_digest})

    def publish_attempt(self, *, candidate_id: str, island: int, parent_id: Optional[str],
                        metrics: dict[str, float], feasible: bool, code_ref: str,
                        insights: Iterable[str], evidence_refs: Iterable[str]) -> str:
        evidence = tuple(evidence_refs)
        if not evidence:
            raise ValueError("shared attempt requires evidence refs")
        semantic = {
            "candidate_id": candidate_id, "island": island, "parent_id": parent_id,
            "metrics": metrics, "feasible": feasible, "code_ref": code_ref,
            "insights": list(insights), "evidence_refs": list(evidence),
        }
        attempt_id = "attempt-" + hashlib.sha256(json.dumps(semantic, sort_keys=True).encode()).hexdigest()[:16]
        destination = self.public / "attempts" / f"{attempt_id}.json"
        if destination.exists():
            return attempt_id
        payload = {**semantic, "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        self._atomic(destination, {"id": attempt_id, **payload})
        wal_write(self.wal, "evolution_hub_attempt", {
            "id": attempt_id, "candidate": candidate_id, "island": island,
            "state_hash": self.state_hash(),
        })
        return attempt_id

    def publish_note(self, *, title: str, content: str, source_candidates: Iterable[str],
                     evidence_refs: Iterable[str], island: Optional[int] = None) -> str:
        refs = tuple(evidence_refs)
        if not refs:
            raise ValueError("shared note requires evidence refs")
        semantic = {
            "title": title, "content": content, "source_candidates": list(source_candidates),
            "evidence_refs": list(refs), "island": island,
        }
        note_id = "note-" + hashlib.sha256(json.dumps(semantic, sort_keys=True).encode()).hexdigest()[:16]
        destination = self.public / "notes" / f"{note_id}.json"
        if destination.exists():
            return note_id
        payload = {**semantic, "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        self._atomic(destination, {"id": note_id, **payload})
        wal_write(self.wal, "evolution_hub_note", {"id": note_id, "island": island, "state_hash": self.state_hash()})
        return note_id

    def attempts(self, island: Optional[int] = None, limit: int = 100) -> list[dict[str, Any]]:
        rows = [json.loads(path.read_text()) for path in sorted((self.public / "attempts").glob("*.json"))]
        if island is not None:
            rows = [row for row in rows if row.get("island") == island]
        return rows[-max(1, limit):]

    def notes(self, island: Optional[int] = None, include_global: bool = True) -> list[dict[str, Any]]:
        rows = [json.loads(path.read_text()) for path in sorted((self.public / "notes").glob("*.json"))]
        if island is not None:
            rows = [row for row in rows if row.get("island") == island or (include_global and row.get("island") is None)]
        return rows

    def state_hash(self) -> str:
        rows = []
        for directory in (self.public / "attempts", self.public / "notes", self.public / "skills"):
            for path in sorted(directory.glob("*")):
                if path.is_file():
                    rows.append((path.relative_to(self.public).as_posix(), hashlib.sha256(path.read_bytes()).hexdigest()))
        return "sha256:" + hashlib.sha256(json.dumps(rows, separators=(",", ":")).encode()).hexdigest()
