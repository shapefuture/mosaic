"""Change-impact-scoped verification with a non-scopable constitutional floor.

Affected tests are derived from Python import reachability and directly changed
tests.  If the mapping is incomplete or a high-blast-radius configuration file
changes, analysis fails safe to the full suite.  Repository constitutional tests
(`tests/test_audit.py`, when present) are always included in focused runs.
"""
from __future__ import annotations

import ast
import hashlib
import json
import pathlib
import shlex
from dataclasses import dataclass
from typing import Iterable

from .changed_lines import ChangedRange, SymbolAnchor, parse_unified_diff_ranges, python_symbol_anchors


@dataclass(frozen=True)
class ImpactScope:
    changed_paths: tuple[str, ...]
    mandatory_tests: tuple[str, ...]
    affected_tests: tuple[str, ...]
    command: str
    mode: str  # focused | full
    confident: bool
    reasons: tuple[str, ...]
    scope_hash: str

    def evidence(self) -> dict:
        return {
            "changed_paths": list(self.changed_paths),
            "mandatory_tests": list(self.mandatory_tests),
            "affected_tests": list(self.affected_tests),
            "command": self.command,
            "mode": self.mode,
            "confident": self.confident,
            "reasons": list(self.reasons),
            "scope_hash": self.scope_hash,
        }


class ImpactAnalyzer:
    """Deterministic affected-test selection for a repository snapshot."""

    HIGH_BLAST_NAMES = {
        "pyproject.toml", "setup.py", "setup.cfg", "tox.ini", "conftest.py",
        "requirements.txt", "requirements-lock.txt",
    }

    def __init__(self, root: pathlib.Path = pathlib.Path("."), *, max_focused_tests: int = 12) -> None:
        self.root = pathlib.Path(root).resolve()
        self.max_focused_tests = max(1, int(max_focused_tests))
        self._graph_signature: tuple[tuple[str, int, int, int], ...] | None = None
        self._graph_cache: tuple[dict[str, set[str]], set[str]] | None = None

    @staticmethod
    def _normalise(raw: str) -> str:
        value = str(raw).replace("\\", "/").removeprefix("./")
        path = pathlib.PurePosixPath(value)
        if path.is_absolute() or any(part == ".." for part in path.parts):
            raise ValueError(f"unsafe changed path: {raw!r}")
        return path.as_posix()

    def _python_files(self) -> list[pathlib.Path]:
        output: list[pathlib.Path] = []
        for path in self.root.rglob("*.py"):
            try:
                rel = path.relative_to(self.root)
            except ValueError:
                continue
            if any(part.startswith(".") for part in rel.parts) or any(
                part in {"node_modules", "build", "dist", "__pycache__", ".venv"}
                for part in rel.parts
            ):
                continue
            output.append(path)
        return sorted(output)

    @staticmethod
    def _module_name(rel: pathlib.PurePosixPath) -> str:
        parts = list(rel.with_suffix("").parts)
        if parts and parts[-1] == "__init__":
            parts.pop()
        return ".".join(parts)

    @staticmethod
    def _resolve_module(module: str, module_to_path: dict[str, str]) -> str | None:
        candidate = module
        while candidate:
            if candidate in module_to_path:
                return module_to_path[candidate]
            candidate = candidate.rsplit(".", 1)[0] if "." in candidate else ""
        return None

    def _dependency_graph(self) -> tuple[dict[str, set[str]], set[str]]:
        files = self._python_files()
        signature = tuple(
            (
                path.relative_to(self.root).as_posix(),
                value.st_size, value.st_mtime_ns, value.st_ctime_ns,
            )
            for path in files for value in (path.stat(),)
        )
        if signature == self._graph_signature and self._graph_cache is not None:
            return self._graph_cache
        module_to_path: dict[str, str] = {}
        source_by_rel: dict[str, str] = {}
        for path in files:
            rel = pathlib.PurePosixPath(path.relative_to(self.root).as_posix())
            module = self._module_name(rel)
            if module:
                module_to_path[module] = rel.as_posix()
            source_by_rel[rel.as_posix()] = path.read_text(encoding="utf-8", errors="ignore")

        graph: dict[str, set[str]] = {rel: set() for rel in source_by_rel}
        parse_failures: set[str] = set()
        for rel, source in source_by_rel.items():
            try:
                tree = ast.parse(source, filename=rel)
            except (SyntaxError, ValueError):
                parse_failures.add(rel)
                continue
            current_module = self._module_name(pathlib.PurePosixPath(rel))
            current_package = current_module.rsplit(".", 1)[0] if "." in current_module else current_module
            for node in ast.walk(tree):
                candidates: list[str] = []
                if isinstance(node, ast.Import):
                    candidates.extend(alias.name for alias in node.names)
                elif isinstance(node, ast.ImportFrom):
                    base = node.module or ""
                    if node.level:
                        package_parts = current_package.split(".") if current_package else []
                        keep = max(0, len(package_parts) - node.level + 1)
                        prefix = ".".join(package_parts[:keep])
                        base = ".".join(part for part in (prefix, base) if part)
                    if base:
                        candidates.append(base)
                        candidates.extend(f"{base}.{alias.name}" for alias in node.names if alias.name != "*")
                for module in candidates:
                    dependency = self._resolve_module(module, module_to_path)
                    if dependency and dependency != rel:
                        graph[rel].add(dependency)
        self._graph_signature = signature
        self._graph_cache = (graph, parse_failures)
        return self._graph_cache

    @staticmethod
    def _closure(start: str, graph: dict[str, set[str]]) -> set[str]:
        seen: set[str] = set()
        frontier = [start]
        while frontier:
            current = frontier.pop()
            for dependency in graph.get(current, set()):
                if dependency not in seen:
                    seen.add(dependency)
                    frontier.append(dependency)
        return seen

    @staticmethod
    def _hash(payload: dict) -> str:
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        return "sha256:" + hashlib.sha256(encoded).hexdigest()

    def _result(
        self,
        *,
        changed: tuple[str, ...],
        mandatory: tuple[str, ...],
        affected: tuple[str, ...],
        command: str,
        mode: str,
        confident: bool,
        reasons: Iterable[str],
    ) -> ImpactScope:
        reason_tuple = tuple(reasons)
        payload = {
            "changed": changed, "mandatory": mandatory, "affected": affected,
            "command": command, "mode": mode, "confident": confident, "reasons": reason_tuple,
        }
        return ImpactScope(
            changed_paths=changed, mandatory_tests=mandatory, affected_tests=affected,
            command=command, mode=mode, confident=confident, reasons=reason_tuple,
            scope_hash=self._hash(payload),
        )

    def dependency_slice(self, seed_paths: Iterable[str], max_paths: int = 12) -> tuple[str, ...]:
        """Return a bounded import/test dependency slice for discovery context.

        The in-memory dependency graph is cached by file signature. Callers can
        persist the returned path/hash receipt rather than replaying a whole
        repository into a model prompt.
        """
        seeds = tuple(sorted(dict.fromkeys(self._normalise(path) for path in seed_paths)))
        if not seeds:
            return ()
        graph, parse_failures = self._dependency_graph()
        if any(seed in parse_failures for seed in seeds):
            return seeds[:max(1, max_paths)]
        reverse: dict[str, set[str]] = {path: set() for path in graph}
        for source, dependencies in graph.items():
            for dependency in dependencies:
                reverse.setdefault(dependency, set()).add(source)
        selected: set[str] = set(seeds)
        frontier = list(seeds)
        while frontier and len(selected) < max_paths:
            current = frontier.pop(0)
            neighbors = sorted(graph.get(current, set()) | reverse.get(current, set()))
            for neighbor in neighbors:
                if neighbor not in selected:
                    selected.add(neighbor); frontier.append(neighbor)
                    if len(selected) >= max_paths:
                        break
        return tuple(sorted(selected))[:max(1, max_paths)]

    def changed_symbol_anchors(self, unified_diff: str) -> tuple[SymbolAnchor, ...]:
        """Return exact Python symbol anchors enclosing changed diff ranges.

        Unanchored/non-Python ranges are intentionally omitted rather than
        guessed. Callers must retain their normal file-level fallback when this
        compact evidence is insufficient.
        """
        ranges = parse_unified_diff_ranges(unified_diff)
        by_path: dict[str, list[ChangedRange]] = {}
        for row in ranges:
            by_path.setdefault(row.path, []).append(row)
        anchors: list[SymbolAnchor] = []
        for path, rows in sorted(by_path.items()):
            source = self.root / path
            if source.suffix != ".py" or not source.is_file():
                continue
            try:
                anchors.extend(python_symbol_anchors(path, source.read_text(encoding="utf-8", errors="replace"), rows))
            except OSError:
                continue
        return tuple(anchors)

    def analyze(self, changed_paths: Iterable[str]) -> ImpactScope:
        changed = tuple(sorted(dict.fromkeys(self._normalise(path) for path in changed_paths)))
        tests_dir = self.root / "tests"
        tests = tuple(
            sorted(path.relative_to(self.root).as_posix() for path in tests_dir.glob("test*.py"))
        ) if tests_dir.exists() else ()
        mandatory = tuple(path for path in ("tests/test_audit.py",) if (self.root / path).exists())

        if not changed:
            return self._result(
                changed=changed, mandatory=mandatory, affected=(), command="pytest -q",
                mode="full", confident=False, reasons=("empty diff cannot establish an impact closure",),
            )
        if any(pathlib.PurePosixPath(path).name in self.HIGH_BLAST_NAMES for path in changed):
            return self._result(
                changed=changed, mandatory=mandatory, affected=(), command="pytest -q",
                mode="full", confident=False, reasons=("high-blast-radius configuration changed",),
            )
        if not tests:
            return self._result(
                changed=changed, mandatory=mandatory, affected=(), command="pytest -q",
                mode="full", confident=False, reasons=("repository has no discoverable pytest files",),
            )

        graph, parse_failures = self._dependency_graph()
        changed_set = set(changed)
        affected_set: set[str] = {
            path for path in changed if path.startswith("tests/test") and path.endswith(".py")
        }
        reasons: list[str] = []
        for test in tests:
            if test in parse_failures:
                # A test we cannot analyze may conceal an import edge. Full suite is safer.
                return self._result(
                    changed=changed, mandatory=mandatory, affected=(), command="pytest -q",
                    mode="full", confident=False, reasons=(f"cannot parse dependency test {test}",),
                )
            dependencies = self._closure(test, graph)
            if changed_set & dependencies:
                affected_set.add(test)
                reasons.append(f"{test} imports changed code")

        affected_set -= set(mandatory)
        affected = tuple(sorted(affected_set))
        if not affected:
            return self._result(
                changed=changed, mandatory=mandatory, affected=(), command="pytest -q",
                mode="full", confident=False,
                reasons=("no affected test dependency could be proven; full suite required",),
            )
        selected = tuple(dict.fromkeys((*mandatory, *affected)))
        if len(selected) > self.max_focused_tests or len(selected) >= len(tests):
            return self._result(
                changed=changed, mandatory=mandatory, affected=affected, command="pytest -q",
                mode="full", confident=True,
                reasons=(*reasons, "affected closure is large enough that full verification is cheaper/safer"),
            )
        command = "pytest -q " + " ".join(shlex.quote(path) for path in selected)
        return self._result(
            changed=changed, mandatory=mandatory, affected=affected, command=command,
            mode="focused", confident=True, reasons=reasons or ("directly changed test selected",),
        )
