"""Fail-closed held-out Pareto gate for context/token optimizations."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class HeldoutContextObservation(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    case_id: str = Field(min_length=1, max_length=200)
    baseline_quality: float = Field(ge=0.0, le=1.0)
    candidate_quality: float = Field(ge=0.0, le=1.0)
    baseline_false_negative: bool
    candidate_false_negative: bool
    baseline_tokens: int = Field(gt=0)
    candidate_tokens: int = Field(gt=0)
    baseline_latency_ms: float = Field(gt=0)
    candidate_latency_ms: float = Field(gt=0)


class ContextParetoReceipt(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    schema_version: str = "chimera.context-pareto.v1"
    qualified: bool
    automatic_promotion: bool = False
    cases: int
    baseline_quality: float | None
    candidate_quality: float | None
    baseline_false_negative_rate: float | None
    candidate_false_negative_rate: float | None
    token_reduction: float | None
    latency_reduction: float | None
    reasons: tuple[str, ...]


class ContextParetoGate:
    """Require a strict efficiency win with no held-out quality/FN regression."""

    def __init__(
        self,
        *,
        minimum_cases: int = 20,
        minimum_token_reduction: float = 0.05,
        per_case_quality_tolerance: float = 0.0,
    ) -> None:
        if minimum_cases < 1:
            raise ValueError("minimum_cases must be positive")
        if not 0.0 <= minimum_token_reduction < 1.0:
            raise ValueError("minimum_token_reduction must be in [0, 1)")
        if not 0.0 <= per_case_quality_tolerance <= 1.0:
            raise ValueError("quality tolerance must be in [0, 1]")
        self.minimum_cases = minimum_cases
        self.minimum_token_reduction = minimum_token_reduction
        self.per_case_quality_tolerance = per_case_quality_tolerance

    def assess(
        self, observations: list[HeldoutContextObservation]
    ) -> ContextParetoReceipt:
        reasons: list[str] = []
        unique = {row.case_id for row in observations}
        if len(unique) != len(observations):
            reasons.append("held-out case identifiers are not unique")
        if len(observations) < self.minimum_cases:
            reasons.append(
                f"need at least {self.minimum_cases} held-out cases; observed {len(observations)}"
            )
        if not observations:
            return ContextParetoReceipt(
                qualified=False,
                cases=0,
                baseline_quality=None,
                candidate_quality=None,
                baseline_false_negative_rate=None,
                candidate_false_negative_rate=None,
                token_reduction=None,
                latency_reduction=None,
                reasons=tuple(reasons or ["held-out evidence is unavailable"]),
            )

        count = len(observations)
        baseline_quality = sum(row.baseline_quality for row in observations) / count
        candidate_quality = sum(row.candidate_quality for row in observations) / count
        baseline_false_negatives = sum(
            row.baseline_false_negative for row in observations
        )
        candidate_false_negatives = sum(
            row.candidate_false_negative for row in observations
        )
        baseline_tokens = sum(row.baseline_tokens for row in observations)
        candidate_tokens = sum(row.candidate_tokens for row in observations)
        baseline_latency = sum(row.baseline_latency_ms for row in observations)
        candidate_latency = sum(row.candidate_latency_ms for row in observations)
        token_reduction = 1.0 - candidate_tokens / baseline_tokens
        latency_reduction = 1.0 - candidate_latency / baseline_latency

        if candidate_quality < baseline_quality:
            reasons.append("aggregate held-out quality regressed")
        if any(
            row.candidate_quality + self.per_case_quality_tolerance
            < row.baseline_quality
            for row in observations
        ):
            reasons.append("at least one held-out case exceeded the quality tolerance")
        if candidate_false_negatives > baseline_false_negatives:
            reasons.append("held-out false-negative rate regressed")
        if any(
            row.candidate_false_negative and not row.baseline_false_negative
            for row in observations
        ):
            reasons.append("candidate introduced a new held-out false negative")
        if token_reduction < self.minimum_token_reduction:
            reasons.append(
                "token reduction did not meet the minimum strict improvement"
            )
        if candidate_latency > baseline_latency:
            reasons.append("aggregate latency regressed")

        return ContextParetoReceipt(
            qualified=not reasons,
            cases=count,
            baseline_quality=baseline_quality,
            candidate_quality=candidate_quality,
            baseline_false_negative_rate=baseline_false_negatives / count,
            candidate_false_negative_rate=candidate_false_negatives / count,
            token_reduction=token_reduction,
            latency_reduction=latency_reduction,
            reasons=tuple(reasons),
        )
