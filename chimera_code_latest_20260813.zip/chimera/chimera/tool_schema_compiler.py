"""Deterministic compact rendering of trusted tool schemas for model context.

The compiled form is an exposure optimization only. Invocation still uses the
canonical JSON schema and ActionIR validation; a compact rendering can never
expand argument authority.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from typing import Any, Mapping

from .request_stability import canonicalize_tool_schema


@dataclass(frozen=True)
class CompiledToolSchema:
    name: str
    schema_hash: str
    text: str


def compile_tool_schema(tool: Mapping[str, Any]) -> CompiledToolSchema:
    name = str(tool.get("name", "")).strip()
    if not name:
        raise ValueError("tool name is required")
    schema = canonicalize_tool_schema(tool.get("parameters", tool.get("inputSchema")))
    props = schema.get("properties", {}) if isinstance(schema.get("properties"), Mapping) else {}
    required = set(schema.get("required", [])) if isinstance(schema.get("required"), list) else set()
    parts: list[str] = []
    for key in sorted(props):
        value = props[key] if isinstance(props[key], Mapping) else {}
        kind = value.get("type", "value")
        enum = value.get("enum")
        shape = f"{key}:{kind}"
        if isinstance(enum, list):
            shape += "{" + "|".join(map(str, enum[:8])) + ("|…" if len(enum) > 8 else "") + "}"
        if key not in required:
            shape += "?"
        parts.append(shape)
    raw = json.dumps(schema, sort_keys=True, separators=(",", ":")).encode()
    return CompiledToolSchema(name, "sha256:" + hashlib.sha256(raw).hexdigest(), f"{name}({', '.join(parts)})")
