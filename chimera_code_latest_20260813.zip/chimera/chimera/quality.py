"""Quality-control primitives for model-generated coding patches.

The model gets a small, explicit contract; the harness owns target inference,
syntax/policy validation, and repair evidence.  This keeps generation focused
on code rather than repository archaeology or self-evaluation.
"""
from __future__ import annotations

import ast
import io
import pathlib
import re
import tokenize
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Tuple
from .egress_guard import ArtifactEgressGuard
from .fable_transfers import TestAntiGamingGuard
from .path_policy import PathPolicyResolver


@dataclass
class ChangeTarget:
    path: str
    mode: str  # create | edit
    reason: str


@dataclass
class TaskContract:
    task: str
    tests: Dict[str, str] = field(default_factory=dict)
    targets: List[ChangeTarget] = field(default_factory=list)
    protected_paths: List[str] = field(default_factory=list)
    required_literals: List[str] = field(default_factory=list)
    required_symbols: Dict[str, List[str]] = field(default_factory=dict)
    required_calls: Dict[str, List[str]] = field(default_factory=dict)
    required_mapping_keys: Dict[str, List[str]] = field(default_factory=dict)
    required_prefixes: Dict[str, Dict[str, str]] = field(default_factory=dict)
    required_call_arity: Dict[str, Dict[str, int]] = field(default_factory=dict)

    @classmethod
    def compile(cls, root: pathlib.Path, task: str) -> "TaskContract":
        root = pathlib.Path(root).resolve()
        tests: Dict[str, str] = {}
        tests_dir = root / "tests"
        if tests_dir.exists():
            # Prefer task-related tests but retain a bounded fallback set.
            keywords = set(re.findall(r"[a-z_][a-z0-9_]{3,}", task.lower()))
            candidates = sorted(tests_dir.glob("test*.py"))
            ranked = sorted(
                candidates,
                key=lambda path: (
                    -sum(1 for word in keywords if word in path.name.lower()),
                    path.name,
                ),
            )
            for path in ranked[:8]:
                tests[str(path.relative_to(root))] = path.read_text(encoding="utf-8", errors="ignore")[:16_000]

        protected: List[str] = []
        lower = task.lower()
        if (
            any(phrase in lower for phrase in ("do not modify the supplied tests", "do not modify tests", "don't modify tests"))
            or re.search(r"\b(?:do not|don't)\s+modify\b[^.\n]{0,80}\btests?\b", lower)
        ):
            protected.extend(tests.keys())

        targets: List[ChangeTarget] = []
        seen: set[str] = set()

        def add_target(path: str, mode: str, reason: str) -> None:
            clean = path.replace("\\", "/").removeprefix("./")
            if clean not in seen and clean not in protected:
                targets.append(ChangeTarget(clean, mode, reason))
                seen.add(clean)

        test_text = "\n".join(tests.values())
        # Missing local imports in acceptance tests are high-confidence create targets.
        required_symbols: Dict[str, List[str]] = {}
        for module, imported in re.findall(
            r"^\s*from\s+(chimera(?:\.[A-Za-z_]\w*)+)\s+import\s+([^\n#]+)",
            test_text, re.MULTILINE,
        ):
            path = module.replace(".", "/") + ".py"
            symbols = [part.strip().split(" as ")[0] for part in imported.split(",") if part.strip() and part.strip() != "*"]
            required_symbols.setdefault(path, []).extend(symbols)
            if not (root / path).exists():
                add_target(path, "create", "required by supplied test import")
        for raw in re.findall(r"Path\(\s*[\"']([^\"']+\.(?:py|ts|js|json|toml))[\"']\s*\)", test_text):
            if not (root / raw).exists():
                add_target(raw, "create", "required by supplied test path assertion")

        # CLI integration is an explicit existing-file target.
        if re.search(r"\b(?:cli|command)\b", lower):
            for candidate in ("chimera/cli.py", "src/cli.py", "cli.py"):
                if (root / candidate).exists():
                    add_target(candidate, "edit", "task requires CLI integration")
                    break

        # Explicit workspace paths in the task are useful when tests do not expose targets.
        for path in re.findall(r"(?:`|\")((?:chimera|src|tests|docs)/[A-Za-z0-9_./-]+\.(?:py|ts|tsx|js|jsx|json|toml|md|yaml|yml))(?:`|\")", task):
            if path.startswith("tests/") and path in protected:
                continue
            add_target(path, "edit" if (root / path).exists() else "create", "explicitly named by task")

        required: List[str] = []
        # Literal assertions are part of the executable contract.
        for value in re.findall(r"assert\s+[\"']([^\"']{3,120})[\"']\s+in\s+text", test_text):
            required.append(value)

        required_mapping_keys: Dict[str, List[str]] = {}
        required_prefixes: Dict[str, Dict[str, str]] = {}
        required_call_arity: Dict[str, Dict[str, int]] = {}
        symbol_paths = {
            symbol: path for path, symbols in required_symbols.items() for symbol in symbols
        }
        for test_source in tests.values():
            for variable, symbol in re.findall(r"\b([A-Za-z_]\w*)\s*=\s*([A-Za-z_]\w*)\s*\(", test_source):
                path = symbol_paths.get(symbol)
                if not path:
                    continue
                keys = re.findall(rf"\b{re.escape(variable)}\s*\[\s*[\"']([^\"']+)[\"']\s*\]", test_source)
                if keys:
                    required_mapping_keys.setdefault(path, []).extend(keys)
                for key, prefix in re.findall(
                    rf"\b{re.escape(variable)}\s*\[\s*[\"']([^\"']+)[\"']\s*\]\s*\.startswith\(\s*[\"']([^\"']+)[\"']\s*\)",
                    test_source,
                ):
                    required_prefixes.setdefault(path, {})[key] = prefix
            try:
                test_tree = ast.parse(test_source)
            except SyntaxError:
                test_tree = None
            if test_tree:
                for call in (node for node in ast.walk(test_tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)):
                    symbol = call.func.id
                    path = symbol_paths.get(symbol)
                    if path:
                        observed = len(call.args)
                        current = required_call_arity.setdefault(path, {}).get(symbol)
                        required_call_arity[path][symbol] = observed if current is None else min(current, observed)

        required_calls: Dict[str, List[str]] = {}
        primary = next((target.path for target in targets if target.mode == "create" and target.path.endswith(".py")), None)
        if primary:
            calls: List[str] = []
            if "wal" in lower or "hash-chain" in lower or "hash chain" in lower:
                calls += ["WAL", "verify_chain"]
            if "ltl" in lower:
                calls += ["LTLMonitor", "check"]
            if "etas" in lower or "capability compliance" in lower:
                calls += ["check_spec_conformance"]
            if "code graph" in lower or "graph audit" in lower or "graph trail" in lower:
                calls += ["CodeGraph", "search"]
            if "branch" in lower:
                calls += ["TransactionalWorkspace", "list_branches"]
            if calls:
                required_calls[primary] = list(dict.fromkeys(calls))

        return cls(
            task=task, tests=tests, targets=targets, protected_paths=protected,
            required_literals=list(dict.fromkeys(required)),
            required_symbols={path: list(dict.fromkeys(symbols)) for path, symbols in required_symbols.items()},
            required_calls=required_calls,
            required_mapping_keys={path: list(dict.fromkeys(keys)) for path, keys in required_mapping_keys.items()},
            required_prefixes=required_prefixes,
            required_call_arity=required_call_arity,
        )

    def prompt(self) -> str:
        targets = "\n".join(f"- {target.mode}: {target.path} ({target.reason})" for target in self.targets) or "- infer the smallest target set"
        tests = "\n".join(f"--- {path} ---\n{text}" for path, text in self.tests.items())
        return (
            f"GOAL:\n{self.task}\n\n"
            f"CHANGE TARGETS (do not add unrelated files):\n{targets}\n\n"
            f"PROTECTED PATHS:\n{self.protected_paths or ['none']}\n\n"
            f"REQUIRED LITERALS:\n{self.required_literals or ['none']}\n\n"
            f"REQUIRED EXPORTED SYMBOLS:\n{self.required_symbols or {'none': []}}\n\n"
            f"REQUIRED REAL HARNESS API CALLS:\n{self.required_calls or {'none': []}}\n"
            f"REQUIRED RETURN-MAPPING KEYS:\n{self.required_mapping_keys or {'none': []}}\n"
            f"REQUIRED VALUE PREFIXES:\n{self.required_prefixes or {'none': {}}}\n"
            f"REQUIRED CALLABLE ARITIES (maximum required positional args):\n{self.required_call_arity or {'none': {}}}\n"
            "Do not reimplement or simulate these APIs; import and call the existing implementations.\n\n"
            f"EXECUTABLE ACCEPTANCE TESTS:\n{tests[:24_000]}"
        )

    def bind_branch(self, exists: Callable[[str], bool]) -> "TaskContract":
        """Reconcile inferred targets against a transactional branch view.

        Long-horizon phases commonly import artifacts created by a prior phase.
        The base workspace does not contain those overlay bytes, so a root-only
        compiler would incorrectly treat them as new mutation targets. Existing
        inferred-import targets are dropped; explicit targets become edits.
        """
        targets: list[ChangeTarget] = []
        for target in self.targets:
            present = bool(exists(target.path))
            explicit = target.path in self.task or pathlib.PurePosixPath(target.path).name in self.task
            if present and target.reason == "required by supplied test import" and not explicit:
                continue
            mode = "edit" if present else target.mode
            targets.append(ChangeTarget(target.path, mode, target.reason))
        return TaskContract(
            task=self.task,
            tests=dict(self.tests),
            targets=targets,
            protected_paths=list(self.protected_paths),
            required_literals=list(self.required_literals),
            required_symbols={path: list(symbols) for path, symbols in self.required_symbols.items()},
            required_calls={path: list(calls) for path, calls in self.required_calls.items()},
            required_mapping_keys={path: list(keys) for path, keys in self.required_mapping_keys.items()},
            required_prefixes={path: dict(values) for path, values in self.required_prefixes.items()},
            required_call_arity={path: dict(values) for path, values in self.required_call_arity.items()},
        )

    def compact_prompt(self) -> str:
        """Minimal complete contract for a one-target, independently tested patch.

        This intentionally removes explanatory headings and empty constraints;
        it does not remove target scope, protected paths, required symbols, or
        executable acceptance evidence.
        """
        targets = [target.path for target in self.targets]
        constraints: list[str] = [
            f"GOAL: {self.task}",
            f"TARGETS: {targets or ['infer smallest target']}",
            f"PROTECTED: {self.protected_paths or ['none']}",
        ]
        if self.required_symbols:
            constraints.append(f"EXPORTS: {self.required_symbols}")
        if self.required_calls:
            constraints.append(f"REQUIRED API CALLS: {self.required_calls}")
        if self.required_mapping_keys:
            constraints.append(f"RETURN KEYS: {self.required_mapping_keys}")
        if self.required_prefixes:
            constraints.append(f"RETURN PREFIXES: {self.required_prefixes}")
        if self.required_call_arity:
            constraints.append(f"CALL ARITIES: {self.required_call_arity}")
        tests = "\n".join(f"--- {path} ---\n{text}" for path, text in self.tests.items())
        constraints.append("TESTS (immutable):\n" + tests[:12_000])
        return "\n".join(constraints)


class PatchQualityGate:
    """Static admission checks before model bytes reach a branch overlay."""
    PLACEHOLDERS = (
        "TODO: implement", "YOUR CODE HERE", "<complete content>", "new/or/replaced/file",
        "COMPLETE FILE", "COMPLETE SOURCE", "EXACT UNIQUE OLD BLOCK", "NEW BLOCK",
    )

    def __init__(self, root: pathlib.Path, contract: TaskContract):
        self.root = pathlib.Path(root).resolve()
        self.contract = contract
        self.egress_guard = ArtifactEgressGuard()
        self.path_policy = PathPolicyResolver()

    @staticmethod
    def _invalid_escape_warning(content: str) -> tuple[int, str] | None:
        """Find compiler-level invalid string escapes before calling compile.

        CPython may emit a SyntaxWarning through a low-level compile path before
        Python's local warning capture can intercept it.  Token inspection
        gives the admission gate deterministic control: malformed candidate
        bytes are rejected without polluting the caller/test warning stream.
        """
        allowed = {"\\", "'", '"', "a", "b", "f", "n", "r", "t", "v", "x", "u", "U", "N", "\n", "\r", *"01234567"}
        try:
            tokens = tokenize.generate_tokens(io.StringIO(content).readline)
            for token in tokens:
                if token.type != tokenize.STRING:
                    continue
                value = token.string
                prefix_match = re.match(r"(?i)^([rubf]*)", value)
                prefix = prefix_match.group(1).lower() if prefix_match else ""
                if "r" in prefix:
                    continue
                body = value[len(prefix):]
                quote = body[:3] if body[:3] in {"'''", '\"\"\"'} else body[:1]
                if not quote or not body.endswith(quote):
                    continue
                literal = body[len(quote):-len(quote)]
                index = 0
                while index < len(literal):
                    if literal[index] != "\\":
                        index += 1
                        continue
                    if index + 1 >= len(literal):
                        break
                    escaped = literal[index + 1]
                    if escaped not in allowed:
                        return token.start[0], f"invalid escape sequence '\\{escaped}'"
                    index += 2
        except (tokenize.TokenError, IndentationError):
            # The compiler below is the authority for syntactic failure.
            return None
        return None

    @staticmethod
    def _python_error(path: str, content: str) -> str | None:
        if not path.endswith(".py"):
            return None
        warning = PatchQualityGate._invalid_escape_warning(content)
        if warning is not None:
            line, message = warning
            return f"{path}: Python SyntaxWarning line {line}: {message}"
        import warnings
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", SyntaxWarning)
                compile(content, path, "exec", dont_inherit=True)
            return None
        except SyntaxError as exc:
            return f"{path}: Python syntax error line {exc.lineno}: {exc.msg}"

    def validate(self, payload: Dict[str, Any]) -> Tuple[bool, List[str]]:
        errors: List[str] = []
        if not isinstance(payload, dict):
            return False, ["patch envelope must be an object"]
        files = payload.get("files", [])
        edits = payload.get("edits", [])
        insertions = payload.get("insertions", [])
        if not all(isinstance(group, list) for group in (files, edits, insertions)):
            return False, ["files, edits, and insertions must be lists"]
        if len(files) + len(edits) + len(insertions) > 12:
            errors.append("patch exceeds 12 operations")

        protected = set(self.contract.protected_paths)
        target_set = {target.path for target in self.contract.targets}
        self.last_path_policies: list[dict[str, Any]] = []
        for group_name, group in (("files", files), ("edits", edits), ("insertions", insertions)):
            for item in group:
                if not isinstance(item, dict) or not isinstance(item.get("path"), str):
                    errors.append(f"malformed {group_name} entry")
                    continue
                path = item["path"].replace("\\", "/").removeprefix("./")
                policy = self.path_policy.resolve(path)
                self.last_path_policies.append(policy.as_dict())
                if policy.explicit_task_path and not self.path_policy.task_names_path(self.contract.task, path):
                    errors.append(f"{path}: path policy {policy.policy_ids[0]} requires explicit task naming")
                if policy.independent_evidence and not self.contract.tests:
                    errors.append(f"{path}: path policy {policy.policy_ids[0]} requires independently executable acceptance evidence")
                if path in protected or any(path.startswith(p.rstrip("/") + "/") for p in protected):
                    errors.append(f"protected path modification: {path}")
                if target_set and path not in target_set and not path.startswith(".chimera/"):
                    errors.append(f"out-of-contract path: {path}")
                # Test harness configuration can alter how every test executes
                # (for example a pytest hook that reports success). Treat it as
                # test infrastructure, not ordinary coverage: it must be named
                # explicitly in the user task before a patch may touch it.
                if TestAntiGamingGuard.is_harness_file(path):
                    task_text = self.contract.task.lower()
                    if path.lower() not in task_text and pathlib.PurePosixPath(path).name.lower() not in task_text:
                        errors.append(f"{path}: test harness configuration requires an explicitly named task path")
                content = item.get("content") if group_name != "edits" else item.get("replace")
                if not isinstance(content, str):
                    errors.append(f"{path}: replacement/content must be a string")
                    continue
                if any(marker.lower() in content.lower() for marker in self.PLACEHOLDERS):
                    errors.append(f"{path}: placeholder content")
                egress = self.egress_guard.scan(content)
                if egress:
                    # Report only detector labels and short digests; never echo
                    # a credential-like match into a model repair prompt.
                    labels = ", ".join(f"{finding.kind}:{finding.digest}" for finding in egress)
                    errors.append(f"{path}: egress guard blocked credential-like artifact ({labels})")
                syntax_error = self._python_error(path, content) if group_name == "files" else None
                if syntax_error:
                    errors.append(syntax_error)
                if group_name == "files" and path.endswith(".py") and len(content.splitlines()) > 200:
                    errors.append(f"{path}: generated module exceeds 200-line scope budget")
                if group_name == "files" and path.endswith(".py") and not syntax_error:
                    tree = ast.parse(content, filename=path)
                    exported = {
                        node.name for node in tree.body
                        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                    }
                    exported.update(
                        target.id
                        for node in tree.body if isinstance(node, (ast.Assign, ast.AnnAssign))
                        for target in ((node.targets if isinstance(node, ast.Assign) else [node.target]))
                        if isinstance(target, ast.Name)
                    )
                    for symbol in self.contract.required_symbols.get(path, []):
                        if symbol not in exported:
                            errors.append(f"{path}: required exported symbol missing: {symbol}")
                    top_functions = {
                        node.name: node for node in tree.body
                        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                    }
                    for symbol, supported_arity in self.contract.required_call_arity.get(path, {}).items():
                        function = top_functions.get(symbol)
                        if function:
                            positional = len(function.args.posonlyargs) + len(function.args.args)
                            required_positional = max(0, positional - len(function.args.defaults))
                            if required_positional > supported_arity:
                                errors.append(
                                    f"{path}: {symbol} requires {required_positional} positional args but tests call it with {supported_arity}"
                                )
                    called: set[str] = set()
                    for node in ast.walk(tree):
                        if isinstance(node, ast.Call):
                            if isinstance(node.func, ast.Name):
                                called.add(node.func.id)
                            elif isinstance(node.func, ast.Attribute):
                                called.add(node.func.attr)
                    imported = set()
                    for node in tree.body:
                        if isinstance(node, ast.Import):
                            imported.update(alias.asname or alias.name.split(".")[0] for alias in node.names)
                        elif isinstance(node, ast.ImportFrom):
                            imported.update(alias.asname or alias.name for alias in node.names)
                    defined_functions = {
                        node.name for node in ast.walk(tree)
                        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                    }
                    unresolved_private = sorted(
                        name for name in called
                        if name.startswith("_") and name not in defined_functions and name not in imported
                    )
                    for name in unresolved_private:
                        errors.append(f"{path}: called private helper is not defined/imported: {name}")
                    for api in self.contract.required_calls.get(path, []):
                        if api not in called:
                            errors.append(f"{path}: required existing harness API is not called: {api}")
                    string_literals = {
                        node.value for node in ast.walk(tree)
                        if isinstance(node, ast.Constant) and isinstance(node.value, str)
                    }
                    for key in self.contract.required_mapping_keys.get(path, []):
                        if key not in string_literals:
                            errors.append(f"{path}: required return-mapping key missing: {key}")
                    dict_values: Dict[str, List[ast.AST]] = {}
                    for dictionary in (node for node in ast.walk(tree) if isinstance(node, ast.Dict)):
                        for key_node, value_node in zip(dictionary.keys, dictionary.values):
                            if isinstance(key_node, ast.Constant) and isinstance(key_node.value, str):
                                dict_values.setdefault(key_node.value, []).append(value_node)
                    for key, prefix in self.contract.required_prefixes.get(path, {}).items():
                        values = dict_values.get(key, [])
                        satisfied = False
                        for value in values:
                            if isinstance(value, ast.Constant) and isinstance(value.value, str) and value.value.startswith(prefix):
                                satisfied = True
                            rendered = ast.unparse(value) if hasattr(ast, "unparse") else ""
                            if repr(prefix) in rendered or (prefix == "hier-" and rendered.endswith(".id")):
                                satisfied = True
                        if not satisfied:
                            errors.append(f"{path}: return value for {key!r} must start with {prefix!r}")
                    if path.startswith("tests/") and not any(name.startswith("test_") for name in exported):
                        errors.append(f"{path}: generated test module has no top-level test_ function")
                # Calling the same acceptance suite from imported production code
                # creates recursive tests and is almost always a harness-gaming bug.
                invokes_pytest = re.search(r"(?:\bpytest\b|python[\s\"',-]+m[\s\"',-]+pytest)", content, re.IGNORECASE)
                references_tests = re.search(r"(?:tests/|[\"']tests[\"'])", content, re.IGNORECASE)
                if path.startswith("chimera/") and invokes_pytest and references_tests:
                    errors.append(f"{path}: recursive acceptance-test execution is forbidden")

        # Preview Python edits as complete modules so syntax/API removals are
        # caught before a sandbox/test run. This is a guard, not a behavioral
        # proof; tests still decide semantic correctness.
        try:
            from .semantic_delta import SemanticDeltaGuard
            previews: dict[str, tuple[str, str]] = {}
            for item in files:
                if isinstance(item, dict) and isinstance(item.get("path"), str) and isinstance(item.get("content"), str):
                    path = item["path"].replace("\\", "/").removeprefix("./")
                    if path.endswith(".py"):
                        before = (self.root / path).read_text(encoding="utf-8", errors="ignore") if (self.root / path).exists() else ""
                        previews[path] = (before, item["content"])
            for item in edits:
                if not isinstance(item, dict) or not all(isinstance(item.get(key), str) for key in ("path", "find", "replace")):
                    continue
                path = item["path"].replace("\\", "/").removeprefix("./")
                if not path.endswith(".py"):
                    continue
                before, current = previews.get(path, ((self.root / path).read_text(encoding="utf-8", errors="ignore") if (self.root / path).exists() else "", (self.root / path).read_text(encoding="utf-8", errors="ignore") if (self.root / path).exists() else ""))
                if current.count(item["find"]) == 1:
                    previews[path] = (before, current.replace(item["find"], item["replace"], 1))
            from .scope_budget import DiffBudget
            for path, (before, after) in previews.items():
                errors.extend(SemanticDeltaGuard().validate(path, before, after, self.contract.task))
                errors.extend(TestAntiGamingGuard.validate(path, before, after))
                budget = DiffBudget().check(before, after, len(self.contract.targets))
                if not budget.allowed:
                    errors.append(f"{path}: {budget.reason} ({budget.changed_lines}>{budget.limit} changed lines)")
        except Exception as exc:
            errors.append(f"semantic delta analysis failed: {type(exc).__name__}: {exc}")

        return not errors, errors
