"""Hierarchical Task Compiler for broad software-engineering objectives.

The compiler recursively turns an intent into milestones, components, and
bounded implementation atoms.  Model execution remains depth-1: recursion is
in the typed plan, not in an ever-growing model conversation.
"""
from __future__ import annotations

import hashlib
import pathlib
import re
import time
from collections import defaultdict
from typing import Any, Dict, Iterable, List, Optional, Tuple

from pydantic import BaseModel, Field

from .quality import ChangeTarget, TaskContract
from .task_slice import TaskSlice, serialize_overlapping_atoms


class AtomicityReport(BaseModel):
    is_atomic: bool
    score: float
    reasons: List[str] = Field(default_factory=list)


class TaskUnit(BaseModel):
    id: str
    title: str
    goal: str
    kind: str
    depth: int
    parent_id: Optional[str] = None
    children: List[str] = Field(default_factory=list)
    dependencies: List[str] = Field(default_factory=list)
    targets: List[str] = Field(default_factory=list)
    protected_paths: List[str] = Field(default_factory=list)
    acceptance: List[str] = Field(default_factory=list)
    effect: Dict[str, List[str]] = Field(default_factory=dict)
    test_command: str = "pytest -q"
    token_budget: int = 5_000
    risk: str = "medium"
    branch: str = ""
    graph_evidence: List[Dict[str, Any]] = Field(default_factory=list)
    atomicity: AtomicityReport = Field(default_factory=lambda: AtomicityReport(is_atomic=False, score=0.0))


class HierarchicalPlan(BaseModel):
    id: str
    task: str
    root_id: str
    units: Dict[str, TaskUnit]
    atoms: List[str]
    levels: List[List[str]]
    integration_branch: str
    created_at: str
    metadata: Dict[str, Any] = Field(default_factory=dict)


class HierarchicalTaskCompiler:
    """Compile broad intent into a bounded, dependency-safe atom DAG."""

    DOMAIN_PATTERNS: Dict[str, Tuple[Tuple[str, ...], int]] = {
        "contract": (("architecture", "design", "contract", "specification", "schema design"), 0),
        "data": (("database", "schema", "migration", "migrations", "model", "models", "persistence", "tenant table"), 1),
        "security": (("auth", "authentication", "authorization", "oauth", "rbac", "permission", "permissions", "security", "session", "token"), 2),
        "core": (("service", "backend", "business logic", "engine", "workflow", "processor", "compiler", "runtime"), 2),
        "api": (("api", "endpoint", "handler", "route", "middleware", "cli", "command"), 3),
        "frontend": (("frontend", "ui", "view", "page", "component", "dashboard"), 3),
        "observability": (("audit", "logging", "metrics", "telemetry", "trace", "monitor", "diagnostic", "diagnostics", "observability"), 3),
        "tests": (("test", "tests", "coverage", "regression", "regression tests", "integration test", "integration tests", "unit test", "unit tests"), 4),
        "docs": (("documentation", "docs", "readme", "guide", "guides"), 4),
        "delivery": (("deploy", "docker", "ci", "release", "packaging", "infrastructure"), 5),
    }

    DOMAIN_ACCEPTANCE: Dict[str, List[str]] = {
        "contract": ["interfaces and invariants are explicit", "no unresolved architectural choice remains"],
        "data": ["schema/migration is reversible", "persistence tests pass"],
        "security": ["deny by default", "cross-tenant or privilege boundaries are tested"],
        "core": ["core behavior is implemented", "unit tests pass"],
        "api": ["public interface is wired to domain behavior", "interface tests pass"],
        "frontend": ["user-visible behavior matches the requirement", "component tests pass"],
        "observability": ["events are structured and attributable", "audit/monitor checks pass"],
        "tests": ["new behavior and regressions are covered", "test suite is green"],
        "docs": ["documentation matches the implemented interface"],
        "delivery": ["build/deployment validation passes", "rollback path is documented"],
        "integration": ["all atom tests pass together", "root acceptance contract is satisfied"],
    }

    DOMAIN_FILE_HINTS: Dict[str, Tuple[str, ...]] = {
        "contract": ("architecture", "contract", "spec", "schema"),
        "data": ("model", "schema", "migration", "database", "db"),
        "security": ("auth", "oauth", "rbac", "permission", "security", "session", "token"),
        "core": ("service", "core", "workflow", "engine", "processor", "compiler", "hierarchical", "runtime", "rlm", "dag"),
        "api": ("api", "route", "router", "handler", "middleware", "cli"),
        "frontend": ("ui", "view", "page", "component", "frontend", "dashboard"),
        "observability": ("audit", "log", "metric", "trace", "telemetry", "monitor", "diagnostic", "health"),
        "tests": ("test", "spec"),
        "docs": ("readme", "docs", "guide"),
        "delivery": ("docker", "deploy", "ci", "release", "workflow"),
    }

    ACTION_WORDS = {
        "add", "build", "create", "implement", "change", "refactor", "migrate",
        "integrate", "secure", "document", "test", "deploy", "update", "remove",
        "support", "expose", "validate", "audit",
    }

    def __init__(self, root: pathlib.Path, graph=None, max_depth: int = 3, max_atoms: int = 14,
                 files_per_atom: int = 3):
        self.root = pathlib.Path(root).resolve()
        self.graph = graph
        self.max_depth = max(2, max_depth)
        self.max_atoms = max(2, max_atoms)
        self.files_per_atom = max(1, files_per_atom)

    @staticmethod
    def _contains_phrase(text: str, phrase: str) -> bool:
        pattern = r"(?<![a-z0-9_])" + re.escape(phrase).replace(r"\ ", r"\s+") + r"(?![a-z0-9_])"
        return re.search(pattern, text, re.IGNORECASE) is not None

    @staticmethod
    def _slug(text: str, limit: int = 32) -> str:
        slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-") or "task"
        return slug[:limit].rstrip("-")

    @staticmethod
    def _id(prefix: str, text: str) -> str:
        digest = hashlib.sha256(text.encode()).hexdigest()[:6]
        return f"{prefix}-{HierarchicalTaskCompiler._slug(text, 24)}-{digest}"

    def complexity(self, task: str) -> Dict[str, Any]:
        lower = task.lower()
        clauses = [part.strip() for part in re.split(r"[;\n]|\.(?=\s+[A-Z])", task) if len(part.strip()) > 8]
        domain_hits = {
            domain for domain, (patterns, _) in self.DOMAIN_PATTERNS.items()
            if any(self._contains_phrase(lower, pattern) for pattern in patterns)
        }
        actions = [token for token in re.findall(r"[a-z_]+", lower) if token in self.ACTION_WORDS]
        explicit_lists = len(re.findall(r"(?:^|\n)\s*(?:[-*]|\d+[.)])\s+", task))
        conjunctions = len(re.findall(r"\b(?:and|plus|along with|as well as)\b", lower))
        score = (
            min(4, len(clauses)) * 0.7
            + min(6, len(domain_hits)) * 0.8
            + min(6, len(set(actions))) * 0.45
            + min(5, conjunctions) * 0.25
            + explicit_lists * 0.5
            + (1.0 if len(task) > 280 else 0.0)
        )
        broad = score >= 4.2 or len(domain_hits) >= 4 or explicit_lists >= 3
        return {
            "score": round(score, 2), "broad": broad, "clauses": len(clauses),
            "domains": sorted(domain_hits), "actions": sorted(set(actions)),
            "conjunctions": conjunctions, "explicit_lists": explicit_lists,
        }

    def is_broad(self, task: str) -> bool:
        return bool(self.complexity(task)["broad"])

    def _domain_components(self, task: str) -> List[Tuple[str, str, int]]:
        lower = task.lower()
        components: List[Tuple[str, str, int]] = []
        for domain, (patterns, phase) in self.DOMAIN_PATTERNS.items():
            matched = [pattern for pattern in patterns if self._contains_phrase(lower, pattern)]
            if matched:
                phrase = ", ".join(matched[:4])
                components.append((domain, f"Implement the {domain} part of the objective, covering: {phrase}", phase))
        # If no domain taxonomy applies, preserve explicit clauses as components.
        if len(components) < 2:
            parts = re.split(r"(?:\n\s*[-*]\s+)|[;]|\b(?:and then|then)\b", task, flags=re.IGNORECASE)
            for index, part in enumerate(part.strip() for part in parts if len(part.strip()) > 12):
                components.append((f"component-{index + 1}", part, min(index, 4)))
        # Deduplicate highly overlapping goals by domain.
        seen = set()
        output = []
        for item in components:
            if item[0] not in seen:
                output.append(item); seen.add(item[0])
        return output[: self.max_atoms - 1]

    def _graph_hits(self, goal: str, limit: int = 8) -> List[Dict[str, Any]]:
        if self.graph is None:
            return []
        try:
            if not self.graph.graph.get("nodes"):
                self.graph.load()
        except Exception:
            try:
                self.graph.build()
            except Exception:
                return []
        stop = {"implement", "part", "objective", "covering", "with", "from", "into", "that", "this"}
        words = [
            word for word in re.findall(r"[a-z_][a-z0-9_]{2,}", goal.lower())
            if word not in stop
        ]
        quoted = re.findall(r"[`\"]([A-Za-z_][\w./-]+)[`\"]", goal)
        queries = list(dict.fromkeys([*quoted, *words[:10]]))
        hits: List[Dict[str, Any]] = []
        seen: set[str] = set()
        for query in queries:
            try:
                found = self.graph.search(query, limit=limit)
            except Exception:
                continue
            query_terms = set(re.findall(r"[a-z_][a-z0-9_]{2,}", query.lower()))
            for hit in found:
                searchable = " ".join(str(hit.get(key, "")) for key in ("name", "label", "file", "description")).lower()
                hit_terms = set(re.findall(r"[a-z_][a-z0-9_]{2,}", searchable))
                # Reject hash-embedding-only neighbors. Broad planning needs a
                # lexical/structural reason to touch an existing file.
                if not (query_terms & hit_terms):
                    continue
                if hit.get("id") not in seen:
                    hits.append(hit); seen.add(hit.get("id"))
            if len(hits) >= limit:
                break
        return hits[:limit]

    def _infer_targets(self, goal: str, domain: str, root_contract: TaskContract) -> Tuple[List[str], List[Dict[str, Any]]]:
        local_contract = TaskContract.compile(self.root, goal)
        hints = self.DOMAIN_FILE_HINTS.get(domain, ())
        targets: List[str] = []
        for candidate in local_contract.targets:
            lower_path = candidate.path.lower()
            name = pathlib.PurePosixPath(candidate.path).name.lower()
            if candidate.reason == "task requires CLI integration" and domain == "api":
                targets.append(candidate.path)
            elif candidate.reason == "explicitly named by task":
                targets.append(candidate.path)
            elif domain == "tests" and candidate.path.startswith("tests/"):
                targets.append(candidate.path)
            elif domain == "docs" and (candidate.path.startswith("docs/") or name.endswith(".md")):
                targets.append(candidate.path)
            elif domain not in {"tests", "docs", "delivery"} and any(hint in name or f"/{hint}" in lower_path for hint in hints):
                targets.append(candidate.path)
        explicit = re.findall(r"(?:`|\")((?:src|chimera|tests|docs|migrations)/[\w./-]+)(?:`|\")", goal)
        targets.extend(explicit)
        # Explicit root artifacts are authoritative and are assigned to the
        # milestone whose domain matches their path/name.
        for root_target in root_contract.targets:
            path = root_target.path
            lower_path = path.lower()
            name = pathlib.PurePosixPath(path).name.lower()
            matches_domain = (
                (domain == "tests" and path.startswith("tests/"))
                or (domain == "docs" and (path.startswith("docs/") or name.endswith(".md")))
                or (domain == "delivery" and any(token in lower_path for token in ("docker", ".github/workflows", "deploy", "ci")))
                or (
                    domain not in {"tests", "docs", "delivery"}
                    and not path.startswith(("tests/", "docs/"))
                    and any(hint in name or f"/{hint}" in lower_path for hint in hints)
                )
            )
            if matches_domain:
                targets.append(path)
        hits = self._graph_hits(goal, limit=self.files_per_atom)
        domain_hits = []
        for hit in hits:
            file = str(hit.get("file") or "")
            name = pathlib.PurePosixPath(file).name.lower()
            if file and (not hints or any(hint in name or f"/{hint}" in file.lower() for hint in hints)):
                domain_hits.append(hit)
                targets.append(file)
        hits = domain_hits

        # Tests/docs/delivery should produce their own artifacts, not edit an
        # arbitrary implementation file returned by semantic search.
        if domain == "tests":
            # Broad objectives should add focused coverage, not rewrite an
            # arbitrary existing regression test selected by retrieval.
            root_test_targets = {target.path for target in root_contract.targets if target.path.startswith("tests/")}
            targets = [
                target for target in targets
                if target.startswith("tests/") and (target in explicit or target in root_test_targets)
            ]
        elif domain == "docs":
            targets = [target for target in targets if target.startswith("docs/") or pathlib.PurePosixPath(target).name.lower().startswith("readme")]
        elif domain == "delivery":
            targets = [target for target in targets if any(part in target.lower() for part in ("docker", ".github/workflows", "deploy", "ci"))]

        # Domain-specific fallback targets only when graph/tests provide none.
        if not targets:
            feature = goal.split("covering:", 1)[-1].split(",", 1)[0].strip()
            if domain == "tests":
                feature = "integration"
            elif domain == "docs":
                feature = "project"
            elif domain == "delivery":
                feature = "deployment"
            slug = self._slug(feature or domain, 24).replace("-", "_")
            if domain == "tests":
                targets.append(f"tests/test_{slug}.py")
            elif domain == "docs":
                targets.append("README.md" if (self.root / "README.md").exists() else f"docs/{slug}.md")
            elif domain == "data":
                migration_dirs = [path for path in ("migrations", "alembic/versions", "db/migrations") if (self.root / path).exists()]
                targets.append(f"{migration_dirs[0]}/{slug}.py" if migration_dirs else f"migrations/{slug}.py")
            elif domain == "frontend":
                targets.append(f"src/{slug}.tsx")
            elif domain == "delivery":
                targets.append("Dockerfile" if "docker" in goal.lower() else ".github/workflows/ci.yml")
            else:
                package = "chimera" if (self.root / "chimera").exists() else "src"
                targets.append(f"{package}/{slug}.py")

        protected = set(root_contract.protected_paths)
        normalized = []
        for target in targets:
            if not target:
                continue
            clean = str(target).replace("\\", "/").removeprefix("./")
            if clean in protected or clean.startswith(".chimera/"):
                continue
            if clean not in normalized:
                normalized.append(clean)
        if not normalized:
            feature = goal.split("covering:", 1)[-1].split(",", 1)[0].strip()
            feature = {"tests": "integration", "docs": "project", "delivery": "deployment"}.get(domain, feature)
            slug = self._slug(feature or domain, 24).replace("-", "_")
            if domain == "tests":
                normalized = [f"tests/test_{slug}.py"]
            elif domain == "docs":
                normalized = ["README.md" if (self.root / "README.md").exists() else f"docs/{slug}.md"]
            elif domain == "data":
                migration_dirs = [path for path in ("migrations", "alembic/versions", "db/migrations") if (self.root / path).exists()]
                normalized = [f"{migration_dirs[0]}/{slug}.py" if migration_dirs else f"migrations/{slug}.py"]
            elif domain == "frontend":
                normalized = [f"src/{slug}.tsx"]
            elif domain == "delivery":
                normalized = ["Dockerfile" if "docker" in goal.lower() else ".github/workflows/ci.yml"]
            else:
                package = "chimera" if (self.root / "chimera").exists() else "src"
                normalized = [f"{package}/{slug}.py"]
        return normalized[: max(self.files_per_atom * 2, 4)], hits

    def _acceptance(self, domain: str, goal: str, targets: List[str]) -> List[str]:
        criteria = list(self.DOMAIN_ACCEPTANCE.get(domain, ["implementation matches the scoped goal", "relevant tests pass"]))
        if targets:
            criteria.append(f"changes remain within: {', '.join(targets)}")
        if any(word in goal.lower() for word in ("security", "auth", "permission", "tenant")):
            criteria.append("negative authorization/isolation cases are covered")
        return list(dict.fromkeys(criteria))

    def _test_command(self, domain: str, goal: str) -> str:
        tests_dir = self.root / "tests"
        if not tests_dir.exists():
            return "pytest -q"
        words = [
            word for word in re.findall(r"[a-z_][a-z0-9_]{3,}", goal.lower())
            if word not in {"implement", "objective", "covering", "part", "tests", "test", "the", "with"}
        ]
        matches = [
            path for path in sorted(tests_dir.glob("test*.py"))
            if any(word in path.name.lower() for word in words[:8])
        ]
        if matches:
            return "pytest -q " + " ".join(str(path.relative_to(self.root)) for path in matches[:3])
        return "pytest -q"

    def _atom_test_command(self, domain: str, goal: str, targets: List[str]) -> str:
        if domain == "tests" and targets:
            return "pytest -q " + " ".join(targets)
        selected = self._test_command(domain, goal)
        if selected != "pytest -q":
            return selected
        python_targets = [target for target in targets if target.endswith(".py")]
        if python_targets:
            return "python -m py_compile " + " ".join(python_targets)
        if targets:
            literals = ", ".join(repr(target) for target in targets)
            return f'python -c "from pathlib import Path; assert all(Path(p).exists() for p in [{literals}])"'
        return "pytest -q"

    def _atomicity(self, goal: str, targets: List[str], acceptance: List[str], depth: int) -> AtomicityReport:
        reasons = []
        action_count = len({word for word in re.findall(r"[a-z_]+", goal.lower()) if word in self.ACTION_WORDS})
        if action_count > 2:
            reasons.append(f"multiple actions ({action_count})")
        if len(targets) > self.files_per_atom:
            reasons.append(f"too many target files ({len(targets)}>{self.files_per_atom})")
        if not targets:
            reasons.append("no output artifact")
        if not acceptance:
            reasons.append("no deterministic acceptance criteria")
        if len(goal) > 360:
            reasons.append("goal too broad")
        score = 1.0 - min(1.0, 0.22 * len(reasons))
        atomic = not reasons or depth >= self.max_depth
        return AtomicityReport(is_atomic=atomic, score=round(score, 2), reasons=reasons)

    def _split_by_target(self, domain: str, goal: str, phase: int, targets: List[str], hits: List[Dict[str, Any]],
                         protected: List[str], integration_branch: str, parent_id: str) -> List[TaskUnit]:
        chunks = [targets[i:i + self.files_per_atom] for i in range(0, len(targets), self.files_per_atom)] or [[]]
        units = []
        for index, chunk in enumerate(chunks, 1):
            suffix = f" part {index}" if len(chunks) > 1 else ""
            atom_goal = goal + suffix
            atom_id = self._id("atom", f"{domain}:{atom_goal}:{chunk}")
            acceptance = self._acceptance(domain, atom_goal, chunk)
            effect = {"fs": chunk, "net": []}
            risk = "high" if domain in {"security", "data", "delivery"} else "medium" if domain not in {"docs", "tests"} else "low"
            units.append(TaskUnit(
                id=atom_id, title=f"{domain}{suffix}", goal=atom_goal, kind="atom", depth=2,
                parent_id=parent_id, targets=chunk, protected_paths=protected,
                acceptance=acceptance, effect=effect,
                test_command=self._atom_test_command(domain, atom_goal, chunk),
                token_budget=max(3_000, min(12_000, 2_500 + len(chunk) * 2_000)), risk=risk,
                branch=f"{integration_branch}--{self._slug(domain, 12)}-{index}-{atom_id[-6:]}",
                graph_evidence=[{"id": hit.get("id"), "file": hit.get("file"), "kind": hit.get("kind")} for hit in hits[:8]],
                atomicity=self._atomicity(atom_goal, chunk, acceptance, 2),
            ))
        return units

    @staticmethod
    def _topological_levels(atoms: Iterable[TaskUnit]) -> List[List[str]]:
        atom_map = {atom.id: atom for atom in atoms}
        remaining = set(atom_map)
        done: set[str] = set()
        levels: List[List[str]] = []
        while remaining:
            level = sorted(atom_id for atom_id in remaining if all(dep in done for dep in atom_map[atom_id].dependencies))
            if not level:
                raise ValueError("hierarchical compiler produced a dependency cycle")
            levels.append(level)
            done.update(level)
            remaining.difference_update(level)
        return levels

    def compile(self, task: str, integration_branch: str = "integration") -> HierarchicalPlan:
        complexity = self.complexity(task)
        root_contract = TaskContract.compile(self.root, task)
        root_id = self._id("root", task)
        units: Dict[str, TaskUnit] = {
            root_id: TaskUnit(
                id=root_id, title="root objective", goal=task, kind="root", depth=0,
                protected_paths=root_contract.protected_paths,
                acceptance=["all child atoms pass", "integration tests satisfy the root objective"],
                branch=integration_branch,
            )
        }

        atoms: List[TaskUnit] = []
        phases: Dict[str, int] = {}
        for domain, component_goal, phase in self._domain_components(task):
            component_id = self._id("milestone", f"{domain}:{component_goal}")
            targets, hits = self._infer_targets(component_goal, domain, root_contract)
            atom_units = self._split_by_target(
                domain, component_goal, phase, targets, hits,
                root_contract.protected_paths, integration_branch, component_id,
            )
            units[component_id] = TaskUnit(
                id=component_id, title=domain, goal=component_goal, kind="milestone", depth=1,
                parent_id=root_id, children=[atom.id for atom in atom_units],
                targets=targets, protected_paths=root_contract.protected_paths,
                acceptance=self._acceptance(domain, component_goal, targets), branch=integration_branch,
            )
            units[root_id].children.append(component_id)
            for atom in atom_units:
                units[atom.id] = atom
                atoms.append(atom)
                phases[atom.id] = phase
                if len(atoms) >= self.max_atoms - 1:
                    break
            if len(atoms) >= self.max_atoms - 1:
                break

        # Dependencies: preserve phase order only where semantically necessary.
        implementation = [atom for atom in atoms if atom.title.split()[0] not in {"tests", "docs", "delivery"}]
        for atom in atoms:
            domain = atom.title.split()[0]
            if domain in {"tests", "docs"}:
                atom.dependencies = [item.id for item in implementation]
            elif domain == "delivery":
                atom.dependencies = [item.id for item in atoms if item.id != atom.id]
            elif phases.get(atom.id, 0) >= 3:
                atom.dependencies = [
                    item.id for item in atoms
                    if item.id != atom.id and phases.get(item.id, 0) < phases.get(atom.id, 0)
                    and item.title.split()[0] in {"contract", "data", "security", "core"}
                ]

        # Interface atoms importing newly created modules must run after those
        # modules exist, so deterministic adapters can inspect the real function
        # signature instead of guessing how to call it.
        created_modules = {
            target.path for target in root_contract.targets
            if target.mode == "create" and target.path.startswith("chimera/") and target.path.endswith(".py")
        }
        module_atoms = [
            atom for atom in atoms
            if atom.title.split()[0] != "api" and any(target in created_modules for target in atom.targets)
        ]
        for atom in atoms:
            if atom.title.split()[0] == "api" and any(target.endswith("cli.py") for target in atom.targets):
                atom.dependencies.extend(item.id for item in module_atoms if item.id != atom.id)
                atom.dependencies = sorted(set(atom.dependencies))

        # Task slices are the parallel coding boundary. Exact same-file races
        # were already serialized here; this additionally catches parent/child
        # path overlap (for example ``src/auth`` versus ``src/auth/tokens.py``).
        # CAS merge remains the final race detector at integration time.
        slice_constraints = serialize_overlapping_atoms(atoms, phases)
        task_slices = {
            atom.id: TaskSlice.build(
                atom_id=atom.id, owned_paths=atom.targets,
                protected_paths=atom.protected_paths, acceptance=atom.acceptance,
                test_command=atom.test_command, integration_branch=atom.branch or integration_branch,
            ).model_dump(mode="json")
            for atom in atoms
        }
        for atom in atoms:
            units[atom.id] = atom

        integration_id = self._id("atom", task + ":integration")
        integration = TaskUnit(
            id=integration_id, title="integration", goal="Integrate all verified atoms and satisfy the root acceptance contract",
            kind="integration", depth=1, parent_id=root_id,
            dependencies=[atom.id for atom in atoms], targets=[], protected_paths=root_contract.protected_paths,
            acceptance=self.DOMAIN_ACCEPTANCE["integration"], effect={"fs": [], "net": []},
            test_command="pytest -q", token_budget=2_000, risk="high",
            branch=integration_branch, atomicity=AtomicityReport(is_atomic=True, score=1.0),
        )
        units[integration_id] = integration
        units[root_id].children.append(integration_id)
        atoms.append(integration)

        levels = self._topological_levels(atoms)
        return HierarchicalPlan(
            id=self._id("hier", task + str(time.time_ns())), task=task, root_id=root_id,
            units=units, atoms=[atom.id for atom in atoms], levels=levels,
            integration_branch=integration_branch,
            created_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            metadata={
                "complexity": complexity, "max_depth": self.max_depth, "max_atoms": self.max_atoms,
                "files_per_atom": self.files_per_atom, "model_execution_depth": 1,
                "task_slices": task_slices,
                "task_slice_serialization": slice_constraints,
                "recursive_plan_depth": max((unit.depth for unit in units.values()), default=0),
                "root_contract": {
                    "targets": [target.__dict__ for target in root_contract.targets],
                    "protected_paths": root_contract.protected_paths,
                    "required_symbols": root_contract.required_symbols,
                    "required_calls": root_contract.required_calls,
                },
            },
        )
