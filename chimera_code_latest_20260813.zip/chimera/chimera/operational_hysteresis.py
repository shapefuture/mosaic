"""Advisory-only hysteresis telemetry for operational measurements.

This module can recommend which already-authorized operational variant appears
healthier under fresh paired measurements.  It cannot accept a candidate,
change a model route, alter a policy, or call Chimera's sealed promotion code.
Correctness, protected tests, oracle receipts, evaluator epochs, and promotion
constraints remain separate authority.
"""
from __future__ import annotations

from collections import deque
import math
import pathlib
import time
from typing import Deque, Literal

from pydantic import BaseModel, ConfigDict, Field

from .wal import WAL, WALIntegrityError


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class OperationalHysteresisPolicy(_FrozenModel):
    min_samples: int = Field(default=100, ge=3)
    window_size: int = Field(default=256, ge=3)
    promote_margin: float = Field(default=0.10, gt=0.0, lt=1.0)
    demote_margin: float = Field(default=0.05, gt=0.0, lt=1.0)
    dwell_windows: int = Field(default=3, ge=1)
    cooldown_seconds: float = Field(default=60.0, ge=0.0)
    max_sample_age_seconds: float = Field(default=300.0, gt=0.0)

    def model_post_init(self, __context: object) -> None:
        if self.demote_margin >= self.promote_margin:
            raise ValueError("demote_margin must be smaller than promote_margin")
        if self.window_size < self.min_samples:
            raise ValueError("window_size must be at least min_samples")


class OperationalHysteresisReceipt(_FrozenModel):
    surface: str
    evaluation_frame: str
    observed_at: float
    state: Literal["cold", "evaluating", "advisory-candidate", "cooldown"]
    recommendation: Literal["control", "candidate"]
    control_samples: int
    candidate_samples: int
    control_p95: float | None = None
    control_p99: float | None = None
    candidate_p95: float | None = None
    candidate_p99: float | None = None
    consecutive_wins: int
    cooldown_remaining_seconds: float
    frame_reset: bool = False
    advisory_only: bool = True
    promotion_authority: bool = False


class _MetricWindow:
    def __init__(self, capacity: int, max_age: float) -> None:
        self.capacity = capacity
        self.max_age = max_age
        self.samples: Deque[tuple[float, float]] = deque()
        self.pushed = 0

    def add(self, value: float, observed_at: float) -> None:
        self.samples.append((float(value), float(observed_at)))
        while len(self.samples) > self.capacity:
            self.samples.popleft()
        self.pushed += 1

    def fresh(self, now: float) -> list[float]:
        cutoff = now - self.max_age
        return [value for value, observed_at in self.samples if observed_at >= cutoff]

    def percentile(self, percentile: float, now: float) -> float | None:
        values = sorted(self.fresh(now))
        if not values:
            return None
        index = min(len(values) - 1, max(0, math.ceil(percentile / 100 * len(values)) - 1))
        return values[index]


class _SurfaceState:
    def __init__(self, frame: str, policy: OperationalHysteresisPolicy) -> None:
        self.frame = frame
        self.control = _MetricWindow(policy.window_size, policy.max_sample_age_seconds)
        self.candidate = _MetricWindow(policy.window_size, policy.max_sample_age_seconds)
        self.state: Literal["cold", "evaluating", "advisory-candidate", "cooldown"] = "cold"
        self.consecutive_wins = 0
        self.cooldown_until = 0.0
        self.last_control_pushed = 0
        self.last_candidate_pushed = 0


class OperationalHysteresis:
    """Pure in-process state machine; results remain advisory receipts."""

    def __init__(self, policy: OperationalHysteresisPolicy | None = None):
        self.policy = policy or OperationalHysteresisPolicy()
        self._states: dict[str, _SurfaceState] = {}
        self._last_now = float("-inf")

    def observe(
        self,
        *,
        surface: str,
        evaluation_frame: str,
        control_value: float,
        candidate_value: float,
        observed_at: float | None = None,
    ) -> OperationalHysteresisReceipt:
        if not surface or not evaluation_frame:
            raise ValueError("surface and evaluation_frame are required")
        if not all(math.isfinite(value) and value >= 0 for value in (control_value, candidate_value)):
            raise ValueError("operational values must be finite and non-negative")
        raw_now = time.time() if observed_at is None else float(observed_at)
        now = max(raw_now, self._last_now)
        self._last_now = now
        prior = self._states.get(surface)
        frame_reset = prior is not None and prior.frame != evaluation_frame
        if prior is None or frame_reset:
            state = _SurfaceState(evaluation_frame, self.policy)
            self._states[surface] = state
        else:
            state = prior
        state.control.add(control_value, now)
        state.candidate.add(candidate_value, now)
        control_values = state.control.fresh(now)
        candidate_values = state.candidate.fresh(now)
        control_p95 = state.control.percentile(95, now)
        control_p99 = state.control.percentile(99, now)
        candidate_p95 = state.candidate.percentile(95, now)
        candidate_p99 = state.candidate.percentile(99, now)
        recommendation: Literal["control", "candidate"] = "control"

        if state.cooldown_until > now:
            state.state = "cooldown"
            state.consecutive_wins = 0
        elif len(control_values) < self.policy.min_samples or len(candidate_values) < self.policy.min_samples:
            state.state = "cold"
            state.consecutive_wins = 0
        else:
            assert control_p95 is not None and control_p99 is not None
            assert candidate_p95 is not None and candidate_p99 is not None
            regressed = (
                candidate_p95 > control_p95 * (1 + self.policy.demote_margin)
                or candidate_p99 > control_p99 * (1 + self.policy.demote_margin)
            )
            winning = (
                control_p95 >= 1e-9 and control_p99 >= 1e-9
                and candidate_p95 <= control_p95 * (1 - self.policy.promote_margin)
                and candidate_p99 <= control_p99 * (1 - self.policy.promote_margin)
            )
            if state.state == "advisory-candidate":
                if regressed:
                    state.state = "cooldown"
                    state.cooldown_until = now + self.policy.cooldown_seconds
                    state.consecutive_wins = 0
                else:
                    recommendation = "candidate"
            else:
                has_new_pair = (
                    state.control.pushed > state.last_control_pushed
                    and state.candidate.pushed > state.last_candidate_pushed
                )
                if winning and not regressed and has_new_pair:
                    state.last_control_pushed = state.control.pushed
                    state.last_candidate_pushed = state.candidate.pushed
                    state.consecutive_wins += 1
                    if state.consecutive_wins >= self.policy.dwell_windows:
                        state.state = "advisory-candidate"
                        recommendation = "candidate"
                    else:
                        state.state = "evaluating"
                else:
                    state.consecutive_wins = 0
                    state.state = "evaluating"
        if state.state == "advisory-candidate":
            recommendation = "candidate"
        remaining = max(0.0, state.cooldown_until - now)
        return OperationalHysteresisReceipt(
            surface=surface,
            evaluation_frame=evaluation_frame,
            observed_at=now,
            state=state.state,
            recommendation=recommendation,
            control_samples=len(control_values),
            candidate_samples=len(candidate_values),
            control_p95=control_p95,
            control_p99=control_p99,
            candidate_p95=candidate_p95,
            candidate_p99=candidate_p99,
            consecutive_wins=state.consecutive_wins,
            cooldown_remaining_seconds=remaining,
            frame_reset=frame_reset,
        )


class OperationalHysteresisLedger:
    """WAL-backed telemetry convenience wrapper; no automatic consumer exists."""

    def __init__(self, root: pathlib.Path, policy: OperationalHysteresisPolicy | None = None):
        self.root = pathlib.Path(root).resolve()
        self.policy = policy or OperationalHysteresisPolicy()
        self.wal = WAL(self.root)
        self.engine = OperationalHysteresis(self.policy)
        self._restore()

    def _restore(self) -> None:
        try:
            valid, _bad = self.wal.verify_chain()
            if not valid:
                return
            rows = self.wal.replay(kind="operational_hysteresis")
        except WALIntegrityError:
            return
        for row in rows:
            data = row.get("data", {})
            if not isinstance(data, dict) or data.get("event") != "observed":
                continue
            try:
                self.engine.observe(
                    surface=str(data["surface"]), evaluation_frame=str(data["evaluation_frame"]),
                    control_value=float(data["control_value"]), candidate_value=float(data["candidate_value"]),
                    observed_at=float(data["observed_at"]),
                )
            except (KeyError, TypeError, ValueError):
                continue

    def observe(self, **kwargs: object) -> OperationalHysteresisReceipt:
        receipt = self.engine.observe(**kwargs)  # type: ignore[arg-type]
        self.wal.append("operational_hysteresis", {
            "event": "observed",
            "surface": receipt.surface,
            "evaluation_frame": receipt.evaluation_frame,
            "control_value": float(kwargs["control_value"]),
            "candidate_value": float(kwargs["candidate_value"]),
            "observed_at": receipt.observed_at,
            "receipt": receipt.model_dump(mode="json"),
        })
        return receipt
