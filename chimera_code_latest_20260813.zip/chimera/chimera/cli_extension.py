"""Optimization and skill extension CLI commands."""
from __future__ import annotations

import json
import pathlib

import click
from rich.json import JSON


def register(main: click.Group, *, console, cli_root) -> None:
    _cli_root = cli_root

    @main.group("optimize")
    def optimize_group():
        """Long-running multi-objective optimization utilities."""
        pass

    @optimize_group.command("qualify")
    @click.argument("profile", type=click.Path(exists=True, dir_okay=False, path_type=pathlib.Path))
    def optimize_qualify(profile):
        """Choose the simplest suitable solver before spending evolution budget."""
        from .optimization_qualifier import ProblemProfile, qualify
        decision = qualify(ProblemProfile.model_validate(json.loads(profile.read_text())))
        console.print(JSON(decision.model_dump_json(indent=2)))

    @optimize_group.command("techniques")
    @click.option("--tag", "tags", multiple=True, required=True)
    @click.option("--precondition", "preconditions", multiple=True)
    def optimize_techniques(tags, preconditions):
        """Retrieve evidence-bound far-transfer hypotheses by structural tags."""
        from .technique_transfer import TechniqueLibrary
        library = TechniqueLibrary(_cli_root()); library.bootstrap()
        console.print(JSON(json.dumps([item.model_dump(mode="json") for item in library.retrieve(tags, preconditions)], indent=2)))

    @main.group("skills")
    def skills_group():
        """Signed executable skill trust/install/rollback."""
        pass

    @skills_group.command("trust-key")
    @click.argument("key_id")
    @click.argument("public_key")
    @click.option("--actor", required=True)
    def skills_trust_key(key_id, public_key, actor):
        from .skills import SkillTrustStore
        SkillTrustStore(_cli_root()).add_key(key_id, public_key, actor=actor)
        console.print("[green]skill trust key added[/green]")

    @skills_group.command("install")
    @click.argument("package", type=click.Path(exists=True, file_okay=False, path_type=pathlib.Path))
    @click.option("--fs-allow", multiple=True, required=True)
    def skills_install(package, fs_allow):
        from .effects import CapabilitySet
        from .skills import SkillInstaller
        result = SkillInstaller(_cli_root()).install(package, capability=CapabilitySet(fs_allow=list(fs_allow)))
        console.print(JSON(json.dumps(result, indent=2)))

    @skills_group.command("rollback")
    @click.argument("name")
    @click.option("--to", "to_version", default=None)
    def skills_rollback(name, to_version):
        from .skills import SkillInstaller
        console.print(JSON(json.dumps(SkillInstaller(_cli_root()).rollback(name, to_version=to_version), indent=2)))

