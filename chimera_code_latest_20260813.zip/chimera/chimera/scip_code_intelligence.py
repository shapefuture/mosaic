"""Provenance-bound SCIP index producer/consumer and verified mapping bridge."""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import subprocess
import uuid
from typing import Any, Callable, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .generated_code_mapping import GeneratedMappingIndex, SourceRange
from .semantic_code_intelligence import WorkspaceSnapshotter


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


def _sha(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _digest(value: str) -> str:
    text = str(value)
    if not text.startswith("sha256:") or len(text) != 71 or any(c not in "0123456789abcdef" for c in text[7:]):
        raise ValueError("digest must use sha256:<64 lowercase hex>")
    return text


class SCIPToolchainSpec(_FrozenModel):
    producer_id: str
    producer_version: str
    producer_entrypoint: str
    producer_entrypoint_digest: str
    argv: tuple[str, ...] = Field(min_length=1)
    decoder_module: str
    decoder_module_digest: str

    _producer_digest = field_validator("producer_entrypoint_digest")(_digest)
    _decoder_digest = field_validator("decoder_module_digest")(_digest)


class SCIPIndexManifest(_FrozenModel):
    schema_version: Literal["chimera.scip-index-manifest.v1"] = "chimera.scip-index-manifest.v1"
    source_snapshot_digest: str
    index_digest: str
    index_size: int = Field(ge=0)
    producer_id: str
    producer_version: str
    producer_entrypoint_digest: str
    decoder_module_digest: str
    command_digest: str
    verified_generator_mapping_digests: tuple[str, ...] = ()

    _source = field_validator("source_snapshot_digest")(_digest)
    _index = field_validator("index_digest")(_digest)
    _producer = field_validator("producer_entrypoint_digest")(_digest)
    _decoder = field_validator("decoder_module_digest")(_digest)
    _command = field_validator("command_digest")(_digest)


class SCIPLocation(_FrozenModel):
    path: str
    start_line: int = Field(ge=0)
    start_character: int = Field(ge=0)
    end_line: int = Field(ge=0)
    end_character: int = Field(ge=0)
    symbol: str
    roles: int = Field(ge=0)


class SCIPQueryReceipt(_FrozenModel):
    status: Literal["completed", "rejected", "not-found", "error"]
    operation: Literal["definitions", "references", "imports"]
    source_snapshot_digest: str
    observed_snapshot_digest: str
    index_digest: str
    symbol: str | None
    locations: tuple[SCIPLocation, ...] = ()
    stale_state_rejected: bool = False
    reason: str

    _source = field_validator("source_snapshot_digest")(_digest)
    _observed = field_validator("observed_snapshot_digest")(_digest)
    _index = field_validator("index_digest")(_digest)


class SCIPIndexProducer:
    """Run a pinned producer and atomically publish index plus source manifest."""

    def __init__(self, root: pathlib.Path, spec: SCIPToolchainSpec) -> None:
        self.root = pathlib.Path(root).resolve()
        self.spec = spec
        self.runtime = self.root / ".chimera" / "scip"

    def build(
        self,
        *,
        timeout_seconds: float = 120,
        verified_generator_mapping_digests: tuple[str, ...] = (),
    ) -> SCIPIndexManifest:
        entrypoint = pathlib.Path(self.spec.producer_entrypoint).resolve()
        decoder = pathlib.Path(self.spec.decoder_module).resolve()
        if _sha(entrypoint.read_bytes()) != self.spec.producer_entrypoint_digest:
            raise RuntimeError("SCIP producer entrypoint digest drifted")
        if _sha(decoder.read_bytes()) != self.spec.decoder_module_digest:
            raise RuntimeError("SCIP decoder module digest drifted")
        snapshot = WorkspaceSnapshotter(self.root).capture()
        self.runtime.mkdir(parents=True, exist_ok=True)
        temporary = self.runtime / f"index.{uuid.uuid4().hex}.tmp.scip"
        final = self.runtime / "index.scip"
        manifest_path = self.runtime / "manifest.json"
        argv = [item.replace("{workspace}", str(self.root)).replace("{output}", str(temporary)) for item in self.spec.argv]
        command_digest = _sha(json.dumps(list(self.spec.argv), separators=(",", ":")).encode("utf-8"))
        try:
            result = subprocess.run(
                argv, cwd=self.root, capture_output=True, text=True,
                timeout=timeout_seconds, shell=False,
                env={"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": str(self.runtime)},
            )
            if result.returncode != 0 or not temporary.is_file():
                raise RuntimeError(f"SCIP producer failed ({result.returncode}): {result.stderr[-1000:]}")
            data = temporary.read_bytes()
            manifest = SCIPIndexManifest(
                source_snapshot_digest=snapshot.digest,
                index_digest=_sha(data),
                index_size=len(data),
                producer_id=self.spec.producer_id,
                producer_version=self.spec.producer_version,
                producer_entrypoint_digest=self.spec.producer_entrypoint_digest,
                decoder_module_digest=self.spec.decoder_module_digest,
                command_digest=command_digest,
                verified_generator_mapping_digests=tuple(sorted(set(verified_generator_mapping_digests))),
            )
            os.replace(temporary, final)
            manifest_tmp = manifest_path.with_suffix(".tmp")
            manifest_tmp.write_text(manifest.model_dump_json(indent=2), encoding="utf-8")
            os.replace(manifest_tmp, manifest_path)
            return manifest
        finally:
            if temporary.exists():
                temporary.unlink()


class SCIPIndexConsumer:
    """Read-only semantic definitions/references/imports over a verified index."""

    def __init__(
        self,
        root: pathlib.Path,
        manifest: SCIPIndexManifest,
        decoded_index: dict[str, Any],
    ) -> None:
        self.root = pathlib.Path(root).resolve()
        self.manifest = manifest
        self.decoded = decoded_index

    @classmethod
    def load(cls, root: pathlib.Path, spec: SCIPToolchainSpec) -> "SCIPIndexConsumer":
        base = pathlib.Path(root).resolve()
        runtime = base / ".chimera" / "scip"
        manifest = SCIPIndexManifest.model_validate_json((runtime / "manifest.json").read_text(encoding="utf-8"))
        index = runtime / "index.scip"
        if _sha(index.read_bytes()) != manifest.index_digest:
            raise RuntimeError("SCIP index bytes do not match the manifest")
        decoder = pathlib.Path(spec.decoder_module).resolve()
        if _sha(decoder.read_bytes()) != manifest.decoder_module_digest:
            raise RuntimeError("SCIP decoder drifted from the index manifest")
        script = (
            "const fs=require('fs');"
            "const {scip}=require(process.argv[1]);"
            "const x=scip.Index.deserializeBinary(fs.readFileSync(process.argv[2]));"
            "process.stdout.write(JSON.stringify(x.toObject()));"
        )
        result = subprocess.run(
            ["node", "-e", script, str(decoder), str(index)],
            capture_output=True, text=True, timeout=30, shell=False,
            env={"PATH": os.environ.get("PATH", "/usr/bin:/bin")},
        )
        if result.returncode != 0:
            raise RuntimeError("SCIP decoder failed: " + result.stderr[-1000:])
        return cls(base, manifest, json.loads(result.stdout))

    def query(
        self,
        *,
        operation: Literal["definitions", "references", "imports"],
        path: str,
        line: int,
        character: int,
    ) -> SCIPQueryReceipt:
        observed = WorkspaceSnapshotter(self.root).capture()
        if observed.digest != self.manifest.source_snapshot_digest:
            return SCIPQueryReceipt(
                status="rejected", operation=operation,
                source_snapshot_digest=self.manifest.source_snapshot_digest,
                observed_snapshot_digest=observed.digest,
                index_digest=self.manifest.index_digest,
                symbol=None, stale_state_rejected=True,
                reason="SCIP source snapshot is stale",
            )
        documents = self.decoded.get("documents", [])
        target = next((item for item in documents if item.get("relative_path") == path), None)
        if not isinstance(target, dict):
            return self._not_found(operation, observed.digest, "document is absent from SCIP index")
        occurrence = next((
            item for item in target.get("occurrences", [])
            if self._contains(item.get("range", []), line, character)
        ), None)
        if not isinstance(occurrence, dict) or not occurrence.get("symbol"):
            return self._not_found(operation, observed.digest, "no SCIP symbol at requested position")
        symbol = str(occurrence["symbol"])
        rows: list[SCIPLocation] = []
        for document in documents:
            relative = str(document.get("relative_path") or "")
            for item in document.get("occurrences", []):
                if item.get("symbol") != symbol:
                    continue
                roles = int(item.get("symbol_roles") or 0)
                if operation == "definitions" and not roles & 1:
                    continue
                if operation == "references" and roles & 1:
                    continue
                if operation == "imports" and not roles & 2:
                    continue
                start_line, start_char, end_line, end_char = self._range(item.get("range", []))
                rows.append(SCIPLocation(
                    path=relative, start_line=start_line, start_character=start_char,
                    end_line=end_line, end_character=end_char,
                    symbol=symbol, roles=roles,
                ))
        rows.sort(key=lambda item: (item.path, item.start_line, item.start_character))
        return SCIPQueryReceipt(
            status="completed", operation=operation,
            source_snapshot_digest=self.manifest.source_snapshot_digest,
            observed_snapshot_digest=observed.digest,
            index_digest=self.manifest.index_digest,
            symbol=symbol, locations=tuple(rows),
            reason="verified SCIP index query",
        )

    def _not_found(self, operation: str, observed: str, reason: str) -> SCIPQueryReceipt:
        return SCIPQueryReceipt(
            status="not-found", operation=operation,
            source_snapshot_digest=self.manifest.source_snapshot_digest,
            observed_snapshot_digest=observed,
            index_digest=self.manifest.index_digest,
            symbol=None, reason=reason,
        )

    @staticmethod
    def _range(value: list[int]) -> tuple[int, int, int, int]:
        if len(value) == 3:
            return int(value[0]), int(value[1]), int(value[0]), int(value[2])
        if len(value) == 4:
            return tuple(map(int, value))  # type: ignore[return-value]
        raise ValueError("invalid SCIP occurrence range")

    @classmethod
    def _contains(cls, value: list[int], line: int, character: int) -> bool:
        try:
            sl, sc, el, ec = cls._range(value)
        except ValueError:
            return False
        return (sl, sc) <= (line, character) <= (el, ec)


class SCIPGeneratedMappingBridge:
    """Bridge only already-verified explicit generated mapping edges."""

    def __init__(self, scip: SCIPIndexConsumer, mapping: GeneratedMappingIndex) -> None:
        if mapping.contract.digest not in scip.manifest.verified_generator_mapping_digests:
            raise ValueError("SCIP manifest is not provenance-bound to this verified generator mapping")
        self.scip = scip
        self.mapping = mapping

    def generated_to_source(self, *, path: str, line: int, character: int) -> tuple[SourceRange, ...]:
        return self.mapping.generated_to_source(path=path, line=line, character=character)
