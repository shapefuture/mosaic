"""Independent patch quality rubric; not an optimization target for self-heal."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping

@dataclass(frozen=True)
class RubricResult:
    score: float
    passed: bool
    findings: tuple[str,...]
    def as_dict(self): return asdict(self)

class PatchReviewRubric:
    PLACEHOLDERS=("TODO: implement","YOUR CODE HERE","<complete content>","pass #")
    def score(self, *, task: str, diff: Mapping[str,Any]|None, answer: str="") -> RubricResult:
        findings=[]; score=1.0
        ops=(diff or {}).get("ops",[]) if isinstance(diff,Mapping) else []
        user_ops=[op for op in ops if isinstance(op,Mapping) and not str(op.get("path","")).startswith(".chimera/")]
        if len(user_ops)>8: findings.append("large diffuse patch"); score-=0.35
        text=answer+"\n"+"\n".join(str(op) for op in user_ops)
        if any(p in text for p in self.PLACEHOLDERS): findings.append("placeholder content"); score-=0.35
        if any("auth" in str(op.get("path","")) for op in user_ops) and "test" not in text.lower(): findings.append("security-sensitive change lacks test mention"); score-=0.15
        if any(str(op.get("path","")).startswith(("tests/",".github/","pyproject.toml")) for op in user_ops):
            findings.append("integrity violation: patch modifies verification/support files")
            score -= 1.25
        if not user_ops and any(w in task.lower() for w in ("fix","implement","add")): findings.append("mutation-shaped task has no user-file diff"); score-=0.35
        score=max(0.0,score)
        return RubricResult(score,score>=0.75,tuple(findings))
