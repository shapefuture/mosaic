"""Release provenance CLI commands."""
from __future__ import annotations

import pathlib

import click
from rich.json import JSON


def register(main: click.Group, *, console) -> None:
    @main.group("release")
    def release_group():
        """Build and consume signed, reproducible release provenance."""
        pass


    @release_group.command("build-provenance")
    @click.option("--workspace", default=".")
    @click.option("--output", type=click.Path(path_type=pathlib.Path), required=True)
    @click.option("--builder-id", required=True)
    @click.option("--source-uri", required=True)
    @click.option("--source-revision", required=True)
    @click.option("--signing-key-env", required=True, help="Environment variable containing a raw Ed25519 private key in base64")
    @click.option("--signing-scope", default="ci-release-builder", show_default=True)
    def release_build_provenance(workspace, output, builder_id, source_uri, source_revision, signing_key_env, signing_scope):
        import os
        from .context_evidence import ContextSigner
        from .release_provenance import ReleaseProvenanceBuilder

        encoded = os.environ.get(signing_key_env)
        if not encoded:
            raise click.UsageError(f"release signing key environment variable is absent: {signing_key_env}")
        signer = ContextSigner.from_base64_private_key(encoded, scope=signing_scope)
        try:
            receipt = ReleaseProvenanceBuilder(pathlib.Path(workspace)).build(
                output=output, signer=signer, builder_id=builder_id,
                source_uri=source_uri, source_revision=source_revision,
            )
        except (ValueError, FileExistsError) as exc:
            raise click.UsageError(str(exc)) from exc
        console.print(JSON(receipt.model_dump_json(indent=2)))


    @release_group.command("verify-provenance")
    @click.option("--workspace", default=".")
    @click.option("--bundle", type=click.Path(path_type=pathlib.Path), required=True)
    @click.option("--trusted-key-id", "trusted_key_ids", multiple=True, required=True)
    @click.option("--expected-builder-id", "expected_builder_ids", multiple=True, required=True)
    @click.option("--skip-source-bytes", is_flag=True, help="Verify bundle/signature only, not the current source tree")
    def release_verify_provenance(workspace, bundle, trusted_key_ids, expected_builder_ids, skip_source_bytes):
        from .release_provenance import ReleaseProvenanceVerifier

        receipt = ReleaseProvenanceVerifier(
            pathlib.Path(workspace), trusted_key_ids=set(trusted_key_ids),
            expected_builder_ids=set(expected_builder_ids),
        ).verify(bundle, verify_source_bytes=not skip_source_bytes)
        console.print(JSON(receipt.model_dump_json(indent=2)))
        if not receipt.verified:
            raise click.ClickException("release provenance verification failed")


