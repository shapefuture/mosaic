"""Antifragile hexagonal architecture audit for Chimera.

This is an evidence gate, not a style essay.  It checks that recent cloud-scale
and optional-stack work remains port/adapters oriented, local-first, and guarded
by benchmark/promotion receipts instead of becoming hidden mandatory runtime
coupling.
"""
from __future__ import annotations

import ast
import pathlib
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class ArchitectureCheck:
    name: str
    status: str  # pass | fail | warn
    evidence: str
    action: str


class AntifragileArchitectureAudit:
    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def run(self) -> dict[str, Any]:
        checks = [
            self._file_exists("stack-alternatives-port", "chimera/stack_alternatives.py", "optional stack alternatives are represented as data, not imports in the core"),
            self._file_exists("benchmark-control-plane", "chimera/stack_benchmarks.py", "replacement candidates require benchmark receipts"),
            self._file_exists("cloud-scale-readiness", "chimera/cloud_scale_readiness.py", "thousand-agent planning is explicit and non-certifying"),
            self._file_contains("ag-ui-adapter", "chimera/run_event_bus.py", "run_event_to_ag_ui", "AG-UI is an adapter over canonical run events"),
            self._file_contains("mcp-trace-context", "chimera/trace_context.py", "inject_trace_context_into_meta", "trace context propagation is isolated in a helper"),
            self._file_contains("openinference-otel", "chimera/otel_mapping.py", "openinference.span.kind", "OpenInference is additive to OTel mapping"),
            self._line_budget("cli-shim-budget", "chimera/cli.py", 400),
            self._line_budget("focused-coder-budget", "chimera/rlm_coder_focused.py", 160),
            self._no_forbidden_core_imports(),
            self._promotion_gates_present(),
        ]
        failures = [check.name for check in checks if check.status == "fail"]
        warnings = [check.name for check in checks if check.status == "warn"]
        return {
            "schema_version": "chimera.antifragile-architecture-audit.v1",
            "root": str(self.root),
            "status": "pass" if not failures else "fail",
            "failures": failures,
            "warnings": warnings,
            "checks": [asdict(check) for check in checks],
            "hexagonal_preserved": not failures,
            "local_mode_preserved": not failures,
            "promotion_allowed": False,
            "promotion_rule": "architecture audit is necessary but not sufficient; candidates still need benchmark and live deployment receipts",
        }

    def _path(self, rel: str) -> pathlib.Path:
        return self.root / rel

    def _file_exists(self, name: str, rel: str, evidence: str) -> ArchitectureCheck:
        exists = self._path(rel).exists()
        return ArchitectureCheck(name, "pass" if exists else "fail", evidence if exists else f"missing {rel}", "restore file or remove dependent profile")

    def _file_contains(self, name: str, rel: str, needle: str, evidence: str) -> ArchitectureCheck:
        path = self._path(rel)
        ok = path.exists() and needle in path.read_text(encoding="utf-8", errors="replace")
        return ArchitectureCheck(name, "pass" if ok else "fail", evidence if ok else f"{needle!r} missing from {rel}", "restore adapter boundary")

    def _line_budget(self, name: str, rel: str, budget: int) -> ArchitectureCheck:
        path = self._path(rel)
        if not path.exists():
            return ArchitectureCheck(name, "fail", f"missing {rel}", "restore file")
        count = len(path.read_text(encoding="utf-8", errors="replace").splitlines())
        return ArchitectureCheck(name, "pass" if count <= budget else "fail", f"{rel} has {count} lines; budget {budget}", "split module to keep orchestration thin")

    def _no_forbidden_core_imports(self) -> ArchitectureCheck:
        forbidden = {"nats", "redis", "duckdb", "libsql", "qdrant_client", "kuzu", "cozo_embedded"}
        offenders: list[str] = []
        for rel in ["chimera/stack_alternatives.py", "chimera/cloud_scale_readiness.py", "chimera/stack_benchmarks.py"]:
            path = self._path(rel)
            if not path.exists():
                continue
            try:
                tree = ast.parse(path.read_text(encoding="utf-8"))
            except SyntaxError:
                offenders.append(f"{rel}:syntax-error")
                continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name.split(".")[0] in forbidden:
                            offenders.append(f"{rel}:{alias.name}")
                elif isinstance(node, ast.ImportFrom) and node.module:
                    if node.module.split(".")[0] in forbidden:
                        offenders.append(f"{rel}:{node.module}")
        return ArchitectureCheck(
            "no-mandatory-optional-runtime-imports",
            "pass" if not offenders else "fail",
            "optional runtimes are probed via shutil/importlib, not imported into core" if not offenders else ", ".join(offenders),
            "move optional dependency behind adapter/probe",
        )

    def _promotion_gates_present(self) -> ArchitectureCheck:
        required = [
            ("chimera/stack_benchmarks.py", "promotion_allowed"),
            ("chimera/cloud_scale_readiness.py", "required_evidence_before_promotion"),
            ("chimera/stack_alternatives.py", "kill_criterion"),
        ]
        missing = [f"{rel}:{needle}" for rel, needle in required if needle not in self._path(rel).read_text(encoding="utf-8", errors="replace")]
        return ArchitectureCheck(
            "promotion-gates-present",
            "pass" if not missing else "fail",
            "benchmark/readiness/kill-criterion gates are present" if not missing else ", ".join(missing),
            "restore explicit promotion gates",
        )
