"""Opt-in, fail-closed host admission for discretionary autonomous work.

No OS probe is enabled by this module.  A host application must deliberately
provide a probe and an enabled policy.  Probe errors, stale samples, unknown
fields, and threshold misses yield/deny; they never permit a background step.
"""
from __future__ import annotations

from dataclasses import dataclass
import time
from typing import Protocol, Literal

from pydantic import BaseModel, ConfigDict, Field


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class HostAdmissionSample(_FrozenModel):
    observed_at: float
    presence: Literal["quiet", "active", "unknown"]
    power: Literal["external", "battery", "unknown"]
    battery_percent: float | None = Field(default=None, ge=0.0, le=100.0)
    resource_headroom_percent: float | None = Field(default=None, ge=0.0, le=100.0)


class HostAdmissionPolicy(_FrozenModel):
    """A strict profile used only when an owner explicitly opts in."""

    enabled: bool = False
    require_quiet: bool = True
    require_external_power: bool = True
    min_battery_percent: float | None = Field(default=50.0, ge=0.0, le=100.0)
    min_resource_headroom_percent: float | None = Field(default=25.0, ge=0.0, le=100.0)
    max_sample_age_seconds: float = Field(default=30.0, gt=0.0, le=3_600.0)

    @classmethod
    def strict_opt_in(cls, **overrides: object) -> "HostAdmissionPolicy":
        return cls(enabled=True, **overrides)


class HostAdmissionDecision(_FrozenModel):
    allowed: bool
    reason: str
    sample: HostAdmissionSample | None = None


class HostAdmissionProbe(Protocol):
    def sample(self) -> HostAdmissionSample:
        """Return one current host sample or raise when it cannot be obtained."""


@dataclass(frozen=True)
class CallableHostAdmissionProbe:
    """Small adapter for an explicit application-owned sampling function."""

    callback: object

    def sample(self) -> HostAdmissionSample:
        value = self.callback()  # type: ignore[operator]
        return value if isinstance(value, HostAdmissionSample) else HostAdmissionSample.model_validate(value)


class HostAdmissionGate:
    """Evaluate a probe under a policy; disabled policy has no host side effects."""

    def __init__(self, probe: HostAdmissionProbe, policy: HostAdmissionPolicy | None = None):
        self.probe = probe
        self.policy = policy or HostAdmissionPolicy()

    def check(self, *, now: float | None = None) -> HostAdmissionDecision:
        if not self.policy.enabled:
            return HostAdmissionDecision(allowed=True, reason="host admission is disabled by policy")
        current = time.time() if now is None else float(now)
        try:
            sample = self.probe.sample()
        except Exception as exc:
            return HostAdmissionDecision(
                allowed=False,
                reason=f"host admission probe failed: {type(exc).__name__}",
            )
        age = current - sample.observed_at
        if age < -1.0 or age > self.policy.max_sample_age_seconds:
            return HostAdmissionDecision(allowed=False, reason="host admission sample is stale or clock-invalid", sample=sample)
        if self.policy.require_quiet and sample.presence != "quiet":
            return HostAdmissionDecision(allowed=False, reason="host is active or presence is unknown", sample=sample)
        if self.policy.require_external_power and sample.power != "external":
            return HostAdmissionDecision(allowed=False, reason="external power is required or unknown", sample=sample)
        if self.policy.min_battery_percent is not None:
            if sample.battery_percent is None or sample.battery_percent < self.policy.min_battery_percent:
                return HostAdmissionDecision(allowed=False, reason="battery level is unavailable or below policy floor", sample=sample)
        if self.policy.min_resource_headroom_percent is not None:
            if sample.resource_headroom_percent is None or sample.resource_headroom_percent < self.policy.min_resource_headroom_percent:
                return HostAdmissionDecision(allowed=False, reason="resource headroom is unavailable or below policy floor", sample=sample)
        return HostAdmissionDecision(allowed=True, reason="host admission passed", sample=sample)
