"""Provider transport and canary methods for RLMRuntime.

Extracted as a mixin so rlm.py can focus on orchestration while preserving
method names and behavior.
"""
from __future__ import annotations

import json
import hashlib
import os
import re
import time
from typing import Any, Dict, Iterable, List, Mapping

from .runtime_ports import CompletionRequest, CompletionResult
from .stream_tools import StreamToolExtractor


class RLMProviderMixin:
    def _http(self):
        with self._http_client_lock:
            if self._http_client is None:
                import httpx
                self._http_client = httpx.Client(
                    http2=True,
                    limits=httpx.Limits(max_connections=20, max_keepalive_connections=10, keepalive_expiry=30),
                    timeout=httpx.Timeout(120.0, connect=20.0),
                    follow_redirects=False,
                )
            return self._http_client

    def _reset_http_client(self) -> None:
        with self._http_client_lock:
            if self._http_client is not None:
                try: self._http_client.close()
                finally: self._http_client = None

    def _stream_openai_chat(self, *, provider: str, url: str, headers: Dict[str, str],
                            payload: Dict[str, Any], timeout: float,
                            enforce_egress: bool = False) -> Dict[str, Any]:
        """Consume OpenAI-compatible SSE while forwarding text immediately."""
        if enforce_egress:
            from urllib.parse import urlparse
            from .bootstrap import ProfileEgressPolicy, profile_policy
            host = (urlparse(url).hostname or "").lower().rstrip(".")
            ProfileEgressPolicy(
                profile_policy(self.config.deployment_profile),
                allowed_hosts={host} if host else set(),
            ).authorize(url)
        client = self._http()
        request = {**payload, "stream": True}
        if provider in {"openai", "openrouter"}:
            request["stream_options"] = {"include_usage": True}
        text_parts: List[str] = []
        usage: Dict[str, Any] = {}
        started = time.perf_counter()
        first_text_ms = None
        stream_tool_extractor = StreamToolExtractor()
        stream_tool_events: List[Dict[str, Any]] = []
        stream_tool_dispatcher = getattr(self._thread_local, "stream_tool_dispatcher", None)
        with client.stream("POST", url, headers=headers, json=request, timeout=timeout) as response:
            if not response.is_success:
                response.read()
                return {
                    "success": False, "status_code": response.status_code,
                    "text": response.text[:500], "headers": dict(response.headers),
                }
            try:
                for line in response.iter_lines():
                    if not line or not line.startswith("data:"):
                        continue
                    data_text = line[5:].strip()
                    if data_text == "[DONE]":
                        break
                    try:
                        event = json.loads(data_text)
                    except json.JSONDecodeError:
                        continue
                    if isinstance(event.get("usage"), dict):
                        usage = event["usage"]
                    choices = event.get("choices") if isinstance(event.get("choices"), list) else []
                    if not choices:
                        continue
                    delta = choices[0].get("delta", {}) if isinstance(choices[0], dict) else {}
                    piece = delta.get("content") or delta.get("reasoning") or ""
                    if not isinstance(piece, str) or not piece:
                        continue
                    if first_text_ms is None:
                        first_text_ms = (time.perf_counter() - started) * 1000
                    text_parts.append(piece)
                    for event in stream_tool_extractor.feed(piece):
                        row = event.as_dict()
                        if callable(stream_tool_dispatcher):
                            try:
                                row["dispatch"] = stream_tool_dispatcher(event.block)
                            except Exception as exc:
                                row["dispatch"] = {"ok": False, "error": f"{type(exc).__name__}: {exc}"[:240]}
                        stream_tool_events.append(row)
                    if self.stream_callback is not None:
                        try:
                            self.stream_callback(piece)
                        except Exception:
                            pass
            except Exception as exc:
                # Once user-visible deltas have escaped, replaying the request can
                # duplicate prose or tool-call fragments. Return a terminal
                # failure shape so the outer retry loop fails closed instead.
                return {
                    "success": False, "status_code": 0,
                    "text": "".join(text_parts), "headers": dict(response.headers),
                    "partial_emitted": bool(text_parts), "do_not_retry": bool(text_parts),
                    "stream_tool_events": stream_tool_events,
                    "error": f"{type(exc).__name__}: {exc}",
                    "first_text_ms": first_text_ms,
                }
        return {
            "success": True, "text": "".join(text_parts), "usage": usage,
            "first_text_ms": first_text_ms, "stream_tool_events": stream_tool_events,
        }

    def _qos_select_model(self, model: str) -> tuple[str, Dict[str, Any] | None]:
        """Optionally choose a lower-penalty equivalent model from a configured pool."""
        if os.environ.get("CHIMERA_QOS_ROUTING") != "1":
            return model, None
        if getattr(self._thread_local, "provider_tools", None) is not None or getattr(self._thread_local, "provider_json_object", False):
            return model, None
        pool = [item.strip() for item in re.split(r"[,;\n]", os.environ.get("CHIMERA_QOS_MODEL_POOL", "")) if item.strip()]
        candidates = list(dict.fromkeys([model, *pool]))
        if len(candidates) <= 1:
            return model, None
        try:
            from .provider_state import ProviderStateRegistry
            registry = ProviderStateRegistry(self.root)
            rows = []
            for candidate in candidates:
                provider = self.auth_storage.resolve_provider(candidate)
                state = registry.profile(provider, candidate)
                rows.append((state.route_penalty, candidate, provider, state.as_dict()))
            rows.sort(key=lambda item: (item[0], item[1]))
            chosen = rows[0]
            current = next(row for row in rows if row[1] == model)
            decision = {
                "current": current[3],
                "candidates": [row[3] for row in rows],
                "recommended_model": chosen[1],
                "recommended_provider": chosen[2],
                "selected_model": model,
                "mode": "advisory-explicit-model-preserved",
            }
            return model, decision
        except Exception as exc:
            from .degradation_ledger import confess_degradation
            confess_degradation(self.root, "qos_advice", "provider", type(exc).__name__, severity="info")
            return model, {"error": f"{type(exc).__name__}: {exc}"[:200], "selected_model": model, "mode": "advisory-fallback"}

    def _complete_model(self, prompt: str, model: str = "mock-echo") -> Dict[str, Any]:
        """Compatibility shim routing every completion through the provider port."""
        started = time.perf_counter()
        # Every normal completion crosses one authority point. Explicit user
        # selection survives intact; only the literal auto request resolves to
        # a configured default. QoS/reliability remain observable advice.
        authority = self.route_authority.resolve(str(model))
        model = authority.selected_model
        routed_model, qos_route = self._qos_select_model(model)
        model = routed_model
        try:
            context = getattr(self._thread_local, "completion_context", {})
            if not isinstance(context, Mapping):
                context = {}
            response = self.model_completion_port.complete(CompletionRequest(
                str(prompt),
                str(model),
                tenant_key=context.get("tenant_key"),
                principal_hash=context.get("principal_hash"),
                run_id=context.get("run_id"),
                request_id=context.get("request_id"),
                trace_id=context.get("trace_id"),
                deadline_unix_ms=context.get("deadline_unix_ms"),
                max_input_tokens=context.get("max_input_tokens"),
                max_output_tokens=context.get("max_output_tokens"),
                max_cost_usd=context.get("max_cost_usd"),
                idempotency_key=context.get("idempotency_key"),
                tools=tuple(context.get("tools", ())),
                response_schema=context.get("response_schema"),
                cancellation_token=context.get("cancellation_token"),
            ))
            if isinstance(response, CompletionResult):
                row = response.as_mapping()
            elif isinstance(response, Mapping):
                row = dict(response)
            else:  # defensive: third-party Protocol implementations
                raise TypeError("model completion port must return a mapping or CompletionResult")
            row["route_authority"] = authority.as_dict()
            if qos_route is not None:
                row["qos_route"] = qos_route
            latency_ms = (time.perf_counter()-started)*1000
            try:
                provider_name = str(row.get("provider") or self.auth_storage.resolve_provider(model))
                model_name = str(row.get("model") or model)
                self.provider_qos.record(provider_name, model_name, latency_ms=latency_ms, tokens=int(row.get("tokens",0) or 0), ok=True)
                from .event_sink import EventSink
                EventSink(self.root).emit("provider_call", {"provider": provider_name, "model": model_name, "latency_ms": round(latency_ms,3), "tokens": int(row.get("tokens",0) or 0), "ok": True, "qos_route": qos_route, "route_authority": authority.as_dict()})
            except Exception as telemetry_exc:
                from .degradation_ledger import confess_degradation
                confess_degradation(self.root, "provider_telemetry", "provider", type(telemetry_exc).__name__, severity="info")
            return row
        except Exception as exc:
            latency_ms = (time.perf_counter()-started)*1000
            try:
                provider_name = self.auth_storage.resolve_provider(model)
                self.provider_qos.record(provider_name, str(model), latency_ms=latency_ms, ok=False, error_class=type(exc).__name__)
                from .event_sink import EventSink
                EventSink(self.root).emit("provider_call", {"provider": provider_name, "model": str(model), "latency_ms": round(latency_ms,3), "ok": False, "error_class": type(exc).__name__, "qos_route": qos_route, "route_authority": authority.as_dict()})
            except Exception as telemetry_exc:
                from .degradation_ledger import confess_degradation
                confess_degradation(self.root, "provider_failure_telemetry", "provider", type(telemetry_exc).__name__, severity="info")
            raise

    def close(self) -> None:
        self.async_memory.close()
        self.observations.close()
        if self._self_hosted_adapter is not None:
            self._self_hosted_adapter.close()
            self._self_hosted_adapter = None
        self.prompt_cache.close()
        self.wire.close()
        self._kernels.clear()
        self._loop_detectors.clear()
        self._progress_loop_detectors.clear()
        self._failure_escalators.clear()
        self._context_pack_builders.clear()
        self._hybrid_observations.clear()
        self._reset_http_client()

    def run_provider_canary(self, model: str, capabilities: Iterable[str]) -> Dict[str, Any]:
        """Run explicitly requested fixed provider probes and persist only facts.

        This is intentionally separate from normal task execution: each probe
        can consume provider quota.  The caller must opt in through the CLI;
        coding tasks never invoke it implicitly.  Prompt text, headers, and
        credentials are not retained in the resulting receipt.
        """
        from .provider_canary import run_fixed_probes, ProviderCanary

        requested = tuple(dict.fromkeys(str(item) for item in capabilities))
        if not requested:
            raise ValueError("at least one provider canary capability is required")
        session = "provider-canary:" + hashlib.sha256(
            (str(model) + "|" + "|".join(sorted(requested))).encode()
        ).hexdigest()[:24]
        observed_provider: List[str] = []

        def invoke(kind: str, prompt: str) -> Mapping[str, Any]:
            previous_tools = getattr(self._thread_local, "provider_tools", None)
            previous_choice = getattr(self._thread_local, "provider_tool_choice", None)
            previous_json = getattr(self._thread_local, "provider_json_object", None)
            previous_partition = getattr(self._thread_local, "prompt_cache_partition", None)
            previous_stream = self.stream_callback
            request = prompt
            try:
                self._thread_local.provider_tools = None
                self._thread_local.provider_tool_choice = None
                self._thread_local.provider_json_object = False
                self._thread_local.prompt_cache_partition = None
                if kind == "native_tools":
                    self._thread_local.provider_tools = [{
                        "type": "function",
                        "function": {
                            "name": "chimera_canary",
                            "description": "Fixed Chimera protocol canary; call it exactly once.",
                            "parameters": {
                                "type": "object",
                                "properties": {"nonce": {"type": "string", "enum": ["native-tool-v1"]}},
                                "required": ["nonce"], "additionalProperties": False,
                            },
                        },
                    }]
                    self._thread_local.provider_tool_choice = "required"
                    request = (
                        "This is a fixed Chimera protocol canary. Call the native function "
                        "chimera_canary exactly once with nonce native-tool-v1. Do not answer in text."
                    )
                elif kind == "strict_json":
                    self._thread_local.provider_json_object = True
                    request = (
                        "RETURN ONLY ONE VALID JSON OBJECT. "
                        "Return exactly {\"chimera_canary\":\"strict-json-v1\"}."
                    )
                elif kind == "streaming":
                    # The production adapter only enters its streaming branch
                    # when a callback is installed.  A private sink is enough
                    # to observe wire timing without exposing any text.
                    self.stream_callback = lambda _piece: None
                    request = "Reply with exactly STREAM_CANARY_V1."
                elif kind in {"prompt_cache_prime", "prompt_cache_reuse"}:
                    prefix = "Fixed Chimera provider cache canary prefix v1. Preserve this exact prefix.\n"
                    suffix = "Reply with exactly CACHE_CANARY_V1."
                    request = prefix + suffix
                    self._thread_local.prompt_cache_partition = self.prompt_cache.partition(
                        session, prefix, suffix,
                    )
                elif kind == "refusal_shape":
                    request = "Reply with exactly REFUSAL_SHAPE_CANARY_V1."
                response = self.model_provider(request, model=model)
                if not isinstance(response, Mapping):
                    return {"canary_error": "provider response was not a mapping"}
                row = dict(response)
                provider = row.get("provider")
                if isinstance(provider, str) and provider:
                    observed_provider.append(provider)
                return row
            except Exception as exc:
                # A failure is an observed failed probe.  Store only an error
                # class so provider responses cannot leak credential material
                # through exception rendering.
                return {"canary_error": type(exc).__name__}
            finally:
                self._thread_local.provider_tools = previous_tools
                self._thread_local.provider_tool_choice = previous_choice
                self._thread_local.provider_json_object = previous_json
                self._thread_local.prompt_cache_partition = previous_partition
                self.stream_callback = previous_stream

        report_provider = self.auth_storage.resolve_provider(model)
        report = run_fixed_probes(report_provider, model, requested, invoke)
        # A routed gateway is authoritative for this particular receipt.  Keep
        # it model-scoped so a success on one gateway/model pair cannot bless
        # a different route.
        if observed_provider:
            report = ProviderCanary.report(observed_provider[-1], model, report.outcomes)
        evidence_ref, profile = ProviderCanary.persist(report, self.artifacts, self.provider_capabilities)
        return {
            "report": report.as_dict(), "evidence_ref": evidence_ref,
            "capabilities": profile,
        }

    def _production_provider(self, prompt: str, model: str="mock-echo") -> Dict:
        """Call the requested provider and never counterfeit a real-model run.

        Non-mock requests fail explicitly when credentials or the provider are
        unavailable.  A mock fallback is possible only with the opt-in
        ``CHIMERA_ALLOW_MOCK_FALLBACK=1`` flag, and is labelled as such.
        """
        import os
        import time as _time

        if "mock" in model.lower():
            return self._mock_provider(prompt, model)

        if model.lower().startswith(("local/", "self-hosted/")):
            endpoint = os.environ.get("CHIMERA_SELF_HOSTED_INFERENCE_URL")
            if not endpoint:
                raise RuntimeError(
                    "self-hosted model requested but CHIMERA_SELF_HOSTED_INFERENCE_URL is absent"
                )
            if self._self_hosted_adapter is None:
                from urllib.parse import urlparse
                from .bootstrap import ProfileEgressPolicy, profile_policy
                from .provider_adapters import (
                    EnvironmentSecretPort,
                    OpenAICompatibleAdapter,
                )

                host = (urlparse(endpoint).hostname or "").lower().rstrip(".")
                self._self_hosted_adapter = OpenAICompatibleAdapter(
                    adapter_id="self-hosted-openai-compatible",
                    local=True,
                    base_url=endpoint,
                    egress=ProfileEgressPolicy(
                        profile_policy(self.config.deployment_profile),
                        allowed_hosts={host} if host else set(),
                        offline_loopback_ports={
                            urlparse(endpoint).port
                            or (443 if urlparse(endpoint).scheme == "https" else 80),
                            11434,
                        },
                    ),
                    secrets=EnvironmentSecretPort(),
                    secret_name=None,
                )
            context = getattr(self._thread_local, "completion_context", {})
            if not isinstance(context, Mapping):
                context = {}
            result = self._self_hosted_adapter.complete(CompletionRequest(
                prompt=str(prompt),
                model=model,
                tenant_key=context.get("tenant_key"),
                principal_hash=context.get("principal_hash"),
                run_id=context.get("run_id"),
                request_id=context.get("request_id"),
                trace_id=context.get("trace_id"),
                deadline_unix_ms=context.get("deadline_unix_ms"),
                max_input_tokens=context.get("max_input_tokens"),
                max_output_tokens=context.get("max_output_tokens"),
                max_cost_usd=context.get("max_cost_usd"),
                idempotency_key=context.get("idempotency_key"),
                cancellation_token=context.get("cancellation_token"),
            ))
            return result.as_mapping()

        from .bootstrap import profile_policy
        if not profile_policy(self.config.deployment_profile).allow_remote_provider:
            raise RuntimeError(
                f"{self.config.deployment_profile.value} denies remote provider egress"
            )

        def bounded_prompt(text: str, limit: int = 100_000) -> str:
            if len(text) <= limit:
                return text
            # Keep immutable instructions/repository map and the newest tool
            # observations. Dropping the suffix caused models to repeat reads.
            head = min(30_000, limit // 3)
            return text[:head] + "\n...[older context pruned by harness]...\n" + text[-(limit - head - 48):]

        # A focused coder uses the textual sentinel; a tool-use contract sets
        # the same requirement thread-locally for its final post-observation
        # turn.  Keep the final structured patch request separate from native
        # function-tool turns because providers commonly reject both controls
        # in the same response.
        strict_json = (
            prompt.lstrip().startswith("RETURN ONLY ONE VALID JSON OBJECT")
            or bool(getattr(self._thread_local, "provider_json_object", False))
        )
        # `_model_tool_loop` installs these only for a tool-observation turn.
        # Keep this transport detail thread-local so concurrent atoms cannot
        # accidentally inherit another atom's tool authority.
        native_tools = getattr(self._thread_local, "provider_tools", None)
        native_tool_choice = getattr(self._thread_local, "provider_tool_choice", None)
        if not isinstance(native_tools, list):
            native_tools = None
        try:
            max_output_tokens = max(128, min(4096, int(os.environ.get("CHIMERA_MAX_OUTPUT_TOKENS", "4096"))))
        except ValueError:
            max_output_tokens = 4096
        from .provider_timing import ProviderTimingPolicy
        request_timeout = ProviderTimingPolicy(
            float(os.environ.get("CHIMERA_STREAM_IDLE_TIMEOUT_SECS", "180"))
        ).timeout(os.environ.get("CHIMERA_REASONING_EFFORT"))
        provider = self.auth_storage.resolve_provider(model)
        pooled_raw = os.environ.get("OPENROUTER_API_KEYS", "")
        pooled_keys = [item.strip() for item in re.split(r"[,;\n]", pooled_raw) if item.strip()]
        single_openrouter = os.environ.get("OPENROUTER_API_KEY")
        openrouter_keys: List[str] = []
        for candidate in [*pooled_keys, single_openrouter]:
            if candidate and candidate not in openrouter_keys:
                openrouter_keys.append(candidate)
        gemini_pool_raw = os.environ.get("GEMINI_API_KEYS") or os.environ.get("GOOGLE_API_KEYS") or ""
        gemini_keys = [item.strip() for item in re.split(r"[,;\n]", gemini_pool_raw) if item.strip()]
        for candidate in (os.environ.get("GEMINI_API_KEY"), os.environ.get("GOOGLE_API_KEY")):
            if candidate and candidate not in gemini_keys:
                gemini_keys.append(candidate)
        selected_gemini_key = None
        if gemini_keys:
            with self._key_lock:
                selected_gemini_key = gemini_keys[self._gemini_key_cursor % len(gemini_keys)]
                self._gemini_key_cursor = (self._gemini_key_cursor + 1) % len(gemini_keys)
        env_keys = {
            "claude": os.environ.get("ANTHROPIC_API_KEY"),
            "openai": os.environ.get("OPENAI_API_KEY"),
            "openrouter": openrouter_keys[0] if openrouter_keys else None,
            "tokenrouter": os.environ.get("TOKENROUTER_API_KEY") or os.environ.get("TOKENROUTER_KEY"),
            "kimi": os.environ.get("KIMI_API_KEY") or os.environ.get("MOONSHOT_API_KEY") or (openrouter_keys[0] if openrouter_keys else None),
            "deepseek": os.environ.get("DEEPSEEK_API_KEY") or (openrouter_keys[0] if openrouter_keys else None),
            "qwen": os.environ.get("DASHSCOPE_API_KEY") or (openrouter_keys[0] if openrouter_keys else None),
            "gemini": selected_gemini_key or (openrouter_keys[0] if openrouter_keys else None),
            "minimax": os.environ.get("MINIMAX_API_KEY") or (openrouter_keys[0] if openrouter_keys else None),
            "mistral": os.environ.get("MISTRAL_API_KEY"),
            "groq": os.environ.get("GROQ_API_KEY"),
            "cerebras": os.environ.get("CEREBRAS_API_KEY"),
            "xai": os.environ.get("XAI_API_KEY"),
            "fireworks": os.environ.get("FIREWORKS_API_KEY"),
            "zai": os.environ.get("ZAI_API_KEY"),
            "prime-inference": os.environ.get("PRIME_API_KEY"),
            "ollama": os.environ.get("OLLAMA_HOST"),
        }
        api_key = (env_keys.get(provider) or self.auth_storage.tokens.get(provider)
                   or self.auth_storage.tokens.get("openrouter"))
        if "/" in model and openrouter_keys and provider == "openrouter":
            provider = "openrouter"
            api_key = openrouter_keys[0]

        def fail(reason: str):
            if os.environ.get("CHIMERA_ALLOW_MOCK_FALLBACK") == "1":
                result = self._mock_provider(prompt, model)
                result.update({"real_call": False, "fallback": True, "fallback_reason": reason})
                return result
            raise RuntimeError(f"provider call for {model!r} failed: {reason}")

        if provider == "openrouter" and openrouter_keys:
            available_keys = self.provider_cooldowns.available(openrouter_keys)
            if not available_keys:
                return fail("all OpenRouter credentials are in quota cooldown")
            openrouter_keys = available_keys
            api_key = openrouter_keys[0]
        if provider != "ollama" and not api_key:
            return fail(f"missing credential for {provider}")

        try:
            import httpx
            client = self._http()
        except ImportError:
            return fail("httpx is not installed")

        cache_partition = getattr(self._thread_local, "prompt_cache_partition", None)
        user_content = (
            cache_partition.content_blocks()
            if cache_partition is not None and cache_partition.prefix + cache_partition.suffix == prompt
            and cache_partition.stable and not cache_partition.lint
            and provider in {"claude", "openrouter"}
            else bounded_prompt(prompt)
        )
        cache_hint = {
            "enabled": isinstance(user_content, list),
            "prefix_hash": cache_partition.prefix_hash if cache_partition else None,
            "stable": cache_partition.stable if cache_partition else False,
            "lint": list(cache_partition.lint) if cache_partition else [],
        }
        from .context_window import ContextWindowPolicy
        budget_text = json.dumps(user_content, ensure_ascii=False, default=str) if isinstance(user_content, list) else str(user_content)
        prompt_measurement = self.tokenizer_measurer.measure(model, budget_text)
        measured_prompt_tokens = (
            prompt_measurement.tokens
            if prompt_measurement.status == "measured"
            else None
        )
        context_budget = ContextWindowPolicy.budget(
            model,
            budget_text,
            max_output_tokens,
            self.config.planner.context_max_tokens,
            prompt_tokens=measured_prompt_tokens,
            token_kind=prompt_measurement.status,
        )
        if not context_budget.prompt_fits:
            return fail(
                "prompt exceeds the declared context budget by "
                f"{context_budget.overrun_tokens} tokens"
            )
        max_output_tokens = context_budget.output_tokens
        def post(*args, **kwargs):
            from urllib.parse import urlparse
            from .bootstrap import ProfileEgressPolicy, profile_policy
            from .process_limiter import ProcessLLMGate
            target = str(args[0] if args else kwargs.get("url", ""))
            host = (urlparse(target).hostname or "").lower().rstrip(".")
            ProfileEgressPolicy(
                profile_policy(self.config.deployment_profile),
                allowed_hosts={host} if host else set(),
            ).authorize(target)
            gate = ProcessLLMGate.acquire(interactive=True)
            try:
                return self.provider_breaker.call(provider, client.post, *args, **kwargs)
            finally:
                gate.release()

        errors: List[str] = []
        def finish_success(row: Dict[str, Any], attempt_index: int) -> Dict[str, Any]:
            usage = dict(row.get("usage", {})) if isinstance(row.get("usage"), dict) else {}
            usage.setdefault("request_count", attempt_index + 1)
            row["usage"] = usage
            row["request_count"] = attempt_index + 1
            row["retry_count"] = attempt_index
            row["context_budget"] = context_budget.__dict__
            return row
        compatible_endpoints = {
            "deepseek": "https://api.deepseek.com/v1",
            "tokenrouter": "https://api.tokenrouter.com/v1",
            "qwen": "https://dashscope.aliyuncs.com/compatible-mode/v1",
            "kimi": "https://api.moonshot.ai/v1",
            "minimax": "https://api.minimax.chat/v1",
            "mistral": "https://api.mistral.ai/v1",
            "groq": "https://api.groq.com/openai/v1",
            "cerebras": "https://api.cerebras.ai/v1",
            "xai": "https://api.x.ai/v1",
            "fireworks": "https://api.fireworks.ai/inference/v1",
            "zai": "https://api.z.ai/api/paas/v4",
            "prime-inference": "https://api.pinference.ai/api/v1",
        }
        rotation_start = 0
        if provider == "openrouter" and openrouter_keys:
            with self._key_lock:
                rotation_start = self._openrouter_key_cursor % len(openrouter_keys)
                self._openrouter_key_cursor = (self._openrouter_key_cursor + 1) % len(openrouter_keys)
        max_attempts = max(3, len(openrouter_keys)) if provider == "openrouter" else 3
        for attempt in range(max_attempts):
            rate_limited = False
            retry_after_value = None
            try:
                if provider == "claude":
                    response = post(
                        "https://api.anthropic.com/v1/messages",
                        headers={"x-api-key": api_key, "content-type": "application/json", "anthropic-version": "2023-06-01"},
                        json={"model": model, "max_tokens": max_output_tokens, "messages": [{"role": "user", "content": user_content}]},
                        timeout=request_timeout,
                    )
                    if response.is_success:
                        data = response.json()
                        text = "".join(part.get("text", "") for part in data.get("content", []))
                        usage = data.get("usage", {})
                        return finish_success({"answer": text, "tokens": usage.get("input_tokens", 0) + usage.get("output_tokens", 0),
                                "model": model, "provider": provider, "real_call": True, "usage": usage,
                                "prompt_cache": cache_hint}, attempt)
                elif provider == "openai":
                    url = "https://api.openai.com/v1/chat/completions"
                    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
                    payload = {"model": model, "messages": [{"role": "user", "content": user_content}], "max_tokens": max_output_tokens}
                    if self.stream_callback is not None:
                        streamed = self.provider_breaker.call(
                            provider, self._stream_openai_chat,
                            provider=provider, url=url, headers=headers, payload=payload, timeout=request_timeout,
                            enforce_egress=True,
                        )
                        if streamed["success"]:
                            text = streamed["text"]; usage = streamed["usage"]
                            return finish_success({"answer": text, "tokens": usage.get("total_tokens", self._count_tokens(model, text)),
                                    "model": model, "provider": provider, "real_call": True, "usage": usage,
                                    "streamed": True, "first_text_ms": streamed["first_text_ms"],
                                    "stream_tool_events": streamed.get("stream_tool_events", []),
                                    "prompt_cache": cache_hint}, attempt)
                        response = type("StreamFailure", (), {"is_success": False, **streamed})()
                    else:
                        response = post(url, headers=headers, json=payload, timeout=request_timeout)
                    if response.is_success:
                        data = response.json(); text = data["choices"][0]["message"].get("content") or ""
                        return finish_success({"answer": text, "tokens": data.get("usage", {}).get("total_tokens", self._count_tokens(model, text)),
                                "model": model, "provider": provider, "real_call": True, "usage": data.get("usage", {}),
                                "prompt_cache": cache_hint}, attempt)
                elif provider == "gemini":
                    model_id = model.split("/", 1)[1] if "/" in model else model
                    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_id}:generateContent"
                    payload = {
                        "contents": [{"role": "user", "parts": [{"text": bounded_prompt(prompt)}]}],
                        "generationConfig": {"maxOutputTokens": max_output_tokens, "temperature": 0.0 if strict_json else 0.2},
                    }
                    response = post(url, headers={"x-goog-api-key": api_key, "Content-Type": "application/json"}, json=payload, timeout=request_timeout)
                    if response.is_success:
                        data = response.json()
                        parts = (((data.get("candidates") or [{}])[0].get("content") or {}).get("parts") or [])
                        text = "".join(part.get("text", "") for part in parts if isinstance(part, dict))
                        usage = data.get("usageMetadata", {}) if isinstance(data.get("usageMetadata"), dict) else {}
                        total = usage.get("totalTokenCount") or (usage.get("promptTokenCount", 0) + usage.get("candidatesTokenCount", 0))
                        return finish_success({"answer": text, "tokens": total or self._count_tokens(model, text),
                                "model": model, "provider": provider, "real_call": True, "usage": usage,
                                "prompt_cache": cache_hint}, attempt)
                elif provider in compatible_endpoints:
                    url = compatible_endpoints[provider].rstrip("/") + "/chat/completions"
                    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
                    payload = {
                        "model": model.split("/", 1)[1] if provider in {"tokenrouter", "cerebras"} and "/" in model else model.split(":", 1)[0],
                        "messages": [{"role": "user", "content": user_content}],
                        "max_tokens": max_output_tokens,
                        "temperature": 0.0 if strict_json else 0.2,
                        **({"response_format": {"type": "json_object"}} if strict_json else {}),
                        **({"reasoning_effort": os.environ.get("CHIMERA_REASONING_EFFORT", "low")} if provider in {"cerebras", "tokenrouter"} else {}),
                    }
                    if self.stream_callback is not None:
                        streamed = self.provider_breaker.call(
                            provider, self._stream_openai_chat,
                            provider=provider, url=url, headers=headers, payload=payload, timeout=request_timeout,
                            enforce_egress=True,
                        )
                        if streamed["success"]:
                            text = streamed["text"]; usage = streamed["usage"]
                            return finish_success({"answer": text, "tokens": usage.get("total_tokens", self._count_tokens(model, text)),
                                    "model": model, "provider": provider, "real_call": True, "usage": usage,
                                    "streamed": True, "first_text_ms": streamed["first_text_ms"],
                                    "stream_tool_events": streamed.get("stream_tool_events", []),
                                    "prompt_cache": cache_hint}, attempt)
                        response = type("StreamFailure", (), {"is_success": False, **streamed})()
                    else:
                        response = post(url, headers=headers, json=payload, timeout=request_timeout)
                    if response.is_success:
                        data = response.json(); text = data["choices"][0]["message"].get("content") or ""
                        return finish_success({"answer": text, "tokens": data.get("usage", {}).get("total_tokens", self._count_tokens(model, text)),
                                "model": model, "provider": provider, "real_call": True, "usage": data.get("usage", {}),
                                "prompt_cache": cache_hint}, attempt)
                elif provider == "ollama":
                    host = api_key or "http://localhost:11434"
                    response = post(f"{host.rstrip('/')}/api/generate", json={"model": model.split("/", 1)[-1], "prompt": prompt, "stream": False}, timeout=request_timeout)
                    if response.is_success:
                        text = response.json().get("response", "")
                        return finish_success({"answer": text, "tokens": self._count_tokens(model, text), "model": model, "provider": provider, "real_call": True, "prompt_cache": cache_hint}, attempt)
                else:
                    # OpenRouter is the common gateway for provider/model names
                    # such as poolside/laguna-s-2.1:free.
                    if not openrouter_keys:
                        return fail("missing OpenRouter credential pool")
                    key_slot = (rotation_start + attempt) % len(openrouter_keys)
                    or_key = openrouter_keys[key_slot]
                    url = "https://openrouter.ai/api/v1/chat/completions"
                    headers = {"Authorization": f"Bearer {or_key}", "Content-Type": "application/json",
                               "HTTP-Referer": "https://arena.ai", "X-Title": "Chimera Harness"}
                    payload = {
                        "model": model,
                        "messages": (
                            [{"role": "system", "content": "You are a strict JSON compiler. Output exactly one valid JSON object and no other text."}]
                            if strict_json else []
                        ) + [{"role": "user", "content": user_content}],
                        "max_tokens": max_output_tokens, "temperature": 0.0 if strict_json else 0.2,
                        **({"response_format": {"type": "json_object"}} if strict_json and not native_tools else {}),
                    }
                    if native_tools:
                        # OpenRouter exposes the OpenAI function-tool contract.
                        # Native transport prevents a model's otherwise fragile
                        # prose/tag formatting from becoming the security boundary.
                        payload["tools"] = native_tools
                        if native_tool_choice:
                            payload["tool_choice"] = native_tool_choice
                    if self.stream_callback is not None and not native_tools:
                        streamed = self.provider_breaker.call(
                            provider, self._stream_openai_chat,
                            provider="openrouter", url=url, headers=headers, payload=payload, timeout=request_timeout,
                            enforce_egress=True,
                        )
                        if streamed["success"]:
                            text = streamed["text"]; usage = streamed["usage"]
                            return finish_success({"answer": text, "tokens": usage.get("total_tokens", self._count_tokens(model, text)),
                                    "model": model, "provider": "openrouter", "real_call": True,
                                    "key_slot": key_slot + 1, "key_pool_size": len(openrouter_keys),
                                    "usage": usage, "streamed": True,
                                    "first_text_ms": streamed["first_text_ms"], "stream_tool_events": streamed.get("stream_tool_events", []), "prompt_cache": cache_hint}, attempt)
                        response = type("StreamFailure", (), {"is_success": False, **streamed})()
                    else:
                        response = post(url, headers=headers, json=payload, timeout=request_timeout)
                    if response.is_success:
                        data = response.json(); choice = data["choices"][0]; message = choice.get("message", {})
                        text = message.get("content") or message.get("reasoning") or ""
                        tool_calls = self._native_tool_calls(message.get("tool_calls"))
                        return finish_success({"answer": text, "tokens": data.get("usage", {}).get("total_tokens", self._count_tokens(model, text)),
                                "model": model, "provider": "openrouter", "real_call": True,
                                "key_slot": key_slot + 1, "key_pool_size": len(openrouter_keys),
                                "usage": data.get("usage", {}), "prompt_cache": cache_hint,
                                "tool_calls": tool_calls, "native_tool_transport": bool(native_tools),
                                "finish_reason": choice.get("finish_reason"),
                                "refusal": str(choice.get("finish_reason", "")).lower() == "refusal"}, attempt)

                body = response.text[:500].replace("\n", " ")
                errors.append(f"HTTP {response.status_code}: {body}")
                if getattr(response, "do_not_retry", False):
                    errors.append("stream interrupted after user-visible output; request replay suppressed")
                    break
                rate_limited = response.status_code == 429
                headers_value = getattr(response, "headers", {}) or {}
                retry_after_value = headers_value.get("Retry-After") or headers_value.get("retry-after")
                exhausted_free_tier = (
                    response.status_code == 429
                    and (str(headers_value.get("X-RateLimit-Remaining", "")).strip() == "0"
                         or "free-models-per-day" in body.lower())
                )
                if exhausted_free_tier:
                    # A daily quota cannot recover through exponential backoff.
                    # Persist a secret-free cooldown so the next request skips
                    # this known-exhausted slot instead of repeating the probe.
                    if provider == "openrouter":
                        try:
                            raw_reset = float(headers_value.get("X-RateLimit-Reset", 0) or 0)
                            until = raw_reset / 1000.0 if raw_reset > 10_000_000_000 else raw_reset
                        except (TypeError, ValueError):
                            until = 0.0
                        self.provider_cooldowns.cooldown(or_key, until if until > _time.time() else _time.time() + 3600)
                    break
                if provider == "openrouter" and response.status_code in {401, 402, 429} and len(openrouter_keys) > 1:
                    continue  # invalid, exhausted, or throttled key: rotate without backoff
                if response.status_code != 0 and response.status_code not in {408, 409, 429} and response.status_code < 500:
                    break
            except Exception as exc:
                errors.append(f"{type(exc).__name__}: {exc}")
                if isinstance(exc, httpx.TransportError):
                    # A transport exception after dispatch has an ambiguous
                    # bill/effect outcome. Without an adapter-specific replay
                    # proof, do not send a duplicate physical request.
                    self._reset_http_client()
                    errors.append("ambiguous transport outcome; replay suppressed")
                    break
            if attempt < max_attempts - 1:
                from .backoff import backoff_seconds
                _time.sleep(backoff_seconds(
                    attempt + 1, rate_limited=rate_limited,
                    retry_after=retry_after_value,
                ))
        if any("ambiguous transport outcome" in item for item in errors):
            return {
                "outcome": "unknown_outcome",
                "answer": "",
                "tokens": 0,
                "model": model,
                "provider": provider,
                "real_call": True,
                "reconciliation_required": True,
                "error_class": "AmbiguousTransportOutcome",
                "request_count": attempt + 1,
            }
        return fail("; ".join(errors[-3:]) or "unknown provider error")

    def _mock_provider(self, prompt: str, model: str="mock-echo") -> Dict:
        lower=prompt.lower()
        # Support swarm model naming: kimi-k2.5:agent-swarm
        swarm_bonus = "swarm" in model.lower()
        base_tokens=120 if swarm_bonus else 80
        if "blast radius" in lower or "auth" in lower:
            ans="Blast radius: src/auth.ts (42 LOC), src/middleware/auth.ts, tests/auth.test.ts. Sources: https://example.com/auth-docs , https://example.com/security . Diff shows no writes outside ./src/**."
            if swarm_bonus: ans+=" [swarm 100-agent consensus]"
            return {"answer": ans, "tokens": base_tokens+40, "model": model}
        if "fix" in lower:
            return {"answer": "Fix applied to src/auth.ts: added verification check. Tests pass (exit 0). Diff: write src/auth.ts (1200 bytes).", "tokens": base_tokens+20, "model": model}
        if "cite" in lower or "source" in lower:
            return {"answer": "Answer with citations: https://example.com/source1 , https://example.com/source2", "tokens": base_tokens, "model": model}
        if "variable" in lower:
            return {"answer": f"[mock:{model}] Variable context preserved: {prompt[:80]}", "tokens": len(prompt)//4, "model": model}
        return {"answer": f"[mock:{model}] Completed: {prompt[:120]}", "tokens": len(prompt)//4, "model": model}


