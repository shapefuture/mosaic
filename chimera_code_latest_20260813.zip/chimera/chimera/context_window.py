"""Single source of truth for conservative request/output window budgeting."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class WindowBudget:
    context_tokens: int
    estimated_prompt_tokens: int
    reserve_tokens: int
    requested_output_tokens: int
    output_tokens: int
    clamped: bool
    source: str
    prompt_fits: bool = True
    overrun_tokens: int = 0
    token_kind: str = "estimate"


class ContextWindowPolicy:
    """Conservative model windows; unknown models use the configured safe cap."""

    WINDOWS = {
        "poolside/laguna-s-2.1:free": 262_144,
        "poolside/laguna-s-2.1": 1_048_576,
        "poolside/laguna-xs-2.1:free": 262_144,
        "poolside/laguna-xs-2.1": 262_144,
    }

    @classmethod
    def resolve(cls, model: str, fallback: int) -> tuple[int, str]:
        value = cls.WINDOWS.get(model.lower())
        return (value, "catalog") if value else (
            max(4_096, int(fallback)),
            "conservative-config",
        )

    @classmethod
    def budget(
        cls,
        model: str,
        prompt_text: str,
        requested_output: int,
        fallback: int,
        *,
        prompt_tokens: int | None = None,
        token_kind: str = "estimate",
    ) -> WindowBudget:
        context, source = cls.resolve(model, fallback)
        measured = (
            max(0, int(prompt_tokens))
            if prompt_tokens is not None
            else (len(prompt_text.encode("utf-8")) + 3) // 4
        )
        kind = token_kind if prompt_tokens is not None else "estimate"
        reserve = max(512, min(16_384, context // 20))
        minimum_output = 256
        prompt_fits = measured + reserve + minimum_output <= context
        available = max(0, context - measured - reserve)
        output = min(max(minimum_output, int(requested_output)), available) if prompt_fits else 0
        return WindowBudget(
            context_tokens=context,
            estimated_prompt_tokens=measured,
            reserve_tokens=reserve,
            requested_output_tokens=int(requested_output),
            output_tokens=output,
            clamped=output != int(requested_output),
            source=source,
            prompt_fits=prompt_fits,
            overrun_tokens=max(0, measured + reserve + minimum_output - context),
            token_kind=kind,
        )
