"""Closed, deeply immutable configuration and capability policy.

Unknown keys and invalid values fail explicitly.  Loading never catches a
validation error and silently substitutes defaults: that would turn a typo in a
security policy into a broader policy.  Credentials are not part of this schema;
provider adapters read them from the process environment only.
"""
from __future__ import annotations

import json
import pathlib
from collections.abc import Mapping
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

try:
    import tomllib
except ImportError:  # pragma: no cover - Python 3.11+ is required
    import tomli as tomllib
try:
    import tomli_w
except ImportError:
    tomli_w = None


class DeploymentProfile(StrEnum):
    LOCAL_OFFLINE = "LOCAL_OFFLINE"
    LOCAL_DETERMINISTIC = "LOCAL_DETERMINISTIC"
    DEV_EXTERNAL = "DEV_EXTERNAL"
    SHADOW_PRODUCTION = "SHADOW_PRODUCTION"
    SINGLE_TENANT_PRODUCTION = "SINGLE_TENANT_PRODUCTION"
    SELF_HOSTED = "SINGLE_TENANT_PRODUCTION"  # compatibility alias
    MULTI_TENANT_PRODUCTION = "MULTI_TENANT_PRODUCTION"
    CLOUD_MULTI_TENANT = "MULTI_TENANT_PRODUCTION"  # compatibility alias
    HIGH_AUTONOMY = "HIGH_AUTONOMY"
    REGULATED = "REGULATED"


class FrozenDict(dict):
    """A serializer-compatible dict that rejects every mutation path."""

    def _blocked(self, *args, **kwargs):
        raise TypeError("configuration mapping is frozen")

    __setitem__ = _blocked
    __delitem__ = _blocked
    clear = _blocked
    pop = _blocked
    popitem = _blocked
    setdefault = _blocked
    update = _blocked
    __ior__ = _blocked


def _deep_freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return FrozenDict({str(key): _deep_freeze(item) for key, item in value.items()})
    if isinstance(value, list):
        return tuple(_deep_freeze(item) for item in value)
    if isinstance(value, tuple):
        return tuple(_deep_freeze(item) for item in value)
    return value


class ClosedFrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class FSConfig(ClosedFrozenModel):
    allow: tuple[str, ...] = (
        "./src/**", "./tests/**", "./chimera/**", "./examples/**", "./docs/**",
        "./migrations/**", "./.github/**", "./Dockerfile", "./pyproject.toml",
        "./README.md", "./.chimera/**",
    )
    deny: tuple[str, ...] = (
        "./.env", "./.env.*", "./.chimera/auth.json", "/etc/**", "~/.ssh/**",
    )


class NetConfig(ClosedFrozenModel):
    allow: tuple[str, ...] = ("api.anthropic.com",)
    deny: tuple[str, ...] = ("169.254.169.254", "10.*", "192.168.*")


class EnvConfig(ClosedFrozenModel):
    allow: tuple[str, ...] = ("PATH", "CHIMERA_*")
    deny: tuple[str, ...] = ("AWS_*", "GITHUB_TOKEN", "*_API_KEY", "*_TOKEN", "*_SECRET")


class MCPConfig(ClosedFrozenModel):
    allow: tuple[str, ...] = ()
    deny: tuple[str, ...] = ()


class Capabilities(ClosedFrozenModel):
    fs: FSConfig = Field(default_factory=FSConfig)
    net: NetConfig = Field(default_factory=NetConfig)
    env: EnvConfig = Field(default_factory=EnvConfig)
    mcp: MCPConfig = Field(default_factory=MCPConfig)


class SandboxConfig(ClosedFrozenModel):
    fuel: int = Field(default=1_000_000, gt=0)
    timeout_ms: int = Field(default=30_000, gt=0, le=3_600_000)
    mem_mb: int = Field(default=512, gt=0, le=1_048_576)
    workDir: str = "."


class RequiredGateConfig(ClosedFrozenModel):
    id: str
    command: str
    scope: str = "repository"
    max_age_seconds: int = Field(default=3600, ge=1)


class QualityConfig(ClosedFrozenModel):
    mutation_mode: Literal["off", "high-risk", "always"] = "high-risk"
    max_mutants: int = Field(default=2, ge=0, le=20)
    minimum_kill_rate: float = Field(default=0.5, ge=0.0, le=1.0)
    enforce_mutation_gate: bool = False
    required_gates: tuple[RequiredGateConfig, ...] = ()


class PlannerConfig(ClosedFrozenModel):
    token_budget: int = Field(default=100_000, gt=0)
    agent_timeout: int = Field(default=600, gt=0, le=86_400)
    max_parallel: int = Field(default=4, gt=0, le=256)
    diminishing_threshold: float = Field(default=0.05, ge=0.0, le=1.0)
    tool_surface: Literal["single", "legacy", "kernel"] = "single"
    # Default quality/speed policy: use one shared native observation turn only
    # for tasks whose multi-target shape can amortize it, then let focused atoms
    # synthesize and test patches transactionally.
    hybrid_observation: Literal["off", "auto", "always"] = "auto"
    hybrid_max_paths: int = Field(default=12, ge=1, le=64)
    max_actions_per_run: int = Field(default=16, ge=1, le=64)
    context_max_tokens: int = Field(default=25_000, ge=1_000, le=1_000_000)
    context_max_chars: int = Field(default=100_000, ge=4_000, le=4_000_000)


DEFAULT_CONFIG: dict[str, Any] = {
    "version": "4.4.0",
    "workspace_root": ".",
    "deployment_profile": DeploymentProfile.LOCAL_DETERMINISTIC.value,
    "capabilities": Capabilities().model_dump(mode="json"),
    "sandbox": SandboxConfig().model_dump(mode="json"),
    "planner": PlannerConfig().model_dump(mode="json"),
    "quality": QualityConfig().model_dump(mode="json"),
    "models": {"default": "mock-echo"},
}


class ChimeraConfig(ClosedFrozenModel):
    version: str = "4.4.0"
    workspace_root: str = "."
    # Compatibility-safe default for source checkouts. Production profiles are
    # still explicit enum values; there is no implicit production mode.
    deployment_profile: DeploymentProfile = DeploymentProfile.LOCAL_DETERMINISTIC
    capabilities: Capabilities = Field(default_factory=Capabilities)
    sandbox: SandboxConfig = Field(default_factory=SandboxConfig)
    planner: PlannerConfig = Field(default_factory=PlannerConfig)
    quality: QualityConfig = Field(default_factory=QualityConfig)
    models: dict[str, Any] = Field(default_factory=lambda: FrozenDict({"default": "mock-echo"}))

    @field_validator("models", mode="after")
    @classmethod
    def _freeze_models(cls, value: Mapping[str, Any]) -> dict[str, Any]:
        # Model routing config is policy too; BaseModel(frozen=True) alone is
        # shallow and would still allow config.models["default"] = ... .
        return _deep_freeze(value)

    @field_validator("workspace_root", mode="after")
    @classmethod
    def _workspace_root_is_not_empty(cls, value: str) -> str:
        if not value.strip() or "\x00" in value:
            raise ValueError("workspace_root must be a non-empty path without NUL bytes")
        return value

    @classmethod
    def load(cls, path: pathlib.Path | None = None) -> "ChimeraConfig":
        if path is None:
            for candidate in (
                pathlib.Path("chimera.toml"),
                pathlib.Path(".chimera/config.toml"),
                pathlib.Path("capability.toml"),
            ):
                if candidate.exists():
                    path = candidate
                    break
        if path is None or not path.exists():
            return cls()

        raw = tomllib.loads(path.read_text())
        if not isinstance(raw, dict):
            raise ValueError(f"{path}: top-level TOML value must be a table")
        # Support the historical [chimera] table without accepting it as an
        # unvalidated extra field. Sibling policy blocks remain top-level.
        data = dict(raw)
        base = data.pop("chimera", {})
        if base and not isinstance(base, dict):
            raise ValueError(f"{path}: [chimera] must be a table")
        merged = {**dict(base), **data}
        # Validation errors intentionally propagate with precise field paths.
        return cls.model_validate(merged)

    @staticmethod
    def _plain(value: Any) -> Any:
        if isinstance(value, Mapping):
            return {str(key): ChimeraConfig._plain(item) for key, item in value.items()}
        if isinstance(value, (tuple, list)):
            return [ChimeraConfig._plain(item) for item in value]
        if isinstance(value, StrEnum):
            return value.value
        return value

    def save(self, path: pathlib.Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        data = self._plain(self.model_dump())
        if path.suffix.lower() == ".json":
            path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
            return
        if tomli_w is None:
            raise RuntimeError("Saving TOML requires the optional 'tomli-w' package")
        path.write_text(tomli_w.dumps(data))

    def to_capability_set(self):
        from .effects import CapabilitySet

        return CapabilitySet(
            fs_allow=list(self.capabilities.fs.allow),
            fs_deny=list(self.capabilities.fs.deny),
            net_allow=list(self.capabilities.net.allow),
            net_deny=list(self.capabilities.net.deny),
            env_allow=list(self.capabilities.env.allow),
            env_deny=list(self.capabilities.env.deny),
            mcp_allow=list(self.capabilities.mcp.allow),
            mcp_deny=list(self.capabilities.mcp.deny),
        )
