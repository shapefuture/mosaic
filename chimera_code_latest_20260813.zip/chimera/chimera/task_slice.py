"""Hexagonal task-slice contracts for safe parallel coding atoms.

A parallel coding atom owns a small write slice, declares its local acceptance
and test command, and returns a patch/evidence artifact through the integration
branch.  The scheduler may run atoms concurrently only when their ownership
slices do not overlap or a dependency serializes them.

This does not replace CAS merge: it prevents predictable conflicts early, while
CAS remains the final authority against races and changed parent state.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Iterable, Mapping

from pydantic import BaseModel, ConfigDict, Field


class TaskSlice(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    atom_id: str
    owned_paths: tuple[str, ...]
    protected_paths: tuple[str, ...] = ()
    acceptance: tuple[str, ...] = ()
    test_command: str = "pytest -q"
    integration_branch: str = "integration"
    contract_hash: str

    @staticmethod
    def _normalize(path: str) -> str:
        return str(path).replace("\\", "/").removeprefix("./").rstrip("/")

    @classmethod
    def paths_overlap(cls, left: str, right: str) -> bool:
        a, b = cls._normalize(left), cls._normalize(right)
        return a == b or a.startswith(b + "/") or b.startswith(a + "/")

    @classmethod
    def build(
        cls, *, atom_id: str, owned_paths: Iterable[str], protected_paths: Iterable[str] = (),
        acceptance: Iterable[str] = (), test_command: str = "pytest -q", integration_branch: str = "integration",
    ) -> "TaskSlice":
        owned = tuple(sorted(dict.fromkeys(cls._normalize(path) for path in owned_paths if path)))
        protected = tuple(sorted(dict.fromkeys(cls._normalize(path) for path in protected_paths if path)))
        payload = {
            "atom_id": atom_id, "owned_paths": owned, "protected_paths": protected,
            "acceptance": tuple(str(item) for item in acceptance), "test_command": test_command,
            "integration_branch": integration_branch,
        }
        digest = "sha256:" + hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        return cls(**payload, contract_hash=digest)

    def violations(self, paths: Iterable[str]) -> tuple[str, ...]:
        invalid: list[str] = []
        for raw in paths:
            path = self._normalize(raw)
            if path.startswith(".chimera/"):
                continue  # private harness receipts are not user-workspace ownership.
            if not any(self.paths_overlap(path, owned) for owned in self.owned_paths):
                invalid.append(path)
            if any(self.paths_overlap(path, protected) for protected in self.protected_paths):
                invalid.append(path)
        return tuple(sorted(dict.fromkeys(invalid)))


def serialize_overlapping_atoms(atoms: Iterable[Any], phases: Mapping[str, int] | None = None) -> list[dict[str, Any]]:
    """Add deterministic dependencies for overlapping task ownership.

    The function accepts the compiler's TaskUnit-like objects by duck typing so
    it does not pull hierarchy planning into the runtime execution core.
    """
    phase_map = dict(phases or {})
    ordered = sorted(list(atoms), key=lambda atom: (phase_map.get(str(atom.id), 0), str(atom.id)))
    prior: list[Any] = []
    constraints: list[dict[str, Any]] = []
    for atom in ordered:
        dependencies = list(getattr(atom, "dependencies", []) or [])
        for earlier in prior:
            overlaps = sorted({
                str(path)
                for path in getattr(atom, "targets", []) or []
                for other in getattr(earlier, "targets", []) or []
                if TaskSlice.paths_overlap(str(path), str(other))
            })
            if overlaps and str(earlier.id) not in dependencies:
                dependencies.append(str(earlier.id))
                constraints.append({"before": str(earlier.id), "after": str(atom.id), "paths": overlaps})
        atom.dependencies = sorted(set(dependencies))
        prior.append(atom)
    return constraints


def slice_from_mapping(value: Mapping[str, Any]) -> TaskSlice:
    return TaskSlice.model_validate(dict(value))
