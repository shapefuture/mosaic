"""Release performance gates for regression detection across repo profiles."""
from __future__ import annotations
from dataclasses import dataclass, asdict
import pathlib, time
from .wal import WAL
from .sandbox import Sandbox

@dataclass(frozen=True)
class RepoProfile:
    files:int; bytes:int; dependency_heavy:bool; name:str
    def as_dict(self): return asdict(self)

@dataclass(frozen=True)
class PerformanceGateResult:
    name:str; duration_ms:float; threshold_ms:float; passed:bool; profile:str="unknown"
    def as_dict(self): return asdict(self)

class PerformanceGateRunner:
    def __init__(self, root:pathlib.Path): self.root=pathlib.Path(root)
    def repo_profile(self)->RepoProfile:
        files=0; total=0; dep=False
        for p in self.root.rglob('*'):
            rel=p.relative_to(self.root).parts
            if any(part in {'.chimera','.git','__pycache__','.pytest_cache'} for part in rel): continue
            if any(part in {'node_modules','.venv','build','dist','target'} for part in rel): dep=True
            if p.is_file():
                files+=1
                try:
                    total+=p.stat().st_size
                except OSError:
                    # An unreadable dependency makes the profile conservative
                    # rather than silently shrinking the measured repository.
                    dep=True
        if dep: name='dependency-heavy'
        elif files<100: name='small'
        elif files<2000: name='medium'
        else: name='large'
        return RepoProfile(files,total,dep,name)
    def threshold(self, gate:str)->float:
        profile=self.repo_profile().name
        table={
            'wal_batch_100': {'small':500,'medium':750,'large':1200,'dependency-heavy':1500},
            'sandbox_echo': {'small':2000,'medium':3000,'large':5000,'dependency-heavy':8000},
        }
        return float(table[gate][profile])
    def wal_batch_100(self, threshold_ms:float|None=None)->PerformanceGateResult:
        prof=self.repo_profile(); threshold_ms=self.threshold('wal_batch_100') if threshold_ms is None else threshold_ms
        wal=WAL(self.root); start=time.perf_counter(); wal.append_batch([(f'perf_{i}',{}) for i in range(100)]); dur=(time.perf_counter()-start)*1000
        return PerformanceGateResult('wal_batch_100',round(dur,3),threshold_ms,dur<=threshold_ms,prof.name)
    def sandbox_echo(self, threshold_ms:float|None=None)->PerformanceGateResult:
        prof=self.repo_profile(); threshold_ms=self.threshold('sandbox_echo') if threshold_ms is None else threshold_ms
        start=time.perf_counter(); res=Sandbox(self.root).exec('echo ok',timeout=5); dur=(time.perf_counter()-start)*1000
        return PerformanceGateResult('sandbox_echo',round(dur,3),threshold_ms,res.status==0 and dur<=threshold_ms,prof.name)
    def run_all(self)->tuple[PerformanceGateResult,...]: return (self.wal_batch_100(), self.sandbox_echo())
