"""Supreme release/readiness gate.

Composes the strongest local evidence gates into one non-promotional receipt.
It is deliberately conservative: a pass means local structural gates passed, not
that cloud/live-provider infrastructure has been certified.
"""
from __future__ import annotations

import pathlib
import tempfile
from dataclasses import asdict, dataclass
from typing import Any

from .agent_shard_controller import cloud_scale_smoke
from .antifragile_architecture import AntifragileArchitectureAudit
from .architecture_ratchet import ArchitectureRatchet
from .benchmark_exploit_scanner import BenchmarkExploitScanner
from .project_forge_agent import ProjectForgeAgent
from .self_improvement_recursion import RecursiveSelfImprovementPlanner
from .stack_benchmarks import StackBenchmarkRunner
from .token_error_tax import TokenErrorTaxAnalyzer
from .candidate_promotion_gate import CandidatePromotionGate


@dataclass(frozen=True)
class GateVerdict:
    name: str
    status: str  # pass | review | fail
    evidence: str
    action: str


class SupremeGate:
    """Run a short, local, high-signal readiness gate."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def run(
        self,
        *,
        scan_path: pathlib.Path | None = None,
        agents: int = 1000,
        tenants: int = 100,
        project_prompt: str = "Should Chimera add or modify infrastructure for this engineering task?",
    ) -> dict[str, Any]:
        scan_root = pathlib.Path(scan_path).resolve() if scan_path is not None else self.root
        architecture = AntifragileArchitectureAudit(self.root).run()
        ratchet = ArchitectureRatchet(self.root).run()
        exploit = BenchmarkExploitScanner(scan_root).scan()
        cloud = cloud_scale_smoke(self.root, agents=agents, tenants=tenants)
        token_tax = TokenErrorTaxAnalyzer(self.root).analyze()
        recursive = RecursiveSelfImprovementPlanner(self.root).structural_receipt()
        forge = ProjectForgeAgent(self.root).plan(project_prompt, paths=("chimera",))
        candidate_gate = self._candidate_task_bank_smoke()
        benchmarks = {
            "gateway": StackBenchmarkRunner(self.root).gateway(candidates=("direct-mock",), operations=10),
            "event_bus": StackBenchmarkRunner(self.root).event_bus(candidates=("jsonl",), operations=10),
            "cache": StackBenchmarkRunner(self.root).cache(candidates=("memory",), operations=10),
            "durable": StackBenchmarkRunner(self.root).durable(candidates=("local-step",), operations=10),
            "sandbox": StackBenchmarkRunner(self.root).sandbox(candidates=("local-process",), operations=1),
        }
        verdicts = self._verdicts(architecture, ratchet, exploit, cloud, recursive, forge, benchmarks, candidate_gate)
        failures = [v.name for v in verdicts if v.status == "fail"]
        reviews = [v.name for v in verdicts if v.status == "review"]
        return {
            "schema_version": "chimera.supreme-gate.v1",
            "root": str(self.root),
            "scan_path": str(scan_root),
            "status": "fail" if failures else "review" if reviews else "pass",
            "failures": failures,
            "reviews": reviews,
            "verdicts": [asdict(v) for v in verdicts],
            "evidence": {
                "architecture": architecture,
                "architecture_ratchet": ratchet,
                "exploit_scan": exploit,
                "cloud_scale_smoke": cloud,
                "token_error_tax": token_tax,
                "recursive_self_improvement": recursive,
                "project_forge": forge,
                "benchmarks": benchmarks,
                "candidate_task_bank_gate": candidate_gate,
            },
            "promotion_allowed": False,
            "promotion_rule": "Supreme gate is necessary but not sufficient. Promotion still requires task-specific hidden tests, exploit scan over candidate diff/worktree, rollback artifact, and deployment/live-provider receipts when relevant.",
        }

    def _candidate_task_bank_smoke(self) -> dict[str, Any]:
        with tempfile.TemporaryDirectory(prefix="chimera-supreme-candidate-") as td:
            candidate = pathlib.Path(td)
            pkg = candidate / "chimera_tasks"
            pkg.mkdir(parents=True, exist_ok=True)
            (pkg / "flags.py").write_text(
                "def parse_flags(text):\n"
                "    out={}\n"
                "    for part in str(text).split():\n"
                "        if not part.startswith('--'): continue\n"
                "        item=part[2:]\n"
                "        if '=' in item:\n"
                "            k,v=item.split('=',1)\n"
                "            if k in out:\n"
                "                out[k]=out[k]+[v] if isinstance(out[k], list) else [out[k], v]\n"
                "            else: out[k]=v\n"
                "        else: out[item]=True\n"
                "    return out\n",
                encoding="utf-8",
            )
            return CandidatePromotionGate(self.root).evaluate(
                candidate,
                task="supreme gate evaluator-owned task bank smoke",
                task_bank_id="parse_flags_recursive_v1",
                authorize_promotion_evaluation=True,
                timeout_seconds=60,
            )

    @staticmethod
    def _verdicts(architecture: dict[str, Any], ratchet: dict[str, Any], exploit: dict[str, Any], cloud: dict[str, Any], recursive: dict[str, Any], forge: dict[str, Any], benchmarks: dict[str, Any], candidate_gate: dict[str, Any]) -> list[GateVerdict]:
        out: list[GateVerdict] = []
        out.append(GateVerdict(
            "antifragile-architecture",
            "pass" if architecture.get("status") == "pass" else "fail",
            f"status={architecture.get('status')} failures={architecture.get('failures')}",
            "keep optional stack behind adapters and gates",
        ))
        out.append(GateVerdict(
            "architecture-ratchet",
            "fail" if ratchet.get("status") == "fail" else "review" if ratchet.get("status") == "review" else "pass",
            f"status={ratchet.get('status')} findings={len(ratchet.get('findings', []))}",
            "split or freeze modules that exceed ratchet",
        ))
        out.append(GateVerdict(
            "benchmark-exploit-scan",
            "fail" if exploit.get("blocker_count") else "review" if exploit.get("finding_count") else "pass",
            f"status={exploit.get('status')} blockers={exploit.get('blocker_count')} findings={exploit.get('finding_count')}",
            "candidate promotion requires clean scan or evaluator-owned waiver",
        ))
        out.append(GateVerdict(
            "cloud-scale-smoke",
            "pass" if cloud.get("all_leases_unique") and cloud.get("drain_successful") and not cloud.get("overloaded_shards") else "fail",
            f"agents={cloud.get('agents')} shards={cloud.get('suggested_shards')} overloaded={len(cloud.get('overloaded_shards', {}))}",
            "run same smoke in deployment image before claiming cloud readiness",
        ))
        out.append(GateVerdict(
            "recursive-self-improvement",
            "pass" if recursive.get("next_iteration_superiority_required") and not recursive.get("promotion_allowed") else "fail",
            "next iteration superiority required and structural receipt is non-promotional",
            "require executable next-iteration evidence before promoting self-improvement changes",
        ))
        gate_statuses = {gate["id"]: gate["status"] for gate in forge.get("gates", [])}
        out.append(GateVerdict(
            "project-forge-gates",
            "pass" if gate_statuses.get("gate-1") in {"run", "skipped"} and gate_statuses.get("gate-2") in {"run", "skipped"} else "fail",
            f"gate statuses={gate_statuses}",
            "run find-before-build and lean-by-default for infrastructure coding tasks",
        ))
        out.append(GateVerdict(
            "candidate-task-bank-promotion-gate",
            "pass" if candidate_gate.get("evaluation_passed") and not candidate_gate.get("failures") else "fail",
            f"promotion_allowed={candidate_gate.get('promotion_allowed')} failures={candidate_gate.get('failures')}",
            "candidate gate must pass evaluator-owned hidden task smoke",
        ))
        bench_failures = []
        for name, receipt in benchmarks.items():
            if not receipt.get("results") or receipt["results"][0].get("status") != "ran":
                bench_failures.append(name)
        out.append(GateVerdict(
            "local-baseline-benchmarks",
            "pass" if not bench_failures else "fail",
            f"failed baselines={bench_failures}",
            "local baselines must run even when external services skip",
        ))
        return out
