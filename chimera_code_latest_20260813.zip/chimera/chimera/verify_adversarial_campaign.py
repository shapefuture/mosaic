"""Short verify_benchmark-inspired adversarial campaign over Chimera itself."""
from __future__ import annotations

import json
import os
import pathlib
import subprocess
import sys
import tempfile
import time
from dataclasses import asdict, dataclass
from typing import Any, Callable

from .antifragile_architecture import AntifragileArchitectureAudit
from .cloud_scale_readiness import CloudScaleReadinessPlanner
from .run_event_bus import RunEventBus
from .stack_alternatives import StackAlternativesPlanner
from .stack_benchmarks import StackBenchmarkRunner
from .testing_environment import TestingEnvironment, TransientEnvironmentError
from .trace_context import inject_trace_context_into_meta
from .wal import WAL
from .otel_mapping import wal_to_otel_spans


@dataclass(frozen=True)
class ShortVerifyTask:
    id: str
    prompt: str
    adversarial_property: str


@dataclass(frozen=True)
class ShortVerifyResult:
    task_id: str
    visible_passed: bool
    hidden_passed: bool
    adversarial_passed: bool
    details: dict[str, Any]


class ShortChimeraVerifyAdversarialCampaign:
    """Evaluator-owned short tasks against Chimera code/config surfaces.

    This is intentionally short and local.  It does not let Chimera self-certify
    broad provider capability; live TokenRouter/Kimi canary runs only when the
    explicit transient testing flag and route are present.
    """

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root).resolve()

    def run(self, *, live_tokenrouter: bool = False) -> dict[str, Any]:
        started = time.perf_counter()
        tasks = self.tasks()
        results = [self._run_task(task) for task in tasks]
        provider = self._maybe_tokenrouter_canary(live_tokenrouter=live_tokenrouter)
        hidden_failures = [r.task_id for r in results if not r.hidden_passed]
        adversarial_failures = [r.task_id for r in results if not r.adversarial_passed]
        payload = {
            "schema_version": "chimera.short-verify-adversarial-campaign.v1",
            "verify_benchmark_inspired": True,
            "hidden_tests_evaluator_owned": True,
            "task_count": len(tasks),
            "tasks": [asdict(task) for task in tasks],
            "results": [asdict(result) for result in results],
            "provider_canary": provider,
            "hidden_failures": hidden_failures,
            "adversarial_failures": adversarial_failures,
            "all_passed": not hidden_failures and not adversarial_failures,
            "repository_promotion_applied": False,
            "promotion_allowed": False,
            "duration_ms": round((time.perf_counter() - started) * 1000, 3),
            "limits": [
                "Short local campaign; validates Chimera protocol/architecture/cloud gates, not general SWE-bench capability.",
                "Live TokenRouter/Kimi canary is skipped unless CHIMERA_TESTING_ENVIRONMENT=1 and route guard match.",
            ],
        }
        return payload

    @staticmethod
    def tasks() -> tuple[ShortVerifyTask, ...]:
        return (
            ShortVerifyTask(
                "protocol_trace_surface_v1",
                "Verify AG-UI projection, outbound trace context metadata, and OpenInference span enrichment compose without secrets.",
                "protocol adapters must preserve traceability without making optional telemetry backends mandatory",
            ),
            ShortVerifyTask(
                "stack_semantic_tiers_v1",
                "Verify stack alternatives separate queue/workflow/durable-service and trusted/semi-trusted/hostile sandbox tiers.",
                "adversary attempts to promote cheaper components as semantically equivalent replacements",
            ),
            ShortVerifyTask(
                "cloud_scale_gate_v1",
                "Verify thousands-agent cloud readiness creates shard plan and still refuses false live certification.",
                "adversary attempts to turn a planning receipt into production certification",
            ),
            ShortVerifyTask(
                "benchmark_control_plane_v1",
                "Verify local benchmark baselines run and external candidates skip honestly with promotion disabled.",
                "adversary attempts to infer unavailable external service success from local baseline",
            ),
        )

    def _run_task(self, task: ShortVerifyTask) -> ShortVerifyResult:
        runners: dict[str, Callable[[], tuple[bool, bool, bool, dict[str, Any]]]] = {
            "protocol_trace_surface_v1": self._protocol_trace_surface,
            "stack_semantic_tiers_v1": self._stack_semantic_tiers,
            "cloud_scale_gate_v1": self._cloud_scale_gate,
            "benchmark_control_plane_v1": self._benchmark_control_plane,
        }
        try:
            visible, hidden, adversarial, details = runners[task.id]()
        except Exception as exc:
            return ShortVerifyResult(task.id, False, False, False, {"error": type(exc).__name__, "message": str(exc)[:500]})
        return ShortVerifyResult(task.id, visible, hidden, adversarial, details)

    def _protocol_trace_surface(self) -> tuple[bool, bool, bool, dict[str, Any]]:
        with tempfile.TemporaryDirectory(prefix="chimera-short-protocol-") as td:
            root = pathlib.Path(td)
            bus = RunEventBus(root)
            bus.append("run-1", "tool.started", {"tool": "pytest", "arguments": {"authorization": "secret-token"}})
            agui = bus.replay_ag_ui(run_id="run-1")
            WAL(root).append("provider.call", {"provider": "mock", "model": "m", "usage": {"prompt_tokens": 2, "completion_tokens": 3}, "tool": "pytest"})
            spans = wal_to_otel_spans(root)
        meta = inject_trace_context_into_meta({})
        visible = agui and agui[0]["type"] == "TOOL_CALL_START" and spans[0]["attributes"].get("openinference.span.kind") == "LLM"
        hidden = agui[0]["args"].get("authorization") == "[REDACTED]" and spans[0]["attributes"].get("llm.token_count.prompt") == 2
        adversarial = "authorization" not in json.dumps(agui).lower() or "[REDACTED]" in json.dumps(agui)
        return visible, hidden, adversarial, {"agui_type": agui[0]["type"], "span_kind": spans[0]["attributes"].get("openinference.span.kind"), "trace_meta_keys": sorted(meta)}

    def _stack_semantic_tiers(self) -> tuple[bool, bool, bool, dict[str, Any]]:
        plan = StackAlternativesPlanner(self.root).plan()
        by_name = {item["name"]: item for item in plan["alternatives"]}
        visible = all(name in by_name for name in ("restate", "honker", "crun-youki", "kata-cloud-hypervisor"))
        hidden = by_name["honker"]["category"] == "queue" and by_name["rivet-actors-runtime"]["category"] == "durable-execution"
        crun_text = " ".join([by_name["crun-youki"]["kill_criterion"], *by_name["crun-youki"]["notes"]]).lower()
        adversarial = "shared-kernel" in crun_text or "host kernel" in crun_text
        return visible, hidden, adversarial, {"categories": {k: by_name[k]["category"] for k in ("restate", "honker", "crun-youki")}}

    def _cloud_scale_gate(self) -> tuple[bool, bool, bool, dict[str, Any]]:
        plan = CloudScaleReadinessPlanner(self.root).plan(agents=5000, tenants=500, mode="k8s")
        visible = plan["shard_plan"]["agents"] == 5000 and plan["shard_plan"]["suggested_shards"] >= 20
        hidden = plan["local_mode_preserved"] is True and "runtime-density" in plan["warnings"]
        adversarial = plan["promotion_allowed"] is False and plan["repository_promotion_applied"] is False if "repository_promotion_applied" in plan else plan["promotion_allowed"] is False
        return visible, hidden, adversarial, {"shard_plan": plan["shard_plan"], "warnings": plan["warnings"], "promotion_allowed": plan["promotion_allowed"]}

    def _benchmark_control_plane(self) -> tuple[bool, bool, bool, dict[str, Any]]:
        runner = StackBenchmarkRunner(self.root)
        gateway = runner.gateway(candidates=("direct-mock", "agentify-gateway"), operations=5)
        sandbox = runner.sandbox(candidates=("local-process", "crun"), operations=1)
        durable = runner.durable(candidates=("local-step", "honker"), operations=5)
        visible = gateway["results"][0]["status"] == "ran" and sandbox["results"][0]["status"] == "ran"
        hidden = gateway["results"][1]["status"] == "skipped" and durable["results"][1]["details"].get("semantic_warning") == "not a full durable workflow replacement"
        adversarial = all(receipt["promotion_allowed"] is False for receipt in (gateway, sandbox, durable))
        return visible, hidden, adversarial, {"gateway": gateway["results"], "sandbox": sandbox["results"], "durable": durable["results"]}

    def _maybe_tokenrouter_canary(self, *, live_tokenrouter: bool) -> dict[str, Any]:
        model = TestingEnvironment.TOKENROUTER_MODEL
        if not live_tokenrouter:
            return {"status": "skipped", "reason": "live_tokenrouter flag not requested", "raw_key_recorded": False}
        try:
            TestingEnvironment.require_tokenrouter_kimi(model=model)
        except TransientEnvironmentError as exc:
            return {"status": "skipped", "reason": str(exc), "raw_key_recorded": False}
        if not (os.environ.get("TOKENROUTER_API_KEY") or os.environ.get("TOKENROUTER_KEY")):
            return {"status": "skipped", "reason": "TOKENROUTER_API_KEY/TOKENROUTER_KEY not present in transient environment", "raw_key_recorded": False}
        cmd = [sys.executable, "-m", "chimera.cli", "provider-canary", "tokenrouter/moonshotai/kimi-k3-free", "--capability", "strict_json", "--authorize-live-call"]
        completed = subprocess.run(cmd, cwd=self.root, text=True, capture_output=True, timeout=120, check=False)
        return {
            "status": "ran" if completed.returncode == 0 else "failed",
            "returncode": completed.returncode,
            "stdout_tail": completed.stdout[-1000:],
            "stderr_tail": completed.stderr[-1000:],
            "raw_key_recorded": False,
            "transient_flag": True,
        }
