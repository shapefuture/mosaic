"""Dry-run local handoff bundle for snapshot-consistent workflow migration."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import pathlib
from typing import Any, Mapping

from .artifacts import ContentAddressedArtifactStore
from .resume_identity import ResumeIdentity
from .wait_registry import WaitRegistry


@dataclass(frozen=True)
class HandoffBundle:
    resume_identity: str
    workspace_diff_hash: str
    run_projection_hash: str
    pending_wait_ids: tuple[str, ...]
    artifact_ref: str


class LocalHandoffBundleBuilder:
    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root)
        self.artifacts = ContentAddressedArtifactStore(self.root)
        self.waits = WaitRegistry(self.root)

    def create(self, *, identity: ResumeIdentity, workspace_diff: Mapping[str, Any], run_projection: Mapping[str, Any], run_id: str) -> HandoffBundle:
        diff_raw = json.dumps(dict(workspace_diff), sort_keys=True, separators=(",", ":"), default=str).encode()
        projection_raw = json.dumps(dict(run_projection), sort_keys=True, separators=(",", ":"), default=str).encode()
        pending = self.waits.pending(run_id)
        payload = {
            "schema_version": "chimera.local-handoff-bundle.v1",
            "resume_identity": identity.as_dict(),
            "workspace_diff": dict(workspace_diff),
            "run_projection": dict(run_projection),
            "pending_waits": [asdict(wait) for wait in pending],
        }
        ref = self.artifacts.put(json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str), media_type="application/vnd.chimera.local-handoff+json", provenance={"run_id": run_id, "resume_identity": identity.digest})
        return HandoffBundle(identity.digest, "sha256:" + hashlib.sha256(diff_raw).hexdigest(), "sha256:" + hashlib.sha256(projection_raw).hexdigest(), tuple(wait.id for wait in pending), "artifact:" + ref.digest)

    def restore(self, bundle: HandoffBundle, *, identity: ResumeIdentity) -> dict[str, Any]:
        if bundle.resume_identity != identity.digest:
            raise ValueError("handoff bundle resume identity does not match current execution")
        payload = json.loads(self.artifacts.get(bundle.artifact_ref.removeprefix("artifact:")).decode())
        if payload.get("resume_identity", {}).get("digest") != identity.digest:
            raise ValueError("handoff payload identity mismatch")
        return payload
