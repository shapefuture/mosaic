"""Hexagonal GUI ports for future desktop/web clients.

GUI adapters must depend on these ports/use cases, not on runtime internals.
This keeps Tauri/Dioxus/web dashboards replaceable and tenant-safe.
"""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol, runtime_checkable


@dataclass(frozen=True)
class GuiTenantSession:
    tenant_key: str | None
    principal_hash: str | None
    scopes: tuple[str, ...] = ()
    trace_id: str | None = None


@dataclass(frozen=True)
class GuiNavigationItem:
    id: str
    title: str
    kind: Literal["dashboard", "run", "graph", "telemetry", "settings"]
    badge: str | None = None


@dataclass(frozen=True)
class GuiViewModel:
    schema_version: str
    title: str
    navigation: tuple[GuiNavigationItem, ...]
    panels: Mapping[str, Any]
    redactions: tuple[str, ...] = ()


@dataclass(frozen=True)
class GuiAction:
    id: str
    kind: Literal["run_task", "open_session", "query_graph", "verify_branch", "cancel_session", "read_telemetry"]
    payload: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class GuiActionResult:
    ok: bool
    status: str
    data: Mapping[str, Any] = field(default_factory=dict)
    error: str | None = None


@runtime_checkable
class GuiReadPort(Protocol):
    def dashboard(self, session: GuiTenantSession) -> GuiViewModel: ...
    def telemetry(self, session: GuiTenantSession, *, recent: int = 200) -> Mapping[str, Any]: ...
    def graph_query(self, session: GuiTenantSession, query: str, *, limit: int = 20) -> Mapping[str, Any]: ...


@runtime_checkable
class GuiCommandPort(Protocol):
    def dispatch(self, session: GuiTenantSession, action: GuiAction) -> GuiActionResult: ...


class GuiApplicationPort(GuiReadPort, GuiCommandPort, Protocol):
    """Primary inbound GUI port implemented by a GUI adapter facade."""
