# 60-query 2026 research grounding — capability per KB / observability / GUI / cloud / self-improvement

## Execution note

A 60-query sweep was executed after the user correctly pointed out that the previous turn used only a targeted subset. Queries covered English and Chinese sources across:

- AI/LLM/agent observability and OpenTelemetry GenAI;
- MCP trace propagation;
- token/cost telemetry and FinOps;
- GUI frameworks and AG-UI;
- durable/serverless agents;
- multi-tenant LLM serving;
- prompt/tool/context compression;
- Rust graph/code intelligence;
- self-improving agents and adversarial benchmark safety;
- ultra-low-footprint agent runtimes;
- browser/Exa search adapters.

## Strongest findings for Chimera

### 1. Observability must be structural, not logs

2026 sources converge on OpenTelemetry/OpenInference-style span trees for every meaningful LLM, tool, retriever, and agent step. Chimera should map every run to span kinds and token/cost/latency fields; content should be redacted by default.

### 2. MCP trace propagation via `_meta.traceparent` is now the right direction

MCP trace context in `params._meta` is documented and adopted by agent frameworks. Chimera implemented receiving/returning `traceparent`; next step is auto-injecting outbound MCP `_meta` on client/proxy calls.

### 3. GCF is highly aligned with Chimera

GCF's graph/session/delta model matches Chimera's code graph, tool result, telemetry and multi-turn agent loops. Chimera already uses GCF at model/tool boundaries; next step is extending GCF to telemetry tables and GUI graph payload streams.

### 4. GUI choice remains Tauri + Svelte/Solid for the primary UI

Tauri remains the best desktop shell for cloud-first web UI due to lower footprint than Electron and Rust backend isolation. Chinese/English GUI comparisons reinforce: Tauri for web-to-desktop production apps; egui for debug/internal tooling; Slint for embedded/ultra-low-resource; GPUI for high-performance editor-like apps if we commit to a native stack.

### 5. AG-UI is the missing user-facing event grammar

AG-UI is increasingly the right event protocol above SSE/WebSocket for agent UI: text chunks, tool events, state deltas, approval events. Chimera's run-event bus should adopt AG-UI-like event names while preserving its own evidence semantics.

### 6. Durable cloud execution: DBOS + Restate remains a strong pair

Research comparing durable execution patterns supports Chimera's split: DBOS/Postgres for zero-new-infra database-backed durability and Restate for serverless durable services/agents that scale to zero while waiting on approvals.

### 7. Multi-tenant LLM serving needs quotas, tenant tags, and request-level attribution

Sources emphasize tenant identity propagation, token quotas, and per-tenant observability in vLLM/LiteLLM-style stacks. Chimera should keep tenant tags in telemetry, provider billing ledger, quotas, and GUI dashboards.

### 8. Self-improvement must be evaluator-owned

2026 RSI/self-improvement sources emphasize generator/critic/metacritic/task-curriculum loops but also reward hacking and benchmark exploitation risks. Chimera's hidden-test/metacritic/no-promotion-by-default design is aligned.

### 9. For capability per KB, the frontier is tiny resident kernels + external memory/state

Claw-family and ZeroClaw/NullClaw-style claims reinforce the key idea: keep resident agent loops tiny; externalize memory, content, graph, and durable state. Chimera should prototype a zygote/forkserver hot kernel and measure PSS per agent.

### 10. Missing/superior ideas to add next

- AG-UI-compatible event schema over existing SSE/WebSocket.
- Outbound MCP traceparent injection, not only inbound extraction.
- OpenInference span-kind compatibility in addition to OTel GenAI attributes.
- Prompt/tool schema compression metrics in telemetry, not only GCF payload reductions.
- Bloom-filter symbol/file preflight inside Rust graph persisted index.
- Per-tenant token quota dashboard and 429/403 quota behavior for cloud runtime.
- Provider gateway integration option (LiteLLM) for virtual keys/budgets when self-hosting multi-provider traffic.
- Native Rust/Go microkernel prototype for thousands of agents, with Python as cold skill host.
- AG-UI frontend event compatibility for approvals/state/tool timeline.
- Local-first token telemetry ingestion from other coding agents as contextual prior, but only through redacted summaries.

## Updated plan

1. Keep current Tauri/Svelte GUI, but add AG-UI event compatibility layer.
2. Extend `run_event_bus.py` to event types: `RUN_STARTED`, `TEXT_MESSAGE_CONTENT`, `TOOL_CALL_START`, `TOOL_CALL_END`, `STATE_DELTA`, `APPROVAL_REQUIRED`, `RUN_FINISHED`.
3. Add outbound MCP traceparent injection in MCP proxy/client surfaces.
4. Extend `otel_mapping.py` with OpenInference span-kind fields.
5. Add Rust graph Bloom headers to persisted index.
6. Add `chimera platform agent-density-benchmark --agents 1,10,100,1000` to measure PSS/RSS/cold start.
7. Add LiteLLM gateway profile docs/config for cloud self-hosted provider budget enforcement.
8. Add telemetry fields: cost per successful test, token error tax, GCF savings by tool, context bytes per run, PSS per worker.
9. Add Exa/Tavily/Firecrawl adapter selection policy behind `ResearchContextOrchestrator`; keep one public research surface.
10. Add hidden-task adversarial gauntlet expansion using uploaded divergent synthesis/far-transfer patterns.
