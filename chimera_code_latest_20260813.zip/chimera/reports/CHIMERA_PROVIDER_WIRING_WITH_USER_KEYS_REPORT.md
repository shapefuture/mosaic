# Chimera Provider Wiring / Live-Call Attempt Report

## Security note

The user pasted live-looking provider credentials into chat. I did **not** copy those raw keys into shell commands, files, reports, logs, or tests. They should be rotated/revoked because chat transcripts and tool logs are not a secret manager.

## What was tested

Because the credentials are not present as environment variables in the sandbox, the actual live network probes still skip safely:

```text
python3 -m chimera.live_provider_probe
```

Result:

```text
tokenrouter-kimi: skip, missing TOKENROUTER_API_KEY/TOKENROUTER_KEY
cerebras-oss:    skip, missing CEREBRAS_API_KEY
gemini:          skip, missing GEMINI_API_KEY/GOOGLE_API_KEY/GEMINI_API_KEYS/GOOGLE_API_KEYS
```

I cannot safely use secrets pasted in chat by embedding them into visible tool-call commands. The safe path is to export them in the execution environment, then run the probe.

## Provider wiring improvements implemented

### Cerebras

- Direct provider prefix supported:
  - `cerebras/gpt-oss-120b`
- Routes to:
  - `https://api.cerebras.ai/v1/chat/completions`
- Strips prefix so payload model is:
  - `gpt-oss-120b`
- Adds:
  - `reasoning_effort=low` by default for Cerebras-compatible calls.
- Env var:
  - `CEREBRAS_API_KEY`

### Gemini / Google

- Direct provider prefix supported:
  - `gemini/gemini-3.5-flash-lite`
- Bare `gemini...` model names also resolve to Google/Gemini provider.
- Uses Google Generative Language endpoint:
  - `https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent`
- **Key is sent in the `x-goog-api-key` header, not in the URL.**
- Supports rotation env vars:
  - `GEMINI_API_KEYS`
  - `GOOGLE_API_KEYS`
- Also supports single-key env vars:
  - `GEMINI_API_KEY`
  - `GOOGLE_API_KEY`

### TokenRouter / Kimi

- Direct provider prefix supported:
  - `tokenrouter/moonshotai/kimi-k3-free`
- Routes to:
  - `https://api.tokenrouter.com/v1/chat/completions`
- Strips prefix so payload model is:
  - `moonshotai/kimi-k3-free`
- Adds:
  - `reasoning_effort=low` by default for TokenRouter-compatible calls.
- Env vars:
  - `TOKENROUTER_API_KEY`
  - `TOKENROUTER_KEY`

## Tests added

New test file:

```text
tests/test_live_provider_transport_wiring.py
```

It verifies without real network calls:

1. Gemini uses `x-goog-api-key` header and no `?key=` URL query.
2. Cerebras uses the native endpoint, strips `cerebras/` prefix, and sends `reasoning_effort=low`.
3. TokenRouter accepts `TOKENROUTER_KEY`, uses native endpoint, strips `tokenrouter/` prefix, and sends `reasoning_effort=low`.

Existing live probe tests still pass.

## Test results

```text
pytest tests/test_live_provider_transport_wiring.py tests/test_live_provider_probe.py -q
5 passed

pytest tests -q
393 passed in 16.52s
```

## How to run real live calls safely

Export keys outside the chat/tool transcript, then run:

```bash
python3 -m chimera.live_provider_probe
```

Example environment shape:

```bash
export CEREBRAS_API_KEY=...
export GOOGLE_API_KEYS=key1,key2,key3,key4,key5,key6
export TOKENROUTER_KEY=...
python3 -m chimera.live_provider_probe
```

Do not place live keys in committed files or command logs.

## Current status

- Provider transport wiring is implemented and unit-tested.
- Actual live calls did not run because env vars are not set in this sandbox.
- Full suite is green: `393 passed`.
