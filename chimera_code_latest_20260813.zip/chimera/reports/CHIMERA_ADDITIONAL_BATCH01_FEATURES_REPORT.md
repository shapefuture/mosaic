# Chimera Additional Less-Obvious Batch-01 / PRD Features Report

## Purpose

Double-check the source docs for less-obvious but relevant mechanisms that had not yet been implemented, and add the ones that provide practical gains without a full architecture rewrite.

## Implemented additional mechanisms

### 1. Outbound secret scanning / redaction

New file:

```text
chimera/secret_scanner.py
```

Integrated into:

```text
chimera/output_filter.py
```

What it does:

- redacts Google-style keys,
- OpenAI/OpenRouter-style keys,
- Cerebras-style keys,
- generic `api_key/token/secret = ...` patterns,
- before observations are returned to the model/user context.

Why it matters:

The PRD emphasizes outbound secret scanning and credential paths never entering context. This is a cheap, high-reliability guard.

### 2. UTF-8-safe truncation with explicit notice

New file:

```text
chimera/text_truncation.py
```

Integrated into:

```text
chimera/output_filter.py
```

What it does:

- truncates by bytes without splitting multibyte UTF-8 characters,
- preserves head/tail,
- adds explicit notice with original byte count and limit.

Why it matters:

The batch docs highlight truncation notices and UTF-8 boundary safety in production-grade tool output handling. This improves reliability and transparency with no model call.

### 3. Per-canonical-path file mutation queue

New file:

```text
chimera/file_mutation_queue.py
```

Integrated into:

```text
chimera/branch.py
```

What it does:

- serializes concurrent writes/unlinks to the same canonical overlay path,
- allows unrelated files to remain parallel,
- reduces race risk from parallel tool/DAG execution.

Why it matters:

The batch docs identify per-file mutation queues as the right concurrency granularity: not no locks, not global locks.

### 4. Output filter hardening

Updated:

```text
chimera/output_filter.py
```

Now combines:

- domain-aware pytest filtering,
- secret redaction,
- UTF-8-safe truncation,
- explicit truncation notice.

## Tests added

New file:

```text
tests/test_additional_batch01_features.py
```

Covers:

- secret redaction in output filtering,
- UTF-8-safe truncation does not split multibyte characters,
- concurrent writes through `TransactionalWorkspace` remain valid under per-path mutation queue.

## Validation

```text
pytest tests/test_additional_batch01_features.py -q
3 passed

python3 -m compileall -q chimera tests
OK

pytest tests -q
420 passed in 15.75s
```

## Relevant features still intentionally not implemented

These remain not worth a direct port yet:

1. Full service-registry/hook kernel rewrite — too broad for current Chimera.
2. Always-on multi-agent economics — adds cost/latency before measured benefit.
3. Full goal-mode state machine — current stop-reason and runtime structures are lighter.
4. Provider-native compaction by default — still requires canary proof and recall A/B.
5. Always-on double confirmation — too expensive; conditional version exists.

## Final status

```text
420 passed in 15.75s
```
