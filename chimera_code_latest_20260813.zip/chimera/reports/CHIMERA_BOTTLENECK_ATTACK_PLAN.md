# Chimera Bottleneck Attack Plan — First-Principles, Evidence-Gated

**Created:** 2026-08-11  
**Status:** plan first; Phase 1A (managed local cancellation) and the Phase 2B transcript-minimized verification-brief primitive are implemented. No independent model checker, provider cancellation claim, or universal superiority claim follows from this plan.

## 0. Operating thesis

A coding control plane is not made faster or better by adding more agents, retries, memory, or model routing by default. Its end-to-end useful-work rate is constrained by:

```text
verified task completions / (wall time, tokens, cost, unsafe/unknown effects, regressions)
```

The denominator contains serial provider time, test execution, context assembly, branch materialization, retries, and repair loops. The numerator is reduced by ambiguous contracts, context noise, false verification, provider failures, unsafe cancellation, and premature parallelization.

Every intervention must therefore have a named bottleneck, bounded scope, measured baseline, acceptance metric, kill criterion, and no automatic promotion.

## 1. What was audited

### Internal source / test evidence

- Current complete local suite: **488 passed in 18.62s**.
- Existing strengths already found in code:
  - transactional branch overlays, WAL/CAS, protected tests, command proofs;
  - impact analysis with a constitutional test floor and fail-safe full-suite fallback;
  - typed context planning, output filtering, repair briefing, prompt-cache telemetry;
  - explicit concrete-model authority; QoS is advisory;
  - branch-aware task contracts and audited continuation state;
  - sealed promotion evaluator with evaluator epoch and optional oracle gate;
  - managed scheduler claims and local-only artifact recovery.
- Existing non-solutions / unresolved limits:
  - HTTPX timeout controls socket inactivity, not an end-to-end useful deadline when a stream drips bytes;
  - generic injected provider callbacks cannot be forcefully stopped safely;
  - no route-specific terminal cancellation/billing proof for remote model providers;
  - host subprocess fallback is not a microVM/container claim;
  - no repeated equal-config held-out campaign establishes general quality/token/latency superiority;
  - a real independent model checker is not currently a deterministic authority.

### Attached material read

Fully read:

- `SKILL.md`
- `divergent-synthesis-bridge.md`
- `technique-library.md`
- `far-transfer-bank.md`
- `diagnosis.md`
- `agent-specific-gaps.md`

The SKILL references additional requirements, gate, example, technique, and eval files that were not supplied. Their missing content is not treated as evidence or implementation authority.

### External research inventory

Sixteen focused English/Chinese searches were used; this was deliberately not padded to 60 unrelated queries. Primary findings were checked against official HTTPX, gRPC, Python, Temporal, OpenAI, OpenTelemetry, pytest, Azure TIA, Bazel, GitHub Actions, and Google SRE material. Query/result inventory belongs in the evidence report accompanying implementation.

Key externally sourced principles:

1. socket/read timeouts are not total request deadlines;
2. deadlines and cancellation must propagate and a handler must cooperate;
3. retries without a shared bounded budget can amplify overload;
4. impacted-test selection needs a safe full-suite fallback and periodic full validation;
5. static prompt prefixes and explicit cache telemetry matter more than speculative semantic response caching for effectful work;
6. model judging is useful as an advisory discriminator but needs calibration and cannot replace executable correctness.

Primary source set: [HTTPX timeout modes](https://www.python-httpx.org/advanced/timeouts/), [gRPC deadlines](https://grpc.io/docs/guides/deadlines/), [gRPC cancellation](https://grpc.io/docs/guides/cancellation/), [Python subprocess process groups](https://docs.python.org/3/library/subprocess.html), [Google SRE on retries/deadlines](https://sre.google/sre-book/addressing-cascading-failures/), [Temporal cancellation](https://docs.temporal.io/develop/python/workflows/cancellation), [OpenAI prompt caching](https://developers.openai.com/api/docs/guides/prompt-caching), [OpenAI latency guidance](https://developers.openai.com/api/docs/guides/latency-optimization), [test impact analysis](https://martinfowler.com/articles/rise-test-impact-analysis.html), [Azure TIA fail-safe fallback](https://learn.microsoft.com/zh-cn/azure/devops/pipelines/test/test-impact-analysis?view=azure-devops), and [evaluation best practices](https://platform.openai.com/docs/guides/evaluation-best-practices).

## 2. Bottleneck inventory and priority

| Priority | Bottleneck | Why it is load-bearing | Existing state | Proposed intervention |
|---|---|---|---|---|
| P0 | Remote provider total deadline/cancel ambiguity | Can consume time/cost after the control plane has given up; outcome may be unknown | Explicitly unresolved | Route-specific terminal-cancel capability receipt and canary; no normal policy change until a route proves it. |
| P0 | Execution isolation on host fallback | Local command success/failure is weaker than isolated effect containment | Explicitly labelled host-subprocess-unisolated | Certified bwrap test matrix first; later isolated worker backend only if its teardown/egress proof is real. |
| P0 | Task ambiguity / interface conventions | Wrong requirements dominate any model/planner gain | Contract/readiness checks are partial | Advisory requirements/interface receipt: measurable acceptance, target scope, units/conventions, acceptance owner, solution lock-in. Missing facts remain unknown—not invented. |
| P1 | Long-horizon repair quality | Context rot and same-pass self-confirmation create plausible wrong patches | Context plan and deterministic gates exist; no independent checker port | Transcript-minimized verification brief, separate checker only under explicit authorization, deterministic evidence remains authority. |
| P1 | Provider token/latency measurement comparability | Uncontrolled output caps/routes make “optimization” claims meaningless | Telemetry exists, comparisons incomplete | Sealed equal-config campaign: same route/model/max output/deadline/tests/repetitions; record TTFT, E2E, prompt/completion/cache tokens, repairs, unknown outcomes. |
| P1 | Test latency and confidence | Full tests are safe but often expensive; over-aggressive selection is unsafe | Static impact selection with fallback exists | Measure focused-vs-full precision/recall on held-out mutations. Run full suite periodically and immediately on unclear/high-blast changes. |
| P2 | Context/token efficiency | Repeated static content, noisy observations, and unbounded outputs cost tokens and dilute signal | Typed context and cache tracker exist | Stabilize provider-prefix layout, audit per-segment marginal utility, gate compaction by protected facts; no semantic cache for code/effects. |
| P2 | Parallelism | More concurrent model work can create conflicting patches, redundant reads, rate-limit collapse | DAG/task slices/CAS exist | Concurrency controller based on dependency, ownership overlap, provider queue/deadline budget, and verification capacity—not a fixed fan-out. |
| P2 | Strategy diversity for genuinely ambiguous tasks | One trajectory can lock into a local solution family | Patch fusion and branch primitives exist | Opt-in three-candidate branch campaign: conventional, constraint inversion, and evidence-backed far-transfer; same budget/tests; no automatic merge. |
| P3 | Local compute start-up / artifact costs | Repeated process/setup work can dominate small validations | Local CAS/proofs/cache exist | Measure before adding persistent workers; use exact action keys and signed command proofs, never generic response cache. |

## 3. Phase sequence

### Phase 1 — Make stopping, observability, and comparison truthful

**1A. Managed local scheduler cancellation — IMPLEMENTED**

- Hypothesis: a schedule routed through a managed local process port can terminate its original process group on lease revocation or local deadline, while preserving unknown-outcome semantics when proof is absent.
- Acceptance: process group receipt confirms leader exit and group absence; crash claims do not replay; no cooperative fallback.
- Kill: any scheduler route reaches foreground/cooperative execution, any unconfirmed cancellation is treated as success, or a late child side effect survives the group cancellation test.

**1B. Provider route cancellation capability — NOT IMPLEMENTED**

- Hypothesis: a named provider/adapter can prove terminal cancellation semantics for one concrete route.
- Scope: one authorized canary, no automatic routing, no hedge.
- Acceptance: terminal status/cancel acknowledgement plus provider-specific outcome/billing semantics are captured; parent deadline wins.
- Kill: cancellation only closes a client socket, is unobservable, or leaves billing/effect outcome ambiguous.

**1C. Single trace identity and budget ledger — PLAN**

- Record parent deadline, per-stage remaining budget, provider request identity, test scope, process cancellation receipt, cache attribution, and terminal classification.
- Acceptance: every run finalizes as pass/fail/cancelled/unknown with a bounded reason; no hidden timeout is called a failure or a pass.

### Phase 2 — Improve quality before increasing autonomy or fan-out

**2A. Requirements/interface readiness receipt — PLAN**

- Deterministically expose what is known vs missing: acceptance test, bounded targets, interface/units conventions found in repository evidence, protected paths, acceptance owner if explicitly supplied.
- Acceptance: only repository/task facts are labeled as facts; unknowns are not hallucinated; high-risk ambiguity pauses for owner input or remains explicitly provisional.
- Kill: heuristic guesses become gates or silently mutate task scope.

**2B. Transcript-minimized verifier brief — PRIMITIVE IMPLEMENTED**

- `chimera/verification_brief.py` builds a branch/diff/contract/evidence artifact and strips generation transcript, provider-response, chain-of-thought, prompt, completion, and rationale fields from facts.
- It contains task/contract hashes, diff operation hashes, test hashes, protected paths, required symbols/calls, command proof refs, and bounded verification facts. It is persisted only as a local CAS/WAL artifact when explicitly requested.
- Acceptance proven locally: unsafe diff paths and un-hashed diffs reject; excluded text does not render; the artifact is anchored in WAL.
- Still not implemented: an actual independent model checker. Any future checker must be explicitly authorized, read-only, and unable to merge/promote without existing deterministic gates.
- Kill: raw model output becomes persistent authority or a checker bypasses deterministic tests.

**2C. Equal-config held-out campaign — PLAN**

- Measure direct versus Chimera only after explicit provider authorization.
- Fixed: model, route, prompt/output caps, request deadline, parent deadline, task corpus, repetitions, evaluation frame, and protected tests.
- Metrics: task completion, repairs, full-test pass, unknown effects, prompt/completion/cached tokens, TTFT, E2E latency, peak parallelism, cost.
- Kill: incomparable conditions, secret/credential persistence, or any safety regression.

### Phase 3 — Optimize bottlenecks proven by Phase 2

**3A. Test-impact calibration**

- Treat focused tests as fast feedback, not final promotion evidence.
- Build an offline mutation/held-out calibration: test selection recall of deliberately seeded defects, selected-test precision, focused/full latency ratio, high-blast fallback rate.
- Promote a focused policy only if recall floor and full-suite catch-rate are predeclared and met.

**3B. Context and provider-prefix optimization**

- Inspect context segment token contribution and retrieval utility.
- Move immutable instructions/tools/schema first, dynamic observations last, preserving exact model choice.
- Do not claim a provider cache hit without route telemetry; do not use semantic result cache for code/effect work.

**3C. Dependency-aware parallelism**

- Use task-slice ownership/conflict graph plus provider queue/deadline budget.
- Parallelize read-only discovery and non-overlapping branch atoms; serialize overlapping writes and irreversible actions.
- Reserve verification capacity; never let producer fan-out starve tests/merges.

### Phase 4 — Experimental innovation portfolio, only after the above

- Enable only on predeclared genuinely ambiguous engineering tasks.
- Candidate arms use independent branch state and exact shared contract/tests/budget.
- Candidate mechanism tags must be structurally distinguishable from changed paths, effects, or formal strategy—not adjective changes.
- Winner requires deterministic/held-out evidence; all candidates remain non-promoted by default.

## 4. Explicit non-goals

This plan does not authorize generic speculative execution, semantic response caching for coding/effects, provider hedging, automatic model switching, raw model-generated shell scripts, autonomous test/policy/skill promotion, external research loops, network ingestion, wallet/proxy/P2P features, broad approvals, or unmeasured “self-evolution.”

## 5. Decision rule

A rewrite is justified only when evidence shows that an existing subsystem is the measured bottleneck and the replacement improves the safety-adjusted objective on a held-out/equal-config evaluation. Sunk cost is irrelevant; unmeasured novelty is also irrelevant.
