# Chimera First-Principles System Audit

## Executive conclusion

A coding-agent harness is not improved by accumulating features. It is improved when every expensive or nondeterministic operation is preceded by a deterministic decision that can change the outcome:

```text
task contract
→ work geometry
→ bounded relevant context
→ one closed patch proposal
→ cheap local rejection
→ targeted feedback when useful
→ final integration proof
→ durable truthful receipt
```

Anything that does not improve one of those transitions is either optional telemetry, an experiment, or liability.

## Fresh research receipt

**Executed:** 12 targeted searches, exactly **6 English + 6 Chinese** query strings.

Promoted sources:

* [HTTPX timeouts](https://www.python-httpx.org/advanced/timeouts/): connect/read/write/pool timeouts are distinct and read timeout is per inactivity interval, not an end-to-end semantic deadline.
* [gRPC deadlines](https://grpc.io/docs/guides/deadlines/): deadline propagation and cancellation reduce resource retention, but server/application work must cooperate with cancellation.
* [OpenAI structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs): valid JSON and schema conformance differ; route/model support must be proven before using native strict output as authority.
* [OpenAI evaluation best practices](https://platform.openai.com/docs/guides/evaluation-best-practices): held-out, task-specific, automated measurement is required; evaluation is continuous.
* [Test Impact Analysis](https://martinfowler.com/articles/rise-test-impact-analysis.html): fast pre-integration selection and post-integration broader verification are distinct stages.
* [Temporal durable testing](https://docs.temporal.io/best-practices/pre-production-testing): durable orchestration does not prove external dependency success; timeouts, idempotency, recovery and fault testing remain necessary.

The Chinese queries were used for cross-language discovery/context; no unsourced benchmark numbers were promoted.

## System map

| Plane | Correct end state | Primary hazard |
|---|---|---|
| Task geometry | One-target micro, at-most-two-file cohesive, or dependency DAG | Flattening genuine multi-step work into one opaque prompt |
| Context | Trusted, selected working set plus labelled dependency handoff | Prompt bloat or untrusted transcript authority |
| Provider | Explicit model selection, bounded attempt, typed result | Hidden model switching, duplicate hedge calls, open-ended stream wait |
| Patch | Closed declarative patch data, static/path/test gates | Scripts or target-name scaffold shortcuts becoming authority |
| Verification | Cheap focused feedback when meaningful; final broad proof | Duplicate broad tests with no decision value, or focused tests certifying integration |
| Recovery | WAL/receipts/outbox classify known/unknown outcome | Blind retry after a possibly completed external effect |
| Evaluation | Private/time-gated held-out corpus, per-step traces, immutable tests | Public benchmark contamination or test-fitting scaffolds |

## Findings and resolved bottlenecks

### 1. Imported execution profile over-compressed multi-step work

The imported profile permitted a 3–4 file `cohesive_transaction` under package-level heuristics. That violates the atomicity boundary: helper files may look cohesive while creating hidden ordering, integration and context dependencies.

**Resolution:** direct transactions are again limited to:

```text
1 target → micro_transaction
2 targets with direct shared executable acceptance → cohesive_transaction
otherwise → DAG
```

This implements a true “atomic unit” rather than a path-count shortcut.

### 2. Imported QoS routing could silently replace a user-selected model

The imported provider path selected a lower-penalty model from `CHIMERA_QOS_MODEL_POOL` when enabled. That invalidates model choice, confounds evaluation, and may cause duplicate cost/capability changes. The imported generic hedge could issue an additional provider call after a short wait without route-specific cancellation/billing proof.

**Resolution:**

```text
explicit model → exact model
model="auto" → configured default only
QoS/reliability → advisory receipt only
generic hedge → removed from normal execution
```

Every normal completion now crosses `RouteAuthority`; event receipts include the decision. This makes the provider route authoritative without treating a heuristic as authority.

### 3. Imported TesterAgent bypassed transaction isolation

Generated tests were written to the workspace root before patch admission. That could mutate user test state outside the branch overlay.

**Resolution:** generated deterministic tests now write through the branch overlay, seals are content-based/logical-path receipts, and root tests remain untouched. The tester is explicitly opt-in. Model-generated test code remains unpromoted.

### 4. Imported scaffold registry could become a benchmark oracle

Path/name-specific scaffolds were enabled by default and could seed exact implementation content based on target names.

**Resolution:** the registry remains the only scaffold source, legacy fallback is removed, but deterministic scaffolds now require:

```text
CHIMERA_ENABLE_DETERMINISTIC_SCAFFOLDS=1
```

This preserves experimental/evaluation utility without allowing test-name templates to inflate ordinary coding outcomes.

### 5. Model loop had hidden operational coupling

One 647-line method built context, mutated provider transport thread-locals, issued the provider request, projected tool results and appended the transcript.

**Resolution:** functional split:

```text
rlm_loop_context.py        context/directive/cache/evidence
rlm_loop_provider_turn.py  transport setup/request/lifecycle/usage
rlm_loop_transcript.py     tool-result wire projection/transcript
rlm_loop.py                state machine/protocol/dispatch/exit
```

The compatibility loop is now 454 lines and integration tests cover the actual split seams.

### 6. Silent fallback paths obscured degradation

Executable broad `except: pass` paths existed across provider telemetry, sandbox state hashing, evolution, Nixo, agent-state callbacks, terminal UI and quality-gate parsing.

**Resolution:** no executable broad pass remains. Each site either:

* catches a narrow expected exception;
* records a bounded degradation receipt; or
* makes conservative state explicit.

The phrase remains only in Etas documentation warning against the pattern.

### 7. Patch fusion could compose ambiguity

The imported edit fusion picked a lexicographic candidate on conflicting replacements and did not reject potential overlaps.

**Resolution:** fusion now requires independent support, rejects tied whole patches, rejects conflicting same-span replacements, conservatively removes overlapping atom spans, and cannot mix file and edit atom types. Fused results still have no direct apply authority.

### 8. Event HTTP export had implicit egress

The imported HTTP event sink issued a direct request whenever configured, bypassing an explicit second egress acknowledgement.

**Resolution:** HTTP sink requires explicit environment opt-in in addition to target configuration. No cloud-specific event backend was fabricated.

## Implementation verification

```text
444 passed in 17.37s
0 pytest warnings
compileall: pass
legacy fallback: absent
executable broad except/pass: absent
```

New or updated coverage exercises:

```text
explicit-model preservation
auto-only default selection
generic hedge removal
scaffold opt-in
branch-local TesterAgent output
patch fusion conflict abstention
loop context/provider/transcript split
event HTTP egress opt-in
```

## Remaining external evidence gates

These are not code chores. Implementing a workaround locally would create an unsupported claim:

1. **End-to-end provider deadline:** HTTP idle timeouts exist, but a stream with periodic bytes can still outlive task value. A route-specific total-deadline/cancellation receipt needs adapter support and a live canary.
2. **Native structured patch response:** the current route’s JSON object/schema probes were incomplete, so strict schema transport is not enabled.
3. **Long-horizon superiority:** needs private/time-gated chained-state tasks with immutable tests, state-handoff scoring, independent review, terminal provider receipts and repeated trials.
4. **Real sandbox isolation:** local materialization/environment filtering is not a microVM/container proof.
5. **Remote tool behavior:** manifest/schema/output validation attests descriptors and values, not remote execution behavior.
6. **External event delivery:** needs explicit capability policy, delivery/idempotency contract, retention policy and restore drill.

## Decision rule

Chimera may claim a bounded superiority result only when a named profile/provider/evaluation shows:

```text
non-inferior protected-test + full-integration outcome
AND no authority or safety regression
AND predeclared improvement in tokens, latency, repair count, or success rate
on repeated held-out tasks.
```

No broad "leading" or universal superiority claim follows from test count, a scaffold template, model prose, or a public benchmark.
