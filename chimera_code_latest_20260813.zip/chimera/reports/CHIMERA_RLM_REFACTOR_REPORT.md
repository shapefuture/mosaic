# Chimera `rlm.py` Backup + Careful Refactor Report

## Backup

Kept the pre-refactor runtime file exactly as requested:

```text
chimera/rlm.py.backup_before_split
```

Backup size:

```text
4991 lines / 292,992 bytes
```

## Refactor strategy

I used a conservative mixin/extraction approach instead of rewriting behavior. Public imports such as `from chimera.rlm import AgentMessageBus` still work because `rlm.py` re-exports the extracted primitives.

No high-risk logic rewrite was done. The extracted modules preserve method names and are inherited by `RLMRuntime`.

## New extracted chunks

### 1. `chimera/rlm_primitives.py`

Extracted from top of `rlm.py`:

- `Variable`
- `AgentMessageBus`
- `AuthStorage`
- `TaskScript`
- `Blackboard`

Size:

```text
292 lines
```

### 2. `chimera/rlm_provider.py`

Extracted provider / transport / canary methods as `RLMProviderMixin`:

- `_http`
- `_reset_http_client`
- `_stream_openai_chat`
- `_complete_model`
- `run_provider_canary`
- `_production_provider`
- `_mock_provider`

Size:

```text
559 lines
```

### 3. `chimera/rlm_action_methods.py`

Extracted patch application and branch test execution as `RLMActionMixin`:

- `_lint_before_apply`
- `_apply_patch_payload`
- `_run_branch_tests`

Size:

```text
221 lines
```

### 4. `chimera/rlm_tool_methods.py`

Extracted tool/native protocol helper methods as `RLMToolMixin`:

- `_tool_call_blocks`
- `_literal_tool_arguments`
- `_parse_tool_calls`
- `_unwrap_provider_json`
- `_native_tool_calls`
- `_native_tool_definitions`
- `_native_patch_submission`
- `_coalesce_kernel_calls`
- `_tool_requirement_missing`
- `_final_patch_context`
- `_tool_surface_instruction`
- `_compact_tool_results`
- `_tool_request_summary`
- `_normalise_tool_path`
- `_task_write_scope_error`
- `_budget_tool_text`

Size:

```text
511 lines
```

## Resulting `rlm.py` size

Before:

```text
4991 lines
```

After:

```text
3472 lines
```

Reduction:

```text
1519 lines moved out of rlm.py
~30.4% smaller
```

## Runtime class after refactor

`RLMRuntime` now inherits:

```python
class RLMRuntime(RLMProviderMixin, RLMActionMixin, RLMToolMixin):
    ...
```

This keeps behavior compatible while separating concerns.

## Issues caught during refactor and fixed

### 1. Missing `hashlib` import in provider mixin

Caught by provider canary tests.

Fixed in `chimera/rlm_provider.py`.

### 2. Missing `os`, `re`, and `Sandbox` imports in action mixin

Caught by command-proof/focused-coder tests.

Fixed in `chimera/rlm_action_methods.py`.

### 3. Dangling `@staticmethod` boundary and missing `Mapping` import in tool mixin

Caught by tool-surface/native patch tests.

Fixed in `chimera/rlm_tool_methods.py` and `chimera/rlm.py`.

## Tests run during refactor

Targeted tests after each extraction:

```text
pytest tests/test_prime_strengths.py::test_retained_subagent_registry_and_direct_message tests/test_rlm_split_facades.py tests/test_agent_runtime_transfer.py -q
13 passed

pytest tests/test_provider_canary.py tests/test_provider_cooldown.py tests/test_provider_timing.py tests/test_rlm_split_facades.py -q
7 passed

pytest tests/test_focused_native_patch.py tests/test_command_proof.py tests/test_resolve_command_proof_exact.py tests/test_resolve_aci_only.py tests/test_tier1_hotpath_facades.py -q
8 passed

pytest tests/test_tool_surface_protocol.py tests/test_native_patch_fallback.py tests/test_mcp_unknown_outcome.py tests/test_kernel_batching.py -q
9 passed
```

Final verification:

```text
python3 -m compileall -q chimera tests
OK

pytest tests -q
388 passed in 15.59s

python3 -m chimera health | python3 -m json.tool
OK

ChimeraHarness mock run smoke
ltl=True heldout=True quality=True
```

## Current file sizes

```text
chimera/rlm.py                      3472 lines
chimera/rlm_primitives.py            292 lines
chimera/rlm_provider.py              559 lines
chimera/rlm_action_methods.py        221 lines
chimera/rlm_tool_methods.py          511 lines
chimera/rlm.py.backup_before_split  4991 lines
```

## Next safe refactor chunks, if desired

The next good candidates are:

1. focused/cohesive coder methods:
   - `_focused_coder`
   - `_cohesive_coder`
   - `_strict_patch_call`
   - `_target_prompt`
   - deterministic scaffolds

2. execution/action methods:
   - `_execute_model_tool`
   - `_execute_kernel_call`
   - `_execute_compiled_actions`

3. DAG/orchestration methods:
   - `_solver_for_node`
   - `_model_tool_loop`
   - `rlm`

I stopped here because this pass already removed ~30% of `rlm.py` while keeping the whole test suite green. Further extraction should continue in the same pattern: one chunk, targeted tests, full regression.

## Final status

```text
388 passed in 15.59s
```
