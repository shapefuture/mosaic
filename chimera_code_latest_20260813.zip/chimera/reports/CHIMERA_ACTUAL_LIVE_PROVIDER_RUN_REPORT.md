# Chimera Actual Live Provider Run Report

## Security note

The live keys were supplied in chat for testing. I used them only as temporary process environment variables inside Python runs and did not write the raw values into files/reports. They should still be revoked/rotated after testing because chat is not a secret manager.

## Fixes made before live run

During the first live attempt, all slash-prefixed models were accidentally forced through OpenRouter when an OpenRouter key was present. That caused TokenRouter/Cerebras/Gemini direct models to fail as invalid OpenRouter model IDs.

I fixed:

- `chimera/rlm_provider.py`
  - only forces slash models to OpenRouter if provider resolution already selected OpenRouter.
  - direct `tokenrouter/...`, `cerebras/...`, and `gemini/...` now stay direct.
- `chimera/preflight.py`
  - direct provider credential checks for Cerebras, TokenRouter, and Gemini/Gemini key pools.
  - no longer treats all slash models as OpenRouter.
- `chimera/live_provider_probe.py`
  - Cerebras probe model updated to `cerebras/gpt-oss-120b`.
- `chimera/providers.py`
  - `google/gemma-...:free` now correctly routes to OpenRouter, while `gemini/...` routes to Gemini direct.
- `chimera/rlm_orchestration_methods.py`
  - added assessment fast path for no-target non-repository tasks so simple compute/answer tasks do not go through a code-DAG that never calls the provider.
- `chimera/rlm_dag_solver.py`
  - `_finalize_run_evidence()` now attaches held-out and quality-rubric results for `RLMRuntime.rlm()` directly, not only via `ChimeraHarness.run()`.

## Live connectivity probes

Command equivalent:

```bash
python3 -m chimera.live_provider_probe
```

with temporary process env keys.

Results:

```json
[
  {
    "provider": "tokenrouter-kimi",
    "model": "tokenrouter/moonshotai/kimi-k3-free",
    "status": "pass",
    "duration_ms": 4301.462,
    "tokens": 145,
    "answer_chars": 4
  },
  {
    "provider": "cerebras-oss",
    "model": "cerebras/gpt-oss-120b",
    "status": "pass",
    "duration_ms": 240.189,
    "tokens": 102,
    "answer_chars": 4
  },
  {
    "provider": "gemini",
    "model": "gemini/gemini-3.5-flash-lite",
    "status": "pass",
    "duration_ms": 637.455,
    "tokens": 18,
    "answer_chars": 4
  }
]
```

## Full Chimera RLMRuntime.rlm live runs

Task:

```text
Compute 12345 * 6789 exactly and state the result in one line.
```

### A. Certified primary: Cerebras

Model:

```text
cerebras/gpt-oss-120b
```

Result:

```json
{
  "case": "A_certified_cerebras",
  "ok": true,
  "wall": 0.88,
  "answer_head": "12345 × 6789 = 83,810,205.",
  "preflight_ok": true,
  "verification": {"status": "pass", "completeness": 1.0},
  "heldout_passed": true,
  "quality_passed": true,
  "tokens": 233
}
```

### B. Certified hedge/primary: Gemini

Model:

```text
gemini-3.5-flash-lite
```

Result:

```json
{
  "case": "B_certified_gemini",
  "ok": true,
  "wall": 0.74,
  "answer_head": "83810205",
  "preflight_ok": true,
  "verification": {"status": "pass", "completeness": 1.0},
  "heldout_passed": true,
  "quality_passed": true,
  "tokens": 59
}
```

### C. OpenRouter free model

Model:

```text
google/gemma-4-31b-it:free
```

Result: honest quota failure, as expected.

```json
{
  "case": "C_openrouter_capped",
  "ok": false,
  "error": "RuntimeError: provider call for 'google/gemma-4-31b-it:free' failed: HTTP 429: Rate limit exceeded: free-models-per-day ... X-RateLimit-Remaining: 0 ..."
}
```

### Verdict

```json
{
  "chimera_runs_with_cerebras": true,
  "chimera_runs_with_gemini": true,
  "openrouter_failure_is_honest_quota": true,
  "all_expected": true
}
```

## TokenRouter / Kimi full RLMRuntime run

Model:

```text
tokenrouter/moonshotai/kimi-k3-free
```

Result:

```json
{
  "case": "tokenrouter_kimi_rlm",
  "ok": true,
  "wall": 6.83,
  "answer_head": "83810205",
  "verification": {"status": "pass", "completeness": 1.0},
  "heldout_passed": true,
  "tokens": 262
}
```

## Final regression

```text
pytest tests -q
393 passed in 15.41s
```

## Current live status

- Cerebras direct: **LIVE and working** through Chimera runtime.
- Gemini direct: **LIVE and working** through Chimera runtime.
- TokenRouter/Kimi direct: **LIVE and working** through Chimera runtime.
- OpenRouter free: **honest 429 quota failure**, as expected.

## Recommendation

For the certified low-latency path, use:

```bash
CHIMERA_CERTIFIED_ROUTE=1
CHIMERA_REASONING_EFFORT=low
CEREBRAS_API_KEY=...
GOOGLE_API_KEYS=key1,key2,key3,key4,key5,key6
```

Use model:

```text
cerebras/gpt-oss-120b
```

Gemini is a healthy hedge:

```text
gemini-3.5-flash-lite
```

TokenRouter/Kimi works but is slower in the observed run.
