# Chimera Double-Verification Report

## Verification performed

I re-checked the live package after all tier implementations.

Commands run:

```bash
pytest tests -q
python3 -m compileall -q chimera tests
python3 -m chimera health
python -c 'from chimera.orchestrator import ChimeraHarness; ... h.run(...)'
```

Final result:

```text
379 passed in 14.93s
compileall ok
```

Additional runtime smoke checks:

- `ChimeraHarness().health()` returns `wal_ok=True`.
- `ChimeraHarness().run(..., model="mock-echo")` returns:
  - `ltl_ok=True`
  - non-null `heldout`
  - non-null `quality_rubric`
- Archived causal/belief memory files are present under `archived_experimental/...`.
- No live imports of `belief_memory` / `causal_memory` remain.

## Issues found during double verification and fixed

### 1. CLI `health` was not valid machine JSON

**Problem:**

`python -m chimera health` used Rich `JSON(...)`. Long strings were line-wrapped in a way that made captured stdout invalid JSON.

**Fix:**

Changed `chimera/cli.py` health command to:

```python
click.echo(json.dumps(h.health(), indent=2, default=str))
```

**Regression test added:**

`tests/test_double_verify_fixes.py::test_cli_health_emits_valid_json`

### 2. `route_pipeline` still smuggled `preferred_model` as an explicit user model

**Problem:**

`preferred_model` was effectively passed as `explicit_model`, causing the router to preserve it as if the user explicitly required it. That defeated the intended “preferred but overridable” semantics.

**Fix:**

`explicit_model` is now the only hard override. `preferred_model` is recorded and used to detect/report override disagreement, but does not bypass router choice.

**Regression test added:**

`tests/test_double_verify_fixes.py::test_route_pipeline_preferred_model_is_not_treated_as_user_explicit`

### 3. `ContradictionLedger.record_claim()` had a weird evidence expression

**Problem:**

It used `time.time() and evidence_ref` in the `evidence_ref` field. It usually worked, but was unclear and brittle.

**Fix:**

Now passes `evidence_ref` directly.

### 4. Test collection warning around `TestImpactSelector`

**Problem:**

Pytest tried to collect `TestImpactSelector` because its class name starts with `Test`.

**Fix:**

Added `TestImpactSelector.__test__ = False`.

## Current verification status

```text
379 passed in 14.93s
```

No compile errors.

No live causal/belief memory imports.

CLI `health` now produces valid JSON.

## Remaining known caveats / additional improvements

These are not missed regressions; they are honest boundaries of the current implementation and recommended next improvements/workarounds.

### A. Bubblewrap branch-overlay correctness still needs real-host validation

The current sandbox correctness tests validate the host-subprocess cached materialization path. This environment does not have a production bwrap/overlayfs setup, so full bwrap behavior for:

- branch-only new files,
- branch deletions masking base files,
- overlayfs upper/work directory composition,

should be validated on a Linux host with Bubblewrap and overlayfs support.

**Workaround now:** if bwrap correctness is unverified on a host, prefer the cached materialization fallback for production tasks where exact branch view matters more than minimum latency.

### B. Held-out verifier is deterministic and useful, but shallow

The held-out verifier currently catches obvious intent/diff/test contradictions and preserves CAS evidence. It is not yet a strong semantic maintainer-review model.

**Recommended improvement:** add optional sampled semantic review by a strong model or a rule-based project-specific maintainer rubric, never feeding details back to self-heal.

### C. ACI exists but the model loop is not yet fully ACI-only

The ACI layer exists and is wired, but legacy tool protocol paths still exist. The next quality jump is to force normal coding tasks through ACI view/search/line-edit before allowing raw patch payloads.

**Workaround now:** use ACI for high-risk or flaky tasks; keep native patches for providers known to produce clean structured edits.

### D. Command proof selected input hashes are conservative but can be stronger

`workspace_input_root(...)` is already strong and included, and command proof now has env/dependency/input fields. `selected_input_hashes` currently records changed inputs/path-level details in the branch context. For maximum precision, this can be extended to exact branch-view bytes for selected tests and changed files.

### E. Provider reliability profile exists but is not yet authoritative in routing

`ProviderReliabilityRegistry` records and profiles reliability, but `route_pipeline` does not yet lower-score unreliable providers by default.

**Recommended improvement:** route decisions should incorporate reliability as a penalty or hard floor.

### F. Performance gates are smoke-level

The release performance gates are intentionally broad to avoid flakiness. For production, add repo-size-specific gates:

- small repo,
- medium repo,
- large repo,
- dependency-heavy repo.

### G. `rlm.py` remains large

The strangler facades are in place and some calls route through them, but `rlm.py` is still ~5k LOC. Continue moving functionality behind facades until `rlm.py` is mostly orchestration.

## Extra workaround recommendations

1. **Production sandbox mode flag**
   - Add `CHIMERA_SANDBOX_MODE=materialized|bwrap|auto`.
   - If bwrap overlay is not certified, force materialized cache.

2. **Provider reliability gate**
   - Temporarily route strict JSON/tool-use tasks only to providers with canary-proved native tools and recent reliability > 0.9.

3. **Held-out sampling budget**
   - Run expensive held-out semantic checks only on:
     - high-risk files,
     - repeated self-heal retries,
     - patches with low rubric score,
     - final commit candidates.

4. **CI matrix**
   - Run test suite in two modes:
     - no-bwrap fallback mode,
     - bwrap-enabled Linux mode.

5. **Release checklist**
   - `pytest tests -q`
   - `python -m compileall -q chimera tests`
   - `python -m chimera health | python -m json.tool`
   - performance gates
   - one mock `ChimeraHarness.run()` smoke

## Conclusion

I did find and fix additional issues during double verification. The live package is now greener and more robust:

```text
379 passed in 14.93s
```

The main remaining work is not another broad subsystem pass. It is targeted hardening:

1. certify bwrap/overlayfs behavior on a real Linux host,
2. make ACI mandatory for normal coding edits,
3. make provider reliability influence routing,
4. strengthen held-out semantic verification,
5. continue shrinking `rlm.py` behind the new facades.
