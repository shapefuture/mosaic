# Chimera 2026 Documents — Skeptical Synthesis and Upgrade Plan

**Date:** 2026-08-11  
**Scope:** full review of the user-supplied `chimera_V1.md`, `chimera_2026_v2.md`, `chimera_2026_v3.md`, and `chimera_2026_v3.1_extension.md`; no source replacement is performed by this plan.  
**Pre-analysis backup:**

```text
/home/user/chimera_current_pre_upgrade_analysis_20260811.zip
sha256: 3551a6edce46922a2fac26f67a91a4c5cf21d7eace02239cd8aa24728af7a5a2
```

## 1. Executive decision

The documents identify several real deployment-scale concerns, especially the interaction between connection pools, cache locality, and worker isolation. They are not a drop-in blueprint for the current Chimera.

Chimera today is a **local transactional coding-agent control plane** whose authority is branch overlays, WAL/CAS, TaskContract, protected tests, command proofs, exact model authority, scoped approvals, and evidence gates. The proposed DBOS/Hatchet/pg_crdt/forkd/SGLang architecture is a **production deployment topology** for a self-hosted multi-agent fleet. Treating its components as a wholesale rewrite would duplicate or weaken current authorities before there is a measured workload that needs them.

**Decision:** preserve Chimera’s deterministic authority plane. Add deployment/runtime adapters only behind explicit ports and only after stage gates prove the workload, host capabilities, and safety properties. No automatic model-tier routing, semantic coding cache, CRDT authority, speculative duplicate effects, external egress, or alpha microVM promotion.

## 2. Document claims reconciled against evidence

| Proposal | Research / source result | Chimera decision |
|---|---|---|
| DBOS over Postgres for durable workflows | DBOS is an active Postgres-backed durable-workflow library with queues and steps. Its durable model distinguishes deterministic workflows from I/O steps. | **Evaluate adapter, do not replace core.** Chimera already has `LocalDurableWorkflowPort`, WAL, run lifecycle, unknown outcomes, and branch transactions. A DBOS port must preserve these semantics and be tested with a real Postgres crash/recovery matrix first. |
| Hatchet + SKIP LOCKED dispatch | SKIP LOCKED is a valid queue-claim pattern; DBOS itself also exposes durable queues. | **Measure before adding.** Do not stack DBOS and Hatchet because documents say so. Benchmark Chimera’s local scheduler/queue needs; add one queue adapter only if DBOS/native queue cannot meet a predeclared concurrent workload. |
| pg_crdt shared state | Upstream `supabase/pg_crdt` identifies itself as **experimental** and describes WAL/dead-tuple pressure for frequently updated documents. | **Do not adopt as authoritative state.** Current branch/CAS/WAL/task-slice state is stricter for coding work. At most evaluate a per-run advisory collaboration board after a merge-size/hold-time benchmark and conflict model. Never use it for claims, approvals, work ownership, or promotion. |
| forkd primary sandbox | forkd documents Firecracker/KVM properties but also requires privileged host setup and remains an orchestration layer with deployment risk. | **Keep external and unpromoted.** Current host reports `host-subprocess-unisolated`; forkd cannot be claimed until host doctor, threat model, post-spawn attestation, egress, IMDS, cgroup, and escape tests pass. Kata/gVisor are alternatives to evaluate, not defaults. |
| DNS-aware egress proxy | Domain policy cannot be proved by an IP-only firewall; proxy/DNS mediation is a valid design direction. | **Need an isolated host test.** Current local adapter has no network-isolation proof. Do not deploy a transparent TLS proxy into a coding sandbox before root/namespace threat-model and bypass tests exist. |
| SGLang RadixAttention/cache-aware routing | SGLang router exposes cache-aware policy; multi-replica cache locality is a real issue. | **Self-hosted-only adapter trial.** It is irrelevant to current hosted TokenRouter use. If self-hosting, benchmark with a pinned server/router version, actual prompts, cache-hit telemetry, and load/TTFT traces. |
| Prefill/decode disaggregation | vLLM documents it as experimental and says it tunes TTFT/tail ITL but does **not** itself improve throughput. It requires multiple GPU workers and KV transfer. | **No generic 2–3x claim.** Evaluate only on a self-hosted multi-GPU workload after simple prefix caching/cache-aware routing baseline. |
| Model-tier classifier / semantic cache | Documents propose automatic tier selection. Current Chimera preserves exact requested model and intentionally disables semantic cache for coding/effects. | **Do not auto-route.** Build an offline advisory recommender/evaluation only. A concrete requested model must remain exact. Semantic cache is allowed only for separately classified pure, effect-free data with equivalence/staleness proof; never coding/effect results. |
| tokensave | Active tool with local code graph and self-reported benchmark. Release notes also reveal update checks, telemetry/counter behavior, process memory risks, and prefix-pollution regressions. | **Isolated local trial only.** Pin artifact/checksum, disable update/telemetry paths, use read-only MCP surface, inspect memory/process behavior, and compare against Chimera’s existing CodeGraph/ImpactAnalyzer/ContextPlan on a sealed query set. |
| PgBouncer transaction pooling | Valid pool reduction technique, but transaction mode is incompatible with persistent session features including LISTEN; direct/session listener path is required. | **Only after a real DBOS/Hatchet deployment exists.** Pool sizing is a measured deployment concern, not codebase infrastructure to preinstall. Treat listener/notify connections separately. |
| native/Depyler/io_uring | Native optimization and io_uring are workload-specific. | **Already aligned.** Use profiler-gated kernels and mirror tests. No language rewrite or I/O-runtime swap before profile evidence. |

## 3. Important document corrections

1. **“One Postgres” does not mean one undifferentiated connection path.** If DBOS, queueing, and advisory shared state ever coexist, their pool, listener, transaction, and application-name accounting must be independently measured. But this concern is premature before Postgres is actually adopted.
2. **DBOS step semantics are not generic exactly-once external effects.** A workflow step may be retried; remote/provider/effect outcomes need idempotency keys or Chimera’s unknown-outcome/outbox rules. v3 correctly retracts broad speculative duplicate execution. Chimera keeps that retraction.
3. **CRDT commutativity does not license non-atomic coding state.** Branch merge, approvals, promotions, and work claims are intentionally non-CRDT authority surfaces.
4. **PD disaggregation is an infrastructure-level latency/tail control, not a hosted-provider optimization.** It cannot improve hosted TokenRouter, and vLLM’s own docs label the feature experimental and do not claim throughput improvement by itself.
5. **A tier classifier conflicts with explicit user model choice.** The only acceptable first phase is advisory evidence under a literal `auto` policy that the user separately opts into; concrete model requests stay unchanged.
6. **Self-reported vendor benchmark numbers are discovery inputs.** The v3.1 connection and cache-hit numbers become only hypotheses until replayed on a sealed Chimera workload.

## 4. Upgrade architecture

```text
                 ┌──────────────────────────────────────┐
                 │ Existing Chimera authority plane       │
                 │ TaskContract / capabilities / WAL-CAS  │
                 │ branches / protected tests / proofs    │
                 └──────────────────┬───────────────────┘
                                    │ stable ports only
       ┌────────────────────────────┼─────────────────────────────┐
       │                            │                             │
┌──────▼─────────┐          ┌───────▼──────────┐         ┌────────▼────────┐
│ Durable runtime│          │ Inference runtime │         │ Isolated worker │
│ Local port now │          │ Hosted exact route│         │ Local managed   │
│ DBOS port later│          │ Self-hosted port  │         │ microVM port    │
└────────────────┘          └──────────────────┘         └─────────────────┘
       │                            │                             │
       └──── all adapters return bounded evidence receipts ────────┘
```

No deployment adapter receives commit/promotion authority. The authority plane decides what to accept after an adapter returns evidence.

## 5. Ordered upgrade plan

### Gate 0 — Preserve and measure the current baseline

**Before any external system:**

- Seal current local test/mutation/held-out fixtures, route authority tests, cancellation evidence, and performance baseline.
- Add a `DeploymentProfile` evidence record that says local deterministic, hosted exact-route, or self-hosted experimental; never infer production capability from installed package names.
- Acceptance: repeat baseline at least five times; record test duration, branch operations, context tokens, provider evidence, unknown outcomes, and memory/process counts.
- Kill: variance makes a claimed improvement indistinguishable from noise.

### Gate 1 — Code/context economy first, local and reversible

**Experiment A: read-only code intelligence trial**

- Build a sealed suite of Chimera code-navigation questions from repository tests and user tasks.
- Compare existing `CodeGraph + ImpactAnalyzer + ContextPlan` to a pinned, telemetry-disabled, read-only tokensave subprocess on: retrieval token count, answer recall against known symbols, latency, memory/RSS, stale-index behavior, and unexpected egress/process behavior.
- No write tools, no MCP promotion, no automatic tool selection.
- Accept only if recall does not regress and median token/latency improves on held-out questions with bounded memory.

**Experiment B: stable-prefix audit**

- Existing provider cache telemetry becomes the source of truth.
- Add a prompt-prefix structural test that computes a static prefix hash from immutable instructions/tool schemas and rejects per-run identity/time fields before the prefix boundary.
- Hosted caches are observational only; cache reads must be reported by the route.

### Gate 2 — Durable-runtime compatibility spike

- Implement `DBOSDurableWorkflowPort` beside `LocalDurableWorkflowPort`, not inside RLM core.
- Use disposable real Postgres, no production DB.
- Test: kill process after deterministic checkpoint, after I/O step, after ambiguous effect; restart; compare to current WAL/outbox/unknown semantics.
- Test queue capacity with DBOS queue alone before adding Hatchet.
- Require effect idempotency key/outbox receipt for any external I/O.
- Accept only if recovery is at least as safe as current unknown-outcome behavior and added latency/connection use is measured.
- Kill: DBOS retry would replay a non-idempotent provider/tool effect, serialization leaks protected context, or a failure cannot be reconciled.

### Gate 3 — Queue and connection capacity, only if Gate 2 proves need

- Use a load generator against the chosen DBOS/native queue at target concurrency tiers: 1, 4, 16, 64, 100 workers.
- Collect claim latency, throughput, retry distribution, queue age, DB connection counts by application name, transaction hold time, and Postgres CPU/IOPS.
- Only if workload fails predeclared SLOs, trial Hatchet/another queue adapter.
- Only after real pools exist, evaluate PgBouncer with a direct/session listener carve-out. Add transaction-pool compatibility tests for LISTEN, prepared statements, session variables, advisory locks, and migrations.
- Accept external queue/pool only if it improves measured target SLOs without weakening recovery or listener semantics.

### Gate 4 — Isolation ladder

1. Certify Bubblewrap on the target host: overlay, network deny, DNS/IP bypass, process tree, signal cleanup, resource exhaustion.
2. If inadequate, run a non-production Kata/gVisor/forkd comparison on the exact host. Verify actual prerequisites and threat model; do not rely on README benchmarks.
3. For forkd specifically: pinned version, doctor output, per-child post-spawn attestation, cgroup quotas, netns identity, egress proxy/dns path, IMDS deny, host escape attempts, health check, and failure cleanup.
4. Promote only the backend with measured containment, latency, density, and restore behavior compatible with Chimera’s managed cancellation receipts.

### Gate 5 — Hosted versus self-hosted inference split

**Hosted path:**

- Keep exact model authority.
- Complete one real route cancellation canary through the transient descriptor protocol.
- Run equal-config held-out campaign before any cost/latency claim.
- Maintain provider-native prefix/cached-token telemetry.

**Self-hosted path (separate experimental deployment):**

- Start with one replica + prefix cache baseline.
- Add SGLang cache-aware router only after multi-replica workload exists; measure cache hit rate, TTFT, throughput, tail latency, load imbalance, and failure behavior.
- Evaluate PD disaggregation only with the needed multi-GPU/KV-transfer topology; compare against single-server/chunked-prefill baseline. Do not assume throughput gain.
- Speculative decoding only after exact-model output/correctness and tail metrics remain stable.

### Gate 6 — Advisory step-shape recommender, not auto tier routing

- Gather only sanitized trace features: deterministic step type, input/output token counts, test outcome, repair count, latency, provider response class, and evidence refs. Never capture credentials or raw code/prompt content as routing data by default.
- Cold start: rule-based **advisory** labels plus synthetic fixture corpus; no automatic model substitution.
- Train/evaluate only after an independently reviewed held-out trace set exists.
- Eligibility requires calibration, non-regression on task success/safety, cost/latency benefit, and explicit user `auto` policy. Concrete model request remains exact.

### Gate 7 — Advisory collaboration state only

- Do not install pg_crdt as branch or authority state.
- If concurrent UI/task-board state becomes a demonstrated bottleneck, build a local append-only advisory board first; measure operation size/merge latency and connection hold time.
- A CRDT extension trial requires its own data corruption, WAL/dead-tuple, snapshot, concurrent merge, and transaction-hold benchmark. Snapshot threshold derives from measured merge curve, not `1000` by folklore.

### Gate 8 — Native optimization only after a profiler report

- Emit a reproducible profile bundle for hash/diff/graph/context paths using representative repos.
- Optimize only a function whose inclusive time and call count cross a predeclared threshold.
- Candidate native kernel must pass property/mirror tests against Python, fault injection, portability build, and end-to-end measured gain.
- `io_uring` is considered only if profile attributes latency to syscall/IO, not Python compute or model inference.

## 6. Explicit non-adoptions now

```text
No DBOS runtime replacement now.
No Hatchet now.
No pg_crdt now.
No PgBouncer now.
No forkd/Kata/gVisor promotion now.
No DNS proxy now.
No SGLang/vLLM PD deployment now.
No auto model-tier routing or semantic cache.
No generic speculative effects.
No native rewrite.
No tokensave installation in the authority path.
```

These are not rejected forever. They are deferred until their dependency graph and evidence gate are satisfied.

## 7. Immediate next three actions

1. Build the stable-prefix audit + sealed navigation benchmark because they are local, reversible, and directly address token/cost without weakening authority.
2. Build the DBOS compatibility harness using disposable Postgres, not a production rewrite.
3. Run the transient exact-route cancellation/equal-config campaign once the host can supply the inherited secret descriptor; otherwise preserve the route as unproven.

## 8. Success definition

Chimera improves only when a held-out, equal-config, safety-adjusted evaluation demonstrates:

```text
no higher escaped defect/unknown effect/protected-test regression rate
AND equal or higher task completion
AND lower median tokens, cost, or wall latency for the declared workload
AND reproducible evidence receipts
```

No architecture diagram, package adoption, test-count increase, or vendor benchmark is evidence of superiority by itself.
