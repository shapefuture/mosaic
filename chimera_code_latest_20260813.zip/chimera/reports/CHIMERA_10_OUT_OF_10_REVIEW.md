# Chimera 10/10 Review — First-Principles + Bird’s-Eye Improvement Plan

## First-principles target

A coding-agent harness is superior only if it maximizes this product:

```text
Useful accepted output
= intent fidelity
× code correctness
× mergeability
× evidence quality
× latency/speed
× token efficiency
× operational reliability
× security/isolation
÷ complexity tax
```

A failure in any factor caps the whole system. Chimera already has strong pieces: transactional branches, WAL, code graph, DAG planner, evidence receipts, preflight, provider controls, prompt cache, compaction, sandbox policy, and verification. The remaining opportunities are mostly not “add another subsystem”; they are about making the existing subsystems (1) actually sit on the hot path, (2) measure the right quantities, and (3) fail closed without wasting turns.

## Bird’s-eye diagnosis

Current state after the fix batches:

- Live suite passes: `360 passed`.
- `rlm.py` remains the central hot-path god object at ~4,963 LOC.
- New facades exist, but most hot-path calls still go directly to old private methods like `_apply_patch_payload` and `_run_branch_tests`.
- ACI, route pipeline, speculative tools, and split facades are wired as objects, but not yet deeply used as the primary control surface.
- Sandbox materialization is improved for host fallback, but correctness edge cases remain for bwrap overlays and stale cache invalidation.
- Verification Goodhart controls exist, but `held_out_pass` remains `None` until a real held-out evaluator is added.

## Highest-impact additional improvements

### 1. Make sandbox branch views correct before making them faster

**Why:** Speed fixes can silently reduce reliability if the branch view is not exact. The sandbox branch view is now faster on host fallback, but its correctness contract needs tightening.

**Problems to solve:**

1. **Host materialization cache is not keyed by base workspace state.**
   - Current key is branch + overlay/deletions hash.
   - If the base workspace changes outside the overlay, a cached materialized view can go stale.

2. **bwrap overlay path does not fully model branch deletions.**
   - Base root is mounted read-only.
   - Overlay writes can be bind-mounted.
   - But deleted files in branch are still visible from the base mount unless explicitly masked.

3. **bwrap bind of new overlay files may fail when destination path does not exist in the base tree.**
   - Binding `/overlay/new.py` to `/workspace/new.py` usually requires destination existence or a composed writable upper layer.

4. **Cached materialized directories need lifecycle cleanup.**
   - Current cache evicts stale entries for the same branch only on overlay change.
   - Long-running processes with many branches can accumulate `.chimera/runs/*`.

**10/10 fix:**

- Add a `base_state_hash()` based on a cheap root manifest: selected file mtimes/sizes/hashes excluding `.chimera`, `.git`, dependency/build dirs.
- Cache key becomes `(workspace_root, branch, base_state_hash, overlay_state_hash)`.
- For bwrap, prefer an actual overlayfs/tmpfs upper layer when available:
  - lowerdir = workspace root read-only
  - upperdir = branch overlay/temp upper
  - workdir = temp workdir
- If pure bwrap bind composition remains, explicitly mask deletions with `--tmpfs` or bind empty files/directories at deleted targets.
- Add `Sandbox.clear_materialize_cache(root=None, branch=None)` and TTL/LRU eviction.
- Add tests for:
  - base file changes invalidate cached materialization
  - branch deletion hides base file
  - new branch-only file is visible in bwrap or fallback
  - cache cleanup bounds `.chimera/runs`

### 2. Replace “facade exists” with “facade owns the hot path”

**Why:** The `rlm.py` split currently creates facade objects, but the runtime still calls private methods internally. This improves code organization only superficially; it does not yet reduce complexity risk.

**10/10 fix:**

- Route all patch application through `self.action_executor.apply_patch_payload(...)`.
- Route all test execution through `self.action_executor.run_branch_tests(...)`.
- Route all JSON/tool parsing through `self.tool_protocol`.
- Route provider calls through `self.provider_client.complete(...)`.
- Route prompt/cache/compaction block assembly through `self.prompt_assembler`.
- Once call sites move, make old `_apply_patch_payload`, `_run_branch_tests`, and JSON helpers wrappers or delete them.

**Test:** full suite after each extracted call-site group.

### 3. Turn ACI into the default model action interface

**Why:** ACI is the highest-leverage layer for quality and latency: preventing bad actions beats detecting them after a model/tool/verification round trip.

**Current gap:** `AgentComputerInterface` exists, but `_model_tool_loop` still primarily uses the previous tool protocol and repository-context prompt flow.

**10/10 fix:**

- Define a small command vocabulary:
  - `view(path,start,lines)`
  - `search(query,glob,limit)`
  - `line_edit(path,start,end,replacement)`
  - `run_tests(command)`
  - `submit_patch()`
- Make `_model_tool_loop` expose only these commands for normal coding tasks.
- Force all edits through line-anchored ACI edits unless a patch is a validated native patch payload.
- Add a rolling “current file cursor” to reduce repeated path/line tokens.
- Add structured observations with compact previews, not raw dumps.

**Metrics:**

- malformed patch rate
- wrong-file edit rate
- self-heal retries per accepted patch
- average tool turns per successful patch
- prompt tokens per turn

### 4. Add real held-out verification, not just the ledger placeholder

**Why:** `record_dual_pass(... held_out_pass=None)` records the shape but cannot detect Goodhart divergence yet.

**10/10 fix:**

Add a hidden evaluator that is not shown to the model or self-heal loop:

- For code changes:
  - direct tests visible to agent
  - hidden sampled tests or metamorphic checks not visible during repair
- For patch intent:
  - semantic diff review against task contract
  - “maintainer acceptability” rubric
- For security/path changes:
  - adversarial tests generated from path/capability policy

Implement `HeldOutVerifier.evaluate(task, branch, diff, traces) -> HeldOutResult`.

Then orchestrator records:

```python
self.gate_effectiveness.record_dual_pass(
    branch,
    grader_pass=ltl_ok and verification_status,
    held_out_pass=heldout.passed,
    evidence_ref=heldout.evidence_ref,
)
```

Do not feed held-out failure details back into self-heal. Feed only coarse escalation.

### 5. Upgrade token accounting from output fallback to full request accounting

**Why:** The tokenizer is now wired for fallback response counts, but routing/cost decisions need full input/output token measurement for the exact outgoing provider payload.

**10/10 fix:**

- Add `TokenAccountant.measure_request(model, messages_or_blocks, tools=None)`.
- Count:
  - system messages
  - user blocks
  - tool schemas
  - cache-control block overhead where provider-specific
  - expected max output separately
- Record token source in usage rows:
  - `measured:tiktoken`
  - `measured:tokenizers-json`
  - `estimated:len//4`
  - `provider-billed`
- CostGovernor should distinguish:
  - planned/estimated cost
  - measured local cost
  - provider billed cost

### 6. Make route pipeline authoritative

**Why:** `route_pipeline.py` is additive, but `rlm.py`/DAG routing still does scattered direct route decisions. Multiple routing sources create hidden disagreement and inconsistent cost/quality tradeoffs.

**10/10 fix:**

- All model selection goes through `decide_route()`.
- Fix the subtle router semantics: posterior choice should not be passed as `explicit_model`, because explicit model bypasses normal router constraints. Use a distinct parameter like `preferred_model`.
- `RouteDecision` should include:
  - selected model
  - preferred model
  - rejected candidates with reasons
  - estimated cost
  - confidence interval
  - whether user explicitly overrode route
- Record every `RouteDecision` to WAL as Tier-2 batched telemetry.

### 7. Build a true latency budget and critical-path profiler

**Why:** “Fast” requires knowing where the critical path is. Chimera has latency attribution, but not yet a single always-on critical-path report spanning model, tool, sandbox, WAL, graph, compaction, verifier, and provider.

**10/10 fix:**

Add `CriticalPathTrace`:

- turn id
- model wait ms
- stream first-token ms
- tool execution ms
- sandbox materialize/cache hit ms
- WAL fsync batch ms
- graph retrieval ms
- compaction ms
- verification/test ms
- prompt assembly/tokenization ms
- queue/admission wait ms

Emit a per-run flame summary:

```text
critical_path_ms=8420
model=5120 sandbox=930 tests=1800 wal=40 graph=120 prompt=210 compaction=20 other=180
```

Use this to gate all future “speed” changes.

### 8. Introduce latency SLO modes

**Why:** Not every task should pay the same verification/planning/provider overhead.

**Modes:**

1. **Inspect mode:** no writes, graph/search only, cheapest model, no test run.
2. **Micro edit:** one/two files, line-edit ACI, focused test, no DAG.
3. **Normal fix:** DAG allowed, focused tests + final test.
4. **High-risk:** full evidence, held-out verifier, mutation tests, strict approvals.

TaskExecutionProfiler already points this way; make it govern the full pipeline.

### 9. Make compaction and prompt cache block-native end to end

**Why:** `CompactionResult.content_blocks()` exists, but the provider path still primarily uses a flat transcript string and `PromptPartition.content_blocks()`.

**10/10 fix:**

- PromptAssembler should accept typed blocks:
  - stable system block
  - tool schema block
  - repository map block
  - compacted pointer block
  - retained tail block
  - live turn block
- ProviderClient converts blocks to provider-specific message format.
- PromptCacheTracker hashes each block independently and records which block caused a miss.

### 10. Add test-impact selection with confidence levels

**Why:** Running all tests is reliable but slow; running too few is fast but risky. Need explicit confidence.

**10/10 fix:**

For a patch, compute:

- directly touched tests
- import/dependency impacted tests
- changed-symbol tests
- historical regression tests for same files
- random smoke sample
- full suite requirement if confidence too low

Return:

```json
{
  "command": "pytest tests/test_x.py tests/test_y.py -q",
  "confidence": 0.87,
  "fallback": "full-suite-required-if-final-commit"
}
```

### 11. Make command proof cache invalidation exact

**Why:** Command proof caching is useful, but reusing test results must be invalidated by all relevant inputs.

**Required cache key inputs:**

- branch snapshot hash
- test command
- environment allowlist hash
- dependency lockfile hashes
- pytest version/python version
- relevant config hash
- selected test files and their hashes

If any are missing, command proof reuse risks false confidence.

### 12. Add provider conformance profiles to route decisions

**Why:** Provider capabilities are partly proved, but routing should also know conformance risks:

- strict JSON reliability
- function-call schema reliability
- streaming stability
- refusal shape
- rate-limit history
- context-window honesty
- tool-call argument malformation rate

Use ProviderCapabilityRegistry + UsageLedger + ToolProtocol failures to build a `ProviderReliabilityProfile`.

### 13. Improve WAL batching semantics on exceptions

**Why:** Current `WALBatchScope.__exit__` flushes even on exceptions. For Tier-2 telemetry this can be fine, but the semantic should be explicit.

**10/10 fix:**

- Add `flush_on_exception: bool = True` parameter.
- For telemetry, flush exception traces with `status=failed`.
- For normal success-only bookkeeping, discard or mark aborted.
- Add nested-scope tests.

### 14. Make speculative execution prove its own usefulness

**Why:** Speculative execution can hurt when prediction misses or verifier pressure is high.

**10/10 fix:**

- Track:
  - prediction count
  - hit count
  - discarded count
  - saved latency estimate
  - added queue pressure
- Enable only if recent expected value is positive.
- Start with read-only tools only.
- Never speculate writes.

### 15. Restore / replace archived memory functionality with a tiny contradiction ledger

**Why:** Full causal/belief memory was dead weight, but contradiction detection is still useful at subagent merge points.

**10/10 replacement:**

Add a small `ContradictionLedger` instead of restoring 2,280 LOC:

- record claim: `{subject, predicate, value, source, trust, evidence_ref}`
- detect conflicts on same subject/predicate
- prefer higher-trust/fresher evidence
- surface conflicts in subagent condensation

This delivers the needed function without the old complexity.

### 16. Add quality-of-output rubric independent of tests

**Why:** Tests do not measure maintainability, minimality, API design, or user intent fit.

Add `PatchReviewRubric` scoring:

- minimal diff
- target scope compliance
- no placeholder code
- public API compatibility
- error handling
- readability
- follows existing style
- no new global state unless justified
- tests match behavior
- rollback safety

Use it as a non-optimized post-hoc held-out signal, not as a self-heal target.

### 17. Add dataset of adversarial harness tasks

**Why:** A harness needs regression tests for agent failure modes, not just unit tests for modules.

Create `evals/harness_regression/` with tasks:

- assessment request must not write
- ambiguous request must ask or report no mutation
- malicious README instruction ignored
- wrong file name trap
- passing test but bad intent trap
- hidden import dependency trap
- stale cache trap
- provider malformed JSON trap
- branch conflict/CAS trap

Run nightly or before release.

### 18. Reduce public API surface

**Why:** `chimera/__init__.py` exports many classes. Large public API increases compatibility burden and model/human cognitive load.

**10/10 fix:**

- Define `chimera.public` minimal API.
- Move experimental exports behind `chimera.experimental`.
- Keep `__init__.py` thin.
- Add API surface tests.

### 19. Make generated evidence user-facing and compact

**Why:** Evidence exists, but users need a concise acceptance report.

Every `ChimeraHarness.run()` should return:

```text
What changed
Why it matches task
Tests run
Verification status
Known limitations
Evidence refs
Next suggested action
```

This improves output quality more than more internal receipts.

### 20. Add release-quality performance gates

**Why:** “10/10 speed” must be protected by tests.

Add performance tests with generous but real thresholds:

- `Sandbox.exec("true")` cached branch view under X ms on fixture repo
- WAL batch 100 entries under Y ms
- graph incremental update under Z ms
- ACI search under Z ms on N files
- Prompt assembly/tokenization under Z ms
- RLM mock task under Z ms

Fail only on large regressions to avoid flaky tests.

## Ranked implementation sequence

### Tier 0 — correctness fixes before more optimization

1. Exact branch-view correctness for sandbox cache/bwrap overlay.
2. Command proof cache invalidation audit.
3. WALBatchScope exception semantics.

### Tier 1 — make existing new layers real hot-path owners

4. Move RLM patch/test/provider/tool/prompt call sites to extracted facades.
5. Make ACI the default edit/search/view path.
6. Make route_pipeline authoritative for all model selection.
7. Make compaction/prompt cache block-native end to end.

### Tier 2 — real reliability/quality gains

8. Add real held-out verifier.
9. Add independent patch quality rubric.
10. Add contradiction ledger at subagent merge.
11. Add provider reliability profiles.

### Tier 3 — speed and token efficiency

12. Critical-path profiler.
13. Latency SLO modes.
14. Test-impact confidence selector.
15. Positive-EV speculative execution only.

### Tier 4 — maintainability / long-term 10/10

16. Shrink public API.
17. Expand adversarial harness evals.
18. Add performance gates.
19. Continue `rlm.py` strangler split until it is mostly orchestration only.

## The single most important strategic point

Chimera already has many strong subsystems. The path to 10/10 is not adding more isolated modules. It is enforcing this rule:

> Every subsystem must either own a hot-path decision, produce measured evidence used by a hot-path decision, or be moved to experimental/archive.

That rule improves all target axes at once: output quality, reliability, token efficiency, speed, minimum latency, and maintainability.
