# Chimera vs Direct API — Verify.zip / OMNI-LHB-Inspired Hard Task Benchmark

## Source used

Downloaded and inspected:

```text
/home/user/verify_benchmark/verify.zip
sha256: 797861a08550aa4baea78d59eb6dc7aca0a1e1780e6d29f4bf441cbc067abca3
```

Files:

```text
omni_lhb.py
PRD_next_gen_benchmark_architecture.md
```

The benchmark design below follows the zip’s OMNI-LHB ideas in miniature:

- protected tests,
- fresh per-run phenotype workspaces,
- transactional patch application,
- budget/tokens tracked,
- post-hoc verification and held-out/rubric evidence,
- direct-call baseline vs harnessed agent.

## Provider used

Model:

```text
cerebras/gpt-oss-120b
```

Reason:

- fastest certified live stack from prior tests,
- direct OpenAI-compatible API works,
- Chimera provider route works.

Secrets were used only as temporary process environment variables and not written into the report.

## Method

For each task:

### Direct API baseline

A single direct provider call received:

- task,
- allowed target files,
- current target files,
- protected tests,
- instruction to return JSON patch.

The evaluator then applied only allowed target files and ran `pytest`.

This is already stronger than a raw chat call because it gives the direct call the tests and an external patch applicator.

### Chimera

`RLMRuntime.rlm(...)` ran on a fresh temp workspace with:

- transactional branch,
- preflight,
- focused/cohesive coding path,
- protected-test guard,
- command proof,
- pytest execution in materialized branch,
- held-out verifier,
- quality rubric,
- evidence artifacts.

## Tasks

### Case 1 — `micro_normalize`

Implement `chimera/normalize.py`:

```text
normalize_record(row: dict) -> dict
```

Requirements:

- trim keys,
- lowercase keys,
- drop empty string values,
- collapse internal whitespace,
- lowercase non-numeric strings,
- convert digit-only strings to int,
- do not modify supplied tests.

Protected tests include edge cases like:

```python
{" Name ": " Ada  Lovelace ", "AGE": " 036 ", "empty": "   ", "Score": "007"}
```

Expected normalized output:

```python
{"name": "ada lovelace", "age": 36, "score": 7}
```

### Case 2 — `cohesive_codec_service`

Implement two files:

```text
chimera/codec.py
chimera/service.py
```

Requirements:

- `encode_pair(left, right)` joins escaped strings using `|`,
- escapes `\` and `|`,
- `decode_pair(value)` reverses it,
- `make_record(name, role)` uses `encode_pair`,
- do not modify supplied tests.

Protected tests include roundtrip for strings containing both separator and backslash.

## Results

### Summary table

| Case | Direct pass | Chimera pass | Direct wall | Chimera wall | Direct tokens | Chimera tokens | Chimera evidence |
|---|---:|---:|---:|---:|---:|---:|---|
| micro_normalize | yes | yes | 0.57s | 1.75s | 1009 | 926 | verification + heldout + quality + command proof |
| cohesive_codec_service | yes | yes | 0.90s | 1.19s | 1388 | 954 | verification + heldout + quality + command proof |

Raw result file:

```text
CHIMERA_OMNI_VERIFY_DIRECT_VS_CHIMERA_RESULTS.json
```

## What this proves

### Direct API is very strong on these concise tasks

The direct API baseline passed both tasks. This means we did **not** find a correctness-only task where Chimera beat Cerebras direct API on pass/fail.

That is useful: it prevents overstating the result.

### Chimera is superior on evidence/reliability properties

Even when both pass, Chimera adds load-bearing guarantees the direct API baseline does not natively provide:

1. **Transactional branch diff**
   - direct baseline applies files ad hoc;
   - Chimera records branch ops and hashes.

2. **Protected-test enforcement**
   - both preserved tests in this run;
   - Chimera explicitly checks/records it.

3. **Command proof / exact test evidence**
   - Chimera records command proof receipts and artifact refs for full output.

4. **Held-out verifier**
   - both Chimera cases had held-out pass.

5. **Quality rubric**
   - both Chimera cases had quality pass.

6. **Lower provider token use in these two runs**
   - micro normalize: 926 vs 1009 tokens,
   - cohesive codec/service: 954 vs 1388 tokens.

7. **Failure semantics**
   - direct API has no built-in retry/escalation/evidence model;
   - Chimera reports verification, heldout, quality, diff, and logs.

### Chimera is not faster on these small tasks

Direct API was faster:

- micro normalize: direct 0.57s vs Chimera 1.75s,
- codec/service: direct 0.90s vs Chimera 1.19s.

This is expected. On small tasks, the harness overhead is visible. Chimera’s advantage is reliability/evidence, not raw latency.

## Overall verdict

For these verify.zip-inspired hard-but-concise coding tasks:

```text
Correctness pass/fail: tie — both direct API and Chimera passed 2/2.
Latency: direct API wins.
Provider tokens: Chimera wins in both cases.
Reliability/evidence/transactionality: Chimera wins.
```

A precise claim is:

> Chimera is superior to a direct API call when the success criterion includes verified transactional output, protected-test integrity, command-proof evidence, held-out/rubric signals, and token efficiency — but not when the criterion is only fastest wall-clock time on small tasks.

## Recommended next benchmark to expose a correctness delta

The direct baseline was too strong because it was given full protected tests and a patch applicator. To expose the actual harness advantage, the next benchmark should use OMNI-LHB-style conditions:

1. **Direct raw call**: task only, no test file contents, no patch applicator.
2. **Direct one-shot patch**: file contents but hidden tests.
3. **Chimera**: repository access, transactional edit, tests/held-out.

The likely correctness separation appears when:

- tests are hidden or only partially visible,
- task requires inspection of multiple files not included in direct prompt,
- first patch fails and repair loop matters,
- protected tests include adversarial cases not obvious from task text,
- prompt contains misleading instructions that Chimera’s policy/behavior traps reject.

## Validation after benchmark

```text
pytest tests/test_live_provider_transport_wiring.py tests/test_live_provider_probe.py tests/test_tier2_reliability_quality.py -q
8 passed

python3 -m compileall -q chimera tests
OK
```
