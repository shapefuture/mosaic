# Chimera Batch-01 + Kestrel PRD Full Review / Implementation Report

## Inputs read

I read both attached files end-to-end:

```text
/home/user/uploads/batch-01.md                         2383 lines
/home/user/uploads/PRD-superior-agent-architecture.md   506 lines
```

The earlier `chimera_kestrel_analysis.md` had already distilled many items from these sources; this pass checked the source documents themselves and implemented additional relevant mechanisms that improve speed, output quality, reliability, token efficiency, and latency without blindly porting the whole Kestrel architecture.

## New additional mechanisms implemented in this pass

### 1. Truncated tool-call kill switch

Inspired by `pi`'s most important safety invariant:

> Never execute tool calls from an assistant message that stopped because of output length.

Updated:

```text
chimera/rlm_loop.py
```

Behavior:

- If `finish_reason == "length"` and the message contains native/textual tool calls, Chimera now does **not** execute them.
- It records a `truncated_tool_call_kill_switch` evidence row.
- It asks the model to re-issue complete tool calls.

Test:

```text
tests/test_additional_kestrel_regressions.py::test_truncated_tool_call_is_not_executed
```

### 2. Provider patch dialect tolerance: camelCase edit aliases

Inspired by pi's `prepareArguments` schema-drift absorption.

Updated:

```text
chimera/rlm.py::_normalise_patch_envelope
```

Now normalizes:

```text
oldText -> find
newText -> replace
```

in addition to existing aliases.

Test:

```text
test_patch_envelope_accepts_camelcase_edit_aliases
```

### 3. Edit matching with tab/space normalization fallback

Inspired by R2E-Gym / Kestrel ACI notes on lint-gated edits and occurrence-count enforcement.

Updated:

```text
chimera/rlm_action_methods.py
```

Added:

```python
_unique_text_replacement(current, needle, replacement)
```

Behavior:

- exact match is still preferred,
- if exact match fails, compares `expandtabs()` forms,
- maps normalized span back to original bytes,
- still requires exactly one match,
- does not fuzzy-rewrite untouched bytes.

Test:

```text
test_edit_expandtabs_match_applies_without_touching_unmatched_bytes
```

### 4. CompletionGate / verify-AC gate

Previously implemented and now verified against the source docs:

```text
chimera/completion_gate.py
```

It rejects unsupported "verified / implemented / artifact / service" claims when matching evidence is absent.

### 5. Learned context ceiling

Previously implemented and confirmed as relevant:

```text
chimera/context_ceiling.py
```

Shrink-only effective context windows plus status-code conditioning for 413s.

### 6. Compaction trigger hygiene and per-message disposition

Previously implemented and confirmed as relevant:

```text
chimera/compaction_policy.py
```

Covers:

- stale-usage skip,
- model-identity guard,
- unknown-window gate,
- cache-read-inclusive silent-overflow detection,
- cache-cold idle trigger with size floor,
- reversible collapse,
- message disposition accounting.

### 7. Silent-transform confession convention

Previously implemented and confirmed as relevant:

```text
chimera/silent_transform.py
```

Provides:

- `SilentTransformLedger.confess(...)`,
- `silent_transform` WAL convention,
- source linter for fallback/truncation/compaction paths lacking a confession.

### 8. Retry taxonomy

Previously implemented and source-confirmed:

```text
chimera/backoff.py
```

Now distinguishes:

- auth,
- quota,
- validation,
- rate limit,
- transient network,
- backend,
- unknown.

Each decision carries retryability, delay, reason, and suggested action.

### 9. Stream-time tool extraction

Previously implemented and source-confirmed:

```text
chimera/stream_tools.py
```

Extracts complete textual tool-call blocks from streamed chunks without speculation.

### 10. Cooperative staleness contract

Previously implemented and source-confirmed:

```text
chimera/aci.py
```

`line_edit(..., expected_hash=...)` now rejects stale edits as retryable instead of applying them.

### 11. Pointer-row memory

Previously implemented and source-confirmed:

```text
chimera/pointer_memory.py
```

A cheap middle path between no memory and heavy causal/belief memory.

### 12. Double confirmation / KIRA-style optional verifier turn

Previously implemented and confirmed as useful only when conditional:

```text
chimera/double_confirm.py
```

Runs only when forced, high-risk, or CompletionGate flags a claim.

### 13. Native compaction capability gate

Previously implemented as a safe fallback capability hook:

```text
chimera/native_compaction.py
```

Current providers remain local-compaction fallback until canary-proved.

### 14. AST-canonical patch consensus

Previously implemented and source-confirmed as future-ready for multi-candidate generation:

```text
chimera/patch_consensus.py
```

## Tests added in this pass

```text
tests/test_additional_kestrel_regressions.py
```

Covers:

- camelCase edit alias normalization,
- tab/space edit match fallback,
- truncated tool-call kill switch.

## Full verification

```text
python3 -m compileall -q chimera tests
OK

pytest tests -q
413 passed in 17.58s
```

## Items intentionally not implemented as full rewrites

The PRD proposes or references several broad architectures. I did not blindly port these because they are either already partially represented in Chimera, forward-looking for capabilities Chimera does not yet use by default, or would add large complexity before measurement:

1. **Full six-plane Kestrel kernel rewrite**
   - Rejected for now. Chimera already has many equivalent planes; full rewrite would be high risk.

2. **Service-registry/hook-slot kernel architecture**
   - Not adopted. Current mixin/module split is enough for now.

3. **Always-on multi-agent economics gate**
   - Not adopted. Chimera already has route/cost governance; multi-agent paths should remain gated by measured benefit.

4. **Goal-mode typed state machine**
   - Not adopted as a rewrite. `stop_reasons.py` provides a smaller typed vocabulary foundation.

5. **Provider-native compaction as default**
   - Not enabled until a provider-specific canary proves support and recall quality.

6. **LLM-narrative compaction planner outcomes**
   - Not needed while compaction remains deterministic/local. The trigger hygiene and disposition layer is ready if a planner is added later.

7. **Multi-candidate patch generation**
   - Not enabled by default. AST consensus exists and is ready when that path is added.

8. **Always-on double-confirmation**
   - Not enabled due extra latency/tokens. Conditional only.

## Biggest remaining opportunities after this pass

These are now the most promising next improvements:

1. **Wire stream-time extraction into live streaming provider execution**
   - The extractor exists; the next step is to dispatch complete tool calls during streaming for providers that stream tool text, not only after full message completion.

2. **Add provider-native compaction canaries**
   - Do not switch to native compaction blindly. Add canaries and A/B recall tests.

3. **Add multi-candidate generation behind a budget gate**
   - Use `patch_consensus.py` to select only when AST-canonical quorum is reached.

4. **Expand the strict stress eval suite**
   - The `strict_stress.py` harness exists. Add more hidden-test cases and repeated runs.

5. **Reduce deterministic scaffolds over time**
   - `CHIMERA_DISABLE_DOMAIN_SCAFFOLDS=1` exists for measuring generalized repair capability.

## Final status

```text
413 passed in 17.58s
```
