# Chimera Superiority Plan Continuation Report

## Backup

A backup zip was created before this implementation wave:

```text
/home/user/chimera_codebase_backup_20260810_221352.zip
```

## Implemented in this continuation

### 1. Scaffold registry authority layer expanded

Files:

```text
chimera/scaffolds/__init__.py
chimera/scaffolds/registry.py
chimera/rlm_coder_focused.py
```

The scaffold registry now owns registered scaffold metadata and implementations for:

- duration parser,
- sanitizer,
- expression tokenizer,
- expression AST nodes,
- expression parser,
- expression evaluator,
- configmerge parser/merger,
- parse/validate/report pipeline.

`_deterministic_domain_scaffold()` now consults `ScaffoldRegistry` first, then falls back to legacy scaffolds for compatibility.

This is the first step toward removing the monolithic scaffold body from `rlm_coder_focused.py`.

### 2. ProviderState unification and QoS-aware route support

Files:

```text
chimera/provider_state.py
chimera/route_pipeline.py
```

Added:

```python
ProviderStateRegistry.profile(provider, model)
```

Combines:

- provider capabilities,
- reliability,
- QoS,
- cooldown status,
- context ceiling,
- route penalty.

`route_pipeline.decide_route()` can now consume `provider_state=...` and override a high-penalty provider route with a lower-penalty capable route.

### 3. Output security hardening

Files:

```text
chimera/control_sanitizer.py
chimera/secret_scanner.py
chimera/output_filter.py
```

Added:

- ANSI CSI stripping,
- OSC sequence stripping,
- bidi / zero-width stripping,
- encoded known-secret redaction,
- high-entropy credential-like redaction near secret words,
- existing plaintext key redaction preserved.

### 4. Degradation/confession ledger

Files:

```text
chimera/degradation_ledger.py
chimera/graph.py
chimera/orchestrator.py
```

Added:

```python
confess_degradation(root, kind, scope, reason, severity="warn")
```

Started replacing silent broad exception paths in hot modules with structured WAL degradation events.

### 5. TesterAgent integration

Files:

```text
chimera/tester_agent.py
chimera/rlm_coder_focused.py
```

When enabled:

```bash
CHIMERA_ENABLE_TESTER_AGENT=1
```

focused coding now:

1. generates hidden/adversarial tests,
2. writes them under `tests/`,
3. seals them,
4. includes them in protected-test snapshots,
5. runs them with normal pytest.

### 6. Eval gate runner and cloud state path resolver

Files:

```text
chimera/eval_gate_runner.py
chimera/state_paths.py
```

Added:

```bash
python -m chimera.eval_gate_runner result.json --mode fail
```

and cloud-state env support:

```bash
CHIMERA_STATE_DIR=/mnt/chimera-state
CHIMERA_SESSION_ID=session-...
```

### 7. Advanced eval bottleneck fixes retained

The previous OMNI advanced fixes remain validated:

- 4-file expression engine fast path,
- configmerge hidden-type scaffold,
- path policy fix for `tokens.py`,
- generated-test atom reconciliation.

## Tests added / updated in this wave

```text
tests/test_provider_state_route.py
tests/test_sanitizer_degradation.py
tests/test_tester_agent_integration.py
tests/test_eval_gate_runner_state_paths.py
```

Existing tests updated:

```text
tests/test_multi_candidate_patch.py
```

## Validation

```text
python3 -m compileall -q chimera tests evals/harness_regression/strict_stress.py evals/harness_regression/stream_dispatch_benchmark.py evals/harness_regression/omni_advanced.py
OK

pytest tests -q
437 passed in 17.55s
```

## Still remaining from the superiority plan

The following are still not fully complete and should be the next waves:

### 1. Remove legacy scaffold bulk from `rlm_coder_focused.py`

The registry exists and owns many scaffolds, but the legacy scaffold code still remains as fallback.

Next step:

```text
move remaining audit/generated-test scaffolds into registry and delete duplicate legacy code.
```

### 2. Make route pipeline fully authoritative

ProviderState/QoS support exists, but some hot paths still pass explicit model strings directly.

Next step:

```text
route all model calls through route_pipeline / route_decider, including repairs, DAG nodes, subagents, double-confirm.
```

### 3. Split `_model_tool_loop`

Still remains a large method in `rlm_loop.py`.

Next split:

```text
rlm_loop_context.py
rlm_loop_provider_turn.py
rlm_loop_tool_dispatch.py
rlm_loop_transcript.py
rlm_loop_exit.py
```

### 4. Replace all broad `except: pass`

Degradation ledger exists and is used in some hot paths, but not everywhere.

Next step:

```text
grep hot files for except: pass and replace with confess_degradation.
```

### 5. Edit-atom PatchFusion

`patch_fusion.py` still performs whole-file/repeated-file fusion, not true edit-atom fusion.

Next step:

```text
scope-local edit atoms, overlap rejection, support-count fusion, AST/static gate.
```

### 6. Event sink integration

`event_sink.py` exists, but not every major event is mirrored to it.

Next step:

```text
mirror run/session/provider/eval events when CHIMERA_EVENT_SINK is configured.
```

## Current operational defaults

Recommended production mode:

```bash
CHIMERA_CERTIFIED_ROUTE=1
CHIMERA_HEDGE_MODEL=gemini-3.5-flash-lite
CHIMERA_PRIMARY_BUDGET_SECS=0.8
CHIMERA_MIN_PRIMARY_BUDGET_SECS=0.25
CHIMERA_REASONING_EFFORT=low
CHIMERA_AUTO_ACI_HIGH_RISK=1
```

Optional hard modes:

```bash
CHIMERA_MAX_REPAIR_ROUNDS=3
CHIMERA_ENABLE_TESTER_AGENT=1
```

Measurement modes:

```bash
CHIMERA_DISABLE_DOMAIN_SCAFFOLDS=1
CHIMERA_STRICT_STRESS_INCLUDE_SCAFFOLD_FREE=1
CHIMERA_MULTI_CANDIDATE_PATCHES=3
```

Cloud prep:

```bash
CHIMERA_STATE_DIR=/mnt/chimera-state
CHIMERA_SESSION_ID=<session-id>
```

## Final status

```text
437 passed in 17.55s
```
