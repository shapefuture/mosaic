# Chimera Codebase First-Principles Superiority Review

## Scope

This review analyzes the current Chimera code itself, not just the external PRD/analysis documents. I used static code metrics, hot-path inspection, full regression tests, live provider measurements, and targeted online research in English and Chinese to identify bottlenecks, missed mechanisms, and superior alternatives.

Current verification after the latest implemented improvements:

```text
pytest tests -q
420 passed in 15.75s
```

## First-principles success function

A truly superior coding-agent harness maximizes:

```text
accepted useful work per unit cost/time/risk
```

That decomposes into:

```text
output quality
× hidden-test/spec correctness
× mergeability/security
× evidence quality
× latency
× token efficiency
× operational reliability
× maintainability
÷ complexity tax
```

Any subsystem that does not either:

1. improve a hot-path decision,
2. produce measured evidence used by a hot-path decision, or
3. reduce risk/cost/latency,

should be removed, gated, or moved to experimental.

## Bird’s-eye codebase state

Static scan of current live modules:

```text
223 modules
~33,254 LOC in chimera/
```

Largest current modules:

```text
rlm_coder_focused.py          1045 LOC
rlm_loop.py                    645 LOC
rlm_execution_methods.py       671 LOC
rlm_provider.py                676 LOC
rlm_dag_solver.py              559 LOC
sandbox.py                     493 LOC
branch.py                      585 LOC
```

`rlm.py` itself has been reduced from ~4,991 LOC to ~425 LOC and is now mostly a runtime shell/mixin composition point.

Most important architectural strengths now present:

- transactional branch workspace,
- WAL and batched Tier-2 writes,
- exact command proof cache,
- ACI with lint and staleness contracts,
- live provider routing for Cerebras/Gemini/TokenRouter,
- read-only stream-time tool dispatch,
- held-out/rubric/CompletionGate verification layers,
- strict stress evals,
- context compaction hygiene policy,
- secret redaction and UTF-8-safe truncation,
- per-path mutation serialization,
- optional multi-candidate AST consensus,
- optional certified hedge routing.

## Bottlenecks and resolved opportunities

### 1. Provider routing / live stack

Problem found: slash-prefixed direct-provider models were being forced through OpenRouter when an OpenRouter key existed.

Fix implemented:

- `cerebras/...` routes native Cerebras.
- `tokenrouter/...` routes native TokenRouter.
- `gemini/...` routes native Gemini.
- `google/gemma-...:free` still routes OpenRouter.

Live results:

```text
Cerebras direct through Chimera: pass, ~0.88s for arithmetic RLM task
Gemini direct through Chimera: pass, ~0.74s
TokenRouter/Kimi through Chimera: pass, ~6.83s on arithmetic RLM task
OpenRouter free: honest 429 quota failure
```

Decision:

- certified path = Cerebras primary, Gemini hedge,
- TokenRouter/Kimi = reference-quality lane, not latency lane,
- OpenRouter free = opportunistic only.

### 2. Hedge routing

TRIZ contradiction:

- Faster failover improves tail latency.
- But hedging too early wastes tokens and can worsen latency.

Resolution: separation by condition.

Implemented:

```bash
CHIMERA_CERTIFIED_ROUTE=1
CHIMERA_HEDGE_MODEL=gemini-3.5-flash-lite
CHIMERA_PRIMARY_BUDGET_SECS=0.8
CHIMERA_MIN_PRIMARY_BUDGET_SECS=0.25
```

Measured:

| Mode | p50 / sample wall | Tokens | Decision |
|---|---:|---:|---|
| no hedge | ~0.27–0.29s | ~100 | baseline |
| hedge with 0.05s budget | worsened to ~1.94s p50 before clamp | 18 | over-triggered |
| hedge with 0.25s floor / 0.8s budget | ~0.17–0.33s | ~99–100 | keep |

Decision:

- keep certified hedge with minimum budget clamp,
- do not use pathological sub-0.25s primary budgets by default.

### 3. Hidden-test correctness

Direct API is faster when fully informed. Under strict hidden-test conditions, Chimera wins.

Strict benchmark results:

| Case | Direct raw | Direct visible/no tests | Chimera |
|---|---:|---:|---:|
| duration parser hidden edges | fail | fail | pass |
| inventory hidden schema | fail | fail | pass |
| event summary hidden schema | fail/queue | fail | pass |

Max-stress results:

| Case | Direct raw | Direct visible/no tests | Chimera |
|---|---:|---:|---:|
| 3-file pipeline | fail | fail | pass |
| prompt-injection sanitizer | fail | fail | pass |

Decision:

- Chimera is superior when requirements are repository/test/evidence dependent.
- Direct API remains latency winner only on small fully specified tasks.

### 4. Repair loop

Problem: raw pytest text is noisy and model repair can loop or miss the actionable diff.

Implemented:

- `chimera/pytest_repair.py`
- `extract_repair_hints(...)`
- `build_local_repair_plan(...)`
- injected current source + pytest anchors + assertion snippets + failing inputs into repair prompt.

Far transfer:

- from program repair / debugger-agent loops to a compact deterministic preprocessor before provider retry.

Decision:

- keep generalized repair loop enabled,
- keep deterministic scaffolds only as fallback/known-brittle-class repair,
- measure scaffold-free before adding new scaffolds.

Repeated scaffold-free measurement:

| Mode | Pass rate | Median wall | Median tokens |
|---|---:|---:|---:|
| scaffolded | 3/3 | 1.452s | 949 |
| scaffold-free | 2/3 | 56.569s | 987 |

Decision:

- do not disable scaffolds globally yet.

### 5. Multi-candidate consensus

TRIZ contradiction:

- More candidates improve reliability.
- More candidates hurt latency/token efficiency.

Resolution: keep behind budget gate.

Implemented:

```bash
CHIMERA_MULTI_CANDIDATE_PATCHES=1..5
CHIMERA_MULTI_CANDIDATE_TOKEN_BUDGET=6000
CHIMERA_MULTI_CANDIDATE_MIN_VOTES=2
```

Measured:

| Mode | Pass | Wall | Tokens |
|---|---:|---:|---:|
| single candidate | yes | 1.094s | 862 |
| multi-candidate | yes | 119.853s | 6906 |

Decision:

- do not enable by default,
- use only after failed single-candidate attempt or high-risk task.

### 6. Stream-time tool dispatch

Online research confirms this is a production serving trend; NVIDIA Dynamo exposes streaming tool dispatch to start tool execution as soon as tool payload is parsed rather than at turn end.

Implemented:

- `chimera/stream_tools.py`
- wired into `rlm_provider.py` streaming path,
- read-only dispatcher in `rlm_loop.py`.

Measured:

- live Cerebras stream emitted a textual tool block and Chimera extracted/dispatched it.
- synthetic benchmark hid 100% of simulated tool wall time.

Decision:

- keep enabled for read-only dispatch,
- never dispatch writes mid-stream.

### 7. Context and compaction

Online research shows provider-native compaction exists for OpenAI Responses and Anthropic-style context management, but current certified live providers do not have canary-proved native compaction in Chimera.

Implemented local mechanisms:

- `compaction_policy.py`
- stale-usage skip,
- model identity guard,
- unknown-window gate,
- silent-overflow detection including cache-read tokens,
- cache-cold idle trigger with size floor,
- reversible deterministic collapse,
- per-message disposition accounting.

Decision:

- keep local compaction fallback,
- do not enable native compaction until provider canary + recall A/B passes.

### 8. Prompt cache and token efficiency

Online research confirms prompt caching is prefix-sensitive and tool-definition order matters. Chimera now has:

- prompt cache health tracking,
- token measurement integration,
- compaction block split,
- context ceiling shrink-only mechanism.

Remaining improvement:

- provider-specific cache-breakpoint strategy for Anthropic/OpenAI-style providers if those become primary.
- current certified stack is Cerebras/Gemini, so direct benefit is limited.

### 9. Output safety

Implemented:

- secret scanner,
- output redaction,
- UTF-8-safe truncation,
- explicit truncation notice,
- truncated tool-call kill switch.

These address common production failure modes:

- terminal/control-char leakage,
- credentials entering model-visible context,
- partial tool calls executing after length cutoff,
- malformed UTF-8 truncation.

### 10. Workspace / sandbox

Implemented:

- cached materialized branch views,
- base-state invalidation,
- bwrap certification flag,
- `CHIMERA_SANDBOX_MODE=materialized|bwrap|auto`,
- per-path mutation queue.

Online research supports DeltaFS/DeltaBox-style future direction: dynamic overlay layers and C/R can provide millisecond checkpoint/rollback.

Decision:

- current fallback is correct and reliable,
- next disruptive leap is true overlayfs/reflink layer stack instead of materialization cache.

## Remaining high-potential improvements not fully implemented

### A. True DeltaFS-style branch runtime

Current state:

- branch overlay exists,
- materialized cache avoids repeated full copy,
- bwrap direct overlay path requires certification.

Superior alternative:

- dynamic overlay layer stack with frozen read-only layers and new writable layer per checkpoint.

Expected benefit:

- milliseconds checkpoint/rollback,
- enables serious tree search / multi-candidate sandbox exploration.

Why not done yet:

- requires host filesystem/kernel/bwrap/overlayfs support, not fully testable in this sandbox.

Recommended next step:

```text
Implement host capability probe + optional DeltaFS backend.
```

### B. Provider-native compaction canary implementation

Current state:

- decision/canary scaffolding exists,
- no live provider in certified stack supports it.

Superior alternative:

- if OpenAI/Anthropic becomes available, run native vs local compaction A/B recall tests.

Recommended next step:

```text
Add OpenAI/Anthropic native compaction adapter only after live keys/provider choice exist.
```

### C. Multi-candidate PatchFusion, not just consensus

Current state:

- AST-canonical consensus exists.

Superior alternative from research:

- patch fusion / edit-atom evidence fusion can outperform selecting one candidate.

Expected benefit:

- improve pass@1 from candidate pool without tests/model judge at selection time.

Risk:

- complexity and potential bad merge of edit atoms.

Recommended next step:

```text
Implement experimental PatchFusion over AST/local edit atoms, gated behind CHIMERA_PATCH_FUSION=1.
```

### D. Fully ACI-only default for coding tasks

Current state:

- ACI exists,
- `CHIMERA_ACI_ONLY=1` exists,
- raw patch path still allowed by default.

Superior alternative:

- make ACI-only default for high-risk/security and hidden-test evals.

Expected benefit:

- fewer malformed/wrong-file patches,
- better staleness handling.

Risk:

- can slow down simple fully specified tasks.

Recommended next step:

```text
Default ACI-only when task is high-risk or completion gate flags uncertainty.
```

### E. Automatic hidden-test generation / tester agent

Current state:

- held-out verifier is deterministic and shallow.

Superior alternative:

- separate Tester agent writes adversarial tests from task spec before Coder sees implementation.

Expected benefit:

- catches underspecified direct-prompt failures,
- reduces reward hacking.

Risk:

- extra model calls,
- tests can be over-specific or wrong.

Recommended next step:

```text
Add optional Tester->Coder loop for high-risk tasks only.
```

### F. CompletionGate hard enforcement

Current state:

- CompletionGate result is attached.

Potential improvement:

- actually degrade/fail verification when CompletionGate rejects full verification.

Risk:

- false positives on benign claims.

Recommended next step:

```text
Make CompletionGate blocking only for final commit/approval path, not for intermediate diagnostics.
```

### G. Live provider QoS table

Current state:

- provider reliability profile exists,
- hedge measured manually.

Potential improvement:

- continuously maintain p50/p95 latency, tokens/sec, error class, cost, rate-limit windows per provider/model.
- route by live QoS, not static provider order.

Expected benefit:

- better latency and cost adaptation.

Recommended next step:

```text
ProviderQoSLedger + route_pipeline penalty/reward based on live stats.
```

### H. Agentic eval suite as product gate

Current state:

- strict stress script exists,
- hidden-test cases exist,
- scaffold-free/multi-candidate measurement exists.

Potential improvement:

- convert to a CI benchmark matrix with thresholds:
  - pass rate,
  - token budget,
  - wall-clock budget,
  - evidence completeness,
  - no integrity violations.

Expected benefit:

- prevents regressions in the thing that matters, not just unit tests.

## TRIZ / far-transfer solutions

### Contradiction: fastest path vs safest path

Resolution: separation by condition.

- Direct fast path for assessment/no-target tasks.
- Micro/cohesive transaction for bounded code edits.
- DAG for broad tasks.
- Multi-candidate/Tester/DoubleConfirm only for high-risk or failed first pass.

### Contradiction: compaction saves context but destroys cache

Resolution: laddered mechanism.

1. reversible local collapse,
2. cache-cold idle compaction,
3. threshold compaction with block split,
4. provider-native only if canary-proved.

### Contradiction: tests prove behavior but can be gamed

Resolution: separate verifier authority.

- protected tests immutable,
- negative scoring for integrity edits,
- CompletionGate,
- held-out verifier,
- future Tester agent with hidden tests.

### Contradiction: memory helps long horizon but pollutes context

Resolution: pointer-row memory.

- inject table of contents, not bodies,
- outcome-conditioned bumps,
- fetch body only when needed.

### Far transfer: CPU branch prediction -> speculative tools

Implemented partially:

- read-only stream-time dispatch,
- speculative tool executor remains gated.

Do not speculate writes.

### Far transfer: OS copy-on-write -> branch runtime

Future target:

- DeltaFS-style dynamic overlay backend.

## Recommended bold roadmap

### Phase 1 — Quality hardening (immediate)

1. CompletionGate blocking for final commit/approval.
2. Provider QoS ledger and route penalties.
3. CI strict stress benchmark thresholds.
4. High-risk tasks default to ACI-only.

### Phase 2 — Latency breakthrough

1. DeltaFS/reflink branch runtime backend.
2. Stream-time dispatch live metrics on real tool loops.
3. Provider QoS dynamic hedge thresholds.
4. Cache-breakpoint tuning for providers with prompt caching.

### Phase 3 — Hidden-test superiority

1. Optional Tester agent generates adversarial tests.
2. Coder cannot see Tester internals until after first patch.
3. Held-out/Tester tests are immutable and separately signed.
4. Reward hacking score penalty feeds capability calibration.

### Phase 4 — Candidate-pool intelligence

1. Multi-candidate only after single failure or high-risk.
2. PatchFusion edit-atom consensus.
3. AST canonical majority + local static guards.
4. Use no LLM judge at selection time.

### Phase 5 — Provider-native context systems

1. Add OpenAI/Anthropic native compaction canaries when credentials/provider route exists.
2. A/B recall tests vs local compaction.
3. Only enable if artifact/decision recall is not worse.

## Final judgement

Chimera is already much stronger than a direct API call under hidden-test and evidence-heavy conditions. It is not yet maximally superior on latency and autonomous broad-DAG repairs.

The biggest remaining disruptive wins are:

1. DeltaFS-style runtime,
2. Tester-agent hidden tests,
3. provider QoS dynamic routing,
4. PatchFusion-style candidate fusion,
5. strict CI benchmark gates.

Everything else is incremental.
