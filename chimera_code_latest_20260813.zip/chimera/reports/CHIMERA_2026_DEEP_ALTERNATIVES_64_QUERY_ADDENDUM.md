# Chimera Deep Alternatives Addendum — Additional 64-Query Pass

**Date:** 2026-08-11  
**Method:** 64 additional English/Chinese targeted queries after the earlier alternative audit. Sources prioritized upstream docs, official repositories, and primary papers. This is a research synthesis, not an adoption decision.

## Query coverage (64 additional queries)

1. Durable execution, queueing, pooling, and CRDTs — 16
2. Sandboxes, egress, runtime enforcement, and Wasm — 16
3. Inference serving, routing, KV cache, PD, and speculative decoding — 16
4. Code intelligence, test impact, fuzzing, static analysis, profiling, and compilation — 16

## Highest-value underexplored alternatives

### A. Dynamic coverage-backed Test Impact Analysis is the best immediate speed workaround

Current real-source mutation calibration produced 5/5 detection but full-suite fallback on every case and a 1.148x focused/full time ratio. The static import graph is safe but did not save time on that corpus.

**Superior candidate:** dynamic per-test coverage map rather than looser static heuristics.

- `pytest-testmon` and pytest-TIA-like tools build dependency information from actual execution.
- Coverage.py supports `dynamic_context = "test_function"`, allowing an explicit test-to-executed-line map.
- This can be implemented inside Chimera without trusting third-party test selection: collect a branch-local coverage manifest, select impacted tests, then retain the constitutional floor and periodic/full promotion test.

**Experiment:** 30+ real curated mutations, not only five; compare static ImpactAnalyzer, dynamic coverage map, testmon/TIA candidate, and full suite. Track mutation recall, false selection, elapsed time, context of fallback, and full-suite misses. Promote nothing until recall and safety floors are predeclared and passed.

### B. Queue choice should be decided by job semantics, not generic SKIP LOCKED preference

Three materially different alternatives surfaced:

| Candidate | Strong fit | Reason not to install now |
|---|---|---|
| DBOS queue / current scheduler | durable coding task claims | Must measure first; eliminates new engine. |
| PGMQ | visibility-timeout competing consumers and archive/replay | External effects still need idempotency; Postgres extension dependency. |
| PgQue | high-volume durable event/fan-out stream with xmin/bloat concern | Newly released, different batching/latency semantics; not an immediate task-claim replacement. |
| Hatchet | full task/workflow policies, dependencies, worker controls | Documented DB/graph/payload scaling concerns and extra engine complexity. |

**New insight:** PgQue’s design is a better alternative than Hatchet/PGMQ only if measured production-like workload is a sustained event stream suffering from MVCC bloat or held xmin; it is not automatically better for short latency-sensitive agent-task claims.

### C. DBOS versus Restate is the important durable-runtime comparison

- DBOS is the smallest Postgres-first compatibility path.
- Restate supplies journaled durable services/keyed state and control semantics, but introduces a service control plane.
- Temporal remains the maturity escalation option.

**Workaround:** use Testcontainers/disposable Postgres to build one adapter contract test corpus. Test deterministic checkpoint recovery, at-least-once I/O, unknown provider outcome, cancellation, version drift, and serialized branch state. Select a runtime only if it preserves current Chimera effect/unknown semantics.

### D. Sandbox path has a pragmatic local alternative before microVM fleets

The supplied documents over-focus on forkd/Kata. The research suggests a staged ladder:

```text
Bubblewrap namespace policy
+ Landlock ambient-right reduction
+ optional nsjail seccomp profile
→ gVisor comparison
→ Firecracker/Kata/forkd on KVM host only
```

- Bubblewrap alone is a namespace construction tool, not a complete policy.
- Landlock can add unprivileged filesystem/network capability reduction on supported kernels.
- nsjail provides a direct seccomp/namespace comparison point.
- gVisor gives a different application-kernel tradeoff and may be preferable where network/I/O overhead is acceptable.
- Cilium FQDN controls and Tetragon are Kubernetes-specific deployment controls, not local replacement libraries.

**Workaround:** certify the lightest layer that passes the real escape/egress/process/resource matrix before considering microVM orchestration.

### E. Self-hosted inference has more alternatives than SGLang-only

| Layer | Alternatives worth benchmark | Non-negotiable constraint |
|---|---|---|
| Prefix cache | vLLM APC, SGLang RadixAttention | exact token prefix / real cache telemetry |
| Multi-replica routing | SGLang Router, NVIDIA Dynamo KV router, llm-d / Inference Gateway | cache locality versus load, dynamic-worker compatibility |
| PD disaggregation | SGLang NIXL/Mooncake, vLLM connectors, TensorRT-LLM, Dynamo | multi-GPU KV transfer/operational complexity; no generic throughput claim |
| KV offload | LMCache, Mooncake | cache lifecycle, privacy, host memory/disk pressure |
| Decode acceleration | vLLM/SGLang/TensorRT speculative decoding | model/hardware/acceptance-rate specific output and latency test |

**Correction:** vLLM documentation says PD disaggregation helps TTFT and tail ITL and does not itself improve throughput. Self-hosted cache/routing is only relevant after Chimera has a real GPU deployment and a reproducible prompt workload.

### F. Strong code intelligence alternatives require a sealed own-repo benchmark

- tokensave has broad local code graph features, but its own release history exposes update, telemetry, memory, orphan daemon, and cache-prefix concerns.
- SCIP/Kythe are compiler/indexer-grade routes for exact cross-reference, but Python/index freshness integration has cost.
- ast-grep and Tree-sitter are promising deterministic structural primitives that can enhance discovery but must not bypass branch/PatchQualityGate write authority.
- New “token saver” products make impressive self-reported claims but have not earned supply-chain or own-repo evidence.

**Workaround:** benchmark current CodeGraph/Impact/ContextPlan against a pinned read-only candidate using a sealed question set. Score recall, stale-index handling, tokens, latency, memory/RSS, egress, and process lifecycle.

### G. Quality/verification can improve without LLM self-judging

Underused tools worth data-gated trials:

- Coverage contexts + dynamic TIA
- mutmut / Cosmic Ray / Mutatest, potentially fault-driven mutation methods
- Hypothesis state machines for WAL/lease/outbox/scheduler transitions
- Atheris for parser/codec/native boundary fuzzing
- Pyright for staged type checks
- Ruff for fast deterministic lint gate
- CodeQL/Semgrep for security analysis, first in monitor mode

None is a model authority. They are deterministic/analysis inputs and must be introduced with false-positive/latency/failure-mode data.

### H. Native optimization alternatives

Use process sampling (py-spy) and controlled Scalene profiling first. If a target is proven hot:

```text
pure typed module → mypyc trial
numeric/array loop → Cython or PyO3 trial
packaging/startup concern → Nuitka trial
```

Every candidate needs mirror/property tests and an end-to-end speedup threshold. Do not transpile the control plane wholesale.

## Revised first implementation experiments

1. **Dynamic coverage TIA corpus** — highest expected local speed improvement given actual static-selector data.
2. **Pytest-xdist isolation benchmark** — only after detecting per-test shared files/ports/singletons; compare `-n 0`, `loadscope`, and `worksteal` on a sealed test run.
3. **Read-only code intelligence tournament** — current graph vs pinned tokensave vs structural AST approach.
4. **DBOS versus Restate adapter contract test** on disposable Postgres.
5. **Sandbox ladder certification** before forkd/Kata evaluation.
6. **Self-hosted inference trial only if a real GPU workload exists.**

## Explicitly rejected until evidence

```text
Generic semantic coding cache
Automatic provider fallback / tier switching
CRDT authority state
Blanket PD deployment
forkd primary production sandbox
PgBouncer pre-installation
Queue replacement without queue load evidence
Whole-codebase native transpilation
```

## Success criterion

An alternative is superior only when a sealed, repeated, equal-config comparison shows non-regression in deterministic correctness, protected-test integrity, safety/unknown outcomes, and a material measured improvement in the target metric. Vendor numbers and search results are hypotheses, not deployment evidence.
