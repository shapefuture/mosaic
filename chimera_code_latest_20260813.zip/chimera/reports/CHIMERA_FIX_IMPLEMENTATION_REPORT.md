# Chimera Fix Implementation Report

Implemented in `/home/user/chimera_analysis/extracted`.

## Completed fixes

1. **Sandbox materialize/cache fix** — `chimera/sandbox.py`
   - Added overlay-state hashing.
   - Added Bubblewrap bind-argv composition.
   - Added branch materialization cache for host-subprocess fallback.
   - Cached materializations are reused until overlay/deletion state changes.
   - Updated obsolete test expectation from ephemeral deletion to cache reuse.

2. **Tokenizer wiring fix** — `chimera/rlm.py`
   - Added `TokenizerMeasurer` to `RLMRuntime`.
   - Added `_count_tokens()` exact-first helper.
   - Replaced real-provider fallback token estimates in provider success paths.
   - Mock-only prompt echo accounting intentionally left unchanged.

3. **WAL batching** — `chimera/wal.py` plus Tier-2 call sites
   - Added `WALBatchScope` and `wal_write()`.
   - Repointed Tier-2 bookkeeping ledgers: routing, usage, capability calibration, regression ledger, mission, evolution hub, plan cache, latency attribution, provider capabilities.
   - Wrapped `_model_tool_loop` with a WAL batch scope.
   - Tier-1 durability sites were not repointed.

4. **Compaction cache-boundary fix** — `chimera/compaction.py`
   - Added `pointer_block`, `tail_block`, and `content_blocks()`.
   - Preserved the old flat `.text` result for compatibility.

5. **BranchReadCache LRU fix** — `chimera/branch_read_cache.py`
   - Replaced FIFO dict behavior with `OrderedDict` LRU.
   - Hits now call `move_to_end()`; eviction uses `popitem(last=False)`.

6. **Preflight graph load/build fix** — `chimera/preflight.py`
   - Exception path now tries `graph.load()` first and only builds on nested load failure.

7. **Verification / reward-hacking guard** — `chimera/gate_effectiveness.py`, `chimera/self_heal.py`, `chimera/orchestrator.py`
   - Added `record_dual_pass()` and `divergence_alert()`.
   - Added self-heal retry cap for identical failure signatures.
   - Orchestrator records grader pass with `held_out_pass=None` until held-out checks exist.

8. **Subagent condensation** — `chimera/subagents.py`
   - Added `_condense_result()`.
   - Parent message now includes condensed task-aware summary plus result path evidence pointer.

9. **Route pipeline composition** — `chimera/route_pipeline.py`
   - New additive module with `RouteDecision` and `decide_route()`.
   - Calls profiler → optimization qualifier → contextual capability registry → router → route advisor → cost governor.

10. **Lint-before-apply guard** — `chimera/rlm.py`
    - Added `_lint_before_apply()` syntax check.
    - Rejects invalid Python before workspace writes in file/edit/insertion patch paths.

11. **CostGovernor comment/default** — `chimera/cost_governor.py`
    - `account()` now defaults `source="measured"` and documents explicit estimate fallback.

## Test results

One-by-one targeted gates were run after each change. Final full suite:

```text
371 passed in 13.78s
```

## Deferred items

These remain intentionally deferred because the requested plan itself requires a mining/design step before safe implementation:

- Causal/belief memory delete-vs-wire decision.
- Full ACI redesign.
- Meta-critic recalibration using real dual-pass/downstream data.
- Compaction boundary-snapping.
- Speculative tool execution.
- Full `rlm.py` strangler-fig split.

# Deferred items resolved

See `CHIMERA_DEFERRED_RESOLUTION_REPORT.md`.

Final live test suite after resolving deferred items and archiving dead causal/belief frontier modules:

```text
360 passed in 14.50s
```
