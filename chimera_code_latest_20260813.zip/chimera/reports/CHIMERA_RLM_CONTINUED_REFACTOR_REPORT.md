# Chimera Continued `rlm.py` Refactor Report

## Backup status

The original pre-split file remains intact:

```text
chimera/rlm.py.backup_before_split
4991 lines / 292,992 bytes
```

## Continued extraction completed

I continued the refactor through the remaining requested candidate groups:

1. focused/cohesive coder methods
2. execution/action methods
3. DAG/orchestration methods including `_model_tool_loop`, `_solver_for_node`, and `rlm`

The approach remained conservative: extract methods into mixins, keep method names and behavior, test after each extraction.

## New chunks added in this pass

### `chimera/rlm_coder_methods.py`

Extracted focused/cohesive coding logic:

- `_coerce_target_response`
- `_strict_patch_call`
- `_target_prompt`
- `_deterministic_domain_scaffold`
- `_deterministic_adapter_payload`
- `_normalise_contract_values`
- `_focused_coder`
- `_cohesive_coder`

Size:

```text
1090 lines
```

Targeted tests:

```text
pytest tests/test_harness_improvements.py::test_focused_coder_generates_per_file_patch_and_runs_tests tests/test_harness_improvements.py tests/test_cognitect_adoptions.py tests/test_cohesive_transaction.py -q
37 passed
```

### `chimera/rlm_execution_methods.py`

Extracted action/tool execution logic:

- `_state_digest`
- `_workspace_view_precondition`
- `_action_precondition_observation`
- `_validate_thread_action_admission`
- `_execute_model_tool`
- `_literal_kernel_batch_calls`
- `_execute_kernel_call`
- `_bind_wire_evidence`
- `_execute_compiled_actions`

Size:

```text
671 lines
```

Targeted tests:

```text
pytest tests/test_tool_surface_protocol.py tests/test_kernel_batching.py tests/test_action_certificate.py tests/test_action_admission.py tests/test_execution_coverage.py tests/test_mcp_unknown_outcome.py -q
16 passed
```

### `chimera/rlm_orchestration_methods.py`

Extracted main loop and public orchestration logic:

- `_model_tool_loop`
- `_hybrid_observation_needed`
- `_run_hybrid_observation`
- `_integration_repair_contract`
- `_contract_for_atom`
- `_solver_for_node`
- `_finalize_run_evidence`
- `rlm`
- `spawn_subharness`
- `chained_rlm`
- `swarm`

Size:

```text
1347 lines
```

Targeted tests:

```text
pytest tests/test_agent_runtime_transfer.py tests/test_dag_admission.py tests/test_dag_dependency_barrier.py tests/test_hybrid_default.py tests/test_superiority_s1.py -q
17 passed
```

## Full current split

```text
chimera/rlm.py                         421 lines
chimera/rlm_primitives.py              292 lines
chimera/rlm_provider.py                559 lines
chimera/rlm_action_methods.py          221 lines
chimera/rlm_tool_methods.py            511 lines
chimera/rlm_coder_methods.py          1090 lines
chimera/rlm_execution_methods.py       671 lines
chimera/rlm_orchestration_methods.py  1347 lines
chimera/rlm.py.backup_before_split    4991 lines
```

`rlm.py` is now primarily imports, initialization, small local context helpers, and the `RLMRuntime` class shell. The heavy behavior is split into focused chunks.

## Runtime class after continued extraction

```python
class RLMRuntime(
    RLMProviderMixin,
    RLMActionMixin,
    RLMToolMixin,
    RLMCoderMixin,
    RLMExecutionMixin,
    RLMOrchestrationMixin,
):
    ...
```

## Issues caught and fixed during this pass

### 1. Missing imports in `rlm_coder_methods.py`

Caught by focused/cohesive tests. Added required imports.

### 2. Missing `Sandbox` / `os` / `re` in `rlm_action_methods.py`

Caught by command proof, ACI-only, and focused-coder tests. Fixed imports.

### 3. Missing `Mapping` and dangling method-boundary artifact in `rlm_tool_methods.py`

Caught by tool-surface/native-patch tests. Fixed the import and method boundary.

### 4. Missing `HarnessPreflight` and `ToolSurfaceError` in orchestration mixin

Caught by full regression and targeted orchestration tests. Fixed imports.

### 5. Missing `shlex` in execution mixin

Caught by read-only shell tool test. Fixed import.

## Final verification

```text
python3 -m compileall -q chimera tests
OK

pytest tests -q
388 passed in 16.61s

python3 -m chimera health | python3 -m json.tool
OK

ChimeraHarness mock run smoke
smoke True True True

pytest tests/test_resolve_rlm_facade_audit.py -q
1 passed
```

## Result

The requested continued refactor is complete.

`rlm.py` went from the original backup size:

```text
4991 lines
```

to:

```text
421 lines
```

That is a reduction of about 91.6% in the main file, while keeping full regression green.

## Recommended next cleanup

The mixin files are now coherent but some are still large, especially:

- `rlm_orchestration_methods.py` — 1347 lines
- `rlm_coder_methods.py` — 1090 lines

If you want to continue, split those into:

- `rlm_loop.py` for `_model_tool_loop`
- `rlm_dag_solver.py` for `_solver_for_node`, `_contract_for_atom`, integration repair
- `rlm_coder_focused.py` for focused coder
- `rlm_coder_cohesive.py` for cohesive coder

I stopped here because the requested candidates have been extracted and all tests pass.
