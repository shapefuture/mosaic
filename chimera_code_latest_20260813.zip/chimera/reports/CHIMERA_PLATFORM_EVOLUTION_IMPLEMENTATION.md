# Chimera Platform Evolution — Hexagonal Local-to-Cloud Implementation

**Date:** 2026-08-11  
**Validation:** `498 passed in 25.83s`, zero pytest warnings.  
**Production deployment claim:** none. The implementation adds local reference ports, opaque tenant boundaries, deployment truthfulness, and evidence-gated optimization seams.

## Implemented architecture

### 1. Deployment control plane

Added:

```text
chimera/platform.py
chimera platform doctor --profile LOCAL_DETERMINISTIC|DEV_EXTERNAL|SELF_HOSTED|CLOUD_MULTI_TENANT
```

`PlatformDoctor` only inspects local state. It emits one of:

```text
available
unavailable
configured-unverified
certified
```

It never opens a network connection, provisions cloud resources, or turns an environment variable into a certification. Current examples of deliberately non-certified states include Bubblewrap detection, KVM detection, Postgres URL configuration, self-hosted inference URL configuration, and cloud tenant attestation.

### 2. Opaque tenant workspace isolation

Added:

```text
chimera/tenancy.py
chimera tenant provision TENANT_ID --source SOURCE_ROOT
chimera tenant status TENANT_ID
```

A tenant identifier is hashed into an opaque key. The raw ID is not used as a directory name or stored in provision metadata. Provisioning copies a source snapshot into a tenant-specific workspace root:

```text
.chimera/tenants/<sha256>/workspace
```

This gives each tenant a distinct `.chimera` state tree, branch root, WAL, and artifact store once a runtime is instantiated in that workspace. It is deliberately an explicit provisioning operation, not a global mutable `tenant_id` field applied to one shared workspace.

`TenantQuotaLedger` adds bounded active-run admission/release receipts. It does not yet schedule the RLM automatically, because the scheduler must be tenant-context aware at every transport boundary before it can claim multi-tenant enforcement.

### 3. Hexagonal port boundary

Added:

```text
chimera/platform_ports.py
```

The initial local binding declares ports for:

```text
DurableWorkflowPort
CodeIntelligencePort
TenantDirectoryPort
IsolationPort
```

The local durable workflow, ImpactAnalyzer, opaque tenant resolver, and current Sandbox are reference adapters. External DBOS/Restate/Hatchet/forkd/SGLang/tokensave implementations remain unavailable/configured-unverified deployment adapters until their dedicated evidence gates pass.

No adapter receives branch commit, promotion, model-selection, or capability-broadening authority.

### 4. Dynamic impact evidence lane

Added:

```text
chimera/dynamic_impact.py
```

`DynamicImpactMap` is an externally collected test-to-source execution map. `DynamicImpactSelector` accepts a focused selection only if:

- test fingerprint matches;
- environment fingerprint matches;
- every unclaimed source drift is absent;
- every changed path maps to one or more executed tests;
- constitutional tests are included.

The map is intentionally advisory. Existing static `ImpactAnalyzer` and full-suite promotion remain default. The map is keyed by per-file hashes, allowing explicitly named changed source paths while refusing any unrelated source drift.

### 5. Shared-prefix hygiene

Added:

```text
chimera/prompt_prefix_contract.py
```

`PromptPrefixContract` hashes static prefix and volatile suffix separately. It lints timestamp-like values, agent/worker/tenant/session identity, and request IDs when they leak into the shared prefix. This is a deterministic prerequisite for provider/self-hosted cache experiments; it does not claim a provider cache hit.

## Parallel development rules

The new ports allow development of deployment adapters in parallel without source-of-truth conflicts:

```text
core authority lane: TaskContract, WAL/CAS, branches, tests, evidence gates
runtime lane: DBOS/Restate adapter experiments
queue lane: local/DBOS/Hatchet/PGMQ/PgQue measurements
isolation lane: Bubblewrap/Landlock/nsjail/gVisor/microVM test matrix
inference lane: hosted cache evidence or self-hosted SGLang/vLLM/Dynamo trial
code intelligence lane: current graph vs pinned read-only alternatives
```

No lane may merge an adapter into authority without its own held-out data and the existing promotion/evidence gates.

## Test evidence

New file:

```text
tests/test_platform_evolution.py
```

It verifies:

1. platform doctor never certifies a local configuration;
2. tenant roots are opaque and source snapshots are isolated;
3. tenant active-run quotas reject excess admission;
4. dynamic impact selection accepts only current, path-accounted maps and falls back on unclaimed drift;
5. volatile prompt material is rejected from static cache prefix;
6. platform and tenant CLI surfaces function without external deployment.

## Deferred, evidence-gated follow-up

```text
Dynamic coverage collector and 30+ mutation corpus
pytest-xdist isolation benchmark
Pinned read-only code intelligence benchmark
DBOS vs Restate disposable Postgres adapter spike
Bubblewrap/Landlock/nsjail escape matrix
KVM microVM comparison if target host supports it
Hosted exact-route campaign through one-shot descriptor
Self-hosted inference trial only with a real GPU workload
```

No local test proves cloud multi-tenancy, real isolation, queue capacity, provider cancellation, or self-hosted GPU performance. Those remain explicit deployment drills.
