# Authorized TokenRouter canary and cloud-runtime smoke — 2026-08-11

## User authorization and secret handling

The user explicitly authorized quota-consuming provider tests and provided a TokenRouter key for Kimi K3.

Handling policy followed:

- key used only as a transient process environment variable;
- no key was written to source, tests, docs, reports, or artifacts;
- artifacts record env-var names and capability receipts only;
- raw key grep over checked workspace files returned no match.

Verified:

```text
raw key not persisted in checked workspace files
```

## Direct TokenRouter/Kimi streaming probe

Ran a direct transient streaming probe against:

```text
https://api.tokenrouter.com/v1/chat/completions
model: moonshotai/kimi-k3-free
```

Observed:

```json
{
  "status_code": 200,
  "elapsed_ms": 4711.3,
  "chars": 34,
  "content": "I’m part of the Kimi model family.",
  "usage_seen": true,
  "error": null
}
```

This proves the supplied key was valid for the TokenRouter/Kimi route at test time.

## Chimera provider canary

Ran:

```bash
python -m chimera.cli provider-canary tokenrouter/moonshotai/kimi-k3-free \
  --capability strict_json \
  --authorize-live-call
```

Observed:

```json
{
  "provider": "tokenrouter",
  "model": "tokenrouter/moonshotai/kimi-k3-free",
  "capabilities": {
    "strict_json": true,
    "native_tools": false,
    "streaming": false,
    "prompt_cache": false,
    "sticky_session": false,
    "response_chain": false
  },
  "promoted": ["strict_json"]
}
```

Evidence reference produced:

```text
artifact:sha256:c0e2a38e2c0dad87739ed936e0e2018a6a9c6c871ee518c3fe2a5ccfc48f1bb5
```

Only artifact-backed `strict_json` was promoted for the exact route/model.

## Provider live canary campaign

Reran:

```bash
python evals/deployment/provider_live_canary_campaign.py \
  --authorize-live-call \
  --results artifacts/provider_live_canary_campaign_2026-08-11.json
```

Observed:

```json
{
  "schema_version": "chimera.provider-live-canary-campaign.v1",
  "authorized_by_user": true,
  "raw_keys_recorded": false,
  "configured_env_names": ["TOKENROUTER_API_KEY"],
  "live_calls_attempted": 1,
  "any_live_capability_proved": true,
  "all_configured_routes_passed": true,
  "all_passed": true
}
```

Provider report now shows TokenRouter configured and strict JSON proved:

```json
{
  "provider": "tokenrouter",
  "configured": true,
  "env_names": ["TOKENROUTER_API_KEY"],
  "proved": {
    "native_tools": false,
    "streaming": false,
    "strict_json": true,
    "prompt_cache": false,
    "sticky_session": false,
    "response_chain": false
  },
  "canary_proofs": 2
}
```

## Cloud-runtime smoke campaign

Added:

```text
evals/deployment/cloud_runtime_smoke_campaign.py
```

Generated:

```text
artifacts/cloud_runtime_smoke_campaign_2026-08-11.json
```

The campaign starts disposable local endpoints that behave like a self-hosted cloud deployment wiring layer:

- transient PostgreSQL 17.10 endpoint;
- pinned local Restate 1.7.3 endpoint;
- sets only transient env vars:
  - `CHIMERA_POSTGRES_URL`
  - `CHIMERA_RESTATE_INGRESS`
- runs `chimera doctor --profile cloud-runtime --fail-on-blockers --json`;
- performs minimal PostgreSQL cloud-state event/outbox I/O;
- records only env-var names, not endpoint values.

Observed:

```json
{
  "schema_version": "chimera.cloud-runtime-smoke-campaign.v1",
  "all_passed": true,
  "doctor_certified": true,
  "doctor_blockers": [],
  "postgres_event_replayed": true,
  "postgres_outbox_claimed": true,
  "restate_ingress_configured": true,
  "endpoint_values_recorded": false,
  "cloud_runtime_env_names": [
    "CHIMERA_POSTGRES_URL",
    "CHIMERA_RESTATE_INGRESS"
  ],
  "local_option_preserved": true
}
```

This proves cloud-runtime wiring and doctor gating with endpoint env vars. Honest limit: these were disposable local endpoints, not managed-cloud multi-host evidence.

Added:

```text
tests/test_cloud_runtime_smoke_evidence.py
```

## CI update

Updated:

```text
.github/workflows/chimera-ci-matrix.yml
```

The local certification bundle job now also runs:

```bash
python evals/deployment/cloud_runtime_smoke_campaign.py \
  --results artifacts/cloud_runtime_smoke_campaign_2026-08-11.json
```

Workflow YAML parses successfully.

## Validation

Targeted validation:

```bash
pytest tests/test_cloud_runtime_smoke_evidence.py \
  tests/test_cloud_native_profile.py \
  tests/test_provider_live_canary_campaign.py \
  tests/test_rust_graph_broad_retrieval_evidence.py \
  tests/test_rust_graph_runtime_fallback_evidence.py -q
```

Result:

```text
6 passed in 0.40s
```

Full suite:

```bash
pytest tests -q
```

Result:

```text
633 passed in 54.35s
```

## Current status

### Provider

- TokenRouter/Kimi direct route works.
- Chimera provider canary proved and promoted strict JSON for `tokenrouter/moonshotai/kimi-k3-free`.
- No raw key persisted.

### Cloud runtime

- Local option preserved.
- Cloud-priority/selfhosted profile exists.
- `cloud-runtime` gate can pass when endpoint env vars are supplied.
- Transient cloud-runtime smoke proves the wiring using disposable PostgreSQL/Restate endpoints.

### Rust graph

Still mirror-only despite major progress:

```text
mirror_only = true
production_replacement_authorized = false
```

## Honest remaining limitations

- Cloud-runtime smoke used disposable local endpoints, not managed-cloud multi-host infrastructure.
- Provider strict JSON is proved for TokenRouter/Kimi, but native tools/streaming/prompt-cache/sticky sessions are not proved for that route.
- Provider billing-stop proof still requires authoritative provider receipts.
- `/dev/kvm` remains absent, so microVM/KVM evidence is unavailable.
- Rust graph still lacks cross-platform and hidden real-corpus evidence for production replacement.
