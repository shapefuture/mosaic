# Bubblewrap enablement and next split implementation — 2026-08-11

## Bubblewrap workaround attempted

Initial state in this sandbox:

```bash
which bwrap
```

returned no path, so `chimera doctor --profile sandbox-linux` correctly blocked on the Bubblewrap lane.

Because the user asked to consider workarounds, I checked package-manager access:

```text
user is in sudo group
apt-get is available
```

Installed Bubblewrap with noninteractive sudo apt:

```bash
sudo -n apt-get update
sudo -n apt-get install -y bubblewrap
bwrap --version
```

Observed:

```text
bubblewrap 0.11.0
```

## Bubblewrap certification run

Ran the local host campaign:

```bash
python evals/deployment/bubblewrap_campaign.py \
  --results artifacts/bubblewrap_campaign_2026-08-11.json
```

Observed evidence:

```json
{
  "schema_version": "chimera.bubblewrap-campaign.v1",
  "bubblewrap_version": "bubblewrap 0.11.0",
  "all_passed": true,
  "automatic_enablement": false,
  "manual_promotion_required": true,
  "host": {
    "system": "Linux",
    "machine": "x86_64",
    "kernel": "6.1.158+"
  }
}
```

Materialized mode passed:

```json
{
  "backend": "bubblewrap-materialized",
  "certified": true,
  "network_isolation": true,
  "process_group_killed": true,
  "timeout_status": 124
}
```

Overlay mode passed:

```json
{
  "backend": "bubblewrap-overlayfs",
  "certified": true,
  "changed_file_visible": true,
  "new_file_visible": true,
  "deletion_masked": true,
  "command_write_ephemeral": true,
  "host_base_unchanged": true,
  "network_isolation": true
}
```

Limits remain explicit:

- host-local Linux namespace evidence only;
- not VM/physical-host isolation;
- does not certify Kata Containers, Firecracker, or rootless gVisor.

## Doctor after Bubblewrap install

Ran:

```bash
python -m chimera.cli doctor --profile sandbox-linux --json
python -m chimera.cli doctor --profile local --json
```

Observed:

```json
{
  "profile": "sandbox-linux",
  "certified": true,
  "blockers": [],
  "summary": {
    "ready": 6,
    "installed-not-certified": 1,
    "missing-dependency": 9,
    "configured-but-untested": 0,
    "manual-only": 2,
    "not-supported-on-host": 1
  }
}
```

Bubblewrap lane:

```json
{
  "name": "bubblewrap",
  "status": "ready",
  "detail": "bubblewrap binary exists and bounded host-local campaign evidence passed",
  "required_for": ["sandbox-linux"],
  "evidence": {
    "binary": "/usr/bin/bwrap",
    "campaign_all_passed": true,
    "host_system": "Linux"
  }
}
```

Local profile still blocks on `pyright-lsp` in this sandbox:

```json
{
  "profile": "local",
  "certified": false,
  "blockers": ["pyright-lsp"]
}
```

## Doctor bug fixed

After installing Bubblewrap, a legacy platform test exposed a compatibility bug:

```text
assert by_name["bubblewrap-materialized"].state == "certified"
E AssertionError: assert 'configured-unverified' == 'certified'
```

Root cause: the new `capability_matrix()` checked workspace-level campaign artifacts but did not also honor the old per-workspace `.chimera/sandbox-materialized-bwrap-certification.json` receipt loaded by `MaterializedBubblewrapCertifier(self.root).load()`.

Fix in `chimera/platform.py`:

- `_bubblewrap_lane()` now checks both:
  - current root's materialized Bubblewrap receipt;
  - saved campaign artifacts such as `artifacts/bubblewrap_campaign_2026-08-11.json`.
- Legacy `PlatformDoctor.inspect()` still maps the Bubblewrap lane name back to `bubblewrap-materialized` for old tests/callers.

## CLI split continued

Moved more command groups out of `chimera/cli.py` while preserving the public `chimera.cli:main` entry point:

New modules from this pass:

- `chimera/cli_mcp.py`
- `chimera/cli_rpc.py`
- `chimera/cli_tenant.py`

Previously added modules still present:

- `chimera/cli_doctor.py`
- `chimera/cli_graph.py`
- `chimera/cli_wire.py`
- `chimera/cli_platform.py`
- `chimera/cli_mapping.py`
- `chimera/cli_release.py`

Current CLI line counts:

```text
891 chimera/cli.py
175 chimera/cli_mcp.py
145 chimera/cli_tenant.py
135 chimera/cli_graph.py
 96 chimera/cli_mapping.py
 63 chimera/cli_doctor.py
 61 chimera/cli_release.py
 60 chimera/cli_wire.py
 51 chimera/cli_rpc.py
 51 chimera/cli_platform.py
```

## `rlm_coder_focused.py` split started

Moved focused-coder methods into focused mixin modules:

- `chimera/focused_generation.py`
  - `_coerce_target_response()`
  - `_strict_patch_call()`
- `chimera/focused_prompt.py`
  - `_target_prompt()`
- `chimera/focused_capsules.py`
  - `_deterministic_domain_scaffold()`
  - `_deterministic_adapter_payload()`
  - `_normalise_contract_values()`

`chimera/rlm_coder_focused.py` now keeps the core `_focused_coder()` transaction/repair loop and inherits the focused mixins.

Current RLM-focused line counts:

```text
573 chimera/rlm_coder_focused.py
141 chimera/focused_generation.py
137 chimera/focused_capsules.py
136 chimera/focused_prompt.py
```

This is still not the final split; `_focused_coder()` should be split next into repair loop / verification / quality admission helpers.

## Startup latency after additional split

20 subprocess runs of:

```bash
python -m chimera.cli --help
```

Observed:

```text
median_ms = 103.56
p95_ms    = 109.87
min_ms    = 100.59
max_ms    = 109.99
```

This improves over the previous split run (`median_ms=108.67`, `p95_ms=126.38`) but still has not recovered the earlier ~94 ms median claim.

## Validation

Targeted Bubblewrap and compatibility tests after install/fix:

```bash
pytest \
  tests/test_platform_evolution.py::test_materialized_bwrap_certification_when_binary_is_available \
  tests/test_sandbox_controlled_egress.py \
  tests/test_sandbox_overlay_certification.py \
  tests/test_bubblewrap_evidence.py \
  tests/test_doctor_capability_matrix.py -q
```

Result:

```text
7 passed in 2.31s
```

Targeted CLI/MCP/RPC/tenant compatibility tests:

```bash
pytest tests/test_platform_evolution.py tests/test_mcp_remote.py tests/test_application_architecture.py tests/test_doctor_capability_matrix.py -q
```

Result:

```text
37 passed in 2.02s
```

Targeted focused-coder/RLM split tests:

```bash
pytest tests/test_harness_improvements.py tests/test_focused_native_patch.py tests/test_multi_candidate_patch.py tests/test_capsule.py tests/test_prompt_cache.py -q
```

Result:

```text
34 passed in 6.96s
```

Full suite:

```bash
pytest tests -q
```

Result:

```text
602 passed, 10 skipped in 32.73s
```

The three Bubblewrap-related skips disappeared after installing `bubblewrap`.

Remaining skips are still external optional integrations:

- DBOS/PostgreSQL optional integration dependencies unavailable
- pinned runsc/static busybox unavailable
- Restate integration endpoint not configured
- Rust toolchain unavailable
- SCIP TypeScript toolchain unavailable
- PostgreSQL/DBOS unavailable
- Restate endpoint unavailable

## Next moves

1. Finish CLI split:
   - `cli_run.py`
   - `cli_eval.py`
   - `cli_admin.py`
   - goal/agent/harness/skills/optimize groups into focused modules.
2. Finish focused-coder split:
   - move `_focused_coder()` phases into repair-loop / verification / quality helpers.
3. Install Pyright or provide a pinned Node toolchain workaround, then re-run:
   - `chimera doctor --profile local --fail-on-blockers`
4. Optionally install Rust/SCIP/Restate/Postgres deps and convert further skips into live evidence.
