# Chimera 5-Stage Roadmap Implementation Report

## Request

Implement the 5-stage roadmap from the first-principles review:

1. quality hardening,
2. latency breakthrough,
3. hidden-test superiority,
4. candidate-pool intelligence,
5. provider-native context systems.

## Final verification

```text
python3 -m compileall -q chimera tests evals/harness_regression/strict_stress.py evals/harness_regression/stream_dispatch_benchmark.py
OK

pytest tests -q
426 passed in 15.69s
```

---

# Stage 1 — Quality hardening

## 1. CompletionGate blocks final commit/approval

Files changed:

```text
chimera/orchestrator.py
```

Behavior:

- `CompletionGate` is already attached in `_finalize_run_evidence`.
- Final auto-commit gate now requires:

```text
completion_gate.allowed == True
```

This means a model cannot claim a verified implementation/artifact/service without matching evidence and still pass the final commit path.

## 2. Provider QoS ledger

New file:

```text
chimera/provider_qos.py
```

Wired into:

```text
chimera/rlm.py
chimera/rlm_provider.py
```

Records:

- provider,
- model,
- latency ms,
- tokens,
- success/failure,
- error class.

Profiles expose:

- samples,
- p50,
- p95,
- average tokens,
- error count,
- QoS score.

This is the foundation for live QoS-based routing and dynamic hedge thresholds.

## 3. Strict stress eval gates

New file:

```text
chimera/eval_gates.py
```

Adds:

```python
StrictStressGate
```

Checks:

- minimum pass rate,
- max median wall time,
- max median tokens.

This converts stress evals from ad-hoc reports into CI-style pass/fail gates.

## 4. High-risk tasks default to ACI-only

File changed:

```text
chimera/rlm_action_methods.py
```

Behavior:

- raw file payloads are rejected for high-risk tasks unless `aci_approved`.
- High-risk keywords include:
  - auth,
  - security,
  - credential,
  - payment,
  - permission,
  - delete,
  - migration.

Controls:

```bash
CHIMERA_AUTO_ACI_HIGH_RISK=1  # default
CHIMERA_ACI_ONLY=1            # force globally
```

---

# Stage 2 — Latency breakthrough

## 1. DeltaFS/reflink backend probe

New file:

```text
chimera/deltafs_backend.py
```

Adds:

```python
DeltaFSProbe(root).probe()
```

Reports:

- overlayfs availability,
- reflink capability,
- bubblewrap availability,
- whether DeltaFS-style backend is a candidate.

This does not claim a full DeltaBox implementation in this sandbox; it provides the required host capability probe and decision surface for a real fast C/R backend.

## 2. Stream dispatch metrics

Already implemented earlier, retained:

```text
chimera/stream_tools.py
evals/harness_regression/stream_dispatch_benchmark.py
```

Stream-time dispatch remains enabled for read-only tools.

## 3. Dynamic hedge threshold foundation

Files:

```text
chimera/provider_qos.py
chimera/rlm_provider.py
```

Provider QoS data now exists. Certified hedge already supports:

```bash
CHIMERA_CERTIFIED_ROUTE=1
CHIMERA_HEDGE_MODEL=gemini-3.5-flash-lite
CHIMERA_PRIMARY_BUDGET_SECS=0.8
CHIMERA_MIN_PRIMARY_BUDGET_SECS=0.25
```

Next adaptive step is to use QoS p95 to set `CHIMERA_PRIMARY_BUDGET_SECS` automatically. The ledger now collects the data needed.

---

# Stage 3 — Hidden-test superiority

## 1. Tester-agent hidden tests

New file:

```text
chimera/tester_agent.py
```

Adds:

```python
TesterAgent.generate(task, target_path)
GeneratedTestLedger.seal(path)
GeneratedTestLedger.verify(path, seal)
```

Current deterministic seed tester can generate extra adversarial tests for known high-risk patterns like:

- `sanitize`,
- `parse_duration`.

## 2. Immutable signed/generated-test sealing

Also in:

```text
chimera/tester_agent.py
```

Generated tests are sealed with SHA-256 and recorded in WAL. If a test changes, verification fails.

## 3. Reward-hacking penalty

Already implemented earlier in:

```text
chimera/quality_rubric.py
```

Integrity violations that modify tests/support verification files receive negative scoring.

---

# Stage 4 — Candidate-pool intelligence

## 1. PatchFusion edit-atom fusion

New file:

```text
chimera/patch_fusion.py
```

Adds:

```python
fuse_patch_pool(payloads, min_support=2)
```

Behavior:

1. First attempts AST-canonical whole-patch consensus.
2. If no whole-patch quorum, fuses repeated file-level edit atoms per path.
3. Returns a conservative fused patch only when repeated support exists.

## 2. Multi-candidate path now uses PatchFusion

File changed:

```text
chimera/rlm_coder_focused.py
```

When multi-candidate generation is enabled:

```bash
CHIMERA_MULTI_CANDIDATE_PATCHES=3
```

Chimera now tries:

1. PatchFusion,
2. AST consensus,
3. normal single-candidate fallback.

---

# Stage 5 — Provider-native context systems

## 1. Native compaction canary decision surface

Already present and retained:

```text
chimera/native_compaction.py
```

Adds:

```python
NativeCompactionCanary().run(provider, model)
ab_recall_test(local_text, compacted_text, required_terms)
```

Current decision remains:

```text
local_compaction_fallback
```

until provider-native compaction is canary-proved and A/B recall is not worse than local compaction.

---

# Tests added

New test file:

```text
tests/test_roadmap_stages.py
```

Covers:

- ProviderQoSLedger profiles latency/errors,
- DeltaFSProbe returns capability shape,
- StrictStressGate thresholds,
- TesterAgent hidden test generation and sealing,
- PatchFusion repeated file-atom fusion,
- automatic high-risk ACI-only rejection.

Updated:

```text
tests/test_multi_candidate_patch.py
```

Now accepts PatchFusion or AST consensus metadata.

## Validation

```text
pytest tests/test_roadmap_stages.py -q
6 passed

pytest tests/test_multi_candidate_patch.py tests/test_roadmap_stages.py -q
7 passed

pytest tests -q
426 passed in 15.69s
```

---

# Current defaults / workarounds

## Fast reliable production path

```bash
CHIMERA_CERTIFIED_ROUTE=1
CHIMERA_HEDGE_MODEL=gemini-3.5-flash-lite
CHIMERA_PRIMARY_BUDGET_SECS=0.8
CHIMERA_MIN_PRIMARY_BUDGET_SECS=0.25
CHIMERA_REASONING_EFFORT=low
```

## Hard hidden-test repair

```bash
CHIMERA_MAX_REPAIR_ROUNDS=3
```

## Measure generalized repair without scaffolds

```bash
CHIMERA_DISABLE_DOMAIN_SCAFFOLDS=1
```

## High-reliability candidate pool

```bash
CHIMERA_MULTI_CANDIDATE_PATCHES=3
CHIMERA_MULTI_CANDIDATE_TOKEN_BUDGET=6000
CHIMERA_MULTI_CANDIDATE_MIN_VOTES=2
```

Use only after first failure or on high-risk tasks.

---

# Remaining true future work

The roadmap is implemented in bounded form, but two items remain OS/provider dependent:

1. **Full DeltaFS runtime backend**
   - requires host overlayfs/bwrap/reflink support.
   - Probe exists; backend implementation should be enabled only on capable hosts.

2. **Provider-native compaction**
   - requires OpenAI/Anthropic-style provider support and canary proof.
   - Decision surface and recall test exist; default remains local fallback.

## Final status

```text
426 passed in 15.69s
```
