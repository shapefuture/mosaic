# Chimera Remaining High-Impact Items Implementation Report

## Request

From the remaining Kestrel-derived items, implement the ones most likely to improve:

- output quality,
- reliability,
- token efficiency,
- speed / latency,
- and reduce overbuilding via workarounds/toggles.

## Implemented

### 1. Optional KIRA-style double-confirmation completion

New file:

```text
chimera/double_confirm.py
```

Wired into:

```text
chimera/rlm_dag_solver.py::_finalize_run_evidence
```

Behavior:

- Costs one extra model call only when useful.
- Runs when:
  - `CHIMERA_DOUBLE_CONFIRM=1`, or
  - `CompletionGate` rejects/flags a claim, or
  - task is high-risk by keyword.
- Uses a constrained JSON verifier prompt:

```json
{"passed": true|false, "reason": "..."}
```

Workarounds/settings:

```bash
CHIMERA_DOUBLE_CONFIRM=1                 # force
CHIMERA_DOUBLE_CONFIRM_MODEL=...         # optional verifier model
```

This improves reliability/output quality on high-risk or suspect completions, while avoiding default latency/token cost on normal runs.

### 2. Native compaction capability gate / local fallback

New file:

```text
chimera/native_compaction.py
```

Behavior:

- Makes the provider-native compaction decision explicit.
- Current certified providers are treated as **not canary-proved** for native compaction.
- Action is therefore:

```text
local_compaction_fallback
```

This avoids pretending native compaction exists and provides a clean future hook when an endpoint-level canary proves it.

### 3. AST-canonicalized patch consensus

New file:

```text
chimera/patch_consensus.py
```

Capabilities:

- canonicalizes Python candidate patches with `ast.dump(..., include_attributes=False)`,
- treats whitespace-equivalent Python as the same candidate,
- selects majority candidate when quorum is reached,
- abstains when no candidate reaches quorum,
- supports `never_abstain=True` only when caller explicitly wants forced selection.

This improves future multi-candidate output quality and reliability without turning it on by default or adding latency today.

### 4. CompletionGate classification fix

During testing, `CompletionGate` classified `service.py` patch answers as a `service` claim because the filename contains `service`. That caused an unnecessary double-confirmation call in cohesive transaction tests.

Fix:

- If a diff exists, classify as `artifact` before service/liveness claim.

This preserves reliability while avoiding unnecessary extra model calls.

## Tests added

New file:

```text
tests/test_remaining_future_mechanisms.py
```

Covers:

- double-confirm forced JSON verifier path,
- double-confirm on completion-gate rejection,
- native compaction downgrading to local fallback,
- AST-canonical consensus selecting whitespace-equivalent Python patches,
- AST consensus abstention without quorum.

Existing Kestrel mechanism tests still pass.

## Validation

```text
pytest tests/test_remaining_future_mechanisms.py tests/test_kestrel_mechanisms.py -q
12 passed

pytest tests/test_cohesive_transaction.py::test_cohesive_two_file_transaction_uses_one_checked_patch_and_full_integration tests/test_remaining_future_mechanisms.py tests/test_kestrel_mechanisms.py -q
13 passed

python3 -m compileall -q chimera tests
OK

pytest tests -q
410 passed in 16.14s
```

## Why these remaining items were implemented

### Double-confirmation

Improves reliability/output quality for high-risk or suspect completion claims. Not always on, because always-on would hurt latency and token efficiency.

### Native compaction gate

Improves reliability by avoiding false assumptions. It is a clean future hook for provider-native compaction without overbuilding.

### AST consensus

Improves future multi-candidate reliability/output quality while costing nothing in current single-candidate flow.

## Remaining future-only items not turned on by default

- Always-on KIRA double-confirm: rejected due latency/token cost.
- Native provider compaction: not enabled until canary-proved.
- Multi-candidate generation: not enabled yet; AST consensus is ready when that path exists.
- Full Kestrel kernel rewrite: still rejected as overbroad for Chimera’s current architecture.

## Final status

```text
410 passed in 16.14s
```
