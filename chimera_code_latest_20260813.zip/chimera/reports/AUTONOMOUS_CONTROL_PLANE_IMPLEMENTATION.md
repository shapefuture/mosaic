# Bounded Autonomous Control Plane — Implementation Record

**Date:** 2026-08-11  
**Scope:** implementation of the four explicitly requested local control-plane mechanisms.  No live model/provider call, external HTTP call, background daemon, artifact download, or binary execution was used.

This is an autonomy-safety and continuity increment. It does **not** establish general autonomous-agent superiority.

## 1. Durable schedule runner forced through managed background execution

### Implemented

- `chimera/autonomy_scheduler.py`
  - `GoalScheduleRunner`
  - `ScheduledDispatchReceipt`
- `chimera/long_running.py`
  - durable `ScheduleClaim`
  - process-locked, fsynced schedule projection
  - durable `claim_due()` and `complete_schedule_claim()`

Every scheduler dispatch uses exactly:

```python
controller.run_background_managed(goal.id, managed_step_port)
```

There is no foreground `controller.run()` or cooperative callback fallback. Thus each scheduled step reaches the exact-subject lease and host-admission checks while a locally managed process group is running.

### Crash/restart behavior

Before a callback becomes reachable, the scheduler writes a claim containing a unique id and expiry. If a process dies after claim and before completion, the next runner does **not** replay the callback. Once the claim is expired it is recorded as `unknown` and disabled. An operator must make a deliberate recovery/re-scheduling decision.

This is intentionally conservative: without an idempotency/effect proof, “probably did not run” is not safe evidence for automatic replay.

### Concurrency behavior

Schedule file operations use a thread lock and POSIX advisory file lock where available. Only an unclaimed, ready item can be claimed. Completion requires the exact claim id. A runner/controller root mismatch is rejected at construction.

### Managed cancellation boundary

The scheduler now terminates managed local subprocess process groups on lease revocation, host-admission loss, and local deadline, and records whether leader exit plus group absence were confirmed. It still does not claim remote provider cancellation/billing cancellation, reversal of an already-issued external effect, termination of a child that deliberately escaped its original group, or microVM/container isolation.

## 2. Opt-in host admission probe

### Implemented

- `chimera/host_admission.py`
  - `HostAdmissionSample`
  - `HostAdmissionPolicy`
  - `HostAdmissionGate`
  - `HostAdmissionDecision`
- `AutonomousController(..., host_admission=...)` integration

No host probe is created automatically. A caller must supply both a probe and an explicitly enabled policy:

```python
policy = HostAdmissionPolicy.strict_opt_in()
gate = HostAdmissionGate(my_probe, policy)
controller = AutonomousController(store, leases, host_admission=gate)
```

The strict opt-in profile requires fresh evidence of:

- a quiet/present-but-idle host;
- external power;
- battery at or above 50%; and
- resource headroom at or above 25%.

The thresholds are configurable. Probe exceptions, stale samples, unknown values, clock-invalid samples, active user presence, missing external power, and low/missing resource headroom all deny/yield. They never permit background dispatch.

No claim is made that Chimera currently detects real presence, battery, GPU, thermal, or CPU state. It supplies the testable policy boundary; an OS-specific probe remains an explicit future adapter.

## 3. Local hash-addressed artifact recovery

### Implemented

- `chimera/local_artifact_recovery.py`
  - `LocalArtifactRecovery`
  - `LocalArtifactRecoveryAuthorization`
  - `LocalArtifactRecoveryReceipt`

Recovery operates only between two local `ContentAddressedArtifactStore` instances. The API accepts no URL, network transport, shell command, glob, or directory scan.

Before a recovery read, an owner must issue an authorization bound to:

- one exact SHA-256 artifact digest;
- one exact local source-store root hash;
- a positive byte ceiling;
- TTL;
- hashed operator label and explicit evidence reference.

The authorization is anchored in Chimera’s hash-chained WAL. Recovery verifies WAL integrity/anchor, authorization expiry, source-root match, file size before reading, byte count after reading, and final content digest. The target CAS must return exactly the requested digest.

If a source artifact exceeds the cap, has a different digest, is absent/corrupt, is from a different store, or has expired/tampered authorization, the target remains unchanged. There is no automatic retry or network fallback.

## 4. Advisory operational hysteresis telemetry

### Implemented

- `chimera/operational_hysteresis.py`
  - `OperationalHysteresisPolicy`
  - `OperationalHysteresis`
  - `OperationalHysteresisLedger`
  - `OperationalHysteresisReceipt`

The telemetry accepts paired nonnegative operational measurements within an explicit `evaluation_frame`. It uses bounded windows, fresh-sample expiry, P95/P99 comparisons, promotion/demotion hysteresis, dwell windows, and cooldowns.

Its output has two intentional, mechanical declarations:

```text
advisory_only = true
promotion_authority = false
```

It cannot call `PromotionEvaluator`, change routes, alter model selection, accept candidates, modify policies, or bypass oracle/protected-test/sealed-evaluation requirements. Changing `evaluation_frame` resets state to `cold`; results are not compared across frames.

## Safety properties deliberately retained

- No background feature is enabled by default.
- Explicit concrete model choice is unchanged.
- No generic model/provider auto-routing, hedging, self-authored skill/test promotion, network egress, cloud delivery, plugin execution, P2P, wallet, proxy, or service install was added.
- Autonomous work remains branch/verification/lease constrained; no broad approval was introduced.
- The old long-running shell gate remains replaced with constrained path/pytest verification gates.

## Tests

New test suite: `tests/test_autonomous_control_plane.py`.

It covers:

1. scheduler dispatch structurally reaches `run_background_managed()` and never foreground/cooperative execution;
2. a crash after durable claim becomes an `unknown` disabled schedule on restart and is not replayed;
3. a concurrent lease revocation terminates a managed local process group and permits no second dispatch;
4. a local deadline terminates an inherited-group child before its delayed side effect;
5. an enabled host-admission probe exception denies before callback dispatch;
6. strict host admission rejects active user presence and insufficient headroom, while a fresh compliant sample passes;
7. local artifact recovery succeeds only for an exact authorized local CAS object;
8. recovery rejects cap breach, expiry, and a tampered authorization;
9. telemetry promotes only advisory recommendation after dwell, cools down on regression, and frame-changes reset it.

Final validation:

```text
python -m compileall -q chimera tests
pytest -q
473 passed in 19.04s
0 pytest warnings
```

## Follow-up experiments / kill criteria

| Mechanism | Acceptance condition | Kill criterion |
|---|---|---|
| Schedule runner | no callback after an expired/crashed claim, denial, or revocation boundary; exact claim completion only | any automatic replay after unknown outcome or any foreground dispatch path |
| Host admission adapter | real platform adapter returns verifiable fresh samples; probe failure yields | a probe error/unknown observation ever permits discretionary work |
| Artifact recovery | exact digest and cap verification under concurrent source mutation/fault injection | any network fallback, unbounded read, or target mutation after invalid authorization |
| Hysteresis telemetry | stable advisory receipts across restart and fixed operational fixtures | any code path treats its recommendation as promotion/route/approval authority |

No automatic promotion follows from this implementation.
