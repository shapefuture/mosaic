# Chimera Deferred Items Resolution Report

Workspace: `/home/user/chimera_analysis/extracted`

This resolves the previously deferred items with bounded implementations and one-by-one test gates.

## 1. Causal/belief memory decision task — resolved by archiving

**Files moved to archive:**

- `archived_experimental/causal_belief_memory_20260810/chimera/causal_memory.py`
- `archived_experimental/causal_belief_memory_20260810/chimera/belief_memory.py`
- `archived_experimental/causal_belief_memory_20260810/tests/test_causal_memory_frontier.py`
- `archived_experimental/causal_belief_memory_20260810/tests/test_relational_memory_frontier.py`

**Live package changes:**

- Removed causal/belief memory imports and `__all__` exports from `chimera/__init__.py`.
- Added `CHIMERA_MEMORY_DECISION.json` with the mining result.

**Decision:** local runtime/failure corpus had no contradiction/differing-reliability signal requiring these modules on the hot path, and grep confirmed they were only exercised by isolated frontier tests. They are archived, not destroyed.

**Test gate:**

```text
pytest tests/test_memory_hygiene.py tests/test_context_memory.py -q
4 passed
```

## 2. ACI redesign — resolved with first live action-shaping layer

**New file:** `chimera/aci.py`

**RLM wiring:** `RLMRuntime` now has `self.aci`.

Implemented:

- Windowed file viewer with line numbers.
- Concise file search.
- Line-anchored edit command.
- Cheap lint-before-write for Python.
- Failure-shape miner for malformed patch, wrong-file, context-miss, and lint-failed patterns.

**Test gate:**

```text
pytest tests/test_aci.py tests/test_focused_native_patch.py -q
5 passed
```

## 3. Meta-critic recalibration — resolved with verification calibration bucket

**File:** `chimera/capability_calibration.py`

Added:

- `ContextualCapabilityRegistry.update_verification_calibration(...)`
- Uses `agent_id="verification_tier"` and `skill="verification_calibration"`.
- Records downstream accepted/rejected outcomes into the existing Bayesian posterior machinery.

**Test gate:**

```text
pytest tests/test_meta_critic_calibration.py tests/test_routing.py -q
3 passed
```

## 4. Compaction boundary snapping — resolved

**File:** `chimera/compaction.py`

Implemented:

- Boundary-aware cut-point selection before fallback to fixed tail.
- Markers include tool boundaries, markdown section boundaries, structured trace boundaries, and explicit Chimera subgoal markers.
- Manifest now records `cut_strategy` as `boundary-snap` or `fixed-tail`.
- Existing recoverability/hash guarantees preserved.

**Test gate:**

```text
pytest tests/test_compaction.py tests/test_prompt_cache.py -q
4 passed
```

## 5. Speculative tool execution — resolved with gated one-step executor

**New file:** `chimera/speculative_tools.py`

**RLM wiring:** `RLMRuntime` now has `self.speculative_tools`.

Implemented:

- Mines stable `tool_trace` transitions.
- Predicts only one step ahead.
- Executes only via a caller-supplied executor.
- Disables speculation when `gate_dual_pass` telemetry shows grader/held-out divergence above the Goodhart threshold.

**Test gate:**

```text
pytest tests/test_speculative_tools.py -q
2 passed
```

## 6. `rlm.py` strangler-fig split — resolved as first extracted facade boundary

**New files:**

- `chimera/action_executor.py`
- `chimera/provider_client.py`
- `chimera/prompt_assembler.py`
- `chimera/tool_protocol.py`

**RLM wiring:**

- `self.action_executor`
- `self.provider_client`
- `self.prompt_assembler`
- `self.tool_protocol`

This establishes the stable extracted boundaries without rewriting the whole runtime in one risky patch. The existing runtime methods remain compatibility implementations behind the facades.

**Test gate:**

```text
pytest tests/test_rlm_split_facades.py tests/test_focused_native_patch.py -q
5 passed
```

## Final full regression

Because the dead causal/belief frontier modules and their isolated tests were archived out of the live package, the total test count is lower than before. The live package test suite passes:

```text
pytest tests -q
360 passed in 14.50s
```

## Net new tests added

- `tests/test_aci.py`
- `tests/test_meta_critic_calibration.py`
- `tests/test_speculative_tools.py`
- `tests/test_rlm_split_facades.py`

## Summary

All deferred items are now resolved in the live package:

- Dead causal/belief memory removed from hot-path/public API and archived.
- ACI layer exists and is wired.
- Meta-critic calibration is routed through existing posterior machinery.
- Compaction now snaps at task/tool boundaries.
- Speculative tool execution exists, but is conservative and gate-pressure-aware.
- `rlm.py` now has extracted facade boundaries for action execution, providers, prompts, and tool protocol.
