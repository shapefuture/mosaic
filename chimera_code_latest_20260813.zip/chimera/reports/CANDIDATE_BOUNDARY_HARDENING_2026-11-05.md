# Candidate boundary hardening

## Implemented
- Promotion evaluation no longer discovers candidate-local waiver files automatically.
- Explicit policy paths inside the candidate tree are rejected.
- Candidate waivers require signatures; supplied trust registries are enforced.
- Commands are not executed without evaluation authorization, with unresolved scan findings, or with invalid candidate snapshots.
- Before/after source-tree SHA256 fingerprints detect persistent source mutations during evaluation; symlinks fail snapshot admission. Runtime metadata/cache directories are excluded.
- Test subprocesses receive a small environment allowlist rather than inherited provider keys, signing secrets and existing PYTHONPATH.
- Local test success is now `evaluation_passed`; `promotion_allowed` remains false because local subprocess execution is not a security-isolated evaluator.
- Campaign selection and the composed smoke gate consume evaluation success, not release authority.

## Evidence
Focused integration: 13 passed in 17.44s.
Full suite: 758 passed, 13 skipped in 49.42s.

## Important limitations
Source hashes detect persistent changes, not transient modification-and-restoration. This is not a read-only snapshot or TOCTOU defense. Public source contains the demo test bank; tests are still materialized under candidate metadata. This is not hidden-oracle isolation. A subprocess sharing host privileges is not safe for hostile code. No actual repository promotion is performed.

Next: separate evaluator-owned oracle from candidate runtime, immutable snapshot/CAS identity, externally pinned trust policy, process-group deadlines and bounded output, then real adapter/deployment tests.
