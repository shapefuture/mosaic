# Chimera Live Measurement Completion Report

## What was measured

This pass completed the live/evidence-gathering work for the items that were previously deferred pending measured benefit:

1. provider-native compaction recall/cost,
2. multi-candidate success lift vs token cost,
3. scaffold-free generalized repair pass rate,
4. stream-time dispatch latency benefit with real streaming textual tool calls.

## 1. Provider-native compaction recall/cost

### Evidence gathered

I searched current provider-native compaction support and found:

- Anthropic/OpenAI-style native compaction/context-management exists in some APIs and LiteLLM supports pass-through/polyfill modes.
- The currently certified live Chimera stack — Cerebras, Gemini direct, TokenRouter — does **not** expose a canary-proved native compaction API in Chimera.

Current Chimera implementation:

```text
chimera/native_compaction.py
```

Decision remains:

```text
Use local_compaction_fallback until a provider-specific native compaction canary and A/B recall test pass.
```

Measurement hooks exist:

```python
NativeCompactionCanary().run(provider, model)
ab_recall_test(local_text, compacted_text, required_terms)
```

### Decision

Do **not** enable provider-native compaction by default yet.

Reason:

- no native compaction endpoint is canary-proved for the live certified providers,
- opaque provider compaction recall is unverifiable without A/B recall testing,
- local compaction remains safer.

## 2. Multi-candidate success lift vs token cost

### Live measurement

Raw file:

```text
CHIMERA_REMAINING_MEASURE_MULTI_CANDIDATE_STRICT_STRESS.json
```

Stress case:

```text
inventory_reconcile_hidden_edges
```

| Mode | Pass | Wall | Tokens |
|---|---:|---:|---:|
| single-candidate reference | yes | 1.094s | 862 |
| multi-candidate consensus | yes | 119.853s | 6906 |

### Decision

Do **not** enable multi-candidate generation by default.

Keep gated behind:

```bash
CHIMERA_MULTI_CANDIDATE_PATCHES=3
CHIMERA_MULTI_CANDIDATE_TOKEN_BUDGET=6000
CHIMERA_MULTI_CANDIDATE_MIN_VOTES=2
```

Use only when:

- previous single-candidate attempt failed,
- task is high-risk,
- token budget allows,
- latency is less important than reliability.

## 3. Scaffold-free generalized repair pass rate

### Live repeated measurement

Raw file:

```text
CHIMERA_SCAFFOLD_FREE_REPEATED_MEASUREMENT.json
```

Three live repetitions of strict stress with both scaffolded and scaffold-free modes.

| Mode | Pass rate | Median wall | Median tokens |
|---|---:|---:|---:|
| scaffolded Chimera | 3/3 = 1.00 | 1.452s | 949 |
| scaffold-free Chimera | 2/3 = 0.667 | 56.569s | 987 |

Individual repetitions:

| Rep | Scaffolded pass | Scaffold-free pass | Scaffolded wall | Scaffold-free wall |
|---:|---:|---:|---:|---:|
| 1 | yes | no | 2.036s | 57.425s |
| 2 | yes | yes | 1.452s | 56.569s |
| 3 | yes | yes | 1.173s | 1.774s |

### Decision

Do **not** globally disable deterministic scaffolds.

Keep:

```bash
CHIMERA_DISABLE_DOMAIN_SCAFFOLDS=1
```

as a measurement/eval mode, not production default.

Reason:

- scaffold-free can succeed,
- but current pass rate and latency are not yet superior,
- generalized repair should keep improving before scaffolds are removed.

## 4. Stream-time dispatch latency benefit with real streaming textual tool calls

### Real live streaming measurement

Raw file:

```text
CHIMERA_REAL_STREAM_TIME_TOOL_DISPATCH_CEREBRAS.json
```

Provider:

```text
cerebras/gpt-oss-120b
```

Prompt asked the model to emit a textual tool call block and then continue streaming.

Result:

```json
{
  "ok": true,
  "wall": 0.443,
  "tokens": 170,
  "stream_tool_events": [
    {
      "block": "{\"name\":\"read_file\",\"arguments\":{\"path\":\"a.txt\"}}",
      "dispatch": {"ok": true}
    }
  ],
  "dispatcher_event_time": 0.437
}
```

This proves the live provider can stream a textual tool call and Chimera extracts/dispatches it before the full response is complete.

### Synthetic latency benchmark

Raw file:

```text
CHIMERA_STREAM_DISPATCH_SYNTHETIC_BENCHMARK.json
```

Result:

```json
{
  "previous_seconds": 0.6929,
  "stream_time_seconds": 0.4429,
  "saved_seconds": 0.25,
  "tool_wall_hidden_ratio": 1.0
}
```

### Decision

Keep read-only stream-time dispatch enabled.

Reason:

- live provider proof works,
- synthetic latency measurement shows hidden tool wall-time,
- no speculation/misprediction cost,
- writes remain blocked.

## Final decision table

| Mechanism | Data gathered | Decision |
|---|---|---|
| Provider-native compaction | Search + canary scaffolding; no current certified-provider native support | Defer; local fallback |
| Multi-candidate consensus | Live strict stress: pass but 119.853s / 6906 tokens vs 1.094s / 862 | Keep opt-in only |
| Scaffold-free repair | 3 live reps: 2/3 pass, median 56.569s | Keep as measurement mode; not default |
| Stream-time dispatch | Live Cerebras textual stream event + synthetic latency benefit | Keep enabled for read-only dispatch |

## Tests / validation

```text
pytest tests/test_stream_time_dispatch.py tests/test_multi_candidate_patch.py tests/test_native_compaction_canary.py tests/test_pytest_repair.py -q
6 passed

python3 -m compileall -q chimera tests evals/harness_regression/strict_stress.py evals/harness_regression/stream_dispatch_benchmark.py
OK

pytest tests -q
420 passed in 16.00s
```

## Recommended next product defaults

### Production / fastest reliable mode

```bash
CHIMERA_CERTIFIED_ROUTE=1
CHIMERA_HEDGE_MODEL=gemini-3.5-flash-lite
CHIMERA_PRIMARY_BUDGET_SECS=0.8
CHIMERA_MIN_PRIMARY_BUDGET_SECS=0.25
CHIMERA_REASONING_EFFORT=low
```

### Keep enabled

- read-only stream-time dispatch,
- generalized pytest repair loop,
- local compaction fallback,
- deterministic scaffolds for known brittle classes.

### Keep opt-in

- multi-candidate consensus,
- scaffold-free mode,
- native provider compaction,
- always-on double-confirmation.
