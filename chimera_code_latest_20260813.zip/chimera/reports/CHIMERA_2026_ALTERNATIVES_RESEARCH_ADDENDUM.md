# Chimera 2026 Stack Alternatives — 64-Query Research Addendum

**Date:** 2026-08-11  
**Research method:** 64 targeted web queries, grouped across durable execution, queues, pooling, sandbox/isolation, egress, Wasm, inference serving, cache routing, code intelligence, test impact, and Python profiling/native compilation. This addendum evaluates alternatives to the four supplied architecture documents; it does not promote any dependency.

## Query inventory

- Durable/runtime/queue/pooling/CRDT: 16 queries
- Sandbox/egress/Wasm: 16 queries
- Inference/cache/routing: 16 queries
- Code intelligence/test impact/profiling/native: 16 queries

Query results were weighted by official documentation and upstream repositories over blogs, aggregators, vendor claims, and self-reported benchmarks.

## 1. Durable execution alternatives

| Candidate | What research supports | Missing / risk | Chimera decision |
|---|---|---|---|
| DBOS | Lightweight Postgres-backed workflow/checkpoint/queue library; deterministic workflow and idempotent step requirements are explicit. | Per-step database writes; external effects remain idempotency/unknown-outcome concerns; needs real Postgres capacity testing. | First compatibility adapter candidate. |
| Temporal | Mature durable orchestration with strong activity model, but activities are at-least-once and need idempotency. | Separate cluster/operational footprint; duplicates current WAL/outbox authority if used carelessly. | Compare only if DBOS/Postgres port fails workload requirements. |
| Restate | Durable journal, keyed objects, cancellation/control and agent integration; operationally separate service. | New server/control plane; must prove tool/LLM effect semantics against Chimera unknown-outcome rules. | Strongest non-Postgres alternative to evaluate after DBOS compatibility test. |
| LangGraph checkpointing | Python agent durability/checkpointer model. | Agent framework state is not a transactional coding authority; same idempotency/replay caveats. | Do not adopt as Chimera runtime core. |
| Prefect/Inngest/Trigger-like runtimes | Useful workflow/task operations in their target ecosystems. | Less aligned with local transactional branch/CAS/effect semantics or Python-first deployment needs. | Not priority alternatives. |

**Decision:** DBOS and Restate are the only durable-runtime alternatives worth a sealed adapter spike. Temporal is the escalation option if multi-region/polyglot/state-history requirements dominate. No replacement until crash/unknown-effect tests pass.

## 2. Queue alternatives

| Candidate | Best case | Important disqualifier / test |
|---|---|---|
| Existing local scheduler / DBOS queue | Lowest new infrastructure and preserves current authority. | Must load-test before assuming a separate queue is needed. |
| Hatchet | Durable task orchestration, policy/dependency/worker controls, Postgres-first deployment. | Adds a large engine; documented DB/graph/payload bottlenecks need workload data. |
| PGMQ | Lightweight Postgres extension with visibility timeout and archive semantics. | Visibility redelivery means external effects still need idempotency. |
| PgQue | Interesting zero-bloat event-log/rotation design; explicit xmin-horizon benchmark. | Early project and event-stream semantics/latency differ from per-job task ownership. |
| Graphile Worker / pg-boss | Mature Postgres queue approaches in other runtimes. | Language/runtime mismatch; LISTEN assumptions and at-least-once behavior need compatibility checks. |
| RabbitMQ/NATS/Redis | Potential high-throughput escalation. | New durability substrate and effect semantics; do not add before measured Postgres failure. |

**Decision:** do not default to Hatchet. First compare current/DBOS queue against PGMQ and PgQue under queue age, bloat, xmin pin, crash, and at-least-once-effect tests. A queue must be chosen by workload shape: competing task claims versus durable fan-out event streams.

## 3. Connection pooling alternatives

| Candidate | Strength | Constraint |
|---|---|---|
| PgBouncer | Mature default connection multiplexing. | Transaction pooling breaks LISTEN, session locks, persistent SET, etc. |
| PgCat | Multi-threaded pooling plus sharding/load balancing. | Adds broader proxy behavior and sharding semantics not needed by default. |
| Supavisor | Tenant-aware pooling. | More moving parts; suited to multi-tenant deployments. |
| pgagroal | Modern protocol-native pooler with monitoring/TLS/failover features. | Same transaction-pooling session incompatibilities must be audited. |

**Decision:** no pooler until a real Postgres deployment proves connection exhaustion. At that time benchmark PgBouncer, PgCat, and pgagroal with DBOS/Hatchet/listener compatibility. Use a dedicated/direct listener path if LISTEN remains necessary.

## 4. Sandbox and egress alternatives

| Candidate | Correct use | What prevents promotion now |
|---|---|---|
| Bubblewrap + Landlock | Fast Linux local containment with namespace/capability layers. | Current host has no certified bwrap backend; needs a real escape matrix. |
| nsjail | More explicit seccomp/namespace profile option. | Needs host profile design and bypass testing. |
| gVisor | Stronger application-kernel boundary; official docs note workload-specific I/O/network cost. | Benchmark on actual agent/tool workload, not microbenchmarks. |
| Firecracker/Kata | MicroVM/hardware boundary; snapshotting has networking and host setup limits. | Requires privileged host, image/snapshot supply chain, restore/egress/attestation tests. |
| forkd | Convenience layer over Firecracker snapshot/fork. | Alpha/orchestration risk; must not be trusted without per-spawn postconditions. |
| Cilium FQDN policy/Tetragon | Kubernetes-level DNS-aware egress/runtime evidence. | Relevant only in a K8s deployment; needs bypass/TTL/DNS/IMDS test suite. |
| Envoy/proxy egress | Useful component for a designed egress gateway. | TLS/SNI is not a complete application authorization policy; must test IP/DNS/protocol bypasses. |
| Wasmtime/WASI P2 | Capability-limited components for narrow untrusted computations. | Does not execute arbitrary Python/tool workloads; explicit host capabilities remain security boundary. |

**Decision:** for local Chimera use Bubblewrap + optional Landlock as first evidence target. For production untrusted code compare gVisor versus Firecracker/Kata. For Kubernetes egress, Cilium is a stronger alternative than an ad hoc transparent proxy, but only after a K8s target exists. forkd remains an experiment, not primary.

## 5. Inference serving alternatives

| Candidate | Appropriate workload | Important correction |
|---|---|---|
| Hosted provider caching | Current hosted exact-route workload. | Highest ROI before self-hosting; cached tokens must be observed, not assumed. |
| vLLM prefix cache | Self-hosted single/multi-replica shared-prefix workload. | Helps prefill only, not long decode-heavy output. |
| SGLang + router | Self-hosted multi-replica cache-locality workload. | Must measure router compatibility with actual chat request shape and cache metrics. |
| NVIDIA Dynamo | GPU fleet with KV-event-aware routing / TRT-LLM or vLLM backend. | Operationally complex; requires dynamic discovery/cluster control plane. |
| llm-d | Kubernetes-native distributed inference stack. | New ecosystem/control plane; no benefit for hosted API path. |
| TensorRT-LLM | NVIDIA-specific production GPU optimization, PD/KV/spec decoding. | Hardware/model lock-in and deployment complexity. |
| Mooncake / LMCache | Distributed/offloaded KV cache and PD transfer. | Requires multi-GPU/network topology and cache lifecycle observability. |
| PD disaggregation | Multi-GPU TTFT/tail-ITL control. | vLLM docs explicitly say it does not inherently improve throughput. |
| Speculative decoding | Decode-heavy, memory-bound self-hosted workload. | Acceptance rate/model/hardware dependent; must measure exact output and latency. |

**Decision:** hosted and self-hosted are separate product paths. Current Chimera must first complete hosted cache/cancellation/equal-config evidence. If self-hosting becomes a real requirement: prefix-cache baseline → cache-aware routing → PD test → speculative decoding test, each with actual model/GPU workload and quality equivalence.

## 6. Model routing and semantic cache alternatives

| Candidate | Why it is not default Chimera behavior |
|---|---|
| RouteLLM / RouterBench / LLMRouterBench | Useful offline benchmark/recommender inputs, but generic datasets do not override Chimera task distribution or concrete user model choice. |
| LiteLLM / Bifrost gateways | Automate fallback and routing, but explicitly multiply requests/costs and conflict with exact model authority unless user selects an audited policy. |
| GPTCache / semantic cache | Helpful for FAQ/read-only equivalence workloads, but unsafe for coding/effect/branch-state responses without exact equivalence and staleness proof. |

**Decision:** retain `RouteAuthority`. Build only an offline advisory recommender on sanitized Chimera traces; no automatic fallback, hedging, or semantic coding cache.

## 7. Code intelligence and test-speed alternatives

| Candidate | Potential | Constraint |
|---|---|---|
| Existing Chimera CodeGraph/Impact/ContextPlan | Already integrated, transactional-aware. | Real mutation corpus showed full fallback on all five real-source mutations; no focused-test speed promotion. |
| tokensave | Broad local code graph, self-reported per-call savings. | Pin binary, disable update/telemetry, check RSS/orphans, read-only trial, sealed own benchmark. |
| Token Savior / other MCP graph products | Interesting benchmark claims. | Very new/self-reported; requires source/security/provenance and own benchmark. |
| SCIP/Kythe | Compiler-grade cross-reference protocol. | Python indexing/build integration and index freshness cost; use only if current Python AST graph proves insufficient. |
| ast-grep/tree-sitter | Good deterministic structural search/rewrites/incremental parsing. | Never grant direct write authority; route through branch/PatchQualityGate. |
| Dynamic coverage TIA | Strongest workaround for current static full fallback. | Needs a local coverage map/mutation corpus and periodic full-suite validation. |
| pytest-xdist | Potential test wall-time gain. | Requires test isolation analysis; not enabled by default. |
| Pants/Bazel | Hermetic build/test dependency graph/caching. | Major build-system migration; evaluate only if project scale justifies it. |

**Decision:** next local speed trial is dynamic coverage-backed TIA plus pytest-xdist isolation experiment, not installing a queue/database/runtime. Code-intelligence alternatives require sealed in-repo benchmark before adoption.

## 8. Profiling/native alternatives

- **py-spy:** low-intrusion process sampling, useful first profiler for parent/child Python workloads.
- **Scalene:** CPU/memory/GPU/copy attribution; use in controlled benchmarks, not assumed low enough overhead for every production run.
- **mypyc:** most compatible typed-module compilation candidate for narrow pure Python kernels.
- **Cython/PyO3/Nuitka:** viable only for a proven hot function with mirror/property tests. None is a codebase rewrite strategy.

## 9. Revised priority order

1. Dynamic coverage TIA and test-parallelism isolation benchmark.
2. Stable prompt-prefix/cache telemetry audit.
3. Read-only pinned tokensave/alternative code-intelligence benchmark.
4. Disposable Postgres DBOS versus Restate compatibility spike.
5. Queue/pool/sandbox/self-hosted inference only after their preceding gates show real need.

## 10. Non-negotiable policy retained

No alternative may weaken explicit requested model choice, transactional branch authority, WAL/CAS receipts, protected tests, unknown-effect handling, scoped approvals, or held-out promotion gates. No vendor or repository benchmark qualifies as Chimera superiority evidence.
