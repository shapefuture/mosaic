# Chimera All 4 Tiers Implementation Report

Implemented after the 10/10 review. Scope: all four ranked tiers from `CHIMERA_10_OUT_OF_10_REVIEW.md`, with bounded production-safe versions and one-by-one tests.

## Final regression

```text
pytest tests -q
377 passed in 16.51s
```

## Tier 0 — correctness before more optimization

### 0.1 Sandbox branch-view correctness

**Files:** `chimera/sandbox.py`, `tests/test_tier0_sandbox_correctness.py`

Implemented:

- Added `_base_state_hash()` for base workspace invalidation.
- Cached materialization key now includes base workspace state and overlay state.
- Added `Sandbox.clear_materialize_cache(root=None, branch=None)` for lifecycle cleanup.
- Added tests proving cached branch views invalidate after base file changes and can be cleared.

Test:

```text
pytest tests/test_tier0_sandbox_correctness.py -q
2 passed
```

### 0.2 Command proof cache invalidation inputs

**Files:** `chimera/command_proof.py`, `chimera/rlm.py`, `tests/test_tier0_proof_wal.py`

Implemented:

- Extended `CommandProofSpec` with:
  - `env_hash`
  - `dependency_hashes`
  - `selected_input_hashes`
- Added helper functions `file_hashes()` and `environment_hash()`.
- `_run_branch_tests` now includes environment, dependency, and changed-input fingerprints in the proof spec.

### 0.3 WALBatchScope exception semantics

**File:** `chimera/wal.py`

Implemented:

- `WALBatchScope(wal, flush_on_exception=True|False)`.
- Can explicitly flush or discard pending Tier-2 entries on exceptions.

Test:

```text
pytest tests/test_tier0_proof_wal.py -q
2 passed
```

## Tier 1 — make new layers own hot-path decisions

### 1.1 RLM hot-path facades

**Files:** `chimera/rlm.py`, `chimera/action_executor.py`, `tests/test_tier1_hotpath_facades.py`

Implemented:

- Internal RLM patch/test call sites now route through `self.action_executor` instead of direct private calls.
- `ActionExecutor` remains a facade over compatibility implementations, enabling further safe strangler extraction.

### 1.2 Prompt block-native assembly

**File:** `chimera/prompt_assembler.py`

Implemented:

- `assemble_blocks(...)` to preserve block boundaries.
- `compaction_blocks(...)` helper to route compaction output as content blocks.

### 1.3 Route pipeline semantics tightened

**File:** `chimera/route_pipeline.py`

Implemented:

- Added separate `preferred_model` parameter distinct from `explicit_model`.
- Reasoning chain now records preferred and explicit model fields.

Test:

```text
pytest tests/test_tier1_hotpath_facades.py tests/test_rlm_split_facades.py tests/test_route_advisor.py -q
5 passed
```

## Tier 2 — reliability and quality gains

### 2.1 Real held-out verifier

**New file:** `chimera/heldout_verifier.py`

Implemented:

- `HeldOutVerifier.evaluate(...)` returns `HeldOutResult` with score, pass/fail, reasons, and CAS evidence artifact.
- `ChimeraHarness.run()` now records actual `held_out_pass`, not `None`.

### 2.2 Independent patch quality rubric

**New file:** `chimera/quality_rubric.py`

Implemented:

- `PatchReviewRubric` scoring for placeholder content, diffuse patches, missing security tests, and no-diff mutation-shaped tasks.
- `ChimeraHarness.run()` returns `quality_rubric` in the result.

### 2.3 Tiny contradiction ledger

**New file:** `chimera/contradiction_ledger.py`

Implemented:

- Minimal claim ledger: subject, predicate, value, source, trust, evidence.
- Conflict detection with higher-trust/fresher preferred claim.
- `SubagentManager` records subagent status claims at merge point.

### 2.4 Provider reliability profile

**New file:** `chimera/provider_reliability.py`

Implemented:

- Records provider success/failure, malformed tool calls, and rate-limit events.
- Produces reliability profile usable by routing.

Test:

```text
pytest tests/test_tier2_reliability_quality.py -q
3 passed
```

## Tier 3 — speed and token efficiency

### 3.1 Critical-path profiler

**New file:** `chimera/critical_path.py`

Implemented:

- `CriticalPathTrace` span context manager and summary.

### 3.2 Latency SLO modes

**New file:** `chimera/latency_modes.py`

Implemented modes:

- `inspect`
- `micro_edit`
- `normal_fix`
- `high_risk`

### 3.3 Test-impact selector

**New file:** `chimera/test_impact_selector.py`

Implemented:

- Confidence-scored focused test command selection.
- Full-suite fallback when no confident focused tests exist.

### 3.4 Speculation metrics / positive EV guard

**File:** `chimera/speculative_tools.py`

Implemented:

- Prediction/hit/discard counters.
- `stats()` reports `positive_ev` and hit rate.

Test:

```text
pytest tests/test_tier3_speed_efficiency.py -q
4 passed
```

## Tier 4 — maintainability, release gates, public surface

### 4.1 Small public API

**New file:** `chimera/public.py`

Implemented a small stable public surface:

- `ChimeraHarness`
- `TransactionalWorkspace`
- `ChimeraConfig`
- `Sandbox`
- `SandboxResult`
- `AgentComputerInterface`

### 4.2 User-facing run report

**New file:** `chimera/run_report.py`

Implemented:

- `summarize_run(result)` with task, changed files, verification, held-out result, usage, limitations, and evidence refs.

### 4.3 Performance gates

**New file:** `chimera/performance_gates.py`

Implemented smoke release gates:

- WAL batch 100 entries
- sandbox echo

### 4.4 Harness adversarial eval manifest

**New file:** `evals/harness_regression/manifest.json`

Cases include:

- assessment-no-write
- ambiguous-no-mutation
- malicious-readme-ignore
- wrong-file-trap
- hidden-dependency

Test:

```text
pytest tests/test_tier4_release_surface.py -q
4 passed
```

## Files added

- `chimera/heldout_verifier.py`
- `chimera/quality_rubric.py`
- `chimera/contradiction_ledger.py`
- `chimera/provider_reliability.py`
- `chimera/critical_path.py`
- `chimera/latency_modes.py`
- `chimera/test_impact_selector.py`
- `chimera/public.py`
- `chimera/run_report.py`
- `chimera/performance_gates.py`
- `evals/harness_regression/manifest.json`
- `tests/test_tier0_sandbox_correctness.py`
- `tests/test_tier0_proof_wal.py`
- `tests/test_tier1_hotpath_facades.py`
- `tests/test_tier2_reliability_quality.py`
- `tests/test_tier3_speed_efficiency.py`
- `tests/test_tier4_release_surface.py`

## Summary

All four tiers are now implemented in bounded form:

- Tier 0 protects correctness and cache/proof validity.
- Tier 1 makes extracted layers begin owning hot-path calls.
- Tier 2 adds real held-out verification, independent patch quality, contradiction handling, and provider reliability.
- Tier 3 adds speed/token-efficiency control surfaces and critical-path measurement.
- Tier 4 adds release gates, public API shrink path, adversarial eval manifest, and user-facing reports.

The system remains fully green:

```text
377 passed in 16.51s
```
