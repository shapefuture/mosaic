# Chimera Deployment Evidence Collection Results

**Date:** 2026-08-11  
**Purpose:** execute every requested evidence campaign feasible on the current host, capture real measurements, and state blocked experiments without substituting synthetic evidence.

## Completed evidence

### Dynamic coverage / Test Impact Analysis workaround

`pytest-testmon` was installed transiently and executed in disposable complete copies of Chimera. Each run first built a full coverage/dependency database, then changed real Chimera source and compared the testmon-selected run with the complete suite.

| Real mutation | Testmon result | Full result | Testmon wall | Full wall | Result |
|---|---:|---:|---:|---:|---|
| RouteAuthority explicit-model guard | detected | detected | 11.961s | 25.328s | 63 tests deselected |
| EventSink HTTP opt-in guard | detected | detected | 11.860s | 25.306s | 63 tests deselected |
| AutonomyLease exact expiry guard | detected | detected | 3.145s | 25.799s | 7 tests deselected |

This is the first local data showing a plausible faster impact-selection alternative. It is still insufficient to promote a default policy: three mutations do not establish recall across reflection, fixtures, generated imports, environment variants, or repository drift.

A new explicit acceleration policy is implemented in:

```text
chimera/test_acceleration.py
```

It requires both:

```text
CHIMERA_ENABLE_TEST_ACCELERATION=1
CHIMERA_TEST_ACCELERATION_CERTIFIED=1
```

It will never rewrite a custom test command. For the exact default `pytest -q`, it selects either:

```text
pytest -q -n <workers> --dist=loadscope
```

or, with an additional explicit flag:

```text
pytest -q --testmon
```

This is opt-in and evidence-receipted. Existing default full/impact behavior stays unchanged.

### pytest-xdist parallel test benchmark

After installing pytest-xdist transiently, repeated local runs were successful. Latest controlled run:

```text
serial wall:    25.941s   (496 passed in 25.02s)
loadscope wall: 14.917s   (496 passed in 14.46s)
```

This is approximately a **42.5% wall-time reduction** for the present Chimera suite on this two-core host, with no test failure in the measured runs. It justifies the explicit locally certified parallel-test lane for this repository—not a default for arbitrary user repositories or tenant workspaces.

## Blocked evidence, with valid workarounds

| Campaign | Host blocker | Valid workaround | Why no substitute result is accepted |
|---|---|---|---|
| DBOS vs Restate disposable Postgres | no Docker/Podman/Postgres binaries | run Testcontainers/real Postgres on CI or a self-hosted runner | SQLite/fake port cannot establish Postgres recovery, pool, or transaction evidence |
| Bubblewrap/Landlock/nsjail escape matrix | no bwrap/nsjail, no reported Landlock securityfs | Linux runner with user namespaces and pinned tools | static policy/fake test cannot establish OS containment |
| KVM microVM comparison | no `/dev/kvm` | privileged KVM host with Firecracker/Kata/forkd attestation suite | README benchmark is not target-host evidence |
| Pinned tokensave/code intelligence execution | no safe isolated binary execution host/cargo | sandboxed disposable runner, pinned checksum, telemetry/update disabled | unreviewed binary execution on unisolated host is not valid security evidence |
| Hosted exact-route campaign | no inherited secure credential descriptor | platform injects one-shot FD under testing protocol | chat credential or ordinary env copy would violate the secret boundary |
| Self-hosted inference | no GPU/NPU/model workload | GPU runner with pinned model, SGLang/vLLM baseline, cache telemetry | synthetic server metrics cannot establish KV/PD/speculation gain |

## Current conclusion

The test acceleration lane has local speed evidence and is implemented as an explicit opt-in. Every deployment/system-level alternative remains unpromoted until it is measured on a host capable of the relevant boundary. This is a constraint of the environment, not a reason to invent evidence or silently downgrade security.
