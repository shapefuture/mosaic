# Chimera Stream / Native Compaction / Consensus / Stress Implementation Report

## Request

Implement:

1. stream-time tool dispatch,
2. provider-native compaction canaries and A/B recall tests,
3. multi-candidate generation behind a budget gate using `patch_consensus.py`,
4. expanded strict stress eval with scaffold-free measurement,
5. continue considering workarounds.

## Implemented

### 1. Stream-time tool extraction wired into live streaming path

Files changed:

```text
chimera/rlm_provider.py
chimera/rlm_loop.py
```

Existing extractor:

```text
chimera/stream_tools.py
```

New behavior:

- `_stream_openai_chat(...)` now instantiates `StreamToolExtractor`.
- As streaming chunks arrive, complete `<tool_call>...</tool_call>` blocks are extracted immediately.
- If a thread-local `stream_tool_dispatcher` exists, it is invoked immediately with the complete block.
- `_model_tool_loop(...)` installs a read-only dispatcher during provider turns.
- Dispatch evidence is attached as:

```text
stream_time_tool_dispatch
```

Safety/workaround:

- stream-time dispatch is read-only.
- non-read tools are rejected with `stream-time dispatch is read-only`.
- existing truncated tool-call kill switch still prevents executing tool calls from length-truncated messages.

Test added:

```text
tests/test_stream_time_dispatch.py
```

### 2. Provider-native compaction canary + A/B recall tests

File changed:

```text
chimera/native_compaction.py
```

Added:

```python
NativeCompactionCanary().run(provider, model)
ab_recall_test(local_text, compacted_text, required_terms)
```

Current behavior:

- certified providers still downgrade to local compaction until canary-proved.
- A/B recall test measures required-term preservation before a provider-native compaction candidate could be trusted.

Test added:

```text
tests/test_native_compaction_canary.py
```

### 3. Multi-candidate patch generation behind a budget gate

File changed:

```text
chimera/rlm_coder_focused.py
```

Uses existing:

```text
chimera/patch_consensus.py
```

Env controls:

```bash
CHIMERA_MULTI_CANDIDATE_PATCHES=1..5          # default 1, disabled
CHIMERA_MULTI_CANDIDATE_TOKEN_BUDGET=6000     # stop candidate calls past budget
CHIMERA_MULTI_CANDIDATE_MIN_VOTES=2           # AST-canonical quorum
CHIMERA_MULTI_CANDIDATE_NEVER_ABSTAIN=1       # optional forced selection
```

Behavior:

- Only activates when `CHIMERA_MULTI_CANDIDATE_PATCHES > 1`.
- Calls provider multiple times for focused patch generation.
- Parses each patch candidate.
- Uses AST-canonical consensus to select a candidate when quorum is met.
- Abstains and falls back to normal single-candidate path if no quorum.

Test added:

```text
tests/test_multi_candidate_patch.py
```

### 4. Strict stress eval scaffold-free measurement

File changed:

```text
evals/harness_regression/strict_stress.py
```

New env control:

```bash
CHIMERA_STRICT_STRESS_INCLUDE_SCAFFOLD_FREE=1
```

When enabled, the strict stress eval also runs a Chimera condition with:

```bash
CHIMERA_DISABLE_DOMAIN_SCAFFOLDS=1
```

This measures generalized repair capability without deterministic benchmark-specific scaffolds.

The script still skips cleanly without credentials:

```json
{"status": "skip", "reason": "missing CEREBRAS_API_KEY"}
```

### 5. Workarounds / safety constraints

- Stream-time tool dispatch is read-only.
- Multi-candidate generation is opt-in and token-budgeted.
- Native compaction remains local fallback until canary-proved.
- Scaffold-free stress mode is opt-in so production reliability remains intact.

## Tests added / updated

```text
tests/test_stream_time_dispatch.py
tests/test_multi_candidate_patch.py
tests/test_native_compaction_canary.py
```

## Validation

Targeted:

```text
pytest tests/test_stream_time_dispatch.py -q
1 passed

pytest tests/test_multi_candidate_patch.py tests/test_remaining_future_mechanisms.py -q
6 passed

pytest tests/test_native_compaction_canary.py -q
2 passed

python3 evals/harness_regression/strict_stress.py
{"status": "skip", "reason": "missing CEREBRAS_API_KEY"}
```

Full:

```text
python3 -m compileall -q chimera tests evals/harness_regression/strict_stress.py
OK

pytest tests -q
417 passed in 16.07s
```

## Expected impact

### Speed / latency

- Stream-time dispatch can overlap read-only tool execution with model streaming when providers emit textual tool calls incrementally.
- Certified hedge remains available for provider-level latency spikes.

### Output quality / reliability

- Multi-candidate AST consensus can improve patch reliability when enabled.
- Native compaction canaries prevent unsafe blind adoption of opaque provider compaction.
- Scaffold-free stress mode makes generalized repair quality measurable.

### Token efficiency

- Multi-candidate path is budgeted and off by default.
- Native compaction A/B recall prevents switching to compaction that loses required details.

## Final status

```text
417 passed in 16.07s
```
