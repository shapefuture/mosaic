# Chimera Fix Plan — execution order and per-fix test gate

This is the working fix plan for this workspace. I will apply fixes one-by-one and run the listed test gate after each change before moving to the next.

## 0. Baseline

- Baseline test suite already observed: `371 passed`.
- Re-run targeted tests after every fix; run full `pytest tests -q` after the implemented batch.

## 1. Sandbox materialize/cache fix

**Files:** `chimera/sandbox.py`

**Change:**
- Add branch materialization cache keyed by `(branch, overlay_state_hash)` for host-subprocess fallback.
- Add bwrap argument composition that binds workspace root read-only plus overlay files when Bubblewrap is available.
- Stop deleting cached branch materializations in `finally`.

**Test gate:**
- `pytest tests/test_performance_layers.py::test_sandbox_materialized_branch_imports_overlay -q` if present, otherwise `pytest tests/test_performance_layers.py tests/test_harness_improvements.py -q`.
- Extra smoke: run two `Sandbox(..., workspace=ws, branch=...)` calls and assert the cached workdir is reused when overlay does not change and changes when overlay changes.

## 2. Tokenizer wiring fix

**Files:** `chimera/rlm.py`

**Change:**
- Instantiate `TokenizerMeasurer` in `RLMRuntime`.
- Add `_count_tokens(model, text)` helper using exact tokenizer when available, explicit `len(text)//4` fallback otherwise.
- Replace real usage/cost `len(...)//4` paths in `rlm.py` with `_count_tokens` while leaving mock-only internal echo accounting alone.

**Test gate:**
- `pytest tests/test_tokenizer.py tests/test_usage.py tests/test_provider_timing.py -q`
- Smoke instantiate `RLMRuntime` and call `_count_tokens()`.

## 3. WAL batching

**Files:** `chimera/wal.py`, Tier-2 WAL call-site files, `chimera/rlm.py` where practical.

**Change:**
- Add `WALBatchScope` and `wal_write()` using existing `append_batch()`.
- Repoint requested Tier-2 bookkeeping writes to `wal_write()`; leave Tier-1 durability writes untouched.

**Test gate:**
- `pytest tests/test_wal_batch.py tests/test_usage.py tests/test_provider_cooldown.py tests/test_plan_cache.py -q`
- Smoke `with WALBatchScope(wal): wal_write(...); wal_write(...)` and verify replay order.

## 4. Compaction cache-boundary fix

**Files:** `chimera/compaction.py`, possibly `chimera/rlm.py` if an outgoing provider request path consumes compacted transcript as blocks.

**Change:**
- Extend `CompactionResult` with `pointer_block`, `tail_block`, and `content_blocks()`.
- Keep `.text` backward compatible.

**Test gate:**
- `pytest tests/test_compaction.py tests/test_prompt_cache.py -q`
- Smoke compact long text and assert two cache-control blocks.

## 5. BranchReadCache LRU fix

**Files:** `chimera/branch_read_cache.py`

**Change:**
- Replace FIFO dict with `OrderedDict` and `move_to_end()` on hit.

**Test gate:**
- `pytest tests/test_branch_read_cache.py -q`

## 6. Preflight graph load/build fix

**Files:** `chimera/preflight.py`

**Change:**
- In the outlier exception path, try `graph.load()` first; only `build()` on load failure.

**Test gate:**
- `pytest tests/test_provider_canary.py tests/test_harness_improvements.py -q` or targeted preflight tests if present.
- Smoke `python -m chimera health`.

## 7. Verification/reward-hacking guard

**Files:** `chimera/gate_effectiveness.py`, `chimera/self_heal.py`, `chimera/orchestrator.py`

**Change:**
- Add dual-pass tracking and divergence alert.
- Add retry cap for identical self-heal failure signatures.
- Record grader pass with held-out placeholder where orchestrator has verification evidence.

**Test gate:**
- `pytest tests/test_gate_effectiveness.py tests/test_run_recovery.py -q`
- Synthetic divergence smoke.

## 8. Subagent condensation

**Files:** `chimera/subagents.py`

**Change:**
- Add `_condense_result(task, result)` and send condensed summary as parent message while keeping result path metadata.

**Test gate:**
- `pytest tests/test_task_slice_parallelism.py tests/test_agent_runtime_transfer.py -q` plus direct condensation smoke.

## 9. Route pipeline composition

**Files:** new `chimera/route_pipeline.py`

**Change:**
- Add composing entry point and `RouteDecision`. Integrate only if current method signatures line up cleanly; otherwise land as additive module first.

**Test gate:**
- `pytest tests/test_routing.py tests/test_route_advisor.py tests/test_optimization_qualifier.py -q`

## 10. Deferred / investigation items

These require mining or larger design before safe implementation:

- Causal/belief memory delete-vs-wire decision.
- Full ACI redesign.
- Meta-critic recalibration after enough dual-pass data exists.
- Compaction boundary snapping.
- Speculative tool execution.
- `rlm.py` strangler-fig split.

These are intentionally not mixed into the first mechanical patch batch.


## Implementation status after first patch batch

Completed and tested one-by-one:

1. Sandbox materialize/cache fix — targeted tests passed: `34 passed`.
2. Tokenizer wiring fix — targeted tests passed: `4 passed`.
3. WAL batching and Tier-2 repoints — targeted tests passed: `4 passed`.
4. Compaction cache-boundary result blocks — targeted tests passed: `3 passed`.
5. BranchReadCache LRU fix — targeted test passed: `1 passed`.
6. Preflight graph load/build fix — targeted tests passed: `29 passed`; health smoke succeeded.
7. Verification/reward-hacking guard — targeted tests passed: `3 passed`.
8. Subagent condensation — targeted test passed and direct smoke passed.
9. Route pipeline additive composition — targeted tests passed: `4 passed`.
10. Lint-before-apply cheap syntax guard — targeted patch tests passed: `5 passed`; direct lint rejection smoke passed.

Full regression after this batch:

```text
371 passed in 13.78s
```

Deferred intentionally because they require mining/design instead of mechanical edits:

- Causal/belief memory delete-vs-wire decision.
- Full SWE-agent-style ACI redesign.
- Meta-critic calibration after enough dual-pass data exists.
- Compaction subgoal-boundary snapping.
- Speculative tool execution.
- Full `rlm.py` strangler-fig split.
