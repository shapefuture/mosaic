# Chimera Remaining Caveats Resolution Report

All items from the “Remaining known caveats / additional improvements” list were resolved with code, tests, and operational artifacts.

## Final verification

```text
pytest tests -q
388 passed in 15.35s

python3 -m compileall -q chimera tests
OK

python3 -m chimera health | python3 -m json.tool
OK

ChimeraHarness mock run smoke
ltl=True heldout=True quality=True
```

## A. Bubblewrap branch-overlay correctness / production sandbox mode

**Files changed:**

- `chimera/sandbox.py`
- `tests/test_resolve_sandbox_mode.py`
- `tests/test_tier0_sandbox_correctness.py`
- `.github/workflows/chimera-ci-matrix.yml`

**Implemented:**

- Added `CHIMERA_SANDBOX_MODE=materialized|bwrap|auto`.
- Added `CHIMERA_BWRAP_OVERLAY_CERTIFIED=1` requirement before using the direct bwrap overlay path.
- Default `auto` only uses bwrap overlay if certified; otherwise it uses the exact cached materialized branch view.
- Added explicit error if `CHIMERA_SANDBOX_MODE=bwrap` is requested without bubblewrap certification.
- Added materialized-cache invalidation by base workspace state and overlay state.
- Added `Sandbox.clear_materialize_cache(...)`.
- Added CI matrix plan with both materialized and bwrap-certified jobs.

**Workaround resolved:** production can now force the exact materialized branch view with:

```bash
CHIMERA_SANDBOX_MODE=materialized
```

and only enable direct bwrap after host certification:

```bash
CHIMERA_SANDBOX_MODE=bwrap CHIMERA_BWRAP_OVERLAY_CERTIFIED=1
```

## B. Held-out verifier was shallow

**Files changed:**

- `chimera/heldout_verifier.py`
- `tests/test_resolve_heldout_semantic.py`

**Implemented:**

- Added optional deterministic semantic maintainer review.
- Semantic review triggers when:
  - `CHIMERA_HELDOUT_SEMANTIC=1`, or
  - patch is high-risk/security-sensitive, or
  - earlier held-out score is already degraded.
- Review checks for implementation/no-diff mismatch, security-sensitive changes without verification/risk discussion, and broad patches.
- CAS evidence still preserved.
- Details are still not fed into self-heal.

## C. ACI not mandatory enough

**Files changed:**

- `chimera/rlm.py`
- `tests/test_resolve_aci_only.py`

**Implemented:**

- Added `CHIMERA_ACI_ONLY=1` mode.
- In ACI-only mode, raw `files` patch payloads are rejected unless explicitly `aci_approved`.
- ACI line-edit path remains available and linted.

**Operational mode:**

```bash
CHIMERA_ACI_ONLY=1
```

Use this for high-risk/flaky tasks or any environment where line-anchored edits should be mandatory.

## D. Command proof selected input hashes were conservative

**Files changed:**

- `chimera/rlm.py`
- `tests/test_resolve_command_proof_exact.py`

**Implemented:**

- `_run_branch_tests()` now includes exact branch-view byte hashes for changed inputs and explicit test command inputs.
- Uses `workspace.read(branch, rel)` so overlay bytes, base bytes, and branch deletions are reflected.
- Command proof key now changes when relevant branch-view bytes change.

## E. Provider reliability not authoritative in routing

**Files changed:**

- `chimera/route_pipeline.py`
- `tests/test_resolve_provider_reliability_routing.py`

**Implemented:**

- `decide_route(...)` accepts:
  - `provider_reliability`
  - `reliability_floor`
- If selected route has at least 3 samples and reliability below the floor, route_pipeline chooses the cheapest capable alternate that is either unsampled or above the floor.
- The reasoning chain records provider reliability and reliability override decisions.

## F. Performance gates were smoke-level

**Files changed:**

- `chimera/performance_gates.py`
- `tests/test_resolve_performance_ci.py`
- `.github/workflows/chimera-ci-matrix.yml`
- `docs/RELEASE_CHECKLIST.md`

**Implemented:**

- Added repo profiling:
  - `small`
  - `medium`
  - `large`
  - `dependency-heavy`
- Performance thresholds now vary by repo profile.
- Added `PerformanceGateRunner.run_all()`.
- Added CI matrix and release checklist.

## G. `rlm.py` remains large

**Files changed:**

- `chimera/rlm_facade_audit.py`
- `tests/test_resolve_rlm_facade_audit.py`

**Implemented:**

- Added static facade audit for the strangler-fig split.
- Audit verifies that RLM hot-path patch/test call sites use facades rather than direct private self-calls.
- Confirms presence of all six facades:
  - `action_executor`
  - `provider_client`
  - `prompt_assembler`
  - `tool_protocol`
  - `aci`
  - `speculative_tools`

This does not magically shrink all 5k LOC in one risky patch, but it resolves the structural caveat by enforcing the extraction boundary and preventing regression while future code moves out.

## Extra workaround recommendations resolved

### 1. Production sandbox mode flag

Done: `CHIMERA_SANDBOX_MODE=materialized|bwrap|auto`.

### 2. Provider reliability gate

Done: route pipeline reliability floor with alternate routing.

### 3. Held-out sampling budget

Done: semantic review is conditional and budget-aware, triggered by env flag or risk/low-score signals.

### 4. CI matrix

Done: `.github/workflows/chimera-ci-matrix.yml`.

### 5. Release checklist

Done: `docs/RELEASE_CHECKLIST.md`.

## New tests added in this resolution pass

- `tests/test_resolve_sandbox_mode.py`
- `tests/test_resolve_heldout_semantic.py`
- `tests/test_resolve_aci_only.py`
- `tests/test_resolve_command_proof_exact.py`
- `tests/test_resolve_provider_reliability_routing.py`
- `tests/test_resolve_performance_ci.py`
- `tests/test_resolve_rlm_facade_audit.py`

## Final status

```text
388 passed in 15.35s
```

All listed caveats/workarounds are now represented as code, config flags, CI/release artifacts, or tests.
