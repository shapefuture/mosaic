# Chimera Superiority Plan — Second Continuation Report

## Summary

Continued implementing the unified existing-environment superiority plan.

Final validation:

```text
pytest tests -q
439 passed in 19.06s
```

## Implemented in this continuation

### 1. Scaffold registry expanded and made primary

Files:

```text
chimera/scaffolds/registry.py
chimera/rlm_coder_focused.py
```

The scaffold registry now owns registry implementations for:

- duration parser,
- sanitizer,
- expression engine components,
- configmerge parser/merger,
- parse/validate/report pipeline,
- audit composition.

`_deterministic_domain_scaffold()` now goes:

```text
ScaffoldRegistry first -> legacy fallback only for compatibility
```

This reduces the risk of uncontrolled scaffold growth in the main coder mixin.

### 2. ProviderState and QoS-aware routing support expanded

Files:

```text
chimera/provider_state.py
chimera/route_pipeline.py
chimera/rlm_provider.py
```

Added:

- unified provider profile,
- route penalty,
- QoS-based route override support,
- optional QoS routing at provider-call level via:

```bash
CHIMERA_QOS_ROUTING=1
CHIMERA_QOS_MODEL_POOL=modelA,modelB,...
```

Provider calls now also emit `provider_call` events through `EventSink`.

### 3. Event sink integrated into run finalization

Files:

```text
chimera/event_sink.py
chimera/rlm_dag_solver.py
```

Run finalization now emits:

```text
run_finalized
```

events when the file/HTTP event sink is configured.

### 4. Degradation confession expanded

Files:

```text
chimera/degradation_ledger.py
chimera/graph.py
chimera/orchestrator.py
chimera/sandbox.py
```

Converted additional hot-path silent exception patterns into structured `degradation` WAL events.

### 5. PatchFusion upgraded

Files:

```text
chimera/patch_fusion.py
chimera/patch_consensus.py
```

PatchFusion now supports:

- whole-patch consensus,
- repeated edit-atom fusion,
- repeated file-atom fallback.

Edit atoms support common alias forms:

```text
find / old / old_text / oldText / o
replace / new / new_text / newText / n
```

### 6. TesterAgent integration retained

Files:

```text
chimera/tester_agent.py
chimera/rlm_coder_focused.py
```

`CHIMERA_ENABLE_TESTER_AGENT=1` remains available and tested.

### 7. Eval gate runner and state path resolver retained

Files:

```text
chimera/eval_gate_runner.py
chimera/state_paths.py
```

## Tests added / updated

New/updated tests include:

```text
tests/test_qos_authoritative_provider.py
tests/test_event_sink.py
tests/test_provider_state_route.py
tests/test_sanitizer_degradation.py
tests/test_tester_agent_integration.py
tests/test_eval_gate_runner_state_paths.py
tests/test_roadmap_stages.py
```

## Full validation

```text
python3 -m compileall -q chimera tests evals/harness_regression/strict_stress.py evals/harness_regression/stream_dispatch_benchmark.py evals/harness_regression/omni_advanced.py
OK

pytest tests -q
439 passed in 19.06s
```

## Still remaining

The remaining implementation work is now narrower:

1. Finish deleting/migrating remaining legacy scaffold fallback body.
2. Make route pipeline authoritative for every high-level model decision, not only provider-call/QoS routing.
3. Split `_model_tool_loop` into smaller modules.
4. Convert every remaining broad `except: pass` outside hot paths.
5. Add cloud event sink backends beyond file/HTTP if needed.

## Current recommended defaults

```bash
CHIMERA_CERTIFIED_ROUTE=1
CHIMERA_HEDGE_MODEL=gemini-3.5-flash-lite
CHIMERA_PRIMARY_BUDGET_SECS=0.8
CHIMERA_MIN_PRIMARY_BUDGET_SECS=0.25
CHIMERA_REASONING_EFFORT=low
CHIMERA_AUTO_ACI_HIGH_RISK=1
```

Optional high-reliability modes:

```bash
CHIMERA_ENABLE_TESTER_AGENT=1
CHIMERA_MAX_REPAIR_ROUNDS=3
CHIMERA_QOS_ROUTING=1
```

Measurement/experimental modes:

```bash
CHIMERA_DISABLE_DOMAIN_SCAFFOLDS=1
CHIMERA_MULTI_CANDIDATE_PATCHES=3
CHIMERA_STRICT_STRESS_INCLUDE_SCAFFOLD_FREE=1
```
