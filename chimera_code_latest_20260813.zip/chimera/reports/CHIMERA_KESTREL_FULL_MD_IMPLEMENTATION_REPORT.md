# Chimera Kestrel Analysis — Full Read + Implementation Report

I read `/home/user/uploads/chimera_kestrel_analysis.md` end to end, including all headings from 1a through 2r and the Category 3 rejection/defer sections. I then implemented the actionable mechanisms that improve Chimera without blindly porting whole external architectures.

## Final verification

```text
pytest tests -q
405 passed in 17.63s
```

## Implemented from the MD

### 1b / 1e — CompletionGate / verify-AC-style deterministic claim gate

New file:

```text
chimera/completion_gate.py
```

Wired into:

```text
chimera/rlm_dag_solver.py::_finalize_run_evidence
```

Capabilities:

- classifies claims as artifact / service / implementation / statement,
- rejects verified implementation claims without behavior evidence or patch diff,
- rejects artifact claims without file/diff evidence,
- rejects service claims without liveness evidence,
- emits `completion_gate` result into run outputs.

Test:

```text
tests/test_kestrel_mechanisms.py::test_completion_gate_rejects_verified_implementation_without_evidence
```

### 1d / 2e — Learned context-window ceiling

New file:

```text
chimera/context_ceiling.py
```

Capabilities:

- shrink-only effective context ceiling per model alias,
- ignores small 413s as payload-limit rather than context overflow,
- persists in `.chimera/context-ceilings.json`.

Test:

```text
test_context_ceiling_shrinks_only_and_413_small_is_payload_limit
```

### 2a / 2m / 2o — Compaction trigger hygiene + idle trigger + per-message accounting

New file:

```text
chimera/compaction_policy.py
```

Capabilities:

- stale-usage skip,
- model-identity guard,
- unknown-window gate,
- cache-read-inclusive silent-overflow detection,
- cache-cold idle trigger with minimum-size floor,
- reversible deterministic collapse helper,
- per-message disposition accounting.

Test:

```text
test_compaction_policy_hygiene_and_reversible_collapse
```

### 2b — Confession protocol / silent-loss linter

New file:

```text
chimera/silent_transform.py
```

Capabilities:

- `SilentTransformLedger.confess(kind, scope, reason)`,
- WAL `silent_transform` convention,
- source linter for fallback/truncation/compaction lines without explicit confession.

### 2c / 2f / 2o — Retry/backoff taxonomy

Replaced:

```text
chimera/backoff.py
```

Capabilities:

- typed `RetryDecision`,
- categories:
  - auth,
  - quota,
  - validation,
  - rate_limit,
  - transient_network,
  - backend,
  - unknown,
- retryable flag,
- delay seconds,
- reason,
- suggested action.

Legacy `backoff_seconds(...)` remains for compatibility.

Test:

```text
test_backoff_taxonomy_distinguishes_quota_rate_validation
```

### 1c — Stream-time tool-call extraction

New file:

```text
chimera/stream_tools.py
```

Capabilities:

- incremental `<tool_call>...</tool_call>` extraction from streaming chunks,
- no speculation or misprediction,
- emits tool event as soon as a full block is present.

Test:

```text
test_stream_tool_extractor_emits_before_stream_end
```

### 2q / 2j — Cooperative staleness contract + stronger lint-gated edit shape

Updated:

```text
chimera/aci.py
```

Capabilities:

- `line_edit(..., expected_hash=...)`,
- computes actual source hash,
- returns retryable `stale_source` mismatch instead of applying stale edits,
- preserves existing syntax lint-before-write.

Test:

```text
test_aci_staleness_contract_and_integrity_penalty
```

### 2h — Negative scoring for integrity violations

Updated:

```text
chimera/quality_rubric.py
```

Capabilities:

- patches modifying `tests/`, `.github/`, or `pyproject.toml` are penalized as integrity violations,
- score drops below pass threshold instead of merely ignoring the issue.

Test:

```text
test_aci_staleness_contract_and_integrity_penalty
```

### 2i — Pointer-row memory with outcome-conditioned reinforcement

New file:

```text
chimera/pointer_memory.py
```

Capabilities:

- small pointer-row memory store,
- table-of-contents rows only,
- success/failure bumps only on unambiguous outcomes,
- cancelled/stalled outcomes do not corrupt reinforcement.

Test:

```text
test_pointer_memory_bumps_only_unambiguous_outcomes
```

### 2l — Enumerated stop reasons

New file:

```text
chimera/stop_reasons.py
```

Capabilities:

- closed `StopReason` enum,
- `StopDecision` object for auditability.

### 2r — KIRA-style double-confirmation completion

Not implemented as a full model extra-turn by default because it would increase live provider spend and latency on every run. Instead, the code-side `CompletionGate` is now in place as the zero-cost first layer. The double-confirmation turn should be added only for high-risk finalization or when `CompletionGate` rejects/flags a claim.

### 2d / 2n / 2p — Native compaction, typed compaction planner outcomes, candidate consensus

These were read and intentionally not implemented as live mechanisms because Chimera currently uses a deterministic local compactor and does not yet have a native-provider compaction or multi-candidate patch generation path. Implementing those now would be speculative overbuilding. The relevant foundation was added instead:

- provider capability surfaces can carry this later,
- `compaction_policy.py` defines trigger hygiene and message disposition,
- `stream_tools.py` and speculative tooling remain ready for future multi-candidate flow.

## Already implemented before this pass but confirmed by MD

- Compaction block split / boundary snapping.
- Held-out verification and meta-critic calibration base.
- Tokenizer wiring.
- Lint-before-apply.
- Subagent condensation.
- Speculative tool executor, gated by verification pressure.
- WAL batching.
- Sandbox materialization fixes.
- Provider live routing / Cerebras + Gemini + TokenRouter tests.

## Tests added in this pass

```text
tests/test_kestrel_mechanisms.py
```

Covers:

- CompletionGate,
- context ceiling shrink-only behavior,
- compaction trigger hygiene and reversible collapse,
- retry taxonomy,
- stream-time tool extraction,
- ACI expected-hash staleness contract,
- integrity-violation negative scoring,
- pointer-row memory reinforcement.

## Why not port the whole Kestrel architecture?

The MD itself rejects several full rewrites as not worth adopting now:

- full six-plane kernel rewrite,
- service-registry/hook-slot kernel restructuring,
- multi-agent economics gate,
- goal-mode typed state machine.

I followed that discipline. I adopted mechanisms that directly improve Chimera, not wholesale external architecture.

## Final status

```text
405 passed in 17.63s
```

The remaining future-only items are:

1. optional high-risk KIRA double-confirmation turn,
2. provider-native compaction measurement when target providers expose it,
3. typed compaction-planner outcomes if Chimera adds LLM-narrative compaction,
4. AST-canonicalized consensus if Chimera adds multi-candidate generation.
