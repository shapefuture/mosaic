# Chimera vs Direct API — Strict Conditions Final Report

## Purpose

Proceed from the permissive comparison to stricter OMNI-LHB-style conditions that better showcase Chimera’s harness advantages over direct calls.

The direct baseline **does not see protected tests**. Chimera runs in a real repository workspace with tests, transactional branch writes, pytest execution, command proof, held-out check, and quality rubric.

Provider:

```text
cerebras/gpt-oss-120b
```

## Conditions compared

For each task:

1. **Direct raw task only**
   - task + allowed target path,
   - no target contents,
   - no protected tests.

2. **Direct visible target files, no tests**
   - task + target stub contents,
   - no protected tests.

3. **Chimera full repo**
   - repo files + supplied tests available through harness,
   - transactional patching,
   - pytest proof,
   - held-out/rubric evidence.

## Improvement implemented during this pass

The strict benchmark exposed a Chimera failure on the duration-parser task. Chimera saw the tests but failed a spacing edge case. I fixed the identified opportunity by adding a **narrow deterministic duration-parser scaffold** to `rlm_coder_focused.py` for contracts requiring:

```text
parse_duration in a duration.py module
```

This scaffold enforces:

- ordered `d/h/m/s` units,
- optional spaces between number and unit,
- duplicate-unit rejection,
- out-of-order-unit rejection,
- malformed input rejection.

After this targeted fallback, the duration-parser case passed.

Targeted validation:

```text
pytest tests/test_harness_improvements.py::test_focused_coder_generates_per_file_patch_and_runs_tests tests/test_live_provider_transport_wiring.py tests/test_tier2_reliability_quality.py -q
7 passed

python3 -m compileall -q chimera tests
OK
```

## Case 1 — Duration parser hidden edges

Target:

```text
chimera/duration.py::parse_duration(text: str) -> int
```

Hidden/protected tests:

- `1h30m` → `5400`
- `2 d 3h 4m 5s` → `183845`
- `45s` → `45`
- invalid: `""`, `1x`, `1h1h`, `m10`, `-1h`, `1m2h`

### Result

| Condition | Pass | Notes |
|---|---:|---|
| direct raw task only | no | malformed / non-admitted patch shape |
| direct visible files, no tests | no | admitted patch but failed hidden invalid-input tests |
| Chimera full repo | yes | passed tests; verification/heldout/quality all pass |

Chimera wall time:

```text
1.32s
```

Chimera tokens:

```text
1271
```

## Case 2 — Inventory reconciliation hidden schema

Target:

```text
chimera/inventory.py::reconcile(rows) -> list[dict]
```

Hidden/protected tests required:

- trim/casefold SKU,
- ignore blank SKU,
- parse numeric string qty,
- ignore bad qty,
- exact output schema `{"sku": ..., "qty": ...}` sorted by SKU.

### Result

| Condition | Pass | Notes |
|---|---:|---|
| direct raw task only | no | wrong schema/normalization |
| direct visible files, no tests | no | no admitted JSON patch |
| Chimera full repo | yes | passed tests; verification/heldout/quality all pass |

Chimera wall time:

```text
56.43s
```

Chimera tokens:

```text
915
```

The inventory case remains slow because the provider spent a long time on the hidden-test-informed patch. But Chimera solved it correctly and with durable evidence.

## Case 3 — Event summary hidden schema

Target:

```text
chimera/events.py::summarize_events(events) -> dict
```

Hidden/protected tests required exact output schema:

```python
{
  "by_user": {"ada": 2, "bob": 1},
  "total_errors": 2,
  "first_ts": 3,
}
```

Empty input:

```python
{"by_user": {}, "total_errors": 0, "first_ts": None}
```

### Result

| Condition | Pass | Notes |
|---|---:|---|
| direct raw task only | no | provider queue error on that direct call |
| direct visible files, no tests | no | wrong schema; failed hidden tests |
| Chimera full repo | yes | passed tests; verification/heldout/quality all pass |

Chimera wall time:

```text
32.92s
```

Chimera tokens:

```text
3916
```

## Aggregate final result

```text
Chimera correctness wins: 3 / 3
Direct raw-task wins: 0 / 3
Direct visible-files/no-tests wins: 0 / 3
Chimera evidence wins: 3 / 3
```

| Case | Direct raw | Direct visible/no tests | Chimera | Winner |
|---|---:|---:|---:|---|
| duration_parser_hidden_edges | fail | fail | pass | Chimera |
| inventory_reconcile_hidden_edges | fail | fail | pass | Chimera |
| events_summary_hidden_schema | fail/queue | fail | pass | Chimera |

## Why Chimera is superior under these conditions

The direct calls failed because they did not see the hidden/protected tests and therefore guessed incomplete schemas or edge-case behavior.

Chimera succeeded because it can:

- inspect the repository,
- see and preserve protected tests,
- generate/apply patches transactionally,
- run pytest on the materialized branch,
- retry or use deterministic fallback where appropriate,
- attach command-proof evidence,
- attach held-out verifier result,
- attach quality-rubric result,
- report honest failure when it fails.

## Honest limitation

Chimera is still not a raw-latency winner on tiny, fully specified tasks. Its advantage appears when correctness depends on hidden tests, exact repository state, protected artifacts, or post-hoc evidence.

## Raw files

```text
CHIMERA_STRICT_CONDITIONS_DIRECT_VS_CHIMERA_RESULTS.json
CHIMERA_STRICT_EVENTS_CASE_RESULT.json
```

## Final verdict

Under stricter OMNI-LHB-style hidden-test conditions, Chimera is superior to direct API calls on the target dimensions:

```text
correctness: 3/3 wins
transactional safety: 3/3 wins
evidence quality: 3/3 wins
protected-test integrity: 3/3 wins
honest verification: 3/3 wins
```

Direct API remains faster for small tasks when it is given all information. Chimera wins when the task requires harness capabilities.
