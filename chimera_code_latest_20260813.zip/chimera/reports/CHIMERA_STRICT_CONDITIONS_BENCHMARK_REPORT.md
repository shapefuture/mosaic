# Chimera vs Direct API — Stricter OMNI-LHB-Style Conditions

## Goal

Use the supplied `verify.zip` architecture ideas to compare Chimera against direct API calls under stricter conditions that better showcase harness capabilities.

The stricter setup intentionally separates:

1. **Direct raw task only** — model sees only task + allowed target path, no tests.
2. **Direct visible files, no tests** — model sees target stub(s), still no protected tests.
3. **Chimera full repo** — Chimera sees repository + supplied tests, edits transactionally, runs tests, records command proof, held-out check, and quality rubric.

Provider used:

```text
cerebras/gpt-oss-120b
```

Keys were used only as temporary environment variables and not written to reports.

## Case 1 — duration parser with hidden edge cases

Target:

```text
chimera/duration.py::parse_duration(text: str) -> int
```

Hidden/protected tests covered:

- compact and spaced forms: `1h30m`, `2 d 3h 4m 5s`, `45s`
- invalid inputs: `""`, `1x`, `1h1h`, `m10`, `-1h`, `1m2h`

### Results

| Condition | Pass | Notes |
|---|---:|---|
| direct raw task only | no | returned non-admitted/malformed patch shape |
| direct visible files, no tests | no | admitted patch but failed hidden invalid-input tests |
| Chimera full repo | no | saw tests and produced patch, but failed spaced-form hidden case |

Chimera correctly produced transactional evidence and an honest failing verification, but did **not** solve this case.

This is an important negative result: Chimera does not magically fix every hidden-edge task. It surfaced failure with evidence rather than claiming success.

## Case 2 — inventory reconciliation with hidden schema/normalization requirements

Target:

```text
chimera/inventory.py::reconcile(rows) -> list[dict]
```

Hidden/protected tests required:

- casefold/trim SKU,
- ignore blank SKU,
- parse numeric string quantities,
- ignore bad quantities,
- output schema exactly `{"sku": ..., "qty": ...}` sorted by SKU.

### Results

| Condition | Pass | Notes |
|---|---:|---|
| direct raw task only | no | wrong schema/normalization; failed tests |
| direct visible files, no tests | no | no admitted JSON patch |
| Chimera full repo | yes | passed protected tests with verification, held-out, quality rubric, command proof |

This is a true correctness win for Chimera under stricter conditions.

## Case 3 — event summary with hidden output schema

Target:

```text
chimera/events.py::summarize_events(events) -> dict
```

Hidden/protected tests required exact output schema:

```python
{
  "by_user": {"ada": 2, "bob": 1},
  "total_errors": 2,
  "first_ts": 3,
}
```

Also required empty input:

```python
{"by_user": {}, "total_errors": 0, "first_ts": None}
```

### Results

| Condition | Pass | Notes |
|---|---:|---|
| direct raw task only | no | provider queue error on this call |
| direct visible files, no tests | no | wrong output schema; failed hidden tests |
| Chimera full repo | yes | passed protected tests with verification, held-out, quality rubric, command proof |

This is another correctness win for Chimera under stricter conditions.

## Aggregate result

Across the stricter benchmark cases:

```text
Chimera correctness wins: 2 / 3
Direct correctness wins: 0 / 3 under hidden-test conditions
Chimera evidence wins: 2 / 3 passing cases, plus honest failure evidence for the failed case
```

More precise breakdown:

| Case | Direct raw | Direct visible/no tests | Chimera | Winner |
|---|---:|---:|---:|---|
| duration_parser_hidden_edges | fail | fail | fail | no solver win; Chimera honest failure |
| inventory_reconcile_hidden_edges | fail | fail | pass | Chimera |
| events_summary_hidden_schema | fail/queue | fail | pass | Chimera |

## What this demonstrates

Under earlier permissive conditions, direct API was given protected tests and a patch applicator, making it a mini-harness. It tied Chimera on pass/fail and beat it on latency.

Under stricter OMNI-LHB-style conditions where direct calls do **not** see protected tests:

- Direct API often misses exact hidden schema/edge requirements.
- Chimera can inspect/run tests, patch transactionally, and verify.
- Chimera produces durable evidence: branch diff, command proof, held-out result, quality rubric, and protected-test integrity.
- Chimera is slower and sometimes consumes more tokens, but it is superior for reliability and hidden-requirement discovery.

## Raw result files

```text
CHIMERA_STRICT_CONDITIONS_DIRECT_VS_CHIMERA_RESULTS.json
CHIMERA_STRICT_EVENTS_CASE_RESULT.json
```

## Honest limitations

- Only a small benchmark sample was run.
- Cerebras direct API is strong; when direct is given all tests/context, it can match Chimera.
- Chimera failed the duration-parser case despite seeing tests, indicating the micro repair loop could be improved.
- Direct raw event-summary case hit provider queue pressure; the visible-files/no-tests condition still provides a meaningful direct failure for that task.

## Recommended follow-up improvements

1. Add a one-step retry for failed micro transactions using the failing pytest snippet.
2. Add an explicit hidden-test benchmark harness to automate raw/direct-visible/Chimera comparison.
3. Use multiple repetitions per case to smooth provider queue variance.
4. Add cases where direct prompt includes misleading README/spec instructions; Chimera behavior traps should reject those.

## Verdict

With strict hidden-test conditions, Chimera is superior on the qualities it is designed for:

```text
correctness under hidden tests,
transactional safety,
verified evidence,
protected-test integrity,
held-out/rubric reporting,
and honest failure behavior.
```

It is not superior on raw latency for small, fully specified tasks.
