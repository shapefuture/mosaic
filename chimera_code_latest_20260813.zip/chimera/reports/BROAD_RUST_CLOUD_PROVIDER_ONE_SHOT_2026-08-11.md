# Broad Rust graph, cloud-native profile, and authorized provider canary pass — 2026-08-11

## Scope

User requested all next steps in one go:

1. broad corpus retrieval/ranking for Rust graph;
2. runtime fallback drills for Rust graph;
3. quota-consuming provider tests authorized;
4. ensure Chimera can run cloud-priority/self-hosted while preserving local mode;
5. minimize memory footprint while preserving quality/speed/efficiency/functionality;
6. consider workarounds.

## Implemented

### 1. Broad Rust graph retrieval/ranking campaign

Added:

```text
evals/deployment/rust_graph_broad_retrieval_campaign.py
```

Generated artifact:

```text
artifacts/rust_graph_broad_retrieval_campaign_2026-08-11.json
```

The campaign creates a broader synthetic multi-domain corpus:

```text
auth
billing
inventory
search
notifications
tenant
```

Each domain includes Python service classes/functions and TypeScript record interfaces/load functions.

Measured:

- Rust top-10 recall;
- Python `CodeGraph.search()` top-10 recall;
- Rust/Python overlap;
- top-3 recall for additional ranking signal.

Observed:

```json
{
  "schema_version": "chimera.rust-graph-broad-retrieval-campaign.v1",
  "all_passed": true,
  "case_count": 48,
  "rust_recall_at_10": 1.0,
  "python_recall_at_10": 1.0,
  "rust_recall_at_3": 0.75,
  "broad_retrieval_certified": true,
  "bm25_exact_parity_certified": false,
  "semantic_retrieval_certified": false,
  "cross_platform_certified": false,
  "mirror_only": true,
  "production_replacement_authorized": false
}
```

Honest scope: broader lexical symbol retrieval evidence. It is not exact BM25 parity, semantic retrieval parity, or production promotion.

Added:

```text
tests/test_rust_graph_broad_retrieval_evidence.py
```

### 2. Rust runtime fallback drills

Added:

```text
evals/deployment/rust_graph_runtime_fallback_campaign.py
```

Generated artifact:

```text
artifacts/rust_graph_runtime_fallback_campaign_2026-08-11.json
```

Drills:

- default runtime backend remains Python;
- missing Rust binary falls back to Python;
- failing Rust binary falls back to Python;
- fallback still returns expected Python hits;
- explicit Rust mirror mode is allowed only as mirror and not production-authorized.

Observed:

```json
{
  "schema_version": "chimera.rust-graph-runtime-fallback-campaign.v1",
  "all_passed": true,
  "default_backend_python": true,
  "missing_binary_fallback": true,
  "failing_binary_fallback": true,
  "fallback_preserves_hits": true,
  "mirror_explicit_backend_allowed": true,
  "mirror_explicit_not_production_authorized": true,
  "mirror_only": true,
  "production_replacement_authorized": false
}
```

Added:

```text
tests/test_rust_graph_runtime_fallback_evidence.py
```

### 3. Authorized provider live canary campaign

Added:

```text
evals/deployment/provider_live_canary_campaign.py
```

Generated artifact:

```text
artifacts/provider_live_canary_campaign_2026-08-11.json
```

The user authorized quota-consuming provider tests, so the campaign was run with:

```bash
python evals/deployment/provider_live_canary_campaign.py \
  --authorize-live-call \
  --results artifacts/provider_live_canary_campaign_2026-08-11.json
```

Current environment had no configured provider keys:

```text
CEREBRAS_API_KEY=false
GEMINI_API_KEY=false
GOOGLE_API_KEY=false
TOKENROUTER_API_KEY=false
TOKENROUTER_KEY=false
OPENROUTER_API_KEY=false
OPENROUTER_API_KEYS=false
```

Observed artifact:

```json
{
  "schema_version": "chimera.provider-live-canary-campaign.v1",
  "authorized_by_user": true,
  "raw_keys_recorded": false,
  "configured_env_names": [],
  "live_calls_attempted": 0,
  "any_live_capability_proved": false,
  "all_configured_routes_passed": false,
  "all_passed": true
}
```

Honest interpretation: authorization exists, but no live canary could run because no provider credentials are present in the process environment. No raw key was recorded.

Added:

```text
tests/test_provider_live_canary_campaign.py
```

### 4. Cloud-native/self-hosted profile with local option preserved

Added:

```text
chimera/cloud_native_profile.py
```

Added CLI:

```bash
chimera platform cloud-profile --mode selfhosted-cloud
chimera platform cloud-profile --mode local
```

Self-hosted cloud profile reports:

```json
{
  "schema_version": "chimera.cloud-native-profile.v1",
  "mode": "selfhosted-cloud",
  "cloud_priority": true,
  "local_supported": true,
  "required_runtime_envs": [
    "CHIMERA_POSTGRES_URL or DATABASE_URL",
    "CHIMERA_RESTATE_INGRESS or CHIMERA_RESTATE_ENDPOINT or RESTATE_ENDPOINT"
  ]
}
```

It explicitly preserves local mode while making cloud priority first-class.

Memory minimization guidance encoded in the profile:

- externalize durable state to PostgreSQL and Restate instead of local resident processes;
- store large artifacts content-addressed and pass references;
- keep Rust graph mirror/fallback until promotion gates pass;
- use persisted graph/search indexes only with source-digest binding and fail-closed load;
- prefer bounded workers and explicit concurrency over unbounded in-process fanout.

Quality/speed/efficiency preserved by policy:

- do not bypass doctor/certification bundle gates;
- cloud-runtime gate requires persistent endpoint envs;
- provider capabilities require artifact-backed live canaries;
- provider cancellation holds worst-case billing exposure until authoritative receipt;
- direct provider adapters preferred over gateway indirection when available;
- prompt-cache stable prefixes and typed context manifests preserved.

Added:

```text
tests/test_cloud_native_profile.py
```

### 5. Rust promotion docs / CI updated

Updated:

```text
docs/RUST_GRAPH_PROMOTION_PLAN.md
.github/workflows/chimera-ci-matrix.yml
```

CI now includes broad retrieval and runtime fallback in Rust graph jobs:

```bash
python evals/deployment/rust_graph_broad_retrieval_campaign.py
python evals/deployment/rust_graph_runtime_fallback_campaign.py
```

The CI assertions preserve mirror-only / not-production-authorized behavior.

## Validation

Targeted validation:

```bash
pytest tests/test_rust_graph_broad_retrieval_evidence.py \
  tests/test_rust_graph_runtime_fallback_evidence.py \
  tests/test_provider_live_canary_campaign.py \
  tests/test_cloud_native_profile.py \
  tests/test_rust_graph_persisted_index_evidence.py \
  tests/test_rust_graph_runtime_adapter.py \
  tests/test_rust_graph_promotion_docs.py -q
```

Result:

```text
9 passed in 0.54s
```

Full suite:

```bash
pytest tests -q
```

Result:

```text
632 passed in 54.15s
```

Doctor:

```bash
python -m chimera.cli doctor --profile local --fail-on-blockers --json
```

Observed:

```json
{
  "certified": true,
  "blockers": [],
  "summary": {
    "ready": 14,
    "installed-not-certified": 0,
    "missing-dependency": 4,
    "configured-but-untested": 0,
    "manual-only": 2,
    "not-supported-on-host": 1
  }
}
```

## Current Rust graph status after one-shot pass

Rust graph now has:

1. exact batch conformance;
2. stateful incremental API conformance;
3. bounded watch/debounce adapter conformance;
4. bounded lexical symbol-search recall conformance;
5. persisted-index save/load/search fail-closed conformance;
6. runtime mirror adapter with Python fallback;
7. broad synthetic multi-domain retrieval/ranking evidence;
8. runtime fallback drills for missing/failing Rust binaries.

Still correctly guarded:

```text
mirror_only = true
production_replacement_authorized = false
```

## Cloud-native status

Chimera now has explicit local/certification-bundle/cloud-runtime separation:

- local profiles preserved;
- `cloud-postgres`, `durable-restate`, `sandbox-linux` certify local bounded bundles;
- `cloud-runtime` requires persistent cloud endpoint env vars;
- `platform cloud-profile --mode selfhosted-cloud` documents cloud-priority/selfhosted runtime requirements and memory minimization.

The current sandbox still lacks persistent cloud runtime endpoint env vars, so `cloud-runtime` should fail until those are supplied.

## Honest remaining limits

- Provider live canaries did not execute because no provider keys were present despite authorization.
- Rust graph still lacks real hidden/broad production corpus proof and cross-platform matrix proof.
- Exact BM25/semantic/structural/call-neighborhood retrieval parity is still not fully certified.
- Native Rust watcher / production watch lifecycle is still not certified.
- `/dev/kvm` absent; microVM/KVM remains unavailable.
- Release signing and provider billing-stop proof require external protected approval / authoritative receipts.

## Next options

1. If provider keys are supplied in the environment, rerun:

```bash
python evals/deployment/provider_live_canary_campaign.py --authorize-live-call \
  --results artifacts/provider_live_canary_campaign_2026-08-11.json
```

2. Add real-world/hidden corpus retrieval benchmark for Rust graph.
3. Add cloud-runtime smoke campaign once `CHIMERA_POSTGRES_URL` and `CHIMERA_RESTATE_INGRESS` are configured.
4. Start native Rust watch service and broader cross-platform matrix.
