# Chimera Measurement Harness for Previously Deferred Mechanisms

## Goal

For mechanisms that were previously "not adopted until measured benefit," add concrete tests/evals to collect the required evidence and safely decide implement vs defer.

## Implemented measurement / gated adoption paths

### 1. Stream-time tool dispatch measurement

Files:

- `chimera/stream_tools.py`
- `chimera/rlm_provider.py`
- `chimera/rlm_loop.py`
- `tests/test_stream_time_dispatch.py`

What it measures / proves:

- Streaming chunks are parsed incrementally.
- Complete `<tool_call>...</tool_call>` blocks can dispatch before stream end.
- Dispatch is read-only and evidence is recorded as `stream_time_tool_dispatch`.

Decision rule:

- Keep enabled for read-only tools when it hides tool wall-time without triggering truncated-call kill switch.
- Do not enable write dispatch mid-stream.

### 2. Provider-native compaction canary + A/B recall measurement

Files:

- `chimera/native_compaction.py`
- `tests/test_native_compaction_canary.py`

What it measures:

- Whether provider-native compaction is canary-proved for a provider/model.
- Whether candidate/native compaction preserves required recall terms at least as well as local compaction.

Decision rule:

- Use provider-native compaction only when the canary reports support and A/B recall is not worse than local.
- Otherwise use `local_compaction_fallback`.

### 3. Multi-candidate patch generation measurement

Files:

- `chimera/patch_consensus.py`
- `chimera/rlm_coder_focused.py`
- `tests/test_multi_candidate_patch.py`

Env controls:

```bash
CHIMERA_MULTI_CANDIDATE_PATCHES=1..5
CHIMERA_MULTI_CANDIDATE_TOKEN_BUDGET=6000
CHIMERA_MULTI_CANDIDATE_MIN_VOTES=2
CHIMERA_MULTI_CANDIDATE_NEVER_ABSTAIN=1
```

What it measures:

- Whether multiple candidate generations reach AST-canonical quorum.
- Whether consensus-selected patches pass tests more often than single candidate.
- Token cost vs success lift.

Decision rule:

- Keep disabled by default unless success lift justifies token/latency cost.
- Enable for high-risk or flaky tasks only when budget allows.

### 4. Strict stress eval and scaffold-free measurement

Files:

- `evals/harness_regression/strict_stress.py`

Env controls:

```bash
CEREBRAS_API_KEY=... python3 evals/harness_regression/strict_stress.py
CHIMERA_STRICT_STRESS_INCLUDE_SCAFFOLD_FREE=1 CEREBRAS_API_KEY=... python3 evals/harness_regression/strict_stress.py
```

What it measures:

- Direct raw vs direct visible/no-tests vs Chimera full-repo correctness.
- Optional scaffold-free Chimera run with `CHIMERA_DISABLE_DOMAIN_SCAFFOLDS=1`.

Decision rule:

- If scaffold-free performance matches scaffolded on a class, remove/narrow deterministic scaffold.
- If scaffold-free fails but scaffolded passes, keep scaffold as safety fallback and improve generalized repair hints.

### 5. Additional Kestrel regression measurements

Files:

- `tests/test_additional_kestrel_regressions.py`

Covers:

- camelCase edit alias normalization (`oldText` / `newText`),
- tab/space normalized edit matching,
- truncated tool-call kill switch.

Decision rule:

- These are cheap reliability wins and remain enabled.

## Validation

```text
python3 -m compileall -q chimera tests evals/harness_regression/strict_stress.py
OK

pytest tests -q
417 passed in 15.82s
```

## Remaining live measurement still requiring credentials / repeated runs

These are implemented but need periodic live measurement to make product decisions:

1. **Native compaction**
   - currently local fallback; needs provider-specific canary and recall comparison.
2. **Multi-candidate generation**
   - opt-in; needs success-lift vs token-cost measurements on stress suite.
3. **Scaffold-free repair**
   - opt-in via `CHIMERA_DISABLE_DOMAIN_SCAFFOLDS=1`; needs stress suite repetitions.
4. **Stream-time dispatch latency benefit**
   - unit-proven; needs live streaming providers emitting textual tool calls to measure hidden tool wall-time.

## Final status

The mechanisms are no longer vague future ideas. Each now has either:

- a concrete gated implementation,
- a test proving the measurement path,
- or an eval script that skips safely without credentials and runs live when authorized.

Full test suite remains green:

```text
417 passed in 15.82s
```
