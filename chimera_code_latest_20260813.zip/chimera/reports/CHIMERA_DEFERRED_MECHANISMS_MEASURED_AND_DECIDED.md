# Chimera Deferred Mechanisms — Measured and Decided

## Goal

For mechanisms previously deferred until measured benefit, gather the missing data and decide whether to enable, keep gated, or defer.

## Measurements run

### 1. Scaffold-free generalized repair measurement

Command equivalent:

```bash
CHIMERA_STRICT_STRESS_INCLUDE_SCAFFOLD_FREE=1 \
CEREBRAS_API_KEY=... \
python3 evals/harness_regression/strict_stress.py
```

Raw file:

```text
CHIMERA_REMAINING_MEASURE_STRICT_STRESS_SCAFFOLD_FREE.json
```

Result on `inventory_reconcile_hidden_edges`:

| Mode | Pass | Wall | Tokens |
|---|---:|---:|---:|
| scaffolded Chimera | yes | 1.094s | 862 |
| scaffold-free Chimera | yes | 1.042s | 832 |

Decision:

- Generalized repair is good enough on this case.
- Do **not** add more deterministic scaffolds without first running scaffold-free mode.
- Keep existing scaffolds as safety fallbacks for known brittle classes, but prefer generalized repair measurement before adding new ones.

### 2. Multi-candidate patch consensus measurement

Command equivalent:

```bash
CHIMERA_MULTI_CANDIDATE_PATCHES=3 \
CHIMERA_MULTI_CANDIDATE_TOKEN_BUDGET=4000 \
CHIMERA_MULTI_CANDIDATE_MIN_VOTES=2 \
CEREBRAS_API_KEY=... \
python3 evals/harness_regression/strict_stress.py
```

Raw file:

```text
CHIMERA_REMAINING_MEASURE_MULTI_CANDIDATE_STRICT_STRESS.json
```

Result on `inventory_reconcile_hidden_edges`:

| Mode | Pass | Wall | Tokens |
|---|---:|---:|---:|
| single-candidate reference | yes | 1.094s | 862 |
| multi-candidate consensus | yes | 119.853s | 6906 |

Decision:

- Multi-candidate consensus **does not earn default enablement**.
- It preserved correctness, but latency and token cost were far worse.
- Keep it opt-in for high-risk/flaky tasks only.

Recommended gate:

```bash
CHIMERA_MULTI_CANDIDATE_PATCHES=3
```

only when:

- task is high-risk,
- previous single-candidate attempts failed,
- token budget allows,
- latency is less important than reliability.

### 3. Stream-time dispatch benchmark

New script:

```text
evals/harness_regression/stream_dispatch_benchmark.py
```

Command:

```bash
python3 evals/harness_regression/stream_dispatch_benchmark.py
```

Raw file:

```text
CHIMERA_STREAM_DISPATCH_SYNTHETIC_BENCHMARK.json
```

Synthetic result:

```json
{
  "previous_seconds": 0.6929,
  "stream_time_seconds": 0.4429,
  "saved_seconds": 0.25,
  "tool_wall_hidden_ratio": 1.0
}
```

Decision:

- Keep read-only stream-time dispatch enabled.
- It can hide tool wall-time without speculation/misprediction.
- Writes remain blocked mid-stream.

### 4. Provider-native compaction canary / A-B recall

Already implemented measurement path:

```text
chimera/native_compaction.py
tests/test_native_compaction_canary.py
```

Decision:

- Keep local compaction fallback as default.
- Do not enable native provider compaction until a provider-specific canary and A/B recall comparison prove it is not worse.

## Implementation state after measurement

### Enabled / kept

- Generalized pytest repair loop.
- Read-only stream-time dispatch.
- Local compaction fallback.
- Scaffold-free measurement mode.

### Kept gated / opt-in

- Multi-candidate patch consensus.
- Deterministic domain scaffolds.
- Native compaction.

### Not enabled by default

- Multi-candidate consensus, due measured latency/tokens.
- Provider-native compaction, due no canary-proved support.
- Scaffold-free globally, because some previously measured tasks still rely on scaffolds.

## Files added in this measurement pass

```text
evals/harness_regression/stream_dispatch_benchmark.py
CHIMERA_DEFERRED_MEASUREMENT_DECISIONS.json
CHIMERA_STREAM_DISPATCH_SYNTHETIC_BENCHMARK.json
CHIMERA_REMAINING_MEASURE_STRICT_STRESS_SCAFFOLD_FREE.json
CHIMERA_REMAINING_MEASURE_MULTI_CANDIDATE_STRICT_STRESS.json
```

## Validation

Targeted tests:

```text
pytest tests/test_stream_time_dispatch.py tests/test_multi_candidate_patch.py tests/test_native_compaction_canary.py tests/test_pytest_repair.py -q
6 passed
```

Full validation:

```text
python3 -m compileall -q chimera tests evals/harness_regression/strict_stress.py evals/harness_regression/stream_dispatch_benchmark.py
OK

pytest tests -q
420 passed in 16.00s
```

## Final decision table

| Mechanism | Measured result | Decision |
|---|---|---|
| Scaffold-free generalized repair | Passed measured inventory stress case with slightly lower wall/tokens | Use as measurement mode before adding new scaffolds; do not globally force yet |
| Multi-candidate consensus | Passed but ~110x wall and ~8x tokens vs single candidate on measured case | Keep opt-in only |
| Stream-time dispatch | Synthetic benchmark hid 100% of simulated tool wall-time | Keep enabled for read-only stream dispatch |
| Native compaction | No provider-native canary-proved support yet | Keep local fallback |

## Final status

```text
420 passed in 16.00s
```
