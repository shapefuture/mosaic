# Chimera Remaining Underimplemented Backlog

> **Implementation delta:** `IMPLEMENTATION_UPDATE_2026-08-11.md` and
> `REMAINING_IMPLEMENTATION_UPDATE_2026-08-11.md` record the subsequent
> snapshot-bound semantic port/LSP lifecycle, real atomic tool-schema mapping
> producer with optional trusted Ed25519 verification, deterministic Hypothesis
> state machines, and Dynamic-TIA promotion-accounting/drift work. The audit
> below is retained as the pre-implementation baseline; its evidence-dependent
> and platform-dependent gaps remain valid unless the update explicitly says otherwise.

**Date:** 2026-08-11  
**Purpose:** distinguish (1) high-value work that remains genuinely underimplemented, (2) work blocked by missing evidence or host capability, and (3) mechanisms intentionally kept out of the default path.

## Current proved local baseline

| Surface | Current bounded evidence | What it does **not** prove |
|---|---|---|
| Dynamic TIA | 30/30 curated real-source mutations detected; median focused/full duration ratio `0.2714115`; fail-closed dynamic map | Default focused-only verification, different environments, reflection/subprocess/data-file changes, held-out corpus recall |
| xdist | Local loadscope benchmark reduced current-suite wall time in earlier evidence; explicit opt-in only | Other repositories, tenant isolation, flaky/ordering safety on arbitrary suites |
| DBOS | Disposable Postgres same-ID checkpoint, crash/effect simulation, queue concurrency, pool probe | Production DBOS adapter, multi-node recovery, real effects/provider semantics, queue sizing |
| Bubblewrap | Materialized filesystem/network/process matrix passed | Overlay mode, allowlisted egress, microVM/container isolation, adversarial-host threat model |
| Python CodeGraph vs ast-grep | Narrow Python and extended TypeScript structural fixtures measured | Default replacement, semantic references, actual coding-task gain |
| Pyright LSP | Five isolated Python semantic fixture runs: definitions, references, imports, calls, config exclusions, live changes | Full Chimera repository outcome, TypeScript/cross-language support, runtime adapter safety |
| TypeScript LSP | Five isolated runs: TS semantic navigation, call hierarchy, declaration/source map navigation | Python-to-TypeScript provenance, full monorepo behavior, runtime adapter safety |
| Explicit generated map | Five byte-bound source/generated fixture runs; source/generated/evidence drift rejected | Real project generator integration, signed producer identity, semantic equivalence, SCIP encoding |

## Priority 0 — implementable now, highest value

### 1. Dynamic-TIA promotion-quality evidence

**Status:** mechanically strong but not yet promotion-quality.

Remaining work:

- Create a held-out mutation partition that was not used to develop the 30-case corpus.
- Run environment variants: Python/package/version flags, changed tests, fixtures, generated files, static assets, dynamic imports, subprocesses, and reflection.
- Add periodic full-suite agreement checks and stale-map rebuild drills.
- Record false negatives, fallback frequency, selected-test count, and p50/p95 speed—not just successful curated mutants.
- Feed all paired results through `DataEvidenceGate`; preserve manual-only promotion even if accepted.

**Acceptance:** held-out recall and constitutional/protected floors stay at the declared threshold with a real speed gain.  
**Kill:** any missed full-suite regression or map reuse across unclaimed drift.

### 2. Read-only semantic code-intelligence adapter experiment

**Status:** candidates are benchmarked but no adapter exists.

Remaining work:

- Add an explicit `SemanticCodeIntelligencePort`, isolated subprocess/LSP lifecycle manager, and typed read-only request/receipt schema.
- Keep the current `CodeGraph` as deterministic fallback.
- Define an actual Chimera held-out navigation corpus with natural-language intent plus exact definitions/references/imports/call paths.
- Measure actual tokenizer output, context precision/recall, LSP startup, warm-session behavior, RSS, stale workspace state, malformed code, timeout/cancellation, and bwrap teardown.
- Require source snapshot identity in every semantic query; reject results if the workspace changes before consumption.

**Acceptance:** non-regressing held-out retrieval correctness under a fixed context budget and safe failure to local CodeGraph.  
**Kill:** stale results, unsupported requests treated as facts, any write/MCP/provider authority, or token/latency regression.

### 3. Real generator integration for explicit mappings

**Status:** the contract/verifier/index are implemented, but the producer is only a fixture generator.

Remaining work:

- Pick a real generator in a Chimera-managed repository path.
- Emit `GeneratorMappingContract` atomically alongside generated output from that generator.
- Bind mapping evidence to a pinned generator binary/image, generator arguments, input manifest, output manifest, and build receipt.
- Add a signed/in-toto or equivalent producer-attestation path before any shared/remote use.
- Add a *read-only* consumer bridge to a semantic index only after mapping-version and stale-map tests pass.

**Acceptance:** a real generator produces verified source/generated links, and drift of source, generated output, command, mapping, or evidence refuses resolution.  
**Kill:** comments, paths, or text search create a provenance edge without a verified contract.

### 4. Stateful/property/fuzz reliability lane

**Status:** ordinary tests and bounded lifecycle checks exist; systematic operation-sequence campaigns do not.

Remaining work:

- Use Hypothesis state machines for local VFS/WAL, outbox/inbox, leases, task-slice ownership, tenant quota, and generated-map verification.
- Store minimized deterministic counterexamples as ordinary regression tests after review.
- Add Atheris only for narrow parser/decoder targets after a seed corpus, execution cap, and crash triage process are defined.
- If native code is introduced, run AddressSanitizer/UBSan in a dedicated disposable runner.

**Acceptance:** sequence invariants hold and any minimized failing trace is reproducible.  
**Kill:** fuzz/property machinery reaches effects, provider credentials, external endpoints, or becomes auto-generated authority.

## Priority 1 — important adapters with enough local foundation

### 5. DBOS durable adapter, not merely the compatibility matrix

**Status:** `LocalDurableWorkflowPort` is authoritative locally; DBOS has evidence only as a disposable spike.

Remaining work:

- Implement optional `DBOSDurableWorkflowPort` behind `DurableWorkflowPort`.
- Run the shared contract suite for start/checkpoint/recover/wait/finish/cancel/version drift.
- Preserve Chimera outbox unknown outcomes and caller-supplied idempotency keys around all external work.
- Test recovery under Postgres restart, executor restart, duplicate workflow IDs, cancellation race, ambiguous effect, queue contention, and connection starvation.

**Acceptance:** same contract receipt shape as local port plus no weakened unknown-outcome handling.  
**Kill:** checkpointing is misrepresented as generic exactly-once external delivery.

### 6. Restate comparison

**Status:** SDK installed in prior evidence; no server/runtime run.

Remaining work:

- Obtain a pinned Restate server in a disposable runner.
- Run the exact DBOS/local matrix: crash, effects, provider ambiguity, queue saturation, pooling, cancellation, version drift, and tenant propagation.
- Compare behavior, not vendor claims.

**Acceptance:** reproducible receipts for the same fixture.  
**Kill:** SDK import or documentation is reported as an execution result.

### 7. Queue selection and pool capacity

**Status:** bounded DBOS queue/pool evidence exists; no deployment load model exists.

Remaining work:

- Predeclare workload levels at 1/4/16/64/100 workers with service-time distributions and failure modes.
- Compare DBOS queue against a single chosen alternative only when job semantics demand it: competing work vs durable fan-out vs low-latency event stream.
- Test claim expiry, retry storms, queue drain, fairness, dead-letter handling, restore, and idempotent effects.
- Only then test PgBouncer with direct/session listener carve-outs for `LISTEN`, persistent `SET`, temp tables, and session advisory locks.

**Acceptance:** one adapter meets declared semantics and load SLO with correct unknown-effect behavior.  
**Kill:** stacked queues/pools are adopted because they sound scalable.

### 8. Semantic SCIP producer/consumer

**Status:** Python and TypeScript semantic LSP candidates are benchmarked; no SCIP index has been emitted or queried.

Remaining work:

- Pin a SCIP producer and consumer independently.
- Generate an index from a real, disposable project snapshot.
- Verify index provenance, source snapshot identity, index size/build latency, definitions/references/imports, stale index invalidation, and query behavior.
- Define a versioned encoding for verified `GeneratorMappingContract` edges only after a mapping/query corpus validates it.

**Acceptance:** exact index/source identity and non-regressing held-out semantic retrieval.  
**Kill:** plain generated-code comments or an index with stale source is treated as precise navigation.

## Priority 2 — platform, tenant, release, and operational work

### 9. Tenant propagation and authorization

**Status:** opaque local workspaces and independent quotas are proven only at workspace level.

Remaining work:

- Carry immutable `TenantContext` through CLI, RPC, MCP, scheduler, durable workflows, sandbox leases, artifact/CAS paths, and every audit receipt.
- Add authenticated principal → tenant authorization at transport boundaries.
- Test attempted cross-tenant artifact reads, branch snapshots, generated-map lookups, LSP sessions, queue claims, and provider budgets.
- Evaluate SPIFFE/SPIRE or another workload-identity system only in an actual deployment; do not treat opaque paths as auth.

**Acceptance:** a tenant cannot influence or read another tenant at any transport boundary.  
**Kill:** a global/default tenant or an unauthenticated `tenant_id` label reaches an authority path.

### 10. Release provenance and consumer verification

**Status:** bundle hashes and CAS provenance exist; no signed release workflow or SBOM/VEX drill exists.

Remaining work:

- Generate reproducible release manifest, SBOM, and provenance attestation in CI.
- Pin verification identity; verify tamper, missing-step, wrong-builder, and dependency-drift failures.
- Add consumer-side verification before deployment/install—not merely producer-side generation.

**Acceptance:** tampered or mismatched release artifacts are refused.  
**Kill:** a checksum alone is treated as origin/build provenance.

### 11. OpenTelemetry/operational evidence

**Status:** dependency-free OTLP-shaped export exists; no actual collector/export/fault campaign exists.

Remaining work:

- Normalize local agent/model/tool/sandbox/verification receipts into privacy-minimal GenAI-shaped spans.
- Test redaction, truncation, trace propagation, no-prompt leakage, exporter outage, duplicate delivery, and tail-sampling memory caps.
- Keep external export independently opt-in and outbox-backed.

**Acceptance:** errors/slow runs are observable without leaking prompt, source, credential, or tenant data.  
**Kill:** telemetry transport success becomes a durable-delivery claim.

### 12. Sandbox ladder beyond materialized Bubblewrap

**Status:** materialized Bubblewrap is certified; overlay mode and stronger backends are not.

Remaining work:

- Complete overlay matrix: existing-file writes, new files, deletions, symlink escape, Python imports, `/proc`/`/sys`/home denial, process-tree cleanup, network denial, and output containment.
- Design/test a DNS-aware egress path only on a deployment where every route is forced through it and bypass/IMDS tests exist.
- Evaluate gVisor/Kata/Firecracker only on a host with an actual container runtime and/or `/dev/kvm`.
- Test Landlock network rules only on a host ABI that supports them.

**Acceptance:** each backend gets its own host-specific receipt.  
**Kill:** namespace/process isolation is called a microVM or allowlisted egress without evidence.

## Priority 3 — profile-gated polyglot and self-hosted work

### 13. Polyglot plan substrates

**Status:** P0 contracts exist; Rust/Zig/BEAM implementations do not.

Remaining work:

- Profile real branch/VFS, materialization, hashing, graph, sandbox, and ledger workloads first.
- Select one physical hot path and build a mirror-tested implementation behind `polyglot_contracts`.
- Compare Python and candidate across output equivalence, crash recovery, path safety, RSS, CPU, startup, portability, and end-to-end coding-task effect.
- Ship no native adapter as authority until the mirror suite and measured gain pass.

**Acceptance:** a profiled bottleneck gains materially without semantic/safety regression.  
**Kill:** “Rust/BEAM/Zig is faster” replaces a measured workload hypothesis.

### 14. Self-hosted inference/cache locality

**Status:** no GPU/NPU runtime, model workload, or self-hosted server evidence exists.

Remaining work:

- Obtain a GPU runner and sealed representative prompt trace set.
- Benchmark a simple single-server baseline before prefix cache, router, remote KV cache, or prefill/decode disaggregation.
- Measure TTFT, ITL, throughput, cache hit/read telemetry, GPU memory, queue delay, cancellation, and failures under equal traffic.
- Preserve explicit concrete model authority even in a literal `auto` experiment.

**Acceptance:** repeated held-out workload gain with route telemetry.  
**Kill:** hosted-provider results are used as self-hosted cache/router evidence.

## Intentionally not a “remaining implementation” item

These remain disabled by policy until entirely new evidence and explicit authorization exist:

- silent model switching, generic hedging, provider failover, and billable duplicate calls;
- semantic response caching for coding/effectful work;
- broad model-generated tests/skills/policies/tools gaining authority;
- CRDT work claims, approvals, promotion state, or branch authority;
- broad/global approval;
- arbitrary model-generated command execution;
- cloud delivery, multi-tenancy, or microVM claims without deployment evidence.

## Recommended next sequence

1. Dynamic-TIA held-out/environment campaign.
2. Read-only semantic adapter contract and held-out actual Chimera retrieval corpus.
3. Real generator producer that emits verified mapping contracts.
4. Hypothesis stateful campaign over authority boundaries.
5. DBOS adapter contract suite, then Restate comparison on a pinned runtime.
6. Queue/pool load decision after real workload data.
