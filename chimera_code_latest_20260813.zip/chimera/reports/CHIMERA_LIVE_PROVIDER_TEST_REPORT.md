# Chimera Live Provider Test Report

## Direct answer

I attempted to set up and run live provider probes for:

- TokenRouter / Kimi
- Cerebras OSS / OpenAI-compatible
- Gemini / Google

No live API call was made because no usable credentials were present in the environment or files.

The probe result was:

```json
[
  {
    "provider": "tokenrouter-kimi",
    "model": "tokenrouter/moonshotai/kimi-k3-free",
    "status": "skip",
    "reason": "missing credential env TOKENROUTER_API_KEY"
  },
  {
    "provider": "cerebras-oss",
    "model": "cerebras/llama-4-scout-17b-16e-instruct",
    "status": "skip",
    "reason": "missing credential env CEREBRAS_API_KEY"
  },
  {
    "provider": "gemini",
    "model": "gemini/gemini-1.5-flash",
    "status": "skip",
    "reason": "missing credential env ('GEMINI_API_KEY', 'GOOGLE_API_KEY')"
  }
]
```

## What I changed so the live tests are ready

### 1. Added live provider probe module

New file:

```text
chimera/live_provider_probe.py
```

It runs minimal redacted live connectivity probes. It does not persist prompts, completions, or credentials.

Run it with:

```bash
python3 -m chimera.live_provider_probe
```

### 2. Added TokenRouter provider support

Files changed:

- `chimera/providers.py`
- `chimera/rlm_primitives.py`
- `chimera/rlm_provider.py`

Supported model form:

```text
tokenrouter/moonshotai/kimi-k3-free
```

Required env:

```bash
export TOKENROUTER_API_KEY=...
```

Endpoint:

```text
https://api.tokenrouter.com/v1
```

### 3. Strengthened direct Cerebras routing

Files changed:

- `chimera/providers.py`
- `chimera/rlm_provider.py`

Supported model form:

```text
cerebras/llama-4-scout-17b-16e-instruct
```

Required env:

```bash
export CEREBRAS_API_KEY=...
```

Endpoint:

```text
https://api.cerebras.ai/v1
```

### 4. Added direct Gemini adapter

Files changed:

- `chimera/providers.py`
- `chimera/rlm_provider.py`

Supported model form:

```text
gemini/gemini-1.5-flash
```

Required env, either:

```bash
export GEMINI_API_KEY=...
```

or:

```bash
export GOOGLE_API_KEY=...
```

Endpoint:

```text
https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent
```

### 5. Added tests

New test file:

```text
tests/test_live_provider_probe.py
```

It verifies:

- missing credentials produce clean skips,
- direct provider prefixes do not route through OpenRouter by accident:
  - `tokenrouter/...` -> `tokenrouter`
  - `cerebras/...` -> `cerebras`
  - `gemini/...` -> `google` / Gemini adapter

## Credential search result

I checked environment names and scanned candidate files without printing any secrets.

Result:

```json
{
  "candidate_secret_counts": {
    "google_api_key_like": 0,
    "openai_like": 0,
    "generic_assignment": 0
  },
  "files_with_candidates_redacted": []
}
```

So I did not find keys embedded in files.

## Test results after changes

```text
pytest tests/test_live_provider_probe.py tests/test_prime_strengths.py -q
10 passed

python3 -m chimera.live_provider_probe
all three providers skipped due missing credentials

pytest tests -q
390 passed in 16.06s

python3 -m compileall -q chimera tests
OK

python3 -m chimera health | python3 -m json.tool
OK
```

## How to run actual live calls

Set one or more keys, then run:

```bash
TOKENROUTER_API_KEY=... python3 -m chimera.live_provider_probe
```

or:

```bash
CEREBRAS_API_KEY=... python3 -m chimera.live_provider_probe
```

or:

```bash
GEMINI_API_KEY=... python3 -m chimera.live_provider_probe
```

You can also set multiple keys and it will probe all configured providers.

## Current status

- Live provider adapters/probes are implemented.
- TokenRouter, Cerebras, and Gemini direct routing are ready.
- No live quota was consumed because credentials were not present.
- Full test suite remains green: `390 passed`.
