# Chimera Long-Term Quality + Certified Hedge Improvement Report

## Request

Improve the long-term quality path:

- keep generalized pytest repair loop,
- reduce reliance on deterministic benchmark-specific scaffolds over time,
- add more failure-pattern-to-hint extraction,
- feed structured pytest diffs and current source into a small local repair planner before calling the provider again,
- test/compare certified hedge routing vs previous design for speed/latency/tokens.

## Implemented quality improvements

### 1. Structured pytest repair planner

File:

```text
chimera/pytest_repair.py
```

Expanded from simple hint extraction to a structured local repair planner:

```python
extract_repair_hints(stdout, stderr) -> RepairHints
build_local_repair_plan(target_path, current_source, stdout, stderr) -> LocalRepairPlan
```

`RepairHints` now includes:

- `hints`
- `anchors`
- `failing_inputs`
- `assertion_snippets`

The extractor now catches more patterns:

- expected exception not raised,
- value/schema assertion mismatch,
- missing import/symbol,
- missing module,
- parser rejected valid edge input,
- missing dictionary key,
- type/signature errors,
- expected-vs-actual pytest diffs,
- CLI command missing.

### 2. Local repair plan is fed before provider retry

File:

```text
chimera/rlm_coder_focused.py
```

During repair, before calling the provider again, Chimera now builds and injects:

```text
LOCAL REPAIR PLAN (deterministic, from pytest + current branch source)
```

It includes:

- target path,
- failing pytest anchors,
- structured repair hints,
- quoted values seen in failure output,
- assertion snippets,
- current branch source tail.

This directly addresses the prior limitation: repairs are now based on structured pytest diffs + current source instead of raw noisy stdout alone.

### 3. Deterministic scaffolds can now be disabled

File:

```text
chimera/rlm_coder_focused.py
```

Added workaround / long-term migration switch:

```bash
CHIMERA_DISABLE_DOMAIN_SCAFFOLDS=1
```

When set, domain-specific deterministic scaffolds are disabled and repair depends on the generalized repair loop. This helps reduce long-term reliance on benchmark-specific scaffolds while preserving them as safety/fallback machinery when needed.

### 4. Repair round control remains available

```bash
CHIMERA_MAX_REPAIR_ROUNDS=1   # lower latency/cost
CHIMERA_MAX_REPAIR_ROUNDS=2   # default
CHIMERA_MAX_REPAIR_ROUNDS=3   # harder hidden-test repair
```

## Certified hedge routing improvements

### 1. Hedge over-trigger protection

File:

```text
chimera/rlm_provider.py
```

The first live hedge benchmark showed that setting a very low primary budget, e.g. `0.05s`, over-triggered Gemini and worsened latency. I added a minimum primary budget clamp:

```bash
CHIMERA_MIN_PRIMARY_BUDGET_SECS=0.25
```

Default behavior:

```text
budget = max(0.05, CHIMERA_MIN_PRIMARY_BUDGET_SECS, CHIMERA_PRIMARY_BUDGET_SECS)
```

This prevents pathological over-hedging on healthy Cerebras calls, while still allowing tests/operators to lower the floor explicitly.

### 2. Hedge routing remains opt-in and guarded

Hedge only applies when:

```bash
CHIMERA_CERTIFIED_ROUTE=1
CHIMERA_HEDGE_MODEL=gemini-3.5-flash-lite
```

and only when no native tools / strict JSON controls are active, to avoid breaking stateful tool-call semantics.

## Live hedge benchmark: previous vs new

### Initial comparison before clamp

File:

```text
CHIMERA_HEDGE_VS_PREVIOUS_BENCHMARK.json
```

Three runs each:

| Mode | p50 wall | avg tokens | Chosen provider |
|---|---:|---:|---|
| previous/no hedge | 0.293s | 100 | Cerebras |
| hedge budget 0.05 | 1.940s | 18 | Gemini |
| hedge budget 0.8 | 0.334s | 100 | Cerebras |

Finding:

- `0.05s` budget was too aggressive and worsened p50 latency.
- `0.8s` default preserved primary Cerebras path with negligible overhead.

### After clamp

File:

```text
CHIMERA_HEDGE_VS_PREVIOUS_BENCHMARK_AFTER_CLAMP.json
```

Single live sample per mode after adding the `0.25s` default minimum:

| Mode | wall | tokens | provider | route |
|---|---:|---:|---|---|
| previous/no hedge | 0.274s | 102 | Cerebras | none |
| hedge requested 0.05, clamped | 0.173s | 99 | Cerebras | primary, budget_s=0.25 |
| hedge default 0.8 | 0.237s | 99 | Cerebras | primary, budget_s=0.8 |

Interpretation:

- The clamp prevents unnecessary Gemini hedge launches during healthy Cerebras responses.
- New design is effectively as fast as previous design on healthy primary path.
- Hedge remains useful only when Cerebras is slow/hot beyond budget.

## Tests added/updated

### New/expanded tests

```text
tests/test_pytest_repair.py
tests/test_certified_hedge.py
```

`test_certified_hedge.py` explicitly lowers `CHIMERA_MIN_PRIMARY_BUDGET_SECS` for the fake slow-primary test so the hedge path is still tested deterministically.

### Validation

```text
pytest tests/test_pytest_repair.py tests/test_stress_improvements.py -q
4 passed

pytest tests/test_certified_hedge.py -q
1 passed

python3 -m compileall -q chimera tests evals/harness_regression/strict_stress.py
OK

pytest tests -q
398 passed in 16.17s
```

## Current recommended settings

### Fast certified production path

```bash
CHIMERA_CERTIFIED_ROUTE=1
CHIMERA_HEDGE_MODEL=gemini-3.5-flash-lite
CHIMERA_PRIMARY_BUDGET_SECS=0.8
CHIMERA_MIN_PRIMARY_BUDGET_SECS=0.25
CHIMERA_REASONING_EFFORT=low
```

### Hard hidden-test repair mode

```bash
CHIMERA_MAX_REPAIR_ROUNDS=3
```

### Scaffold-free experimental mode

```bash
CHIMERA_DISABLE_DOMAIN_SCAFFOLDS=1
```

Use this mode to measure how well the generalized repair loop performs without benchmark-specific deterministic fallbacks.

## Result

The long-term direction is now implemented:

- more general repair signals,
- local structured repair plan before provider retry,
- deterministic scaffolds can be disabled,
- hedge routing is protected from over-triggering,
- live latency/tokens comparison was measured,
- full suite remains green.

Final status:

```text
398 passed in 16.17s
```
