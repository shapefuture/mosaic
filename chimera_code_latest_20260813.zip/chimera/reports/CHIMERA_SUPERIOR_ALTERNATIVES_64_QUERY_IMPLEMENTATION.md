# Chimera: 64-Query Alternatives Review and Implemented Upgrade

**Date:** 2026-08-11  
**Scope:** v3, v3.1, the existing alternatives addenda, the polyglot rewrite plan, a fresh 64-query research pass, and host-local implementation/evidence.  
**Rule:** an installed package, an upstream claim, or a benchmark from another workload is a candidate signal—not proof that Chimera is better.

## Executive decision

The strongest immediately actionable improvement was **coverage-backed Test Impact Analysis (TIA)**, not a wholesale infrastructure rewrite:

- It directly targets a measured local bottleneck: verification wall time.
- It can be tested against real Chimera mutations without provider, GPU, cloud, or external queue claims.
- It preserves the existing full-suite/protected-test authority and fail-closed fallback.

Implemented this turn:

1. A reusable real-source dynamic-coverage mutation evaluator.
2. A 30-case Chimera source-mutation corpus.
3. An advisory CLI surface: `chimera impact select --workspace . <changed-path>...`.
4. A literal-context escaping repair in `DynamicCoverageCollector` for parametrized pytest node IDs containing regex metacharacters.
5. Regression tests for the repaired collector and high-risk boundary invariants.
6. P0 typed polyglot transport envelopes from the polyglot plan, with no new adapter authority or daemon.

No automatic model switch, generic semantic cache, generic hedging, arbitrary generated-code execution, DBOS production migration, Restate claim, cloud delivery claim, microVM claim, or self-hosted inference claim was enabled.

## Actual dynamic-TIA evidence

Evaluator:

```text
evals/deferred_feature_evidence/dynamic_coverage_real_mutation_calibration.py
```

Corpus:

```text
evals/deferred_feature_evidence/chimera_dynamic_coverage_real_mutation_corpus_v1.json
```

Receipt:

```text
artifacts/dynamic_coverage_real_mutation_calibration.json
```

### Run facts

| Measure | Observed result |
|---|---:|
| Coverage baseline | 33,988.332 ms |
| Dynamic coverage contexts mapped | 177 test files / 3,758 test-to-source path observations |
| Curated real-source mutations requested | 30 |
| Mutations exposed by independent full suite | 30/30 |
| Focused dynamic selections that exposed the same mutation | 30/30 |
| Dynamic detection recall in this corpus | 1.0 |
| Expected-test file present in selection | 1.0 |
| Median focused/full wall-time ratio | 0.2714115 |
| Median local wall-time reduction on this corpus | 72.8589% |
| Automatic promotion | false |

This is meaningful local evidence that dynamic coverage selection can reduce verification wall time on this repository while catching this particular 30-case corpus. It is **not** a general safety or superiority claim.

### Why it remains advisory

The following are still required before a human could even consider default focused-only verification:

- held-out mutation cases not used to construct this corpus;
- changed test, environment, dependency, fixture, reflection, generated-code, subprocess, and static-asset cases;
- repeated runs on additional hosts/OS/Python configurations;
- periodic independently scheduled full-suite agreement;
- a safety-adjusted decision under `DataEvidenceGate`.

The selector remains fail-closed: missing map, stale test/environment fingerprint, unclaimed source drift, or unmapped changed source path returns `pytest -q`.

### Collector repair found by the campaign

Coverage.py interprets context queries as regular expressions. Parameterized pytest IDs may contain `[]()` and similar metacharacters; passing the literal context directly caused a `coverage.exceptions.DataError` during a real full-Chimera coverage collection. `DynamicCoverageCollector` now uses `re.escape(context)` before querying. The new regression test proves a parametrized literal context still maps its test file to the source file.

## Polyglot rewrite plan: worthy work now vs. blocked work

The plan was found at:

```text
/home/user/chimera_new/CHIMERA_POLYGLOT_REWRITE_PLAN.md
```

### Worthy now: P0 contract boundary

Added `chimera/polyglot_contracts.py`, with stable v1 typed envelopes for:

- content-addressed VFS operations;
- sandbox execution requests;
- optimistic ledger append requests;
- explicit-model provider-call requests;
- session-state projections.

The contracts deliberately reject host-root paths, traversal, inline secret material, unbounded/invalid environment names, and VFS writes without a content-addressed blob reference. They only validate/hash data. They do not execute commands or become a second authority plane.

This is a useful parallel-development boundary: a Rust VFS, Rust/Zig sandbox helper, BEAM supervisor, or provider gateway can mirror-test the same JSON envelopes against the Python reference before any migration is proposed.

### Not worthy to rewrite yet

| Proposal | Decision now | Evidence gap / reason |
|---|---|---|
| Rust `chimera-vfs` as authority | Defer | No profile showing branch/VFS operations dominate the real agent workload; no Rust toolchain/binary conformance campaign; Python WAL/CAS remains current authority. |
| Rust/Zig `sandboxd` | Defer, keep P0 schema | Materialized Bubblewrap is certified; overlay remains unverified; no gVisor/KVM/Firecracker host. Need parity, escape, teardown, resource-accounting, and command-proof tests. |
| Rust codegraph | Candidate, not adopted | Current Python graph needs a sealed own-repository retrieval/token/latency/RSS comparison before a third-party/index rewrite. SCIP/LSP can improve precise navigation, but requires a real indexer/build integration. |
| Rust ledger + Postgres/NATS/S3 | Defer | Local WAL/CAS and disposable DBOS evidence exist, but no multi-writer restore/load/partition drill or deployed service evidence. |
| BEAM session/provider supervisor | Defer | It would add another operational control plane before workload data demonstrates Python managed-process supervision is insufficient. |
| Provider gateway failover/hedging | Reject as generic default | Violates explicit model choice and still lacks provider cancellation/billing proof. |
| DeltaFS/O(1) checkpoints | Defer | No host capability/evidence or measured materialization bottleneck beyond current tests. |

## Fresh alternatives research: query ledger

Exactly **64 queries** were executed, eight in each area.

### Durable execution, testing, and TIA

1. `site:docs.dbos.dev DBOS workflow recovery step idempotency external effects queue concurrency`
2. `site:docs.restate.dev Python workflows durable execution idempotency retry external calls`
3. `site:docs.temporal.io durable execution activity idempotency external side effects retries`
4. `site:docs.pytest.org pytest-xdist loadscope scheduling isolation documentation`
5. `pytest-testmon documentation test selection dependency tracking limitations`
6. `coverage.py dynamic contexts pytest coverage context test documentation`
7. `Google Bazel test selection analysis cache remote execution test impact analysis documentation`
8. `Buildkite test engine test splitting timing flaky test retries documentation`

### Sandboxing, identity, and isolation

9. `Bubblewrap documentation user namespaces network namespace bind mounts sandbox security`
10. `Landlock Linux kernel documentation filesystem network access rules ABI`
11. `gVisor documentation security isolation containers threat model performance`
12. `Kata Containers documentation isolation virtual machines container runtime`
13. `Firecracker microVM documentation KVM requirements security isolation`
14. `WASI filesystem network sandbox capability security wasi preview 2 documentation`
15. `nsjail documentation network namespace cgroup filesystem sandbox`
16. `CNCF SPIFFE SPIRE workload identity multi tenant service authentication documentation`

### Code intelligence and retrieval

17. `tree-sitter incremental parsing documentation performance code intelligence`
18. `Language Server Protocol specification workspace symbols call hierarchy definition references`
19. `SCIP code intelligence index format sourcegraph documentation`
20. `Kythe code index cross references graph documentation`
21. `ast-grep documentation structural code search rules performance`
22. `ripgrep README performance benchmarks searching code memory mmap`
23. `universal ctags documentation code index symbols language support`
24. `Sourcegraph Cody context retrieval code graph documentation embeddings search`

### Polyglot/native runtime options

25. `Python documentation cProfile profile optimization performance benchmark first`
26. `mypyc documentation performance compilation limitations Python modules`
27. `Cython documentation performance profiling pure Python extension modules`
28. `PyO3 maturin documentation Rust Python extension performance safety`
29. `Python HPy universal C API documentation extensions migration`
30. `Python free threading documentation extension modules GIL performance 3.13`
31. `Python multiprocessing shared memory documentation resource tracker performance`
32. `Apache Arrow Flight Python Rust interoperability zero copy documentation`

### Self-hosted inference and cache locality

33. `vLLM documentation prefix caching automatic prefix caching metrics`
34. `SGLang documentation RadixAttention cache aware routing disaggregated prefill`
35. `NVIDIA Dynamo documentation disaggregated prefill decode inference serving`
36. `llm-d Kubernetes inference scheduling kv cache aware routing documentation`
37. `LMCache documentation KV cache reuse distributed inference`
38. `Mooncake KV cache disaggregated serving documentation`
39. `OpenAI API prompt caching documentation cached tokens responses`
40. `Anthropic prompt caching documentation cache read input tokens`

### Queues, pooling, and observability

41. `PostgreSQL SKIP LOCKED documentation queue concurrency pattern`
42. `PgBouncer documentation transaction pooling LISTEN SET advisory locks limitations`
43. `PGMQ Postgres message queue visibility timeout documentation`
44. `PgQue Postgres queue event queue documentation batching fanout`
45. `NATS JetStream exactly once consumer deduplication documentation`
46. `Apache Kafka idempotent producer exactly once semantics documentation`
47. `OpenTelemetry semantic conventions AI agent tracing GenAI spans documentation`
48. `OpenTelemetry tail sampling documentation traces sampling policies`

### Verification, mutation, fuzzing, provenance

49. `Hypothesis Python property based testing stateful testing documentation`
50. `Atheris Python fuzzing coverage guided documentation`
51. `libFuzzer continuous fuzzing OSS-Fuzz best practices corpus coverage`
52. `mutation testing Python mutmut documentation incremental mutation testing`
53. `pytest-rerunfailures documentation flaky tests retries false confidence`
54. `NIST SSDF software supply chain SBOM provenance SLSA build attestation documentation`
55. `in-toto supply chain layout link metadata verification documentation`
56. `Sigstore cosign keyless signing verification artifacts documentation`

### Policy, formal methods, security, and contracts

57. `MCP specification security authorization sampling tool annotations documentation`
58. `Open Policy Agent policy as code decision logs bundle signatures documentation`
59. `Cedar policy language authorization verification schema documentation`
60. `TLA+ model checking distributed workflow queue idempotency testing documentation`
61. `Python CrossHair symbolic execution contracts documentation`
62. `Semgrep supply chain code security taint analysis documentation`
63. `CodeQL Python security analysis database query documentation`
64. `Pact contract testing consumer driven APIs documentation verification`

## What the 64-query pass changes

### High-value candidates retained

1. **Dynamic coverage TIA** — implemented and calibrated above.
2. **Read-only precise code intelligence** — strongest next token/latency experiment. Tree-sitter/SCIP/LSP/ast-grep offer complementary structural navigation, but only a sealed Chimera question corpus can establish retrieval recall, index time, update time, RSS, token cost, and stale-index behavior.
3. **Property/stateful testing for ledger, VFS and admission invariants** — low-risk next reliability lane. Hypothesis can generate operation sequences; it must remain deterministic and branch-local.
4. **Fuzzing parsers and native helpers** — only after defining narrow fuzz targets and a reproducible corpus. Atheris/ASan are appropriate for parser/decoder/native extension edges, not a license for fuzzing external effects.
5. **Release provenance** — a local verification envelope plus future signed in-toto/Sigstore release provenance is worthwhile once there is a CI identity and release workflow. No signing service was invented here.
6. **OpenTelemetry GenAI-shaped receipts** — useful as an optional local schema/export normalization. Remote export remains opt-in and requires its own egress/delivery evidence.

### Candidates explicitly kept out of the default path

- Automatic tier classifiers, model switching, provider failover, hedging, and semantic coding caches.
- pg_crdt authority state, speculative duplicate effects, Hatchet stacking, and unmeasured queue replacement.
- PgBouncer transaction pooling without direct/session listener carve-outs and a deployed pool load test.
- gVisor/Kata/Firecracker/WASI as local claims without their host/runtime evidence.
- vLLM/SGLang/Dynamo/llm-d/LMCache/Mooncake without a GPU and actual self-hosted workload.
- NATS/Kafka/PGMQ/PgQue as a replacement for current authority before queue semantics and outage/load evidence choose one.

## Source anchors for decisions

- DBOS documents recovery from the last completed step and still requires idempotent steps for interrupted external work: <https://docs.dbos.dev/architecture>
- Coverage.py dynamic contexts are explicitly designed to answer “what test ran this line?”: <https://coverage.readthedocs.io/en/7.10.7/contexts.html>
- Testmon documents untracked categories such as static files and external services, supporting the full-suite fallback: <https://www.testmon.org/>
- Tree-sitter is useful for syntax structure but has grammar/pathological-input limits: <https://github.com/github/semantic/blob/main/docs/why-tree-sitter.md>
- SCIP supports precomputed definitions/references but needs a genuine indexer: <https://sourcegraph.com/docs/code-navigation/writing-an-indexer>
- Python 3.13 free-threading is experimental and can impose a substantial single-thread overhead: <https://docs.python.org/3.13/howto/free-threading-python.html>
- Node’s own WASI documentation says not to treat `node:wasi` as secure sandboxing for untrusted code: <https://nodejs.org/api/wasi.html>
- PgBouncer transaction mode breaks persistent session features such as `LISTEN/NOTIFY` and session advisory locks: <https://neon.com/docs/connect/connection-pooling>
- JetStream documents at-least-once delivery and acknowledges redelivery, preserving the need for idempotent consumers: <https://docs.nats.io/concepts/jetstream>
- MCP requires user consent/control and treats tools as arbitrary code execution: <https://modelcontextprotocol.io/specification/2025-03-26>

## Next evidence-gated work

1. Build a sealed 30+ question code-navigation corpus, then compare current Python AST graph against a pinned, read-only structural candidate. Do not use a third-party indexer as default before recall/non-regression/RSS/egress results.
2. Add dynamic-TIA calibration for changed tests, dependencies, data files, reflection/dynamic imports, subprocesses, and environment variations; include held-out mutations and periodic full-suite agreement.
3. Run Hypothesis stateful models over local VFS/WAL/outbox/tenant quota transitions; retain generated counterexamples as tests only after deterministic review.
4. Install/benchmark a native substrate only after a profiler names a physical bottleneck. A Rust rewrite is not assumed to improve a provider-bound coding-agent run.
5. Obtain a pinned Restate runtime only on a disposable runner, then run the same DBOS compatibility matrix before treating it as a durable-runtime alternative.
