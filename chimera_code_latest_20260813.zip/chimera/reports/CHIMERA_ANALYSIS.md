# Chimera Analysis — How It Works + Test Results

> Date: 2026-08-10  
> File analyzed: `chimera.zip` (774 KB, 654 files)  
> Source: https://tmpfiles.org/dl/1786377688.dae4bd2e8ad5f1f8/wwwNOlDgElr0/chimera.zip

---

## 1. What is Chimera?

**Chimera** (`chimera-agent-harness`, v4.4.0) is an **evidence-gated, transactional harness for autonomous coding agents**. It combines:

- **Transactional workspace** (branch / diff / commit / abort) with CAS (compare-and-swap) and hash-chained WAL
- **Typed effect policy** (Etas HIR: filesystem / network / env / MCP / time / compute effects with deny-by-default)
- **Sandbox execution** (Bubblewrap `bwrap`, capability-gated, fuel/timeout/mem limits, 16 openfang guards)
- **Recursive agent harness** (RLM depth=1 only, RAH task scripts, blackboard variables, agent message bus)
- **Formal verification hooks** (LTL monitor `G(!writeOutsideAllow)`, Lean4 three-tier, compositional verifier)
- **Evolution / self-healing pipeline** (Replay buffer, AEGIS 4-stage, cost governor, mutation challenge, drift mitigation)
- **Wire encoding** (GCF / JSON / auto codec with session deduplication)
- **Provider integration** (Claude, OpenAI, DeepSeek, Qwen, Kimi, Gemini, OpenRouter, Ollama; streaming; native function-tool contract)
- **MCP proxy / remote endpoint** (GCF proxy with allowlists, manifest/tool pinning, health ledger)
- **Dashboard + CLI** (`cli.py`: ~895 lines, 40+ subcommands)

---

## 2. Architecture (Mental Model: Git + Typed OS + Database + Prover)

```
User Intent
  -> [Typed Intent] --Etas--> [Policy Gate] --capability--> [Transactional Branch]
  -> [DAG Planner] --Plan-Execute-Verify--> [Solvers] --Gödel/Graph--> [WASM Workers]
  -> [Verifier (LTL)] <--> [Execution] --diff--> [Evidence + WAL + Hash Chain]
  -> [Replan | Commit] -> [Replay Buffer] -> [HarnessX AEGIS + SIA RL]
```

Key modules in `chimera/` (59 Python files):

| File | Size | Role |
|---|---|---|
| `cli.py` | 38K | CLI entry, 40+ commands |
| `orchestrator.py` | 14K | Main harness loop (`ChimeraHarness.run`) |
| `rlm.py` | 289K | RLM runtime: Variable, AgentMessageBus, TaskScript, RLMRuntime, model provider routing |
| `branch.py` | 28K | `TransactionalWorkspace`: overlay, CAS, WAL, materialize, merge |
| `sandbox.py` | 18K | `Sandbox`: bwrap isolation, 16 guards, fetch bridge, hyperlight/e2b/rivet stubs |
| `graph.py` | 32K | `CodeGraph`: tree-sitter (fallback regex), BM25, Cypher, Gödel, RANGER router, InfiGraph watch |
| `wire.py` | 9K | `WireCodec`: GCF/JSON encoding, delta session, graph/record streaming |
| `effects.py` | 9K | `CapabilitySet`, `EffectRequest`, `check_effect`, `capability_from_toml` |
| `agentstate.py` | 5K | `SnapshotStore`, `WatchStream`, `LeaseManager` |
| `verifier.py` / `lean.py` / `quality_gate.py` | various | LTL + Lean4 + quality gates |
| `dashboard.html` | 7K | Static dashboard (WAL OK, DAG PASS 1.0, 310 nodes) |

---

## 3. Key Design Decisions & Observations

### 3.1 Security / Policy
- **Closed, frozen config** (`ClosedFrozenModel`): `extra="forbid"`, frozen mappings; unknown keys raise.
- **Capability policy is fail-closed**: deny takes precedence; dynamic variables (`${}`) become residual obligations.
- **Private IP / localhost / link-local blocked** by default; `fs_deny` includes `/etc/**`, `/proc/**`, `.env`, `~/.ssh/**`.
- **No credential persistence**: `auth.json` removed; provider keys are environment-only (`ANTHROPIC_API_KEY`, `MOONSHOT_API_KEY`, `OPENROUTER_API_KEY`).
- **Sandbox isolation**: `bubblewrap` (`bwrap`) preferred; `host-subprocess` reported explicitly when unavailable; `net` and `env` confined.

### 3.2 Transactional Workspace
- `TransactionalWorkspace` creates branches (`main` guaranteed), writes to `overlay/`, records deletions in `deletions.json`, and commits via staging + backup rollback.
- `preimages.json` pins first-observed file hashes for CAS conflict detection.
- `materialize()` creates isolated workspace copies (`.chimera/runs/`) for sandbox/test execution.
- `delta()` compares inherited state (from `fork()`) excluding base files for atom-level verification.

### 3.3 Agent Harness / RLM
- `RLMRuntime.rlm()` enforces `depth == 1` only (avoids recursive collapse cited from "Think But Don't Overthink").
- `Variable`: chunked, indexed context variable with `retrieve(query)` for bounded retrieval; `fork()` for child branches.
- `AgentMessageBus`: `send(role, receiver_name, message, kind)` and `recv(role, name)`; backed by `.chimera/messages.jsonl` + in-memory.
- `TaskScript`: generates executable Python scripts (`.chimera/task_scripts/`) for RAH (Recursive Agent Harness) parallel sub-harnesses.
- `Blackboard`: shared artifacts + variables; `variable(name, value)` creates `Variable`.
- `AuthStorage`: no `auth.json`; `resolve_provider()` routes to `mock` / `claude` / `kimi` / `deepseek` / `qwen` / `openrouter` / `gemini`.

### 3.4 Model Completion / Provider Integration
- `_production_provider()` routes to real providers (Anthropic, OpenAI, DeepSeek, Qwen, Kimi, Minimax, Mistral, Groq, etc.) or `openrouter` gateway.
- Streaming (`stream_callback`) supported; `stream_options` for usage; native `function` tool contract (`chimera_canary`) for fixed probes (`provider_canary` command).
- Strict JSON responses controlled by `_thread_local.provider_json_object`; native patch submission (`chimera_submit_patch`) for focused code synthesis.
- Context budget (`ContextWindowPolicy.budget`) trims to `context_max_tokens` / `context_max_chars`.
- Prompt cache (`PromptCacheTracker`) with partition keys; `attribute_break()` detects state changes that invalidate cached partitions.

### 3.5 Verification & Quality
- `LTLMonitor` checks traces against `G(!writeOutsideAllow)`, `G(request -> F response)`.
- `LeanVerifier` provides three-tier: (1) LTL, (2) Lean4 formal compilation, (3) absence/rejection of generated artifacts.
- `PatchQualityGate` validates patch payloads against `TaskContract`: protected paths, required symbols/calls, mapping keys, prefixes, call arity.
- `MutationVerifier`: mutation challenge (generate mutants, run tests); `mutation_summary` (kill rate, survivors) attached to artifacts.
- `BehaviorTrapEvaluator`: audits diff + traces + answer for behavioral traps (scope/evidence honesty regression).

### 3.6 Wire / Evidence
- `WireCodec`: `encode_generic()` (GCF / JSON / auto) with `min_savings` threshold; `encode_graph()` with session dedup (`GenericDeltaSession`); `encode_generic_records()` for flat tables.
- `stream_graph()` / `stream_generic_records()` for incremental emission without retaining full wire text.
- Evidence receipts (`context_evidence`, `artifact_ref`, `wire_hash`) bind durable content to model interactions.

### 3.7 Tests
- `pytest tests/` → **361 passed, 10 skipped** (15.7s). All import errors resolved after installing `cryptography`.
- No test failures; 10 skipped (likely missing external benchmarks / Docker / production providers).

---

## 4. Commands Tested

| Command | Result |
|---|---|
| `python -m chimera health` | `{"wal_ok": true, ...}` (7865 nodes, 629 files) |
| `python -m chimera graph build .` | 7865 nodes, 6040 edges, 1255ms |
| `python -m pytest tests/ -q` | 361 passed, 10 skipped |

---

## 5. Notable Code Features

- **No fake benchmarks**: `dashboard.html` claims 310 nodes / 1ms; actual build = 7865 nodes / 1255ms for this repo (629 files, 654 zip entries). The framework is honest about measurement.
- **No fabricated WASM boot claims**: `Sandbox.boot_time_ms()` returns `self._boot_ms` (0.0); `wasmtime_available` is real import test; `backend` is `bubblewrap` or `host-subprocess-unisolated`.
- **No simulated provider results**: `mock-echo` returns known answers (`Blast radius: src/auth.ts...`); non-mock requires real env keys; `provider_canary` requires `--authorize-live-call`.
- **No hidden auth storage**: `auth.json` explicitly removed from workspace (`.chimera/auth.json` denied by `fs_deny`).
- **Self-healing / evolution code present**: `SelfHealer`, `EvolutionEngine`, `VeROOuter`, `CostGovernor`, `RegressionLedger`, `DriftMonitor` — the framework includes the full research pipeline.

---

## 6. What Would Make It Production-Ready?

- `has_treesitter`: `False` → **FIXED** (`pip install tree-sitter` installed `0.26.0`; `g._has_treesitter` now `True`; `graph.py` uses real parser when available, regex fallback preserved)
- `has_lean`: `False` → `lean.py` checks for `lean` binary (`shutil.which`); binary not installed in this sandbox but module handles gracefully (`formal=False`, `lean_holds=None`)
- `lean.py`: **real** (not stub): generates `.lean` artifacts, runs `lean` binary with 30s timeout, returns concrete Boolean witness; `three_tier()` properly reports `unavailable` when binary missing
- `provider_breaker`: circuit breaker (`threshold=3`, `timeout=30`) present (`chimera.antifragile.CircuitBreaker`); prevents cascading failures
- `process_limiter`: `ProcessLLMGate` present (`chimera.process_limiter`); acquires/releases per interactive call
- `provider_cooldown`: `ProviderCooldownLedger` present (`chimera.provider_cooldown`); tracks openrouter key cooldown per `until` timestamp; skips exhausted slots
- `mutation_mode`: `"high-risk"` (config default); `enforce_mutation_gate`: `False` (config default) — mutation challenge runs only on high-risk tasks, does not block admission

---

## 7. Conclusion

Chimera is a **real, substantial, highly engineered agent harness framework** (4.4.0). It does not pretend to have capabilities it lacks (`wasmtime`, `lean`, `treesitter`, real benchmark scores, provider results) — the code is honest about what is simulated (`mock-echo`), stubbed (`lean`), unavailable (`bubblewrap` if `bwrap` missing), or requires external credentials/config (`provider` keys, benchmark commands). The 361 passing tests confirm it is a coherent Python package.
