# Chimera Remaining-Plan Completion Audit

## Scope

This audit continued from the user-supplied newer archive after source inspection and a fresh full regression run. The supplied progress reports were treated as discovery inputs; source/tests were the authority.

Baseline observed from the imported tree:

```text
439 passed in 18.37s
```

Final result:

```text
444 passed in 17.37s
0 pytest warnings
compileall: pass
```

## Completed implementation work

### 1. Legacy scaffold fallback removed

`chimera/scaffolds/legacy.py` has been removed. The historical generated-contract-test scaffold was migrated into `ScaffoldRegistry`, and `_deterministic_domain_scaffold()` now resolves only through the registry.

More importantly, deterministic target-name scaffolds are no longer default implementation authority:

```text
CHIMERA_ENABLE_DETERMINISTIC_SCAFFOLDS=1
```

is required to activate them. This prevents registry templates from silently turning target-name recognition into a benchmark shortcut. Unknown work falls through to the normal patch path; all supplied tests remain protected and final verification remains unchanged.

### 2. Model selection is authoritative without silent switching

New `chimera/route_authority.py` is used by the central `_complete_model` path.

Rules:

```text
requested concrete model → exact model is preserved
requested "auto"         → configured concrete default resolves
QoS/reliability           → advisory receipt only
```

The imported generic QoS switching behavior was changed: it still computes and records a better route recommendation, but does not replace an explicitly selected model. The historical generic hedge execution path has been removed from normal runtime execution because no provider-specific cancellation/billing canary proves duplicate-call safety.

This completes route authority at the completion boundary: all normal model calls reach `_complete_model`, which emits a `route_authority` receipt. It intentionally does **not** make the broad route pipeline a model-switching authority.

### 3. `_model_tool_loop` split into real functional modules

The previously monolithic 647-line loop is now 454 lines and delegates real behavior to:

```text
chimera/rlm_loop_context.py
chimera/rlm_loop_provider_turn.py
chimera/rlm_loop_transcript.py
```

Responsibilities:

| Module | Responsibility |
|---|---|
| `rlm_loop_context.py` | directives, recall/observation history, typed context plan, prompt-cache partition, context evidence |
| `rlm_loop_provider_turn.py` | native tool phase setup, request lifecycle, segment receipt, provider request, transport thread-local restoration, usage/cache evidence |
| `rlm_loop_transcript.py` | graph/tool result projection, compaction, wire encoding, transcript materialisation |
| `rlm_loop.py` | turn state machine, protocol validation, closed action compiler/scheduler, loop exit and lifecycle finalisation |

The split is covered by runtime loop tests and an architectural regression test that checks each module is actually invoked.

### 4. All executable broad `except: pass` paths removed

The source audit now finds no executable broad exception-swallowing path. Changes include:

* provider telemetry failures confess via `confess_degradation`;
* QoS advice failure is a structured degradation event;
* optional evolution regularization and private-directory mode failures confess;
* Nixo workspace fallback confesses;
* sandbox unreadable file bytes change the state hash rather than disappearing;
* agent-state callback failures are bounded diagnostics, not silent drops;
* TUI clipping is explicit display-only behavior;
* chaos permission exceptions are asserted, not passed over.

The remaining phrase `except: pass` exists only in an Etas documentation string warning against that anti-pattern.

### 5. Patch fusion now fails safe on edit conflicts

`patch_fusion.py` now:

```text
requires independent repeated support
counts one vote per candidate per exact atom
rejects equal-vote whole-patch ties
rejects competing replacements for one old-text hash
conservatively rejects overlapping old-text spans in a path
never combines file atoms with edit atoms
```

Fusion remains a proposal. `PatchQualityGate`, path scope, overlay transaction, and tests still decide whether it may apply.

### 6. TesterAgent generated tests are branch-local

The imported TesterAgent integration wrote generated tests directly into the root workspace before patch admission. It now writes them through the transactional branch overlay and seals logical content hashes. Generated tests never mutate the caller workspace root.

The existing deterministic tester is retained as an explicit experiment:

```text
CHIMERA_ENABLE_TESTER_AGENT=1
```

Model-generated hidden tests are deliberately **not** auto-enabled: executing arbitrary model-authored test code as authority needs a separate held-out effectiveness and sandbox proof.

### 7. Event egress is explicit

File events remain local by default. HTTP event export now additionally requires:

```text
CHIMERA_EVENT_SINK=http
CHIMERA_EVENT_SINK_TARGET=https://...
CHIMERA_EVENT_SINK_ALLOW_HTTP=1
```

No cloud-specific event backend was fabricated. A state-path resolver or HTTP transport is not evidence of a durable cloud event service, delivery semantics, credentials, or permitted network egress.

## New/updated tests

Relevant additions or updates:

```text
tests/test_qos_authoritative_provider.py
tests/test_certified_hedge.py
tests/test_rlm_loop_split.py
tests/test_roadmap_stages.py
tests/test_tester_agent_integration.py
tests/test_event_sink.py
tests/test_scaffold_policy.py
```

They cover explicit-model preservation, auto-only default resolution, generic hedge removal, split-loop wiring, fusion conflict abstention, branch-local generated tests, event egress opt-in, and scaffold opt-in.

## What is intentionally not promoted

The imported plan included several claims or defaults that do not meet the evidence bar:

| Item | Final disposition |
|---|---|
| Automatic QoS switching of a selected model | Rejected; advisory only. |
| Generic hedge model call after short budget | Rejected; no cancellation/billing proof. |
| Model-generated hidden tests as ordinary authority | Rejected; deterministic branch-local experiment only. |
| Cloud event sink backend | Not implemented; no deployment/egress/delivery evidence. |
| Deterministic domain scaffolds as default | Rejected; explicit experiment flag only. |
| Broad “superiority” claim from local pass counts | Not made. |

## Remaining promotion blockers, not unfinished code chores

The source-level remaining items are now external-evidence gates:

1. **Provider-native structured output:** require a terminal route/model canary that distinguishes valid response, refusal, length exhaustion, timeout, cancellation, and billed completion.
2. **Long-horizon coding outcome:** run a private/time-gated chained-state corpus with immutable tests, independent grading, provider deadline receipts, and state-handoff metrics.
3. **Real sandbox enforcement:** prove process/egress isolation in a deployed backend before changing the local `host-subprocess-unisolated` truth state.
4. **Remote behavior attestation:** descriptor/schema pins are insufficient; require observed isolated process/egress behavior and adapter-specific fault injection.
5. **External event delivery:** require an explicit sink contract, network capability, idempotency/delivery semantics, operator retention policy, and restore drill.

These are not solved by more local code. Implementing them without the listed evidence would create a marketing feature rather than a deterministic authority improvement.

## Current operational guidance

Safe defaults are now:

```text
explicit user model is preserved
no generic hedge
local file event sink
no deterministic scaffold unless explicitly enabled
no tester agent unless explicitly enabled
no cloud event egress unless explicitly enabled
```

Chimera is cleaner and safer at its control boundaries, but this audit does not claim it is universally superior. Superiority remains a measured, held-out, safety-adjusted outcome—not a codebase size or test-count milestone.
