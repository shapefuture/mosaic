# Chimera Platform Evolution Plan — Hexagonal, Local-to-Cloud, Evidence-Gated

**Date:** 2026-08-11  
**Status:** plan authored before implementation. WP-A through WP-E local control-plane primitives were implemented after this plan; WP-F deployment drills remain evidence-gated. The core transactional authority plane remains authoritative and no production cloud isolation or tenancy claim is made before host/deployment evidence exists.

## 1. Design goals

Chimera must support four deployment modes without duplicating business authority:

```text
LOCAL_DETERMINISTIC  — developer workstation, no cloud claim
DEV_EXTERNAL         — explicit hosted provider routes, exact model authority
SELF_HOSTED          — operator-provided inference/sandbox/queue adapters
CLOUD_MULTI_TENANT   — tenant isolation, quotas, deployment attestation
```

The same domain logic must be callable through:

```text
CLI
local Python API
MCP stdio/remote adapter
RPC/session adapter
managed scheduler/worker
```

No transport, provider, queue, microVM, DBOS, tokensave, or cloud deployment gains commit/promotion authority.

## 2. Hexagonal architecture target

```text
                  CLI / MCP / RPC / scheduler / HTTP deployment adapters
                                       │
                              Application services
     task contract · run lifecycle · tenant boundary · evidence gate · policy
                                       │
                               Explicit ports
  DurableWorkflowPort · DispatchPort · IsolationPort · CodeIntelPort
  CompletionPort · TelemetryPort · ArtifactPort · TenantDirectoryPort
                                       │
                   Local adapters / self-hosted adapters / cloud adapters
```

### Port laws

1. A port returns typed evidence/receipt or an explicit unavailable/unknown result.
2. An adapter never chooses a concrete requested model, commits a branch, promotes a candidate, or broadens capabilities.
3. A cloud adapter cannot be labelled ready from configuration alone; it needs deployment attestation and drill evidence.
4. The local adapter remains the reference implementation in every port contract test.

## 3. Work packages

### WP-A — Deployment control plane and truthfulness

Create `PlatformProfile`, `DeploymentAttestation`, and `PlatformDoctor`.

- Reports required capabilities for local, external, self-hosted, and multi-tenant profiles.
- Distinguishes `available`, `unavailable`, `configured-unverified`, and `certified`.
- Probes only local executables/capabilities by default; no network/deployment operation.
- CLI: `chimera platform doctor --profile ...`.

**Acceptance:** no profile reports sandbox/database/queue/cloud delivery as certified without a receipt.  
**Kill:** a configured environment variable turns an unavailable boundary into a certified claim.

### WP-B — Tenant boundary and resource governance

Create `TenantContext`, `TenantWorkspaceResolver`, `TenantQuota`, and `TenantDirectory`.

- Tenant roots use a deterministic opaque digest, never the raw tenant ID as a directory name.
- Each tenant gets distinct branch/WAL/artifact root; there is no cross-tenant root by default.
- Require per-tenant task/cost/token/concurrency budgets and explicit route policy reference.
- Tenant context is propagated to CLI/MCP/RPC session adapters as an explicit argument/metadata field—not global mutable state.

**Acceptance:** path traversal and raw-ID guessing cannot cross a tenant root; quota rejection returns a typed receipt; one tenant’s WAL/artifact cannot be resolved from another.  
**Kill:** any cross-tenant read/write or default global tenant fallback.

### WP-C — Runtime port contracts

Introduce protocols and local adapters for:

```text
DurableWorkflowPort
DispatchPort
IsolationPort
CodeIntelligencePort
TenantDirectoryPort
```

The existing `LocalDurableWorkflowPort`, managed scheduler, Sandbox, CodeGraph/ImpactAnalyzer, and tenant resolver are the initial local adapters.

External DBOS/Restate/Hatchet/forkd/SGLang/tokensave adapters remain unavailable declarations until their own evidence campaigns pass.

**Acceptance:** contract suite passes against local adapters; unavailable adapters fail closed with evidence.  
**Kill:** a stub adapter gets used as an operational backend without a contract receipt.

### WP-D — Dynamic impact evidence lane

Add a `DynamicImpactMap` and `DynamicImpactSelector` separate from existing static ImpactAnalyzer.

- It stores a signed/hashed test-to-file/symbol execution map from an external coverage collector.
- It can advise a focused command only when the map matches the current source/test/environment fingerprint.
- Existing static impact selection and full-suite fallback remain default until mutation corpus data proves gain.

**Acceptance:** stale/corrupt map falls back to full; dynamic selection recalls every seeded mutation in a calibration corpus; full suite periodically validates map.  
**Kill:** map reuse crosses environment/source fingerprint or focused execution is promoted before calibration.

### WP-E — Prefix and code-intelligence evaluation ports

- `PromptPrefixContract`: split immutable prefix from volatile suffix, hash/lint for timestamps, identity, and changing tool metadata.
- `CodeIntelligencePort`: current CodeGraph is baseline; third-party tools run only via a read-only pinned subprocess adapter with explicit update/telemetry disabled.
- Every code-intelligence result includes token/latency/memory/provenance receipt.

**Acceptance:** identical prefix check is deterministic; third-party tool cannot write workspace or egress without explicit grant; benchmark captures recall/tokens/RSS.  
**Kill:** prompt cache claim without route telemetry or tool writes outside branch scope.

### WP-F — Parallel development and antifragile drills

- Extend parallelism planner into a `ParallelLanePlan`: ownership reads/writes, required evidence, tenant, test resource namespace, and merge barrier.
- Add local fault drills: worker death, stale impact map, quota exhaustion, tenant isolation, process cancellation, WAL corruption refusal, unavailable adapter.
- Every drill emits a bounded receipt; no self-healing policy is auto-promoted.

**Acceptance:** conflicting/irreversible lanes serialize; independent lanes preserve isolation; drills leave no orphan process/tenant leakage.  
**Kill:** a drill needs a production provider or a failure is classified as pass.

## 4. Performance strategy

1. Dynamic coverage TIA first: initial pytest-testmon evidence detects 3/3 real mutations in 3.145–11.961s versus 25.306–25.799s full runs, but remains opt-in until a 30+ mutation corpus validates recall.
2. Test isolation benchmark (`-n 0`, `xdist loadscope`, `worksteal`) completed locally: two-worker loadscope reduced the latest full-suite wall time from 25.941s to 14.917s. The acceleration lane is explicit/certified opt-in only.
3. Prefix hygiene and current provider cache telemetry before self-hosting.
4. Profile with py-spy/Scalene before mypyc/Cython/PyO3/Nuitka.
5. Deployment-level DB/queue/inference systems only after local evidence shows the current port is a bottleneck.

## 5. Cloud/self-hosted readiness sequence

```text
local control-plane contracts
→ disposable Postgres durable adapter spike
→ certified local sandbox ladder
→ per-tenant root/quota isolation
→ queue/pool load test
→ self-hosted inference benchmark (if GPUs exist)
→ self-hosted deployment attestation
→ cloud multi-tenant drill
```

## 6. Explicit non-goals

- No automatic provider/model tier routing.
- No semantic cache for coding/effect work.
- No default external queue, DBOS, Restate, Hatchet, pg_crdt, forkd, Kata, SGLang, or tokensave installation.
- No fake multi-tenancy via a `tenant_id` label on shared unpartitioned roots.
- No cloud delivery claim without restore/idempotency/attestation drill.
- No weakening of current protected-test, WAL/CAS, scoped approval, exact-model, and held-out gates.
