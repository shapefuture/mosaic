# Chimera Final `rlm.py` Cleanup Report

## Backup

The original pre-refactor runtime file is still preserved:

```text
chimera/rlm.py.backup_before_split
4991 lines / 292,992 bytes
```

## Requested cleanup completed

You asked to proceed with the next cleanup split:

- `rlm_loop.py` for `_model_tool_loop`
- `rlm_dag_solver.py` for `_solver_for_node`, `_contract_for_atom`, integration repair
- `rlm_coder_focused.py` for focused coder
- `rlm_coder_cohesive.py` for cohesive coder

All four were implemented and tested.

## New / updated split

### `chimera/rlm_coder_focused.py`

Focused coder and focused patch helpers:

- `_coerce_target_response`
- `_strict_patch_call`
- `_target_prompt`
- `_deterministic_domain_scaffold`
- `_deterministic_adapter_payload`
- `_normalise_contract_values`
- `_focused_coder`

Size:

```text
970 lines
```

### `chimera/rlm_coder_cohesive.py`

Cohesive transaction coder:

- `_cohesive_coder`

Size:

```text
129 lines
```

### `chimera/rlm_coder_methods.py`

Compatibility shim:

```python
class RLMCoderMixin(RLMFocusedCoderMixin, RLMCohesiveCoderMixin):
    pass
```

Size:

```text
9 lines
```

### `chimera/rlm_loop.py`

Main model/tool loop:

- `_model_tool_loop`

Size:

```text
619 lines
```

### `chimera/rlm_dag_solver.py`

DAG solver and integration repair:

- `_hybrid_observation_needed`
- `_run_hybrid_observation`
- `_integration_repair_contract`
- `_contract_for_atom`
- `_solver_for_node`
- `_finalize_run_evidence`

Size:

```text
514 lines
```

### `chimera/rlm_orchestration_methods.py`

Public runtime orchestration only:

- `rlm`
- `spawn_subharness`
- `chained_rlm`
- `swarm`

Size:

```text
231 lines
```

## Current RLM split file sizes

```text
chimera/rlm.py                         424 lines
chimera/rlm_coder_focused.py           970 lines
chimera/rlm_coder_cohesive.py          129 lines
chimera/rlm_coder_methods.py             9 lines
chimera/rlm_loop.py                    619 lines
chimera/rlm_dag_solver.py              514 lines
chimera/rlm_orchestration_methods.py   231 lines
chimera/rlm_execution_methods.py       671 lines
chimera/rlm_tool_methods.py            511 lines
chimera/rlm_provider.py                559 lines
chimera/rlm_primitives.py              292 lines
chimera/rlm.py.backup_before_split    4991 lines
```

`rlm.py` is now a compact runtime shell with imports, initialization, and small local context helpers.

## Runtime class now composes these mixins

```python
class RLMRuntime(
    RLMProviderMixin,
    RLMActionMixin,
    RLMToolMixin,
    RLMFocusedCoderMixin,
    RLMCohesiveCoderMixin,
    RLMExecutionMixin,
    RLMLoopMixin,
    RLMDAGSolverMixin,
    RLMOrchestrationMixin,
):
    ...
```

## Issues caught and fixed during this cleanup

### 1. `rlm_loop.py` missing `time`

Caught by tool-surface tests. Fixed import.

### 2. `rlm_loop.py` missing `ToolSurfaceError`

Caught by single-tool-surface rejection test. Fixed import.

### 3. Split boundaries preserved compatibility

The old `RLMCoderMixin` remains as a compatibility shim, while `RLMRuntime` now directly inherits focused/cohesive coder mixins.

## Tests run

Targeted after coder split:

```text
pytest tests/test_harness_improvements.py::test_focused_coder_generates_per_file_patch_and_runs_tests tests/test_cohesive_transaction.py tests/test_tool_surface_protocol.py tests/test_agent_runtime_transfer.py tests/test_dag_admission.py tests/test_hybrid_default.py -q
```

Targeted after loop/DAG split:

```text
pytest tests/test_tool_surface_protocol.py tests/test_native_patch_fallback.py tests/test_agent_runtime_transfer.py tests/test_dag_admission.py tests/test_hybrid_default.py -q
20 passed
```

Final verification:

```text
python3 -m compileall -q chimera tests
OK

pytest tests -q
388 passed in 16.14s

python3 -m chimera health | python3 -m json.tool
OK

ChimeraHarness mock run smoke
smoke True True True
```

## Result

The requested final cleanup is complete and fully green.

The original large `rlm.py` is safely backed up, and the live runtime is now split into small, purpose-specific modules.
