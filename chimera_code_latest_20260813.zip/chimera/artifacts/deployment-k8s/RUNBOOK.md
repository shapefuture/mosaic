# Chimera Kubernetes runbook

1. Replace `${CHIMERA_IMAGE}` via Kustomize/Helm/CI.
2. Use ExternalSecrets/SealedSecrets for `chimera-secrets`.
3. Configure NetworkPolicy for only DB, durable runtime, event bus, OTLP, and selected providers.
4. Run inside a pod:
   - `python -m chimera.cli platform cloud-scale-readiness --agents 5000 --tenants 500 --mode k8s`
   - `python -m chimera.cli platform cloud-scale-smoke --agents 5000 --tenants 500`
   - `python -m chimera.cli platform supreme-gate --scan-path /tmp/clean-candidate`
5. Do not mark production certified until host sandbox/gateway/event/cache receipts exist.
