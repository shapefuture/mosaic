# Chimera self-hosted dense runbook

1. Build or pull `CHIMERA_IMAGE`.
2. Fill `.env` locally; do not commit it.
3. Start: `docker compose up -d`.
4. Smoke:
   - `chimera doctor --profile cloud-runtime` inside the Chimera container.
   - `chimera platform cloud-scale-smoke --agents 1000 --tenants 100`.
   - `chimera platform supreme-gate --scan-path /tmp/clean-candidate`.
5. Only enable NATS/gateways/cache profiles after benchmark receipts.
