# AOS v3 — control plane

A working fullstack implementation of the **hibernating, massively parallel agent operating system** doctrine:
millions of identities, thousands of concurrent tasks, a tiny always-on footprint.

An agent is an identity, a role, a capability set and persistent knowledge. It is never a process. Work wakes a shared
pool, commits a receipt and goes back to sleep.

## Stack

- Next.js 16 (App Router, server components, server actions)
- PostgreSQL + Drizzle ORM
- Tailwind CSS v4, Geist, lucide icons
- Deterministic scheduler, HMAC-signed capability envelopes, idempotent receipts

## Tour

| Route | What it demonstrates |
| --- | --- |
| `/` | Command deck: live execution fabric, queue lanes, budget, approvals, fleet residency |
| `/fleet` | Agent registry — identities, budget, skills, session hibernation; `/fleet/[id]` for detail |
| `/work` | Compile a bounded task DAG; `/work/[id]` shows the DAG, task ledger, gauntlet rounds, receipts, acceptance gates |
| `/scheduler` | Four queue lanes, adaptive concurrency, worker leases, policy editor, capacity qualification harness |
| `/memory` | Memory compiler: proposed → curated knowledge with provenance and scope |
| `/security` | Signed capability envelopes, live allow/deny evaluation, revocation, approval centre |
| `/doctrine` | Reference architecture, TRIZ resolutions, delivery ledger, skills lineage |

The header runs the scheduler. **Autopilot** ticks every few seconds; the manual **Tick** button runs one tick and
refreshes the server view.

## How execution works

1. A plan template compiles into a durable task graph (`work_units`, `tasks` with `depends_on`).
2. Every tick:
   - tasks whose lease elapsed are completed, receipted and verified;
   - blocked tasks whose dependencies succeeded become ready;
   - concurrency is recomputed as `min(provider, tenant, queue lane, sandbox, budget)`, with adaptive shrinkage when the
     failure rate rises;
   - ready tasks are leased atomically to ephemeral workers (`update ... where status = 'ready'` claim semantics).
3. Consequential tasks pause at a human authorization gate instead of writing outside the sandbox.
4. Every side effect writes a receipt with a unique idempotency key. Duplicates reconcile instead of re-executing.
5. Synthesis tasks open a **gauntlet loop**: a separate critic compares the artifact blind against a named bar, names the
   single biggest gap, and stops only when ours wins.

## API

- `GET /api/health` — database liveness
- `GET /api/state` — live lanes, leases, events, spend
- `POST /api/tick` — one scheduler tick
- `POST /api/work` — `{ title, objective, template, ownerAgentId, priority }` (idempotent, bounded by the fan-out cap)
- `POST /api/approvals` — `{ id, decision }`
- `POST /api/authority` — `mode: "issue" | "verify"` for capability envelopes
- `POST /api/qualification` — `kind: idle_sessions | io_flood | failure_injection | duplicate_event`

## Honesty note

No model provider keys are configured in this environment, so **inference is simulated**. Everything else is real:
the scheduler, queue bounding, leases, retries, hibernation, receipts, idempotency, policy evaluation, approval gates,
gauntlet rounds, telemetry and capacity gates all execute against PostgreSQL.

## Skills lineage

- **gauntlet-loop** — named fetchable bar, separate harsh critic, blind A/B, named gap, loop until ours wins.
- **full-plan-delivery** — bounded vertical slices with acceptance criteria, evidence and honest blocker states
  (see the delivery ledger on `/doctrine`).
- **AAA-V7 architecture brief** — the doctrine applied throughout: identity ≠ process, hibernating sessions, bounded
  fan-out, three execution tiers, scoped authority, receipts. The linked spec file was unreachable from this sandbox,
  so the pasted brief is the authority.

## Local commands

```bash
npx drizzle-kit push --config drizzle.config.json   # apply schema
npm run dev                                          # develop
npm run build && npm run start                       # production
```

The database seeds itself on first request behind a PostgreSQL advisory lock; partial seeds are wiped and retried.
