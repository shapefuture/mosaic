import { and, count, desc, eq, inArray, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  agents,
  approvals,
  authorityEnvelopes,
  deliveryTasks,
  events,
  gauntletRounds,
  memories,
  metrics,
  qualificationRuns,
  receipts,
  runtimePolicy,
  sessions,
  skills,
  tasks,
  workers,
  workUnits,
  type Agent,
  type Task,
  type WorkUnit,
} from "@/db/schema";
import { ensureSeed } from "@/lib/seed";
import { getPolicy } from "@/lib/engine";
import { num } from "@/lib/format";

export async function boot() {
  await ensureSeed();
}

export type AcceptanceLine = { label: string; met: boolean; key: string };

export function evaluateAcceptance(
  unit: WorkUnit,
  taskRows: Task[],
  receiptRows: { outcome: string }[],
  rounds: { criticVerdict: string }[],
): AcceptanceLine[] {
  const committed = receiptRows.filter((r) => r.outcome === "committed").length;
  const reconciled = receiptRows.filter((r) => r.outcome === "reconciled").length;
  const verifierOk = taskRows.some((t) => t.mod === "verify" && t.status === "succeeded" && t.verifyStatus === "passed");
  const barWon = rounds.some((r) => r.criticVerdict === "ours");
  const testsOk = taskRows.some((t) => /test/i.test(t.title) && t.status === "succeeded");
  const securityOk = taskRows.some((t) => t.tier === 2 && t.status === "succeeded");
  const withinBudget = num(unit.spentUsd) <= num(unit.budgetUsd);

  return unit.acceptance.map((a) => {
    let met = false;
    if (a.key === "sources") met = committed >= 3;
    if (a.key === "contradictions") met = verifierOk || reconciled > 0;
    if (a.key === "bar") met = barWon;
    if (a.key === "budget") met = withinBudget && unit.status === "done";
    if (a.key === "tests") met = testsOk;
    if (a.key === "security") met = securityOk;
    return { ...a, met };
  });
}

export async function getOverview() {
  await boot();
  const [agentRows, sessionRows, unitRows, taskRows, receiptRows, eventRows, memoryRows, approvalRows, policy, metricRows, roundRows, workerRows] =
    await Promise.all([
      db.select().from(agents),
      db.select().from(sessions),
      db.select().from(workUnits).orderBy(desc(workUnits.createdAt)),
      db.select().from(tasks),
      db.select().from(receipts).where(sql`${receipts.resource} not like 'qualification://%'`).orderBy(desc(receipts.createdAt)).limit(12),
      db.select().from(events).orderBy(desc(events.createdAt)).limit(14),
      db.select().from(memories),
      db.select().from(approvals).orderBy(desc(approvals.requestedAt)),
      getPolicy(),
      db.select().from(metrics).orderBy(desc(metrics.at)).limit(24),
      db.select().from(gauntletRounds),
      db.select().from(workers),
    ]);

  const running = taskRows.filter((t) => t.status === "running");
  const ready = taskRows.filter((t) => t.status === "ready");
  const queueDepth = {
    interactive: ready.filter((t) => t.queue === "interactive").length,
    io: ready.filter((t) => t.queue === "io").length,
    compute: ready.filter((t) => t.queue === "compute").length,
    browser: ready.filter((t) => t.queue === "browser").length,
  };
  const perLaneRunning = {
    interactive: running.filter((t) => t.queue === "interactive").length,
    io: running.filter((t) => t.queue === "io").length,
    compute: running.filter((t) => t.queue === "compute").length,
    browser: running.filter((t) => t.queue === "browser").length,
  };
  const spend = unitRows.reduce((sum, u) => sum + num(u.spentUsd), 0);
  const budget = num(policy.budgetCeilingUsd);
  const hibernated = sessionRows.filter((s) => s.state === "hibernating");
  const pending = approvalRows.filter((a) => a.status === "pending");
  const committed = taskRows.filter((t) => t.status === "succeeded").length;
  const failed = taskRows.filter((t) => t.status === "failed").length;

  return {
    agents: agentRows,
    sessions: sessionRows,
    units: unitRows,
    tasks: taskRows,
    receipts: receiptRows,
    events: eventRows,
    memories: memoryRows,
    approvals: approvalRows,
    policy,
    metrics: [...metricRows].reverse(),
    rounds: roundRows,
    workers: workerRows,
    stats: {
      agentCount: agentRows.length,
      activeAgents: agentRows.filter((a) => a.status === "active").length,
      hibernatedSessions: hibernated.length,
      sessionCount: sessionRows.length,
      residentKb: sessionRows.reduce((sum, s) => sum + s.residentKb, 0),
      storedKb: sessionRows.reduce((sum, s) => sum + s.contextKb, 0),
      running: running.length,
      ready: ready.length,
      committed,
      failed,
      verified: taskRows.filter((t) => t.status === "succeeded" && t.verifyStatus === "passed").length,
      spend,
      budget,
      budgetPct: budget > 0 ? (spend / budget) * 100 : 0,
      pendingApprovals: pending.length,
      curatedMemories: memoryRows.filter((m) => m.trust === "curated").length,
      proposedMemories: memoryRows.filter((m) => m.trust === "proposed").length,
      gauntletWins: roundRows.filter((r) => r.criticVerdict === "ours").length,
      gauntletRounds: roundRows.length,
      queueDepth,
      perLaneRunning,
      residentComputeMb: running.reduce((sum, t) => sum + (t.queue === "browser" ? 104 : t.queue === "compute" ? 256 : 64), 0),
    },
  };
}

export type Overview = Awaited<ReturnType<typeof getOverview>>;

export async function getFleet() {
  await boot();
  const [agentRows, skillRows, sessionRows, taskRows, receiptRows] = await Promise.all([
    db.select().from(agents),
    db.select().from(skills),
    db.select().from(sessions),
    db.select().from(tasks),
    db.select().from(receipts),
  ]);
  return agentRows.map((agent) => ({
    agent,
    skills: skillRows.filter((s) => s.agentId === agent.id),
    sessions: sessionRows.filter((s) => s.agentId === agent.id),
    activeTasks: taskRows.filter((t) => t.agentId === agent.id && ["running", "waiting_approval"].includes(t.status)),
    completed: taskRows.filter((t) => t.agentId === agent.id && t.status === "succeeded").length,
    receipts: receiptRows.filter((r) => r.agentId === agent.id).length,
  }));
}

export async function getAgent(id: string) {
  await boot();
  const [agent] = await db.select().from(agents).where(eq(agents.id, id)).limit(1);
  if (!agent) return null;
  const [skillRows, sessionRows, taskRows, receiptRows, memoryRows] = await Promise.all([
    db.select().from(skills).where(eq(skills.agentId, id)),
    db.select().from(sessions).where(eq(sessions.agentId, id)).orderBy(desc(sessions.lastActiveAt)),
    db.select().from(tasks).where(eq(tasks.agentId, id)).orderBy(desc(tasks.startedAt)).limit(12),
    db.select().from(receipts).where(eq(receipts.agentId, id)).orderBy(desc(receipts.createdAt)).limit(8),
    db.select().from(memories).where(eq(memories.agentId, id)).orderBy(desc(memories.confidence)),
  ]);
  return { agent, skills: skillRows, sessions: sessionRows, tasks: taskRows, receipts: receiptRows, memories: memoryRows };
}

export async function getWorkUnits() {
  await boot();
  const [unitRows, taskRows, ownerRows] = await Promise.all([
    db.select().from(workUnits).orderBy(desc(workUnits.createdAt)),
    db.select().from(tasks),
    db.select().from(agents),
  ]);
  return unitRows.map((unit) => ({
    unit,
    owner: ownerRows.find((a) => a.id === unit.ownerAgentId) ?? null,
    tasks: taskRows.filter((t) => t.workUnitId === unit.id),
  }));
}

export async function getWorkUnit(id: string) {
  await boot();
  const [unit] = await db.select().from(workUnits).where(eq(workUnits.id, id)).limit(1);
  if (!unit) return null;
  const [taskRows, receiptRows, roundRows, approvalRows, ownerRows, agentsRows] = await Promise.all([
    db.select().from(tasks).where(eq(tasks.workUnitId, id)).orderBy(tasks.position),
    db.select().from(receipts).where(eq(receipts.workUnitId, id)).orderBy(desc(receipts.createdAt)),
    db.select().from(gauntletRounds).where(eq(gauntletRounds.workUnitId, id)).orderBy(gauntletRounds.round),
    db.select().from(approvals).where(eq(approvals.workUnitId, id)).orderBy(desc(approvals.requestedAt)),
    db.select().from(agents).where(eq(agents.id, unit.ownerAgentId)).limit(1),
    db.select().from(agents),
  ]);
  return {
    unit,
    tasks: taskRows,
    receipts: receiptRows,
    rounds: roundRows,
    approvals: approvalRows,
    owner: ownerRows[0] ?? null,
    agents: agentsRows,
    acceptance: evaluateAcceptance(unit, taskRows, receiptRows, roundRows),
  };
}

export async function getScheduler() {
  await boot();
  const [policy, workerRows, metricRows, unitRows, taskRows, receiptRows, runs, qualificationRows] = await Promise.all([
    getPolicy(),
    db.select().from(workers),
    db.select().from(metrics).orderBy(desc(metrics.at)).limit(30),
    db.select().from(workUnits),
    db.select().from(tasks),
    db.select().from(receipts),
    db.select().from(runtimePolicy).where(eq(runtimePolicy.id, "default")).limit(1),
    db.select().from(qualificationRuns).orderBy(desc(qualificationRuns.createdAt)).limit(6),
  ]);

  const lanes = (["interactive", "io", "compute", "browser"] as const).map((lane) => {
    const running = taskRows.filter((t) => t.queue === lane && t.status === "running").length;
    const ready = taskRows.filter((t) => t.queue === lane && t.status === "ready").length;
    const limit =
      lane === "compute"
        ? Math.min(policy.sandboxSlots, policy.compute)
        : lane === "browser"
          ? Math.min(policy.browserPool, policy.browser)
          : policy[lane];
    return { lane, running, ready, limit };
  });

  const spend = unitRows.reduce((sum, u) => sum + num(u.spentUsd), 0);
  const completed = taskRows.filter((t) => t.status === "succeeded");
  const failed = taskRows.filter((t) => t.status === "failed");
  const totalCost = completed.reduce((sum, t) => sum + num(t.costActual), 0);
  const tokens = completed.reduce((sum, t) => sum + t.tokensIn + t.tokensOut, 0);

  return {
    policy,
    workers: workerRows,
    metrics: [...metricRows].reverse(),
    lanes,
    runs: qualificationRows,
    receipts: receiptRows.filter((r) => r.outcome === "reconciled"),
    stats: {
      spend,
      ceiling: num(policy.budgetCeilingUsd),
      throughput: completed.length,
      failureRate: completed.length + failed.length > 0 ? (failed.length / (completed.length + failed.length)) * 100 : 0,
      costPerVerified: completed.length ? totalCost / completed.length : 0,
      tokensPerResult: completed.length ? tokens / completed.length : 0,
      ready: taskRows.filter((t) => t.status === "ready").length,
      running: taskRows.filter((t) => t.status === "running").length,
      capacity: Math.min(policy.providerConcurrency, policy.tenantConcurrency, lanes.reduce((s, l) => s + l.limit, 0)),
      policyRows: runs.length,
    },
  };
}

export async function getMemory(search?: string) {
  await boot();
  const [memoryRows, agentRows, unitRows] = await Promise.all([
    db.select().from(memories).orderBy(desc(memories.confidence)),
    db.select().from(agents),
    db.select().from(workUnits),
  ]);
  const term = (search ?? "").trim().toLowerCase();
  const filtered = term
    ? memoryRows.filter(
        (m) =>
          m.content.toLowerCase().includes(term) ||
          m.scope.toLowerCase().includes(term) ||
          m.kind.toLowerCase().includes(term),
      )
    : memoryRows;
  return {
    memories: filtered,
    total: memoryRows.length,
    agents: agentRows,
    units: unitRows,
    term,
    counts: {
      curated: memoryRows.filter((m) => m.trust === "curated").length,
      proposed: memoryRows.filter((m) => m.trust === "proposed").length,
      rejected: memoryRows.filter((m) => m.trust === "rejected").length,
      semantic: memoryRows.filter((m) => m.kind === "semantic").length,
      procedural: memoryRows.filter((m) => m.kind === "procedural").length,
      episodic: memoryRows.filter((m) => m.kind === "episodic").length,
      preference: memoryRows.filter((m) => m.kind === "preference").length,
    },
  };
}

export async function getSecurity() {
  await boot();
  const [agentRows, envelopeRows, receiptRows, approvalRows, unitRows] = await Promise.all([
    db.select().from(agents),
    db.select().from(authorityEnvelopes).orderBy(desc(authorityEnvelopes.createdAt)),
    db.select().from(receipts).where(sql`${receipts.resource} not like 'qualification://%'`).orderBy(desc(receipts.createdAt)).limit(25),
    db.select().from(approvals).orderBy(desc(approvals.requestedAt)),
    db.select().from(workUnits),
  ]);
  const now = Date.now();
  return {
    agents: agentRows,
    envelopes: envelopeRows.map((envelope) => ({
      ...envelope,
      expired: new Date(envelope.expiresAt).getTime() < now,
    })),
    receipts: receiptRows,
    approvals: approvalRows,
    units: unitRows,
  };
}

export async function getDoctrine() {
  await boot();
  const [delivery, runs, unitRows, taskRows, roundRows] = await Promise.all([
    db.select().from(deliveryTasks).orderBy(deliveryTasks.position),
    db.select().from(qualificationRuns).orderBy(desc(qualificationRuns.createdAt)).limit(4),
    db.select().from(workUnits),
    db.select().from(tasks),
    db.select().from(gauntletRounds),
  ]);
  return { delivery, runs, unitRows, taskRows, roundRows };
}

export async function searchMemories(term: string) {
  if (!term.trim()) return db.select().from(memories).limit(8);
  return db
    .select()
    .from(memories)
    .where(
      or(
        sql`${memories.content} ilike ${`%${term}%`}`,
        eq(memories.kind, term),
        sql`${memories.scope} ilike ${`%${term}%`}`,
      ),
    )
    .limit(12);
}

export async function countsFor(agentId: string): Promise<Agent | null> {
  const [agent] = await db.select().from(agents).where(eq(agents.id, agentId)).limit(1);
  return agent ?? null;
}

export async function pendingApprovalCount(): Promise<number> {
  const [row] = await db.select({ n: count() }).from(approvals).where(eq(approvals.status, "pending"));
  return Number(row?.n ?? 0);
}

export async function activeTaskTitles(agentId: string) {
  const rows = await db
    .select({ title: tasks.title })
    .from(tasks)
    .where(and(eq(tasks.agentId, agentId), inArray(tasks.status, ["running", "waiting_approval"])));
  return rows.map((r) => r.title);
}
