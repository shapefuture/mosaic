import crypto from "node:crypto";
import { and, count, desc, eq, gte, inArray, notInArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  agents,
  approvals,
  events,
  gauntletRounds,
  memories,
  metrics,
  receipts,
  runtimePolicy,
  sessions,
  tasks,
  workUnits,
  workers,
  type RuntimePolicy,
  type Task,
} from "@/db/schema";
import { WORK_TEMPLATES, buildGauntletArtifact, type QueueName } from "@/lib/templates";
import { shortHash } from "@/lib/authority";

const LANES: QueueName[] = ["interactive", "io", "compute", "browser"];

export const id = (prefix: string) => `${prefix}_${crypto.randomBytes(6).toString("hex")}`;

function jitter(seed: string): number {
  const h = crypto.createHash("sha256").update(seed).digest();
  return h.readUInt16BE(0) / 65535;
}

export async function logEvent(input: {
  kind: string;
  message: string;
  workUnitId?: string | null;
  taskId?: string | null;
  agentId?: string | null;
  meta?: Record<string, unknown>;
}) {
  await db.insert(events).values({
    id: id("evt"),
    kind: input.kind,
    message: input.message,
    workUnitId: input.workUnitId ?? null,
    taskId: input.taskId ?? null,
    agentId: input.agentId ?? null,
    meta: input.meta ?? {},
  });
}

export async function getPolicy(): Promise<RuntimePolicy> {
  const rows = await db.select().from(runtimePolicy).where(eq(runtimePolicy.id, "default")).limit(1);
  if (rows[0]) return rows[0];
  const inserted = await db
    .insert(runtimePolicy)
    .values({ id: "default", maxFanout: 12 })
    .onConflictDoNothing()
    .returning();
  if (inserted[0]) return inserted[0];
  const existing = await db.select().from(runtimePolicy).where(eq(runtimePolicy.id, "default")).limit(1);
  if (existing[0]) return existing[0];
  throw new Error("runtime policy unavailable");
  return inserted[0];
}

export type CreateWorkUnitInput = {
  title: string;
  objective: string;
  template: string;
  ownerAgentId: string;
  priority?: number;
  budgetUsd?: number;
};

export async function createWorkUnit(input: CreateWorkUnitInput): Promise<{ ok: boolean; workUnitId?: string; error?: string }> {
  const template = WORK_TEMPLATES[input.template] ?? WORK_TEMPLATES.market_intel;
  const policy = await getPolicy();

  if (template.tasks.length > policy.maxFanout) {
    return {
      ok: false,
      error: `Bounded fan-out: this plan needs ${template.tasks.length} task slots but the runtime cap is ${policy.maxFanout}. Raise the cap in Scheduler or pick a smaller plan.`,
    };
  }

  const unitId = id("wu");
  const key = `${input.template}:${shortHash(input.title + input.objective)}`;
  const existing = await db.select().from(workUnits).where(eq(workUnits.idempotencyKey, key)).limit(1);
  if (existing[0]) return { ok: true, workUnitId: existing[0].id };

  await db.insert(workUnits).values({
    id: unitId,
    title: input.title,
    objective: input.objective,
    template: template.key,
    ownerAgentId: input.ownerAgentId,
    status: "running",
    priority: input.priority ?? 3,
    fanoutLimit: Math.min(template.tasks.length, policy.maxFanout),
    budgetUsd: (input.budgetUsd ?? 8).toFixed(4),
    bar: template.bar,
    acceptance: template.acceptance,
    idempotencyKey: key,
    startedAt: new Date(),
  });

  const taskIds = template.tasks.map(() => id("tsk"));
  await db.insert(tasks).values(
    template.tasks.map((t, index) => ({
      id: taskIds[index],
      workUnitId: unitId,
      agentId: input.ownerAgentId,
      title: t.title,
      queue: t.queue,
      position: index,
      status: t.dependsOnPositions.length === 0 ? "ready" : "blocked",
      tier: t.tier,
      dependsOn: t.dependsOnPositions.map((p) => taskIds[p]),
      mod: t.mod,
      model: t.model,
      gauntlet: Boolean(t.gauntlet),
      consequential: Boolean(t.consequential),
      durationMs: t.durationMs,
      costEstimate: t.costEstimate.toFixed(4),
    })),
  );

  const [agent] = await db.select().from(agents).where(eq(agents.id, input.ownerAgentId)).limit(1);
  const sessionId = id("ses");
  await db.insert(sessions).values({
    id: sessionId,
    agentId: input.ownerAgentId,
    workUnitId: unitId,
    title: `Session — ${input.title}`.slice(0, 90),
    state: "active",
    contextKb: 38,
    residentKb: 620,
    transcript: [
      { role: "human", content: input.objective, at: new Date().toISOString() },
      {
        role: "agent",
        content: `Accepted as a durable Work Unit. Plan "${template.label}" admitted ${template.tasks.length} task boundaries; execution starts in the shared pool. I hold no worker between turns.`,
        at: new Date().toISOString(),
      },
    ],
    lastActiveAt: new Date(),
  });

  await logEvent({
    kind: "work_unit.created",
    message: `Work Unit accepted: ${input.title}`,
    workUnitId: unitId,
    agentId: input.ownerAgentId,
    meta: { template: template.key, tasks: template.tasks.length, owner: agent?.handle ?? input.ownerAgentId },
  });
  return { ok: true, workUnitId: unitId };
}

type LaneState = { running: number; limit: number };

function successRoll(task: Task): boolean {
  const roll = jitter(`${task.id}:${task.attempts}`);
  const base = task.queue === "browser" ? 0.14 : task.mod === "verify" ? 0.08 : 0.05;
  const penalty = task.attempts > 0 ? base / 2 : base;
  return roll > penalty;
}

async function finishTask(task: Task): Promise<void> {
  const now = new Date();
  const success = successRoll(task);
  const approved = await db
    .select({ id: approvals.id })
    .from(approvals)
    .where(and(eq(approvals.taskId, task.id), eq(approvals.status, "approved")))
    .limit(1);

  if (task.consequential && approved.length === 0) {
    const [claimed] = await db
      .update(tasks)
      .set({ status: "waiting_approval", leaseOwner: null, leaseExpiresAt: null })
      .where(and(eq(tasks.id, task.id), eq(tasks.status, "running")))
      .returning();
    if (!claimed) return;
    await db.insert(approvals).values({
      id: id("apr"),
      workUnitId: task.workUnitId,
      taskId: task.id,
      agentId: task.agentId,
      action: task.mod.startsWith("storage") ? "storage.write" : "external.commit",
      resource: `project:${task.workUnitId}`,
      risk: task.tier === 2 ? "high" : "medium",
      reason: `${task.title} writes outside the sandbox. Capability token scope allows it; human authorization is still required.`,
      costUsd: Number(task.costEstimate).toFixed(4),
    });
    await logEvent({
      kind: "approval.requested",
      message: `Human authorization requested before: ${task.title}`,
      workUnitId: task.workUnitId,
      taskId: task.id,
      agentId: task.agentId,
    });
    return;
  }

  const attemptNo = task.attempts + 1;
  const cost = task.model === "deterministic" ? 0 : Number((Number(task.costEstimate) * (0.75 + jitter(task.id) * 0.6)).toFixed(4));
  const tokensIn = task.model === "deterministic" ? 0 : Math.round(1200 + jitter(`${task.id}:in`) * 7800);
  const tokensOut = task.model === "deterministic" ? 0 : Math.round(280 + jitter(`${task.id}:out`) * 1300);

  if (!success) {
    if (task.attempts + 1 < task.maxAttempts) {
      const [claimed] = await db
        .update(tasks)
        .set({
          status: "ready",
          attempts: attemptNo,
          leaseOwner: null,
          leaseExpiresAt: null,
          failureReason: "tool timeout — retry scheduled with backoff",
        })
        .where(and(eq(tasks.id, task.id), eq(tasks.status, "running")))
        .returning();
      if (!claimed) return;
      await logEvent({
        kind: "task.retry",
        message: `Retry ${attemptNo}/${task.maxAttempts}: ${task.title}`,
        workUnitId: task.workUnitId,
        taskId: task.id,
        agentId: task.agentId,
        meta: { reason: "tool timeout" },
      });
      return;
    }

    const [claimed] = await db
      .update(tasks)
      .set({
        status: "failed",
        attempts: attemptNo,
        completedAt: now,
        leaseOwner: null,
        leaseExpiresAt: null,
        failureReason: "isolated execution failed after bounded retries",
        costActual: cost.toFixed(4),
        tokensIn,
        tokensOut,
      })
      .where(and(eq(tasks.id, task.id), eq(tasks.status, "running")))
      .returning();
    if (!claimed) return;
    await db
      .update(workUnits)
      .set({ status: "failed", completedAt: now })
      .where(eq(workUnits.id, task.workUnitId));
    await db
      .update(agents)
      .set({ spentUsd: sql`${agents.spentUsd} + ${cost}` })
      .where(eq(agents.id, task.agentId));
    await logEvent({
      kind: "task.failed",
      message: `Task exhausted retries: ${task.title}`,
      workUnitId: task.workUnitId,
      taskId: task.id,
      agentId: task.agentId,
    });
    return;
  }

  const verifyStatus = task.mod === "verify" ? (jitter(`${task.id}:verify`) > 0.1 ? "passed" : "failed") : "pending";
  const [claimed] = await db
    .update(tasks)
    .set({
      status: "succeeded",
      attempts: attemptNo,
      completedAt: now,
      leaseOwner: null,
      leaseExpiresAt: null,
      costActual: cost.toFixed(4),
      tokensIn,
      tokensOut,
      verifyStatus,
      output:
        task.mod === "verify"
          ? verifyStatus === "passed"
            ? "All acceptance assertions reproduced; no unsupported claims detected."
            : "Verifier rejected the deliverable: one price claim lacked a primary source."
          : `${task.title} completed in ${task.queue} lane at tier ${task.tier}. Artifact reference stored; content hash recorded in the receipt.`,
    })
    .where(and(eq(tasks.id, task.id), eq(tasks.status, "running")))
    .returning();
  if (!claimed) return;

  const idempotencyKey = `${task.workUnitId}:${task.id}:${attemptNo}`;
  const inserted = await db
    .insert(receipts)
    .values({
      id: id("rct"),
      workUnitId: task.workUnitId,
      taskId: task.id,
      agentId: task.agentId,
      action: task.mod,
      resource: `artifact://${task.workUnitId}/${task.position}-${shortHash(task.title)}`,
      domain: task.queue === "browser" ? "vendor.example" : null,
      outcome: "committed",
      tier: task.tier,
      costUsd: cost.toFixed(4),
      latencyMs: task.durationMs,
      signature: shortHash(`${task.id}:${attemptNo}:receipt`),
      idempotencyKey,
    })
    .onConflictDoNothing({ target: receipts.idempotencyKey })
    .returning();

  if (inserted.length === 0) {
    await db.insert(receipts).values({
      id: id("rct"),
      workUnitId: task.workUnitId,
      taskId: task.id,
      agentId: task.agentId,
      action: task.mod,
      resource: `artifact://${task.workUnitId}/${task.position}`,
      outcome: "reconciled",
      tier: task.tier,
      costUsd: "0",
      latencyMs: 0,
      signature: shortHash(`${task.id}:duplicate`),
      idempotencyKey: null,
    });
    await logEvent({
      kind: "receipt.reconciled",
      message: `Duplicate completion reconciled, not re-executed: ${task.title}`,
      workUnitId: task.workUnitId,
      taskId: task.id,
      agentId: task.agentId,
    });
  }

  await db
    .update(agents)
    .set({ spentUsd: sql`${agents.spentUsd} + ${cost}`, lastActiveAt: now })
    .where(eq(agents.id, task.agentId));
  await db
    .update(workUnits)
    .set({ spentUsd: sql`${workUnits.spentUsd} + ${cost}` })
    .where(eq(workUnits.id, task.workUnitId));

  if (task.gauntlet) {
    const [unit] = await db.select().from(workUnits).where(eq(workUnits.id, task.workUnitId)).limit(1);
    const rounds = await db
      .select({ n: count() })
      .from(gauntletRounds)
      .where(eq(gauntletRounds.workUnitId, task.workUnitId));
    if (Number(rounds[0]?.n ?? 0) === 0 && unit) {
      const built = buildGauntletArtifact(unit.template, unit.objective, 1, unit.bar);
      await db.insert(gauntletRounds).values({
        id: id("gnt"),
        workUnitId: task.workUnitId,
        taskId: task.id,
        round: 1,
        bar: unit.bar,
        artifactTitle: built.artifactTitle,
        artifact: built.artifact,
        criticVerdict: built.criticVerdict,
        gap: built.gap,
        criticNote: built.criticNote,
        costUsd: cost.toFixed(4),
      });
      await logEvent({
        kind: "gauntlet.round",
        message: `Gauntlet round 1: critic picks the bar. Gap named.`,
        workUnitId: task.workUnitId,
        taskId: task.id,
        agentId: task.agentId,
      });
    }
  }

  if (["http", "reasoning", "memory.retrieve", "sql.read", "browser.isolated"].includes(task.mod)) {
    const [unit] = await db.select().from(workUnits).where(eq(workUnits.id, task.workUnitId)).limit(1);
    const [agent] = await db.select().from(agents).where(eq(agents.id, task.agentId)).limit(1);
    if (unit) {
      const confidence = Math.round(52 + jitter(`${task.id}:mem`) * 36);
      await db.insert(memories).values({
        id: id("mem"),
        agentId: task.agentId,
        scope: agent?.memoryScope ?? `project:${unit.template}`,
        kind: task.queue === "browser" ? "semantic" : "episodic",
        content:
          task.queue === "browser"
            ? `A browser session authenticated against an approved vendor portal yielded a verified price point for "${unit.title}". Contexts are isolated per task; cookies never leave the session.`
            : `For "${unit.title}", the ${task.queue} lane found that ${task.title.toLowerCase()} produced a defensible intermediate result. Reuse the extraction pattern, re-check the primary source before promotion.`,
        trust: "proposed",
        confidence,
        sourceTaskId: task.id,
        sourceWorkUnitId: task.workUnitId,
        provenance: `task ${task.mod} · receipt ${idempotencyKey} · signature ${shortHash(task.id)}`,
      });
    }
  }

  if (task.mod === "memory.compile") {
    await db
      .update(memories)
      .set({ trust: "curated", promotedAt: now })
      .where(and(eq(memories.sourceWorkUnitId, task.workUnitId), eq(memories.trust, "proposed"), gte(memories.confidence, 70)));
    await logEvent({
      kind: "memory.compiled",
      message: `Memory compiler promoted high-confidence candidates for ${task.workUnitId}`,
      workUnitId: task.workUnitId,
      taskId: task.id,
      agentId: task.agentId,
    });
  }

  await logEvent({
    kind: "task.committed",
    message: `${task.title} committed · tier ${task.tier} · $${cost.toFixed(3)}`,
    workUnitId: task.workUnitId,
    taskId: task.id,
    agentId: task.agentId,
  });

  await refreshUnit(task.workUnitId);
}

async function refreshUnit(unitId: string) {
  const rows = await db.select().from(tasks).where(eq(tasks.workUnitId, unitId));
  const now = new Date();

  const blocked = rows.filter((t) => t.status === "blocked");
  if (blocked.length) {
    const succeeded = new Set(rows.filter((t) => t.status === "succeeded").map((t) => t.id));
    for (const task of blocked) {
      if (task.dependsOn.every((dep) => succeeded.has(dep))) {
        await db.update(tasks).set({ status: "ready" }).where(eq(tasks.id, task.id));
        await logEvent({
          kind: "task.ready",
          message: `Dependencies satisfied: ${task.title}`,
          workUnitId: unitId,
          taskId: task.id,
          agentId: task.agentId,
        });
      }
    }
  }

  const fresh = await db.select().from(tasks).where(eq(tasks.workUnitId, unitId));
  const [unit] = await db.select().from(workUnits).where(eq(workUnits.id, unitId)).limit(1);
  if (!unit) return;

  const failed = fresh.find((t) => t.status === "failed");
  const verifierFailed = fresh.find((t) => t.mod === "verify" && t.verifyStatus === "failed");
  const pendingApproval = fresh.some((t) => t.status === "waiting_approval");
  const allDone = fresh.every((t) => t.status === "succeeded");
  const anyActive = fresh.some((t) => ["running", "ready", "blocked"].includes(t.status));

  let status = unit.status;
  if (failed) status = "failed";
  else if (pendingApproval) status = "waiting_approval";
  else if (allDone) status = verifierFailed ? "failed" : "done";
  else if (anyActive) status = "running";

  if (status !== unit.status || (status === "done" && !unit.completedAt)) {
    await db
      .update(workUnits)
      .set({
        status,
        completedAt: ["done", "failed"].includes(status) ? now : null,
      })
      .where(eq(workUnits.id, unitId));
    if (status === "done") {
      await logEvent({
        kind: "work_unit.done",
        message: `Work Unit completed and verified: ${unit.title}`,
        workUnitId: unitId,
        agentId: unit.ownerAgentId,
      });
    }
  }
}

export type TickResult = {
  committed: number;
  leased: number;
  retries: number;
  running: number;
  ready: number;
  scaled: number;
  budgetBlocked: boolean;
};

export async function tick(): Promise<TickResult> {
  const policy = await getPolicy();
  const now = new Date();
  const result: TickResult = { committed: 0, leased: 0, retries: 0, running: 0, ready: 0, scaled: 1, budgetBlocked: false };

  const runningTasks = await db.select().from(tasks).where(eq(tasks.status, "running"));
  for (const task of runningTasks) {
    if (task.startedAt && now.getTime() - task.startedAt.getTime() >= task.durationMs) {
      await finishTask(task);
      result.committed += 1;
    }
  }

  const totalSpendRows = await db.select({ total: sql<string>`coalesce(sum(${workUnits.spentUsd}), 0)` }).from(workUnits);
  const totalSpend = Number(totalSpendRows[0]?.total ?? 0);
  if (totalSpend >= Number(policy.budgetCeilingUsd)) result.budgetBlocked = true;

  const recent = await db
    .select({ status: tasks.status })
    .from(tasks)
    .where(and(gte(tasks.completedAt, new Date(now.getTime() - 20 * 60_000)), inArray(tasks.status, ["succeeded", "failed"])));
  const failures = recent.filter((r) => r.status === "failed").length;
  const failureRate = recent.length ? failures / recent.length : 0;
  const scale = !policy.autoscale ? 1 : Math.max(0.4, Math.min(1, 1.05 - Math.max(0, failureRate - 0.1) * 2.5));
  result.scaled = Number(scale.toFixed(2));

  const lanes: Record<QueueName, LaneState> = {
    interactive: { running: 0, limit: Math.max(1, Math.floor(policy.interactive * scale)) },
    io: { running: 0, limit: Math.max(1, Math.floor(policy.io * scale)) },
    compute: { running: 0, limit: Math.min(policy.sandboxSlots, Math.max(1, Math.floor(policy.compute * scale))) },
    browser: { running: 0, limit: Math.min(policy.browserPool, Math.max(1, Math.floor(policy.browser * scale))) },
  };

  const stillRunning = await db.select().from(tasks).where(eq(tasks.status, "running"));
  for (const t of stillRunning) {
    const lane = lanes[t.queue as QueueName];
    if (lane) lane.running += 1;
  }
  const modelRunning = stillRunning.filter((t) => t.queue !== "compute").length;
  const providerCap = Math.min(policy.providerConcurrency, policy.tenantConcurrency);

  const readyTasks = await db
    .select()
    .from(tasks)
    .where(eq(tasks.status, "ready"));
  result.ready = readyTasks.length;

  const units = await db.select().from(workUnits);
  const priorityOf = new Map(units.map((u) => [u.id, u.priority]));
  readyTasks.sort((a, b) => (priorityOf.get(b.workUnitId) ?? 3) - (priorityOf.get(a.workUnitId) ?? 3) || a.position - b.position);

  let admitted = 0;
  for (const task of readyTasks) {
    if (result.budgetBlocked) break;
    const lane = lanes[task.queue as QueueName];
    if (!lane) continue;
    if (lane.running >= lane.limit) continue;
    if (task.queue !== "compute" && modelRunning + admitted >= providerCap) continue;
    if (task.queue === "browser" && lane.running >= policy.browserPool) continue;

    const leaseOwner = `wrk_${crypto.randomBytes(4).toString("hex")}`;
    const [claimed] = await db
      .update(tasks)
      .set({
        status: "running",
        leaseOwner,
        startedAt: now,
        leaseExpiresAt: new Date(now.getTime() + task.durationMs),
      })
      .where(and(eq(tasks.id, task.id), eq(tasks.status, "ready")))
      .returning();
    if (!claimed) continue;

    lane.running += 1;
    admitted += 1;
    result.leased += 1;

    await db.insert(workers).values({
      id: leaseOwner,
      pool: task.queue,
      status: "busy",
      taskId: task.id,
      memoryMb: task.queue === "browser" ? 104 : task.queue === "compute" ? 256 : 64,
      tier: task.tier,
      startedAt: now,
    });
    await logEvent({
      kind: "task.leased",
      message: `${task.title} leased to ${leaseOwner} (${task.queue} lane, tier ${task.tier})`,
      workUnitId: task.workUnitId,
      taskId: task.id,
      agentId: task.agentId,
      meta: { pool: task.queue, tier: task.tier, model: task.model },
    });
  }

  const runningNow = await db.select({ id: tasks.id, agentId: tasks.agentId, workUnitId: tasks.workUnitId }).from(tasks).where(eq(tasks.status, "running"));
  result.running = runningNow.length;

  if (runningNow.length) {
    await db.delete(workers).where(notInArray(workers.taskId, runningNow.map((r) => r.id)));
  } else {
    await db.delete(workers);
  }

  const activeAgentIds = [...new Set(runningNow.map((r) => r.agentId))];
  await db.update(agents).set({ status: "active" }).where(inArray(agents.id, activeAgentIds.length ? activeAgentIds : ["none"]));
  await db
    .update(agents)
    .set({ status: "hibernating" })
    .where(and(notInArray(agents.id, activeAgentIds.length ? activeAgentIds : ["none"]), notInArray(agents.status, ["paused", "retired"])));

  const staleSessions = await db
    .select()
    .from(sessions)
    .where(and(eq(sessions.state, "active"), sql`${sessions.lastActiveAt} < now() - interval '120 seconds'`));
  if (staleSessions.length) {
    await db
      .update(sessions)
      .set({ state: "hibernating", residentKb: 0 })
      .where(inArray(sessions.id, staleSessions.map((s) => s.id)));
    await logEvent({
      kind: "session.hibernated",
      message: `${staleSessions.length} idle session${staleSessions.length === 1 ? "" : "s"} hibernated; resident memory released`,
      meta: { sessions: staleSessions.length },
    });
  }
  if (runningNow.length) {
    await db
      .update(sessions)
      .set({ state: "active", residentKb: 640, lastActiveAt: now })
      .where(and(eq(sessions.state, "hibernating"), inArray(sessions.agentId, activeAgentIds)));
  }

  const [activeTurnsRow] = await db.select({ n: count() }).from(tasks).where(eq(tasks.status, "running"));
  const [idleSessionsRow] = await db.select({ n: count() }).from(sessions).where(eq(sessions.state, "hibernating"));
  const [queueDepthRow] = await db.select({ n: count() }).from(tasks).where(eq(tasks.status, "ready"));
  const resident = runningNow.reduce((sum, r) => sum + 64, 0);
  await db.insert(metrics).values({
    id: id("mtr"),
    at: now,
    activeTurns: Number(activeTurnsRow?.n ?? 0),
    idleSessions: Number(idleSessionsRow?.n ?? 0),
    queueDepth: Number(queueDepthRow?.n ?? 0),
    running: Number(activeTurnsRow?.n ?? 0),
    committed: result.committed,
    spendUsd: totalSpend.toFixed(4),
    residentMb: resident,
  });

  return result;
}

export async function decideApproval(approvalId: string, decision: "approved" | "denied"): Promise<void> {
  const now = new Date();
  const [row] = await db
    .update(approvals)
    .set({ status: decision, decidedBy: "human:operator", decidedAt: now })
    .where(and(eq(approvals.id, approvalId), eq(approvals.status, "pending")))
    .returning();
  if (!row) return;

  if (decision === "approved") {
    await db
      .update(tasks)
      .set({ status: "running", startedAt: now, leaseExpiresAt: new Date(now.getTime() + 1500), leaseOwner: "wrk_approval" })
      .where(eq(tasks.id, row.taskId));
    await db.insert(workers).values({
      id: `wrk_apr_${crypto.randomBytes(3).toString("hex")}`,
      pool: "io",
      status: "busy",
      taskId: row.taskId,
      memoryMb: 64,
      tier: 0,
    });
  } else {
    await db
      .update(tasks)
      .set({ status: "failed", completedAt: now, failureReason: "human authorization denied" })
      .where(eq(tasks.id, row.taskId));
    await db.update(workUnits).set({ status: "failed", completedAt: now }).where(eq(workUnits.id, row.workUnitId));
  }
  await logEvent({
    kind: decision === "approved" ? "approval.approved" : "approval.denied",
    message: `${decision === "approved" ? "Authorized" : "Denied"} by human: ${row.action} on ${row.resource}`,
    workUnitId: row.workUnitId,
    taskId: row.taskId,
    agentId: row.agentId,
  });
}

export async function advanceGauntlet(workUnitId: string): Promise<{ ok: boolean; verdict?: string }> {
  const [unit] = await db.select().from(workUnits).where(eq(workUnits.id, workUnitId)).limit(1);
  if (!unit) return { ok: false };
  const [latest] = await db
    .select()
    .from(gauntletRounds)
    .where(eq(gauntletRounds.workUnitId, workUnitId))
    .orderBy(desc(gauntletRounds.round))
    .limit(1);
  const nextRound = (latest?.round ?? 0) + 1;
  const [gauntletTask] = await db
    .select()
    .from(tasks)
    .where(and(eq(tasks.workUnitId, workUnitId), eq(tasks.gauntlet, true)))
    .limit(1);
  const built = buildGauntletArtifact(unit.template, unit.objective, nextRound, unit.bar);
  const cost = Number((0.06 + jitter(`${workUnitId}:${nextRound}`) * 0.09).toFixed(4));
  await db.insert(gauntletRounds).values({
    id: id("gnt"),
    workUnitId,
    taskId: gauntletTask?.id ?? null,
    round: nextRound,
    bar: unit.bar,
    artifactTitle: built.artifactTitle,
    artifact: built.artifact,
    criticVerdict: built.criticVerdict,
    gap: built.gap,
    criticNote: built.criticNote,
    costUsd: cost.toFixed(4),
  });
  await db.update(workUnits).set({ spentUsd: sql`${workUnits.spentUsd} + ${cost}` }).where(eq(workUnits.id, workUnitId));
  await logEvent({
    kind: "gauntlet.round",
    message: `Gauntlet round ${nextRound}: critic picks ${built.criticVerdict === "ours" ? "ours" : "the bar"} blind.`,
    workUnitId,
    agentId: unit.ownerAgentId,
    meta: { verdict: built.criticVerdict, gap: built.gap },
  });
  return { ok: true, verdict: built.criticVerdict };
}

export async function hibernateSession(sessionId: string, state: "active" | "hibernating"): Promise<void> {
  await db
    .update(sessions)
    .set({
      state,
      residentKb: state === "active" ? 640 : 0,
      lastActiveAt: new Date(),
    })
    .where(eq(sessions.id, sessionId));
  await logEvent({
    kind: state === "active" ? "session.resumed" : "session.hibernated",
    message: state === "active" ? "Session resumed from stored state" : "Session hibernated; state retained, memory released",
    meta: { sessionId },
  });
}

export async function seedIfEmpty(seed: () => Promise<void>): Promise<void> {
  const [row] = await db.select({ n: count() }).from(agents);
  if (Number(row?.n ?? 0) > 0) return;
  await seed();
}
