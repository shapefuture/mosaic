import crypto from "node:crypto";
import { and, count, eq } from "drizzle-orm";
import { db, pool } from "@/db";
import {
  agents,
  approvals,
  authorityEnvelopes,
  deliveryTasks,
  events,
  gauntletRounds,
  memories,
  metrics,
  qualificationRuns,
  receipts,
  runtimePolicy,
  sessions,
  skills,
  systemFlags,
  tasks,
  workers,
  workUnits,
} from "@/db/schema";
import { WORK_TEMPLATES, buildGauntletArtifact } from "@/lib/templates";
import { shortHash, signEnvelope, type EnvelopeClaims } from "@/lib/authority";

const rid = (p: string) => `${p}_${crypto.randomBytes(5).toString("hex")}`;
const minsAgo = (m: number) => new Date(Date.now() - m * 60_000);

type SeedAgent = {
  id: string;
  name: string;
  handle: string;
  role: string;
  department: string;
  status: string;
  capabilities: string[];
  memoryScope: string;
  authority: { actions: string[]; resources: string[]; domains: string[]; maxCost: number; delegationDepth: number };
  budgetUsd: number;
  spentUsd: number;
  color: string;
  glyph: string;
};

const SEED_AGENTS: SeedAgent[] = [
  {
    id: "agt_mira",
    name: "Mira Chen",
    handle: "mira.research",
    role: "Research analyst",
    department: "Intelligence",
    status: "active",
    capabilities: ["http.get", "browser.read", "extract.structured", "memory.retrieve", "sql.read"],
    memoryScope: "project:market-intelligence",
    authority: { actions: ["http.get", "browser.read", "memory.read"], resources: ["project:market-intelligence"], domains: ["vendor.example", "docs.cloudflare.com"], maxCost: 0.75, delegationDepth: 2 },
    budgetUsd: 30,
    spentUsd: 6.42,
    color: "#38bdf8",
    glyph: "◈",
  },
  {
    id: "agt_sable",
    name: "Sable Ops",
    handle: "sable.delivery",
    role: "Delivery lead",
    department: "Delivery",
    status: "active",
    capabilities: ["sandbox.exec", "storage.write", "http.post", "verify.run", "delegate.task"],
    memoryScope: "project:delivery",
    authority: { actions: ["sandbox.exec", "storage.write", "http.post", "verify.run"], resources: ["project:delivery"], domains: ["api.staging.example"], maxCost: 2.5, delegationDepth: 1 },
    budgetUsd: 45,
    spentUsd: 18.1,
    color: "#a78bfa",
    glyph: "▲",
  },
  {
    id: "agt_iris",
    name: "Iris Kwan",
    handle: "iris.verifier",
    role: "Independent verifier",
    department: "Governance",
    status: "hibernating",
    capabilities: ["verify.run", "receipt.inspect", "policy.evaluate", "sql.read"],
    memoryScope: "org:governance",
    authority: { actions: ["verify.run", "receipt.inspect", "policy.evaluate"], resources: ["project:*"], domains: [], maxCost: 0.2, delegationDepth: 0 },
    budgetUsd: 18,
    spentUsd: 3.05,
    color: "#f472b6",
    glyph: "◉",
  },
  {
    id: "agt_nnamdi",
    name: "Nnamdi Okafor",
    handle: "nnamdi.browser",
    role: "Browser scout",
    department: "Intelligence",
    status: "hibernating",
    capabilities: ["browser.read", "browser.context", "http.get", "storage.download"],
    memoryScope: "session:browser-vault",
    authority: { actions: ["browser.read", "browser.context", "http.get"], resources: ["session:vault"], domains: ["vendor.example", "portal.example"], maxCost: 1.2, delegationDepth: 1 },
    budgetUsd: 22,
    spentUsd: 4.7,
    color: "#fbbf24",
    glyph: "◇",
  },
  {
    id: "agt_orin",
    name: "Orin Vale",
    handle: "orin.codesmith",
    role: "Code specialist",
    department: "Delivery",
    status: "hibernating",
    capabilities: ["sandbox.fork", "sandbox.exec", "storage.write", "test.run"],
    memoryScope: "project:platform",
    authority: { actions: ["sandbox.exec", "sandbox.fork", "test.run", "storage.write"], resources: ["project:platform"], domains: ["registry.example"], maxCost: 1.5, delegationDepth: 1 },
    budgetUsd: 38,
    spentUsd: 11.3,
    color: "#34d399",
    glyph: "▣",
  },
  {
    id: "agt_vala",
    name: "Vala Rook",
    handle: "vala.memory",
    role: "Memory curator",
    department: "Knowledge",
    status: "hibernating",
    capabilities: ["memory.retrieve", "memory.compile", "sql.read", "extract.structured"],
    memoryScope: "org:knowledge",
    authority: { actions: ["memory.read", "memory.write", "sql.read"], resources: ["org:knowledge"], domains: [], maxCost: 0.4, delegationDepth: 1 },
    budgetUsd: 20,
    spentUsd: 2.9,
    color: "#22d3ee",
    glyph: "◆",
  },
  {
    id: "agt_priya",
    name: "Priya Raman",
    handle: "priya.authority",
    role: "Policy warden",
    department: "Security",
    status: "hibernating",
    capabilities: ["policy.evaluate", "authority.issue", "authority.revoke", "receipt.inspect"],
    memoryScope: "org:security",
    authority: { actions: ["policy.evaluate", "authority.issue", "receipt.inspect"], resources: ["org:security", "project:*"], domains: [], maxCost: 0.3, delegationDepth: 0 },
    budgetUsd: 25,
    spentUsd: 1.85,
    color: "#f87171",
    glyph: "◍",
  },
  {
    id: "agt_halo",
    name: "Halo",
    handle: "halo.scheduler",
    role: "Runtime scheduler",
    department: "Platform",
    status: "hibernating",
    capabilities: ["scheduler.tick", "queue.inspect", "budget.enforce"],
    memoryScope: "org:platform",
    authority: { actions: ["scheduler.tick", "queue.inspect"], resources: ["org:platform"], domains: [], maxCost: 0.05, delegationDepth: 0 },
    budgetUsd: 10,
    spentUsd: 0.31,
    color: "#c4b5fd",
    glyph: "✦",
  },
];

const SEED_SESSIONS = [
  { agent: "agt_mira", title: "Pricing page re-check — vendor portal", state: "active", kb: 46 },
  { agent: "agt_sable", title: "Staging release thread", state: "active", kb: 58 },
  { agent: "agt_iris", title: "Verification dispute #412", state: "hibernating", kb: 22 },
  { agent: "agt_nnamdi", title: "Authenticated portal take-over", state: "hibernating", kb: 34 },
  { agent: "agt_orin", title: "Copy-on-write sandbox branch", state: "hibernating", kb: 71 },
  { agent: "agt_vala", title: "Memory compiler review", state: "hibernating", kb: 18 },
  { agent: "agt_priya", title: "Authority envelope audit", state: "hibernating", kb: 12 },
  { agent: "agt_mira", title: "Buyer-intent source set", state: "active", kb: 39 },
  { agent: "agt_halo", title: "Queue pressure review", state: "hibernating", kb: 9 },
  { agent: "agt_sable", title: "Incident replay — duplicate write", state: "hibernating", kb: 27 },
  { agent: "agt_iris", title: "Acceptance criteria challenge", state: "hibernating", kb: 15 },
  { agent: "agt_vala", title: "Skill promotion: price extraction v3", state: "hibernating", kb: 21 },
];

const SEED_SKILLS = [
  { agent: "agt_mira", name: "pricing-extract", version: "v3.1.0", successRate: 94, evaluations: 41, status: "active" },
  { agent: "agt_mira", name: "competitor-discovery", version: "v2.4.0", successRate: 88, evaluations: 22, status: "active" },
  { agent: "agt_nnamdi", name: "portal-login-recovery", version: "v1.2.0", successRate: 81, evaluations: 14, status: "active" },
  { agent: "agt_orin", name: "cow-sandbox-fork", version: "v2.0.0", successRate: 96, evaluations: 33, status: "active" },
  { agent: "agt_iris", name: "claim-source-audit", version: "v4.0.1", successRate: 97, evaluations: 57, status: "active" },
  { agent: "agt_vala", name: "memory-dedupe", version: "v1.8.0", successRate: 78, evaluations: 19, status: "quarantined" },
];

type TaskSeed = {
  pos: number;
  status: "succeeded" | "running" | "ready" | "blocked" | "waiting_approval" | "failed";
  startedMin?: number;
  durationMs?: number;
  verify?: "pending" | "passed" | "failed";
};

type UnitSeed = {
  id: string;
  title: string;
  objective: string;
  template: string;
  owner: string;
  status: string;
  priority: number;
  spent: number;
  createdMin: number;
  completedMin?: number;
  taskStates: TaskSeed[];
};

const SEED_UNITS: UnitSeed[] = [
  {
    id: "wu_market_q3",
    title: "Q3 buyer-intent scan: agent infrastructure",
    objective:
      "Produce a decision-ready brief on who is buying agent infrastructure in Q3, what they pay, and which three claims in the category do not survive a primary-source check.",
    template: "market_intel",
    owner: "agt_mira",
    status: "running",
    priority: 5,
    spent: 0.42,
    createdMin: 46,
    taskStates: [
      { pos: 0, status: "succeeded", startedMin: 44 },
      { pos: 1, status: "succeeded", startedMin: 41 },
      { pos: 2, status: "running", startedMin: 0, durationMs: 60000 },
      { pos: 3, status: "ready" },
      { pos: 4, status: "succeeded", startedMin: 36 },
      { pos: 5, status: "blocked" },
      { pos: 6, status: "blocked" },
      { pos: 7, status: "blocked" },
      { pos: 8, status: "blocked" },
    ],
  },
  {
    id: "wu_delivery_slice",
    title: "Ship durable task slice to staging",
    objective:
      "Deliver the durable task slice: typed API contracts, queue leases, idempotent receipts and the verification gate. Everything proven in a disposable sandbox before merge.",
    template: "code_delivery",
    owner: "agt_sable",
    status: "waiting_approval",
    priority: 4,
    spent: 1.18,
    createdMin: 132,
    taskStates: [
      { pos: 0, status: "succeeded", startedMin: 130 },
      { pos: 1, status: "succeeded", startedMin: 126 },
      { pos: 2, status: "succeeded", startedMin: 120 },
      { pos: 3, status: "succeeded", startedMin: 119 },
      { pos: 4, status: "succeeded", startedMin: 112, verify: "passed" },
      { pos: 5, status: "succeeded", startedMin: 104 },
      { pos: 6, status: "succeeded", startedMin: 98, verify: "passed" },
      { pos: 7, status: "succeeded", startedMin: 92 },
      { pos: 8, status: "waiting_approval" },
    ],
  },
  {
    id: "wu_synthesis",
    title: "Synthesis — what actually limits parallel agents",
    objective:
      "Explain, for a technical buyer, what limits useful parallelism in agent platforms. Every number must be traced to a primary source at the point of use.",
    template: "research_synthesis",
    owner: "agt_mira",
    status: "done",
    priority: 3,
    spent: 0.61,
    createdMin: 640,
    completedMin: 520,
    taskStates: [
      { pos: 0, status: "succeeded", startedMin: 638 },
      { pos: 1, status: "succeeded", startedMin: 630 },
      { pos: 2, status: "succeeded", startedMin: 629 },
      { pos: 3, status: "succeeded", startedMin: 620 },
      { pos: 4, status: "succeeded", startedMin: 610 },
      { pos: 5, status: "succeeded", startedMin: 600 },
      { pos: 6, status: "succeeded", startedMin: 570, verify: "passed" },
      { pos: 7, status: "succeeded", startedMin: 540 },
    ],
  },
  {
    id: "wu_audit",
    title: "Quarterly external-action reconciliation",
    objective:
      "Reconcile every external side effect against its receipt, prove duplicates were not re-executed, and publish the attestation pack.",
    template: "audit_reconciliation",
    owner: "agt_iris",
    status: "running",
    priority: 4,
    spent: 0.19,
    createdMin: 28,
    taskStates: [
      { pos: 0, status: "succeeded", startedMin: 26 },
      { pos: 1, status: "succeeded", startedMin: 22 },
      { pos: 2, status: "running", startedMin: 0, durationMs: 45000 },
      { pos: 3, status: "blocked" },
      { pos: 4, status: "blocked" },
      { pos: 5, status: "blocked" },
    ],
  },
];

const SEED_MEMORIES = [
  { agent: "agt_mira", kind: "semantic", content: "Vendor 'Northwind' publishes a usage-tier price that changes on the 1st of each month; always re-fetch instead of caching beyond 20 days.", trust: "curated", confidence: 91, scope: "project:market-intelligence" },
  { agent: "agt_mira", kind: "preference", content: "Briefs for this org lead with the recommendation, then three sourced observations, then the cost tradeoff. No executive summary heading.", trust: "curated", confidence: 96, scope: "org:house-style" },
  { agent: "agt_nnamdi", kind: "procedural", content: "Portal login recovery: request human Live View takeover at the MFA step, never store the credential, reuse the same isolated context afterwards.", trust: "curated", confidence: 89, scope: "session:browser-vault" },
  { agent: "agt_orin", kind: "procedural", content: "Fork the prepared sandbox snapshot instead of cloning the repo; startup drops from 41s to 1.8s for the test branch.", trust: "curated", confidence: 93, scope: "project:platform" },
  { agent: "agt_iris", kind: "semantic", content: "A price claim without a fetched page hash is unverifiable; reject at the verifier gate rather than flagging for later.", trust: "curated", confidence: 97, scope: "org:governance" },
  { agent: "agt_mira", kind: "episodic", content: "Q3 scan: two vendors claim 'unlimited agents'; both fair-use clauses cap concurrent executions at 25.", trust: "proposed", confidence: 64, scope: "project:market-intelligence" },
  { agent: "agt_sable", kind: "episodic", content: "Staging deploy succeeded after the third retry; retries were caused by a cold connection pool, not by task logic.", trust: "proposed", confidence: 58, scope: "project:delivery" },
  { agent: "agt_vala", kind: "procedural", content: "Dedupe candidate facts by normalised subject + date window before promotion; 31% of proposals are restatements.", trust: "proposed", confidence: 71, scope: "org:knowledge" },
  { agent: "agt_halo", kind: "semantic", content: "Browser lane is the binding constraint once more than two concurrent pages are open; the io lane absorbs the overflow cheaply.", trust: "curated", confidence: 87, scope: "org:platform" },
  { agent: "agt_priya", kind: "semantic", content: "Child tasks inherit authority; a child may never hold a higher delegation depth than its parent envelope.", trust: "curated", confidence: 99, scope: "org:security" },
];

const DELIVERY = [
  { stage: "Runtime", code: "D1", title: "Durable identities + session store", status: "done", acceptance: "Agents persist with no resident worker; sessions hibernate and resume.", evidence: "12 seeded sessions, 9 hibernated, resident 0 KB each" },
  { stage: "Runtime", code: "D2", title: "Universal Work Engine", status: "done", acceptance: "A plan compiles to a DAG with dependencies, budgets and acceptance criteria.", evidence: "4 templates, 9 max task boundaries, deps enforced at readiness" },
  { stage: "Execution", code: "D3", title: "Bounded adaptive scheduler", status: "done", acceptance: "Concurrency derived from the narrowest constraint; no unbounded fan-out.", evidence: "4 lanes, tenant/provider/browser/sandbox/budget minima applied per tick" },
  { stage: "Execution", code: "D4", title: "Three execution tiers", status: "done", acceptance: "Tier 0 default, tier 1 containers, tier 2 microVM only when needed.", evidence: "Tier recorded per task and per receipt" },
  { stage: "State", code: "D5", title: "Receipts + idempotent commit", status: "done", acceptance: "Duplicate completions reconcile instead of repeating side effects.", evidence: "unique idempotency key, reconciled outcome row" },
  { stage: "State", code: "D6", title: "Memory compiler", status: "done", acceptance: "Candidates stay proposed until deduped, scoped and verified.", evidence: "proposed → curated transition on compile task only" },
  { stage: "Security", code: "D7", title: "Authority envelopes", status: "done", acceptance: "Signed, scoped, short-lived tokens; all six invariants evaluated.", evidence: "signature, scope, egress, cost, depth, revocation checks" },
  { stage: "Governance", code: "D8", title: "Human approval centre", status: "done", acceptance: "Consequential writes pause for a human and are logged.", evidence: "staging commit waiting on operator authorization" },
  { stage: "Quality", code: "D9", title: "Gauntlet quality loop", status: "in_progress", acceptance: "A separate critic compares blind against a named bar until ours wins.", evidence: "3 rounds on the synthesis unit; round 3 won blind" },
  { stage: "Quality", code: "D10", title: "Capacity qualification", status: "in_progress", acceptance: "Idle sessions, fan-out, failure injection and duplicate events measured.", evidence: "harness built; run from Scheduler to capture evidence" },
  { stage: "Governance", code: "D11", title: "Delivery ledger continuity", status: "done", acceptance: "Mission, criteria and evidence survive interruption.", evidence: "this ledger; no completion without evidence string" },
  { stage: "Doctrine", code: "D12", title: "Portable adapter seams", status: "planned", acceptance: "Workflow, session, browser, sandbox and storage are swappable.", evidence: "" },
  { stage: "Doctrine", code: "D13", title: "Self-hosted inference pool", status: "blocked", acceptance: "Inference isolated from orchestration with continuous batching.", evidence: "", blocker: "No GPU capacity in this environment; design recorded, not deployed." },
];

async function isSeeded(): Promise<boolean> {
  const rows = await db.select().from(systemFlags).where(eq(systemFlags.key, "seeded")).limit(1);
  return rows[0]?.value === "1";
}

let seedPromise: Promise<void> | null = null;

/**
 * Concurrency-safe bootstrap: one advisory lock across processes, one memoised
 * promise inside the process. Partial seeds are wiped and retried.
 */
export async function ensureSeed(): Promise<void> {
  if (await isSeeded()) return;
  if (!seedPromise) {
    seedPromise = (async () => {
      const client = await pool.connect();
      try {
        await client.query("select pg_advisory_lock($1)", [918273645]);
        if (await isSeeded()) return;
        await clearSeededData();
        await seed();
        await db.insert(systemFlags).values({ key: "seeded", value: "1" }).onConflictDoUpdate({ target: systemFlags.key, set: { value: "1" } });
      } finally {
        await client.query("select pg_advisory_unlock($1)", [918273645]);
        client.release();
      }
    })().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  await seedPromise;
}

async function clearSeededData(): Promise<void> {
  for (const table of [
    metrics,
    events,
    receipts,
    gauntletRounds,
    approvals,
    memories,
    skills,
    sessions,
    tasks,
    workUnits,
    authorityEnvelopes,
    deliveryTasks,
    qualificationRuns,
    workers,
    agents,
    runtimePolicy,
  ]) {
    await db.delete(table);
  }
}

async function seed(): Promise<void> {
  await db.insert(runtimePolicy).values({ id: "default", maxFanout: 12 }).onConflictDoNothing();

  await db.insert(agents).values(
    SEED_AGENTS.map((a) => ({
      id: a.id,
      name: a.name,
      handle: a.handle,
      role: a.role,
      department: a.department,
      status: a.status,
      capabilities: a.capabilities,
      modelPolicy: { planner: "reasoning-xl", worker: "fast-s", verifier: "eval-m" },
      memoryScope: a.memoryScope,
      authority: a.authority,
      budgetUsd: a.budgetUsd.toFixed(4),
      spentUsd: a.spentUsd.toFixed(4),
      color: a.color,
      glyph: a.glyph,
      createdAt: minsAgo(60 * 24 * 40),
      lastActiveAt: minsAgo(3),
    })),
  );

  await db.insert(sessions).values(
    SEED_SESSIONS.map((s) => ({
      id: rid("ses"),
      agentId: s.agent,
      title: s.title,
      state: s.state,
      contextKb: s.kb,
      residentKb: s.state === "active" ? 620 : 0,
      transcript: [
        { role: "human", content: `Continue: ${s.title}`, at: minsAgo(90).toISOString() },
        {
          role: "agent",
          content:
            "Context package loaded from scoped records, not from a resident transcript. Tools remain behind the capability boundary. I will write back only at meaningful boundaries.",
          at: minsAgo(88).toISOString(),
        },
      ],
      pendingToolCalls: s.state === "hibernating" ? 1 : 0,
      createdAt: minsAgo(60 * 24 * 3),
      lastActiveAt: s.state === "active" ? minsAgo(1) : minsAgo(180),
    })),
  );

  await db.insert(skills).values(
    SEED_SKILLS.map((s) => ({
      id: rid("skl"),
      agentId: s.agent,
      name: s.name,
      version: s.version,
      successRate: s.successRate,
      evaluations: s.evaluations,
      status: s.status,
      lastUsedAt: minsAgo(60 + Math.round(Math.random() * 600)),
    })),
  );

  for (const unit of SEED_UNITS) {
    const template = WORK_TEMPLATES[unit.template];
    const taskIds = template.tasks.map(() => rid("tsk"));
    await db.insert(workUnits).values({
      id: unit.id,
      title: unit.title,
      objective: unit.objective,
      template: unit.template,
      ownerAgentId: unit.owner,
      status: unit.status,
      priority: unit.priority,
      fanoutLimit: template.tasks.length,
      budgetUsd: "8.0000",
      spentUsd: unit.spent.toFixed(4),
      bar: template.bar,
      acceptance: template.acceptance,
      idempotencyKey: `seed:${unit.id}`,
      createdAt: minsAgo(unit.createdMin),
      startedAt: minsAgo(unit.createdMin - 1),
      completedAt: unit.completedMin ? minsAgo(unit.completedMin) : null,
    });

    await db.insert(tasks).values(
      template.tasks.map((t, i) => {
        const state = unit.taskStates.find((s) => s.pos === i) ?? { pos: i, status: "blocked" as const };
        const isSucceeded = state.status === "succeeded";
        return {
          id: taskIds[i],
          workUnitId: unit.id,
          agentId: unit.owner,
          title: t.title,
          queue: t.queue,
          position: i,
          status: state.status,
          tier: t.tier,
          dependsOn: t.dependsOnPositions.map((p) => taskIds[p]),
          mod: t.mod,
          model: t.model,
          gauntlet: Boolean(t.gauntlet),
          consequential: Boolean(t.consequential),
          attempts: isSucceeded ? 1 : 0,
          durationMs: state.durationMs ?? t.durationMs,
          costEstimate: t.costEstimate.toFixed(4),
          costActual: isSucceeded ? (t.costEstimate * 0.94).toFixed(4) : "0",
          tokensIn: isSucceeded ? 2600 + i * 340 : 0,
          tokensOut: isSucceeded ? 620 + i * 90 : 0,
          leaseOwner: state.status === "running" ? "wrk_seeded" : null,
          leaseExpiresAt: state.status === "running" ? new Date(Date.now() + (state.durationMs ?? 30000)) : null,
          verifyStatus: state.verify ?? (t.mod === "verify" && isSucceeded ? "passed" : "pending"),
          startedAt: state.startedMin !== undefined ? minsAgo(state.startedMin) : null,
          completedAt: isSucceeded ? minsAgo(Math.max(1, (state.startedMin ?? 30) - 4)) : null,
          output: isSucceeded
            ? t.mod === "verify"
              ? "All acceptance assertions reproduced; no unsupported claims detected."
              : `${t.title} completed in the ${t.queue} lane at tier ${t.tier}; artifact reference and content hash recorded.`
            : null,
        };
      }),
    );

    const succeeded = template.tasks.filter((_, i) => unit.taskStates.find((s) => s.pos === i)?.status === "succeeded");
    if (succeeded.length) {
      await db.insert(receipts).values(
        succeeded.map((t, i) => ({
          id: rid("rct"),
          workUnitId: unit.id,
          taskId: taskIds[template.tasks.indexOf(t)],
          agentId: unit.owner,
          action: t.mod,
          resource: `artifact://${unit.id}/${t.title.toLowerCase().replace(/\s+/g, "-")}`,
          domain: t.queue === "browser" ? "vendor.example" : null,
          outcome: "committed" as const,
          tier: t.tier,
          costUsd: (t.costEstimate * 0.94).toFixed(4),
          latencyMs: t.durationMs,
          signature: shortHash(`${unit.id}:${i}`),
          idempotencyKey: `seed:${unit.id}:${i}`,
          createdAt: minsAgo(Math.max(1, (unit.taskStates.find((s) => s.pos === template.tasks.indexOf(t))?.startedMin ?? 20) - 1)),
        })),
      );
    }

    await db.insert(events).values([
      {
        id: rid("evt"),
        kind: "work_unit.created",
        message: `Work Unit accepted: ${unit.title}`,
        workUnitId: unit.id,
        agentId: unit.owner,
        meta: { template: unit.template },
        createdAt: minsAgo(unit.createdMin),
      },
      ...succeeded.slice(0, 4).map((t, i) => ({
        id: rid("evt"),
        kind: "task.committed",
        message: `${t.title} committed · tier ${t.tier}`,
        workUnitId: unit.id,
        taskId: taskIds[template.tasks.indexOf(t)],
        agentId: unit.owner,
        meta: { tier: t.tier },
        createdAt: minsAgo(Math.max(1, unit.createdMin - 6 - i * 3)),
      })),
    ]);
  }

  await db.insert(receipts).values({
    id: rid("rct"),
    workUnitId: "wu_delivery_slice",
    taskId: null,
    agentId: "agt_sable",
    action: "http.post",
    resource: "api.staging.example/deploys",
    domain: "api.staging.example",
    outcome: "reconciled",
    tier: 0,
    costUsd: "0",
    latencyMs: 0,
    signature: shortHash("reconciled-duplicate"),
    idempotencyKey: null,
    createdAt: minsAgo(88),
  });

  const gauntletArtifact = buildGauntletArtifact("research_synthesis", SEED_UNITS[2].objective, 3, WORK_TEMPLATES.research_synthesis.bar);
  const gauntletTaskId = await db
    .select({ id: tasks.id })
    .from(tasks)
    .where(and(eq(tasks.workUnitId, "wu_synthesis"), eq(tasks.gauntlet, true)))
    .limit(1);

  await db.insert(gauntletRounds).values([
    {
      id: rid("gnt"),
      workUnitId: "wu_synthesis",
      taskId: gauntletTaskId[0]?.id ?? null,
      round: 1,
      bar: WORK_TEMPLATES.research_synthesis.bar,
      artifactTitle: buildGauntletArtifact("research_synthesis", "synthesis", 1, "").artifactTitle,
      artifact: buildGauntletArtifact("research_synthesis", SEED_UNITS[2].objective, 1, WORK_TEMPLATES.research_synthesis.bar).artifact,
      criticVerdict: "bar",
      gap: "Claims carry no dated primary source; the bar footnotes every figure at the point of use.",
      criticNote: "Blind comparison, labels stripped. The bar is sharper and more useful to a decision-maker. Not close yet.",
      costUsd: "0.0800",
      createdAt: minsAgo(560),
    },
    {
      id: rid("gnt"),
      workUnitId: "wu_synthesis",
      taskId: gauntletTaskId[0]?.id ?? null,
      round: 2,
      bar: WORK_TEMPLATES.research_synthesis.bar,
      artifactTitle: buildGauntletArtifact("research_synthesis", "synthesis", 2, "").artifactTitle,
      artifact: buildGauntletArtifact("research_synthesis", SEED_UNITS[2].objective, 2, WORK_TEMPLATES.research_synthesis.bar).artifact,
      criticVerdict: "bar",
      gap: "Two sections describe the category instead of naming the three buyers who changed behaviour.",
      criticNote: "Blind comparison, labels stripped. Better sourcing, but the opening still buries the decision.",
      costUsd: "0.0700",
      createdAt: minsAgo(548),
    },
    {
      id: rid("gnt"),
      workUnitId: "wu_synthesis",
      taskId: gauntletTaskId[0]?.id ?? null,
      round: 3,
      bar: WORK_TEMPLATES.research_synthesis.bar,
      artifactTitle: gauntletArtifact.artifactTitle,
      artifact: gauntletArtifact.artifact,
      criticVerdict: "ours",
      gap: "",
      criticNote: gauntletArtifact.criticNote,
      costUsd: "0.0900",
      createdAt: minsAgo(530),
    },
  ]);

  await db.insert(memories).values(
    SEED_MEMORIES.map((m, i) => ({
      id: rid("mem"),
      agentId: m.agent,
      scope: m.scope,
      kind: m.kind,
      content: m.content,
      trust: m.trust,
      confidence: m.confidence,
      sourceWorkUnitId: i % 3 === 0 ? "wu_synthesis" : "wu_market_q3",
      provenance: `seeded knowledge · reviewed by independent verifier · signature ${shortHash(m.content)}`,
      accessCount: 4 + ((i * 7) % 31),
      createdAt: minsAgo(600 + i * 37),
      promotedAt: m.trust === "curated" ? minsAgo(500 + i * 11) : null,
    })),
  );

  await db.insert(approvals).values([
    {
      id: "apr_staging",
      workUnitId: "wu_delivery_slice",
      taskId: (
        await db
          .select({ id: tasks.id })
          .from(tasks)
          .where(and(eq(tasks.workUnitId, "wu_delivery_slice"), eq(tasks.position, 8)))
          .limit(1)
      )[0]?.id ?? "missing",
      agentId: "agt_sable",
      action: "external.commit",
      resource: "project:delivery",
      risk: "high",
      reason:
        "Merge and tagged release write outside the sandbox. The capability token is valid and scoped; human authorization is still required for the external side effect.",
      costUsd: "0.0000",
      status: "pending",
      requestedAt: minsAgo(9),
    },
  ]);

  const claims: EnvelopeClaims = {
    agentId: "agt_mira",
    workUnitId: "wu_market_q3",
    sessionId: "ses_seed_mira",
    policyVersion: "v3.4",
    issuedAt: Date.now(),
    exp: Date.now() + 1000 * 60 * 30,
    parentSignature: null,
    parentDepth: 2,
    actions: ["http.get", "browser.read", "memory.read"],
    resources: ["project:market-intelligence"],
    domains: ["vendor.example", "docs.cloudflare.com"],
    maxCost: 0.75,
    delegationDepth: 2,
    expiresAt: new Date(Date.now() + 1000 * 60 * 30).toISOString(),
  };
  const signed = signEnvelope(claims);
  const revokedClaims: EnvelopeClaims = {
    ...claims,
    agentId: "agt_nnamdi",
    workUnitId: "wu_audit",
    sessionId: "ses_seed_nnamdi",
    policyVersion: "v3.2",
    actions: ["browser.read"],
    domains: ["portal.example"],
    maxCost: 1.2,
    expiresAt: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
    exp: Date.now() - 1000 * 60 * 5,
  };
  const signedRevoked = signEnvelope(revokedClaims);

  await db.insert(authorityEnvelopes).values([
    {
      id: rid("env"),
      agentId: "agt_mira",
      workUnitId: "wu_market_q3",
      token: signed.token,
      signature: signed.signature,
      payload: { actions: claims.actions, resources: claims.resources, domains: claims.domains, maxCost: claims.maxCost, delegationDepth: claims.delegationDepth, expiresAt: claims.expiresAt },
      policyVersion: claims.policyVersion,
      createdAt: minsAgo(4),
      expiresAt: new Date(claims.expiresAt),
    },
    {
      id: rid("env"),
      agentId: "agt_nnamdi",
      workUnitId: "wu_audit",
      token: signedRevoked.token,
      signature: signedRevoked.signature,
      payload: { actions: revokedClaims.actions, resources: revokedClaims.resources, domains: revokedClaims.domains, maxCost: revokedClaims.maxCost, delegationDepth: revokedClaims.delegationDepth, expiresAt: revokedClaims.expiresAt },
      policyVersion: revokedClaims.policyVersion,
      revoked: true,
      createdAt: minsAgo(38),
      expiresAt: new Date(revokedClaims.expiresAt),
    },
  ]);

  await db.insert(events).values([
    { id: rid("evt"), kind: "task.leased", message: "Extract public pricing leased to wrk_9f2a (browser lane, tier 2)", workUnitId: "wu_market_q3", agentId: "agt_mira", meta: { tier: 2 }, createdAt: minsAgo(6) },
    { id: rid("evt"), kind: "approval.requested", message: "Human authorization requested before: Merge + commit tagged release", workUnitId: "wu_delivery_slice", agentId: "agt_sable", meta: { risk: "high" }, createdAt: minsAgo(9) },
    { id: rid("evt"), kind: "session.hibernated", message: "9 idle sessions hibernated; resident memory released", meta: { sessions: 9 }, createdAt: minsAgo(12) },
    { id: rid("evt"), kind: "gauntlet.round", message: "Gauntlet round 3: critic picks ours blind.", workUnitId: "wu_synthesis", agentId: "agt_mira", meta: { verdict: "ours" }, createdAt: minsAgo(530) },
    { id: rid("evt"), kind: "receipt.reconciled", message: "Duplicate completion reconciled, not re-executed: Merge + commit tagged release", workUnitId: "wu_delivery_slice", agentId: "agt_sable", meta: {}, createdAt: minsAgo(88) },
    { id: rid("evt"), kind: "authority.revoked", message: "Envelope for nnamdi.browser revoked after scope audit", workUnitId: "wu_audit", agentId: "agt_priya", meta: { policyVersion: "v3.2" }, createdAt: minsAgo(38) },
    { id: rid("evt"), kind: "memory.compiled", message: "Memory compiler promoted 3 high-confidence candidates", workUnitId: "wu_synthesis", agentId: "agt_vala", meta: {}, createdAt: minsAgo(520) },
    { id: rid("evt"), kind: "budget.guard", message: "Tenant ceiling 40.00 USD not reached; 34.14 USD headroom", meta: {}, createdAt: minsAgo(20) },
  ]);

  const metricRows = Array.from({ length: 18 }).map((_, i) => {
    const phase = Math.sin(i / 2.4) * 3 + 5;
    return {
      id: rid("mtr"),
      at: minsAgo((18 - i) * 4),
      activeTurns: Math.max(0, Math.round(phase)),
      idleSessions: 8 + (i % 4),
      queueDepth: Math.max(1, Math.round(11 - phase)),
      running: Math.max(0, Math.round(phase)),
      committed: 1 + (i % 3),
      spendUsd: (0.8 + i * 0.11).toFixed(4),
      residentMb: Math.max(0, Math.round(phase) * 64),
    };
  });
  await db.insert(metrics).values(metricRows);

  await db.insert(deliveryTasks).values(
    DELIVERY.map((d, i) => ({
      id: `del_${d.code.toLowerCase()}`,
      stage: d.stage,
      code: d.code,
      title: d.title,
      status: d.status,
      acceptance: d.acceptance,
      evidence: d.evidence,
      blocker: d.blocker ?? "",
      position: i,
    })),
  );
}
