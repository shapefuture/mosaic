export function usd(value: number | string, digits = 2): string {
  const n = typeof value === "string" ? Number(value) : value;
  return `$${n.toFixed(digits)}`;
}

export function pct(value: number): string {
  return `${Math.round(value)}%`;
}

export function timeAgo(date: Date | string | null | undefined): string {
  if (!date) return "—";
  const d = typeof date === "string" ? new Date(date) : date;
  const diff = Date.now() - d.getTime();
  if (diff < 0) return `in ${Math.round(-diff / 1000)}s`;
  const s = Math.round(diff / 1000);
  if (s < 60) return `${s}s ago`;
  const m = Math.round(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.round(h / 24)}d ago`;
}

export function clock(date: Date | string | null | undefined): string {
  if (!date) return "—";
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toISOString().slice(11, 19);
}

export function num(value: number | string | null | undefined): number {
  if (value === null || value === undefined) return 0;
  return typeof value === "string" ? Number(value) : value;
}

export const STATUS_TONE: Record<string, string> = {
  running: "text-sky-300 border-sky-400/30 bg-sky-400/10",
  done: "text-emerald-300 border-emerald-400/30 bg-emerald-400/10",
  succeeded: "text-emerald-300 border-emerald-400/30 bg-emerald-400/10",
  verifying: "text-violet-300 border-violet-400/30 bg-violet-400/10",
  waiting_approval: "text-amber-300 border-amber-400/30 bg-amber-400/10",
  planned: "text-zinc-400 border-zinc-600/40 bg-zinc-500/10",
  ready: "text-cyan-300 border-cyan-400/30 bg-cyan-400/10",
  blocked: "text-zinc-500 border-zinc-700/60 bg-zinc-800/40",
  failed: "text-rose-300 border-rose-400/30 bg-rose-400/10",
  active: "text-emerald-300 border-emerald-400/30 bg-emerald-400/10",
  hibernating: "text-zinc-400 border-zinc-600/40 bg-zinc-500/10",
  paused: "text-amber-300 border-amber-400/30 bg-amber-400/10",
  retired: "text-zinc-500 border-zinc-700/60 bg-zinc-800/40",
  pending: "text-amber-300 border-amber-400/30 bg-amber-400/10",
  approved: "text-emerald-300 border-emerald-400/30 bg-emerald-400/10",
  denied: "text-rose-300 border-rose-400/30 bg-rose-400/10",
  committed: "text-emerald-300 border-emerald-400/30 bg-emerald-400/10",
  reconciled: "text-cyan-300 border-cyan-400/30 bg-cyan-400/10",
  proposed: "text-amber-300 border-amber-400/30 bg-amber-400/10",
  curated: "text-emerald-300 border-emerald-400/30 bg-emerald-400/10",
  rejected: "text-rose-300 border-rose-400/30 bg-rose-400/10",
  ours: "text-emerald-300 border-emerald-400/30 bg-emerald-400/10",
  bar: "text-amber-300 border-amber-400/30 bg-amber-400/10",
  in_progress: "text-sky-300 border-sky-400/30 bg-sky-400/10",
  quarantined: "text-amber-300 border-amber-400/30 bg-amber-400/10",
};

export const LABEL: Record<string, string> = {
  waiting_approval: "awaiting human",
  in_progress: "in progress",
  hibernating: "hibernated",
  done: "done",
};

export function label(status: string): string {
  return LABEL[status] ?? status.replace(/_/g, " ");
}

export const QUEUE_TONE: Record<string, string> = {
  interactive: "#38bdf8",
  io: "#22d3ee",
  compute: "#a78bfa",
  browser: "#fbbf24",
};

export const QUEUE_LABEL: Record<string, string> = {
  interactive: "Interactive",
  io: "I/O parallel",
  compute: "Compute",
  browser: "Browser / desktop",
};
