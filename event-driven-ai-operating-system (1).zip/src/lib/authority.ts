import crypto from "node:crypto";

export type EnvelopePayload = {
  actions: string[];
  resources: string[];
  domains: string[];
  maxCost: number;
  delegationDepth: number;
  expiresAt: string;
};

export type EnvelopeClaims = {
  agentId: string;
  workUnitId: string | null;
  sessionId: string;
  policyVersion: string;
  issuedAt: number;
  exp: number;
  parentSignature: string | null;
  parentDepth: number | null;
} & EnvelopePayload;

const SECRET = process.env.AOS_SIGNING_SECRET ?? "aos-v3-local-capability-secret";

/** Deterministic compact token: base64url(claims) "." base64url(hmac). */
export function signEnvelope(claims: EnvelopeClaims): { token: string; signature: string } {
  const body = Buffer.from(JSON.stringify(claims)).toString("base64url");
  const signature = crypto.createHmac("sha256", SECRET).update(body).digest("base64url").slice(0, 32);
  return { token: `${body}.${signature}`, signature };
}

export function parseEnvelope(token: string): EnvelopeClaims | null {
  try {
    const [body] = token.split(".");
    return JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as EnvelopeClaims;
  } catch {
    return null;
  }
}

export function verifySignature(token: string): boolean {
  const parts = token.split(".");
  if (parts.length !== 2) return false;
  const [body, signature] = parts;
  const expected = crypto.createHmac("sha256", SECRET).update(body).digest("base64url").slice(0, 32);
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
}

export type VerificationRequest = {
  action: string;
  resource: string;
  domain?: string;
  cost: number;
  /** For delegated child tasks: the parent envelope's signature + depth. */
  parentSignature?: string;
  parentDepth?: number;
};

export type VerificationResult = {
  decision: "allow" | "deny";
  reason: string;
  checks: { invariant: string; pass: boolean; detail: string }[];
  tokenRef: string;
};

/**
 * Deterministic authorization. The model never authorizes itself.
 * Invariants: scope, domain allowlist, budget, delegation ceiling, expiry, signature.
 */
export function authorize(
  claims: EnvelopeClaims | null,
  signatureValid: boolean,
  request: VerificationRequest,
  revoked = false,
): VerificationResult {
  const checks: VerificationResult["checks"] = [];
  const tokenRef = claims ? `${claims.agentId}·${claims.policyVersion}` : "unknown";

  checks.push({
    invariant: "signature",
    pass: signatureValid,
    detail: signatureValid ? "HMAC verified against policy signer" : "signature mismatch or tampered payload",
  });

  if (!claims) {
    return { decision: "deny", reason: "envelope unreadable", checks, tokenRef };
  }

  const expired = new Date(claims.expiresAt).getTime() < Date.now();
  checks.push({
    invariant: "expiry",
    pass: !expired,
    detail: expired ? `expired at ${claims.expiresAt}` : `valid until ${claims.expiresAt}`,
  });

  checks.push({
    invariant: "revocation",
    pass: !revoked,
    detail: revoked ? "envelope revoked in authority ledger" : "not revoked",
  });

  const actionOk = claims.actions.includes(request.action);
  checks.push({
    invariant: "action-scope",
    pass: actionOk,
    detail: actionOk ? `action "${request.action}" granted` : `"${request.action}" not in [${claims.actions.join(", ")}]`,
  });

  const resourceOk =
    claims.resources.includes("*") ||
    claims.resources.some((r) => request.resource === r || request.resource.startsWith(`${r}:`));
  checks.push({
    invariant: "resource-scope",
    pass: resourceOk,
    detail: resourceOk ? `resource "${request.resource}" in scope` : `resource outside [${claims.resources.join(", ")}]`,
  });

  const domainRequired = request.action.startsWith("http.") || request.action.startsWith("browser.");
  const domainOk =
    !domainRequired ||
    claims.domains.includes("*") ||
    claims.domains.some((d) => request.domain === d || (request.domain ?? "").endsWith(`.${d}`));
  checks.push({
    invariant: "egress-allowlist",
    pass: domainOk,
    detail: domainRequired
      ? domainOk
        ? `domain "${request.domain}" allowlisted`
        : `domain "${request.domain ?? "none"}" not allowlisted`
      : "no network egress requested",
  });

  const costOk = request.cost <= claims.maxCost;
  checks.push({
    invariant: "cost-ceiling",
    pass: costOk,
    detail: costOk
      ? `$${request.cost.toFixed(2)} within $${claims.maxCost.toFixed(2)}`
      : `$${request.cost.toFixed(2)} exceeds $${claims.maxCost.toFixed(2)}`,
  });

  const depthOk =
    request.parentDepth === undefined ||
    claims.delegationDepth >= 0
      ? request.parentDepth === undefined || claims.delegationDepth <= request.parentDepth
      : false;
  checks.push({
    invariant: "delegation-ceiling",
    pass: depthOk,
    detail:
      request.parentDepth === undefined
        ? `root grant, depth ${claims.delegationDepth}`
        : depthOk
          ? `depth ${claims.delegationDepth} ≤ parent ${request.parentDepth}`
          : `child depth ${claims.delegationDepth} exceeds parent ${request.parentDepth}`,
  });

  const failed = checks.find((c) => !c.pass);
  return {
    decision: failed ? "deny" : "allow",
    reason: failed ? `denied by ${failed.invariant}: ${failed.detail}` : "all invariants pass; execute at the tool boundary",
    checks,
    tokenRef,
  };
}

export function shortHash(input: string): string {
  return crypto.createHash("sha256").update(input).digest("hex").slice(0, 16);
}
