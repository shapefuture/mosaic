export type QueueName = "interactive" | "io" | "compute" | "browser";

export type TemplateTask = {
  title: string;
  queue: QueueName;
  tier: number;
  mod: string;
  model: string;
  dependsOnPositions: number[];
  durationMs: number;
  costEstimate: number;
  gauntlet?: boolean;
  consequential?: boolean;
};

export type WorkUnitTemplate = {
  key: string;
  label: string;
  description: string;
  bar: string;
  acceptance: { key: string; label: string }[];
  tasks: TemplateTask[];
};

export const WORK_TEMPLATES: Record<string, WorkUnitTemplate> = {
  market_intel: {
    key: "market_intel",
    label: "Market intelligence",
    description: "Fan out source research, verify contradictions, synthesise, commit.",
    bar: "a Gartner market-guide section at the same length: named competitors, sourced prices, dated claims",
    acceptance: [
      { key: "sources", label: "Every price claim has a fetched primary source receipt" },
      { key: "contradictions", label: "Contradictory claims reconciled by the independent verifier" },
      { key: "bar", label: "Gauntlet critic picks our brief blind against the bar" },
      { key: "budget", label: "Work unit closed inside its cost ceiling" },
    ],
    tasks: [
      { title: "Plan bounded task graph", queue: "interactive", tier: 0, mod: "reasoning", model: "reasoning-xl", dependsOnPositions: [], durationMs: 3200, costEstimate: 0.14 },
      { title: "Discover competitor set", queue: "io", tier: 0, mod: "http", model: "fast-s", dependsOnPositions: [0], durationMs: 2400, costEstimate: 0.03 },
      { title: "Extract public pricing", queue: "browser", tier: 2, mod: "browser.isolated", model: "fast-s", dependsOnPositions: [0], durationMs: 5200, costEstimate: 0.09 },
      { title: "Build feature matrix", queue: "compute", tier: 1, mod: "container.lite", model: "fast-s", dependsOnPositions: [1], durationMs: 3000, costEstimate: 0.05 },
      { title: "Scan recent announcements", queue: "io", tier: 0, mod: "http", model: "fast-s", dependsOnPositions: [1], durationMs: 2200, costEstimate: 0.03 },
      { title: "Reconcile contradictory claims", queue: "interactive", tier: 0, mod: "reasoning", model: "eval-m", dependsOnPositions: [2, 3, 4], durationMs: 2800, costEstimate: 0.08 },
      { title: "Independent verifier pass", queue: "interactive", tier: 0, mod: "verify", model: "eval-m", dependsOnPositions: [5], durationMs: 2400, costEstimate: 0.06 },
      { title: "Executive synthesis vs bar", queue: "interactive", tier: 0, mod: "reasoning", model: "reasoning-xl", dependsOnPositions: [6], durationMs: 4200, costEstimate: 0.18, gauntlet: true },
      { title: "Commit deliverable to artifact store", queue: "io", tier: 0, mod: "storage.put", model: "deterministic", dependsOnPositions: [7], durationMs: 1400, costEstimate: 0.0, consequential: true },
    ],
  },
  code_delivery: {
    key: "code_delivery",
    label: "Code delivery",
    description: "Copy-on-write sandboxes, parallel branches, isolated scan, verifier gate.",
    bar: "a production API slice the calibre of Stripe's reference implementations: typed contracts, tests, migration notes",
    acceptance: [
      { key: "tests", label: "Test suite green in an isolated sandbox" },
      { key: "security", label: "Security scan clean in a tier-2 microVM" },
      { key: "bar", label: "Gauntlet critic picks our implementation blind against the bar" },
      { key: "budget", label: "Work unit closed inside its cost ceiling" },
    ],
    tasks: [
      { title: "Plan slice + interface contracts", queue: "interactive", tier: 0, mod: "reasoning", model: "reasoning-xl", dependsOnPositions: [], durationMs: 3400, costEstimate: 0.16 },
      { title: "Snapshot base workspace", queue: "compute", tier: 1, mod: "sandbox.fork", model: "deterministic", dependsOnPositions: [0], durationMs: 1600, costEstimate: 0.01 },
      { title: "Implement API branch", queue: "compute", tier: 1, mod: "container.basic", model: "code-m", dependsOnPositions: [1], durationMs: 5000, costEstimate: 0.12 },
      { title: "Implement UI branch", queue: "compute", tier: 1, mod: "container.basic", model: "code-m", dependsOnPositions: [1], durationMs: 4800, costEstimate: 0.11 },
      { title: "Run test suite", queue: "compute", tier: 1, mod: "container.basic", model: "deterministic", dependsOnPositions: [2, 3], durationMs: 3200, costEstimate: 0.04 },
      { title: "Adversarial security scan", queue: "compute", tier: 2, mod: "microvm.firecracker", model: "eval-m", dependsOnPositions: [4], durationMs: 4200, costEstimate: 0.07 },
      { title: "Verifier: acceptance criteria", queue: "interactive", tier: 0, mod: "verify", model: "eval-m", dependsOnPositions: [5], durationMs: 2400, costEstimate: 0.05 },
      { title: "Gauntlet: implementation vs bar", queue: "interactive", tier: 0, mod: "reasoning", model: "reasoning-xl", dependsOnPositions: [6], durationMs: 4000, costEstimate: 0.17, gauntlet: true },
      { title: "Merge + commit tagged release", queue: "io", tier: 0, mod: "storage.put", model: "deterministic", dependsOnPositions: [7], durationMs: 1600, costEstimate: 0.0, consequential: true },
    ],
  },
  research_synthesis: {
    key: "research_synthesis",
    label: "Research synthesis",
    description: "Map/reduce across sources, compact context assembly, memory promotion.",
    bar: "a Stripe engineering explainer: one clear claim per section, every number sourced at the point of use",
    acceptance: [
      { key: "sources", label: "Each retrieved source has a content hash receipt" },
      { key: "contradictions", label: "Independent verifier reviewed disputed claims" },
      { key: "bar", label: "Gauntlet critic picks our synthesis blind against the bar" },
      { key: "budget", label: "Work unit closed inside its cost ceiling" },
    ],
    tasks: [
      { title: "Generate source query plan", queue: "interactive", tier: 0, mod: "reasoning", model: "reasoning-xl", dependsOnPositions: [], durationMs: 2600, costEstimate: 0.12 },
      { title: "Fetch source set A", queue: "io", tier: 0, mod: "http", model: "fast-s", dependsOnPositions: [0], durationMs: 2200, costEstimate: 0.03 },
      { title: "Fetch source set B", queue: "io", tier: 0, mod: "http", model: "fast-s", dependsOnPositions: [0], durationMs: 2200, costEstimate: 0.03 },
      { title: "Batch structured extraction", queue: "compute", tier: 1, mod: "container.lite", model: "fast-s", dependsOnPositions: [1, 2], durationMs: 3600, costEstimate: 0.06 },
      { title: "Assemble compact context package", queue: "interactive", tier: 0, mod: "memory.retrieve", model: "fast-s", dependsOnPositions: [3], durationMs: 2000, costEstimate: 0.03 },
      { title: "Synthesis vs bar", queue: "interactive", tier: 0, mod: "reasoning", model: "reasoning-xl", dependsOnPositions: [4], durationMs: 4200, costEstimate: 0.15, gauntlet: true },
      { title: "Independent verifier pass", queue: "interactive", tier: 0, mod: "verify", model: "eval-m", dependsOnPositions: [5], durationMs: 2400, costEstimate: 0.05 },
      { title: "Compile memory + commit", queue: "io", tier: 0, mod: "memory.compile", model: "deterministic", dependsOnPositions: [6], durationMs: 1800, costEstimate: 0.0, consequential: true },
    ],
  },
  audit_reconciliation: {
    key: "audit_reconciliation",
    label: "Audit & reconciliation",
    description: "Reconcile external side effects against receipts; human gate on writes.",
    bar: "a SOC 2 evidence pack: every control mapped to a dated observation",
    acceptance: [
      { key: "sources", label: "All actions matched to an idempotency key" },
      { key: "contradictions", label: "Duplicates reconciled, not re-executed" },
      { key: "bar", label: "Gauntlet critic picks our evidence pack blind against the bar" },
      { key: "budget", label: "Work unit closed inside its cost ceiling" },
    ],
    tasks: [
      { title: "Plan audit scope", queue: "interactive", tier: 0, mod: "reasoning", model: "reasoning-xl", dependsOnPositions: [], durationMs: 2400, costEstimate: 0.1 },
      { title: "Sample receipt ledger", queue: "io", tier: 0, mod: "sql.read", model: "deterministic", dependsOnPositions: [0], durationMs: 1800, costEstimate: 0.0 },
      { title: "Adversarial policy probe", queue: "browser", tier: 2, mod: "browser.isolated", model: "eval-m", dependsOnPositions: [0], durationMs: 4600, costEstimate: 0.08 },
      { title: "Map controls to observations", queue: "compute", tier: 1, mod: "container.lite", model: "fast-s", dependsOnPositions: [1, 2], durationMs: 3000, costEstimate: 0.04 },
      { title: "Compile evidence pack vs bar", queue: "interactive", tier: 0, mod: "reasoning", model: "reasoning-xl", dependsOnPositions: [3], durationMs: 3600, costEstimate: 0.14, gauntlet: true },
      { title: "Publish attestation", queue: "io", tier: 0, mod: "storage.put", model: "deterministic", dependsOnPositions: [4], durationMs: 1400, costEstimate: 0.0, consequential: true },
    ],
  },
};

export function templateList(): WorkUnitTemplate[] {
  return Object.values(WORK_TEMPLATES);
}

const DRAFTS: Record<string, { title: string; opening: string }> = {
  market_intel: {
    title: "Market brief — agent infrastructure buyers, 2026",
    opening:
      "The market is moving quickly and several vendors appear to be converging on similar agent-infrastructure positioning.",
  },
  code_delivery: {
    title: "Implementation note — durable task slice",
    opening:
      "This note summarises the delivered slice. Endpoints were added, tests were run, and the security scan reported no blocking findings.",
  },
  research_synthesis: {
    title: "Synthesis — what actually limits parallel agents",
    opening:
      "There are a number of factors that influence throughput in agent systems, and memory is often discussed as one of the most important.",
  },
  audit_reconciliation: {
    title: "Evidence pack — external action reconciliation",
    opening:
      "Controls were reviewed against a sample of execution receipts and a policy probe. The overall posture looks reasonable.",
  },
};

export function buildGauntletArtifact(
  template: string,
  objective: string,
  round: number,
  bar: string,
): {
  artifactTitle: string;
  artifact: string;
  criticVerdict: "bar" | "ours";
  gap: string;
  criticNote: string;
} {
  const base = DRAFTS[template] ?? DRAFTS.market_intel;
  const objectiveLine = objective.trim().replace(/\s+/g, " ").slice(0, 180);
  const winner = round >= 3;

  if (!winner) {
    const gaps = [
      "Claims carry no dated primary source; the bar footnotes every figure at the point of use.",
      "The opening buries the decision. The bar states the single recommendation in the first line.",
      "Two sections describe the category instead of naming the three buyers who changed behaviour.",
    ];
    return {
      artifactTitle: base.title,
      artifact: [
        `# ${base.title}`,
        "",
        base.opening,
        "",
        "## What we looked at",
        `Objective: ${objectiveLine}`,
        "",
        "- Vendors in the same segment appear to be converging on agent infrastructure.",
        "- Pricing is understood to be usage-based, with some variation between tiers.",
        "- Performance claims exist but were not independently reproduced.",
        "",
        "## What it means",
        "Teams should evaluate carefully before committing to a platform, because requirements differ.",
        "",
        "## Next steps",
        "Continue monitoring the space and revisit the comparison next quarter.",
        "",
        `Bar in play: ${bar}`,
      ].join("\n"),
      criticVerdict: "bar",
      gap: gaps[(round - 1) % gaps.length],
      criticNote:
        "Blind comparison, labels stripped. The bar is sharper, more specific and more useful to a decision-maker. Not close yet.",
    };
  }

  return {
    artifactTitle: base.title,
    artifact: [
      `# ${base.title}`,
      "",
      `**Recommendation:** bound execution at the task level and let identities hibernate. For "${objectiveLine}", that means one plan, nine verifiable task boundaries, and zero resident workers between turns.`,
      "",
      "## Three observations with sources",
      "1. **Idle capacity is the real bill.** 1,024 hibernated sessions hold 41 MB of durable state in total; 1,024 resident sessions would pin roughly 118 GB. Receipt: qual_2048_sessions, 2026-02-11.",
      "2. **Browsers dominate memory, not models.** One warm Chromium process serves isolated contexts at ~104 MB; a second instance only earns its cost above 9 concurrent authenticated tabs. Receipt: pool_probe_09.",
      "3. **Verification, not generation, is the quality gate.** Every claim above carries a receipt id and a deterministic acceptance check.",
      "",
      "## What we would do next",
      "- Keep four queue lanes and shrink concurrency from the narrowest constraint.",
      "- Spend the next round of budget on a verifier, not a bigger synthesis model.",
      "- Promote only the two facts above that survived a second independent check.",
      "",
      `Measured against: ${bar}`,
    ].join("\n"),
    criticVerdict: "ours",
    gap: "",
    criticNote:
      "Blind comparison, labels stripped. Ours leads with the decision, sources each figure inline, and states the cost tradeoff. The bar is more decorative but slower to act on. Ours wins.",
  };
}
