"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Activity,
  Brain,
  Gauge,
  GitBranch,
  LayoutDashboard,
  ScrollText,
  ShieldCheck,
  Users,
} from "lucide-react";
import { LiveBar } from "@/components/live-bar";

const NAV = [
  { href: "/", label: "Command deck", icon: LayoutDashboard },
  { href: "/fleet", label: "Agent registry", icon: Users },
  { href: "/work", label: "Work engine", icon: GitBranch },
  { href: "/scheduler", label: "Scheduler", icon: Gauge },
  { href: "/memory", label: "Memory compiler", icon: Brain },
  { href: "/security", label: "Authority", icon: ShieldCheck },
  { href: "/doctrine", label: "Doctrine", icon: ScrollText },
];

const TITLES: Record<string, string> = {
  "/": "Command deck",
  "/fleet": "Agent registry",
  "/work": "Universal work engine",
  "/scheduler": "Adaptive scheduler",
  "/memory": "Memory compiler",
  "/security": "Capability authority",
  "/doctrine": "Architecture doctrine",
};

export function Shell({ children, pendingApprovals }: { children: React.ReactNode; pendingApprovals: number }) {
  const pathname = usePathname();
  const title = TITLES[pathname] ?? (pathname.startsWith("/fleet/") ? "Agent identity" : pathname.startsWith("/work/") ? "Work unit" : "AOS v3");

  return (
    <div className="flex min-h-screen">
      <aside className="sticky top-0 hidden h-screen w-[232px] shrink-0 flex-col border-r border-white/[0.07] bg-[#06080c]/80 px-3 py-4 backdrop-blur lg:flex">
        <Link href="/" className="group flex items-center gap-2.5 px-2">
          <span className="grid h-8 w-8 place-items-center rounded-lg border border-cyan-300/30 bg-cyan-300/10 text-[13px] font-semibold text-cyan-200 glow-cyan">
            ◉
          </span>
          <span className="leading-tight">
            <span className="block text-[13px] font-semibold tracking-tight text-zinc-100">AOS v3</span>
            <span className="mono block text-[10px] uppercase tracking-[0.16em] text-zinc-500">agent operating system</span>
          </span>
        </Link>

        <nav className="mt-5 flex flex-col gap-0.5">
          {NAV.map((item) => {
            const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`group flex items-center gap-2.5 rounded-lg px-2.5 py-[7px] text-[12.5px] transition ${
                  active ? "bg-white/[0.055] text-zinc-100" : "text-zinc-500 hover:bg-white/[0.025] hover:text-zinc-300"
                }`}
              >
                <Icon size={14} strokeWidth={1.7} className={active ? "text-cyan-300" : "text-zinc-600 group-hover:text-zinc-400"} />
                <span className="flex-1">{item.label}</span>
                {item.href === "/security" && pendingApprovals > 0 && (
                  <span className="mono rounded-full border border-amber-400/30 bg-amber-400/10 px-1.5 py-0.5 text-[9.5px] text-amber-300">
                    {pendingApprovals}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>

        <div className="mt-auto space-y-2 px-1">
          <div className="panel-flat px-2.5 py-2">
            <p className="mono flex items-center gap-1.5 text-[9.5px] uppercase tracking-[0.14em] text-zinc-500">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 pulse-dot" />
              deterministic core
            </p>
            <p className="mt-1.5 text-[11px] leading-relaxed text-zinc-500">
              Execution is simulated locally. No model keys are configured, so scheduling, receipts and policy are real while inference is synthetic.
            </p>
          </div>
          <p className="mono px-1 text-[9.5px] uppercase tracking-[0.14em] text-zinc-600">control plane · v3.4.0 · pg</p>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 border-b border-white/[0.07] bg-[#05070a]/85 backdrop-blur">
          <div className="flex items-center gap-3 px-4 py-2.5 lg:px-6">
            <div className="min-w-0">
              <p className="mono text-[9.5px] uppercase tracking-[0.16em] text-zinc-500">aos / {title}</p>
              <h1 className="truncate text-[14px] font-medium tracking-tight text-zinc-100">{title}</h1>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <LiveBar />
            </div>
          </div>
          <nav className="flex gap-1 overflow-x-auto border-t border-white/[0.05] px-3 py-1.5 lg:hidden">
            {NAV.map((item) => {
              const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`whitespace-nowrap rounded-md px-2 py-1 text-[11px] ${active ? "bg-white/[0.07] text-zinc-100" : "text-zinc-500"}`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </header>
        <main className="min-w-0 flex-1 px-4 py-5 lg:px-6 lg:py-6">{children}</main>
        <footer className="border-t border-white/[0.06] px-4 py-3 lg:px-6">
          <div className="mono flex flex-wrap items-center gap-x-4 gap-y-1 text-[10px] uppercase tracking-[0.12em] text-zinc-600">
            <span>identities ≫ processes</span>
            <span className="text-zinc-700">·</span>
            <span>hibernation is the default</span>
            <span className="text-zinc-700">·</span>
            <span className="flex items-center gap-1">
              <Activity size={10} /> every side effect carries a receipt
            </span>
          </div>
        </footer>
      </div>
    </div>
  );
}
