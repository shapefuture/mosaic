"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Pause, Play, RefreshCw } from "lucide-react";
import { tickAction } from "@/app/actions";

type LiveState = {
  running: number;
  ready: number;
  spend: number;
  ceiling: number;
  activeAgents: number;
  hibernatedAgents: number;
  gauntletWins: number;
};

export function LiveBar() {
  const router = useRouter();
  const [state, setState] = useState<LiveState | null>(null);
  const [autopilot, setAutopilot] = useState(true);
  const [busy, setBusy] = useState(false);
  const mounted = useRef(true);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/state", { cache: "no-store" });
      if (res.ok) {
        const data = (await res.json()) as LiveState;
        if (mounted.current) setState(data);
      }
    } catch {
      /* offline poll is non-fatal */
    }
  }, []);

  useEffect(() => {
    mounted.current = true;
    void load();
    const t = setInterval(() => void load(), 4000);
    return () => {
      mounted.current = false;
      clearInterval(t);
    };
  }, [load]);

  useEffect(() => {
    if (!autopilot) return;
    const t = setInterval(async () => {
      try {
        await fetch("/api/tick", { method: "POST" });
        await load();
      } catch {
        /* ignore */
      }
    }, 3500);
    return () => clearInterval(t);
  }, [autopilot, load]);

  const runTick = async () => {
    setBusy(true);
    try {
      await tickAction();
      await load();
      router.refresh();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex items-center gap-2">
      <div className="mono hidden items-center gap-3 rounded-lg border border-white/[0.08] bg-white/[0.02] px-2.5 py-1.5 text-[10.5px] text-zinc-400 sm:flex">
        <span className="flex items-center gap-1.5">
          <span className={`h-1.5 w-1.5 rounded-full ${autopilot ? "bg-emerald-400 pulse-dot" : "bg-zinc-500"}`} />
          {state ? `${state.running} turns` : "—"}
        </span>
        <span className="text-zinc-700">|</span>
        <span className="tnum">{state ? `${state.ready} queued` : "—"}</span>
        <span className="text-zinc-700">|</span>
        <span className="tnum text-cyan-300">${state ? state.spend.toFixed(2) : "0.00"}</span>
        <span className="text-zinc-700">/ ${state ? state.ceiling.toFixed(0) : "40"}</span>
      </div>
      <button
        type="button"
        onClick={() => setAutopilot((v) => !v)}
        className="btn"
        title={autopilot ? "Pause the scheduler" : "Let the scheduler tick automatically"}
      >
        {autopilot ? <Pause size={12} /> : <Play size={12} />}
        <span className="hidden md:inline">{autopilot ? "Autopilot on" : "Autopilot off"}</span>
      </button>
      <button type="button" onClick={runTick} disabled={busy} className="btn btn-primary" title="Run one scheduler tick">
        <RefreshCw size={12} className={busy ? "animate-spin" : ""} />
        <span className="hidden sm:inline">Tick</span>
      </button>
    </div>
  );
}
