"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { QUEUE_LABEL, QUEUE_TONE, timeAgo } from "@/lib/format";

type State = {
  at: string;
  lanes: { lane: string; limit: number; running: number; ready: number }[];
  runningTasks: { id: string; title: string; queue: string; tier: number }[];
  events: { id: string; kind: string; message: string; at: string; workUnitId: string | null }[];
  running: number;
  ready: number;
  activeAgents: number;
  hibernatedAgents: number;
  spend: number;
  gauntletWins: number;
  gauntletRounds: number;
};

const KIND_TONE: Record<string, string> = {
  "task.leased": "text-cyan-300",
  "task.committed": "text-emerald-300",
  "task.ready": "text-sky-300",
  "task.retry": "text-amber-300",
  "task.failed": "text-rose-300",
  "receipt.reconciled": "text-cyan-300",
  "approval.requested": "text-amber-300",
  "approval.approved": "text-emerald-300",
  "approval.denied": "text-rose-300",
  "session.hibernated": "text-zinc-400",
  "session.resumed": "text-emerald-300",
  "work_unit.created": "text-violet-300",
  "work_unit.done": "text-emerald-300",
  "gauntlet.round": "text-violet-300",
  "memory.compiled": "text-cyan-300",
  "authority.denied": "text-rose-300",
  "worker.lost": "text-rose-300",
};

export function LiveConsole() {
  const [state, setState] = useState<State | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const res = await fetch("/api/state", { cache: "no-store" });
        if (!res.ok) throw new Error("bad response");
        const data = (await res.json()) as State;
        if (alive) {
          setState(data);
          setError(false);
        }
      } catch {
        if (alive) setError(true);
      }
    };
    void load();
    const t = setInterval(() => void load(), 3000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  return (
    <section className="panel overflow-hidden">
      <header className="flex flex-wrap items-center gap-2 border-b border-white/[0.06] px-4 py-2.5">
        <span className={`h-1.5 w-1.5 rounded-full ${state ? "bg-emerald-400 pulse-dot" : "bg-zinc-500"}`} />
        <h2 className="text-[12.5px] font-medium tracking-tight text-zinc-200">Live execution fabric</h2>
        <span className="mono text-[10px] text-zinc-500">
          {state ? `${state.running} turns · ${state.ready} queued · ${state.activeAgents} awake / ${state.hibernatedAgents} asleep` : error ? "feed offline" : "connecting…"}
        </span>
        <span className="mono ml-auto text-[10px] uppercase tracking-[0.12em] text-zinc-600">poll 3s</span>
      </header>

      <div className="grid gap-4 p-4 xl:grid-cols-[1.15fr_1fr]">
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            {(state?.lanes ?? []).map((lane) => {
              const tone = QUEUE_TONE[lane.lane] ?? "#67e8f9";
              const pct = lane.limit > 0 ? Math.min(100, (lane.running / lane.limit) * 100) : 0;
              return (
                <div key={lane.lane} className="panel-flat px-2.5 py-2">
                  <div className="flex items-center justify-between">
                    <span className="mono text-[10px] uppercase tracking-[0.08em] text-zinc-400">{QUEUE_LABEL[lane.lane] ?? lane.lane}</span>
                    <span className="mono tnum text-[10px] text-zinc-500">
                      {lane.running}/{lane.limit}
                    </span>
                  </div>
                  <div className="mt-2 h-1 w-full overflow-hidden rounded-full bg-white/[0.08]">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${Math.max(pct, lane.running > 0 ? 6 : 0)}%`, background: tone }} />
                  </div>
                  <div className="mono mt-1.5 text-[9.5px] text-zinc-600">{lane.ready} waiting</div>
                </div>
              );
            })}
            {!state && <div className="col-span-2 h-[124px] animate-pulse rounded-lg bg-white/[0.03]" />}
          </div>

          <div>
            <p className="mono mb-1.5 text-[9.5px] uppercase tracking-[0.14em] text-zinc-600">leased right now</p>
            <div className="space-y-1">
              {(state?.runningTasks ?? []).slice(0, 5).map((t) => (
                <div key={t.id} className="flex items-center gap-2 rounded-md border border-white/[0.06] bg-white/[0.018] px-2 py-1.5">
                  <span className="h-1 w-1 shrink-0 rounded-full" style={{ background: QUEUE_TONE[t.queue] ?? "#67e8f9" }} />
                  <span className="truncate text-[11.5px] text-zinc-300">{t.title}</span>
                  <span className="mono ml-auto shrink-0 text-[9.5px] text-zinc-500">
                    {t.queue} · t{t.tier}
                  </span>
                </div>
              ))}
              {state && state.runningTasks.length === 0 && (
                <p className="rounded-md border border-dashed border-white/10 px-2 py-3 text-[11px] text-zinc-500">
                  No leases held. Identities remain durable; nothing is burning memory.
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="min-w-0">
          <p className="mono mb-1.5 text-[9.5px] uppercase tracking-[0.14em] text-zinc-600">event stream</p>
          <div className="max-h-[228px] space-y-1.5 overflow-y-auto pr-1">
            {(state?.events ?? []).map((e) => (
              <div key={e.id} className="flex gap-2 text-[11px] leading-snug">
                <span className="mono w-[42px] shrink-0 pt-[1px] text-[9.5px] text-zinc-600">{new Date(e.at).toISOString().slice(11, 19)}</span>
                <div className="min-w-0">
                  <span className={`mono text-[9.5px] uppercase tracking-[0.06em] ${KIND_TONE[e.kind] ?? "text-zinc-400"}`}>{e.kind.replace(/[._]/g, " ")}</span>
                  <p className="truncate text-zinc-400">
                    {e.workUnitId ? (
                      <Link href={`/work/${e.workUnitId}`} className="hover:text-zinc-200 hover:underline">
                        {e.message}
                      </Link>
                    ) : (
                      e.message
                    )}
                  </p>
                </div>
              </div>
            ))}
            {!state && <div className="h-[180px] animate-pulse rounded-lg bg-white/[0.03]" />}
          </div>
          {state && (
            <p className="mono mt-2 border-t border-white/[0.06] pt-2 text-[9.5px] text-zinc-600">
              last sync {timeAgo(state.at)} · {state.gauntletWins}/{state.gauntletRounds} gauntlet rounds won
            </p>
          )}
        </div>
      </div>
    </section>
  );
}
