"use client";

import { useActionState } from "react";
import { useRouter } from "next/navigation";
import { GitBranch, Loader2 } from "lucide-react";
import { createWorkUnitAction } from "@/app/actions";
import { WORK_TEMPLATES } from "@/lib/templates";

type State = { ok: boolean; error?: string; workUnitId?: string };

const agents = [
  { id: "agt_mira", label: "Mira Chen · research" },
  { id: "agt_sable", label: "Sable Ops · delivery" },
  { id: "agt_iris", label: "Iris Kwan · verifier" },
  { id: "agt_nnamdi", label: "Nnamdi Okafor · browser" },
  { id: "agt_orin", label: "Orin Vale · code" },
];

export function WorkCreate() {
  const router = useRouter();
  const [state, formAction, pending] = useActionState<State, FormData>(
    async (_prev, formData) => {
      const result = await createWorkUnitAction(formData);
      if (result.ok && result.workUnitId) {
        router.push(`/work/${result.workUnitId}`);
        return { ok: true, workUnitId: result.workUnitId };
      }
      return { ok: false, error: result.error ?? "Could not create the work unit." };
    },
    { ok: false },
  );

  return (
    <form action={formAction} className="space-y-2.5">
      <div className="grid gap-2 sm:grid-cols-2">
        <label className="block">
          <span className="mono text-[9.5px] uppercase tracking-[0.12em] text-zinc-500">title</span>
          <input name="title" required placeholder="Q4 pricing teardown" className="field mt-1" />
        </label>
        <label className="block">
          <span className="mono text-[9.5px] uppercase tracking-[0.12em] text-zinc-500">plan template</span>
          <select name="template" className="field mt-1" defaultValue="market_intel">
            {Object.values(WORK_TEMPLATES).map((t) => (
              <option key={t.key} value={t.key}>
                {t.label} · {t.tasks.length} tasks
              </option>
            ))}
          </select>
        </label>
      </div>
      <label className="block">
        <span className="mono text-[9.5px] uppercase tracking-[0.12em] text-zinc-500">objective — what does done look like?</span>
        <textarea
          name="objective"
          required
          rows={3}
          placeholder="Produce a decision-ready brief naming the three vendors that changed pricing, with a fetched source for every figure."
          className="field mt-1 resize-y"
        />
      </label>
      <div className="grid gap-2 sm:grid-cols-[1.4fr_0.8fr]">
        <label className="block">
          <span className="mono text-[9.5px] uppercase tracking-[0.12em] text-zinc-500">owning identity</span>
          <select name="ownerAgentId" className="field mt-1" defaultValue="agt_mira">
            {agents.map((a) => (
              <option key={a.id} value={a.id}>
                {a.label}
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="mono text-[9.5px] uppercase tracking-[0.12em] text-zinc-500">priority</span>
          <select name="priority" className="field mt-1" defaultValue="4">
            {[5, 4, 3, 2, 1].map((p) => (
              <option key={p} value={p}>
                {p} {p === 5 ? "· interactive first" : ""}
              </option>
            ))}
          </select>
        </label>
      </div>
      {state.error && <p className="rounded-md border border-rose-400/30 bg-rose-400/10 px-2 py-1.5 text-[11px] text-rose-200">{state.error}</p>}
      <div className="flex items-center gap-2">
        <button type="submit" disabled={pending} className="btn btn-primary">
          {pending ? <Loader2 size={12} className="animate-spin" /> : <GitBranch size={12} />}
          {pending ? "Compiling graph…" : "Compile & schedule"}
        </button>
        <span className="mono text-[9.5px] text-zinc-600">bounded by the fan-out cap; dependencies enforced</span>
      </div>
    </form>
  );
}
