"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Check, Loader2, ShieldAlert, ShieldCheck } from "lucide-react";

type EnvelopeProp = {
  id: string;
  agentId: string;
  policyVersion: string;
  revoked: boolean;
  expiresAt: string;
  payload: { actions: string[]; resources: string[]; domains: string[]; maxCost: number; delegationDepth: number; expiresAt: string };
};

type VerifyResult = {
  decision: "allow" | "deny";
  reason: string;
  checks: { invariant: string; pass: boolean; detail: string }[];
  tokenRef: string;
};

const ACTIONS = ["http.get", "http.post", "browser.read", "browser.context", "storage.write", "sandbox.exec", "verify.run", "memory.read"];

export function SecurityPlayground({ envelopes, agentHandles }: { envelopes: EnvelopeProp[]; agentHandles: { id: string; handle: string }[] }) {
  const router = useRouter();
  const [envelopeId, setEnvelopeId] = useState(envelopes[0]?.id ?? "");
  const [action, setAction] = useState("browser.read");
  const [resource, setResource] = useState("project:market-intelligence");
  const [domain, setDomain] = useState("vendor.example");
  const [cost, setCost] = useState("0.40");
  const [parentDepth, setParentDepth] = useState("");
  const [result, setResult] = useState<VerifyResult | null>(null);
  const [busy, setBusy] = useState(false);

  const [issueAgent, setIssueAgent] = useState(agentHandles[0]?.id ?? "agt_mira");
  const [issueActions, setIssueActions] = useState("http.get,browser.read");
  const [issueResources, setIssueResources] = useState("project:market-intelligence");
  const [issueDomains, setIssueDomains] = useState("vendor.example");
  const [issueCost, setIssueCost] = useState("0.75");
  const [issueDepth, setIssueDepth] = useState("1");
  const [issueTtl, setIssueTtl] = useState("30");
  const [issued, setIssued] = useState<{ token: string; signature: string; envelopeId: string } | null>(null);
  const [issuing, setIssuing] = useState(false);

  const selected = envelopes.find((e) => e.id === envelopeId);

  const evaluate = async () => {
    if (!envelopeId) return;
    setBusy(true);
    try {
      const res = await fetch("/api/authority", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          mode: "verify",
          envelopeId,
          action,
          resource,
          domain: domain || undefined,
          cost: Number(cost) || 0,
          parentDepth: parentDepth === "" ? undefined : Number(parentDepth),
        }),
      });
      const data = (await res.json()) as VerifyResult;
      setResult(data);
      router.refresh();
    } finally {
      setBusy(false);
    }
  };

  const issue = async () => {
    setIssuing(true);
    try {
      const res = await fetch("/api/authority", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          mode: "issue",
          agentId: issueAgent,
          actions: issueActions.split(",").map((s) => s.trim()).filter(Boolean),
          resources: issueResources.split(",").map((s) => s.trim()).filter(Boolean),
          domains: issueDomains.split(",").map((s) => s.trim()).filter(Boolean),
          maxCost: Number(issueCost) || 0,
          delegationDepth: Number(issueDepth) || 0,
          ttlMinutes: Number(issueTtl) || 30,
        }),
      });
      const data = (await res.json()) as { token: string; signature: string; envelopeId: string };
      setIssued(data);
      setEnvelopeId(data.envelopeId);
      router.refresh();
    } finally {
      setIssuing(false);
    }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <div>
        <p className="mono text-[9.5px] uppercase tracking-[0.14em] text-zinc-500">evaluate a requested action</p>
        <div className="mt-2 space-y-2">
          <label className="block">
            <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">envelope</span>
            <select value={envelopeId} onChange={(e) => setEnvelopeId(e.target.value)} className="field mt-1">
              {envelopes.map((env) => (
                <option key={env.id} value={env.id}>
                  {env.agentId} · {env.policyVersion} {env.revoked ? "· REVOKED" : ""}
                </option>
              ))}
            </select>
          </label>
          {selected && (
            <p className="mono text-[9px] leading-relaxed text-zinc-600">
              grants [{selected.payload.actions.join(", ")}] · domain [{selected.payload.domains.join(", ") || "none"}] · ceiling ${selected.payload.maxCost.toFixed(2)} ·
              depth {selected.payload.delegationDepth} · expires {new Date(selected.expiresAt).toISOString().slice(11, 16)}Z
            </p>
          )}
          <div className="grid grid-cols-2 gap-2">
            <label className="block">
              <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">action</span>
              <select value={action} onChange={(e) => setAction(e.target.value)} className="field mt-1">
                {[...new Set([...ACTIONS, ...(selected?.payload.actions ?? [])])].map((a) => (
                  <option key={a} value={a}>{a}</option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">requested cost $</span>
              <input value={cost} onChange={(e) => setCost(e.target.value)} className="field mt-1" inputMode="decimal" />
            </label>
          </div>
          <label className="block">
            <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">resource</span>
            <input value={resource} onChange={(e) => setResource(e.target.value)} className="field mt-1" />
          </label>
          <div className="grid grid-cols-2 gap-2">
            <label className="block">
              <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">egress domain</span>
              <input value={domain} onChange={(e) => setDomain(e.target.value)} className="field mt-1" />
            </label>
            <label className="block">
              <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">parent depth (delegation)</span>
              <input value={parentDepth} onChange={(e) => setParentDepth(e.target.value)} placeholder="root grant" className="field mt-1" inputMode="numeric" />
            </label>
          </div>
          <button type="button" onClick={evaluate} disabled={busy || !envelopeId} className="btn btn-primary w-full justify-center">
            {busy ? <Loader2 size={12} className="animate-spin" /> : <ShieldCheck size={12} />} Evaluate at the execution boundary
          </button>

          {result && (
            <div className={`rounded-lg border p-3 ${result.decision === "allow" ? "border-emerald-400/30 bg-emerald-400/[0.06]" : "border-rose-400/30 bg-rose-400/[0.06]"}`}>
              <div className="flex items-center gap-2">
                {result.decision === "allow" ? <ShieldCheck size={14} className="text-emerald-300" /> : <ShieldAlert size={14} className="text-rose-300" />}
                <span className={`mono text-[11px] uppercase tracking-[0.1em] ${result.decision === "allow" ? "text-emerald-200" : "text-rose-200"}`}>{result.decision}</span>
                <span className="mono ml-auto text-[9px] text-zinc-500">{result.tokenRef}</span>
              </div>
              <p className="mt-1 text-[11px] leading-relaxed text-zinc-300">{result.reason}</p>
              <div className="mt-2 space-y-0.5">
                {result.checks.map((check) => (
                  <div key={check.invariant} className="flex items-start gap-1.5">
                    <span className={`mono mt-[1px] shrink-0 text-[10px] ${check.pass ? "text-emerald-300" : "text-rose-300"}`}>{check.pass ? "✓" : "✕"}</span>
                    <p className="mono text-[9.5px] leading-relaxed text-zinc-500">
                      <span className={check.pass ? "text-zinc-300" : "text-rose-200"}>{check.invariant}</span> · {check.detail}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div>
        <p className="mono text-[9.5px] uppercase tracking-[0.14em] text-zinc-500">issue a scoped, short-lived envelope</p>
        <div className="mt-2 space-y-2">
          <label className="block">
            <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">identity</span>
            <select value={issueAgent} onChange={(e) => setIssueAgent(e.target.value)} className="field mt-1">
              {agentHandles.map((a) => (
                <option key={a.id} value={a.id}>{a.handle}</option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">actions (comma separated)</span>
            <input value={issueActions} onChange={(e) => setIssueActions(e.target.value)} className="field mt-1" />
          </label>
          <label className="block">
            <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">resources</span>
            <input value={issueResources} onChange={(e) => setIssueResources(e.target.value)} className="field mt-1" />
          </label>
          <label className="block">
            <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">egress allowlist</span>
            <input value={issueDomains} onChange={(e) => setIssueDomains(e.target.value)} className="field mt-1" />
          </label>
          <div className="grid grid-cols-3 gap-2">
            <label className="block">
              <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">max $</span>
              <input value={issueCost} onChange={(e) => setIssueCost(e.target.value)} className="field mt-1" inputMode="decimal" />
            </label>
            <label className="block">
              <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">depth</span>
              <input value={issueDepth} onChange={(e) => setIssueDepth(e.target.value)} className="field mt-1" inputMode="numeric" />
            </label>
            <label className="block">
              <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">ttl min</span>
              <input value={issueTtl} onChange={(e) => setIssueTtl(e.target.value)} className="field mt-1" inputMode="numeric" />
            </label>
          </div>
          <button type="button" onClick={issue} disabled={issuing} className="btn w-full justify-center">
            {issuing ? <Loader2 size={12} className="animate-spin" /> : <Check size={12} />} Sign envelope
          </button>
          {issued && (
            <div className="rounded-lg border border-white/[0.08] bg-black/40 p-2.5">
              <p className="mono text-[9px] uppercase tracking-[0.1em] text-cyan-300">signed token</p>
              <p className="mono mt-1 break-all text-[9px] leading-relaxed text-zinc-500">{issued.token}</p>
              <p className="mono mt-1 text-[9px] text-zinc-600">signature {issued.signature}</p>
            </div>
          )}
          <p className="mono text-[9px] leading-relaxed text-zinc-600">
            The model never sees the underlying credential. The gateway validates this envelope, then injects the secret at the tool boundary.
          </p>
        </div>
      </div>
    </div>
  );
}
