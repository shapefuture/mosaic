import type { ReactNode } from "react";
import { STATUS_TONE, label } from "@/lib/format";

export function Panel({
  children,
  className = "",
  title,
  subtitle,
  actions,
  bodyClass = "",
}: {
  children: ReactNode;
  className?: string;
  title?: ReactNode;
  subtitle?: ReactNode;
  actions?: ReactNode;
  bodyClass?: string;
}) {
  return (
    <section className={`panel overflow-hidden ${className}`}>
      {(title || actions) && (
        <header className="flex flex-wrap items-center gap-2 border-b border-white/[0.06] px-4 py-2.5">
          <div className="min-w-0">
            {typeof title === "string" ? (
              <h2 className="text-[12.5px] font-medium tracking-tight text-zinc-200">{title}</h2>
            ) : (
              title
            )}
            {subtitle && <p className="mt-0.5 text-[11px] leading-snug text-zinc-500">{subtitle}</p>}
          </div>
          {actions && <div className="ml-auto flex items-center gap-1.5">{actions}</div>}
        </header>
      )}
      <div className={bodyClass || "p-4"}>{children}</div>
    </section>
  );
}

export function Badge({ children, status, tone }: { children?: ReactNode; status?: string; tone?: string }) {
  const cls = tone ?? (status ? STATUS_TONE[status] : "") ?? "text-zinc-400 border-zinc-600/40 bg-zinc-500/10";
  return (
    <span
      className={`mono inline-flex items-center gap-1 whitespace-nowrap rounded-md border px-1.5 py-0.5 text-[10px] uppercase tracking-[0.06em] ${cls}`}
    >
      {children ?? (status ? label(status) : null)}
    </span>
  );
}

export function Stat({
  label: statLabel,
  value,
  hint,
  accent = "text-zinc-100",
  icon,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  accent?: string;
  icon?: ReactNode;
}) {
  return (
    <div className="panel px-3.5 py-3">
      <div className="flex items-start justify-between gap-2">
        <p className="mono text-[9.5px] uppercase tracking-[0.14em] text-zinc-500">{statLabel}</p>
        {icon && <span className="text-zinc-600">{icon}</span>}
      </div>
      <p className={`tnum mt-1.5 text-[22px] font-medium leading-none tracking-tight ${accent}`}>{value}</p>
      {hint && <p className="mt-1.5 text-[10.5px] leading-snug text-zinc-500">{hint}</p>}
    </div>
  );
}

export function Meter({ value, max, tone = "bg-cyan-400", muted = "bg-white/10" }: { value: number; max: number; tone?: string; muted?: string }) {
  const pctValue = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  return (
    <div className={`h-1.5 w-full overflow-hidden rounded-full ${muted}`}>
      <div className={`h-full rounded-full ${tone} transition-all duration-500`} style={{ width: `${Math.max(pctValue, value > 0 ? 3 : 0)}%` }} />
    </div>
  );
}

export function SectionHeading({ eyebrow, title, children }: { eyebrow?: string; title: string; children?: ReactNode }) {
  return (
    <div className="mb-3 flex flex-wrap items-end justify-between gap-2">
      <div>
        {eyebrow && <p className="mono text-[9.5px] uppercase tracking-[0.16em] text-zinc-500">{eyebrow}</p>}
        <h2 className="text-[15px] font-medium tracking-tight text-zinc-100">{title}</h2>
      </div>
      {children}
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="rounded-lg border border-dashed border-white/10 px-3 py-6 text-center text-[12px] text-zinc-500">{children}</div>;
}

export function Kv({ items }: { items: { k: string; v: ReactNode }[] }) {
  return (
    <dl className="grid grid-cols-[minmax(88px,auto)_1fr] gap-x-3 gap-y-1.5 text-[11.5px]">
      {items.map((item) => (
        <div key={item.k} className="contents">
          <dt className="mono text-[10px] uppercase tracking-[0.08em] text-zinc-500">{item.k}</dt>
          <dd className="text-zinc-300">{item.v}</dd>
        </div>
      ))}
    </dl>
  );
}

export function AgentMark({ glyph, color, size = 26 }: { glyph: string; color: string; size?: number }) {
  return (
    <span
      className="grid shrink-0 place-items-center rounded-md border text-[12px]"
      style={{
        width: size,
        height: size,
        color,
        borderColor: `${color}45`,
        background: `${color}12`,
      }}
    >
      {glyph}
    </span>
  );
}

export function Sparkline({ data, tone = "#67e8f9", height = 44 }: { data: number[]; tone?: string; height?: number }) {
  const width = 220;
  if (data.length < 2) {
    return <div className="mono text-[10px] text-zinc-600">awaiting telemetry</div>;
  }
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const span = max - min || 1;
  const step = width / (data.length - 1);
  const points = data.map((v, i) => `${(i * step).toFixed(1)},${(height - 4 - ((v - min) / span) * (height - 10)).toFixed(1)}`);
  const path = `M${points.join(" L")}`;
  return (
    <svg viewBox={`0 0 ${width} ${height}`} width="100%" height={height} preserveAspectRatio="none" aria-hidden>
      <defs>
        <linearGradient id={`fill-${tone.replace("#", "")}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={tone} stopOpacity="0.28" />
          <stop offset="100%" stopColor={tone} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={`${path} L${width},${height} L0,${height} Z`} fill={`url(#fill-${tone.replace("#", "")})`} />
      <path d={path} fill="none" stroke={tone} strokeWidth="1.4" strokeLinejoin="round" strokeLinecap="round" />
      {points.length > 0 && <circle cx={points[points.length - 1].split(",")[0]} cy={points[points.length - 1].split(",")[1]} r="2" fill={tone} />}
    </svg>
  );
}

export function Progress({ done, total, tone = "bg-emerald-400" }: { done: number; total: number; tone?: string }) {
  return (
    <div className="flex items-center gap-2">
      <Meter value={done} max={Math.max(total, 1)} tone={tone} />
      <span className="mono tnum shrink-0 text-[10px] text-zinc-500">
        {done}/{total}
      </span>
    </div>
  );
}

export function TierChip({ tier }: { tier: number }) {
  const map: Record<number, { label: string; cls: string }> = {
    0: { label: "T0 · api", cls: "text-cyan-300 border-cyan-400/25 bg-cyan-400/[0.07]" },
    1: { label: "T1 · container", cls: "text-violet-300 border-violet-400/25 bg-violet-400/[0.07]" },
    2: { label: "T2 · microvm", cls: "text-amber-300 border-amber-400/25 bg-amber-400/[0.07]" },
  };
  const item = map[tier] ?? map[0];
  return <span className={`mono rounded border px-1.5 py-0.5 text-[9.5px] uppercase tracking-[0.05em] ${item.cls}`}>{item.label}</span>;
}
