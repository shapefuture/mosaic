import type { Task } from "@/db/schema";
import { QUEUE_TONE } from "@/lib/format";

const NODE_W = 158;
const NODE_H = 40;
const GAP_X = 34;
const GAP_Y = 12;
const PAD = 14;

const STATUS_FILL: Record<string, { fill: string; stroke: string; text: string }> = {
  succeeded: { fill: "rgba(52,211,153,0.10)", stroke: "rgba(52,211,153,0.45)", text: "#a7f3d0" },
  running: { fill: "rgba(56,189,248,0.14)", stroke: "rgba(56,189,248,0.55)", text: "#bae6fd" },
  ready: { fill: "rgba(34,211,238,0.08)", stroke: "rgba(34,211,238,0.35)", text: "#a5f3fc" },
  waiting_approval: { fill: "rgba(251,191,36,0.10)", stroke: "rgba(251,191,36,0.5)", text: "#fde68a" },
  blocked: { fill: "rgba(255,255,255,0.025)", stroke: "rgba(255,255,255,0.12)", text: "#a1a1aa" },
  failed: { fill: "rgba(251,113,133,0.10)", stroke: "rgba(251,113,133,0.5)", text: "#fecdd3" },
};

function truncate(text: string, max: number) {
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

export function Dag({ tasks }: { tasks: Task[] }) {
  const levels = new Map<string, number>();
  const byId = new Map(tasks.map((t) => [t.id, t]));
  const resolve = (id: string, seen = new Set<string>()): number => {
    if (levels.has(id)) return levels.get(id)!;
    if (seen.has(id)) return 0;
    seen.add(id);
    const task = byId.get(id);
    if (!task || task.dependsOn.length === 0) {
      levels.set(id, 0);
      return 0;
    }
    const level = Math.max(...task.dependsOn.map((d) => resolve(d, seen))) + 1;
    levels.set(id, level);
    return level;
  };
  tasks.forEach((t) => resolve(t.id));

  const columns = new Map<number, Task[]>();
  for (const task of tasks) {
    const level = levels.get(task.id) ?? 0;
    columns.set(level, [...(columns.get(level) ?? []), task]);
  }
  const maxLevel = Math.max(0, ...columns.keys());
  const maxRows = Math.max(1, ...Array.from(columns.values()).map((c) => c.length));
  const width = PAD * 2 + (maxLevel + 1) * NODE_W + maxLevel * GAP_X;
  const height = PAD * 2 + maxRows * NODE_H + (maxRows - 1) * GAP_Y;

  const positions = new Map<string, { x: number; y: number }>();
  for (const [level, items] of columns) {
    items
      .slice()
      .sort((a, b) => a.position - b.position)
      .forEach((task, row) => {
        positions.set(task.id, {
          x: PAD + level * (NODE_W + GAP_X),
          y: PAD + row * (NODE_H + GAP_Y),
        });
      });
  }

  return (
    <div className="overflow-x-auto">
      <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="min-w-full">
        <defs>
          <marker id="dag-arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto">
            <path d="M0,0 L7,3.5 L0,7 z" fill="rgba(255,255,255,0.22)" />
          </marker>
        </defs>
        {tasks.flatMap((task) =>
          task.dependsOn.map((dep) => {
            const from = positions.get(dep);
            const to = positions.get(task.id);
            if (!from || !to) return null;
            const sx = from.x + NODE_W;
            const sy = from.y + NODE_H / 2;
            const tx = to.x;
            const ty = to.y + NODE_H / 2;
            const mid = (sx + tx) / 2;
            const active = task.status !== "blocked";
            return (
              <path
                key={`${dep}-${task.id}`}
                d={`M${sx},${sy} C${mid},${sy} ${mid},${ty} ${tx - 4},${ty}`}
                fill="none"
                stroke={active ? "rgba(103,232,249,0.32)" : "rgba(255,255,255,0.12)"}
                strokeWidth="1"
                markerEnd="url(#dag-arrow)"
              />
            );
          }),
        )}
        {tasks.map((task) => {
          const pos = positions.get(task.id);
          if (!pos) return null;
          const style = STATUS_FILL[task.status] ?? STATUS_FILL.blocked;
          const tone = QUEUE_TONE[task.queue];
          return (
            <g key={task.id}>
              <rect x={pos.x} y={pos.y} width={NODE_W} height={NODE_H} rx={8} fill={style.fill} stroke={style.stroke} strokeWidth="1" />
              <rect x={pos.x} y={pos.y} width={3} height={NODE_H} rx={1.5} fill={tone} opacity={0.9} />
              <text x={pos.x + 11} y={pos.y + 16} fill={style.text} fontSize="10.5" fontWeight="500">
                {truncate(task.title, 22)}
              </text>
              <text x={pos.x + 11} y={pos.y + 29} fill="rgba(228,232,240,0.45)" fontSize="8.5" fontFamily="var(--font-geist-mono), monospace" letterSpacing="0.04em">
                {task.queue.toUpperCase()} · T{task.tier} · {task.status.replace("_", " ").toUpperCase()}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

export function DagLegend() {
  return (
    <div className="mono flex flex-wrap items-center gap-3 text-[9px] uppercase tracking-[0.06em] text-zinc-500">
      {(["succeeded", "running", "ready", "waiting_approval", "blocked", "failed"] as const).map((status) => (
        <span key={status} className="flex items-center gap-1">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: STATUS_FILL[status].stroke }} />
          {status.replace("_", " ")}
        </span>
      ))}
    </div>
  );
}
