import { Activity, CircleCheck, CircleX, FlaskConical, Trash2 } from "lucide-react";
import { cleanupFormAction, qualificationFormAction, savePolicyAction } from "@/app/actions";
import { Badge, Empty, Kv, Meter, Panel, Sparkline, Stat, TierChip } from "@/components/ui";
import { getScheduler } from "@/lib/queries";
import { QUEUE_LABEL, QUEUE_TONE, num, pct, timeAgo, usd } from "@/lib/format";

export const dynamic = "force-dynamic";

const QUEUE_FIELDS = [
  { key: "interactive", label: "Interactive", hint: "chat, questions, approvals" },
  { key: "io", label: "I/O parallel", hint: "research, API calls, extraction" },
  { key: "compute", label: "Compute", hint: "code, documents, parsers" },
  { key: "browser", label: "Browser", hint: "authenticated pages, GUI" },
] as const;

export default async function SchedulerPage() {
  const data = await getScheduler();
  const { policy, lanes, workers, metrics, stats, runs } = data;
  const throughput = metrics.map((m) => m.committed);
  const resident = metrics.map((m) => m.residentMb);
  const spendSeries = metrics.map((m) => num(m.spendUsd));
  const laneCapacity = lanes.reduce((sum, l) => sum + l.limit, 0);
  const capacityMath = [
    { k: "provider cap", v: policy.providerConcurrency },
    { k: "tenant cap", v: policy.tenantConcurrency },
    { k: "lane capacity", v: laneCapacity },
    { k: "browser lane", v: Math.min(policy.browserPool, policy.browser) },
    { k: "sandbox lane", v: Math.min(policy.sandboxSlots, policy.compute) },
  ];
  const narrowest = Math.min(policy.providerConcurrency, policy.tenantConcurrency, laneCapacity);
  const bindingLane = [...lanes].sort((a, b) => a.limit / Math.max(a.limit + a.ready, 1) - b.limit / Math.max(b.limit + b.ready, 1))[0];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-3 xl:grid-cols-6">
        <Stat label="allowed now" value={narrowest} hint="min(provider, tenant, Σ lanes)" accent="text-cyan-200" />
        <Stat label="leased" value={stats.running} hint={`${stats.ready} queued`} />
        <Stat label="committed" value={stats.throughput} hint={`${pct(stats.failureRate)} failure rate`} accent="text-emerald-200" />
        <Stat label="cost / committed" value={usd(stats.costPerVerified, 3)} hint="model + tier charges" accent="text-violet-200" />
        <Stat label="tokens / result" value={Math.round(stats.tokensPerResult).toLocaleString()} hint="compact context pays off" />
        <Stat label="spend" value={usd(stats.spend)} hint={`of ${usd(stats.ceiling, 0)} ceiling`} accent="text-amber-200" />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.4fr_1fr]">
        <div className="space-y-4">
          <Panel
            title="Queue lanes"
            subtitle="Four independent queues. One pathological browser task cannot starve interactive work."
            bodyClass="p-4"
          >
            <div className="space-y-2.5">
              {lanes.map((lane) => (
                <div key={lane.lane}>
                  <div className="flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: QUEUE_TONE[lane.lane] }} />
                    <span className="text-[11.5px] text-zinc-300">{QUEUE_LABEL[lane.lane]}</span>
                    <span className="mono ml-auto text-[9.5px] text-zinc-500">
                      {lane.running}/{lane.limit} leased · {lane.ready} waiting
                    </span>
                  </div>
                  <div className="mt-1">
                    <Meter value={lane.running} max={lane.limit} tone={lane.running >= lane.limit ? "bg-amber-400" : "bg-cyan-400"} />
                  </div>
                </div>
              ))}
            </div>
            <p className="mono mt-3 border-t border-white/[0.06] pt-2 text-[9.5px] leading-relaxed text-zinc-600">
              C_allowed = min(provider, tenant, Σ lane limits, budget) → {narrowest} concurrent executions across lanes. Tightest lane: {bindingLane?.lane ?? "io"} ({bindingLane?.limit ?? 0}). Autoscale {policy.autoscale ? "on" : "off"}:
              failure rate above 20% shrinks every lane by up to 60%.
            </p>
          </Panel>

          <Panel title="Throughput & residency" subtitle="Completed work per tick against resident memory." bodyClass="p-4">
            <div className="grid gap-3 md:grid-cols-3">
              <div>
                <p className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-600">committed / tick</p>
                <Sparkline data={throughput.length ? throughput : [0, 1, 0]} tone="#34d399" />
              </div>
              <div>
                <p className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-600">resident MB</p>
                <Sparkline data={resident.length ? resident : [0, 0]} tone="#a78bfa" />
              </div>
              <div>
                <p className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-600">committed spend</p>
                <Sparkline data={spendSeries.length ? spendSeries : [0, 1]} tone="#67e8f9" />
              </div>
            </div>
            <div className="mono mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[9.5px] text-zinc-600">
              <span>{metrics.length} telemetry samples</span>
              <span>idle sessions in last sample · {metrics[metrics.length - 1]?.idleSessions ?? 0}</span>
              <span>queue depth · {metrics[metrics.length - 1]?.queueDepth ?? 0}</span>
            </div>
          </Panel>

          <Panel title="Elastic worker leases" subtitle="Ephemeral execution. Nothing here outlives its task." bodyClass="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[11px]">
                <thead>
                  <tr className="border-b border-white/[0.06] text-zinc-500">
                    <th className="mono px-3 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">lease</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">lane</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">memory</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">tier</th>
                    <th className="mono px-3 py-1.5 text-right text-[9px] font-normal uppercase tracking-[0.07em]">held</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.04]">
                  {workers.map((worker) => (
                    <tr key={worker.id} className="row-hover">
                      <td className="mono px-3 py-1.5 text-[10px] text-zinc-300">{worker.id}</td>
                      <td className="mono px-2 py-1.5 text-[9.5px] text-zinc-400">{worker.pool}</td>
                      <td className="mono tnum px-2 py-1.5 text-[9.5px] text-zinc-400">{worker.memoryMb} MB</td>
                      <td className="px-2 py-1.5"><TierChip tier={worker.tier} /></td>
                      <td className="mono px-3 py-1.5 text-right text-[9px] text-zinc-600">{timeAgo(worker.startedAt)}</td>
                    </tr>
                  ))}
                  {!workers.length && (
                    <tr><td colSpan={5} className="px-3 py-5 text-center text-zinc-500">No leases held. Zero cost while the fleet sleeps.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </Panel>

          <Panel title="Capacity qualification" subtitle="Prove the architecture; do not trust a vendor number." bodyClass="p-4">
            <div className="grid gap-2 sm:grid-cols-2">
              {[
                { kind: "idle_sessions", label: "Idle session flood", hint: `1024 durable sessions, no resident worker` },
                { kind: "io_flood", label: "Bounded fan-out", hint: `200 requested, cap ${policy.maxFanout} admitted` },
                { kind: "failure_injection", label: "Kill workers mid-lease", hint: "no lost work, leases reclaimed" },
                { kind: "duplicate_event", label: "Duplicate side effect", hint: "idempotency suppresses the repeat" },
              ].map((item) => (
                <form key={item.kind} action={qualificationFormAction} className="panel-flat flex flex-col p-2.5">
                  <input type="hidden" name="kind" value={item.kind} />
                  <p className="text-[11.5px] text-zinc-200">{item.label}</p>
                  <p className="mono mt-0.5 text-[9px] leading-snug text-zinc-500">{item.hint}</p>
                  <button type="submit" className="btn mt-2 justify-center text-[10.5px]">
                    <FlaskConical size={11} /> Run test
                  </button>
                </form>
              ))}
            </div>
            <div className="mt-3 flex items-center gap-2">
              <form action={cleanupFormAction}>
                <button type="submit" className="btn btn-danger text-[10.5px]"><Trash2 size={11} /> Clean synthetic data</button>
              </form>
              <span className="mono text-[9px] text-zinc-600">production records are never touched</span>
            </div>

            <div className="mt-3 space-y-2">
              {runs.map((run) => (
                <div key={run.id} className="rounded-lg border border-white/[0.07] bg-white/[0.015] p-2.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="mono text-[10px] uppercase tracking-[0.08em] text-cyan-300">{run.kind.replace(/_/g, " ")}</span>
                    <Badge status={run.status} />
                    <span className="mono ml-auto text-[9px] text-zinc-600">{timeAgo(run.createdAt)}</span>
                  </div>
                  <div className="mt-1.5 space-y-1">
                    {run.gates.map((gate) => (
                      <div key={gate.gate} className="flex items-start gap-1.5">
                        {gate.pass ? <CircleCheck size={11} className="mt-[2px] shrink-0 text-emerald-300" /> : <CircleX size={11} className="mt-[2px] shrink-0 text-rose-300" />}
                        <p className="text-[10.5px] leading-relaxed text-zinc-400">
                          <span className="text-zinc-300">{gate.gate}</span> · {gate.evidence}
                        </p>
                      </div>
                    ))}
                  </div>
                  <p className="mono mt-1.5 text-[9px] text-zinc-600">
                    {Object.entries(run.result)
                      .slice(0, 4)
                      .map(([k, v]) => `${k}=${String(v)}`)
                      .join(" · ")}
                  </p>
                </div>
              ))}
              {!runs.length && <Empty>No qualification runs captured yet. Four gates are available above.</Empty>}
            </div>
          </Panel>
        </div>

        <div className="space-y-4">
          <Panel title="Runtime policy" subtitle="Tune the constraints; the scheduler recomputes." bodyClass="p-4">
            <form action={savePolicyAction} className="space-y-2.5">
              <div className="grid grid-cols-2 gap-2">
                {QUEUE_FIELDS.map((field) => (
                  <label key={field.key} className="block">
                    <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">{field.label} lanes</span>
                    <input type="number" min={0} max={64} name={field.key} defaultValue={policy[field.key]} className="field mt-1" />
                    <span className="mono mt-0.5 block text-[8.5px] text-zinc-600">{field.hint}</span>
                  </label>
                ))}
                <label className="block">
                  <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">provider concurrency</span>
                  <input type="number" min={0} max={256} name="providerConcurrency" defaultValue={policy.providerConcurrency} className="field mt-1" />
                </label>
                <label className="block">
                  <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">tenant concurrency</span>
                  <input type="number" min={0} max={256} name="tenantConcurrency" defaultValue={policy.tenantConcurrency} className="field mt-1" />
                </label>
                <label className="block">
                  <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">browser pool</span>
                  <input type="number" min={0} max={32} name="browserPool" defaultValue={policy.browserPool} className="field mt-1" />
                </label>
                <label className="block">
                  <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">sandbox slots</span>
                  <input type="number" min={0} max={32} name="sandboxSlots" defaultValue={policy.sandboxSlots} className="field mt-1" />
                </label>
                <label className="block">
                  <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">fan-out cap</span>
                  <input type="number" min={1} max={32} name="maxFanout" defaultValue={policy.maxFanout} className="field mt-1" />
                </label>
                <label className="block">
                  <span className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-500">budget ceiling $</span>
                  <input type="number" min={0} max={100000} name="budgetCeilingUsd" defaultValue={num(policy.budgetCeilingUsd)} className="field mt-1" />
                </label>
              </div>
              <label className="mono flex items-center gap-2 text-[10px] uppercase tracking-[0.08em] text-zinc-400">
                <input type="checkbox" name="autoscale" defaultChecked={policy.autoscale} className="h-3.5 w-3.5 accent-cyan-400" />
                adaptive concurrency from failure feedback
              </label>
              <button type="submit" className="btn btn-primary w-full justify-center">
                <Activity size={12} /> Apply policy
              </button>
              <p className="mono text-[9px] leading-relaxed text-zinc-600">
                Lower the fan-out cap below a template&apos;s task count and planning is refused instead of silently trimming the graph.
              </p>
            </form>
          </Panel>

          <Panel title="Constraint ledger">
            <Kv
              items={[
                ...capacityMath.map((c) => ({ k: c.k, v: `${c.v}` })),
                { k: "narrowest", v: <span className="mono text-cyan-200">{narrowest}</span> },
                { k: "autoscale", v: policy.autoscale ? "enabled" : "disabled" },
              ]}
            />
          </Panel>

          <Panel title="Reconciliation log" subtitle="Duplicates reconciled instead of re-executed." bodyClass="p-0">
            <div className="divide-y divide-white/[0.05]">
              {data.receipts.slice(0, 6).map((receipt) => (
                <div key={receipt.id} className="px-4 py-2">
                  <div className="flex items-center gap-2">
                    <Badge status={receipt.outcome} />
                    <span className="mono text-[9.5px] text-zinc-500">{receipt.action}</span>
                    <span className="mono ml-auto text-[9px] text-zinc-600">{timeAgo(receipt.createdAt)}</span>
                  </div>
                  <p className="mono mt-0.5 truncate text-[9.5px] text-zinc-500">{receipt.resource}</p>
                </div>
              ))}
              {!data.receipts.length && <div className="p-4"><Empty>No duplicates observed.</Empty></div>}
            </div>
          </Panel>

          <Panel title="Explicit non-goals" bodyClass="p-4">
            <ul className="space-y-1 text-[10.5px] leading-relaxed text-zinc-500">
              <li>· Redis, Kafka, NATS — not needed at this event volume.</li>
              <li>· Neo4j / FalkorDB / Qdrant — relations and lexical search first.</li>
              <li>· Multiple workflow engines or gateways — one authority each.</li>
              <li>· A resident desktop per research task — Browser Run contexts instead.</li>
              <li>· Kubernetes on day one — managed serverless execution.</li>
            </ul>
          </Panel>
        </div>
      </div>
    </div>
  );
}
