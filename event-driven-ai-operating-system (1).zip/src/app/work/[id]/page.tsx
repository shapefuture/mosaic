import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Check, CircleDashed, Sparkles, X } from "lucide-react";
import { decideApprovalFormAction, gauntletFormAction } from "@/app/actions";
import { AgentMark, Badge, Empty, Kv, Meter, Panel, Stat, TierChip } from "@/components/ui";
import { Dag, DagLegend } from "@/components/dag";
import { getWorkUnit } from "@/lib/queries";
import { QUEUE_LABEL, num, pct, timeAgo, usd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function WorkUnitPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const data = await getWorkUnit(id);
  if (!data) notFound();
  const { unit, tasks: unitTasks, receipts: unitReceipts, rounds, approvals: unitApprovals, owner, acceptance } = data;

  const succeeded = unitTasks.filter((t) => t.status === "succeeded").length;
  const met = acceptance.filter((a) => a.met).length;
  const spent = num(unit.spentUsd);
  const hasGauntlet = unitTasks.some((t) => t.gauntlet);
  const lastRound = rounds[rounds.length - 1];
  const totalTokens = unitTasks.reduce((sum, t) => sum + t.tokensIn + t.tokensOut, 0);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Link href="/work" className="mono inline-flex items-center gap-1 text-[10px] uppercase tracking-[0.1em] text-zinc-500 hover:text-zinc-300">
          <ArrowLeft size={11} /> work engine
        </Link>
        <span className="mono text-[9.5px] text-zinc-700">/ {unit.id}</span>
      </div>

      <Panel bodyClass="p-4">
        <div className="flex flex-wrap items-start gap-3">
          {owner && <AgentMark glyph={owner.glyph} color={owner.color} size={38} />}
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-[16px] font-medium tracking-tight text-zinc-50">{unit.title}</h2>
              <Badge status={unit.status} />
              <Badge tone="text-violet-300 border-violet-400/30 bg-violet-400/10">{unit.template}</Badge>
            </div>
            <p className="mt-1.5 max-w-[86ch] text-[12px] leading-relaxed text-zinc-400">{unit.objective}</p>
            <p className="mono mt-2 text-[10px] text-zinc-500">
              bar · {unit.bar || "no external bar recorded"}
            </p>
          </div>
          <div className="flex flex-col items-end gap-1.5">
            {hasGauntlet && (
              <form action={gauntletFormAction}>
                <input type="hidden" name="workUnitId" value={unit.id} />
                <button type="submit" className="btn btn-primary">
                  <Sparkles size={12} /> Run gauntlet round
                </button>
              </form>
            )}
            <span className="mono text-[9.5px] text-zinc-600">
              opened {timeAgo(unit.createdAt)} · {num(unit.spentUsd).toFixed(2)} USD committed
            </span>
          </div>
        </div>
      </Panel>

      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-4">
        <Stat label="tasks committed" value={`${succeeded}/${unitTasks.length}`} hint={`${unitTasks.filter((t) => t.status === "running").length} leased now`} accent="text-emerald-200" />
        <Stat label="acceptance" value={`${met}/${acceptance.length}`} hint="hard gates, not opinions" accent={met === acceptance.length ? "text-emerald-200" : "text-amber-200"} />
        <Stat label="gauntlet" value={lastRound ? `r${lastRound.round}` : "—"} hint={lastRound ? (lastRound.criticVerdict === "ours" ? "ours won blind" : "bar still ahead") : "not started"} accent="text-violet-200" />
        <Stat label="tokens" value={totalTokens.toLocaleString()} hint={`${usd(spent / Math.max(succeeded, 1), 3)} per committed task`} accent="text-cyan-200" />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.65fr_1fr]">
        <div className="space-y-4">
          <Panel title="Task DAG" subtitle="Frontier execution only; independent branches run concurrently." actions={<DagLegend />} bodyClass="p-3">
            <Dag tasks={unitTasks} />
          </Panel>

          <Panel title="Task ledger" subtitle="Queue lane, execution tier, model, cost and verification." bodyClass="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[11px]">
                <thead>
                  <tr className="border-b border-white/[0.06] text-zinc-500">
                    <th className="mono px-3 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">task</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">lane</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">tier</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">state</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">try</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">verify</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">model</th>
                    <th className="mono px-3 py-1.5 text-right text-[9px] font-normal uppercase tracking-[0.07em]">cost</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.04]">
                  {unitTasks.map((task) => (
                    <tr key={task.id} className="row-hover align-top">
                      <td className="px-3 py-1.5">
                        <div className="flex items-start gap-1.5">
                          <span className="mono mt-[1px] w-4 shrink-0 text-[9px] text-zinc-600">{task.position + 1}</span>
                          <div className="min-w-0">
                            <p className="text-zinc-200">
                              {task.title}
                              {task.gauntlet && <span className="mono ml-1.5 rounded border border-violet-400/30 bg-violet-400/10 px-1 text-[8px] uppercase text-violet-200">gauntlet</span>}
                              {task.consequential && <span className="mono ml-1.5 rounded border border-amber-400/30 bg-amber-400/10 px-1 text-[8px] uppercase text-amber-200">gated</span>}
                            </p>
                            {task.dependsOn.length > 0 && <p className="mono text-[9px] text-zinc-600">after {task.dependsOn.length} dep{task.dependsOn.length === 1 ? "" : "s"}</p>}
                            {task.failureReason && task.status !== "succeeded" && <p className="mono text-[9px] text-rose-300/80">{task.failureReason}</p>}
                          </div>
                        </div>
                      </td>
                      <td className="mono px-2 py-1.5 text-[9.5px] text-zinc-400">{QUEUE_LABEL[task.queue] ?? task.queue}</td>
                      <td className="px-2 py-1.5"><TierChip tier={task.tier} /></td>
                      <td className="px-2 py-1.5"><Badge status={task.status} /></td>
                      <td className="mono tnum px-2 py-1.5 text-[9.5px] text-zinc-400">{task.attempts}/{task.maxAttempts}</td>
                      <td className="px-2 py-1.5">
                        <span className={`mono text-[9.5px] ${task.verifyStatus === "passed" ? "text-emerald-300" : task.verifyStatus === "failed" ? "text-rose-300" : "text-zinc-600"}`}>
                          {task.verifyStatus}
                        </span>
                      </td>
                      <td className="mono px-2 py-1.5 text-[9.5px] text-zinc-500">{task.model}</td>
                      <td className="mono tnum px-3 py-1.5 text-right text-[9.5px] text-zinc-400">{usd(num(task.costActual), 3)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>

          <Panel
            title="Gauntlet quality loop"
            subtitle={`A separate critic compares blind against a named bar. ${rounds.length} round${rounds.length === 1 ? "" : "s"} on record.`}
            actions={<Badge tone={lastRound?.criticVerdict === "ours" ? "text-emerald-300 border-emerald-400/30 bg-emerald-400/10" : "text-amber-300 border-amber-400/30 bg-amber-400/10"}>{lastRound?.criticVerdict === "ours" ? "ours wins" : "bar ahead"}</Badge>}
            bodyClass="p-0"
          >
            <div className="divide-y divide-white/[0.05]">
              {rounds.map((round) => (
                <div key={round.id} className="px-4 py-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="mono text-[10px] uppercase tracking-[0.08em] text-zinc-500">round {round.round}</span>
                    <Badge status={round.criticVerdict}>{round.criticVerdict === "ours" ? "ours picked" : "bar picked"}</Badge>
                    <span className="mono ml-auto text-[9px] text-zinc-600">{usd(num(round.costUsd), 3)} · {timeAgo(round.createdAt)}</span>
                  </div>
                  <p className="mt-1 text-[12px] font-medium text-zinc-200">{round.artifactTitle}</p>
                  <p className="mt-1 text-[11px] leading-relaxed text-zinc-400">{round.criticNote}</p>
                  {round.gap && (
                    <p className="mono mt-1.5 rounded border border-amber-400/20 bg-amber-400/[0.06] px-2 py-1 text-[10px] leading-relaxed text-amber-200/90">
                      biggest gap · {round.gap}
                    </p>
                  )}
                  <details className="group mt-2">
                    <summary className="mono cursor-pointer list-none text-[9.5px] uppercase tracking-[0.1em] text-cyan-300/80 hover:text-cyan-200">
                      inspect artifact ▾
                    </summary>
                    <pre className="mt-1.5 max-h-[280px] overflow-y-auto whitespace-pre-wrap rounded-md border border-white/[0.07] bg-black/40 p-3 text-[10.5px] leading-relaxed text-zinc-400">{round.artifact}</pre>
                  </details>
                </div>
              ))}
              {!rounds.length && <div className="p-4"><Empty>No gauntlet rounds yet. The synthesis task opens round 1 on commit.</Empty></div>}
            </div>
          </Panel>

          <Panel title="Receipts" subtitle="Only meaningful boundaries are persisted." bodyClass="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[11px]">
                <thead>
                  <tr className="border-b border-white/[0.06] text-zinc-500">
                    <th className="mono px-3 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">action</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">resource</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">outcome</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">idempotency</th>
                    <th className="mono px-3 py-1.5 text-right text-[9px] font-normal uppercase tracking-[0.07em]">cost</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.04]">
                  {unitReceipts.map((receipt) => (
                    <tr key={receipt.id} className="row-hover">
                      <td className="mono px-3 py-1.5 text-[10px] text-zinc-300">{receipt.action}</td>
                      <td className="mono max-w-[240px] truncate px-2 py-1.5 text-[9.5px] text-zinc-500">{receipt.resource}</td>
                      <td className="px-2 py-1.5"><Badge status={receipt.outcome} /></td>
                      <td className="mono px-2 py-1.5 text-[9px] text-zinc-600">{receipt.idempotencyKey ? `…${receipt.idempotencyKey.slice(-18)}` : "n/a"}</td>
                      <td className="mono tnum px-3 py-1.5 text-right text-[9.5px] text-zinc-400">{usd(num(receipt.costUsd), 3)}</td>
                    </tr>
                  ))}
                  {!unitReceipts.length && (
                    <tr><td colSpan={5} className="px-3 py-5 text-center text-zinc-500">No receipts yet.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>

        <div className="space-y-4">
          <Panel title="Acceptance criteria" subtitle="Computed from artifacts, receipts and the critic." bodyClass="p-0">
            <ul className="divide-y divide-white/[0.05]">
              {acceptance.map((criterion) => (
                <li key={criterion.label} className="flex items-start gap-2 px-4 py-2">
                  {criterion.met ? (
                    <Check size={13} className="mt-[2px] shrink-0 text-emerald-300" />
                  ) : (
                    <CircleDashed size={13} className="mt-[2px] shrink-0 text-zinc-600" />
                  )}
                  <span className={`text-[11.5px] leading-relaxed ${criterion.met ? "text-zinc-300" : "text-zinc-500"}`}>{criterion.label}</span>
                </li>
              ))}
            </ul>
          </Panel>

          <Panel title="Authorization gates" bodyClass="p-0">
            {unitApprovals.map((approval) => (
              <div key={approval.id} className="border-b border-white/[0.05] px-4 py-2.5 last:border-b-0">
                <div className="flex items-center gap-2">
                  <Badge status={approval.status} />
                  <span className="mono text-[9.5px] uppercase tracking-[0.06em] text-zinc-500">{approval.action}</span>
                  <span className="mono ml-auto text-[9px] text-zinc-600">{timeAgo(approval.requestedAt)}</span>
                </div>
                <p className="mt-1 text-[11px] leading-relaxed text-zinc-400">{approval.reason}</p>
                {approval.status === "pending" && (
                  <div className="mt-2 flex gap-1.5">
                    <form action={decideApprovalFormAction}>
                      <input type="hidden" name="approvalId" value={approval.id} />
                      <input type="hidden" name="decision" value="approved" />
                      <button className="btn btn-primary px-2 py-1" type="submit"><Check size={11} /> Authorize</button>
                    </form>
                    <form action={decideApprovalFormAction}>
                      <input type="hidden" name="approvalId" value={approval.id} />
                      <input type="hidden" name="decision" value="denied" />
                      <button className="btn btn-danger px-2 py-1" type="submit"><X size={11} /> Deny</button>
                    </form>
                  </div>
                )}
                {approval.decidedBy && <p className="mono mt-1 text-[9px] text-zinc-600">decided by {approval.decidedBy} · {timeAgo(approval.decidedAt)}</p>}
              </div>
            ))}
            {!unitApprovals.length && <div className="p-4"><Empty>No gate required for this unit.</Empty></div>}
          </Panel>

          <Panel title="Unit facts">
            <Kv
              items={[
                { k: "owner", v: owner ? <Link className="hover:text-cyan-200" href={`/fleet/${owner.id}`}>{owner.name} · {owner.handle}</Link> : "—" },
                { k: "priority", v: `p${unit.priority}` },
                { k: "fan-out", v: `${unit.fanoutLimit} task boundaries` },
                { k: "idempotency", v: <span className="mono text-[10px]">{unit.idempotencyKey.slice(0, 30)}</span> },
                { k: "started", v: unit.startedAt ? `${timeAgo(unit.startedAt)}` : "queued" },
                { k: "completed", v: unit.completedAt ? timeAgo(unit.completedAt) : "—" },
                { k: "acceptance met", v: `${met}/${acceptance.length} · ${pct((met / Math.max(acceptance.length, 1)) * 100)}` },
              ]}
            />
            <div className="mt-3">
              <div className="mono flex justify-between text-[9.5px] text-zinc-500">
                <span>budget</span>
                <span>{usd(spent)} / {usd(unit.budgetUsd, 0)}</span>
              </div>
              <div className="mt-1"><Meter value={spent} max={num(unit.budgetUsd)} /></div>
            </div>
          </Panel>

          <Panel title="Execution replay" subtitle="What a resumed worker sees." bodyClass="p-4">
            <p className="text-[11px] leading-relaxed text-zinc-400">
              State is durable at three boundaries: the work unit graph in PostgreSQL, each session in hibernatable storage, and every side effect
              in an immutable receipt. A worker that disappears is replaced; a task whose lease expired returns to the ready queue. No transcript is
              replayed into the model — only the compact context package for the next task.
            </p>
            <div className="mono mt-2 grid grid-cols-2 gap-1.5 text-[9.5px] text-zinc-500">
              <span>queued · {unitTasks.filter((t) => t.status === "ready").length}</span>
              <span>blocked · {unitTasks.filter((t) => t.status === "blocked").length}</span>
              <span>leased · {unitTasks.filter((t) => t.status === "running").length}</span>
              <span>failed · {unitTasks.filter((t) => t.status === "failed").length}</span>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
