import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { AgentMark, Badge, Empty, Panel, Progress, Stat } from "@/components/ui";
import { WorkCreate } from "@/components/work-create";
import { getWorkUnits } from "@/lib/queries";
import { num, timeAgo, usd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function WorkPage() {
  const units = await getWorkUnits();
  const totalTasks = units.reduce((sum, u) => sum + u.tasks.length, 0);
  const running = units.filter((u) => ["running", "waiting_approval", "verifying"].includes(u.unit.status));
  const done = units.filter((u) => u.unit.status === "done");
  const spend = units.reduce((sum, u) => sum + num(u.unit.spentUsd), 0);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-4">
        <Stat label="work units" value={units.length} hint={`${totalTasks} admitted tasks`} />
        <Stat label="in flight" value={running.length} hint="durable graph orchestration" accent="text-cyan-200" />
        <Stat label="completed + verified" value={done.length} hint="acceptance criteria enforced" accent="text-emerald-200" />
        <Stat label="committed spend" value={usd(spend)} hint="per-task cost ledger" accent="text-violet-200" />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.7fr_1fr]">
        <Panel
          title="Work units"
          subtitle="Plan → fan-out → join → verify → commit."
          actions={<span className="mono text-[9.5px] uppercase tracking-[0.1em] text-zinc-600">{units.length} graphs</span>}
          bodyClass="p-0"
        >
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[11.5px]">
              <thead>
                <tr className="border-b border-white/[0.06] text-zinc-500">
                  <th className="mono px-4 py-1.5 text-[9.5px] font-normal uppercase tracking-[0.08em]">work unit</th>
                  <th className="mono px-2 py-1.5 text-[9.5px] font-normal uppercase tracking-[0.08em]">owner</th>
                  <th className="mono px-2 py-1.5 text-[9.5px] font-normal uppercase tracking-[0.08em]">state</th>
                  <th className="mono w-[136px] px-2 py-1.5 text-[9.5px] font-normal uppercase tracking-[0.08em]">progress</th>
                  <th className="mono px-2 py-1.5 text-[9.5px] font-normal uppercase tracking-[0.08em]">spend</th>
                  <th className="mono px-4 py-1.5 text-right text-[9.5px] font-normal uppercase tracking-[0.08em]">opened</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.04]">
                {units.map(({ unit, owner, tasks: unitTasks }) => {
                  const succeeded = unitTasks.filter((t) => t.status === "succeeded").length;
                  return (
                    <tr key={unit.id} className="row-hover">
                      <td className="px-4 py-2">
                        <Link href={`/work/${unit.id}`} className="group flex items-start gap-1.5">
                          <span className="min-w-0">
                            <span className="flex items-center gap-1.5 text-[12px] text-zinc-200 group-hover:text-cyan-200">
                              <span className="truncate">{unit.title}</span>
                              {unit.priority >= 4 && (
                                <span className="mono shrink-0 rounded border border-violet-400/30 bg-violet-400/10 px-1 text-[8.5px] uppercase text-violet-200">p{unit.priority}</span>
                              )}
                            </span>
                            <span className="mono mt-0.5 block truncate text-[9.5px] text-zinc-600">
                              {unit.template} · {unitTasks.length} tasks · fan-out {unit.fanoutLimit}
                            </span>
                          </span>
                          <ArrowUpRight size={11} className="mt-0.5 shrink-0 text-zinc-600 group-hover:text-cyan-300" />
                        </Link>
                      </td>
                      <td className="px-2 py-2">
                        {owner ? (
                          <span className="flex items-center gap-1.5">
                            <AgentMark glyph={owner.glyph} color={owner.color} size={20} />
                            <span className="mono hidden text-[10px] text-zinc-400 xl:inline">{owner.handle}</span>
                          </span>
                        ) : (
                          <span className="mono text-[10px] text-zinc-600">system</span>
                        )}
                      </td>
                      <td className="px-2 py-2"><Badge status={unit.status} /></td>
                      <td className="px-2 py-2"><Progress done={succeeded} total={unitTasks.length} tone={unit.status === "done" ? "bg-emerald-400" : "bg-cyan-400"} /></td>
                      <td className="mono tnum px-2 py-2 text-[10px] text-zinc-400">
                        {usd(unit.spentUsd, 3)}
                        <span className="text-zinc-600"> / {usd(unit.budgetUsd, 0)}</span>
                      </td>
                      <td className="mono px-4 py-2 text-right text-[9.5px] text-zinc-600">{timeAgo(unit.createdAt)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {!units.length && <div className="p-4"><Empty>No work units yet. Compile one on the right.</Empty></div>}
        </Panel>

        <div className="space-y-4">
          <Panel title="Plan a work unit" subtitle="A planner call, then bounded parallel execution.">
            <WorkCreate />
          </Panel>

          <Panel title="Execution contract" bodyClass="p-4">
            <ol className="space-y-2">
              {[
                "One strong planning call emits the structured graph.",
                "Independent tasks fan out immediately; dependent tasks stay blocked.",
                "Each task uses the least expensive capable tier.",
                "Results land as artifacts + receipts, never as full transcripts.",
                "A separate verifier reproduces the acceptance assertions.",
                "Consequential writes wait for a human authorization.",
                "Commit, compile memory, release every temporary resource.",
              ].map((step, i) => (
                <li key={step} className="flex gap-2 text-[11px] leading-relaxed text-zinc-400">
                  <span className="mono mt-[1px] shrink-0 text-[9px] text-cyan-300/70">{String(i + 1).padStart(2, "0")}</span>
                  <span>{step}</span>
                </li>
              ))}
            </ol>
          </Panel>

          <Panel title="Rules that never bend" bodyClass="p-4">
            <ul className="space-y-1.5 text-[11px] leading-relaxed text-zinc-400">
              <li>· No unbounded fan-out — the cap is a runtime setting.</li>
              <li>· No duplicate external action — receipts are idempotent.</li>
              <li>· No child task with more authority than its parent.</li>
              <li>· No deliverable accepted without its success criteria.</li>
              <li>· No process left running for an idle identity.</li>
            </ul>
          </Panel>
        </div>
      </div>
    </div>
  );
}
