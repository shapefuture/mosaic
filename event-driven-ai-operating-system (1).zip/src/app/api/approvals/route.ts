import { decideApprovalAction } from "@/app/actions";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: { id?: string; decision?: string };
  try {
    body = (await request.json()) as { id?: string; decision?: string };
  } catch {
    return Response.json({ ok: false, error: "invalid JSON body" }, { status: 400 });
  }
  if (!body.id || !body.decision || !["approved", "denied"].includes(body.decision)) {
    return Response.json({ ok: false, error: "id and decision (approved|denied) are required" }, { status: 400 });
  }
  await decideApprovalAction(body.id, body.decision as "approved" | "denied");
  return Response.json({ ok: true, id: body.id, decision: body.decision });
}
