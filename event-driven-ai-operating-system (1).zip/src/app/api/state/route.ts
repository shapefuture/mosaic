import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { agents, events, gauntletRounds, tasks, workUnits } from "@/db/schema";
import { getPolicy } from "@/lib/engine";
import { boot } from "@/lib/queries";
import { num } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function GET() {
  await boot();
  const policy = await getPolicy();
  const [taskRows, unitRows, agentRows, eventRows, roundRows] = await Promise.all([
    db.select().from(tasks),
    db.select().from(workUnits),
    db.select().from(agents),
    db.select().from(events).orderBy(desc(events.createdAt)).limit(10),
    db.select().from(gauntletRounds),
  ]);

  const running = taskRows.filter((t) => t.status === "running");
  const ready = taskRows.filter((t) => t.status === "ready");
  const lanes = (["interactive", "io", "compute", "browser"] as const).map((lane) => {
    const limit =
      lane === "compute"
        ? Math.min(policy.sandboxSlots, policy.compute)
        : lane === "browser"
          ? Math.min(policy.browserPool, policy.browser)
          : policy[lane];
    return {
      lane,
      limit,
      running: running.filter((t) => t.queue === lane).length,
      ready: ready.filter((t) => t.queue === lane).length,
    };
  });

  const hibernated = agentRows.filter((a) => a.status === "hibernating").length;
  const spend = unitRows.reduce((sum, u) => sum + num(u.spentUsd), 0);

  return Response.json({
    at: new Date().toISOString(),
    lanes,
    spend: Number(spend.toFixed(4)),
    ceiling: num(policy.budgetCeilingUsd),
    running: running.length,
    ready: ready.length,
    activeAgents: agentRows.filter((a) => a.status === "active").length,
    hibernatedAgents: hibernated,
    units: unitRows.map((u) => ({
      id: u.id,
      title: u.title,
      status: u.status,
      spent: num(u.spentUsd),
      tasks: taskRows.filter((t) => t.workUnitId === u.id).length,
      done: taskRows.filter((t) => t.workUnitId === u.id && t.status === "succeeded").length,
    })),
    runningTasks: running.map((t) => ({ id: t.id, title: t.title, queue: t.queue, tier: t.tier, agentId: t.agentId })),
    events: eventRows.map((e) => ({ id: e.id, kind: e.kind, message: e.message, at: e.createdAt, workUnitId: e.workUnitId })),
    gauntletWins: roundRows.filter((r) => r.criticVerdict === "ours").length,
    gauntletRounds: roundRows.length,
    taskCount: taskRows.length,
  });
}

export async function POST() {
  await boot();
  await db.execute(sql`select 1`);
  const [pending] = await db.select().from(workUnits).where(eq(workUnits.status, "waiting_approval")).limit(1);
  return Response.json({ ok: true, pendingApproval: pending?.id ?? null });
}
