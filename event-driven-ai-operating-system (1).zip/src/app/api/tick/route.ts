import { tickAction } from "@/app/actions";

export const dynamic = "force-dynamic";

export async function POST() {
  const result = await tickAction();
  return Response.json({ ok: true, ...result });
}
