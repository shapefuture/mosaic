import { eq } from "drizzle-orm";
import { db } from "@/db";
import { authorityEnvelopes } from "@/db/schema";
import { id, logEvent } from "@/lib/engine";
import { authorize, parseEnvelope, signEnvelope, verifySignature, type EnvelopeClaims } from "@/lib/authority";
import { boot } from "@/lib/queries";

export const dynamic = "force-dynamic";

type IssueBody = {
  mode: "issue";
  agentId: string;
  actions: string[];
  resources: string[];
  domains: string[];
  maxCost: number;
  delegationDepth: number;
  ttlMinutes: number;
  parentDepth?: number;
};

type VerifyBody = {
  mode: "verify";
  envelopeId: string;
  action: string;
  resource: string;
  domain?: string;
  cost: number;
  parentDepth?: number;
};

export async function POST(request: Request) {
  await boot();
  const body = (await request.json()) as IssueBody | VerifyBody;

  if (body.mode === "issue") {
    const claims: EnvelopeClaims = {
      agentId: body.agentId,
      workUnitId: null,
      sessionId: id("ses"),
      policyVersion: "v3.4",
      issuedAt: Date.now(),
      exp: Date.now() + body.ttlMinutes * 60_000,
      parentSignature: null,
      parentDepth: body.parentDepth ?? null,
      actions: body.actions,
      resources: body.resources,
      domains: body.domains,
      maxCost: body.maxCost,
      delegationDepth: body.delegationDepth,
      expiresAt: new Date(Date.now() + body.ttlMinutes * 60_000).toISOString(),
    };
    const signed = signEnvelope(claims);
    const [row] = await db
      .insert(authorityEnvelopes)
      .values({
        id: id("env"),
        agentId: body.agentId,
        token: signed.token,
        signature: signed.signature,
        payload: {
          actions: claims.actions,
          resources: claims.resources,
          domains: claims.domains,
          maxCost: claims.maxCost,
          delegationDepth: claims.delegationDepth,
          expiresAt: claims.expiresAt,
        },
        policyVersion: claims.policyVersion,
        expiresAt: new Date(claims.expiresAt),
      })
      .returning();
    await logEvent({
      kind: "authority.issued",
      message: `Scoped capability token issued to ${body.agentId} ($${body.maxCost.toFixed(2)} ceiling, depth ${body.delegationDepth})`,
      agentId: body.agentId,
      meta: { signature: signed.signature, ttlMinutes: body.ttlMinutes },
    });
    return Response.json({ ok: true, envelopeId: row.id, token: signed.token, signature: signed.signature, claims });
  }

  const [envelope] = await db.select().from(authorityEnvelopes).where(eq(authorityEnvelopes.id, body.envelopeId)).limit(1);
  if (!envelope) return Response.json({ ok: false, error: "envelope not found" }, { status: 404 });

  const claims = parseEnvelope(envelope.token);
  const signatureValid = verifySignature(envelope.token);
  const result = authorize(
    claims,
    signatureValid,
    {
      action: body.action,
      resource: body.resource,
      domain: body.domain,
      cost: body.cost,
      parentDepth: body.parentDepth,
    },
    envelope.revoked,
  );

  await logEvent({
    kind: result.decision === "allow" ? "authority.allowed" : "authority.denied",
    message: `${result.decision.toUpperCase()} ${body.action} on ${body.resource}${body.domain ? ` @ ${body.domain}` : ""} — ${result.reason}`,
    agentId: envelope.agentId,
    meta: { checks: result.checks, envelopeId: envelope.id },
  });

  return Response.json({ ok: true, ...result, envelope: { id: envelope.id, agentId: envelope.agentId, revoked: envelope.revoked, policyVersion: envelope.policyVersion } });
}
