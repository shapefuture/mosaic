import { createWorkUnit } from "@/lib/engine";
import { boot } from "@/lib/queries";
import { WORK_TEMPLATES } from "@/lib/templates";

export const dynamic = "force-dynamic";

/** Public ingress for planning a work unit. Idempotent on title + objective. */
export async function POST(request: Request) {
  await boot();
  let body: {
    title?: string;
    objective?: string;
    template?: string;
    ownerAgentId?: string;
    priority?: number;
    budgetUsd?: number;
  };
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "invalid JSON body" }, { status: 400 });
  }

  const template = body.template ?? "market_intel";
  if (!WORK_TEMPLATES[template]) {
    return Response.json({ ok: false, error: `unknown template; available: ${Object.keys(WORK_TEMPLATES).join(", ")}` }, { status: 400 });
  }
  if (!body.title || !body.objective) {
    return Response.json({ ok: false, error: "title and objective are required" }, { status: 400 });
  }

  const created = await createWorkUnit({
    title: body.title.slice(0, 160),
    objective: body.objective.slice(0, 600),
    template,
    ownerAgentId: body.ownerAgentId ?? "agt_mira",
    priority: body.priority ?? 3,
    budgetUsd: body.budgetUsd,
  });

  return Response.json(created, { status: created.ok ? 201 : 409 });
}
