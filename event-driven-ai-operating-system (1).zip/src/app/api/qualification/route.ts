import { runQualificationAction } from "@/app/actions";

export const dynamic = "force-dynamic";

const KINDS = ["idle_sessions", "io_flood", "failure_injection", "duplicate_event"];

export async function POST(request: Request) {
  let kind = "";
  try {
    const body = (await request.json()) as { kind?: string };
    kind = body.kind ?? "";
  } catch {
    return Response.json({ ok: false, error: "invalid JSON body" }, { status: 400 });
  }
  if (!KINDS.includes(kind)) {
    return Response.json({ ok: false, error: `kind must be one of ${KINDS.join(", ")}` }, { status: 400 });
  }
  const result = await runQualificationAction(kind);
  return Response.json(result);
}
