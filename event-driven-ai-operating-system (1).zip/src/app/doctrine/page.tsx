import Link from "next/link";
import { Badge, Empty, Kv, Meter, Panel, Stat } from "@/components/ui";
import { getDoctrine } from "@/lib/queries";
import { num, timeAgo } from "@/lib/format";

export const dynamic = "force-dynamic";

const LAYERS = [
  {
    n: "01",
    name: "Global ingress",
    parts: "Worker edge · static UI · WebSockets · channels",
    detail: "Requests terminate at stateless edge handlers. Nothing here holds agent state.",
    tone: "text-cyan-200 border-cyan-400/30",
  },
  {
    n: "02",
    name: "Durable sessions",
    parts: "Session actor · local SQLite · resume after eviction",
    detail: "One identity, many sessions. A session hibernates with transcript and pending tool calls intact.",
    tone: "text-sky-200 border-sky-400/30",
  },
  {
    n: "03",
    name: "Universal work engine",
    parts: "Work Units · task DAG · fan-out / join · human gates",
    detail: "The durable business process. It owns external side effects through idempotent receipts.",
    tone: "text-violet-200 border-violet-400/30",
  },
  {
    n: "04",
    name: "Elastic execution",
    parts: "Queue lanes · shared worker pool · 3 tiers",
    detail: "Bounded concurrency from the narrowest constraint. Tier 0 APIs by default; tier 2 only when isolation is required.",
    tone: "text-amber-200 border-amber-400/30",
  },
  {
    n: "05",
    name: "Managed state",
    parts: "PostgreSQL records · object storage · lexical/vector retrieval",
    detail: "One authoritative store, one artifact store, one retrieval path. No graph server, no vector cluster on day one.",
    tone: "text-emerald-200 border-emerald-400/30",
  },
  {
    n: "06",
    name: "Quality & governance",
    parts: "Cedar-style policy · receipts · gauntlet · evaluations",
    detail: "Independent verification, deterministic acceptance checks and a critic that must win blind.",
    tone: "text-rose-200 border-rose-400/30",
  },
];

const TRIZ = [
  ["Persistent agent vs minimal memory", "Separation in time", "Hibernating session actors"],
  ["Many agents vs few servers", "Taking out / universality", "Identity is a database row"],
  ["More parallelism vs limited memory", "Resource pooling", "Shared, stateless worker pool"],
  ["Isolation vs startup latency", "Prior action / copying", "Prepared snapshots, copy-on-write branches"],
  ["Large memory vs small context", "Segmentation / nesting", "Retrieve a compact context package"],
  ["Central security vs distributed work", "Intermediary", "Capability gateway with scoped tokens"],
  ["Faster execution vs safe retries", "Feedback / prior action", "Durable steps + idempotency keys"],
  ["Quality vs lower model cost", "Asymmetry", "Model routing by task difficulty"],
];

const EXCLUDED = [
  "A VM or process per agent",
  "Redis, Kafka, NATS at launch",
  "Neo4j / FalkorDB / Qdrant at launch",
  "Multiple workflow engines",
  "Multiple overlapping model gateways",
  "A vision model on every click",
  "Always-on Kubernetes",
  "Autonomous agent-to-agent chat loops",
];

export default async function DoctrinePage() {
  const { delivery, runs, unitRows, taskRows, roundRows } = await getDoctrine();
  const done = delivery.filter((d) => d.status === "done").length;
  const committed = taskRows.filter((t) => t.status === "succeeded").length;
  const verified = taskRows.filter((t) => t.status === "succeeded" && t.verifyStatus === "passed").length;
  const gauntletWon = roundRows.filter((r) => r.criticVerdict === "ours").length;

  return (
    <div className="space-y-4">
      <section className="panel relative overflow-hidden">
        <div className="grid-lines pointer-events-none absolute inset-0 opacity-30" />
        <div className="relative grid gap-5 p-5 lg:grid-cols-[1.4fr_1fr]">
          <div>
            <p className="mono text-[10px] uppercase tracking-[0.18em] text-cyan-300/80">doctrine · aos v3</p>
            <h2 className="mt-2 max-w-[30ch] text-[23px] font-medium leading-[1.15] tracking-tight text-zinc-50">
              The move is from persistent agent infrastructure to persistent agent identity.
            </h2>
            <p className="mt-2.5 max-w-[66ch] text-[12.5px] leading-relaxed text-zinc-400">
              An agent is a schedulable workload, not a permanently allocated computer. This control plane implements that separation: durable
              identity and knowledge in PostgreSQL, conversational state in a hibernatable session boundary, business process in a work graph, and
              ephemeral execution in a shared pool sized by the narrowest constraint.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link href="/work" className="btn btn-primary">See it execute</Link>
              <Link href="/scheduler" className="btn">Read the scheduler</Link>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="panel-flat p-2.5">
              <p className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-600">verified commitments</p>
              <p className="tnum mt-1 text-[20px] text-emerald-200">{verified}</p>
              <p className="mono text-[9px] text-zinc-600">of {committed} committed</p>
            </div>
            <div className="panel-flat p-2.5">
              <p className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-600">gauntlet wins</p>
              <p className="tnum mt-1 text-[20px] text-violet-200">{gauntletWon}</p>
              <p className="mono text-[9px] text-zinc-600">{roundRows.length} rounds judged blind</p>
            </div>
            <div className="panel-flat p-2.5">
              <p className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-600">work graphs</p>
              <p className="tnum mt-1 text-[20px] text-cyan-200">{unitRows.length}</p>
              <p className="mono text-[9px] text-zinc-600">durable, restartable</p>
            </div>
            <div className="panel-flat p-2.5">
              <p className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-600">qualification runs</p>
              <p className="tnum mt-1 text-[20px] text-amber-200">{runs.length}</p>
              <p className="mono text-[9px] text-zinc-600">gates recorded with evidence</p>
            </div>
          </div>
        </div>
      </section>

      <div className="grid gap-4 xl:grid-cols-[1.35fr_1fr]">
        <div className="space-y-4">
          <Panel title="Reference architecture" subtitle="Six layers, no redundant always-on services." bodyClass="p-0">
            <div className="divide-y divide-white/[0.05]">
              {LAYERS.map((layer) => (
                <div key={layer.n} className="flex items-start gap-3 px-4 py-2.5">
                  <span className={`mono grid h-7 w-7 shrink-0 place-items-center rounded border bg-white/[0.02] text-[10px] ${layer.tone}`}>{layer.n}</span>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-[12px] font-medium text-zinc-100">{layer.name}</p>
                      <span className="mono text-[9px] uppercase tracking-[0.06em] text-zinc-500">{layer.parts}</span>
                    </div>
                    <p className="mt-0.5 text-[11px] leading-relaxed text-zinc-500">{layer.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Three kinds of state, three homes" subtitle="The same fact is not reconstructed and stored in four places." bodyClass="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[11px]">
                <thead>
                  <tr className="border-b border-white/[0.06] text-zinc-500">
                    <th className="mono px-4 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">state</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">home</th>
                    <th className="mono px-4 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">why</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.04]">
                  {[
                    ["Identity, permissions, budgets", "PostgreSQL", "durable, queryable, shared"],
                    ["Conversation turn + tool calls", "session store (SQLite-equivalent)", "local, fast, hibernatable"],
                    ["Business process lifecycle", "work engine", "durable orchestration and recovery"],
                    ["Documents, screenshots, code", "object storage", "cheap, versioned, content-addressed"],
                    ["Searchable semantic content", "PostgreSQL lexical / vector", "one retrieval path before a second store"],
                  ].map(([state, home, why]) => (
                    <tr key={state} className="row-hover">
                      <td className="px-4 py-1.5 text-zinc-300">{state}</td>
                      <td className="mono px-2 py-1.5 text-[10px] text-cyan-200">{home}</td>
                      <td className="px-4 py-1.5 text-zinc-500">{why}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>

          <Panel title="Three execution tiers" subtitle="The highest-value optimisation is removing unnecessary execution." bodyClass="p-0">
            <div className="grid divide-y divide-white/[0.05] md:grid-cols-3 md:divide-x md:divide-y-0">
              {[
                { tier: "Tier 0", title: "No computer", body: "Typed APIs, HTTP fetch, SQL, deterministic transforms. The default for most business work.", usage: `${taskRows.filter((t) => t.tier === 0).length} tasks` },
                { tier: "Tier 1", title: "Lightweight", body: "Small container or sandbox for parsers, document transforms and test runs.", usage: `${taskRows.filter((t) => t.tier === 1).length} tasks` },
                { tier: "Tier 2", title: "Isolated", body: "MicroVM or remote browser context only for untrusted code, auth browsing or desktop work.", usage: `${taskRows.filter((t) => t.tier === 2).length} tasks` },
              ].map((item) => (
                <div key={item.tier} className="p-4">
                  <p className="mono text-[9.5px] uppercase tracking-[0.12em] text-zinc-500">{item.tier}</p>
                  <p className="mt-0.5 text-[12.5px] font-medium text-zinc-100">{item.title}</p>
                  <p className="mt-1 text-[11px] leading-relaxed text-zinc-500">{item.body}</p>
                  <p className="mono mt-2 text-[9.5px] text-cyan-300/80">{item.usage}</p>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Ideation record — TRIZ and far transfer" subtitle="The contradictions were removed structurally, not optimised incrementally." bodyClass="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[11px]">
                <thead>
                  <tr className="border-b border-white/[0.06] text-zinc-500">
                    <th className="mono px-4 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">contradiction</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">principle</th>
                    <th className="mono px-4 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">resolution</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.04]">
                  {TRIZ.map(([problem, principle, solution]) => (
                    <tr key={problem} className="row-hover">
                      <td className="px-4 py-1.5 text-zinc-400">{problem}</td>
                      <td className="mono px-2 py-1.5 text-[9.5px] uppercase tracking-[0.05em] text-violet-200/80">{principle}</td>
                      <td className="px-4 py-1.5 text-zinc-300">{solution}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>

        <div className="space-y-4">
          <Panel
            title="Delivery ledger"
            subtitle="Mission, acceptance and evidence — the state that survives interruption."
            actions={<span className="mono text-[10px] text-zinc-500">{done}/{delivery.length} done</span>}
            bodyClass="p-0"
          >
            <div className="border-b border-white/[0.06] px-4 py-2">
              <Meter value={done} max={Math.max(delivery.length, 1)} tone="bg-emerald-400" />
            </div>
            <div className="max-h-[420px] divide-y divide-white/[0.05] overflow-y-auto">
              {delivery.map((item) => (
                <div key={item.id} className="px-4 py-2">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="mono text-[9px] text-zinc-600">{item.code}</span>
                    <p className="text-[11.5px] text-zinc-200">{item.title}</p>
                    <span className="ml-auto"><Badge status={item.status} /></span>
                  </div>
                  <p className="mono mt-0.5 text-[9px] uppercase tracking-[0.05em] text-zinc-600">{item.stage}</p>
                  <p className="mt-1 text-[10.5px] leading-relaxed text-zinc-500">
                    <span className="text-zinc-400">acceptance · </span>{item.acceptance}
                  </p>
                  {item.evidence && (
                    <p className="mono mt-0.5 text-[9.5px] leading-relaxed text-emerald-300/70">evidence · {item.evidence}</p>
                  )}
                  {item.blocker && <p className="mono mt-0.5 text-[9.5px] leading-relaxed text-rose-300/70">blocker · {item.blocker}</p>}
                </div>
              ))}
              {!delivery.length && <div className="p-4"><Empty>No delivery tasks recorded.</Empty></div>}
            </div>
          </Panel>

          <Panel title="Skills applied" subtitle="How the requested working methods shaped this build." bodyClass="p-4">
            <div className="space-y-2.5">
              {[
                {
                  name: "gauntlet-loop",
                  how: "Quality bar named up front (a Stripe-grade explainer and a Gartner-grade brief), a separate blind critic, a named single gap each round, and no exit until ours wins. Implemented as the gauntlet panel with round-by-round artifacts.",
                },
                {
                  name: "full-plan-delivery",
                  how: "The delivery ledger above: bounded vertical slices, acceptance criteria, evidence strings, explicit blockers, and honest status. No task is marked complete on build success alone.",
                },
                {
                  name: "AAA-V7 architecture brief",
                  how: "Applied as doctrine: identity ≠ process, hibernating sessions, bounded fan-out, three execution tiers, scoped capability tokens and receipts. The linked spec file was unreachable from this sandbox, so the pasted brief is the authority.",
                },
              ].map((skill) => (
                <div key={skill.name} className="rounded-lg border border-white/[0.07] bg-white/[0.015] p-2.5">
                  <p className="mono text-[10px] uppercase tracking-[0.1em] text-cyan-300">{skill.name}</p>
                  <p className="mt-1 text-[10.5px] leading-relaxed text-zinc-400">{skill.how}</p>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Measure before scaling" bodyClass="p-0">
            <div className="divide-y divide-white/[0.05]">
              {[
                ["Memory per active turn", "efficiency of the runtime"],
                ["Memory per idle session", "did hibernation work"],
                ["Queue waiting time", "is the scheduler overloaded"],
                ["Browser memory per tab", "browser density"],
                ["Database writes per task", "persistence overhead"],
                ["Tokens per accepted result", "intelligence efficiency"],
                ["Cost per verified deliverable", "the only score that matters"],
              ].map(([metric, question]) => (
                <div key={metric} className="flex items-center gap-2 px-4 py-1.5">
                  <span className="text-[11px] text-zinc-300">{metric}</span>
                  <span className="mono ml-auto text-[9px] text-zinc-600">{question}</span>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Not built, on purpose" bodyClass="p-4">
            <div className="flex flex-wrap gap-1.5">
              {EXCLUDED.map((item) => (
                <span key={item} className="mono rounded border border-white/[0.08] bg-white/[0.02] px-1.5 py-0.5 text-[9.5px] text-zinc-500">{item}</span>
              ))}
            </div>
            <p className="mt-2 text-[10.5px] leading-relaxed text-zinc-500">
              The objective is not to eliminate useful components. It is to avoid paying for their memory and operational cost before they produce
              measurable value.
            </p>
          </Panel>

          <Panel title="Final verdict">
            <Kv
              items={[
                { k: "north star", v: "verified work per GB of active memory and per dollar" },
                { k: "default", v: "no computer at all" },
                { k: "guarantee", v: "durable work units, idempotent receipts, scoped authority" },
                { k: "honesty", v: "inference is simulated here; the orchestration is real" },
                { k: "runs", v: runs.length ? `${runs.length} qualification runs · latest ${timeAgo(runs[0]?.createdAt)}` : "no runs captured yet" },
                { k: "spend tracked", v: `${unitRows.reduce((sum, u) => sum + num(u.spentUsd), 0).toFixed(2)} USD across ${unitRows.length} units` },
              ]}
            />
          </Panel>
        </div>
      </div>
    </div>
  );
}
