export default function Loading() {
  return (
    <div className="space-y-4">
      <div className="panel h-[124px] animate-pulse bg-white/[0.02]" />
      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-3 xl:grid-cols-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="panel h-[86px] animate-pulse bg-white/[0.02]" />
        ))}
      </div>
      <div className="grid gap-4 xl:grid-cols-[1.7fr_1fr]">
        <div className="panel h-[320px] animate-pulse bg-white/[0.02]" />
        <div className="panel h-[320px] animate-pulse bg-white/[0.02]" />
      </div>
      <p className="mono text-center text-[9.5px] uppercase tracking-[0.16em] text-zinc-600">resuming from durable state…</p>
    </div>
  );
}
