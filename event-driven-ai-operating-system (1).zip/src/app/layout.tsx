import type { Metadata } from "next";
import type { ReactNode } from "react";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import { Shell } from "@/components/shell";
import { pendingApprovalCount } from "@/lib/queries";
import "./globals.css";

export const metadata: Metadata = {
  title: "AOS v3 — hibernating, massively parallel agent OS",
  description:
    "Control plane for durable agent identities, a bounded adaptive scheduler, a universal work engine and scoped capability authority.",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  let approvals = 0;
  try {
    approvals = await pendingApprovalCount();
  } catch {
    approvals = 0;
  }
  return (
    <html lang="en" className={`${GeistSans.variable} ${GeistMono.variable}`}>
      <body className="min-h-screen antialiased">
        <Shell pendingApprovals={approvals}>{children}</Shell>
      </body>
    </html>
  );
}
