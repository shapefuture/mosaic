import Link from "next/link";
import { Moon, Pause, Play, ShieldCheck } from "lucide-react";
import { agentPauseFormAction } from "@/app/actions";
import { AgentMark, Badge, Empty, Meter, Panel, Stat } from "@/components/ui";
import { getFleet } from "@/lib/queries";
import { num, pct, timeAgo, usd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function FleetPage({ searchParams }: { searchParams: Promise<{ dept?: string; status?: string }> }) {
  const params = await searchParams;
  const fleet = await getFleet();
  const departments = [...new Set(fleet.map((f) => f.agent.department))];
  const filtered = fleet.filter(
    (f) => (!params.dept || f.agent.department === params.dept) && (!params.status || f.agent.status === params.status),
  );
  const totalBudget = fleet.reduce((sum, f) => sum + num(f.agent.budgetUsd), 0);
  const totalSpend = fleet.reduce((sum, f) => sum + num(f.agent.spentUsd), 0);
  const asleep = fleet.filter((f) => f.agent.status === "hibernating").length;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-4">
        <Stat label="identities" value={fleet.length} hint="database rows, not services" />
        <Stat label="hibernated" value={asleep} hint="zero resident compute" accent="text-violet-200" />
        <Stat label="durable sessions" value={fleet.reduce((s, f) => s + f.sessions.length, 0)} hint="DO SQLite equivalent" />
        <Stat label="fleet spend" value={usd(totalSpend)} hint={`of ${usd(totalBudget, 0)} allocated`} accent="text-cyan-200" />
      </div>

      <Panel
        title="Agent registry"
        subtitle="An agent is an identity, a role, a capability set and persistent knowledge."
        actions={
          <div className="flex flex-wrap items-center gap-1">
            <Link href="/fleet" className={`mono rounded border px-1.5 py-0.5 text-[10px] uppercase tracking-[0.06em] ${!params.dept && !params.status ? "border-cyan-400/40 bg-cyan-400/10 text-cyan-200" : "border-white/10 text-zinc-500"}`}>
              all
            </Link>
            {departments.map((dept) => (
              <Link
                key={dept}
                href={`/fleet?dept=${encodeURIComponent(dept)}`}
                className={`mono rounded border px-1.5 py-0.5 text-[10px] uppercase tracking-[0.06em] ${params.dept === dept ? "border-cyan-400/40 bg-cyan-400/10 text-cyan-200" : "border-white/10 text-zinc-500 hover:text-zinc-300"}`}
              >
                {dept}
              </Link>
            ))}
            {["active", "hibernating", "paused"].map((status) => (
              <Link
                key={status}
                href={`/fleet?status=${status}`}
                className={`mono rounded border px-1.5 py-0.5 text-[10px] uppercase tracking-[0.06em] ${params.status === status ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-200" : "border-white/10 text-zinc-500 hover:text-zinc-300"}`}
              >
                {status}
              </Link>
            ))}
          </div>
        }
        bodyClass="p-3"
      >
        <div className="grid gap-2.5 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map(({ agent, skills: agentSkills, sessions: agentSessions, activeTasks, completed, receipts }) => {
            const spend = num(agent.spentUsd);
            const budget = num(agent.budgetUsd);
            return (
              <div key={agent.id} className="panel-flat flex flex-col p-3">
                <div className="flex items-start gap-2.5">
                  <AgentMark glyph={agent.glyph} color={agent.color} size={30} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <Link href={`/fleet/${agent.id}`} className="truncate text-[13px] font-medium text-zinc-100 hover:text-cyan-200">
                        {agent.name}
                      </Link>
                      <Badge status={agent.status} />
                    </div>
                    <p className="mono truncate text-[10px] text-zinc-500">
                      {agent.handle} · {agent.role}
                    </p>
                  </div>
                </div>

                <div className="mt-2.5 flex flex-wrap gap-1">
                  {agent.capabilities.slice(0, 4).map((cap) => (
                    <span key={cap} className="mono rounded border border-white/10 bg-white/[0.03] px-1.5 py-0.5 text-[9.5px] text-zinc-400">
                      {cap}
                    </span>
                  ))}
                  {agent.capabilities.length > 4 && (
                    <span className="mono rounded border border-white/10 px-1.5 py-0.5 text-[9.5px] text-zinc-500">+{agent.capabilities.length - 4}</span>
                  )}
                </div>

                <div className="mt-2.5 grid grid-cols-3 gap-1.5 text-center">
                  <div className="rounded border border-white/[0.06] bg-white/[0.015] py-1">
                    <p className="mono text-[8.5px] uppercase tracking-[0.08em] text-zinc-600">asleep</p>
                    <p className="tnum text-[11px] text-zinc-300">{agentSessions.filter((s) => s.state === "hibernating").length}</p>
                  </div>
                  <div className="rounded border border-white/[0.06] bg-white/[0.015] py-1">
                    <p className="mono text-[8.5px] uppercase tracking-[0.08em] text-zinc-600">live tasks</p>
                    <p className="tnum text-[11px] text-zinc-300">{activeTasks.length}</p>
                  </div>
                  <div className="rounded border border-white/[0.06] bg-white/[0.015] py-1">
                    <p className="mono text-[8.5px] uppercase tracking-[0.08em] text-zinc-600">receipts</p>
                    <p className="tnum text-[11px] text-zinc-300">{receipts}</p>
                  </div>
                </div>

                <div className="mt-2.5">
                  <div className="mono flex justify-between text-[9.5px] text-zinc-500">
                    <span>budget</span>
                    <span className="tnum">
                      {usd(spend)} / {usd(budget, 0)} · {pct((spend / Math.max(budget, 1)) * 100)}
                    </span>
                  </div>
                  <div className="mt-1">
                    <Meter value={spend} max={budget} tone={spend / Math.max(budget, 1) > 0.85 ? "bg-rose-400" : "bg-cyan-400"} />
                  </div>
                </div>

                <div className="mt-2.5 flex items-center gap-1.5 border-t border-white/[0.06] pt-2">
                  <span className="mono text-[9px] uppercase tracking-[0.08em] text-zinc-600">
                    {agentSkills.length} skills · {completed} done
                  </span>
                  <div className="ml-auto flex items-center gap-1">
                    <form action={agentPauseFormAction}>
                      <input type="hidden" name="agentId" value={agent.id} />
                      <button type="submit" className="btn px-1.5 py-1" title={agent.status === "paused" ? "Resume identity" : "Pause execution"}>
                        {agent.status === "paused" ? <Play size={11} /> : <Pause size={11} />}
                      </button>
                    </form>
                    <Link href={`/fleet/${agent.id}`} className="btn px-1.5 py-1">
                      <ShieldCheck size={11} /> inspect
                    </Link>
                  </div>
                </div>
                <p className="mono mt-1.5 text-[9px] text-zinc-600">last active {timeAgo(agent.lastActiveAt)}</p>
              </div>
            );
          })}
          {!filtered.length && (
            <div className="md:col-span-2 xl:col-span-3">
              <Empty>No identities match this filter.</Empty>
            </div>
          )}
        </div>
      </Panel>

      <Panel title="Why this scales" subtitle="The cost of an idle identity is a row, not a machine." bodyClass="p-4">
        <div className="grid gap-3 md:grid-cols-3">
          {[
            { t: "Identity ≠ process", d: "Roles, capabilities and model policy live in PostgreSQL. Nothing is scheduled until a Work Unit assigns a task." },
            { t: "Session ≠ agent", d: "One identity can hold many concurrent sessions. Each session is an independently hibernatable actor with its own isolated context." },
            { t: "Computer ≠ agent", d: "Tier 0 handles most tasks with APIs. Tier 1 containers and tier 2 microVMs appear only for the work that needs them." },
          ].map((item) => (
            <div key={item.t} className="rounded-lg border border-white/[0.06] bg-white/[0.015] p-3">
              <p className="flex items-center gap-1.5 text-[12px] font-medium text-zinc-200">
                <Moon size={12} className="text-violet-300" /> {item.t}
              </p>
              <p className="mt-1 text-[11px] leading-relaxed text-zinc-500">{item.d}</p>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}
