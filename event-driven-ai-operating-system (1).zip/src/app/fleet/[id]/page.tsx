import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Moon, Pause, Play, Sun } from "lucide-react";
import { agentPauseFormAction, sessionStateFormAction } from "@/app/actions";
import { AgentMark, Badge, Empty, Kv, Meter, Panel, Stat, TierChip } from "@/components/ui";
import { getAgent } from "@/lib/queries";
import { clock, num, pct, timeAgo, usd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function AgentPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const data = await getAgent(id);
  if (!data) notFound();
  const { agent, skills: agentSkills, sessions: agentSessions, tasks: agentTasks, receipts: agentReceipts, memories: agentMemories } = data;
  const spend = num(agent.spentUsd);
  const budget = num(agent.budgetUsd);
  const liveSessions = agentSessions.filter((s) => s.state === "active");

  return (
    <div className="space-y-4">
      <Link href="/fleet" className="mono inline-flex items-center gap-1 text-[10px] uppercase tracking-[0.1em] text-zinc-500 hover:text-zinc-300">
        <ArrowLeft size={11} /> agent registry
      </Link>

      <Panel bodyClass="p-4">
        <div className="flex flex-wrap items-start gap-3">
          <AgentMark glyph={agent.glyph} color={agent.color} size={44} />
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-[17px] font-medium tracking-tight text-zinc-50">{agent.name}</h2>
              <Badge status={agent.status} />
              <span className="mono rounded border border-white/10 px-1.5 py-0.5 text-[9.5px] text-zinc-500">{agent.profileVersion}</span>
            </div>
            <p className="mono mt-0.5 text-[11px] text-zinc-500">
              {agent.handle} · {agent.role} · {agent.department}
            </p>
            <p className="mt-1.5 max-w-[70ch] text-[11.5px] leading-relaxed text-zinc-400">
              A durable identity with no resident process. Capabilities are gated by signed envelopes; knowledge is retrieved per turn from
              scoped records. {liveSessions.length} session{liveSessions.length === 1 ? "" : "s"} awake,{" "}
              {agentSessions.filter((s) => s.state === "hibernating").length} hibernated.
            </p>
          </div>
          <div className="ml-auto flex items-center gap-1.5">
            <form action={agentPauseFormAction}>
              <input type="hidden" name="agentId" value={agent.id} />
              <button type="submit" className="btn">
                {agent.status === "paused" ? <Play size={12} /> : <Pause size={12} />}
                {agent.status === "paused" ? "Resume identity" : "Pause execution"}
              </button>
            </form>
          </div>
        </div>
      </Panel>

      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-4">
        <Stat label="budget used" value={usd(spend)} hint={`${pct((spend / Math.max(budget, 1)) * 100)} of ${usd(budget, 0)}`} accent="text-cyan-200" />
        <Stat label="skills" value={agentSkills.length} hint={`${agentSkills.filter((s) => s.status === "active").length} active versions`} />
        <Stat label="committed tasks" value={agentTasks.filter((t) => t.status === "succeeded").length} hint="with receipts" accent="text-emerald-200" />
        <Stat label="curated memories" value={agentMemories.filter((m) => m.trust === "curated").length} hint={`${agentMemories.length} records in scope`} accent="text-violet-200" />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.15fr_1fr]">
        <div className="space-y-4">
          <Panel title="Durable sessions" subtitle="Each session is an independently hibernatable actor." bodyClass="p-0">
            <div className="divide-y divide-white/[0.05]">
              {agentSessions.map((session) => (
                <div key={session.id} className="flex flex-wrap items-center gap-2 px-4 py-2.5">
                  <span className={`grid h-6 w-6 place-items-center rounded border ${session.state === "active" ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300" : "border-white/10 bg-white/[0.02] text-zinc-500"}`}>
                    {session.state === "active" ? <Sun size={11} /> : <Moon size={11} />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[11.5px] text-zinc-200">{session.title}</p>
                    <p className="mono text-[9.5px] text-zinc-500">
                      {session.storage} · context {session.contextKb} KB · resident {session.residentKb} KB · {session.pendingToolCalls} pending tool call
                      {session.pendingToolCalls === 1 ? "" : "s"}
                    </p>
                  </div>
                  <Badge status={session.state} />
                  <form action={sessionStateFormAction}>
                    <input type="hidden" name="sessionId" value={session.id} />
                    <input type="hidden" name="state" value={session.state === "active" ? "hibernating" : "active"} />
                    <button type="submit" className="btn px-2 py-1">
                      {session.state === "active" ? "Hibernate" : "Resume"}
                    </button>
                  </form>
                </div>
              ))}
              {!agentSessions.length && <div className="p-4"><Empty>No sessions. The identity costs one row.</Empty></div>}
            </div>
          </Panel>

          <Panel title="Task history" subtitle="Every task ran in the shared pool, not in an agent process." bodyClass="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[11.5px]">
                <thead>
                  <tr className="border-b border-white/[0.06] text-zinc-500">
                    <th className="mono px-4 py-1.5 text-[9.5px] font-normal uppercase tracking-[0.08em]">task</th>
                    <th className="mono px-2 py-1.5 text-[9.5px] font-normal uppercase tracking-[0.08em]">lane</th>
                    <th className="mono px-2 py-1.5 text-[9.5px] font-normal uppercase tracking-[0.08em]">state</th>
                    <th className="mono px-2 py-1.5 text-[9.5px] font-normal uppercase tracking-[0.08em]">cost</th>
                    <th className="mono px-4 py-1.5 text-right text-[9.5px] font-normal uppercase tracking-[0.08em]">when</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.04]">
                  {agentTasks.map((task) => (
                    <tr key={task.id} className="row-hover">
                      <td className="px-4 py-1.5">
                        <Link href={`/work/${task.workUnitId}`} className="text-zinc-300 hover:text-cyan-200">
                          {task.title}
                        </Link>
                      </td>
                      <td className="mono px-2 py-1.5 text-[10px] text-zinc-500">{task.queue}</td>
                      <td className="px-2 py-1.5"><Badge status={task.status} /></td>
                      <td className="mono tnum px-2 py-1.5 text-[10px] text-zinc-400">{usd(num(task.costActual), 3)}</td>
                      <td className="mono px-4 py-1.5 text-right text-[9.5px] text-zinc-600">{timeAgo(task.completedAt ?? task.startedAt)}</td>
                    </tr>
                  ))}
                  {!agentTasks.length && (
                    <tr><td colSpan={5} className="px-4 py-6 text-center text-zinc-500">No tasks yet.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>

        <div className="space-y-4">
          <Panel title="Authority profile">
            <Kv
              items={[
                { k: "actions", v: <span className="mono text-[10px] text-cyan-200">{agent.authority.actions.join(", ")}</span> },
                { k: "resources", v: <span className="mono text-[10px]">{agent.authority.resources.join(", ")}</span> },
                { k: "domains", v: <span className="mono text-[10px]">{agent.authority.domains.length ? agent.authority.domains.join(", ") : "none (no egress)"}</span> },
                { k: "max cost", v: usd(agent.authority.maxCost) },
                { k: "delegation", v: `${agent.authority.delegationDepth} level${agent.authority.delegationDepth === 1 ? "" : "s"}` },
                { k: "memory scope", v: <span className="mono text-[10px]">{agent.memoryScope}</span> },
                { k: "models", v: <span className="mono text-[10px]">{agent.modelPolicy.planner} · {agent.modelPolicy.worker} · {agent.modelPolicy.verifier}</span> },
              ]}
            />
            <div className="mt-3">
              <div className="mono flex justify-between text-[9.5px] text-zinc-500">
                <span>budget</span>
                <span>{usd(spend)} / {usd(budget, 0)}</span>
              </div>
              <div className="mt-1"><Meter value={spend} max={budget} /></div>
            </div>
          </Panel>

          <Panel title="Versioned skills" subtitle="Procedural memory, loaded on demand." bodyClass="p-0">
            <div className="divide-y divide-white/[0.05]">
              {agentSkills.map((skill) => (
                <div key={skill.id} className="flex items-center gap-2 px-4 py-2">
                  <div className="min-w-0 flex-1">
                    <p className="mono truncate text-[11px] text-zinc-200">{skill.name}</p>
                    <p className="mono text-[9.5px] text-zinc-600">
                      {skill.version} · {skill.evaluations} evaluations · {skill.successRate}% success
                    </p>
                  </div>
                  <Badge status={skill.status} />
                </div>
              ))}
              {!agentSkills.length && <div className="p-4"><Empty>No skills promoted yet.</Empty></div>}
            </div>
          </Panel>

          <Panel title="Scoped memory" subtitle="Retrieved per turn; never a resident profile." bodyClass="p-0">
            <div className="max-h-[280px] divide-y divide-white/[0.05] overflow-y-auto">
              {agentMemories.map((memory) => (
                <div key={memory.id} className="px-4 py-2">
                  <div className="flex items-center gap-1.5">
                    <Badge status={memory.trust} />
                    <span className="mono text-[9px] uppercase tracking-[0.08em] text-zinc-600">{memory.kind}</span>
                    <span className="mono ml-auto text-[9px] text-zinc-600">{memory.confidence}%</span>
                  </div>
                  <p className="mt-1 text-[11px] leading-relaxed text-zinc-400">{memory.content}</p>
                </div>
              ))}
              {!agentMemories.length && <div className="p-4"><Empty>No memories in scope.</Empty></div>}
            </div>
          </Panel>

          <Panel title="Recent receipts" bodyClass="p-0">
            <div className="divide-y divide-white/[0.05]">
              {agentReceipts.map((receipt) => (
                <div key={receipt.id} className="flex items-center gap-2 px-4 py-1.5">
                  <TierChip tier={receipt.tier} />
                  <span className="mono truncate text-[10px] text-zinc-400">{receipt.action}</span>
                  <Badge status={receipt.outcome} />
                  <span className="mono ml-auto text-[9px] text-zinc-600">{clock(receipt.createdAt)}</span>
                </div>
              ))}
              {!agentReceipts.length && <div className="p-4"><Empty>No side effects committed.</Empty></div>}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
