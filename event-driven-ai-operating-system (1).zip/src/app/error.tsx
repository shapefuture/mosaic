"use client";

import { useEffect } from "react";
import { RotateCcw, TriangleAlert } from "lucide-react";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    // Keep the failure visible without leaking internals into the UI.
    console.error("aos.control-plane.error", error.message);
  }, [error]);

  return (
    <div className="panel mx-auto max-w-xl p-6">
      <div className="flex items-center gap-2 text-rose-300">
        <TriangleAlert size={16} />
        <h2 className="text-[14px] font-medium text-zinc-100">The control plane hit an error</h2>
      </div>
      <p className="mt-2 text-[12px] leading-relaxed text-zinc-400">
        Durable state is safe: identities, work graphs and receipts live in PostgreSQL. Resuming re-reads the ledger rather than replaying a
        transcript.
      </p>
      <p className="mono mt-2 rounded border border-white/[0.07] bg-black/40 p-2 text-[10px] text-zinc-500">{error.message}</p>
      <button type="button" onClick={reset} className="btn btn-primary mt-3">
        <RotateCcw size={12} /> Resume from durable state
      </button>
    </div>
  );
}
