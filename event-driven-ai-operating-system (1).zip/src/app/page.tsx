import Link from "next/link";
import { and, desc, eq } from "drizzle-orm";
import { ArrowRight, Boxes, CheckCircle2, Cpu, Moon, ShieldCheck, Zap } from "lucide-react";
import { db } from "@/db";
import { approvals } from "@/db/schema";
import { decideApprovalFormAction } from "@/app/actions";
import { AgentMark, Badge, Empty, Kv, Meter, Panel, Progress, Sparkline, Stat } from "@/components/ui";
import { LiveConsole } from "@/components/live-console";
import { getFleet, getOverview } from "@/lib/queries";
import { num, pct, timeAgo, usd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const [overview, fleet, pending] = await Promise.all([
    getOverview(),
    getFleet(),
    db.select().from(approvals).where(eq(approvals.status, "pending")).orderBy(desc(approvals.requestedAt)).limit(3),
  ]);

  const { stats } = overview;
  const activeUnits = overview.units.filter((u) => ["running", "waiting_approval", "verifying"].includes(u.status)).slice(0, 4);
  const queueTotal = Object.values(stats.queueDepth).reduce((a, b) => a + b, 0);
  const residentMb = stats.residentComputeMb + stats.residentKb / 1024;
  const throughput = overview.metrics.slice(-18).map((m) => m.committed);

  return (
    <div className="space-y-4">
      <section className="panel relative overflow-hidden">
        <div className="grid-lines pointer-events-none absolute inset-0 opacity-[0.35]" />
        <div className="relative grid gap-5 p-5 lg:grid-cols-[1.5fr_1fr] lg:p-6">
          <div>
            <p className="mono text-[10px] uppercase tracking-[0.18em] text-cyan-300/80">aos v3 · hibernating execution</p>
            <h2 className="mt-2 max-w-[24ch] text-[26px] font-medium leading-[1.12] tracking-tight text-zinc-50">
              Millions of identities. Thousands of concurrent tasks. A tiny always-on footprint.
            </h2>
            <p className="mt-2.5 max-w-[62ch] text-[12.5px] leading-relaxed text-zinc-400">
              An agent is an identity, a role and scoped knowledge — never a process. Work wakes a shared pool, commits a receipt and goes back
              to sleep. The scheduler shrinks concurrency from the narrowest live constraint.
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <Link href="/work" className="btn btn-primary">
                Plan a work unit <ArrowRight size={12} />
              </Link>
              <Link href="/scheduler" className="btn">
                <Cpu size={12} /> Scheduler & capacity
              </Link>
              <Link href="/security" className="btn">
                <ShieldCheck size={12} /> Authority envelopes
              </Link>
            </div>
          </div>
          <div className="space-y-2.5">
            <div className="panel-flat px-3 py-2.5">
              <div className="flex items-center justify-between">
                <span className="mono text-[9.5px] uppercase tracking-[0.14em] text-zinc-500">active footprint</span>
                <span className="mono tnum text-[11px] text-cyan-300">{residentMb < 1 ? "storage only" : `${residentMb.toFixed(0)} MB`}</span>
              </div>
              <div className="mt-2 grid grid-cols-2 gap-2 text-[10.5px]">
                <div>
                  <p className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-600">awake</p>
                  <p className="tnum text-zinc-200">{stats.activeAgents} identities</p>
                </div>
                <div>
                  <p className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-600">asleep</p>
                  <p className="tnum text-zinc-200">{stats.hibernatedSessions} sessions</p>
                </div>
                <div>
                  <p className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-600">durable state</p>
                  <p className="tnum text-zinc-200">{(stats.storedKb / 1024).toFixed(1)} MB</p>
                </div>
                <div>
                  <p className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-600">resident</p>
                  <p className="tnum text-zinc-200">{stats.residentKb} KB</p>
                </div>
              </div>
            </div>
            <div className="panel-flat px-3 py-2.5">
              <div className="flex items-center justify-between text-[10.5px]">
                <span className="mono text-[9.5px] uppercase tracking-[0.14em] text-zinc-500">tenant budget</span>
                <span className="mono tnum text-zinc-300">
                  {usd(stats.spend)} / {usd(stats.budget, 0)}
                </span>
              </div>
              <div className="mt-2">
                <Meter value={stats.spend} max={stats.budget} tone={stats.budgetPct > 85 ? "bg-rose-400" : "bg-cyan-400"} />
              </div>
              <p className="mono mt-1.5 text-[9.5px] text-zinc-600">{pct(100 - stats.budgetPct)} headroom · deterministic ceiling</p>
            </div>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-3 xl:grid-cols-6">
        <Stat label="active turns" value={stats.running} hint={`${queueTotal} queued tasks`} icon={<Zap size={13} />} accent="text-cyan-200" />
        <Stat label="hibernated" value={stats.hibernatedSessions} hint={`${stats.sessionCount} durable sessions`} icon={<Moon size={13} />} accent="text-violet-200" />
        <Stat label="verified work" value={stats.verified} hint={`${stats.committed} committed tasks`} icon={<CheckCircle2 size={13} />} accent="text-emerald-200" />
        <Stat label="recent receipts" value={overview.receipts.length} hint="durable action ledger" icon={<Boxes size={13} />} accent="text-zinc-100" />
        <Stat label="gauntlet" value={`${stats.gauntletWins}/${stats.gauntletRounds}`} hint="rounds won blind vs bar" icon={<Zap size={13} />} accent="text-amber-200" />
        <Stat label="curated memory" value={stats.curatedMemories} hint={`${stats.proposedMemories} candidates pending`} icon={<Cpu size={13} />} accent="text-sky-200" />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.7fr_1fr]">
        <div className="space-y-4">
          <LiveConsole />

          <Panel
            title="Work in flight"
            subtitle="A plan compiles to a DAG; only the frontier executes."
            actions={
              <Link href="/work" className="mono text-[10px] uppercase tracking-[0.1em] text-cyan-300 hover:text-cyan-200">
                all work units →
              </Link>
            }
            bodyClass=""
          >
            <div className="divide-y divide-white/[0.05]">
              {activeUnits.map((unit) => {
                const owner = fleet.find((f) => f.agent.id === unit.ownerAgentId)?.agent;
                const done = overview.tasks.filter((t) => t.workUnitId === unit.id && t.status === "succeeded").length;
                const total = overview.tasks.filter((t) => t.workUnitId === unit.id).length;
                return (
                  <Link key={unit.id} href={`/work/${unit.id}`} className="row-hover block px-4 py-2.5 transition">
                    <div className="flex items-start gap-2.5">
                      <AgentMark glyph={owner?.glyph ?? "◆"} color={owner?.color ?? "#67e8f9"} size={24} />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <p className="truncate text-[12.5px] text-zinc-200">{unit.title}</p>
                          <Badge status={unit.status} />
                          <span className="mono tnum ml-auto shrink-0 text-[10px] text-zinc-500">{usd(unit.spentUsd)}</span>
                        </div>
                        <p className="mt-0.5 truncate text-[11px] text-zinc-500">{unit.objective}</p>
                        <div className="mt-1.5 max-w-[340px]">
                          <Progress done={done} total={total} tone={unit.status === "waiting_approval" ? "bg-amber-400" : "bg-emerald-400"} />
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
              {!activeUnits.length && <div className="p-4"><Empty>No work in flight. Plan a work unit to wake the pool.</Empty></div>}
            </div>
          </Panel>
        </div>

        <div className="space-y-4">
          <Panel
            title="Human authorization"
            subtitle="Consequential writes stop here."
            actions={<Badge tone="text-amber-300 border-amber-400/30 bg-amber-400/10">{pending.length} pending</Badge>}
            bodyClass="p-0"
          >
            {pending.map((approval) => (
              <div key={approval.id} className="border-b border-white/[0.05] px-4 py-3 last:border-b-0">
                <div className="flex items-center gap-2">
                  <Badge tone="text-rose-300 border-rose-400/30 bg-rose-400/10">{approval.risk} risk</Badge>
                  <span className="mono text-[9.5px] uppercase tracking-[0.08em] text-zinc-500">{approval.action}</span>
                  <span className="mono ml-auto text-[9.5px] text-zinc-600">{timeAgo(approval.requestedAt)}</span>
                </div>
                <p className="mt-1.5 text-[11.5px] leading-relaxed text-zinc-300">{approval.reason}</p>
                <p className="mono mt-1 text-[9.5px] text-zinc-500">scope {approval.resource} · max {usd(approval.costUsd, 3)}</p>
                <div className="mt-2 flex gap-1.5">
                  <form action={decideApprovalFormAction}>
                    <input type="hidden" name="approvalId" value={approval.id} />
                    <input type="hidden" name="decision" value="approved" />
                    <button className="btn btn-primary" type="submit">
                      Authorize
                    </button>
                  </form>
                  <form action={decideApprovalFormAction}>
                    <input type="hidden" name="approvalId" value={approval.id} />
                    <input type="hidden" name="decision" value="denied" />
                    <button className="btn btn-danger" type="submit">
                      Deny
                    </button>
                  </form>
                </div>
              </div>
            ))}
            {!pending.length && <div className="p-4"><Empty>No authorizations waiting. The capability boundary is holding.</Empty></div>}
          </Panel>

          <Panel title="Fleet state" subtitle="Identity residency, not process residency." bodyClass="p-0">
            <div className="max-h-[268px] divide-y divide-white/[0.05] overflow-y-auto">
              {fleet.map(({ agent, sessions: agentSessions, activeTasks }) => (
                <Link key={agent.id} href={`/fleet/${agent.id}`} className="row-hover flex items-center gap-2.5 px-4 py-2 transition">
                  <AgentMark glyph={agent.glyph} color={agent.color} size={22} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[11.5px] text-zinc-200">{agent.name}</p>
                    <p className="mono truncate text-[9.5px] text-zinc-500">{agent.role}</p>
                  </div>
                  <div className="text-right">
                    <Badge status={agent.status} />
                    <p className="mono mt-0.5 text-[9px] text-zinc-600">
                      {agentSessions.filter((s) => s.state === "hibernating").length} asleep
                      {activeTasks.length ? ` · ${activeTasks.length} live` : ""}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </Panel>

          <Panel title="Throughput" subtitle="Committed tasks per scheduler tick.">
            <Sparkline data={throughput.length ? throughput : [0, 1, 0, 2, 1, 3]} height={48} />
            <div className="mt-2 grid grid-cols-2 gap-2 text-[10.5px]">
              <div>
                <p className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-600">cost / verified task</p>
                <p className="tnum text-zinc-200">{stats.committed ? usd(stats.spend / Math.max(stats.committed, 1), 3) : "—"}</p>
              </div>
              <div>
                <p className="mono text-[9px] uppercase tracking-[0.1em] text-zinc-600">failure rate</p>
                <p className="tnum text-zinc-200">{stats.committed + stats.failed ? pct((stats.failed / (stats.committed + stats.failed)) * 100) : "0%"}</p>
              </div>
            </div>
          </Panel>

          <Panel title="Latest receipts" bodyClass="p-0">
            <div className="divide-y divide-white/[0.05]">
              {overview.receipts.slice(0, 5).map((r) => (
                <div key={r.id} className="flex items-center gap-2 px-4 py-1.5">
                  <span className={`h-1 w-1 rounded-full ${r.outcome === "committed" ? "bg-emerald-400" : "bg-cyan-400"}`} />
                  <span className="mono truncate text-[10px] text-zinc-400">{r.action}</span>
                  <Badge status={r.outcome} />
                  <span className="mono tnum ml-auto text-[9.5px] text-zinc-600">{usd(num(r.costUsd), 3)}</span>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Narrowest constraint" bodyClass="p-4">
            <Kv
              items={[
                { k: "provider", v: `${overview.policy.providerConcurrency} concurrent calls` },
                { k: "tenant", v: `${overview.policy.tenantConcurrency} slots` },
                { k: "browser", v: `${overview.policy.browserPool} processes` },
                { k: "sandbox", v: `${overview.policy.sandboxSlots} microVMs` },
                { k: "fan-out", v: `${overview.policy.maxFanout} task boundaries` },
                { k: "formula", v: <span className="mono text-[10px] text-cyan-300">min(provider, tenant, queue, sandbox, budget)</span> },
              ]}
            />
            <Link href="/scheduler" className="btn mt-3 w-full justify-center">
              Tune the scheduler <ArrowRight size={11} />
            </Link>
          </Panel>
        </div>
      </div>
    </div>
  );
}
