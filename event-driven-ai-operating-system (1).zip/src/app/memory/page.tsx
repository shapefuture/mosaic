import Link from "next/link";
import { Check, Search, X } from "lucide-react";
import { memoryDecisionFormAction } from "@/app/actions";
import { Badge, Empty, Panel, Stat } from "@/components/ui";
import { getMemory } from "@/lib/queries";
import { timeAgo } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function MemoryPage({ searchParams }: { searchParams: Promise<{ q?: string; trust?: string }> }) {
  const params = await searchParams;
  const data = await getMemory(params.q);
  const trustFilter = params.trust ?? "";
  const memories = trustFilter ? data.memories.filter((m) => m.trust === trustFilter) : data.memories;
  const candidates = memories.filter((m) => m.trust === "proposed");
  const curated = memories.filter((m) => m.trust === "curated");
  const rejected = memories.filter((m) => m.trust === "rejected");
  const agentById = new Map(data.agents.map((a) => [a.id, a]));

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-4">
        <Stat label="records" value={data.total} hint="shared service, scoped rows" />
        <Stat label="curated" value={data.counts.curated} hint="promoted after verification" accent="text-emerald-200" />
        <Stat label="candidates" value={data.counts.proposed} hint="awaiting dedupe + trust" accent="text-amber-200" />
        <Stat label="procedural" value={data.counts.procedural} hint="versioned skills, not prose" accent="text-violet-200" />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.55fr_1fr]">
        <div className="space-y-4">
          <Panel
            title="Memory records"
            subtitle="Exact scope lookup and lexical retrieval today; pgvector is a drop-in upgrade."
            actions={
              <div className="flex items-center gap-1">
                {["", "curated", "proposed", "rejected"].map((trust) => (
                  <Link
                    key={trust || "all"}
                    href={`/memory${trust ? `?trust=${trust}` : ""}${params.q ? `${trust ? "&" : "?"}q=${encodeURIComponent(params.q)}` : ""}`}
                    className={`mono rounded border px-1.5 py-0.5 text-[10px] uppercase tracking-[0.06em] ${
                      trustFilter === trust ? "border-cyan-400/40 bg-cyan-400/10 text-cyan-200" : "border-white/10 text-zinc-500 hover:text-zinc-300"
                    }`}
                  >
                    {trust || "all"}
                  </Link>
                ))}
              </div>
            }
            bodyClass="p-0"
          >
            <form action="/memory" className="flex items-center gap-2 border-b border-white/[0.06] px-4 py-2">
              <Search size={12} className="text-zinc-500" />
              <input name="q" defaultValue={params.q ?? ""} placeholder="search scope, kind or claim…" className="field h-7 flex-1 border-0 bg-transparent px-0 focus:shadow-none" />
              {trustFilter && <input type="hidden" name="trust" value={trustFilter} />}
              <button type="submit" className="btn px-2 py-1 text-[10px]">Search</button>
            </form>
            <div className="divide-y divide-white/[0.05]">
              {memories.map((memory) => {
                const agent = agentById.get(memory.agentId);
                return (
                  <div key={memory.id} className="px-4 py-2.5">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <Badge status={memory.trust} />
                      <span className="mono text-[9px] uppercase tracking-[0.08em] text-zinc-500">{memory.kind}</span>
                      <Link href={`/fleet/${memory.agentId}`} className="mono text-[9.5px] text-zinc-400 hover:text-cyan-200">
                        {agent?.handle ?? memory.agentId}
                      </Link>
                      <span className="mono rounded border border-white/[0.08] px-1 text-[9px] text-zinc-500">{memory.scope}</span>
                      <span className="mono ml-auto text-[9px] text-zinc-600">{memory.confidence}% · {memory.accessCount} reads</span>
                    </div>
                    <p className="mt-1 text-[11.5px] leading-relaxed text-zinc-300">{memory.content}</p>
                    <p className="mono mt-1 text-[9px] text-zinc-600">{memory.provenance || "no provenance recorded"} · {timeAgo(memory.createdAt)}</p>
                    <div className="mt-1.5 flex gap-1.5">
                      {memory.trust !== "curated" && (
                        <form action={memoryDecisionFormAction}>
                          <input type="hidden" name="memoryId" value={memory.id} />
                          <input type="hidden" name="decision" value="curated" />
                          <button className="btn px-1.5 py-0.5 text-[9.5px]" type="submit"><Check size={10} /> Promote</button>
                        </form>
                      )}
                      {memory.trust !== "rejected" && (
                        <form action={memoryDecisionFormAction}>
                          <input type="hidden" name="memoryId" value={memory.id} />
                          <input type="hidden" name="decision" value="rejected" />
                          <button className="btn btn-danger px-1.5 py-0.5 text-[9.5px]" type="submit"><X size={10} /> Reject</button>
                        </form>
                      )}
                      {memory.sourceWorkUnitId && (
                        <Link href={`/work/${memory.sourceWorkUnitId}`} className="btn px-1.5 py-0.5 text-[9.5px]">
                          source unit
                        </Link>
                      )}
                    </div>
                  </div>
                );
              })}
              {!memories.length && <div className="p-4"><Empty>No memory matches this query.</Empty></div>}
            </div>
          </Panel>
        </div>

        <div className="space-y-4">
          <Panel title="Compiler queue" subtitle="Candidates are never trusted on first write." bodyClass="p-0">
            <div className="divide-y divide-white/[0.05]">
              {candidates.slice(0, 6).map((memory) => (
                <div key={memory.id} className="px-4 py-2">
                  <div className="flex items-center gap-2">
                    <span className="mono text-[9px] uppercase tracking-[0.08em] text-amber-300/80">{memory.kind}</span>
                    <span className="mono ml-auto text-[9px] text-zinc-600">{memory.confidence}% confident</span>
                  </div>
                  <p className="mt-0.5 line-clamp-2 text-[10.5px] leading-relaxed text-zinc-400">{memory.content}</p>
                </div>
              ))}
              {!candidates.length && <div className="p-4"><Empty>Nothing pending review.</Empty></div>}
            </div>
          </Panel>

          <Panel title="Promotion pipeline" bodyClass="p-4">
            <ol className="space-y-2">
              {[
                ["Outcome captured", "Task result, artifact hash and receipt land first."],
                ["Extraction", "Candidate facts and procedures proposed off the critical path."],
                ["Dedupe", "Normalised subject + window comparison against curated records."],
                ["Scope & trust", "Project, org or session scope assigned with a confidence."],
                ["Contradiction check", "The verifier challenges claims that conflict with curated knowledge."],
                ["Promotion", "Only verified candidates become curated knowledge."],
                ["Skill generation", "A repeated procedure becomes a versioned skill after testing."],
              ].map(([title, body], i) => (
                <li key={title} className="flex gap-2">
                  <span className="mono mt-[2px] shrink-0 text-[9px] text-cyan-300/70">{String(i + 1).padStart(2, "0")}</span>
                  <div>
                    <p className="text-[11.5px] text-zinc-200">{title}</p>
                    <p className="text-[10.5px] leading-relaxed text-zinc-500">{body}</p>
                  </div>
                </li>
              ))}
            </ol>
          </Panel>

          <Panel title="Freshly promoted" bodyClass="p-0">
            <div className="divide-y divide-white/[0.05]">
              {curated.slice(0, 5).map((memory) => (
                <div key={memory.id} className="px-4 py-2">
                  <p className="line-clamp-2 text-[10.5px] leading-relaxed text-zinc-400">{memory.content}</p>
                  <p className="mono mt-0.5 text-[9px] text-zinc-600">{memory.scope} · {timeAgo(memory.promotedAt ?? memory.createdAt)}</p>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Rejected on purpose" bodyClass="p-0">
            <div className="divide-y divide-white/[0.05]">
              {rejected.slice(0, 3).map((memory) => (
                <div key={memory.id} className="px-4 py-2">
                  <p className="line-clamp-2 text-[10.5px] leading-relaxed text-zinc-500">{memory.content}</p>
                </div>
              ))}
              {!rejected.length && <div className="p-4"><Empty>No rejected memories. Rejections are kept as evidence, never deleted.</Empty></div>}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
