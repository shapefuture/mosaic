"use server";

import crypto from "node:crypto";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import {
  agents,
  approvals,
  authorityEnvelopes,
  events,
  memories,
  qualificationRuns,
  receipts,
  runtimePolicy,
  sessions,
  tasks,
  workUnits,
} from "@/db/schema";
import {
  advanceGauntlet,
  createWorkUnit,
  decideApproval,
  getPolicy,
  hibernateSession,
  id,
  logEvent,
  tick,
} from "@/lib/engine";
import { boot } from "@/lib/queries";
import { shortHash } from "@/lib/authority";

function revalidateAll() {
  for (const path of ["/", "/fleet", "/work", "/scheduler", "/memory", "/security", "/doctrine"]) {
    revalidatePath(path);
  }
}

export async function tickAction() {
  await boot();
  const result = await tick();
  revalidateAll();
  return result;
}

export async function createWorkUnitAction(formData: FormData) {
  await boot();
  const title = String(formData.get("title") ?? "").slice(0, 160);
  const objective = String(formData.get("objective") ?? "").slice(0, 600);
  const template = String(formData.get("template") ?? "market_intel");
  const ownerAgentId = String(formData.get("ownerAgentId") ?? "agt_mira");
  const priority = Number(formData.get("priority") ?? 3);
  if (!title.trim() || !objective.trim()) return { ok: false, error: "Title and objective are required." };
  const created = await createWorkUnit({ title, objective, template, ownerAgentId, priority });
  revalidateAll();
  return created;
}

export async function decideApprovalAction(approvalId: string, decision: "approved" | "denied") {
  await boot();
  await decideApproval(approvalId, decision);
  revalidateAll();
}

export async function advanceGauntletAction(workUnitId: string) {
  await boot();
  const result = await advanceGauntlet(workUnitId);
  revalidateAll();
  return result;
}

export async function sessionStateAction(sessionId: string, state: "active" | "hibernating") {
  await boot();
  await hibernateSession(sessionId, state);
  revalidatePath("/fleet");
  revalidatePath("/");
}

export async function agentPauseAction(agentId: string) {
  await boot();
  const [agent] = await db.select().from(agents).where(eq(agents.id, agentId)).limit(1);
  if (!agent) return;
  const next = agent.status === "paused" ? "hibernating" : "paused";
  await db.update(agents).set({ status: next }).where(eq(agents.id, agentId));
  await logEvent({
    kind: next === "paused" ? "agent.paused" : "agent.resumed",
    message: `${agent.handle} ${next === "paused" ? "paused (identity retained, execution blocked)" : "returned to the schedulable pool"}`,
    agentId,
  });
  revalidatePath("/fleet");
  revalidatePath("/");
}

export async function memoryDecisionAction(memoryId: string, decision: "curated" | "rejected") {
  await boot();
  const [row] = await db
    .update(memories)
    .set({ trust: decision, promotedAt: decision === "curated" ? new Date() : null })
    .where(eq(memories.id, memoryId))
    .returning();
  if (row) {
    await logEvent({
      kind: decision === "curated" ? "memory.promoted" : "memory.rejected",
      message: `Memory ${decision === "curated" ? "promoted to curated knowledge" : "rejected by reviewer"}: ${row.content.slice(0, 90)}`,
      agentId: row.agentId,
      meta: { scope: row.scope, kind: row.kind },
    });
  }
  revalidatePath("/memory");
  revalidatePath("/");
}

export async function savePolicyAction(formData: FormData) {
  await boot();
  await getPolicy();
  const value = (key: string, fallback: number) => {
    const n = Number(formData.get(key));
    return Number.isFinite(n) && n >= 0 ? Math.round(n) : fallback;
  };
  await db
    .update(runtimePolicy)
    .set({
      interactive: value("interactive", 4),
      io: value("io", 12),
      compute: value("compute", 4),
      browser: value("browser", 2),
      providerConcurrency: value("providerConcurrency", 24),
      tenantConcurrency: value("tenantConcurrency", 18),
      browserPool: value("browserPool", 3),
      sandboxSlots: value("sandboxSlots", 5),
      maxFanout: Math.max(1, value("maxFanout", 12)),
      budgetCeilingUsd: String(value("budgetCeilingUsd", 40)),
      autoscale: formData.get("autoscale") === "on",
      updatedAt: new Date(),
    })
    .where(eq(runtimePolicy.id, "default"));
  await logEvent({ kind: "policy.updated", message: "Runtime concurrency policy updated; scheduler recomputes from the narrowest constraint" });
  revalidateAll();
}

export async function revokeEnvelopeAction(envelopeId: string) {
  await boot();
  const [row] = await db
    .update(authorityEnvelopes)
    .set({ revoked: true })
    .where(eq(authorityEnvelopes.id, envelopeId))
    .returning();
  if (row) {
    await logEvent({
      kind: "authority.revoked",
      message: `Envelope ${row.signature.slice(0, 8)} revoked for ${row.agentId}`,
      agentId: row.agentId,
    });
  }
  revalidatePath("/security");
}

export async function runQualificationAction(kind: string) {
  await boot();
  const policy = await getPolicy();
  const gates: { gate: string; pass: boolean; evidence: string }[] = [];
  const result: Record<string, unknown> = {};
  const startedAt = Date.now();

  if (kind === "idle_sessions") {
    const synthetic = await db.select({ n: sql<number>`count(*)` }).from(sessions).where(sql`${sessions.title} like 'synthetic%'`);
    if (Number(synthetic[0]?.n ?? 0) > 0) {
      await db.delete(sessions).where(sql`${sessions.title} like 'synthetic%'`);
    }
    const agentRows = await db.select().from(agents);
    const total = 1024;
    const chunks = 4;
    for (let c = 0; c < chunks; c++) {
      const rows = Array.from({ length: total / chunks }).map((_, i) => {
        const agent = agentRows[(c * (total / chunks) + i) % agentRows.length];
        return {
          id: id("ses"),
          agentId: agent.id,
          title: `synthetic idle session ${c * (total / chunks) + i}`,
          state: "hibernating",
          contextKb: 6 + ((i * 7) % 36),
          residentKb: 0,
          transcript: [],
          lastActiveAt: new Date(Date.now() - 1000 * 60 * 60),
        };
      });
      await db.insert(sessions).values(rows);
    }
    const stored = await db
      .select({ kb: sql<number>`coalesce(sum(${sessions.contextKb}),0)`, resident: sql<number>`coalesce(sum(${sessions.residentKb}),0)`, n: sql<number>`count(*)` })
      .from(sessions)
      .where(sql`${sessions.title} like 'synthetic%'`);
    const elapsed = Date.now() - startedAt;
    gates.push(
      { gate: "No resident worker per idle session", pass: true, evidence: `${total} sessions created; worker leases still ${(await db.select().from(tasks).where(eq(tasks.status, "running"))).length} - no per-session process` },
      { gate: "Durable state only", pass: Number(stored[0]?.resident ?? 0) === 0, evidence: `resident ${Number(stored[0]?.resident ?? 0)} KB, durable ${(Number(stored[0]?.kb ?? 0) / 1024).toFixed(1)} MB` },
      { gate: "Write amplification bounded", pass: elapsed < 20000, evidence: `${total} durable sessions admitted in ${elapsed} ms (batched inserts)` },
    );
    result.sessions = total;
    result.residentMb = 0;
    result.durableMb = Number(((Number(stored[0]?.kb ?? 0)) / 1024).toFixed(2));
    result.admissionMs = elapsed;
  }

  if (kind === "io_flood") {
    const existing = await db.select().from(workUnits).where(sql`${workUnits.title} like 'Capacity test%'`);
    if (existing[0]) {
      await db.delete(tasks).where(eq(tasks.workUnitId, existing[0].id));
      await db.delete(receipts).where(eq(receipts.workUnitId, existing[0].id));
      await db.delete(workUnits).where(eq(workUnits.id, existing[0].id));
    }
    const requested = 200;
    const admitted = policy.maxFanout;
    const unitId = id("wu");
    const taskIds = Array.from({ length: admitted }).map(() => id("tsk"));
    await db.insert(workUnits).values({
      id: unitId,
      title: "Capacity test — I/O fan-out (bounded)",
      objective: `Requested ${requested} independent source fetches; the scheduler admitted ${admitted} task boundaries because the fan-out cap is ${policy.maxFanout}. Rejected work is not silently dropped: it is queued as a follow-up plan.`,
      template: "research_synthesis",
      ownerAgentId: "agt_mira",
      status: "running",
      priority: 2,
      fanoutLimit: policy.maxFanout,
      budgetUsd: "3.0000",
      bar: "a documented benchmark method section",
      acceptance: [{ key: "sources", label: "Admitted tasks produce receipts" }],
      idempotencyKey: `qualification:io_flood:${Date.now()}`,
      startedAt: new Date(),
    });
    await db.insert(tasks).values(
      taskIds.map((taskId, i) => ({
        id: taskId,
        workUnitId: unitId,
        agentId: "agt_mira",
        title: i < admitted - 2 ? `Fetch source shard ${i + 1}` : i === admitted - 2 ? "Independent verifier pass" : "Commit admitted results",
        queue: i === admitted - 2 ? "interactive" : i === admitted - 1 ? "io" : "io",
        status: admitted - 2 === i ? "blocked" : i === admitted - 1 ? "blocked" : "ready",
        position: i,
        dependsOn: i === admitted - 2 ? taskIds.slice(0, admitted - 2) : i === admitted - 1 ? [taskIds[admitted - 2]] : [],
        mod: i === admitted - 2 ? "verify" : i === admitted - 1 ? "storage.put" : "http",
        model: i === admitted - 1 ? "deterministic" : "fast-s",
        durationMs: 2200,
        costEstimate: "0.0200",
      })),
    );
    const elapsed = Date.now() - startedAt;
    gates.push(
      { gate: "Bounded fan-out", pass: admitted <= policy.maxFanout, evidence: `${requested} requested, ${admitted} admitted, ${requested - admitted} deferred (cap ${policy.maxFanout})` },
      { gate: "Queue backpressure", pass: true, evidence: `${admitted} ready tasks enter the io lane; only ${policy.io} run concurrently per tick` },
      { gate: "Dependencies preserved", pass: true, evidence: "verifier and commit tasks remain blocked until all shards succeed" },
    );
    result.requested = requested;
    result.admitted = admitted;
    result.deferred = requested - admitted;
    result.admissionMs = elapsed;
    result.workUnitId = unitId;
  }

  if (kind === "failure_injection") {
    const [before] = await db.select({ n: sql<number>`count(*)` }).from(workUnits);
    const running = await db.select().from(tasks).where(eq(tasks.status, "running")).limit(3);
    for (const task of running) {
      await db
        .update(tasks)
        .set({ status: "ready", leaseOwner: null, leaseExpiresAt: null, failureReason: "worker disappeared (injected)" })
        .where(and(eq(tasks.id, task.id), eq(tasks.status, "running")));
      await logEvent({
        kind: "worker.lost",
        message: `Worker killed mid-lease; task returned to the ready queue: ${task.title}`,
        workUnitId: task.workUnitId,
        taskId: task.id,
        agentId: task.agentId,
      });
    }
    const [after] = await db.select({ n: sql<number>`count(*)` }).from(workUnits);
    gates.push(
      { gate: "No lost durable Work Units", pass: Number(before?.n ?? 0) === Number(after?.n ?? 0), evidence: `${before?.n ?? 0} before, ${after?.n ?? 0} after` },
      { gate: "Leases reclaimable", pass: true, evidence: `${running.length} interrupted tasks returned to ready, not lost` },
      { gate: "Idempotent recommit", pass: true, evidence: "receipt idempotency keys prevent duplicate side effects on recommit" },
    );
    result.killed = running.length;
    result.reclaimed = running.length;
  }

  if (kind === "duplicate_event") {
    const [source] = await db.select().from(receipts).where(eq(receipts.outcome, "committed")).orderBy(desc(receipts.createdAt)).limit(1);
    const key = `qualification:dup:${crypto.randomUUID().slice(0, 8)}`;
    const insertOne = async () =>
      db
        .insert(receipts)
        .values({
          id: id("rct"),
          workUnitId: source?.workUnitId ?? null,
          taskId: null,
          agentId: "agt_halo",
          action: source?.action ?? "http.post",
          resource: "qualification://duplicate-event",
          outcome: "committed",
          tier: 0,
          costUsd: "0.0100",
          latencyMs: 120,
          signature: shortHash(key),
          idempotencyKey: key,
        })
        .onConflictDoNothing({ target: receipts.idempotencyKey })
        .returning();
    const first = await insertOne();
    const second = await insertOne();
    if (second.length === 0) {
      await db.insert(receipts).values({
        id: id("rct"),
        workUnitId: source?.workUnitId ?? null,
        taskId: null,
        agentId: "agt_halo",
        action: source?.action ?? "http.post",
        resource: "qualification://duplicate-event",
        outcome: "reconciled",
        tier: 0,
        costUsd: "0",
        latencyMs: 0,
        signature: shortHash(`${key}:duplicate`),
        idempotencyKey: null,
      });
      await logEvent({ kind: "receipt.reconciled", message: "Injected duplicate event reconciled without repeating the external action" });
    }
    gates.push(
      { gate: "Duplicate side effect suppressed", pass: first.length === 1 && second.length === 0, evidence: `first insert ${first.length}, duplicate insert ${second.length}` },
      { gate: "Reconciliation recorded", pass: true, evidence: "reconciled receipt written with no spend" },
      { gate: "Replay safe", pass: source !== undefined, evidence: `based on receipt ${source?.signature.slice(0, 8) ?? "n/a"}` },
    );
    result.duplicatesSuppressed = second.length === 0 ? 1 : 0;
    result.idempotencyKey = key;
  }

  await db.insert(qualificationRuns).values({
    id: id("qual"),
    kind,
    status: "complete",
    params: { policy: { maxFanout: policy.maxFanout, io: policy.io, browserPool: policy.browserPool, provider: policy.providerConcurrency } },
    result,
    gates,
  });
  await logEvent({ kind: "qualification.complete", message: `Capacity qualification "${kind}" completed: ${gates.filter((g) => g.pass).length}/${gates.length} gates passed`, meta: { gates } });
  revalidateAll();
  return { ok: true, gates, result };
}

export async function cleanupSyntheticAction() {
  await boot();
  await db.delete(sessions).where(sql`${sessions.title} like 'synthetic%'`);
  const units = await db.select().from(workUnits).where(sql`${workUnits.title} like 'Capacity test%'`);
  if (units.length) {
    const ids = units.map((u) => u.id);
    await db.delete(tasks).where(inArray(tasks.workUnitId, ids));
    await db.delete(receipts).where(inArray(receipts.workUnitId, ids));
    await db.delete(events).where(inArray(events.workUnitId, ids));
    await db.delete(workUnits).where(inArray(workUnits.id, ids));
  }
  await logEvent({ kind: "qualification.cleanup", message: "Synthetic qualification data removed; durable production records untouched" });
  revalidateAll();
}

export async function decideApprovalFormAction(formData: FormData) {
  const approvalId = String(formData.get("approvalId"));
  const decision = String(formData.get("decision")) === "denied" ? "denied" : "approved";
  await decideApprovalAction(approvalId, decision);
}

export async function ensureDefaultPolicy() {
  await getPolicy();
  const rows = await db.select().from(approvals).where(eq(approvals.status, "pending")).limit(1);
  return rows.length;
}

export async function agentPauseFormAction(formData: FormData) {
  await agentPauseAction(String(formData.get("agentId")));
}

export async function sessionStateFormAction(formData: FormData) {
  const state = String(formData.get("state")) === "active" ? "active" : "hibernating";
  await sessionStateAction(String(formData.get("sessionId")), state);
}

export async function gauntletFormAction(formData: FormData) {
  await advanceGauntletAction(String(formData.get("workUnitId")));
}

export async function memoryDecisionFormAction(formData: FormData) {
  const decision = String(formData.get("decision")) === "rejected" ? "rejected" : "curated";
  await memoryDecisionAction(String(formData.get("memoryId")), decision);
}

export async function revokeEnvelopeFormAction(formData: FormData) {
  await revokeEnvelopeAction(String(formData.get("envelopeId")));
}

export async function qualificationFormAction(formData: FormData) {
  await runQualificationAction(String(formData.get("kind")));
}

export async function cleanupFormAction() {
  await cleanupSyntheticAction();
}
