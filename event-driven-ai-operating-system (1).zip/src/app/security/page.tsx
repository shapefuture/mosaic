import Link from "next/link";
import { Check, Lock, ShieldAlert, X } from "lucide-react";
import { decideApprovalFormAction, revokeEnvelopeFormAction } from "@/app/actions";
import { Badge, Empty, Kv, Panel, Stat, TierChip } from "@/components/ui";
import { SecurityPlayground } from "@/components/security-playground";
import { getSecurity } from "@/lib/queries";
import { num, timeAgo, usd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function SecurityPage() {
  const data = await getSecurity();
  const valid = data.envelopes.filter((e) => !e.revoked && !e.expired);
  const pending = data.approvals.filter((a) => a.status === "pending");
  const denied = data.receipts.filter((r) => r.outcome === "denied");

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-4">
        <Stat label="live envelopes" value={valid.length} hint={`${data.envelopes.length} on record`} accent="text-emerald-200" icon={<Lock size={13} />} />
        <Stat label="pending gates" value={pending.length} hint="human authorization" accent="text-amber-200" />
        <Stat label="receipts sampled" value={data.receipts.length} hint="immutable action ledger" />
        <Stat label="denied actions" value={denied.length} hint="blocked at the boundary" accent="text-rose-200" icon={<ShieldAlert size={13} />} />
      </div>

      <Panel
        title="Capability boundary"
        subtitle="An agent can request an action. It cannot authorize itself."
        bodyClass="p-4"
      >
        <SecurityPlayground
          envelopes={data.envelopes.map((e) => ({
            id: e.id,
            agentId: e.agentId,
            policyVersion: e.policyVersion,
            revoked: e.revoked,
            expiresAt: e.expiresAt.toISOString(),
            payload: e.payload,
          }))}
          agentHandles={data.agents.map((a) => ({ id: a.id, handle: a.handle }))}
        />
      </Panel>

      <div className="grid gap-4 xl:grid-cols-[1.35fr_1fr]">
        <div className="space-y-4">
          <Panel title="Envelope ledger" subtitle="Signed, scoped, short-lived. Revocation is immediate." bodyClass="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[11px]">
                <thead>
                  <tr className="border-b border-white/[0.06] text-zinc-500">
                    <th className="mono px-3 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">identity</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">actions</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">ceiling</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">state</th>
                    <th className="mono px-3 py-1.5 text-right text-[9px] font-normal uppercase tracking-[0.07em]">control</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.04]">
                  {data.envelopes.map((envelope) => {
                    const expired = envelope.expired;
                    return (
                      <tr key={envelope.id} className="row-hover align-top">
                        <td className="px-3 py-1.5">
                          <Link href={`/fleet/${envelope.agentId}`} className="mono text-[10px] text-zinc-300 hover:text-cyan-200">{envelope.agentId}</Link>
                          <p className="mono text-[9px] text-zinc-600">{envelope.policyVersion} · sig {envelope.signature.slice(0, 10)}…</p>
                        </td>
                        <td className="mono px-2 py-1.5 text-[9.5px] text-zinc-400">{envelope.payload.actions.join(", ")}</td>
                        <td className="mono tnum px-2 py-1.5 text-[9.5px] text-zinc-400">{usd(envelope.payload.maxCost)}</td>
                        <td className="px-2 py-1.5">
                          <Badge tone={envelope.revoked || expired ? "text-rose-300 border-rose-400/30 bg-rose-400/10" : "text-emerald-300 border-emerald-400/30 bg-emerald-400/10"}>
                            {envelope.revoked ? "revoked" : expired ? "expired" : "live"}
                          </Badge>
                        </td>
                        <td className="px-3 py-1.5 text-right">
                          {!envelope.revoked && (
                            <form action={revokeEnvelopeFormAction}>
                              <input type="hidden" name="envelopeId" value={envelope.id} />
                              <button className="btn btn-danger px-1.5 py-0.5 text-[9.5px]" type="submit">Revoke</button>
                            </form>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Panel>

          <Panel title="Action receipts" subtitle="External side effects carry an idempotency key and a signature." bodyClass="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[11px]">
                <thead>
                  <tr className="border-b border-white/[0.06] text-zinc-500">
                    <th className="mono px-3 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">action</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">tier</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">outcome</th>
                    <th className="mono px-2 py-1.5 text-[9px] font-normal uppercase tracking-[0.07em]">signature</th>
                    <th className="mono px-3 py-1.5 text-right text-[9px] font-normal uppercase tracking-[0.07em]">when</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.04]">
                  {data.receipts.map((receipt) => (
                    <tr key={receipt.id} className="row-hover">
                      <td className="mono px-3 py-1.5 text-[10px] text-zinc-300">{receipt.action}</td>
                      <td className="px-2 py-1.5"><TierChip tier={receipt.tier} /></td>
                      <td className="px-2 py-1.5"><Badge status={receipt.outcome} /></td>
                      <td className="mono px-2 py-1.5 text-[9px] text-zinc-600">{receipt.signature}</td>
                      <td className="mono px-3 py-1.5 text-right text-[9px] text-zinc-600">{timeAgo(receipt.createdAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>

        <div className="space-y-4">
          <Panel title="Three hard invariants" bodyClass="p-4">
            <ol className="space-y-2.5">
              {[
                ["No secret reaches the model", "Credentials are injected by the broker at the tool boundary, never embedded in context."],
                ["Untrusted input cannot widen policy", "A page, email or tool result cannot amend an envelope, allowlist or delegation ceiling."],
                ["No child outranks its parent", "Delegation depth is inherited and checked on every request, not just at issue time."],
              ].map(([title, body], i) => (
                <li key={title} className="flex gap-2">
                  <span className="mono mt-[1px] shrink-0 rounded border border-rose-400/25 bg-rose-400/[0.07] px-1 text-[9px] text-rose-200">0{i + 1}</span>
                  <div>
                    <p className="text-[11.5px] text-zinc-200">{title}</p>
                    <p className="text-[10.5px] leading-relaxed text-zinc-500">{body}</p>
                  </div>
                </li>
              ))}
            </ol>
          </Panel>

          <Panel title="Approval centre" subtitle="Consequential writes pause for a human." bodyClass="p-0">
            <div className="divide-y divide-white/[0.05]">
              {data.approvals.map((approval) => (
                <div key={approval.id} className="px-4 py-2.5">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Badge status={approval.status} />
                    <Badge tone="text-zinc-400 border-zinc-600/40 bg-zinc-500/10">{approval.risk}</Badge>
                    <span className="mono text-[9.5px] text-zinc-500">{approval.action}</span>
                    <span className="mono ml-auto text-[9px] text-zinc-600">{timeAgo(approval.requestedAt)}</span>
                  </div>
                  <p className="mt-1 text-[10.5px] leading-relaxed text-zinc-400">{approval.reason}</p>
                  <p className="mono mt-0.5 text-[9px] text-zinc-600">
                    {approval.agentId} · {approval.resource} · {usd(num(approval.costUsd), 3)}
                  </p>
                  {approval.status === "pending" && (
                    <div className="mt-1.5 flex gap-1.5">
                      <form action={decideApprovalFormAction}>
                        <input type="hidden" name="approvalId" value={approval.id} />
                        <input type="hidden" name="decision" value="approved" />
                        <button className="btn btn-primary px-1.5 py-0.5 text-[9.5px]" type="submit"><Check size={10} /> Authorize</button>
                      </form>
                      <form action={decideApprovalFormAction}>
                        <input type="hidden" name="approvalId" value={approval.id} />
                        <input type="hidden" name="decision" value="denied" />
                        <button className="btn btn-danger px-1.5 py-0.5 text-[9.5px]" type="submit"><X size={10} /> Deny</button>
                      </form>
                      <Link href={`/work/${approval.workUnitId}`} className="btn px-1.5 py-0.5 text-[9.5px]">unit</Link>
                    </div>
                  )}
                </div>
              ))}
              {!data.approvals.length && <div className="p-4"><Empty>No approvals requested.</Empty></div>}
            </div>
          </Panel>

          <Panel title="Policy shape" bodyClass="p-4">
            <Kv
              items={[
                { k: "evaluation", v: "deterministic, in-process (Cedar-equivalent rules)" },
                { k: "signing", v: <span className="mono text-[10px]">HMAC-SHA256 · 32-char signature</span> },
                { k: "scope", v: "role + work unit + session + domain + cost" },
                { k: "revocation", v: "ledger flag checked on every request" },
                { k: "network", v: "default deny; domain allowlist enforced outside the model" },
                { k: "relationship layer", v: "SQL resource grants; OpenFGA only if the graph outgrows joins" },
              ]}
            />
          </Panel>
        </div>
      </div>
    </div>
  );
}
