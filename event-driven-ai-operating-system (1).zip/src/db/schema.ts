import {
  boolean,
  integer,
  jsonb,
  numeric,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/** Logical agent identity. Never a process. */
export const agents = pgTable("agents", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  handle: text("handle").notNull().unique(),
  role: text("role").notNull(),
  department: text("department").notNull(),
  /** active | hibernating | paused | retired */
  status: text("status").notNull().default("hibernating"),
  profileVersion: text("profile_version").notNull().default("v3.0.0"),
  capabilities: jsonb("capabilities").$type<string[]>().notNull().default([]),
  modelPolicy: jsonb("model_policy")
    .$type<{ planner: string; worker: string; verifier: string }>()
    .notNull()
    .default({ planner: "reasoning-xl", worker: "fast-s", verifier: "eval-m" }),
  memoryScope: text("memory_scope").notNull(),
  authority: jsonb("authority")
    .$type<{
      actions: string[];
      resources: string[];
      domains: string[];
      maxCost: number;
      delegationDepth: number;
    }>()
    .notNull()
    .default({ actions: [], resources: [], domains: [], maxCost: 0, delegationDepth: 1 }),
  budgetUsd: numeric("budget_usd", { precision: 12, scale: 4 }).notNull().default("25"),
  spentUsd: numeric("spent_usd", { precision: 12, scale: 4 }).notNull().default("0"),
  color: text("color").notNull().default("#7dd3fc"),
  glyph: text("glyph").notNull().default("◆"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastActiveAt: timestamp("last_active_at", { withTimezone: true }),
});

/** Durable conversation actor. Hibernates when idle. */
export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  agentId: text("agent_id").notNull(),
  workUnitId: text("work_unit_id"),
  title: text("title").notNull(),
  /** active | hibernating | closed */
  state: text("state").notNull().default("hibernating"),
  storage: text("storage").notNull().default("DO SQLite"),
  contextKb: integer("context_kb").notNull().default(0),
  residentKb: integer("resident_kb").notNull().default(0),
  transcript: jsonb("transcript")
    .$type<{ role: string; content: string; at: string }[]>()
    .notNull()
    .default([]),
  pendingToolCalls: integer("pending_tool_calls").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastActiveAt: timestamp("last_active_at", { withTimezone: true }).notNull().defaultNow(),
});

export const skills = pgTable("skills", {
  id: text("id").primaryKey(),
  agentId: text("agent_id").notNull(),
  name: text("name").notNull(),
  version: text("version").notNull(),
  /** active | proposed | quarantined */
  status: text("status").notNull().default("active"),
  successRate: integer("success_rate").notNull().default(90),
  evaluations: integer("evaluations").notNull().default(0),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
});

export const workUnits = pgTable("work_units", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  objective: text("objective").notNull(),
  template: text("template").notNull(),
  ownerAgentId: text("owner_agent_id").notNull(),
  /** planned | running | waiting_approval | verifying | done | failed | cancelled */
  status: text("status").notNull().default("planned"),
  priority: integer("priority").notNull().default(3),
  fanoutLimit: integer("fanout_limit").notNull().default(6),
  budgetUsd: numeric("budget_usd", { precision: 12, scale: 4 }).notNull().default("8"),
  spentUsd: numeric("spent_usd", { precision: 12, scale: 4 }).notNull().default("0"),
  bar: text("bar").notNull().default(""),
  acceptance: jsonb("acceptance").$type<{ key: string; label: string }[]>().notNull().default([]),
  idempotencyKey: text("idempotency_key").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
});

export const tasks = pgTable("tasks", {
  id: text("id").primaryKey(),
  workUnitId: text("work_unit_id").notNull(),
  agentId: text("agent_id").notNull(),
  title: text("title").notNull(),
  /** interactive | io | compute | browser */
  queue: text("queue").notNull().default("io"),
  /** blocked | ready | running | waiting_approval | succeeded | failed */
  status: text("status").notNull().default("blocked"),
  tier: integer("tier").notNull().default(0),
  position: integer("position").notNull().default(0),
  dependsOn: jsonb("depends_on").$type<string[]>().notNull().default([]),
  mod: text("mod").notNull().default("api"),
  model: text("model").notNull().default("fast-s"),
  gauntlet: boolean("gauntlet").notNull().default(false),
  consequential: boolean("consequential").notNull().default(false),
  attempts: integer("attempts").notNull().default(0),
  maxAttempts: integer("max_attempts").notNull().default(2),
  durationMs: integer("duration_ms").notNull().default(2400),
  costEstimate: numeric("cost_estimate", { precision: 12, scale: 4 }).notNull().default("0.05"),
  costActual: numeric("cost_actual", { precision: 12, scale: 4 }).notNull().default("0"),
  tokensIn: integer("tokens_in").notNull().default(0),
  tokensOut: integer("tokens_out").notNull().default(0),
  leaseOwner: text("lease_owner"),
  leaseExpiresAt: timestamp("lease_expires_at", { withTimezone: true }),
  verifyStatus: text("verify_status").notNull().default("pending"),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  output: text("output"),
  failureReason: text("failure_reason"),
});

export const workers = pgTable("workers", {
  id: text("id").primaryKey(),
  pool: text("pool").notNull(),
  /** busy | idle */
  status: text("status").notNull().default("busy"),
  taskId: text("task_id"),
  memoryMb: integer("memory_mb").notNull().default(64),
  tier: integer("tier").notNull().default(0),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
});

export const receipts = pgTable("receipts", {
  id: text("id").primaryKey(),
  workUnitId: text("work_unit_id"),
  taskId: text("task_id"),
  agentId: text("agent_id"),
  action: text("action").notNull(),
  resource: text("resource").notNull(),
  domain: text("domain"),
  /** committed | denied | reconciled */
  outcome: text("outcome").notNull().default("committed"),
  tier: integer("tier").notNull().default(0),
  costUsd: numeric("cost_usd", { precision: 12, scale: 4 }).notNull().default("0"),
  latencyMs: integer("latency_ms").notNull().default(0),
  policyVersion: text("policy_version").notNull().default("v3"),
  signature: text("signature").notNull().default(""),
  idempotencyKey: text("idempotency_key").unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const authorityEnvelopes = pgTable("authority_envelopes", {
  id: text("id").primaryKey(),
  agentId: text("agent_id").notNull(),
  workUnitId: text("work_unit_id"),
  token: text("token").notNull(),
  signature: text("signature").notNull(),
  payload: jsonb("payload")
    .$type<{
      actions: string[];
      resources: string[];
      domains: string[];
      maxCost: number;
      delegationDepth: number;
      expiresAt: string;
    }>()
    .notNull(),
  policyVersion: text("policy_version").notNull().default("v3"),
  revoked: boolean("revoked").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

export const memories = pgTable("memories", {
  id: text("id").primaryKey(),
  agentId: text("agent_id").notNull(),
  scope: text("scope").notNull(),
  /** preference | episodic | semantic | procedural */
  kind: text("kind").notNull().default("semantic"),
  content: text("content").notNull(),
  /** proposed | curated | rejected */
  trust: text("trust").notNull().default("proposed"),
  confidence: integer("confidence").notNull().default(60),
  sourceTaskId: text("source_task_id"),
  sourceWorkUnitId: text("source_work_unit_id"),
  provenance: text("provenance").notNull().default(""),
  accessCount: integer("access_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  promotedAt: timestamp("promoted_at", { withTimezone: true }),
});

export const approvals = pgTable("approvals", {
  id: text("id").primaryKey(),
  workUnitId: text("work_unit_id").notNull(),
  taskId: text("task_id").notNull(),
  agentId: text("agent_id").notNull(),
  action: text("action").notNull(),
  resource: text("resource").notNull(),
  risk: text("risk").notNull().default("medium"),
  reason: text("reason").notNull(),
  costUsd: numeric("cost_usd", { precision: 12, scale: 4 }).notNull().default("0"),
  /** pending | approved | denied */
  status: text("status").notNull().default("pending"),
  decidedBy: text("decided_by"),
  requestedAt: timestamp("requested_at", { withTimezone: true }).notNull().defaultNow(),
  decidedAt: timestamp("decided_at", { withTimezone: true }),
});

export const gauntletRounds = pgTable("gauntlet_rounds", {
  id: text("id").primaryKey(),
  workUnitId: text("work_unit_id").notNull(),
  taskId: text("task_id"),
  round: integer("round").notNull().default(1),
  bar: text("bar").notNull(),
  artifactTitle: text("artifact_title").notNull(),
  artifact: text("artifact").notNull(),
  criticVerdict: text("critic_verdict").notNull().default("bar"),
  gap: text("gap").notNull().default(""),
  criticNote: text("critic_note").notNull().default(""),
  costUsd: numeric("cost_usd", { precision: 12, scale: 4 }).notNull().default("0"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const events = pgTable("events", {
  id: text("id").primaryKey(),
  kind: text("kind").notNull(),
  message: text("message").notNull(),
  workUnitId: text("work_unit_id"),
  taskId: text("task_id"),
  agentId: text("agent_id"),
  meta: jsonb("meta").$type<Record<string, unknown>>(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const runtimePolicy = pgTable("runtime_policy", {
  id: text("id").primaryKey(),
  interactive: integer("interactive").notNull().default(4),
  io: integer("io").notNull().default(12),
  compute: integer("compute").notNull().default(4),
  browser: integer("browser").notNull().default(2),
  providerConcurrency: integer("provider_concurrency").notNull().default(24),
  tenantConcurrency: integer("tenant_concurrency").notNull().default(18),
  browserPool: integer("browser_pool").notNull().default(3),
  sandboxSlots: integer("sandbox_slots").notNull().default(5),
  budgetCeilingUsd: numeric("budget_ceiling_usd", { precision: 12, scale: 2 }).notNull().default("40"),
  maxFanout: integer("max_fanout").notNull().default(8),
  autoscale: boolean("autoscale").notNull().default(true),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const metrics = pgTable("metrics", {
  id: text("id").primaryKey(),
  at: timestamp("at", { withTimezone: true }).notNull().defaultNow(),
  activeTurns: integer("active_turns").notNull().default(0),
  idleSessions: integer("idle_sessions").notNull().default(0),
  queueDepth: integer("queue_depth").notNull().default(0),
  running: integer("running").notNull().default(0),
  committed: integer("committed").notNull().default(0),
  spendUsd: numeric("spend_usd", { precision: 12, scale: 4 }).notNull().default("0"),
  residentMb: integer("resident_mb").notNull().default(0),
});

export const qualificationRuns = pgTable("qualification_runs", {
  id: text("id").primaryKey(),
  kind: text("kind").notNull(),
  status: text("status").notNull().default("complete"),
  params: jsonb("params").$type<Record<string, unknown>>().notNull().default({}),
  result: jsonb("result").$type<Record<string, unknown>>().notNull().default({}),
  gates: jsonb("gates").$type<{ gate: string; pass: boolean; evidence: string }[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Delivery ledger: the plan and its proof (full-plan-delivery skill). */
export const deliveryTasks = pgTable("delivery_tasks", {
  id: text("id").primaryKey(),
  stage: text("stage").notNull(),
  code: text("code").notNull(),
  title: text("title").notNull(),
  /** done | in_progress | blocked | planned */
  status: text("status").notNull().default("planned"),
  acceptance: text("acceptance").notNull(),
  evidence: text("evidence").notNull().default(""),
  blocker: text("blocker").notNull().default(""),
  position: integer("position").notNull().default(0),
});

export const systemFlags = pgTable("system_flags", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});

export type Agent = typeof agents.$inferSelect;
export type Session = typeof sessions.$inferSelect;
export type WorkUnit = typeof workUnits.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type Receipt = typeof receipts.$inferSelect;
export type Memory = typeof memories.$inferSelect;
export type Approval = typeof approvals.$inferSelect;
export type GauntletRound = typeof gauntletRounds.$inferSelect;
export type EventRow = typeof events.$inferSelect;
export type RuntimePolicy = typeof runtimePolicy.$inferSelect;
export type Worker = typeof workers.$inferSelect;
export type QualificationRun = typeof qualificationRuns.$inferSelect;
export type DeliveryTask = typeof deliveryTasks.$inferSelect;
export type Skill = typeof skills.$inferSelect;
export type AuthorityEnvelope = typeof authorityEnvelopes.$inferSelect;
